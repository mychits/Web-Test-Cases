import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UserAccountsMenu.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useState = __vite__cjsImport3_react["useState"];
import { Link, useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import {
  Select,
  Button,
  Spin,
  Input,
  Drawer,
  message,
  Divider,
  Alert,
  Timeline,
  Tag,
  Avatar,
  Card,
  Modal as antModal,
  Empty,
  DatePicker,
  Tabs,
  Radio,
  Modal as AntModal,
  Form,
  Descriptions,
  Space,
  Row,
  Col,
  Table,
  notification
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  CalendarOutlined,
  ExclamationCircleOutlined,
  FileTextOutlined,
  FundProjectionScreenOutlined,
  GroupOutlined,
  SwapOutlined,
  UserOutlined,
  StopOutlined,
  ArrowRightOutlined,
  TransactionOutlined,
  LockOutlined,
  SafetyOutlined,
  CloseCircleOutlined,
  CheckCircleOutlined,
  InfoCircleOutlined,
  ThunderboltOutlined,
  PauseCircleOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import __vite__cjsImport7_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport7_dayjs.__esModule ? __vite__cjsImport7_dayjs.default : __vite__cjsImport7_dayjs;
import { FaCalculator, FaRupeeSign, FaWhatsappSquare } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import QuickSearchContent from "/src/pages/QuickSearchContent.jsx";
import api from "/src/instance/TokenInstance.js";
import { MdCancel, MdCheck } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { FiShuffle } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { VscRemove } from "/node_modules/.vite/deps/react-icons_vsc.js?v=819e0a34";
import { IndianRupee } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import SuspendedCustomerReport from "/src/pages/SuspendedCustomerReport.jsx";
const UserAccountsMenu = () => {
  _s();
  const navigate = useNavigate();
  const [cancelRequests, setCancelRequests] = useState([]);
  const [cancelRequestsLoading, setCancelRequestsLoading] = useState(false);
  const [requestTypeFilter, setRequestTypeFilter] = useState("chit");
  const [isAddRequestModalOpen, setIsAddRequestModalOpen] = useState(false);
  const [addRequestForm] = Form.useForm();
  const [users, setUsers] = useState([]);
  const [customerEnrollments, setCustomerEnrollments] = useState([]);
  const [pigmyData, setPigmyData] = useState([]);
  const [loanData, setLoanData] = useState([]);
  const [loadingEnrollments, setLoadingEnrollments] = useState(false);
  const [loadingPigmy, setLoadingPigmy] = useState(false);
  const [loadingLoans, setLoadingLoans] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedEnrollmentData, setSelectedEnrollmentData] = useState(null);
  const [activeActionType, setActiveActionType] = useState(null);
  const [errors, setErrors] = useState({});
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [quickSearchKey, setQuickSearchKey] = useState(0);
  const [transactions, setTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [groups, setGroups] = useState([]);
  const [overview, setOverview] = useState({ totalCount: 0, totalAmount: 0 });
  const [filters, setFilters] = useState({
    group_id: "",
    user_id: "",
    startDate: "",
    endDate: ""
  });
  const { RangePicker } = DatePicker;
  const location = useLocation();
  const [showModal, setShowModal] = useState(false);
  const [step, setStep] = useState(1);
  const [enrollments, setEnrollments] = useState([]);
  const [selectedEnrollId, setSelectedEnrollId] = useState(null);
  const [selectedEnroll, setSelectedEnroll] = useState(null);
  const [totalAmount, setTotalAmount] = useState(null);
  const [loading, setLoading] = useState(false);
  const [remarkType, setRemarkType] = useState(null);
  const [customRemark, setCustomRemark] = useState("");
  const [moveRemark, setMoveRemark] = useState("");
  const [confirmInput, setConfirmInput] = useState("");
  const [availableAmount, setAvailableAmount] = useState(0);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [activeTabKey, setActiveTabKey] = useState(() => {
    return location.state?.activeTab || "cancel-requests";
  });
  const [transferLoading, setTransferLoading] = useState(false);
  const [openAntDDrawer, setOpenAntDDrawer] = useState(false);
  const [lastAllPayments, setLastAllPayments] = useState([]);
  const [serviceCharge, setServiceCharge] = useState(0);
  const [finalAmount, setFinalAmount] = useState(0);
  const [gstAmount, setGstAmount] = useState();
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [withdrawData, setWithdrawData] = useState(null);
  const [showCalculated, setShowCalculated] = useState(false);
  const [editableInterest, setEditableInterest] = useState("");
  const [raisingRequestLoading, setRaisingRequestLoading] = useState(false);
  const [gstPercentage, setGstPercentage] = useState(18);
  const [paymentDate, setPaymentDate] = useState(null);
  const [showModelOnHold, setShowModelOnHold] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [adminId, setAdminId] = useState("");
  const [withdrawLoading, setWithdrawLoading] = useState(false);
  const [rawTransactions, setRawTransactions] = useState([]);
  const [deductionAmount, setDeductionAmount] = useState("");
  const [thirdPartyEnable, setThirdPartyEnable] = useState({
    send_whatsapp: false,
    send_gmail: false,
    send_sms: false
  });
  const [enrollmentOperation, setEnrollmentOperation] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const resetForm = () => {
    setTotalAmount(null);
    setSelectedEnrollId(null);
    setSelectedEnroll(null);
    setMoveRemark("");
    setRemarkType(null);
    setCustomRemark("");
    setAvailableAmount(0);
    setSelectedUserId(null);
    setConfirmInput("");
    setStep(1);
  };
  const handleCloseModal = () => {
    setShowModal(false);
    resetForm();
  };
  const totalPaid = withdrawData?.total_paid;
  const handlePercentBlur = () => {
    if (!editableInterest || totalPaid <= 0) {
      setDeductionAmount("");
      return;
    }
    const percent = parseFloat(editableInterest);
    if (isNaN(percent) || percent < 0) {
      setDeductionAmount("");
      return;
    }
    const calculatedAmount = percent / 100 * totalPaid;
    setDeductionAmount(calculatedAmount.toFixed(2));
  };
  const handleAmountBlur = () => {
    if (!deductionAmount || totalPaid <= 0) {
      setEditableInterest("");
      return;
    }
    const amount = parseFloat(deductionAmount);
    if (isNaN(amount) || amount < 0) {
      setEditableInterest("");
      return;
    }
    const calculatedPercent = amount / totalPaid * 100;
    setEditableInterest(calculatedPercent.toFixed(2));
  };
  const handleSyncFields = () => {
    if (editableInterest && totalPaid > 0) {
      const percent = parseFloat(editableInterest);
      if (!isNaN(percent) && percent >= 0) {
        const amt = percent / 100 * totalPaid;
        setDeductionAmount(amt.toFixed(0));
      }
    } else if (deductionAmount && totalPaid > 0) {
      const amt = parseFloat(deductionAmount);
      if (!isNaN(amt) && amt >= 0) {
        const pct = amt / totalPaid * 100;
        setEditableInterest(pct.toFixed(2));
      }
    }
  };
  useEffect(() => {
    const user = localStorage.getItem("user");
    if (user) {
      const userObj = JSON.parse(user);
      setAdminId(userObj?._id);
    }
  }, []);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await api.get("user/verified");
        setUsers(res.data?.data || []);
      } catch (error) {
        console.error("Error fetching users", error);
      }
    };
    fetchUsers();
  }, []);
  useEffect(() => {
    const gross = Number(totalAmount) || 0;
    const charge = Number(serviceCharge) || 0;
    const gst = Number(gstAmount) || 0;
    const net = gross - charge - gst;
    setFinalAmount(net >= 0 ? net : 0);
  }, [totalAmount, serviceCharge, gstAmount]);
  useEffect(() => {
    const status = pigmyData?.[0]?.request_status;
    if (status === "APPROVED") {
      notification.success({
        message: "Pigmy Withdrawal Completed",
        description: "Pigmy withdrawal completed. Go to Pigmy Payment Out page to view remaining payout.",
        placement: "topRight"
      });
    }
  }, [pigmyData]);
  useEffect(() => {
    if (location.state?.activeTab) {
      window.history.replaceState({}, document.title);
    }
  }, [location]);
  const handleQuickSearchSelect = (record) => {
    if (!record) return;
    const customer = {
      _id: record._id,
      full_name: record.name,
      phone_number: record.phone_number,
      customer_id: record.customer_id,
      adhaar_no: record.aadhaar_number
    };
    setSelectedCustomer(customer);
    setSelectedEnrollmentData(null);
    fetchCustomerPortfolio(record._id);
    setQuickSearchKey((prev) => prev + 1);
    setTimeout(() => {
      const portfolioElement = document.getElementById("customer-portfolio");
      if (portfolioElement) {
        portfolioElement.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }, 300);
  };
  const fetchCustomerPortfolio = async (userId) => {
    if (!userId) {
      setCustomerEnrollments([]);
      setPigmyData([]);
      setLoanData([]);
      setSelectedEnrollmentData(null);
      return;
    }
    setLoadingEnrollments(true);
    setLoadingPigmy(true);
    setLoadingLoans(true);
    try {
      const [enrollResult, pigmyResult, loanResult] = await Promise.allSettled(
        [
          api.post(`/enroll/get-user-tickets-report/${userId}`),
          api.get(`/payment/pigme/user/${userId}`),
          api.get(`/payment/loan/user/${userId}`)
        ]
      );
      if (enrollResult.status === "fulfilled") {
        const reportData = enrollResult.value?.data || [];
        const groupIds = [
          ...new Set(
            reportData.map((item) => item?.enrollment?.group?._id).filter(Boolean)
          )
        ];
        const groupEnrollResults = await Promise.allSettled(
          groupIds.map(
            (groupId) => api.get(`/enroll/get-group-enroll/${groupId}`)
          )
        );
        const updatedEnrollments = reportData.map((item) => {
          const groupId = item?.enrollment?.group?._id;
          const resultIndex = groupIds.indexOf(groupId);
          const groupEnrollResult = groupEnrollResults[resultIndex];
          let enrollmentDetails = null;
          if (groupEnrollResult?.status === "fulfilled") {
            const responseData = groupEnrollResult.value?.data;
            const groupEnrollments = Array.isArray(responseData) ? responseData : responseData?.data || [];
            enrollmentDetails = groupEnrollments.find(
              (enrollment) => {
                const enrollmentUserId = enrollment?.user_id?._id || enrollment?.user_id;
                return String(enrollmentUserId) === String(userId);
              }
            );
          }
          return {
            ...item,
            // Actual enrollment document ID
            enrollmentId: enrollmentDetails?._id || null,
            // Keep complete enrollment object if required
            enrollmentDetails: enrollmentDetails || null
          };
        });
        setCustomerEnrollments(updatedEnrollments);
      } else {
        console.error(
          "Error fetching enrollments:",
          enrollResult.reason
        );
        setCustomerEnrollments([]);
      }
      if (pigmyResult.status === "fulfilled") {
        const rawData = pigmyResult.value.data?.overall_pigme || pigmyResult.value?.overall_pigme || [];
        const transformedPigmy = rawData.map((item) => {
          const pigme = item.pigme_details?.pigme || {};
          return {
            ...item,
            _id: pigme._id,
            request_status: pigme.request_status || null,
            // Flatten useful fields
            maturity_period: pigme.maturity_period,
            payable_amount: pigme.payable_amount,
            duration: pigme.duration,
            start_date: pigme.start_date,
            pigme_id: pigme.pigme_id,
            maturity_interest: pigme.maturity_interest
          };
        });
        setPigmyData(transformedPigmy);
      } else {
        console.warn(
          "User has no pigmy data or API failed",
          pigmyResult.reason
        );
        setPigmyData([]);
      }
      if (loanResult.status === "fulfilled") {
        const loans = loanResult.value.data?.overall_loan || [];
        setLoanData(loans);
      } else {
        console.error(
          "Error fetching loans:",
          loanResult.reason
        );
        setLoanData([]);
      }
    } catch (error) {
      console.error(
        "Unexpected error in portfolio fetch:",
        error
      );
      setCustomerEnrollments([]);
      setPigmyData([]);
      setLoanData([]);
    } finally {
      setLoadingEnrollments(false);
      setLoadingPigmy(false);
      setLoadingLoans(false);
    }
  };
  const checkCustomerOperationAllowed = () => {
    const status = selectedEnrollmentData?.enrollment?.customer_status || selectedEnrollmentData?.customer_status || selectedEnrollmentData?.enrollmentDetails?.customer_status || "";
    const normalizedStatus = status.trim().toLowerCase();
    if (["on hold", "inactive"].includes(normalizedStatus)) {
      message.warning(
        `Customer is ${status}. No operations are allowed.`
      );
      return false;
    }
    return true;
  };
  const handleRaiseWithdrawRequest = async (pigmyId) => {
    if (!pigmyId) {
      message.error("Invalid pigmy ID");
      return;
    }
    setRaisingRequestLoading(true);
    try {
      await api.patch(`/v1/admin/pigmes/status/${pigmyId}`, {
        request_status: "REQUESTED"
      });
      setPigmyData(
        (prev) => prev.map(
          (p) => p._id === pigmyId ? { ...p, request_status: "REQUESTED" } : p
        )
      );
      const customerName = selectedCustomer?.full_name || "Customer";
      const amount = pigmyData.find((p) => p._id === pigmyId)?.total_deposited_amount || 0;
      notification.success({
        message: "Pigmy Withdrawal Request",
        description: `${customerName} has raised a withdrawal request of ₹${amount}`,
        placement: "topRight"
      });
    } catch (error) {
      console.error("Error raising withdraw request:", error);
      message.error("Failed to raise withdraw request");
    } finally {
      setRaisingRequestLoading(false);
    }
  };
  const fetchPigmyDetails = async (pigmyId) => {
    try {
      const response = await api.get(`/v1/admin/pigmes/${pigmyId}`);
      if (response.data.success) {
        return response.data.data;
      } else {
        throw new Error("Failed to fetch pigmy data");
      }
    } catch (error) {
      console.error("Error fetching pigmy details:", error);
      message.error("Could not load pigmy details");
      return null;
    }
  };
  const handleOpenWithdrawModal = async (pigmyId) => {
    const details = await fetchPigmyDetails(pigmyId);
    if (details) {
      setWithdrawData(details);
      setEditableInterest(details.pre_matured_interest?.toString() || "");
      setShowCalculated(false);
      setShowWithdrawModal(true);
    }
  };
  const handleRecalculate = async () => {
    const newErrors = {};
    if (!editableInterest) {
      newErrors.editableInterest = "Enter the Interest required to calculate Maturity amount";
    }
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;
    if (!withdrawData) return;
    try {
      const response = await api.put(`/v1/admin/pigmes/pigme-closer/${withdrawData._id}`, {
        pre_matured_interest: editableInterest
      });
      if (response.data.status) {
        setWithdrawData((prev) => ({ ...prev, ...response.data.data }));
        setShowCalculated(true);
        message.success("Recalculation successful");
      } else {
        throw new Error("Calculation failed");
      }
    } catch (error) {
      console.error("Error calculating withdrawal:", error);
      message.error(error.response?.data?.message || "Failed to calculate");
    }
  };
  const handleWithdraw = async () => {
    const admin = JSON.parse(localStorage.getItem("user") || "{}");
    if (!withdrawData) return;
    try {
      setWithdrawLoading(true);
      const payload = {
        removalReason: "Pigmy Withdrawal",
        netPayable: withdrawData.maturity_amount,
        adminId: admin._id
      };
      await api.post(`/v1/admin/pigmes/${withdrawData._id}/admins/${adminId}/remove`, payload);
      message.success("Pigmy withdrawal completed successfully");
      setShowWithdrawModal(false);
      setWithdrawData(null);
      setShowCalculated(false);
      if (selectedCustomer?._id) {
        fetchCustomerPortfolio(selectedCustomer._id);
      }
    } catch (error) {
      console.error("Error removing pigmy:", error);
      message.error(error.response?.data?.message || "Failed to complete withdrawal");
    } finally {
      setWithdrawLoading(false);
    }
  };
  const handleActionClick = (actionType, contextData) => {
    setActionLoading(true);
    if (!activeActionType) {
      setActiveActionType(actionType);
    }
    const { enrollment } = contextData || {};
    const enrollmentId = contextData?.enrollmentId;
    const enrollmentDetails = contextData?.enrollmentDetails;
    if (!enrollmentId) {
      message.error("Enrollment ID missing. Please refresh the page or contact support.");
      setActionLoading(false);
      return;
    }
    setSelectedEnrollId(enrollmentId);
    setSelectedEnroll(enrollmentDetails || enrollment);
    setSelectedUserId(
      enrollmentDetails?.user_id?._id || enrollment?.user_id?._id || selectedCustomer?._id
    );
    setSelectedEnrollmentData(contextData);
    if (actionType.includes("CHIT")) {
      addRequestForm.setFieldsValue({
        group_id: enrollmentDetails?.group_id?._id || enrollment?.group?._id,
        ticket: enrollmentDetails?.tickets || enrollment?.tickets,
        user_id: enrollmentDetails?.user_id?._id || enrollment?.user_id?._id,
        amount: "",
        reason: ""
      });
    } else if (actionType.includes("PIGMY") && selectedCustomer) {
      addRequestForm.setFieldsValue({
        user_id: selectedCustomer._id,
        amount: "",
        reason: ""
      });
    }
    setTimeout(() => {
      document.getElementById("action-form-section")?.scrollIntoView({
        behavior: "smooth"
      });
      setActionLoading(false);
    }, 300);
  };
  const handleAddCancelRequest = async (values) => {
    try {
      setCancelRequestsLoading(true);
      const payload = { ...values, request_type: activeActionType || requestTypeFilter, action: activeActionType };
      await api.post("/chit-cancle/cancel-requests", payload);
      message.success("Request submitted successfully");
      setIsAddRequestModalOpen(false);
      addRequestForm.resetFields();
      setActiveActionType(null);
      setSelectedCustomer(null);
      setCustomerEnrollments([]);
      setPigmyData([]);
    } catch (error) {
      message.error("Failed to submit request");
    } finally {
      setCancelRequestsLoading(false);
    }
  };
  useEffect(() => {
    const fetchEnrollments = async () => {
      try {
        const res = await api.get("/enroll/get-enroll");
        setEnrollments(
          (res.data || []).filter(
            (item) => item.group_id != null && item.user_id != null && item.tickets != null
          )
        );
      } catch (error) {
        console.error("Error fetching enrollments:", error);
      }
    };
    fetchEnrollments();
  }, []);
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const [groupRes, userRes] = await Promise.all(
          [
            api.get("/group/get-group-admin"),
            api.get("user/verified")
          ]
        );
        setGroups(groupRes.data || []);
        setUsers(userRes.data?.data || []);
      } catch (error) {
        console.error("Error fetching initial data", error);
      }
    };
    fetchInitialData();
  }, []);
  useEffect(() => {
    if (selectedEnrollId) fetchTotalAmount();
    else
      setTotalAmount(null);
  }, [selectedEnrollId]);
  useEffect(() => {
    const fetchTransactions = async () => {
      setIsLoading(true);
      try {
        const params = {};
        if (filters.group_id) params.group_id = filters.group_id;
        if (filters.user_id) params.user_id = filters.user_id;
        if (filters.startDate) params.startDate = filters.startDate;
        if (filters.endDate) params.endDate = filters.endDate;
        const response = await api.get("/v1/admin/transaction-history/", { params });
        if (response.data?.data) {
          setRawTransactions(response.data.data || []);
          const formattedData = response.data.data.map((item, index) => {
            const formatCurrency = (value) => value != null && !isNaN(value) ? `₹${Number(value).toLocaleString("en-IN")}` : "-";
            const interestAmount = item?.interest_amount ?? item?.intrest_amount ?? 0;
            let gstDisplay = "-";
            if (item.gst_amount != null && item.gst_amount !== 0) {
              gstDisplay = /* @__PURE__ */ jsxDEV("span", { className: "text-red-600", children: formatCurrency(item.gst_amount) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 753,
                columnNumber: 28
              }, this);
            } else if (item.pigme_id && Object.keys(item.pigme_id).length > 0) {
              const isPreMatured = item.pigme_id?.closure_type === "PRE-MATURED";
              const sign = isPreMatured ? "-" : "+";
              const colorClass = isPreMatured ? "text-red-600" : "text-green-600";
              gstDisplay = /* @__PURE__ */ jsxDEV("span", { className: colorClass, children: [
                sign,
                " ",
                formatCurrency(interestAmount)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 760,
                columnNumber: 15
              }, this);
            } else if (interestAmount !== 0) {
              gstDisplay = /* @__PURE__ */ jsxDEV("span", { className: "text-green-600", children: formatCurrency(interestAmount) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 765,
                columnNumber: 28
              }, this);
            }
            return {
              id: index + 1,
              date: item.transaction_date ? dayjs(item.transaction_date).format("DD-MM-YYYY") : "-",
              user_name: item.enroll_id?.user_id?.full_name || item?.pigme_id?.customer?.full_name || "N/A",
              group_name: item.enroll_id?.group_id?.group_name || item?.pigme_id?.pigme_id || "N/A",
              ticket: item.enroll_id?.tickets || item?.pigme_id?.closure_type || "N/A",
              amount: formatCurrency(item.amount),
              gross_amount: formatCurrency(item.gross_amount),
              gst_amount: gstDisplay,
              service_charge: formatCurrency(item.service_charge),
              reason: item.reason || "N/A",
              type: /* @__PURE__ */ jsxDEV(Tag, { color: item.transaction_type === "credit" ? "green" : "orange", children: item.transaction_type?.toUpperCase() || "N/A" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 780,
                columnNumber: 15
              }, this),
              admin: item.admin_id?.name || "System"
            };
          });
          setTransactions(formattedData);
          setOverview({
            totalCount: formattedData.length,
            totalAmount: response.data.data.reduce((acc, curr) => acc + (curr.amount || 0), 0)
          });
        } else {
          setTransactions([]);
        }
      } catch (error) {
        console.error("Error fetching transactions:", error);
        setTransactions([]);
      } finally {
        setIsLoading(false);
      }
    };
    fetchTransactions();
  }, [filters, reloadTrigger]);
  const stats = useMemo(() => {
    if (!rawTransactions.length) return null;
    const chitCancel = rawTransactions.filter(
      (t) => t.reason && t.reason.toLowerCase().includes("cancel")
    );
    const pigmy = rawTransactions.filter((t) => t.pigme_id);
    const loan = rawTransactions.filter((t) => t.loan_id);
    const sumAmount = (arr) => arr.reduce((s, t) => s + (t.amount || 0), 0);
    return {
      chitCancel: { count: chitCancel.length, amount: sumAmount(chitCancel) },
      pigmy: { count: pigmy.length, amount: sumAmount(pigmy) },
      loan: { count: loan.length, amount: sumAmount(loan) },
      total: {
        count: rawTransactions.length,
        amount: rawTransactions.reduce((s, t) => s + (t.amount || 0), 0)
      }
    };
  }, [rawTransactions]);
  const onDateRangeChange = (dates) => {
    setFilters((prev) => ({
      ...prev,
      startDate: dates ? dates[0].format("YYYY-MM-DD") : "",
      endDate: dates ? dates[1].format("YYYY-MM-DD") : ""
    }));
  };
  const handleChange = (value) => {
    const enroll = enrollments.find((e) => e._id === value);
    setSelectedEnrollId(value);
    setSelectedEnroll(enroll);
    setSelectedUserId(enroll?.user_id?._id);
    setTotalAmount(null);
  };
  const fetchTotalAmount = async () => {
    if (!selectedEnrollId) return;
    try {
      setLoading(true);
      const res = await api.get(`/v1/admin/enrolls/${selectedEnrollId}/payments/total`);
      setTotalAmount(res.data?.data?.total_amount || 0);
    } catch (error) {
      message.error("Failed to fetch total amount");
    } finally {
      setLoading(false);
    }
  };
  const openTransferModal = () => {
    if (!selectedEnrollId || !totalAmount) {
      message.warning("Please select user and calculate amount first");
      return;
    }
    const finalRemark = remarkType === "OTHER" ? customRemark : remarkType;
    if (!finalRemark || !finalRemark.trim()) {
      message.warning("Please select or enter reason");
      return;
    }
    setMoveRemark(finalRemark);
    setStep(2);
  };
  const handleMoveAmount = async () => {
    const payload = {
      userId: selectedUserId,
      removalReason: getActionButtonText(activeActionType) === "Close" ? "Chit Closed" : moveRemark,
      paymentDate: paymentDate ? paymentDate.format("YYYY-MM-DD") : null,
      netPayable: finalAmount,
      serviceCharge,
      gstAmount,
      grossAmount: totalAmount,
      send_whatsapp: thirdPartyEnable?.send_whatsapp,
      send_gmail: thirdPartyEnable?.send_gmail,
      send_sms: thirdPartyEnable?.send_sms
    };
    try {
      setLoading(true);
      await api.post(`/v1/admin/enrolls/${selectedEnrollId}/admins/${adminId}/remove`, payload);
      message.success("Amount transferred successfully");
      setAvailableAmount(totalAmount);
      setConfirmInput("");
      setStep(3);
    } catch (error) {
      message.error("Failed to submit amount");
    } finally {
      setLoading(false);
    }
  };
  const handleTabChange = (key) => {
    setActiveTabKey(key);
    if (key === "transaction-history") {
      setReloadTrigger((prev) => prev + 1);
    }
  };
  const fetchAllTransactions = async () => {
    if (!selectedEnrollId) {
      message.warning("Please select enrollment first");
      return;
    }
    try {
      setLoading(true);
      setOpenAntDDrawer(true);
      const res = await api.get(`/v1/admin/enrolls/${selectedEnrollId}/payments`);
      setLastAllPayments(res.data?.data || []);
    } catch (error) {
      message.error("Failed to fetch transactions");
      setLastAllPayments([]);
    } finally {
      setLoading(false);
    }
  };
  const handleTransferClick = async (items) => {
    setTransferLoading(true);
    const ticket = items.enrollment.tickets;
    const groupId = items.enrollment.group._id;
    try {
      const response = await api.get("/v1/admin/enrolls/get-all-enrolls", {
        params: { ticket, groupId }
      });
      const enrollments2 = response.data.data || response.data.enrolls || [];
      const sourceEnrollment = enrollments2.find(
        (e) => (e.tickets || e.ticket) == ticket && e.group_id?._id === groupId
      );
      if (!sourceEnrollment) {
        console.error("No enrollment found for ticket", ticket, "group", groupId);
        return;
      }
      const sourceEnrollmentId = sourceEnrollment._id;
      navigate(`/transfer-menu?sourceEnrollmentId=${sourceEnrollmentId}`);
    } catch (err) {
      console.error("Failed to fetch enrollment ID:", err);
    } finally {
      setTransferLoading(false);
    }
  };
  const handleRefund = () => {
    navigate(
      `/payment-menu/payment-in-out-menu/pay-out-menu/chit-cancelation-pay-out?amount=${finalAmount}&userId=${selectedUserId}&totalAmount=${totalAmount}&deductions=${serviceCharge}`
    );
    handleCloseModal();
  };
  const handleTransferToDifferentAccount = () => {
    navigate(
      `/payment-menu/payment-in-out-menu/pay-in-menu/chit-cancelation-pay-in?amount=${availableAmount}&userId=${selectedUserId}`
    );
    handleCloseModal();
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Date" },
    { key: "user_name", header: "Customer Name" },
    { key: "group_name", header: "Group" },
    { key: "ticket", header: "Ticket" },
    { key: "gross_amount", header: "Gross Amount", width: 150 },
    { key: "service_charge", header: "Service Charge" },
    { key: "gst_amount", header: "GST / Interest Amount" },
    { key: "amount", header: "Net Payable Amount", width: 150 },
    { key: "reason", header: "Reason" },
    { key: "type", header: "Type" },
    { key: "admin", header: "Processed By" }
  ];
  const cancelColumns = [
    { key: "id", header: "ID" },
    { key: "customer_name", header: "Customer Name" },
    { key: "group_name", header: "Group" },
    { key: "ticket", header: "Ticket" },
    { key: "amount", header: "Amount" },
    { key: "request_type", header: "Type" },
    { key: "status", header: "Status" },
    { key: "request_date", header: "Request Date" }
  ];
  const getCancelTableData = () => {
    return cancelRequests.map((req, idx) => ({
      id: idx + 1,
      customer_name: req.user_name || req.customer_name || "N/A",
      group_name: req.group_name || "N/A",
      ticket: req.ticket || "N/A",
      amount: `₹${(req.amount || 0).toLocaleString("en-IN")}`,
      request_type: /* @__PURE__ */ jsxDEV(Tag, { color: "blue", children: req.request_type?.toUpperCase() || requestTypeFilter.toUpperCase() }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 997,
        columnNumber: 21
      }, this),
      status: /* @__PURE__ */ jsxDEV(Tag, { color: req.status === "approved" ? "green" : "orange", children: req.status || "Pending" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 998,
        columnNumber: 15
      }, this),
      request_date: dayjs(req.created_at).format("DD-MM-YYYY")
    }));
  };
  const handleOnHoldModelOpen = async (enrollmentId, operation = "hold") => {
    try {
      const response = await api.get(
        `/enroll/get-enroll-by-id/${enrollmentId}`
      );
      const enrollmentData = response.data;
      let finalOperation = operation;
      if (operation === "active-inactive") {
        const currentStatus = enrollmentData?.customer_status?.toLowerCase();
        if (currentStatus === "active") {
          finalOperation = "inactive";
        } else {
          finalOperation = "active";
        }
      }
      setCurrentGroup(enrollmentData);
      setEnrollmentOperation(finalOperation);
      setShowModelOnHold(true);
    } catch (error) {
      console.error(
        "Error fetching enrollment:",
        error
      );
      message.error("Failed to load enrollment details");
    }
  };
  const handleOnHoldGroup = async (e) => {
    e.preventDefault();
    if (!currentGroup) return;
    const userId = currentGroup?.user_id?._id;
    if (!userId) {
      message.error("User ID missing");
      return;
    }
    try {
      const adminId2 = JSON.parse(localStorage.getItem("user"))?._id;
      if (enrollmentOperation === "suspend") {
        await api.put(`/enroll/remove/${currentGroup._id}`, {
          user_id: userId,
          deleted_by: adminId2,
          deleted_at: (/* @__PURE__ */ new Date()).toISOString(),
          removalReason: "Suspend"
        });
        message.success("Enrollment suspended successfully");
      } else if (enrollmentOperation === "inactive") {
        await api.put(`/enroll/remove/${currentGroup._id}`, {
          user_id: userId,
          deleted_by: adminId2,
          deleted_at: (/* @__PURE__ */ new Date()).toISOString(),
          removalReason: "In Active Customer"
        });
        message.success("Customer made inactive successfully");
      } else if (enrollmentOperation === "hold") {
        await api.put(`/v1/admin/enrolls/on-hold/${currentGroup._id}`, {
          user_id: userId,
          customer_status: "On Hold"
        });
        message.success("Enrollment placed on hold successfully");
      } else if (enrollmentOperation === "active") {
        await api.put(`/v1/admin/enrolls/activate/${currentGroup?._id}`, {
          user_id: userId,
          customer_status: "Activate"
        });
        message.success("Customer made active successfully");
      }
      setShowModelOnHold(false);
      setCurrentGroup(null);
      setEnrollmentOperation(null);
      if (selectedCustomer?._id) {
        fetchCustomerPortfolio(selectedCustomer._id);
      }
    } catch (error) {
      console.error("Error updating enrollment:", error);
      message.error("Failed to update enrollment");
    }
  };
  const handleProceedToSettlement = () => {
    if (!totalAmount) {
      message.warning("Please calculate total payment first");
      return;
    }
    if (!selectedEnrollId) {
      message.warning("No enrollment selected");
      return;
    }
    const remark = "Chit Cancellation";
    setRemarkType(remark);
    setMoveRemark(remark);
    setConfirmInput("");
    const groupValue = selectedEnrollmentData?.enrollment?.group?.group_value ? Number(selectedEnrollmentData.enrollment.group.group_value) : null;
    const defaultCharge = groupValue ? Math.round(groupValue * 0.05) : Math.round((Number(totalAmount) || 0) * 0.05);
    setServiceCharge(defaultCharge);
    setGstAmount(defaultCharge * 0.18);
    setShowModal(true);
    setStep(2);
  };
  const handleProceedToSettlementConfirm = () => {
    if (!totalAmount) {
      message.warning("Please calculate total payment first");
      return;
    }
    if (!selectedEnrollId) {
      message.warning("No enrollment selected");
      return;
    }
    antModal.confirm({
      title: "Confirm Proceed",
      content: "Are you sure you want to proceed with chit settlement?",
      okText: "Yes, Proceed",
      cancelText: "Cancel",
      onOk: () => {
        handleProceedToSettlement();
      }
    });
  };
  const getActionButtonText = (actionType) => {
    switch (actionType) {
      case "CHIT_CANCEL":
        return "Cancel";
      case "CHIT_CLOSE":
        return "Close";
      case "CHIT_TRANSFER":
        return "Transfer";
      case "PIGMY_PRECLOSURE":
        return "Preclosure";
      case "PIGMY_TO_CHIT":
        return "Convert to Chit";
      case "PIGMY_TO_LOAN":
        return "Convert to Loan";
      default:
        return "Proceed";
    }
  };
  const renderCustomerPortfolio = () => {
    if (!selectedCustomer) return null;
    const totalPigmyAmount = pigmyData.reduce((acc, curr) => acc + (curr.total_deposited_amount || 0), 0);
    const hasPigmy = pigmyData.length > 0;
    const hasLoans = loanData?.length > 0;
    const hasChits = customerEnrollments.length > 0;
    const primaryPigmy = pigmyData[0];
    const pigmyRequestStatus = primaryPigmy?.request_status;
    const isRequested = pigmyRequestStatus === "REQUESTED";
    const isApproved = pigmyRequestStatus === "APPROVED";
    const isCompleted = isApproved;
    const pigmyButtonText = isRequested ? "Withdraw Pigmy" : isApproved ? "Withdraw Approved Pigmy" : "Raise Request to Withdraw";
    const handlePigmyClick = () => {
      if (!primaryPigmy) return;
      if (isApproved) {
        message.warning(
          "Go to Pigmy Payment Out page to view remaining payout for Pigmy"
        );
        return;
      }
      if (isRequested) {
        handleOpenWithdrawModal(primaryPigmy._id);
      } else {
        handleRaiseWithdrawRequest(primaryPigmy._id);
      }
    };
    return /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 animate-fade-in-up", id: "customer-portfolio", children: [
      /* @__PURE__ */ jsxDEV(Card, { className: "border-l-4 border-l-blue-600 shadow-sm", children: /* @__PURE__ */ jsxDEV(Descriptions, { column: { xs: 1, sm: 2, md: 4 }, size: "small", children: [
        /* @__PURE__ */ jsxDEV(Descriptions.Item, { label: "Customer Name", children: selectedCustomer.full_name }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 1209,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(Descriptions.Item, { label: "Customer ID", children: selectedCustomer.customer_id }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 1210,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(Descriptions.Item, { label: "Phone", children: selectedCustomer.phone_number }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 1211,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(Descriptions.Item, { label: "Aadhaar", children: selectedCustomer.adhaar_no }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 1212,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 1208,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 1207,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Row, { gutter: 16, children: [
        /* @__PURE__ */ jsxDEV(Col, { xs: 24, md: 12, lg: 8, children: /* @__PURE__ */ jsxDEV(
          Card,
          {
            title: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2 text-blue-800", children: [
              /* @__PURE__ */ jsxDEV(GroupOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1218,
                columnNumber: 78
              }, this),
              " Active Chits (",
              customerEnrollments.length,
              ")"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1218,
              columnNumber: 22
            }, this),
            className: "h-full",
            bodyStyle: { padding: hasChits ? "0" : "0" },
            children: loadingEnrollments ? /* @__PURE__ */ jsxDEV("div", { className: "p-8 text-center", children: /* @__PURE__ */ jsxDEV(Spin, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1223,
              columnNumber: 48
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1223,
              columnNumber: 15
            }, this) : hasChits ? /* @__PURE__ */ jsxDEV("div", { className: "max-h-[400px] overflow-y-auto p-3 space-y-4", children: customerEnrollments.map(
              (item, idx) => /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-200 rounded-lg p-3 bg-gray-50", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start mb-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-gray-800", children: item.enrollment.group.group_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1230,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500", children: [
                      "Ticket: ",
                      item.enrollment.tickets
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1231,
                      columnNumber: 53
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1229,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Tag,
                    {
                      color: item?.enrollment?.customer_status === "Active" ? "blue" : item?.enrollment?.customer_status === "On Hold" ? "orange" : "red",
                      children: item?.enrollment?.customer_status || "Active"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1233,
                      columnNumber: 49
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 1228,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV(Space, { size: "small", wrap: true, children: [
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      size: "small",
                      type: "primary",
                      icon: /* @__PURE__ */ jsxDEV(MdCheck, {}, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1251,
                        columnNumber: 29
                      }, this),
                      onClick: () => handleActionClick("CHIT_CANCEL", item),
                      children: "Select This Ticket"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1248,
                      columnNumber: 49
                    },
                    this
                  ),
                  item?.prized?.is_prized === "true" && /* @__PURE__ */ jsxDEV(
                    Tag,
                    {
                      color: "blue",
                      className: "!rounded-full !px-3 !py-1 !text-xs !font-semibold shadow-sm border-0",
                      children: "🏆 Prized"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1257,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 1247,
                  columnNumber: 45
                }, this)
              ] }, idx, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1227,
                columnNumber: 17
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1225,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV(Empty, { image: Empty.PRESENTED_IMAGE_SIMPLE, description: "No Active Chits", className: "py-8" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1287,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 1217,
            columnNumber: 25
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 1216,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Col, { xs: 24, md: 12, lg: 8, children: /* @__PURE__ */ jsxDEV(
          Card,
          {
            title: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-2 text-emerald-800", children: [
              /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "w-4 h-4" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1296,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Pigmy Account" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1297,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1295,
              columnNumber: 13
            }, this),
            className: "h-full",
            bodyStyle: { padding: hasPigmy ? "16px" : "0" },
            children: loadingPigmy ? /* @__PURE__ */ jsxDEV("div", { className: "p-8 text-center", children: /* @__PURE__ */ jsxDEV(Spin, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1304,
              columnNumber: 48
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1304,
              columnNumber: 15
            }, this) : hasPigmy ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-emerald-50 p-4 rounded-lg border border-emerald-100", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-emerald-600 uppercase font-bold", children: "Total Deposited" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 1309,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-emerald-800", children: [
                  "₹",
                  totalPigmyAmount.toLocaleString()
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 1310,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1308,
                columnNumber: 37
              }, this),
              pigmyData.map(
                (pigmy, idx) => /* @__PURE__ */ jsxDEV("div", { className: "bg-white border border-gray-200 rounded-lg p-3 space-y-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500", children: "Pigmy ID" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1324,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono font-semibold", children: pigmy.pigme_id || "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1325,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1323,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500", children: "Payment Type" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1328,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium capitalize", children: pigmy.maturity_period || "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1329,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1327,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: [
                      pigmy.maturity_period?.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase()),
                      " ",
                      "paid Amount"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1332,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium", children: [
                      "₹",
                      Number(pigmy.payable_amount || 0).toLocaleString()
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1338,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1331,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500", children: "Duration" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1341,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium", children: [
                      pigmy.duration || "-",
                      " months"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1342,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1340,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500", children: "Start Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1345,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium", children: pigmy.start_date ? dayjs(pigmy.start_date).format("DD-MM-YYYY") : "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1346,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1344,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500", children: "Months Completed" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1351,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-blue-600", children: pigmy.start_date ? (() => {
                      const start = dayjs(pigmy.start_date);
                      const today = dayjs();
                      let months = (today.year() - start.year()) * 12 + (today.month() - start.month());
                      months = Math.max(0, months);
                      return `${months} / ${pigmy.duration || "?"} months`;
                    })() : "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1352,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1350,
                    columnNumber: 45
                  }, this)
                ] }, idx, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 1322,
                  columnNumber: 17
                }, this)
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-3", children: [
                (() => {
                  const primaryPigmy2 = pigmyData[0];
                  const isNone = !primaryPigmy2?.request_status || primaryPigmy2?.request_status === "PENDING";
                  const isRequested2 = primaryPigmy2?.request_status === "REQUESTED";
                  const isApproved2 = primaryPigmy2?.request_status === "APPROVED";
                  const isDeleted = primaryPigmy2?.request_status === "DONE";
                  if (isNone) {
                    return /* @__PURE__ */ jsxDEV(
                      Button,
                      {
                        block: true,
                        size: "large",
                        icon: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, {}, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1381,
                          columnNumber: 33
                        }, this),
                        loading: raisingRequestLoading,
                        onClick: () => handleRaiseWithdrawRequest(primaryPigmy2._id),
                        className: "border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300 font-medium h-11",
                        children: "Raise Request to Withdraw"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1378,
                        columnNumber: 25
                      },
                      this
                    );
                  }
                  const steps = [
                    {
                      key: "raised",
                      label: "Request raised",
                      desc: "Withdrawal request submitted successfully.",
                      status: "done"
                    },
                    {
                      key: "calculate",
                      label: "Calculate & approve",
                      desc: isApproved2 ? "Withdrawal amount calculated and approved." : "Open the withdrawal modal, adjust interest if needed, then calculate and confirm.",
                      status: isApproved2 ? "done" : "active",
                      // Hide the action button if the account is deleted
                      action: !isApproved2 && !isDeleted ? /* @__PURE__ */ jsxDEV(
                        Button,
                        {
                          size: "small",
                          type: "primary",
                          loading: raisingRequestLoading,
                          icon: /* @__PURE__ */ jsxDEV(FaCalculator, {}, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1412,
                            columnNumber: 31
                          }, this),
                          onClick: () => handleOpenWithdrawModal(primaryPigmy2._id),
                          className: "mt-2 bg-blue-600 hover:bg-blue-700",
                          children: "Open withdrawal modal"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1408,
                          columnNumber: 23
                        },
                        this
                      ) : null
                    },
                    {
                      key: "payout",
                      label: isDeleted ? "Account closed" : "Process payout",
                      desc: isDeleted ? "The pigmy account has been closed and the final amount has been withdrawn." : "Go to Pigmy Payment Out page to disburse the final amount to the customer.",
                      status: isDeleted ? "done" : isApproved2 ? "active" : "pending",
                      action: isDeleted ? null : isApproved2 ? /* @__PURE__ */ jsxDEV(
                        Button,
                        {
                          size: "small",
                          type: "primary",
                          icon: /* @__PURE__ */ jsxDEV(ArrowRightOutlined, {}, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1431,
                            columnNumber: 31
                          }, this),
                          onClick: () => navigate("/payment-menu/payment-in-out-menu/pay-out-menu/pigmy-payout"),
                          className: "mt-2 bg-emerald-600 hover:bg-emerald-700",
                          children: "Go to Pigmy Payout page"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1428,
                          columnNumber: 23
                        },
                        this
                      ) : /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-400 border border-dashed border-gray-200 rounded-lg px-3 py-2 mt-2 flex items-center gap-1", children: [
                        /* @__PURE__ */ jsxDEV(LockOutlined, {}, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1439,
                          columnNumber: 61
                        }, this),
                        " Unlocks after approval"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1438,
                        columnNumber: 23
                      }, this)
                    }
                  ];
                  const statusStyles = {
                    done: { icon: "bg-emerald-50 text-emerald-700 border-emerald-400", label: "text-emerald-800", line: "bg-emerald-400" },
                    active: { icon: "bg-blue-50 text-blue-700 border-blue-400", label: "text-blue-900", line: "bg-gray-200" },
                    pending: { icon: "bg-gray-100 text-gray-400 border-gray-300", label: "text-gray-400", line: "bg-gray-200" }
                  };
                  return /* @__PURE__ */ jsxDEV("div", { className: "mt-2", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3", children: "Withdrawal progress" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1453,
                      columnNumber: 53
                    }, this),
                    steps.map((step2, idx) => {
                      const s = statusStyles[step2.status];
                      const isLast = idx === steps.length - 1;
                      return /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: `w-7 h-7 rounded-full border flex items-center justify-center text-sm flex-shrink-0 ${s.icon}`, children: step2.status === "done" ? /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1463,
                            columnNumber: 99
                          }, this) : step2.status === "active" ? /* @__PURE__ */ jsxDEV(ArrowRightOutlined, {}, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1463,
                            columnNumber: 152
                          }, this) : /* @__PURE__ */ jsxDEV(LockOutlined, {}, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1463,
                            columnNumber: 177
                          }, this) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1462,
                            columnNumber: 69
                          }, this),
                          !isLast && /* @__PURE__ */ jsxDEV("div", { className: `w-0.5 flex-grow mt-1 mb-1 min-h-6 ${s.line}` }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1466,
                            columnNumber: 33
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1461,
                          columnNumber: 65
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "pb-4 flex-1", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: `text-sm font-medium ${s.label}`, children: step2.label }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1470,
                            columnNumber: 69
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-gray-500 mt-0.5 leading-relaxed", children: step2.desc }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1471,
                            columnNumber: 69
                          }, this),
                          step2.action
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1469,
                          columnNumber: 65
                        }, this)
                      ] }, step2.key, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1460,
                        columnNumber: 29
                      }, this);
                    }),
                    /* @__PURE__ */ jsxDEV("div", { className: `mt-1 rounded-lg px-3 py-2 text-xs leading-relaxed ${isApproved2 ? "bg-emerald-50 border border-emerald-100 text-emerald-700" : "bg-blue-50 border border-blue-100 text-blue-700"}`, children: [
                      isRequested2 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                        /* @__PURE__ */ jsxDEV("strong", { children: "Next:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1479,
                          columnNumber: 75
                        }, this),
                        " Open the withdrawal modal to calculate and approve the payout amount."
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1479,
                        columnNumber: 73
                      }, this),
                      isApproved2 && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                        /* @__PURE__ */ jsxDEV("strong", { children: "Next:" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1480,
                          columnNumber: 74
                        }, this),
                        " Go to the Pigmy Payout page to complete the disbursement."
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1480,
                        columnNumber: 72
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1478,
                      columnNumber: 53
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1452,
                    columnNumber: 23
                  }, this);
                })(),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    block: true,
                    size: "large",
                    onClick: () => window.open(`/pigmy-preclosure-print/${primaryPigmy._id}`, "_blank"),
                    className: "border-gray-200 text-gray-700 hover:bg-gray-50 hover:border-gray-300 font-medium h-11",
                    children: "🖨️ Print Closure Form"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1487,
                    columnNumber: 41
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    block: true,
                    size: "large",
                    icon: /* @__PURE__ */ jsxDEV(ArrowRightOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1500,
                      columnNumber: 27
                    }, this),
                    disabled: true,
                    className: "border-blue-200 text-blue-600 hover:bg-blue-50 hover:border-blue-300 font-medium h-11 opacity-50 cursor-not-allowed",
                    children: "Transfer to Chit (Disabled)"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1497,
                    columnNumber: 41
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    block: true,
                    size: "large",
                    icon: /* @__PURE__ */ jsxDEV(SwapOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1509,
                      columnNumber: 27
                    }, this),
                    disabled: true,
                    className: "border-purple-200 text-purple-600 hover:bg-purple-50 hover:border-purple-300 font-medium h-11 opacity-50 cursor-not-allowed",
                    children: "Transfer to Loan (Disabled)"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1506,
                    columnNumber: 41
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1366,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1306,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV(Empty, { image: Empty.PRESENTED_IMAGE_SIMPLE, description: "No Pigmy Data", className: "py-8" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1518,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 1292,
            columnNumber: 25
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 1291,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Col, { xs: 24, md: 12, lg: 8, children: /* @__PURE__ */ jsxDEV(
          Card,
          {
            title: /* @__PURE__ */ jsxDEV("span", { className: "inline-flex items-center gap-2 text-purple-800", children: [
              /* @__PURE__ */ jsxDEV(FaRupeeSign, { className: "w-4 h-4" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1526,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Loan Details" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1527,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1525,
              columnNumber: 15
            }, this),
            className: "h-full shadow-sm",
            bodyStyle: { padding: loanData.length ? "20px" : "0" },
            children: loadingLoans ? /* @__PURE__ */ jsxDEV("div", { className: "p-8 text-center", children: /* @__PURE__ */ jsxDEV(Spin, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1534,
              columnNumber: 48
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1534,
              columnNumber: 15
            }, this) : loanData.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col h-full", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 flex-grow", children: loanData.map((item, idx) => {
                const loan = item.loan_details?.loan || {};
                const loanValue = item.loan_value || loan.loan_amount;
                const balance = item.balance || 0;
                const paidAmount = item.total_paid_amount || 0;
                return /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "bg-slate-50 p-5 rounded-xl border border-slate-200 hover:border-purple-200 transition-colors",
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start mb-4", children: [
                        /* @__PURE__ */ jsxDEV("div", { children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "text-xs text-slate-500 uppercase tracking-wider font-semibold mb-1", children: [
                            "Loan #",
                            loan.loan_id || idx + 1
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1551,
                            columnNumber: 61
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "text-2xl font-bold text-slate-800", children: [
                            "₹",
                            Number(loanValue).toLocaleString()
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1554,
                            columnNumber: 61
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1550,
                          columnNumber: 57
                        }, this),
                        /* @__PURE__ */ jsxDEV(Tag, { color: "purple", className: "bg-purple-100 text-purple-700 border-none px-3 py-1 rounded-full", children: "Active" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1558,
                          columnNumber: 57
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1549,
                        columnNumber: 53
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-y-3 gap-x-4 text-sm", children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                          /* @__PURE__ */ jsxDEV("span", { className: "text-slate-500 text-xs", children: "Total Paid" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1565,
                            columnNumber: 61
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-slate-700", children: [
                            "₹",
                            paidAmount.toLocaleString()
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1566,
                            columnNumber: 61
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1564,
                          columnNumber: 57
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                          /* @__PURE__ */ jsxDEV("span", { className: "text-slate-500 text-xs", children: "Tenure" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1569,
                            columnNumber: 61
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-slate-700", children: [
                            loan.tenure,
                            " days"
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1570,
                            columnNumber: 61
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1568,
                          columnNumber: 57
                        }, this),
                        loan.daily_payment_amount && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                          /* @__PURE__ */ jsxDEV("span", { className: "text-slate-500 text-xs", children: "Daily EMI" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1575,
                            columnNumber: 65
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-slate-700", children: [
                            "₹",
                            Number(loan.daily_payment_amount).toLocaleString()
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1576,
                            columnNumber: 65
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1574,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col col-span-2 mt-1 pt-3 border-t border-slate-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 font-medium", children: "Outstanding Balance" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1582,
                            columnNumber: 65
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-red-600", children: [
                            "₹",
                            balance.toLocaleString()
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1583,
                            columnNumber: 65
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1581,
                          columnNumber: 61
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1580,
                          columnNumber: 57
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1563,
                        columnNumber: 53
                      }, this)
                    ]
                  },
                  idx,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1545,
                    columnNumber: 23
                  },
                  this
                );
              }) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1537,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "pt-6 mt-4 border-t border-slate-100", children: /* @__PURE__ */ jsxDEV(
                Button,
                {
                  block: true,
                  size: "large",
                  danger: true,
                  type: "default",
                  icon: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1598,
                    columnNumber: 27
                  }, this),
                  onClick: () => handleActionClick("LOAN_PRECLOSE", { loanData: loanData[0] }),
                  className: "h-12 font-medium border-red-200 text-red-600 hover:!border-red-500 hover:!text-red-700 hover:!bg-red-50 transition-all shadow-sm",
                  children: "Preclose Loan"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 1593,
                  columnNumber: 41
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1592,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1536,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV(Empty, { image: Empty.PRESENTED_IMAGE_SIMPLE, description: "No Active Loans", className: "py-8" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1607,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 1523,
            columnNumber: 25
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 1522,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 1215,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
      lineNumber: 1206,
      columnNumber: 7
    }, this);
  };
  const operationConfig = {
    hold: {
      title: "Confirm Enrollment Hold?",
      description: "Are you sure you want to place this enrollment on hold? The customer will be temporarily excluded from participation until the enrollment is reactivated.",
      buttonText: "Confirm Hold",
      buttonClass: "bg-yellow-500 hover:bg-yellow-600 focus:ring-yellow-300",
      iconClass: "bg-gradient-to-br from-yellow-400 to-yellow-600",
      accentClass: "bg-yellow-500"
    },
    suspend: {
      title: "Confirm Enrollment Suspension?",
      description: "Are you sure you want to suspend this enrollment? The customer will be temporarily suspended from participation.",
      buttonText: "Confirm Suspend",
      buttonClass: "bg-orange-500 hover:bg-orange-600 focus:ring-orange-300",
      iconClass: "bg-gradient-to-br from-orange-400 to-orange-600",
      accentClass: "bg-orange-500"
    },
    active: {
      title: "Activate Enrollment?",
      description: "Are you sure you want to activate this enrollment? The customer will be allowed to participate again.",
      buttonText: "Confirm Activate",
      buttonClass: "bg-green-500 hover:bg-green-600 focus:ring-green-300",
      iconClass: "bg-gradient-to-br from-green-400 to-green-600",
      accentClass: "bg-green-500"
    }
  };
  const currentOperation = operationConfig[enrollmentOperation] || operationConfig.hold;
  const tabItems = [
    {
      key: "cancel-requests",
      label: "Transaction Details",
      children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap justify-between items-center gap-4", children: /* @__PURE__ */ jsxDEV(Radio.Group, { value: requestTypeFilter, onChange: (e) => setRequestTypeFilter(e.target.value), buttonStyle: "solid" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 1666,
          columnNumber: 25
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 1665,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-slate-50 via-white to-blue-50 rounded-2xl shadow-sm border border-gray-200/60 overflow-hidden", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "px-6 pt-6 pb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 rounded-lg bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center shadow-md shadow-indigo-200", children: /* @__PURE__ */ jsxDEV(ThunderboltOutlined, { className: "text-white text-sm" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1680,
                columnNumber: 41
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1679,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-800", children: "Available Operations" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 1684,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400", children: "Select a customer enrollment to perform any of the following actions" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 1688,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1683,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1678,
              columnNumber: 33
            }, this),
            selectedEnrollmentData?.enrollmentId && /* @__PURE__ */ jsxDEV("div", { className: "hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-50 border border-green-200", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "w-2 h-2 rounded-full bg-green-500 animate-pulse" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1697,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold text-green-700", children: "Ticket Selected" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1699,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 1696,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 1677,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 1676,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-6 pb-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => {
                  setActiveActionType("CHIT_CANCEL");
                },
                className: `
        group relative text-left bg-white rounded-xl
        border p-4 transition-all duration-300
        focus:outline-none focus:ring-2 focus:ring-red-300
        ${activeActionType === "CHIT_CANCEL" ? "border-red-500 bg-red-50/50 shadow-lg ring-2 ring-red-200" : "border-gray-150 hover:shadow-lg hover:shadow-red-100/50 hover:border-red-200 cursor-pointer"}
    `,
                children: [
                  activeActionType === "CHIT_CANCEL" && /* @__PURE__ */ jsxDEV("div", { className: "absolute top-3 right-3 z-50 w-7 h-7 rounded-full bg-blue-500 flex items-center justify-center shadow-md", children: /* @__PURE__ */ jsxDEV(MdCheck, { className: "text-white text-lg" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1732,
                    columnNumber: 41
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1731,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 rounded-xl bg-gradient-to-br from-red-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1737,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "relative z-10", children: [
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `
                w-11 h-11 rounded-xl
                bg-gradient-to-br from-red-900 to-rose-600
                flex items-center justify-center mb-3
                shadow-md shadow-red-200/60
                transition-transform duration-300
                ${activeActionType === "CHIT_CANCEL" ? "scale-110" : "group-hover:scale-110"}
            `,
                        children: /* @__PURE__ */ jsxDEV(MdCancel, { className: "text-white text-xl" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1754,
                          columnNumber: 41
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1741,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-gray-800 mb-1", children: "Chit Cancel" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1757,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] leading-relaxed text-gray-400", children: "Permanently cancel the enrollment with settlement calculation" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1761,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-red-400" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1766,
                        columnNumber: 41
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold text-red-500 uppercase tracking-wider", children: "Termination" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1768,
                        columnNumber: 41
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1765,
                      columnNumber: 37
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1740,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1712,
                columnNumber: 29
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => {
                  setActiveActionType("CHIT_CLOSE");
                },
                className: `
        group relative text-left bg-white rounded-xl
        border p-4 transition-all duration-300
        focus:outline-none focus:ring-2 focus:ring-red-300
        ${activeActionType === "CHIT_CLOSE" ? "border-red-500 bg-red-50/50 shadow-lg ring-2 ring-red-200" : "border-gray-150 hover:shadow-lg hover:shadow-red-100/50 hover:border-red-200 cursor-pointer"}
    `,
                children: [
                  activeActionType === "CHIT_CLOSE" && /* @__PURE__ */ jsxDEV("div", { className: "absolute top-3 right-3 z-50 w-7 h-7 rounded-full bg-blue-500 flex items-center justify-center shadow-md", children: /* @__PURE__ */ jsxDEV(MdCheck, { className: "text-white text-lg" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1799,
                    columnNumber: 41
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1798,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 rounded-xl bg-gradient-to-br from-orange-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1802,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "relative z-10", children: [
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `
                w-11 h-11 rounded-xl
                bg-gradient-to-br from-red-600 to-rose-400
                flex items-center justify-center mb-3
                shadow-md shadow-red-200/60
                transition-transform duration-300
                ${activeActionType === "CHIT_CLOSE" ? "scale-110" : "group-hover:scale-110"}
            `,
                        children: /* @__PURE__ */ jsxDEV(StopOutlined, { className: "text-white text-lg" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1817,
                          columnNumber: 41
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1805,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-gray-800 mb-1", children: "Chit Close" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1820,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] leading-relaxed text-gray-400", children: "Close the chit after all installments are completed" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1824,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-orange-400" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1829,
                        columnNumber: 41
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold text-orange-500 uppercase tracking-wider", children: "Completion" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1831,
                        columnNumber: 41
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1828,
                      columnNumber: 37
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1804,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1776,
                columnNumber: 29
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => {
                  setActiveActionType("CHIT_TRANSFER");
                },
                className: `
        group relative text-left bg-white rounded-xl
        border p-4 transition-all duration-300
        focus:outline-none focus:ring-2 focus:ring-red-300
        ${activeActionType === "CHIT_TRANSFER" ? "border-red-500 bg-red-50/50 shadow-lg ring-2 ring-red-200" : "border-gray-150 hover:shadow-lg hover:shadow-red-100/50 hover:border-red-200 cursor-pointer"}
    `,
                children: [
                  activeActionType === "CHIT_TRANSFER" && /* @__PURE__ */ jsxDEV("div", { className: "absolute top-3 right-3 z-50 w-7 h-7 rounded-full bg-blue-500 flex items-center justify-center shadow-md", children: /* @__PURE__ */ jsxDEV(MdCheck, { className: "text-white text-lg" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1865,
                    columnNumber: 41
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1864,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 rounded-xl bg-gradient-to-br from-blue-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1868,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "relative z-10", children: [
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `
                w-11 h-11 rounded-xl
                bg-gradient-to-br from-blue-500 to-rose-500
                flex items-center justify-center mb-3
                shadow-md shadow-red-200/60
                transition-transform duration-300
                ${activeActionType === "CHIT_CANCEL" ? "scale-110" : "group-hover:scale-110"}
            `,
                        children: transferLoading ? /* @__PURE__ */ jsxDEV(
                          SwapOutlined,
                          {
                            spin: true,
                            className: "text-white text-lg"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 1884,
                            columnNumber: 17
                          },
                          this
                        ) : /* @__PURE__ */ jsxDEV(SwapOutlined, { className: "text-white text-lg" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 1889,
                          columnNumber: 17
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1871,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-gray-800 mb-1", children: transferLoading ? "Transferring..." : "Chit Transfer" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1893,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] leading-relaxed text-gray-400", children: "Transfer enrollment ownership to another subscriber" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1899,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-blue-400" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1904,
                        columnNumber: 41
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold text-blue-500 uppercase tracking-wider", children: "Transfer" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1906,
                        columnNumber: 41
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1903,
                      columnNumber: 37
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1870,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1840,
                columnNumber: 29
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => {
                  setActiveActionType("SUSPEND");
                },
                className: `
        group relative text-left bg-white rounded-xl
        border p-4 transition-all duration-300
        focus:outline-none focus:ring-2 focus:ring-red-300
        ${activeActionType === "SUSPEND" ? "border-red-500 bg-red-50/50 shadow-lg ring-2 ring-red-200" : "border-gray-150 hover:shadow-lg hover:shadow-red-100/50 hover:border-red-200 cursor-pointer"}
    `,
                children: [
                  activeActionType === "SUSPEND" && /* @__PURE__ */ jsxDEV("div", { className: "absolute top-3 right-3 z-50 w-7 h-7 rounded-full bg-blue-500 flex items-center justify-center shadow-md", children: /* @__PURE__ */ jsxDEV(MdCheck, { className: "text-white text-lg" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1940,
                    columnNumber: 41
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1939,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 rounded-xl bg-gradient-to-br from-yellow-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1943,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "relative z-10", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: `
                w-11 h-11 rounded-xl
                bg-gradient-to-br from-indigo-700 to-violet-400
                flex items-center justify-center mb-3
                shadow-md shadow-red-200/60
                transition-transform duration-300
                ${activeActionType === "SUSPEND" ? "scale-110" : "group-hover:scale-110"}
            `, children: /* @__PURE__ */ jsxDEV(PauseCircleOutlined, { className: "text-white text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1958,
                      columnNumber: 41
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1946,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-gray-800 mb-1", children: "Suspend" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1961,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] leading-relaxed text-gray-400", children: "Temporarily suspend the enrollment for a specific period" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1965,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-yellow-400" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1970,
                        columnNumber: 41
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold text-yellow-600 uppercase tracking-wider", children: "Pause" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 1972,
                        columnNumber: 41
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 1969,
                      columnNumber: 37
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 1945,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1915,
                columnNumber: 29
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => {
                  setActiveActionType("hold");
                },
                className: `
        group relative text-left bg-white rounded-xl
        border p-4 transition-all duration-300
        focus:outline-none focus:ring-2 focus:ring-red-300
        ${activeActionType === "hold" ? "border-red-500 bg-red-50/50 shadow-lg ring-2 ring-red-200" : "border-gray-150 hover:shadow-lg hover:shadow-red-100/50 hover:border-red-200 cursor-pointer"}
    `,
                children: [
                  activeActionType === "hold" && /* @__PURE__ */ jsxDEV("div", { className: "absolute top-3 right-3 z-50 w-7 h-7 rounded-full bg-blue-500 flex items-center justify-center shadow-md", children: /* @__PURE__ */ jsxDEV(MdCheck, { className: "text-white text-lg" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2006,
                    columnNumber: 41
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2005,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 rounded-xl bg-gradient-to-br from-purple-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2009,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "relative z-10", children: [
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `
                w-11 h-11 rounded-xl
                bg-gradient-to-br from-yellow-500 to-rose-600
                flex items-center justify-center mb-3
                shadow-md shadow-red-200/60
                transition-transform duration-300
                ${activeActionType === "holdss" ? "scale-110" : "group-hover:scale-110"}
            `,
                        children: /* @__PURE__ */ jsxDEV(VscRemove, { className: "text-white text-xl" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 2025,
                          columnNumber: 41
                        }, this)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 2012,
                        columnNumber: 37
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-gray-800 mb-1", children: "On Hold" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2028,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] leading-relaxed text-gray-400", children: "Place the enrollment on hold pending review or action" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2032,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-purple-400" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 2037,
                        columnNumber: 41
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold text-purple-500 uppercase tracking-wider", children: "Pending" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 2039,
                        columnNumber: 41
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2036,
                      columnNumber: 37
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2011,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 1981,
                columnNumber: 29
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                onClick: () => {
                  if (selectedEnrollmentData?.enrollment?.customer_status?.toLowerCase() === "on hold")
                    setActiveActionType("active-inactive");
                },
                className: `
        group relative text-left bg-white rounded-xl
        border p-4 transition-all duration-300
        focus:outline-none focus:ring-2 focus:ring-green-300
        ${selectedEnrollmentData?.enrollment?.customer_status?.toLowerCase() === "on hold" ? "border-gray-150 hover:shadow-lg hover:shadow-green-100/50 hover:border-green-200 cursor-pointer" : "border-gray-150 opacity-50 cursor-not-allowed"}
    `,
                children: [
                  activeActionType === "active-inactive" && /* @__PURE__ */ jsxDEV("div", { className: "absolute top-3 right-3 z-50 w-7 h-7 rounded-full bg-blue-500 flex items-center justify-center shadow-md", children: /* @__PURE__ */ jsxDEV(MdCheck, { className: "text-white text-lg" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2071,
                    columnNumber: 41
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2070,
                    columnNumber: 13
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 rounded-xl bg-gradient-to-br from-green-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2074,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "relative z-10", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-11 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center mb-3 shadow-md shadow-green-200/60 group-hover:scale-110 transition-transform duration-300", children: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, { className: "text-white text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2079,
                      columnNumber: 41
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2078,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-bold text-gray-800 mb-1", children: "Make Active / Inactive" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2082,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] leading-relaxed text-gray-400", children: "Change customer status from On Hold to Active or Inactive" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2086,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "w-1.5 h-1.5 rounded-full bg-green-400" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 2091,
                        columnNumber: 41
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-semibold text-green-600 uppercase tracking-wider", children: "Status Change" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 2093,
                        columnNumber: 41
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2090,
                      columnNumber: 37
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2076,
                    columnNumber: 33
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2046,
                columnNumber: 29
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 1709,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-6 pb-5", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 bg-gray-50/80 rounded-lg px-4 py-2.5 border border-gray-100", children: [
            /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-gray-400 text-sm flex-shrink-0" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2107,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-600", children: "Tip:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2110,
                columnNumber: 37
              }, this),
              " ",
              "Select a customer from the search below, then choose a ticket to activate these operations."
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2109,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2106,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2105,
            columnNumber: 25
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-sm border border-gray-100", children: /* @__PURE__ */ jsxDEV(QuickSearchContent, { onSelect: handleQuickSearchSelect }, quickSearchKey, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2120,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2119,
            columnNumber: 25
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 1673,
          columnNumber: 21
        }, this),
        renderCustomerPortfolio(),
        activeActionType && selectedEnrollmentData && /* @__PURE__ */ jsxDEV("div", { id: "action-form-section", className: "relative bg-blue-50 border border-blue-200 rounded-xl p-6 mt-6 animate-fade-in", children: [
          actionLoading && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 z-50 flex items-center justify-center bg-white/70 backdrop-blur-sm rounded-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-3", children: [
            /* @__PURE__ */ jsxDEV(Spin, { size: "large" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2133,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-medium text-blue-700", children: "Loading customer details..." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2134,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2132,
            columnNumber: 37
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2131,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-bold text-blue-900 mb-4 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(FileTextOutlined, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2141,
              columnNumber: 33
            }, this),
            " Customer Details"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2140,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV(Form, { form: addRequestForm, layout: "vertical", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4", children: [
              /* @__PURE__ */ jsxDEV(Form.Item, { label: "Subscriber Name", children: /* @__PURE__ */ jsxDEV(Input, { value: selectedCustomer?.full_name || "", disabled: true, style: { backgroundColor: "#f0f0f0", color: "#333" } }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2146,
                columnNumber: 41
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2145,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(Form.Item, { label: "Mobile Number", children: /* @__PURE__ */ jsxDEV(Input, { value: selectedCustomer?.phone_number || "", disabled: true, style: { backgroundColor: "#f0f0f0", color: "#333" } }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2149,
                columnNumber: 41
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2148,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(Form.Item, { label: "Group Name", children: /* @__PURE__ */ jsxDEV(Input, { value: selectedEnrollmentData?.enrollment?.group.group_name, disabled: true, style: { backgroundColor: "#f0f0f0", color: "#333" } }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2152,
                columnNumber: 41
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2151,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV(Form.Item, { label: "Ticket Number", children: /* @__PURE__ */ jsxDEV(Input, { value: selectedEnrollmentData?.enrollment?.tickets, disabled: true, style: { backgroundColor: "#f0f0f0", color: "#333" } }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2155,
                columnNumber: 41
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2154,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2144,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3", children: "2. Payment Calculation" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2160,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row items-center gap-5 bg-indigo-50 p-5 rounded-xl border border-indigo-100", children: [
                /* @__PURE__ */ jsxDEV(Button, { type: "primary", size: "large", onClick: fetchTotalAmount, disabled: !selectedEnrollId || loading, className: "w-full md:w-auto bg-indigo-600 hover:bg-indigo-700 font-medium shadow-sm", children: loading ? /* @__PURE__ */ jsxDEV(Spin, { size: "small" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2163,
                  columnNumber: 56
                }, this) : "Refresh Total Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2162,
                  columnNumber: 41
                }, this),
                totalAmount !== null && /* @__PURE__ */ jsxDEV("div", { className: "flex-grow text-center md:text-right", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-indigo-500 text-xs font-medium uppercase tracking-wider", children: "Total Calculated Amount" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2167,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-bold text-indigo-800", children: [
                    "₹ ",
                    Number(totalAmount).toLocaleString()
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2168,
                    columnNumber: 49
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2166,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2161,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-2", children: /* @__PURE__ */ jsxDEV(Button, { type: "link", onClick: fetchAllTransactions, className: "text-indigo-500 text-xs", children: "View All Transactions →" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2173,
                columnNumber: 41
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2172,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2159,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap justify-end gap-3 mt-6 pt-4 border-t border-gray-200", children: [
              /* @__PURE__ */ jsxDEV(Button, { onClick: () => setActiveActionType(null), children: "Cancel" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2226,
                columnNumber: 37
              }, this),
              activeActionType === "CHIT_CANCEL" && /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  disabled: !totalAmount || loading,
                  onClick: () => {
                    if (!checkCustomerOperationAllowed()) return;
                    setActiveActionType("CHIT_CANCEL");
                    handleProceedToSettlementConfirm();
                  },
                  className: "bg-indigo-600 hover:bg-indigo-700",
                  icon: /* @__PURE__ */ jsxDEV(MdCancel, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2241,
                    columnNumber: 21
                  }, this),
                  children: "Proceed to Chit Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2231,
                  columnNumber: 13
                },
                this
              ),
              activeActionType === "CHIT_CLOSE" && /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  danger: true,
                  disabled: !totalAmount || loading,
                  onClick: () => {
                    if (!checkCustomerOperationAllowed()) return;
                    setActiveActionType("CHIT_CLOSE");
                    handleProceedToSettlementConfirm();
                  },
                  icon: /* @__PURE__ */ jsxDEV(StopOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2258,
                    columnNumber: 21
                  }, this),
                  children: "Proceed to Chit Close"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2248,
                  columnNumber: 13
                },
                this
              ),
              activeActionType === "CHIT_TRANSFER" && /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  disabled: transferLoading,
                  onClick: () => {
                    if (!checkCustomerOperationAllowed()) return;
                    handleTransferClick(selectedEnrollmentData);
                  },
                  icon: transferLoading ? /* @__PURE__ */ jsxDEV(SwapOutlined, { spin: true }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2275,
                    columnNumber: 15
                  }, this) : /* @__PURE__ */ jsxDEV(SwapOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2277,
                    columnNumber: 15
                  }, this),
                  className: "border-blue-500 text-blue-100 hover:bg-blue-50",
                  children: transferLoading ? "Transferring..." : "Proceed with Chit Transfer"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2265,
                  columnNumber: 13
                },
                this
              ),
              activeActionType === "hold" && /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "default",
                  onClick: () => {
                    if (!checkCustomerOperationAllowed()) return;
                    handleOnHoldModelOpen(
                      selectedEnrollmentData?.enrollmentId
                    );
                  },
                  icon: /* @__PURE__ */ jsxDEV(VscRemove, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2296,
                    columnNumber: 21
                  }, this),
                  className: "bg-orange-500 hover:bg-orange-600 border-none text-white shadow-sm",
                  children: "Place On Hold"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2287,
                  columnNumber: 13
                },
                this
              ),
              activeActionType === "SUSPEND" && /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "default",
                  onClick: () => {
                    if (!checkCustomerOperationAllowed()) return;
                    handleOnHoldModelOpen(
                      selectedEnrollmentData?.enrollmentId,
                      "suspend"
                    );
                  },
                  icon: /* @__PURE__ */ jsxDEV(PauseCircleOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2314,
                    columnNumber: 21
                  }, this),
                  className: "bg-indigo-600 hover:bg-indigo-700 border-none text-white shadow-sm",
                  children: "Proceed with Suspend"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2304,
                  columnNumber: 13
                },
                this
              ),
              activeActionType === "active-inactive" && /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  onClick: () => {
                    handleOnHoldModelOpen(
                      selectedEnrollmentData?.enrollmentId,
                      "active"
                    );
                  },
                  icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2332,
                    columnNumber: 21
                  }, this),
                  className: "bg-green-600 hover:bg-green-700 border-none text-white shadow-sm",
                  children: "Make Active / Inactive"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2322,
                  columnNumber: 13
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2225,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2143,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2129,
          columnNumber: 7
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 1664,
        columnNumber: 5
      }, this)
    },
    {
      key: "transaction-history",
      label: "Other Transaction History",
      children: /* @__PURE__ */ jsxDEV(Fragment, { children: [
        stats && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg border-t-4 border-blue-600 shadow-sm hover:shadow-md transition-all p-3", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-500", children: "Total Transactions" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2356,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-gray-900 mt-2", children: stats.total.count }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2359,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold text-blue-600 mt-2", children: [
              "₹",
              stats.total.amount.toLocaleString("en-IN")
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2362,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2355,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border-t-4 border-red-500 shadow-sm hover:shadow-md transition-all p-5", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-500", children: "Chit Cancellations" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2369,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-gray-900 mt-2", children: stats.chitCancel.count }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2372,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold text-red-600 mt-2", children: [
              "₹",
              stats.chitCancel.amount.toLocaleString("en-IN")
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2375,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2368,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border-t-4 border-emerald-500 shadow-sm hover:shadow-md transition-all p-5", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-500", children: "Pigmy Withdrawals" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2382,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-gray-900 mt-2", children: stats.pigmy.count }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2385,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold text-emerald-600 mt-2", children: [
              "₹",
              stats.pigmy.amount.toLocaleString("en-IN")
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2388,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2381,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2353,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-200 shadow-sm p-4", children: isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Transactions" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2411,
          columnNumber: 9
        }, this) : transactions.length === 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "No Transactions Found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2413,
          columnNumber: 9
        }, this) : /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: transactions,
            columns,
            exportedPdfName: "Transaction_Report",
            exportedFileName: "Transaction_Report.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2415,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2409,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 2351,
        columnNumber: 5
      }, this)
    },
    {
      key: "suspended-customers",
      label: "Suspended Customers",
      children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-gray-200 shadow-sm p-4", children: /* @__PURE__ */ jsxDEV(SuspendedCustomerReport, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 2431,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 2430,
        columnNumber: 5
      }, this)
    }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20 overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV(Navbar, { onGlobalSearchChangeHandler: () => {
    }, visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
      lineNumber: 2440,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
      lineNumber: 2441,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV(CustomAlert, { type: alertConfig.type, isVisible: alertConfig.visibility, message: alertConfig.message }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
      lineNumber: 2442,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 bg-gray-50 min-h-screen min-w-0", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(FiShuffle, { className: "text-blue-900" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2446,
          columnNumber: 29
        }, this),
        " Other Transactions"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 2445,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 2444,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        Tabs,
        {
          activeKey: activeTabKey,
          onChange: handleTabChange,
          items: tabItems,
          type: "card",
          tabBarExtraContent: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              Link,
              {
                to: "/payment-menu/payment-in-out-menu/pay-out-menu/chit-cancelation-pay-out",
                className: "px-3 py-1.5 border border-blue-500 text-blue-600 rounded-md hover:bg-blue-50",
                children: "Chit Cancel/Close PayOut"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2458,
                columnNumber: 33
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Link,
              {
                to: "/payment-menu/payment-in-out-menu/pay-in-menu/chit-transfer-pay-in",
                className: "px-3 py-1.5 border border-green-500 text-green-600 rounded-md hover:bg-green-50",
                children: "Chit Transfer"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2465,
                columnNumber: 33
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2457,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2450,
          columnNumber: 21
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(AntModal, { title: "Process Cancellation / Transfer", open: isAddRequestModalOpen, onCancel: () => {
        setIsAddRequestModalOpen(false);
        addRequestForm.resetFields();
        setSelectedCustomer(null);
        setSelectedEnrollmentData(null);
        setCustomerEnrollments([]);
        setActiveActionType(null);
      }, footer: null, width: 800, children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxDEV(Form.Item, { label: "Search Customer", children: /* @__PURE__ */ jsxDEV(Select, { showSearch: true, placeholder: "Search by Name, Phone, Aadhaar...", filterOption: (input, option) => (option?.label ?? "").toLowerCase().includes(input.toLowerCase()), onChange: (val) => handleCustomerChange(val), value: selectedCustomer?._id, options: users.map((user) => ({ value: user._id, label: `${user.full_name} - ${user.phone_number}` })) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2478,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2477,
          columnNumber: 29
        }, this),
        renderCustomerPortfolio(),
        activeActionType && /* @__PURE__ */ jsxDEV("div", { className: "pt-4 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV(Form, { form: addRequestForm, layout: "vertical", onFinish: handleAddCancelRequest, children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "amount", label: "Amount", rules: [{ required: true }], children: /* @__PURE__ */ jsxDEV(Input, { type: "number", prefix: "₹" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2485,
              columnNumber: 114
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2485,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "reason", label: "Reason", rules: [{ required: true }], children: /* @__PURE__ */ jsxDEV(Input.TextArea, { rows: 1 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2486,
              columnNumber: 114
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2486,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2484,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2", children: [
            /* @__PURE__ */ jsxDEV(Button, { onClick: () => setIsAddRequestModalOpen(false), children: "Cancel" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2489,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { type: "primary", htmlType: "submit", loading: cancelRequestsLoading, children: "Submit" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2490,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2488,
            columnNumber: 41
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2483,
          columnNumber: 37
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2482,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 2476,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 2475,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: handleCloseModal, showCloseButton: false, children: [
        step === 1 && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
          /* @__PURE__ */ jsxDEV("button", { onClick: handleCloseModal, className: "absolute top-2 right-2 p-1 text-2xl text-red-500 hover:bg-gray-100 z-10", children: "✕" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2503,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-indigo-700 to-slate-800 px-8 py-6 text-center relative", children: [
            /* @__PURE__ */ jsxDEV(FundProjectionScreenOutlined, { className: "text-white text-3xl mb-2 opacity-90" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2505,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl md:text-3xl font-bold text-white tracking-tight", children: "Cancellation & Transfer Process" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2506,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-indigo-200 text-sm mt-1", children: "Select an action, choose member, and settle" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2507,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2504,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-6 pb-2", children: [
            /* @__PURE__ */ jsxDEV(Divider, { className: "!my-2 !border-slate-100" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2510,
              columnNumber: 41
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: [
              /* @__PURE__ */ jsxDEV("a", { href: "/payment-menu/payment-in-out-menu/pay-out-menu/chit-cancelation-pay-out", className: "flex items-center justify-between px-4 py-3 rounded-lg border border-red-100 text-red-600 hover:bg-red-50 transition", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Chit Cancellation Pay Out" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2512,
                  columnNumber: 256
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "→" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2512,
                  columnNumber: 318
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2512,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("a", { href: "/payment-menu/payment-in-out-menu/pay-in-menu/chit-cancelation-pay-in", className: "flex items-center justify-between px-4 py-3 rounded-lg border border-emerald-100 text-emerald-600 hover:bg-emerald-50 transition", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Chit Cancellation Pay In" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2513,
                  columnNumber: 266
                }, this),
                /* @__PURE__ */ jsxDEV("span", { children: "→" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2513,
                  columnNumber: 327
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2513,
                columnNumber: 45
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2511,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2509,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-6 pt-8 pb-2", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [
              { label: "Chit Cancellation", value: "CHIT_CANCELLATION", icon: /* @__PURE__ */ jsxDEV(MdCancel, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2519,
                columnNumber: 85
              }, this), color: "from-red-500 to-red-600", hover: "hover:from-red-600 hover:to-red-700" },
              { label: "Group Change", value: "GROUP_CHANGE", icon: /* @__PURE__ */ jsxDEV(SwapOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2520,
                columnNumber: 75
              }, this), color: "from-amber-500 to-amber-600", hover: "hover:from-amber-600 hover:to-amber-700" },
              { label: "Group Close", value: "GROUP_CLOSED", icon: /* @__PURE__ */ jsxDEV(GroupOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2521,
                columnNumber: 74
              }, this), color: "from-orange-500 to-orange-600", hover: "hover:from-orange-600 hover:to-orange-700" },
              { label: "Other", value: "OTHER", icon: /* @__PURE__ */ jsxDEV(FileTextOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2522,
                columnNumber: 61
              }, this), color: "from-slate-500 to-slate-600", hover: "hover:from-slate-600 hover:to-slate-700" }
            ].map(
              (action) => /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => {
                    setRemarkType(action.value);
                    setCustomRemark("");
                  },
                  className: `relative group flex flex-col items-center justify-center p-4 rounded-xl bg-gradient-to-br ${action.color} ${action.hover} text-white shadow-md transition-all transform hover:-translate-y-1 focus:outline-none ${remarkType === action.value ? "ring-4 ring-offset-2 ring-indigo-300 scale-105" : ""}`,
                  children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-2xl mb-1", children: action.icon }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2529,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-sm md:text-base", children: action.label }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2530,
                      columnNumber: 53
                    }, this),
                    remarkType === action.value && /* @__PURE__ */ jsxDEV("span", { className: "absolute top-2 right-2 text-xs bg-white text-indigo-700 rounded-full px-1.5 py-0.5 font-bold", children: "✓" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2531,
                      columnNumber: 85
                    }, this)
                  ]
                },
                action.value,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2524,
                  columnNumber: 21
                },
                this
              )
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2517,
              columnNumber: 41
            }, this),
            remarkType && /* @__PURE__ */ jsxDEV("p", { className: "text-center text-xs text-indigo-600 mt-3 font-medium", children: [
              "Selected: ",
              remarkType.replace("_", " ")
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2535,
              columnNumber: 56
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2516,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "border-t border-slate-100 my-1" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2537,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(UserOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2540,
                  columnNumber: 153
                }, this),
                " 1. Select Member"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2540,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  showSearch: true,
                  size: "large",
                  placeholder: "Search by Name, Phone, Group, or Ticket",
                  className: "w-full",
                  value: selectedEnrollId,
                  onChange: handleChange,
                  options: enrollments.map((e) => ({ value: e._id, label: `${e.user_id?.full_name || "N/A"} | ${e.user_id?.phone_number} | ${e.group_id?.group_name || "N/A"} | Ticket: ${e.tickets}` })),
                  filterOption: (input, option) => (option?.label ?? "").toLowerCase().includes(input.toLowerCase())
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2541,
                  columnNumber: 45
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2539,
              columnNumber: 41
            }, this),
            selectedEnroll && /* @__PURE__ */ jsxDEV(Card, { className: "mb-8 border border-indigo-100 shadow-sm bg-gradient-to-r from-indigo-50 to-white", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxDEV(Avatar, { size: 48, icon: /* @__PURE__ */ jsxDEV(UserOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2551,
                columnNumber: 77
              }, this), className: "bg-indigo-200 text-indigo-700" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2551,
                columnNumber: 53
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-slate-800 font-semibold text-base", children: selectedEnroll.user_id?.full_name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2553,
                  columnNumber: 57
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-3 text-slate-500 text-xs mt-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
                    /* @__PURE__ */ jsxDEV(GroupOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2555,
                      columnNumber: 103
                    }, this),
                    " ",
                    selectedEnroll.group_id?.group_name
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2555,
                    columnNumber: 61
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
                    /* @__PURE__ */ jsxDEV(FileTextOutlined, {}, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2556,
                      columnNumber: 103
                    }, this),
                    " Ticket: ",
                    selectedEnroll.tickets
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2556,
                    columnNumber: 61
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2554,
                  columnNumber: 57
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2552,
                columnNumber: 53
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2550,
              columnNumber: 49
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2549,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-xs font-semibold text-slate-400 uppercase tracking-widest mb-3", children: "2. Payment Calculation" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2563,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row items-center gap-5 bg-indigo-50 p-5 rounded-xl border border-indigo-100", children: [
                /* @__PURE__ */ jsxDEV(Button, { type: "primary", size: "large", onClick: fetchTotalAmount, disabled: !selectedEnrollId || loading, className: "w-full md:w-auto bg-indigo-600 hover:bg-indigo-700 font-medium shadow-sm", children: loading ? /* @__PURE__ */ jsxDEV(Spin, { size: "small" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2566,
                  columnNumber: 64
                }, this) : "Calculate Total Payment" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2565,
                  columnNumber: 49
                }, this),
                totalAmount !== null && /* @__PURE__ */ jsxDEV("div", { className: "flex-grow text-center md:text-right", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-indigo-500 text-xs font-medium uppercase tracking-wider", children: "Total Calculated Amount" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2570,
                    columnNumber: 57
                  }, this),
                  /* @__PURE__ */ jsxDEV("h2", { className: "text-3xl font-bold text-indigo-800", children: [
                    "₹ ",
                    Number(totalAmount).toLocaleString()
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2571,
                    columnNumber: 57
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2569,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2564,
                columnNumber: 45
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-2", children: /* @__PURE__ */ jsxDEV(Button, { type: "link", onClick: fetchAllTransactions, className: "text-indigo-500 text-xs", children: "View All Transactions →" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2575,
                columnNumber: 84
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2575,
                columnNumber: 45
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2562,
              columnNumber: 41
            }, this),
            totalAmount !== null && remarkType && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 pt-4 border-t border-slate-200", children: /* @__PURE__ */ jsxDEV(Button, { type: "primary", size: "large", icon: /* @__PURE__ */ jsxDEV(SwapOutlined, {}, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2579,
              columnNumber: 91
            }, this), onClick: openTransferModal, disabled: loading || remarkType === "OTHER" && !customRemark?.trim(), className: "w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 border-0 text-white font-bold py-2 text-lg shadow-md", children: [
              "Proceed with ",
              remarkType.replace("_", " ")
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2579,
              columnNumber: 49
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2578,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2538,
            columnNumber: 37
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2502,
          columnNumber: 33
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2501,
          columnNumber: 13
        }, this),
        step === 2 && /* @__PURE__ */ jsxDEV("div", { className: "py-8 px-6 max-w-5xl mx-auto animate-fade-in-up", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-indigo-50 to-blue-50 p-3 rounded-2xl border border-indigo-100 shadow-sm ring-4 ring-white", children: /* @__PURE__ */ jsxDEV(IndianRupee, { className: "text-indigo-600 text-2xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2593,
                columnNumber: 45
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2592,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-slate-800 tracking-tight", children: [
                  "Confirm Chit ",
                  getActionButtonText(activeActionType)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2596,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500 mt-1 font-medium", children: "Review deduction breakdown and finalize" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2597,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowModal(false), className: "absolute top-2 right-3 p-1 text-2xl text-red-500 hover:bg-gray-100 z-10", children: "✕" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2598,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2595,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2591,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV(Tag, { color: "orange", className: "bg-orange-50 border-orange-100 text-orange-700 px-4 py-1.5 rounded-full text-sm font-semibold shadow-sm", children: "Awaiting Confirmation" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2601,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2590,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-5 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-slate-50/80 px-6 py-1 border-b border-slate-200 flex justify-between items-center", children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-xs font-bold text-slate-500 uppercase tracking-wider", children: "Service Charge Reference (5%)" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2608,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded-md font-medium", children: [
                "Current Group: ₹ ",
                Number(selectedEnrollmentData?.enrollment?.group?.group_value || 0).toLocaleString()
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2609,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2607,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-2", children: /* @__PURE__ */ jsxDEV(
              Table,
              {
                dataSource: [
                  { chit: "₹ 50,000", charge: "₹ 2,500" },
                  { chit: "₹ 1,00,000", charge: "₹ 5,000" },
                  { chit: "₹ 5,00,000", charge: "₹ 25,000" },
                  { chit: "₹ 10,00,000", charge: "₹ 50,000" }
                ].concat(
                  (() => {
                    const groupVal = selectedEnrollmentData?.enrollment?.group?.group_value;
                    if (groupVal && !["50000", "100000", "500000", "1000000"].includes(String(groupVal))) {
                      return [{ chit: `₹ ${Number(groupVal).toLocaleString()}`, charge: `₹ ${Math.round(Number(groupVal) * 0.05).toLocaleString()}` }];
                    }
                    return [];
                  })()
                ),
                columns: [
                  { title: "Chit Value", dataIndex: "chit", key: "chit", className: "text-slate-600" },
                  { title: "Service Charge (5%)", dataIndex: "charge", key: "charge", className: "font-semibold text-slate-700" }
                ],
                pagination: false,
                size: "small",
                rowClassName: (record) => record.chit === `₹ ${Number(selectedEnrollmentData?.enrollment?.group?.group_value || 0).toLocaleString()}` ? "!bg-indigo-50/50 text-indigo-900" : "hover:bg-slate-50",
                className: "!border-none"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2614,
                columnNumber: 41
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2613,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2606,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative bg-gradient-to-b from-slate-50 to-white rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50 p-6 md:p-8 mb-4 overflow-hidden", children: [
            /* @__PURE__ */ jsxDEV("h4", { className: "text-center text-xs font-bold text-slate-400 uppercase tracking-widest mb-4", children: "Calculation Breakdown" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2648,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-nowrap items-stretch gap-4 overflow-x-auto pb-2 px-1", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[160px] bg-white border border-slate-200 rounded-2xl p-4 text-center shadow-sm hover:shadow-md transition-all flex flex-col justify-center", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-blue-500 uppercase tracking-wider mb-1", children: "Gross Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2654,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold text-slate-800 tracking-tight", children: [
                  "₹ ",
                  Number(totalAmount).toFixed(0)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2655,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2653,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-slate-300 font-bold text-2xl flex items-center shrink-0", children: "−" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2661,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[160px] bg-white border-2  border-orange-200 rounded-2xl p-4 text-center shadow-sm hover:shadow-md hover:bg-orange-50/30 transition-all flex flex-col justify-center relative group", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-orange-400 uppercase tracking-wider mb-1", children: "Service Charge" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2665,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "absolute left-1 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm", children: "₹" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2667,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      min: 0,
                      value: serviceCharge,
                      onChange: (e) => setServiceCharge(parseFloat(e.target.value) || 0),
                      className: "text-center font-bold text-xl px-5 bg-transparent hover:text-orange-600 transition-colors focus:outline-none "
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2668,
                      columnNumber: 49
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2666,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2664,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-slate-300 font-bold text-2xl flex items-center shrink-0", children: "−" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2680,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[160px] bg-white border-2  border-purple-200 rounded-2xl p-4 text-center shadow-sm hover:shadow-md hover:bg-purple-50/30 transition-all flex flex-col justify-center relative group", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] font-bold text-purple-400 uppercase tracking-wider mb-1", children: "GST(18%)" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2684,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "absolute left-1 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm ", children: "₹" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2686,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "number",
                      min: 0,
                      value: gstAmount?.toFixed(0),
                      onChange: (e) => setGstAmount(parseFloat(e.target.value) || 0),
                      className: "text-center font-bold text-xl px-5 bg-transparent hover:text-purple-600 transition-colors focus:outline-none"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2687,
                      columnNumber: 49
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2685,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2683,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "text-slate-300 font-bold text-2xl flex items-center shrink-0", children: "=" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2699,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[160px] bg-gradient-to-br from-indigo-600 to-violet-600 rounded-2xl p-5 text-center shadow-lg shadow-indigo-200 flex flex-col justify-center border border-indigo-500/20", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold text-indigo-200 uppercase tracking-widest mb-1", children: "Net Payable" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2703,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-extrabold text-white tracking-tight drop-shadow-sm", children: [
                  "₹ ",
                  (finalAmount >= 0 ? finalAmount : 0).toFixed(0)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2704,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2702,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2651,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2645,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-1 gap-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-red-50 rounded-2xl p-5 border border-red-100 flex flex-col justify-center relative overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 relative z-10", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mt-0.5 text-red-500", children: /* @__PURE__ */ jsxDEV(ExclamationCircleOutlined, { className: "text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2722,
              columnNumber: 49
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2721,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h5", { className: "text-sm font-bold text-red-800 mb-1", children: "Irreversible Action" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2725,
                columnNumber: 49
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-red-600 leading-relaxed", children: "Funds will be permanently deducted from the user ledger. This action cannot be undone." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2726,
                columnNumber: 49
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2724,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2720,
            columnNumber: 41
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2719,
            columnNumber: 37
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2711,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mb-3", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-bold text-slate-700 mb-3 flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV(LockOutlined, { className: "text-slate-400" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2737,
                  columnNumber: 45
                }, this),
                "Security Check"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2736,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "bg-slate-100 text-slate-600 px-3 py-1 rounded-lg font-mono text-xs border border-slate-200", children: [
                "Target: ₹ ",
                finalAmount >= 0 ? finalAmount : 0
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2740,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2735,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                size: "large",
                placeholder: "Enter the amount above to confirm",
                value: confirmInput,
                onChange: (e) => setConfirmInput(e.target.value),
                status: confirmInput && confirmInput !== String(finalAmount) ? "error" : void 0,
                className: "rounded-xl border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10",
                prefix: /* @__PURE__ */ jsxDEV(SafetyOutlined, { className: "text-slate-400" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2751,
                  columnNumber: 27
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2744,
                columnNumber: 37
              },
              this
            ),
            confirmInput && confirmInput !== String(finalAmount) && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-2 text-red-500 text-xs animate-pulse", children: [
              /* @__PURE__ */ jsxDEV(CloseCircleOutlined, {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2755,
                columnNumber: 45
              }, this),
              " Amount does not match calculation"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2754,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2734,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl p-1 ", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-1", children: /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-bold text-gray-900", children: "Notification" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2762,
              columnNumber: 41
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2761,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-3 gap-4", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-3 p-4 rounded-xl border border-gray-200 \r\n            hover:border-green-400 hover:bg-green-50 cursor-pointer transition", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: thirdPartyEnable.send_whatsapp,
                    onChange: () => setThirdPartyEnable((prev) => ({
                      ...prev,
                      send_whatsapp: !prev.send_whatsapp
                    })),
                    className: "w-5 h-5 accent-green-600 rounded focus:ring-green-500"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2772,
                    columnNumber: 45
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsappSquare, { className: "text-green-500 text-3xl" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2784,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700", children: [
                  "WhatsApp",
                  /* @__PURE__ */ jsxDEV("small", { className: "block text-xs text-gray-400 font-normal", children: "Send notification" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2788,
                    columnNumber: 49
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2786,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2770,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-3 p-4 rounded-xl border border-gray-200 \r\n            hover:border-red-400 hover:bg-red-50 cursor-pointer transition", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: thirdPartyEnable.send_gmail,
                    onChange: () => setThirdPartyEnable((prev) => ({
                      ...prev,
                      send_gmail: !prev.send_gmail
                    })),
                    className: "w-5 h-5 accent-red-600 rounded focus:ring-red-500"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2798,
                    columnNumber: 45
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-2xl", children: "📧" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2810,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700", children: [
                  "Gmail",
                  /* @__PURE__ */ jsxDEV("small", { className: "block text-xs text-gray-400 font-normal", children: "Send email" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2816,
                    columnNumber: 49
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2814,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2796,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV("label", { className: "flex items-center gap-3 p-4 rounded-xl border border-gray-200 \r\n            hover:border-blue-400 hover:bg-blue-50 cursor-pointer transition", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: thirdPartyEnable.send_sms,
                    onChange: () => setThirdPartyEnable((prev) => ({
                      ...prev,
                      send_sms: !prev.send_sms
                    })),
                    className: "w-5 h-5 accent-blue-600 rounded focus:ring-blue-500"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2826,
                    columnNumber: 45
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-2xl", children: "💬" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2838,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-700", children: [
                  "SMS",
                  /* @__PURE__ */ jsxDEV("small", { className: "block text-xs text-gray-400 font-normal", children: "Send message" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2844,
                    columnNumber: 49
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2842,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2824,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2767,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2760,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col-reverse sm:flex-row gap-3 justify-end pt-6 border-t border-slate-100", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                size: "large",
                onClick: () => setShowModal(false),
                className: "h-12 px-8 font-medium rounded-xl border-slate-300 text-slate-600 hover:bg-slate-50 hover:border-slate-400",
                children: "Close"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2854,
                columnNumber: 37
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                size: "large",
                onClick: handleMoveAmount,
                disabled: loading || !confirmInput || String(confirmInput).trim() !== String(finalAmount),
                danger: true,
                className: "h-12 px-10 font-bold rounded-xl bg-gradient-to-r from-red-500 to-orange-500 border-none shadow-lg shadow-red-200 hover:shadow-red-300 hover:-translate-y-0.5 transition-all flex items-center gap-2",
                icon: /* @__PURE__ */ jsxDEV(SwapOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2868,
                  columnNumber: 25
                }, this),
                children: loading ? /* @__PURE__ */ jsxDEV(Spin, { size: "small", className: "text-white" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2870,
                  columnNumber: 52
                }, this) : `Confirm Chit ${getActionButtonText(activeActionType)}`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2861,
                columnNumber: 37
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2853,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2589,
          columnNumber: 13
        }, this),
        step === 3 && /* @__PURE__ */ jsxDEV("div", { className: "py-4 px-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-2 rounded-full", children: /* @__PURE__ */ jsxDEV(SwapOutlined, { className: "text-blue-600 text-xl" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2878,
              columnNumber: 83
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2878,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-slate-800", children: "What would you like to do?" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2879,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2877,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxDEV(Button, { block: true, size: "large", onClick: handleRefund, className: "bg-amber-500 hover:bg-amber-600 text-white font-medium", children: "Process Fund Settlement" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2882,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV(Divider, { plain: true, children: "OR" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2883,
              columnNumber: 37
            }, this),
            /* @__PURE__ */ jsxDEV(Button, { block: true, size: "large", onClick: handleTransferToDifferentAccount, className: "bg-emerald-500 hover:bg-emerald-600 text-white font-medium", children: "Fund Transfer to Chit / Loan / Pigmy" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2884,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2881,
            columnNumber: 33
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex justify-end", children: /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: () => {
                setShowModal(false);
                window.location.reload();
              },
              className: "font-medium",
              children: "Back"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2888,
              columnNumber: 37
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2887,
            columnNumber: 33
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2876,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 2499,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        Modal,
        {
          isVisible: showWithdrawModal,
          onClose: () => {
            setShowWithdrawModal(false);
            setWithdrawData(null);
            setShowCalculated(false);
          },
          showCloseButton: false,
          children: /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setShowWithdrawModal(false);
                  setWithdrawData(null);
                  setShowCalculated(false);
                },
                className: "absolute top-0 right-1 text-red-600 hover:text-red-800 text-xl font-bold z-10 focus:outline-none",
                "aria-label": "Close",
                children: "✕"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2914,
                columnNumber: 29
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-purple-600 to-indigo-600 px-2 py-5 flex justify-between items-center", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-2xl font-bold text-white", children: "Withdraw Pigmy Account" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2927,
                  columnNumber: 37
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-purple-100 text-sm mt-1", children: "Review details before processing withdrawal" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2928,
                  columnNumber: 37
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2926,
                columnNumber: 33
              }, this),
              withdrawData && /* @__PURE__ */ jsxDEV("div", { children: [
                withdrawData.request_status === "APPROVED" && /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 bg-green-200 text-green-800 rounded-full text-sm font-semibold", children: "Approved" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2933,
                  columnNumber: 19
                }, this),
                withdrawData.request_status === "REQUESTED" && /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 bg-yellow-200 text-yellow-800 rounded-full text-sm font-semibold", children: "Requested" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2936,
                  columnNumber: 19
                }, this),
                withdrawData.request_status === "COMPLETED" && /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 bg-blue-200 text-blue-800 rounded-full text-sm font-semibold", children: "Completed" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2939,
                  columnNumber: 19
                }, this),
                withdrawData.request_status === "CLOSED" && /* @__PURE__ */ jsxDEV("span", { className: "px-3 py-1 bg-gray-200 text-gray-800 rounded-full text-sm font-semibold", children: "Closed" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2942,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2931,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2925,
              columnNumber: 29
            }, this),
            withdrawData && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-100 rounded-xl p-5 mb-6", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold text-gray-800 mb-4", children: "Pigmy Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2952,
                  columnNumber: 41
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Pigmy ID" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2955,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: withdrawData.pigme_id }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2956,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2954,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Customer Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2959,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: withdrawData.customer?.full_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2960,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2958,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Payment Type" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2963,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: withdrawData.maturity_period }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2964,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2962,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: [
                      withdrawData.maturity_period?.toLowerCase().replace(/\b\w/g, (char) => char.toUpperCase()),
                      " ",
                      "paid Amount"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2967,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-blue-600 text-lg", children: [
                      "₹",
                      withdrawData.payable_amount
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2973,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2966,
                    columnNumber: 45
                  }, this),
                  withdrawData?.closure_type === "MATURED" && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Interest Rate" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2981,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-green-600", children: [
                      withdrawData.maturity_interest,
                      "%"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2982,
                      columnNumber: 53
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2980,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Start Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2988,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: new Date(withdrawData.start_date).toLocaleDateString("en-GB") }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2989,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2987,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Total Paid" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2994,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-blue-600", children: [
                      "₹",
                      withdrawData.total_paid
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2995,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2993,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Months Completed" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 2999,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: withdrawData.start_date ? (() => {
                      const start = dayjs(withdrawData.start_date);
                      const today = dayjs();
                      let months = (today.year() - start.year()) * 12 + (today.month() - start.month());
                      months = Math.max(0, months);
                      return `${months} / ${withdrawData.duration || "?"} months`;
                    })() : "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3e3,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 2997,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Closure Type" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3012,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: "inline-flex px-3 py-1 rounded-full text-sm font-medium bg-yellow-100 text-yellow-800 mt-1", children: withdrawData.closure_type }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3013,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3011,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-3 shadow-sm", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Pigmy Duration" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3018,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-800", children: [
                      withdrawData.duration,
                      " Months"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3019,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3017,
                    columnNumber: 45
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: withdrawData.closure_type === "PRE-MATURED" ? "Premature Withdrawal Deduction" : "Interest" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3022,
                      columnNumber: 49
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "number",
                            step: "any",
                            value: editableInterest,
                            onChange: (e) => setEditableInterest(e.target.value),
                            onBlur: handlePercentBlur,
                            className: "w-full p-2 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500",
                            placeholder: "%"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 3027,
                            columnNumber: 57
                          },
                          this
                        ),
                        errors.editableInterest && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-600", children: errors.editableInterest }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 3037,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 3026,
                        columnNumber: 53
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          type: "button",
                          onClick: handleSyncFields,
                          className: "p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition flex items-center justify-center",
                          title: "Calculate the other field",
                          children: /* @__PURE__ */ jsxDEV(FaCalculator, {}, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                            lineNumber: 3046,
                            columnNumber: 57
                          }, this)
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 3040,
                          columnNumber: 53
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "number",
                          step: "any",
                          value: deductionAmount,
                          onChange: (e) => setDeductionAmount(e.target.value),
                          onBlur: handleAmountBlur,
                          className: "w-full p-2 border border-gray-300 rounded-lg focus:ring-purple-500 focus:border-purple-500",
                          placeholder: "₹ Amount"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 3049,
                          columnNumber: 57
                        },
                        this
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 3048,
                        columnNumber: 53
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3025,
                      columnNumber: 49
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3021,
                    columnNumber: 45
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 2953,
                  columnNumber: 41
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 2951,
                columnNumber: 37
              }, this),
              showCalculated && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-5 mb-6", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold text-gray-800 mb-4", children: "Calculated Values" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 3067,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Total Paid" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3070,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-blue-600", children: [
                      "₹",
                      withdrawData.total_paid
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3071,
                      columnNumber: 53
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3069,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: withdrawData.closure_type === "PRE-MATURED" ? " Premature Withdrawal Deduction (%)" : "Maturity Interest (%)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3074,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: `text-xl font-bold ${withdrawData.closure_type === "PRE-MATURED" ? "text-red-600" : "text-green-600"}`, children: [
                      withdrawData.closure_type === "PRE-MATURED" ? withdrawData.pre_matured_interest : withdrawData.maturity_interest,
                      "%"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3075,
                      columnNumber: 53
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3073,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl p-4", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Maturity Amount" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3078,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-purple-600", children: [
                      "₹",
                      withdrawData.maturity_amount
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3079,
                      columnNumber: 53
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3077,
                    columnNumber: 49
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 3068,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 3066,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 border-t pt-5", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: handleRecalculate,
                    className: "px-6 py-3 bg-blue-500 text-white rounded-xl font-medium shadow-md hover:shadow-lg transition-all duration-200",
                    children: "Recalculate"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3101,
                    columnNumber: 41
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: handleWithdraw,
                    disabled: withdrawLoading || !showCalculated,
                    className: `px-6 py-3 rounded-xl font-medium shadow-md transition-all duration-200 flex items-center gap-2 ${withdrawLoading || !showCalculated ? "bg-gray-300 text-gray-500 cursor-not-allowed" : "bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:shadow-lg"}`,
                    children: withdrawLoading ? /* @__PURE__ */ jsxDEV(Spin, { size: "small", className: "text-white" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3115,
                      columnNumber: 64
                    }, this) : "Submit"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3107,
                    columnNumber: 41
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 3090,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 2949,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 2912,
            columnNumber: 25
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 2903,
          columnNumber: 21
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Drawer, { closable: true, title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "text-indigo-500" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 3124,
          columnNumber: 86
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800", children: "Transaction History" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 3124,
          columnNumber: 134
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 3124,
        columnNumber: 45
      }, this), placement: "right", open: openAntDDrawer, onClose: () => setOpenAntDDrawer(false), width: 420, children: loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-40", children: /* @__PURE__ */ jsxDEV(Spin, { size: "large" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 3126,
        columnNumber: 68
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 3126,
        columnNumber: 13
      }, this) : lastAllPayments?.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-16", children: [
        /* @__PURE__ */ jsxDEV(FileTextOutlined, { className: "text-4xl text-slate-300 mb-3" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 3128,
          columnNumber: 48
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-500 font-medium", children: "No Transactions Found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 3128,
          columnNumber: 109
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 3128,
        columnNumber: 13
      }, this) : /* @__PURE__ */ jsxDEV(Timeline, { items: lastAllPayments.map((payment, index) => ({
        color: "blue",
        children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg p-4 shadow-sm border border-slate-100 mb-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start mb-2", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-slate-500 font-medium", children: payment.pay_date ? new Date(payment.pay_date).toLocaleDateString("en-GB") : "-" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 3135,
              columnNumber: 45
            }, this),
            /* @__PURE__ */ jsxDEV(Tag, { color: "indigo", className: "m-0 font-semibold", children: [
              "₹",
              payment?.amount?.toLocaleString()
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 3138,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 3134,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-slate-800 text-sm mb-1", children: payment.user_id?.full_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 3140,
            columnNumber: 41
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 flex-wrap", children: [
            payment.group_id && /* @__PURE__ */ jsxDEV("span", { className: "text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded", children: payment.group_id?.group_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 3142,
              columnNumber: 66
            }, this),
            payment.ticket && /* @__PURE__ */ jsxDEV("span", { className: "text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded", children: [
              "Ticket: ",
              payment?.ticket
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 3143,
              columnNumber: 64
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded", children: payment?.pay_type }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 3144,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 3141,
            columnNumber: 41
          }, this)
        ] }, index, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 3133,
          columnNumber: 15
        }, this)
      })) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 3130,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
        lineNumber: 3124,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV(
        Modal,
        {
          isVisible: showModelOnHold,
          onClose: () => {
            setShowModelOnHold(false);
            setCurrentGroup(null);
            setEnrollmentOperation(null);
          },
          children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-gray-50 rounded-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `
                        flex h-14 w-14 items-center justify-center
                        rounded-full shadow-lg
                        ${currentOperation.iconClass}
                    `,
                children: /* @__PURE__ */ jsxDEV(
                  "svg",
                  {
                    className: "h-8 w-8 text-white",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    strokeWidth: 2,
                    children: enrollmentOperation === "active" ? /* @__PURE__ */ jsxDEV(
                      "path",
                      {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        d: "M5 13l4 4L19 7"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 3181,
                        columnNumber: 23
                      },
                      this
                    ) : /* @__PURE__ */ jsxDEV(
                      "path",
                      {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        d: "M12 9v4m0 4h.01M10.29 3.86l-7.5 13A1 1 0 003.66 18h16.68a1 1 0 00.87-1.5l-7.5-13a1 1 0 00-1.74 0z"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 3187,
                        columnNumber: 23
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3173,
                    columnNumber: 41
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 3166,
                columnNumber: 37
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 3165,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: currentOperation.title }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 3202,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-gray-600 leading-relaxed", children: currentOperation.description }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 3207,
                columnNumber: 37
              }, this),
              currentGroup && /* @__PURE__ */ jsxDEV("div", { className: "mt-5 bg-white rounded-xl border border-gray-200 p-5 shadow-sm", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `
                                    h-8 w-1 rounded-full
                                    ${currentOperation.accentClass}
                                `
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3217,
                      columnNumber: 49
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-700", children: "Customer Details" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3224,
                    columnNumber: 49
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 3216,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-3", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Customer" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3234,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-1", children: currentGroup?.user_id?.full_name || "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3238,
                      columnNumber: 53
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3233,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-3", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Group" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3246,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-1", children: currentGroup?.group_id?.group_name || "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3250,
                      columnNumber: 53
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3245,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-3", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Phone" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3258,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-1", children: currentGroup?.user_id?.phone_number || "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3262,
                      columnNumber: 53
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3257,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-3", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Ticket" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3270,
                      columnNumber: 53
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-1", children: currentGroup?.tickets || "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3274,
                      columnNumber: 53
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3269,
                    columnNumber: 49
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 3230,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex items-center justify-between bg-gray-50 rounded-lg px-4 py-3 border border-gray-200", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-500", children: "Current Status" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3285,
                    columnNumber: 49
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Tag,
                    {
                      color: currentGroup?.customer_status === "On Hold" ? "orange" : currentGroup?.customer_status === "Active" ? "blue" : "red",
                      children: currentGroup?.customer_status || "N/A"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3289,
                      columnNumber: 49
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 3283,
                  columnNumber: 45
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex items-start gap-2 bg-red-50 rounded-lg p-3 border-l-4 border-red-500", children: [
                  /* @__PURE__ */ jsxDEV(
                    "svg",
                    {
                      className: "w-5 h-5 text-red-500 flex-shrink-0",
                      fill: "currentColor",
                      viewBox: "0 0 20 20",
                      children: /* @__PURE__ */ jsxDEV(
                        "path",
                        {
                          fillRule: "evenodd",
                          d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9a1 1 0 00-1-1z",
                          clipRule: "evenodd"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                          lineNumber: 3312,
                          columnNumber: 53
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3307,
                      columnNumber: 49
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-700", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Important:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                      lineNumber: 3320,
                      columnNumber: 53
                    }, this),
                    " ",
                    "Verify customer details before proceeding."
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3319,
                    columnNumber: 49
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 3305,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                lineNumber: 3214,
                columnNumber: 19
              }, this),
              currentGroup && /* @__PURE__ */ jsxDEV(
                "form",
                {
                  onSubmit: handleOnHoldGroup,
                  className: "mt-6",
                  children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col-reverse sm:flex-row justify-end gap-3", children: [
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "button",
                        onClick: () => {
                          setShowModelOnHold(false);
                          setCurrentGroup(null);
                          setEnrollmentOperation(null);
                        },
                        className: "\r\n                                    inline-flex justify-center items-center\r\n                                    px-6 py-2.5 text-sm font-medium\r\n                                    text-gray-700 bg-white\r\n                                    border border-gray-300 rounded-lg\r\n                                    hover:bg-gray-50\r\n                                    hover:border-gray-400\r\n                                    focus:outline-none\r\n                                    focus:ring-2 focus:ring-gray-300\r\n                                    transition-all\r\n                                ",
                        children: "Cancel"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 3341,
                        columnNumber: 49
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        type: "submit",
                        className: `
                                    inline-flex justify-center items-center
                                    px-6 py-2.5 text-sm font-medium
                                    text-white rounded-lg
                                    focus:outline-none
                                    focus:ring-4
                                    shadow-md hover:shadow-lg
                                    transition-all
                                    ${currentOperation.buttonClass}
                                `,
                        children: currentOperation.buttonText
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                        lineNumber: 3365,
                        columnNumber: 49
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                    lineNumber: 3338,
                    columnNumber: 45
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
                  lineNumber: 3334,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
              lineNumber: 3199,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 3162,
            columnNumber: 29
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
            lineNumber: 3160,
            columnNumber: 25
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
          lineNumber: 3152,
          columnNumber: 21
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
      lineNumber: 2443,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
    lineNumber: 2439,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx",
    lineNumber: 2438,
    columnNumber: 5
  }, this);
};
_s(UserAccountsMenu, "PDRgbYoMou6t7y63H6bZjvVwEoU=", false, function() {
  return [useNavigate, Form.useForm, useLocation];
});
_c = UserAccountsMenu;
export default UserAccountsMenu;
var _c;
$RefreshReg$(_c, "UserAccountsMenu");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UserAccountsMenu.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ3ZCeUMsU0FzdEIrQixVQXR0Qi9COzJCQWh2QnpDO0FBQW9CQSxNQUFPLGNBQVUsT0FBUSxzQkFBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNwRCxTQUFTQyxNQUFNQyxhQUFhQyxtQkFBbUI7QUFDL0M7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxTQUFTQztBQUFBQSxFQUNUQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBTCxTQUFTTTtBQUFBQSxFQUNUQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBQ1A7QUFBQSxFQUNJQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNHO0FBQ1AsT0FBT0MsV0FBVztBQUNsQixTQUFTQyxjQUFjQyxhQUFhQyx3QkFBd0I7QUFFNUQsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGVBQWU7QUFDdEIsT0FBT3JDLFdBQVc7QUFDbEIsT0FBT3NDLGlCQUFpQjtBQUN4QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0Msd0JBQXdCO0FBRS9CLE9BQU9DLFNBQVM7QUFDaEIsU0FBU0MsVUFBVUMsZUFBZTtBQUNsQyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLG1CQUFtQjtBQUM1QixPQUFPQyw2QkFBNkI7QUFFcEMsTUFBTUMsbUJBQW1CQSxNQUFNO0FBQUFDLEtBQUE7QUFDM0IsUUFBTUMsV0FBVy9ELFlBQVk7QUFHN0IsUUFBTSxDQUFDZ0UsZ0JBQWdCQyxpQkFBaUIsSUFBSUMsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ0MsdUJBQXVCQyx3QkFBd0IsSUFBSUYsU0FBUyxLQUFLO0FBQ3hFLFFBQU0sQ0FBQ0csbUJBQW1CQyxvQkFBb0IsSUFBSUosU0FBUyxNQUFNO0FBQ2pFLFFBQU0sQ0FBQ0ssdUJBQXVCQyx3QkFBd0IsSUFBSU4sU0FBUyxLQUFLO0FBR3hFLFFBQU0sQ0FBQ08sY0FBYyxJQUFJckQsS0FBS3NELFFBQVE7QUFDdEMsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUlWLFNBQVMsRUFBRTtBQUdyQyxRQUFNLENBQUNXLHFCQUFxQkMsc0JBQXNCLElBQUlaLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUNhLFdBQVdDLFlBQVksSUFBSWQsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ2UsVUFBVUMsV0FBVyxJQUFJaEIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ2lCLG9CQUFvQkMscUJBQXFCLElBQUlsQixTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDbUIsY0FBY0MsZUFBZSxJQUFJcEIsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ3FCLGNBQWNDLGVBQWUsSUFBSXRCLFNBQVMsS0FBSztBQUd0RCxRQUFNLENBQUN1QixrQkFBa0JDLG1CQUFtQixJQUFJeEIsU0FBUyxJQUFJO0FBQzdELFFBQU0sQ0FBQ3lCLHdCQUF3QkMseUJBQXlCLElBQUkxQixTQUFTLElBQUk7QUFDekUsUUFBTSxDQUFDMkIsa0JBQWtCQyxtQkFBbUIsSUFBSTVCLFNBQVMsSUFBSTtBQUM3RCxRQUFNLENBQUM2QixRQUFRQyxTQUFTLElBQUk5QixTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUMrQixlQUFlQyxnQkFBZ0IsSUFBSWhDLFNBQVMsQ0FBQztBQUdwRCxRQUFNLENBQUNpQyxnQkFBZ0JDLGlCQUFpQixJQUFJbEMsU0FBUyxDQUFDO0FBR3RELFFBQU0sQ0FBQ21DLGNBQWNDLGVBQWUsSUFBSXBDLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUNxQyxXQUFXQyxZQUFZLElBQUl0QyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDdUMsUUFBUUMsU0FBUyxJQUFJeEMsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ3lDLFVBQVVDLFdBQVcsSUFBSTFDLFNBQVMsRUFBRTJDLFlBQVksR0FBR0MsYUFBYSxFQUFFLENBQUM7QUFDMUUsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUk5QyxTQUFTO0FBQUEsSUFDbkMrQyxVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYQyxTQUFTO0FBQUEsRUFDYixDQUFDO0FBQ0QsUUFBTSxFQUFFQyxZQUFZLElBQUlyRztBQUN4QixRQUFNc0csV0FBV3ZILFlBQVk7QUFHN0IsUUFBTSxDQUFDd0gsV0FBV0MsWUFBWSxJQUFJdEQsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ3VELE1BQU1DLE9BQU8sSUFBSXhELFNBQVMsQ0FBQztBQUNsQyxRQUFNLENBQUN5RCxhQUFhQyxjQUFjLElBQUkxRCxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDMkQsa0JBQWtCQyxtQkFBbUIsSUFBSTVELFNBQVMsSUFBSTtBQUM3RCxRQUFNLENBQUM2RCxnQkFBZ0JDLGlCQUFpQixJQUFJOUQsU0FBUyxJQUFJO0FBQ3pELFFBQU0sQ0FBQzRDLGFBQWFtQixjQUFjLElBQUkvRCxTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDZ0UsU0FBU0MsVUFBVSxJQUFJakUsU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ2tFLFlBQVlDLGFBQWEsSUFBSW5FLFNBQVMsSUFBSTtBQUNqRCxRQUFNLENBQUNvRSxjQUFjQyxlQUFlLElBQUlyRSxTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDc0UsWUFBWUMsYUFBYSxJQUFJdkUsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ3dFLGNBQWNDLGVBQWUsSUFBSXpFLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUMwRSxpQkFBaUJDLGtCQUFrQixJQUFJM0UsU0FBUyxDQUFDO0FBQ3hELFFBQU0sQ0FBQzRFLGdCQUFnQkMsaUJBQWlCLElBQUk3RSxTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDOEUsY0FBY0MsZUFBZSxJQUFJL0UsU0FBUyxNQUFNO0FBQ25ELFdBQU9vRCxTQUFTNEIsT0FBT0MsYUFBYTtBQUFBLEVBQ3hDLENBQUM7QUFDRCxRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUluRixTQUFTLEtBQUs7QUFHNUQsUUFBTSxDQUFDb0YsZ0JBQWdCQyxpQkFBaUIsSUFBSXJGLFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUNzRixpQkFBaUJDLGtCQUFrQixJQUFJdkYsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ3dGLGVBQWVDLGdCQUFnQixJQUFJekYsU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQzBGLGFBQWFDLGNBQWMsSUFBSTNGLFNBQVMsQ0FBQztBQUNoRCxRQUFNLENBQUM0RixXQUFXQyxZQUFZLElBQUk3RixTQUFTO0FBRzNDLFFBQU0sQ0FBQzhGLG1CQUFtQkMsb0JBQW9CLElBQUkvRixTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDZ0csY0FBY0MsZUFBZSxJQUFJakcsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQ2tHLGdCQUFnQkMsaUJBQWlCLElBQUluRyxTQUFTLEtBQUs7QUFDMUQsUUFBTSxDQUFDb0csa0JBQWtCQyxtQkFBbUIsSUFBSXJHLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUNzRyx1QkFBdUJDLHdCQUF3QixJQUFJdkcsU0FBUyxLQUFLO0FBQ3hFLFFBQU0sQ0FBQ3dHLGVBQWVDLGdCQUFnQixJQUFJekcsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzBHLGFBQWFDLGNBQWMsSUFBSTNHLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUM0RyxpQkFBaUJDLGtCQUFrQixJQUFJN0csU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzhHLGNBQWNDLGVBQWUsSUFBSS9HLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNnSCxTQUFTQyxVQUFVLElBQUlqSCxTQUFTLEVBQUU7QUFDekMsUUFBTSxDQUFDa0gsaUJBQWlCQyxrQkFBa0IsSUFBSW5ILFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNvSCxpQkFBaUJDLGtCQUFrQixJQUFJckgsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ3NILGlCQUFpQkMsa0JBQWtCLElBQUl2SCxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDd0gsa0JBQWtCQyxtQkFBbUIsSUFBSXpILFNBQVM7QUFBQSxJQUNyRDBILGVBQWU7QUFBQSxJQUNmQyxZQUFZO0FBQUEsSUFDWkMsVUFBVTtBQUFBLEVBQ2QsQ0FBQztBQUNELFFBQU0sQ0FBQ0MscUJBQXFCQyxzQkFBc0IsSUFBSTlILFNBQVMsSUFBSTtBQUNuRSxRQUFNLENBQUMrSCxlQUFlQyxnQkFBZ0IsSUFBSWhJLFNBQVMsS0FBSztBQUd4RCxRQUFNLENBQUNpSSxhQUFhQyxjQUFjLElBQUlsSSxTQUFTO0FBQUEsSUFDM0NtSSxZQUFZO0FBQUEsSUFDWi9MLFNBQVM7QUFBQSxJQUNUZ00sTUFBTTtBQUFBLEVBQ1YsQ0FBQztBQUdELFFBQU1DLFlBQVlBLE1BQU07QUFDcEJ0RSxtQkFBZSxJQUFJO0FBQ25CSCx3QkFBb0IsSUFBSTtBQUN4QkUsc0JBQWtCLElBQUk7QUFDdEJTLGtCQUFjLEVBQUU7QUFDaEJKLGtCQUFjLElBQUk7QUFDbEJFLG9CQUFnQixFQUFFO0FBQ2xCTSx1QkFBbUIsQ0FBQztBQUNwQkUsc0JBQWtCLElBQUk7QUFDdEJKLG9CQUFnQixFQUFFO0FBQ2xCakIsWUFBUSxDQUFDO0FBQUEsRUFDYjtBQUVBLFFBQU04RSxtQkFBbUJBLE1BQU07QUFDM0JoRixpQkFBYSxLQUFLO0FBQ2xCK0UsY0FBVTtBQUFBLEVBQ2Q7QUFFQSxRQUFNRSxZQUFZdkMsY0FBY3dDO0FBR2hDLFFBQU1DLG9CQUFvQkEsTUFBTTtBQUM1QixRQUFJLENBQUNyQyxvQkFBb0JtQyxhQUFhLEdBQUc7QUFDckNoQix5QkFBbUIsRUFBRTtBQUNyQjtBQUFBLElBQ0o7QUFDQSxVQUFNbUIsVUFBVUMsV0FBV3ZDLGdCQUFnQjtBQUMzQyxRQUFJd0MsTUFBTUYsT0FBTyxLQUFLQSxVQUFVLEdBQUc7QUFDL0JuQix5QkFBbUIsRUFBRTtBQUNyQjtBQUFBLElBQ0o7QUFDQSxVQUFNc0IsbUJBQW9CSCxVQUFVLE1BQU9IO0FBQzNDaEIsdUJBQW1Cc0IsaUJBQWlCQyxRQUFRLENBQUMsQ0FBQztBQUFBLEVBQ2xEO0FBR0EsUUFBTUMsbUJBQW1CQSxNQUFNO0FBQzNCLFFBQUksQ0FBQ3pCLG1CQUFtQmlCLGFBQWEsR0FBRztBQUNwQ2xDLDBCQUFvQixFQUFFO0FBQ3RCO0FBQUEsSUFDSjtBQUNBLFVBQU0yQyxTQUFTTCxXQUFXckIsZUFBZTtBQUN6QyxRQUFJc0IsTUFBTUksTUFBTSxLQUFLQSxTQUFTLEdBQUc7QUFDN0IzQywwQkFBb0IsRUFBRTtBQUN0QjtBQUFBLElBQ0o7QUFDQSxVQUFNNEMsb0JBQXFCRCxTQUFTVCxZQUFhO0FBQ2pEbEMsd0JBQW9CNEMsa0JBQWtCSCxRQUFRLENBQUMsQ0FBQztBQUFBLEVBQ3BEO0FBR0EsUUFBTUksbUJBQW1CQSxNQUFNO0FBQzNCLFFBQUk5QyxvQkFBb0JtQyxZQUFZLEdBQUc7QUFDbkMsWUFBTUcsVUFBVUMsV0FBV3ZDLGdCQUFnQjtBQUMzQyxVQUFJLENBQUN3QyxNQUFNRixPQUFPLEtBQUtBLFdBQVcsR0FBRztBQUNqQyxjQUFNUyxNQUFPVCxVQUFVLE1BQU9IO0FBQzlCaEIsMkJBQW1CNEIsSUFBSUwsUUFBUSxDQUFDLENBQUM7QUFBQSxNQUNyQztBQUFBLElBQ0osV0FBV3hCLG1CQUFtQmlCLFlBQVksR0FBRztBQUN6QyxZQUFNWSxNQUFNUixXQUFXckIsZUFBZTtBQUN0QyxVQUFJLENBQUNzQixNQUFNTyxHQUFHLEtBQUtBLE9BQU8sR0FBRztBQUN6QixjQUFNQyxNQUFPRCxNQUFNWixZQUFhO0FBQ2hDbEMsNEJBQW9CK0MsSUFBSU4sUUFBUSxDQUFDLENBQUM7QUFBQSxNQUN0QztBQUFBLElBQ0o7QUFBQSxFQUNKO0FBRUFPLFlBQVUsTUFBTTtBQUNaLFVBQU1DLE9BQU9DLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxRQUFJRixNQUFNO0FBQ04sWUFBTUcsVUFBVUMsS0FBS0MsTUFBTUwsSUFBSTtBQUMvQnJDLGlCQUFXd0MsU0FBU0csR0FBRztBQUFBLElBQzNCO0FBQUEsRUFDSixHQUFHLEVBQUU7QUFHTFAsWUFBVSxNQUFNO0FBQ1osVUFBTVEsYUFBYSxZQUFZO0FBQzNCLFVBQUk7QUFDQSxjQUFNQyxNQUFNLE1BQU0xSyxJQUFJMkssSUFBSSxlQUFlO0FBQ3pDckosaUJBQVNvSixJQUFJRSxNQUFNQSxRQUFRLEVBQUU7QUFBQSxNQUNqQyxTQUFTQyxPQUFPO0FBQ1pDLGdCQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLE1BQy9DO0FBQUEsSUFDSjtBQUNBSixlQUFXO0FBQUEsRUFDZixHQUFHLEVBQUU7QUFJTFIsWUFBVSxNQUFNO0FBQ1osVUFBTWMsUUFBUUMsT0FBT3hILFdBQVcsS0FBSztBQUNyQyxVQUFNeUgsU0FBU0QsT0FBTzVFLGFBQWEsS0FBSztBQUN4QyxVQUFNOEUsTUFBTUYsT0FBT3hFLFNBQVMsS0FBSztBQUNqQyxVQUFNMkUsTUFBTUosUUFBUUUsU0FBU0M7QUFDN0IzRSxtQkFBZTRFLE9BQU8sSUFBSUEsTUFBTSxDQUFDO0FBQUEsRUFDckMsR0FBRyxDQUFDM0gsYUFBYTRDLGVBQWVJLFNBQVMsQ0FBQztBQUUxQ3lELFlBQVUsTUFBTTtBQUNaLFVBQU1tQixTQUFTM0osWUFBWSxDQUFDLEdBQUc0SjtBQUMvQixRQUFJRCxXQUFXLFlBQVk7QUFDdkJoTixtQkFBYWtOLFFBQVE7QUFBQSxRQUNqQnRPLFNBQVM7QUFBQSxRQUNUdU8sYUFBYTtBQUFBLFFBQ2JDLFdBQVc7QUFBQSxNQUNmLENBQUM7QUFBQSxJQUNMO0FBQUEsRUFDSixHQUFHLENBQUMvSixTQUFTLENBQUM7QUFFZHdJLFlBQVUsTUFBTTtBQUNaLFFBQUlqRyxTQUFTNEIsT0FBT0MsV0FBVztBQUMzQjRGLGFBQU9DLFFBQVFDLGFBQWEsQ0FBQyxHQUFHQyxTQUFTQyxLQUFLO0FBQUEsSUFDbEQ7QUFBQSxFQUNKLEdBQUcsQ0FBQzdILFFBQVEsQ0FBQztBQUliLFFBQU04SCwwQkFBMEJBLENBQUNDLFdBQVc7QUFDeEMsUUFBSSxDQUFDQSxPQUFRO0FBQ2IsVUFBTUMsV0FBVztBQUFBLE1BQ2J4QixLQUFLdUIsT0FBT3ZCO0FBQUFBLE1BQ1p5QixXQUFXRixPQUFPRztBQUFBQSxNQUNsQkMsY0FBY0osT0FBT0k7QUFBQUEsTUFDckJDLGFBQWFMLE9BQU9LO0FBQUFBLE1BQ3BCQyxXQUFXTixPQUFPTztBQUFBQSxJQUN0QjtBQUNBbEssd0JBQW9CNEosUUFBUTtBQUM1QjFKLDhCQUEwQixJQUFJO0FBRTlCaUssMkJBQXVCUixPQUFPdkIsR0FBRztBQUdqQzFILHNCQUFrQixDQUFDMEosU0FBU0EsT0FBTyxDQUFDO0FBR3BDQyxlQUFXLE1BQU07QUFDYixZQUFNQyxtQkFBbUJkLFNBQVNlLGVBQWUsb0JBQW9CO0FBQ3JFLFVBQUlELGtCQUFrQjtBQUNsQkEseUJBQWlCRSxlQUFlLEVBQUVDLFVBQVUsVUFBVUMsT0FBTyxRQUFRLENBQUM7QUFBQSxNQUMxRTtBQUFBLElBQ0osR0FBRyxHQUFHO0FBQUEsRUFDVjtBQUdBLFFBQU1QLHlCQUF5QixPQUFPUSxXQUFXO0FBQzdDLFFBQUksQ0FBQ0EsUUFBUTtBQUNUdkwsNkJBQXVCLEVBQUU7QUFDekJFLG1CQUFhLEVBQUU7QUFDZkUsa0JBQVksRUFBRTtBQUNkVSxnQ0FBMEIsSUFBSTtBQUU5QjtBQUFBLElBQ0o7QUFFQVIsMEJBQXNCLElBQUk7QUFDMUJFLG9CQUFnQixJQUFJO0FBQ3BCRSxvQkFBZ0IsSUFBSTtBQUVwQixRQUFJO0FBQ0EsWUFBTSxDQUFDOEssY0FBY0MsYUFBYUMsVUFBVSxJQUN4QyxNQUFNQyxRQUFRQztBQUFBQSxRQUFXO0FBQUEsVUFDckJwTixJQUFJcU4sS0FBSyxtQ0FBbUNOLE1BQU0sRUFBRTtBQUFBLFVBQ3BEL00sSUFBSTJLLElBQUksdUJBQXVCb0MsTUFBTSxFQUFFO0FBQUEsVUFDdkMvTSxJQUFJMkssSUFBSSxzQkFBc0JvQyxNQUFNLEVBQUU7QUFBQSxRQUFDO0FBQUEsTUFDMUM7QUFLTCxVQUFJQyxhQUFhNUIsV0FBVyxhQUFhO0FBQ3JDLGNBQU1rQyxhQUFhTixhQUFhTyxPQUFPM0MsUUFBUTtBQUcvQyxjQUFNNEMsV0FBVztBQUFBLFVBQ2IsR0FBRyxJQUFJQztBQUFBQSxZQUNISCxXQUNLSSxJQUFJLENBQUNDLFNBQVNBLE1BQU1DLFlBQVlDLE9BQU9yRCxHQUFHLEVBQzFDc0QsT0FBT0MsT0FBTztBQUFBLFVBQ3ZCO0FBQUEsUUFBQztBQUlMLGNBQU1DLHFCQUFxQixNQUFNYixRQUFRQztBQUFBQSxVQUNyQ0ksU0FBU0U7QUFBQUEsWUFBSSxDQUFDTyxZQUNWak8sSUFBSTJLLElBQUksNEJBQTRCc0QsT0FBTyxFQUFFO0FBQUEsVUFDakQ7QUFBQSxRQUNKO0FBR0EsY0FBTUMscUJBQXFCWixXQUFXSSxJQUFJLENBQUNDLFNBQVM7QUFDaEQsZ0JBQU1NLFVBQVVOLE1BQU1DLFlBQVlDLE9BQU9yRDtBQUV6QyxnQkFBTTJELGNBQWNYLFNBQVNZLFFBQVFILE9BQU87QUFDNUMsZ0JBQU1JLG9CQUNGTCxtQkFBbUJHLFdBQVc7QUFFbEMsY0FBSUcsb0JBQW9CO0FBRXhCLGNBQUlELG1CQUFtQmpELFdBQVcsYUFBYTtBQUMzQyxrQkFBTW1ELGVBQ0ZGLGtCQUFrQmQsT0FBTzNDO0FBRTdCLGtCQUFNNEQsbUJBQW1CQyxNQUFNQyxRQUFRSCxZQUFZLElBQzdDQSxlQUNBQSxjQUFjM0QsUUFBUTtBQUc1QjBELGdDQUFvQkUsaUJBQWlCRztBQUFBQSxjQUNqQyxDQUFDZixlQUFlO0FBQ1osc0JBQU1nQixtQkFDRmhCLFlBQVloSyxTQUFTNEcsT0FDckJvRCxZQUFZaEs7QUFFaEIsdUJBQ0lpTCxPQUFPRCxnQkFBZ0IsTUFDdkJDLE9BQU85QixNQUFNO0FBQUEsY0FFckI7QUFBQSxZQUNKO0FBQUEsVUFDSjtBQUVBLGlCQUFPO0FBQUEsWUFDSCxHQUFHWTtBQUFBQTtBQUFBQSxZQUdIbUIsY0FDSVIsbUJBQW1COUQsT0FBTztBQUFBO0FBQUEsWUFHOUI4RCxtQkFDSUEscUJBQXFCO0FBQUEsVUFDN0I7QUFBQSxRQUNKLENBQUM7QUFDRDlNLCtCQUF1QjBNLGtCQUFrQjtBQUFBLE1BQzdDLE9BQU87QUFDSHBELGdCQUFRRDtBQUFBQSxVQUNKO0FBQUEsVUFDQW1DLGFBQWErQjtBQUFBQSxRQUNqQjtBQUVBdk4sK0JBQXVCLEVBQUU7QUFBQSxNQUM3QjtBQUtBLFVBQUl5TCxZQUFZN0IsV0FBVyxhQUFhO0FBQ3BDLGNBQU00RCxVQUNGL0IsWUFBWU0sTUFBTTNDLE1BQU1xRSxpQkFDeEJoQyxZQUFZTSxPQUFPMEIsaUJBQ25CO0FBRUosY0FBTUMsbUJBQW1CRixRQUFRdEIsSUFBSSxDQUFDQyxTQUFTO0FBQzNDLGdCQUFNd0IsUUFDRnhCLEtBQUt5QixlQUFlRCxTQUFTLENBQUM7QUFFbEMsaUJBQU87QUFBQSxZQUNILEdBQUd4QjtBQUFBQSxZQUVIbkQsS0FBSzJFLE1BQU0zRTtBQUFBQSxZQUVYYSxnQkFDSThELE1BQU05RCxrQkFBa0I7QUFBQTtBQUFBLFlBRzVCZ0UsaUJBQ0lGLE1BQU1FO0FBQUFBLFlBRVZDLGdCQUNJSCxNQUFNRztBQUFBQSxZQUVWQyxVQUNJSixNQUFNSTtBQUFBQSxZQUVWQyxZQUNJTCxNQUFNSztBQUFBQSxZQUVWQyxVQUNJTixNQUFNTTtBQUFBQSxZQUVWQyxtQkFDSVAsTUFBTU87QUFBQUEsVUFDZDtBQUFBLFFBQ0osQ0FBQztBQUVEaE8scUJBQWF3TixnQkFBZ0I7QUFBQSxNQUNqQyxPQUFPO0FBQ0hwRSxnQkFBUTZFO0FBQUFBLFVBQ0o7QUFBQSxVQUNBMUMsWUFBWThCO0FBQUFBLFFBQ2hCO0FBRUFyTixxQkFBYSxFQUFFO0FBQUEsTUFDbkI7QUFLQSxVQUFJd0wsV0FBVzlCLFdBQVcsYUFBYTtBQUNuQyxjQUFNd0UsUUFDRjFDLFdBQVdLLE1BQU0zQyxNQUFNaUYsZ0JBQWdCO0FBRTNDak8sb0JBQVlnTyxLQUFLO0FBQUEsTUFDckIsT0FBTztBQUNIOUUsZ0JBQVFEO0FBQUFBLFVBQ0o7QUFBQSxVQUNBcUMsV0FBVzZCO0FBQUFBLFFBQ2Y7QUFFQW5OLG9CQUFZLEVBQUU7QUFBQSxNQUNsQjtBQUFBLElBQ0osU0FBU2lKLE9BQU87QUFDWkMsY0FBUUQ7QUFBQUEsUUFDSjtBQUFBLFFBQ0FBO0FBQUFBLE1BQ0o7QUFFQXJKLDZCQUF1QixFQUFFO0FBQ3pCRSxtQkFBYSxFQUFFO0FBQ2ZFLGtCQUFZLEVBQUU7QUFBQSxJQUNsQixVQUFDO0FBQ0dFLDRCQUFzQixLQUFLO0FBQzNCRSxzQkFBZ0IsS0FBSztBQUNyQkUsc0JBQWdCLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQ0o7QUFFQSxRQUFNNE4sZ0NBQWdDQSxNQUFNO0FBQ3hDLFVBQU0xRSxTQUNGL0ksd0JBQXdCdUwsWUFBWW1DLG1CQUNwQzFOLHdCQUF3QjBOLG1CQUN4QjFOLHdCQUF3QmlNLG1CQUFtQnlCLG1CQUMzQztBQUVKLFVBQU1DLG1CQUFtQjVFLE9BQU82RSxLQUFLLEVBQUVDLFlBQVk7QUFFbkQsUUFBSSxDQUFDLFdBQVcsVUFBVSxFQUFFQyxTQUFTSCxnQkFBZ0IsR0FBRztBQUNwRGhULGNBQVFvVDtBQUFBQSxRQUNKLGVBQWVoRixNQUFNO0FBQUEsTUFDekI7QUFFQSxhQUFPO0FBQUEsSUFDWDtBQUVBLFdBQU87QUFBQSxFQUNYO0FBRUEsUUFBTWlGLDZCQUE2QixPQUFPQyxZQUFZO0FBQ2xELFFBQUksQ0FBQ0EsU0FBUztBQUNWdFQsY0FBUTZOLE1BQU0sa0JBQWtCO0FBQ2hDO0FBQUEsSUFDSjtBQUNBMUQsNkJBQXlCLElBQUk7QUFDN0IsUUFBSTtBQUNBLFlBQU1uSCxJQUFJdVEsTUFBTSwyQkFBMkJELE9BQU8sSUFBSTtBQUFBLFFBQ2xEakYsZ0JBQWdCO0FBQUEsTUFDcEIsQ0FBQztBQUNEM0o7QUFBQUEsUUFBYSxDQUFBOEssU0FDVEEsS0FBS2tCO0FBQUFBLFVBQUksQ0FBQThDLE1BQ0xBLEVBQUVoRyxRQUFROEYsVUFBVSxFQUFFLEdBQUdFLEdBQUduRixnQkFBZ0IsWUFBWSxJQUFJbUY7QUFBQUEsUUFDaEU7QUFBQSxNQUNKO0FBQ0EsWUFBTUMsZUFBZXRPLGtCQUFrQjhKLGFBQWE7QUFDcEQsWUFBTXJDLFNBQVNuSSxVQUFVa04sS0FBSyxDQUFBNkIsTUFBS0EsRUFBRWhHLFFBQVE4RixPQUFPLEdBQUdJLDBCQUEwQjtBQUNqRnRTLG1CQUFha04sUUFBUTtBQUFBLFFBQ2pCdE8sU0FBUztBQUFBLFFBQ1R1TyxhQUFhLEdBQUdrRixZQUFZLHdDQUF3QzdHLE1BQU07QUFBQSxRQUMxRTRCLFdBQVc7QUFBQSxNQUNmLENBQUM7QUFBQSxJQUNMLFNBQVNYLE9BQU87QUFDWkMsY0FBUUQsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdEQ3TixjQUFRNk4sTUFBTSxrQ0FBa0M7QUFBQSxJQUNwRCxVQUFDO0FBQ0cxRCwrQkFBeUIsS0FBSztBQUFBLElBQ2xDO0FBQUEsRUFDSjtBQUdBLFFBQU13SixvQkFBb0IsT0FBT0wsWUFBWTtBQUN6QyxRQUFJO0FBQ0EsWUFBTU0sV0FBVyxNQUFNNVEsSUFBSTJLLElBQUksb0JBQW9CMkYsT0FBTyxFQUFFO0FBQzVELFVBQUlNLFNBQVNoRyxLQUFLVSxTQUFTO0FBQ3ZCLGVBQU9zRixTQUFTaEcsS0FBS0E7QUFBQUEsTUFDekIsT0FBTztBQUNILGNBQU0sSUFBSWlHLE1BQU0sNEJBQTRCO0FBQUEsTUFDaEQ7QUFBQSxJQUNKLFNBQVNoRyxPQUFPO0FBQ1pDLGNBQVFELE1BQU0saUNBQWlDQSxLQUFLO0FBQ3BEN04sY0FBUTZOLE1BQU0sOEJBQThCO0FBQzVDLGFBQU87QUFBQSxJQUNYO0FBQUEsRUFDSjtBQUVBLFFBQU1pRywwQkFBMEIsT0FBT1IsWUFBWTtBQUMvQyxVQUFNUyxVQUFVLE1BQU1KLGtCQUFrQkwsT0FBTztBQUMvQyxRQUFJUyxTQUFTO0FBQ1RsSyxzQkFBZ0JrSyxPQUFPO0FBQ3ZCOUosMEJBQW9COEosUUFBUUMsc0JBQXNCQyxTQUFTLEtBQUssRUFBRTtBQUNsRWxLLHdCQUFrQixLQUFLO0FBQ3ZCSiwyQkFBcUIsSUFBSTtBQUFBLElBQzdCO0FBQUEsRUFDSjtBQUVBLFFBQU11SyxvQkFBb0IsWUFBWTtBQUNsQyxVQUFNQyxZQUFZLENBQUM7QUFDbkIsUUFBSSxDQUFDbkssa0JBQWtCO0FBQ25CbUssZ0JBQVVuSyxtQkFBbUI7QUFBQSxJQUNqQztBQUNBdEUsY0FBVXlPLFNBQVM7QUFDbkIsUUFBSUMsT0FBT0MsS0FBS0YsU0FBUyxFQUFFRyxTQUFTLEVBQUc7QUFFdkMsUUFBSSxDQUFDMUssYUFBYztBQUNuQixRQUFJO0FBQ0EsWUFBTWdLLFdBQVcsTUFBTTVRLElBQUl1UixJQUFJLGlDQUFpQzNLLGFBQWE0RCxHQUFHLElBQUk7QUFBQSxRQUNoRndHLHNCQUFzQmhLO0FBQUFBLE1BQzFCLENBQUM7QUFDRCxVQUFJNEosU0FBU2hHLEtBQUtRLFFBQVE7QUFDdEJ2RSx3QkFBZ0IsQ0FBQzJGLFVBQVUsRUFBRSxHQUFHQSxNQUFNLEdBQUdvRSxTQUFTaEcsS0FBS0EsS0FBSyxFQUFFO0FBQzlEN0QsMEJBQWtCLElBQUk7QUFDdEIvSixnQkFBUXNPLFFBQVEsMEJBQTBCO0FBQUEsTUFDOUMsT0FBTztBQUNILGNBQU0sSUFBSXVGLE1BQU0sb0JBQW9CO0FBQUEsTUFDeEM7QUFBQSxJQUNKLFNBQVNoRyxPQUFPO0FBQ1pDLGNBQVFELE1BQU0saUNBQWlDQSxLQUFLO0FBQ3BEN04sY0FBUTZOLE1BQU1BLE1BQU0rRixVQUFVaEcsTUFBTTVOLFdBQVcscUJBQXFCO0FBQUEsSUFDeEU7QUFBQSxFQUNKO0FBQ0EsUUFBTXdVLGlCQUFpQixZQUFZO0FBQy9CLFVBQU1DLFFBQVFuSCxLQUFLQyxNQUFNSixhQUFhQyxRQUFRLE1BQU0sS0FBSyxJQUFJO0FBQzdELFFBQUksQ0FBQ3hELGFBQWM7QUFDbkIsUUFBSTtBQUNBbUIseUJBQW1CLElBQUk7QUFDdkIsWUFBTTJKLFVBQVU7QUFBQSxRQUNaQyxlQUFlO0FBQUEsUUFDZkMsWUFBWWhMLGFBQWFpTDtBQUFBQSxRQUN6QmpLLFNBQVM2SixNQUFNakg7QUFBQUEsTUFDbkI7QUFDQSxZQUFNeEssSUFBSXFOLEtBQUssb0JBQW9CekcsYUFBYTRELEdBQUcsV0FBVzVDLE9BQU8sV0FBVzhKLE9BQU87QUFDdkYxVSxjQUFRc08sUUFBUSx5Q0FBeUM7QUFDekQzRSwyQkFBcUIsS0FBSztBQUMxQkUsc0JBQWdCLElBQUk7QUFDcEJFLHdCQUFrQixLQUFLO0FBRXZCLFVBQUk1RSxrQkFBa0JxSSxLQUFLO0FBQ3ZCK0IsK0JBQXVCcEssaUJBQWlCcUksR0FBRztBQUFBLE1BQy9DO0FBQUEsSUFDSixTQUFTSyxPQUFPO0FBQ1pDLGNBQVFELE1BQU0seUJBQXlCQSxLQUFLO0FBQzVDN04sY0FBUTZOLE1BQU1BLE1BQU0rRixVQUFVaEcsTUFBTTVOLFdBQVcsK0JBQStCO0FBQUEsSUFDbEYsVUFBQztBQUNHK0sseUJBQW1CLEtBQUs7QUFBQSxJQUM1QjtBQUFBLEVBQ0o7QUFFQSxRQUFNK0osb0JBQW9CQSxDQUFDQyxZQUFZQyxnQkFBZ0I7QUFDbkRwSixxQkFBaUIsSUFBSTtBQUVyQixRQUFJLENBQUNyRyxrQkFBa0I7QUFDbkJDLDBCQUFvQnVQLFVBQVU7QUFBQSxJQUNsQztBQUVBLFVBQU0sRUFBRW5FLFdBQVcsSUFBSW9FLGVBQWUsQ0FBQztBQUN2QyxVQUFNbEQsZUFBZWtELGFBQWFsRDtBQUNsQyxVQUFNUixvQkFBb0IwRCxhQUFhMUQ7QUFFdkMsUUFBSSxDQUFDUSxjQUFjO0FBQ2Y5UixjQUFRNk4sTUFBTSxvRUFBb0U7QUFDbEZqQyx1QkFBaUIsS0FBSztBQUN0QjtBQUFBLElBQ0o7QUFFQXBFLHdCQUFvQnNLLFlBQVk7QUFDaENwSyxzQkFBa0I0SixxQkFBcUJWLFVBQVU7QUFDakRuSTtBQUFBQSxNQUNJNkksbUJBQW1CMUssU0FBUzRHLE9BQzVCb0QsWUFBWWhLLFNBQVM0RyxPQUNyQnJJLGtCQUFrQnFJO0FBQUFBLElBQ3RCO0FBQ0FsSSw4QkFBMEIwUCxXQUFXO0FBRXJDLFFBQUlELFdBQVc1QixTQUFTLE1BQU0sR0FBRztBQUM3QmhQLHFCQUFlOFEsZUFBZTtBQUFBLFFBQzFCdE8sVUFBVTJLLG1CQUFtQjNLLFVBQVU2RyxPQUFPb0QsWUFBWUMsT0FBT3JEO0FBQUFBLFFBQ2pFMEgsUUFBUTVELG1CQUFtQjZELFdBQVd2RSxZQUFZdUU7QUFBQUEsUUFDbER2TyxTQUFTMEssbUJBQW1CMUssU0FBUzRHLE9BQU9vRCxZQUFZaEssU0FBUzRHO0FBQUFBLFFBQ2pFWixRQUFRO0FBQUEsUUFDUm1GLFFBQVE7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNMLFdBQVdnRCxXQUFXNUIsU0FBUyxPQUFPLEtBQUtoTyxrQkFBa0I7QUFDekRoQixxQkFBZThRLGVBQWU7QUFBQSxRQUMxQnJPLFNBQVN6QixpQkFBaUJxSTtBQUFBQSxRQUMxQlosUUFBUTtBQUFBLFFBQ1JtRixRQUFRO0FBQUEsTUFDWixDQUFDO0FBQUEsSUFDTDtBQUVBdEMsZUFBVyxNQUFNO0FBQ2JiLGVBQVNlLGVBQWUscUJBQXFCLEdBQUdDLGVBQWU7QUFBQSxRQUMzREMsVUFBVTtBQUFBLE1BQ2QsQ0FBQztBQUNEakUsdUJBQWlCLEtBQUs7QUFBQSxJQUMxQixHQUFHLEdBQUc7QUFBQSxFQUNWO0FBRUEsUUFBTXdKLHlCQUF5QixPQUFPQyxXQUFXO0FBQzdDLFFBQUk7QUFDQXZSLCtCQUF5QixJQUFJO0FBQzdCLFlBQU00USxVQUFVLEVBQUUsR0FBR1csUUFBUUMsY0FBYy9QLG9CQUFvQnhCLG1CQUFtQndSLFFBQVFoUSxpQkFBaUI7QUFDM0csWUFBTXZDLElBQUlxTixLQUFLLGdDQUFnQ3FFLE9BQU87QUFDdEQxVSxjQUFRc08sUUFBUSxnQ0FBZ0M7QUFDaERwSywrQkFBeUIsS0FBSztBQUM5QkMscUJBQWVxUixZQUFZO0FBQzNCaFEsMEJBQW9CLElBQUk7QUFDeEJKLDBCQUFvQixJQUFJO0FBQ3hCWiw2QkFBdUIsRUFBRTtBQUN6QkUsbUJBQWEsRUFBRTtBQUFBLElBQ25CLFNBQVNtSixPQUFPO0FBQ1o3TixjQUFRNk4sTUFBTSwwQkFBMEI7QUFBQSxJQUM1QyxVQUFDO0FBQ0cvSiwrQkFBeUIsS0FBSztBQUFBLElBQ2xDO0FBQUEsRUFDSjtBQUdBbUosWUFBVSxNQUFNO0FBQ1osVUFBTXdJLG1CQUFtQixZQUFZO0FBQ2pDLFVBQUk7QUFDQSxjQUFNL0gsTUFBTSxNQUFNMUssSUFBSTJLLElBQUksb0JBQW9CO0FBQzlDckc7QUFBQUEsV0FDS29HLElBQUlFLFFBQVEsSUFBSWtEO0FBQUFBLFlBQ2IsQ0FBQ0gsU0FBU0EsS0FBS2hLLFlBQVksUUFBUWdLLEtBQUsvSixXQUFXLFFBQVErSixLQUFLd0UsV0FBVztBQUFBLFVBQy9FO0FBQUEsUUFDSjtBQUFBLE1BQ0osU0FBU3RILE9BQU87QUFDWkMsZ0JBQVFELE1BQU0sK0JBQStCQSxLQUFLO0FBQUEsTUFDdEQ7QUFBQSxJQUNKO0FBQ0E0SCxxQkFBaUI7QUFBQSxFQUNyQixHQUFHLEVBQUU7QUFFTHhJLFlBQVUsTUFBTTtBQUNaLFVBQU15SSxtQkFBbUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0EsY0FBTSxDQUFDQyxVQUFVQyxPQUFPLElBQUksTUFBTXpGLFFBQVEwRjtBQUFBQSxVQUFJO0FBQUEsWUFDMUM3UyxJQUFJMkssSUFBSSx3QkFBd0I7QUFBQSxZQUNoQzNLLElBQUkySyxJQUFJLGVBQWU7QUFBQSxVQUFDO0FBQUEsUUFDM0I7QUFDRHZILGtCQUFVdVAsU0FBUy9ILFFBQVEsRUFBRTtBQUM3QnRKLGlCQUFTc1IsUUFBUWhJLE1BQU1BLFFBQVEsRUFBRTtBQUFBLE1BQ3JDLFNBQVNDLE9BQU87QUFDWkMsZ0JBQVFELE1BQU0sK0JBQStCQSxLQUFLO0FBQUEsTUFDdEQ7QUFBQSxJQUNKO0FBQ0E2SCxxQkFBaUI7QUFBQSxFQUNyQixHQUFHLEVBQUU7QUFFTHpJLFlBQVUsTUFBTTtBQUNaLFFBQUkxRixpQkFBa0J1TyxrQkFBaUI7QUFBQTtBQUNsQ25PLHFCQUFlLElBQUk7QUFBQSxFQUM1QixHQUFHLENBQUNKLGdCQUFnQixDQUFDO0FBRXJCMEYsWUFBVSxNQUFNO0FBQ1osVUFBTThJLG9CQUFvQixZQUFZO0FBQ2xDN1AsbUJBQWEsSUFBSTtBQUNqQixVQUFJO0FBQ0EsY0FBTThQLFNBQVMsQ0FBQztBQUNoQixZQUFJdlAsUUFBUUUsU0FBVXFQLFFBQU9yUCxXQUFXRixRQUFRRTtBQUNoRCxZQUFJRixRQUFRRyxRQUFTb1AsUUFBT3BQLFVBQVVILFFBQVFHO0FBQzlDLFlBQUlILFFBQVFJLFVBQVdtUCxRQUFPblAsWUFBWUosUUFBUUk7QUFDbEQsWUFBSUosUUFBUUssUUFBU2tQLFFBQU9sUCxVQUFVTCxRQUFRSztBQUM5QyxjQUFNOE0sV0FBVyxNQUFNNVEsSUFBSTJLLElBQUksa0NBQWtDLEVBQUVxSSxPQUFPLENBQUM7QUFDM0UsWUFBSXBDLFNBQVNoRyxNQUFNQSxNQUFNO0FBQ3JCM0MsNkJBQW1CMkksU0FBU2hHLEtBQUtBLFFBQVEsRUFBRTtBQUMzQyxnQkFBTXFJLGdCQUFnQnJDLFNBQVNoRyxLQUFLQSxLQUFLOEMsSUFBSSxDQUFDQyxNQUFNdUYsVUFBVTtBQUUxRCxrQkFBTUMsaUJBQWlCQSxDQUFDNUYsVUFDcEJBLFNBQVMsUUFBUSxDQUFDL0QsTUFBTStELEtBQUssSUFDdkIsSUFBSXZDLE9BQU91QyxLQUFLLEVBQUU2RixlQUFlLE9BQU8sQ0FBQyxLQUN6QztBQUNWLGtCQUFNQyxpQkFBaUIxRixNQUFNMkYsbUJBQW1CM0YsTUFBTTRGLGtCQUFrQjtBQUV4RSxnQkFBSUMsYUFBYTtBQUNqQixnQkFBSTdGLEtBQUs4RixjQUFjLFFBQVE5RixLQUFLOEYsZUFBZSxHQUFHO0FBRWxERCwyQkFBYSx1QkFBQyxVQUFLLFdBQVUsZ0JBQWdCTCx5QkFBZXhGLEtBQUs4RixVQUFVLEtBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdFO0FBQUEsWUFDakYsV0FBVzlGLEtBQUs4QixZQUFZMkIsT0FBT0MsS0FBSzFELEtBQUs4QixRQUFRLEVBQUU2QixTQUFTLEdBQUc7QUFFL0Qsb0JBQU1vQyxlQUFlL0YsS0FBSzhCLFVBQVVrRSxpQkFBaUI7QUFDckQsb0JBQU1DLE9BQU9GLGVBQWUsTUFBTTtBQUNsQyxvQkFBTUcsYUFBYUgsZUFBZSxpQkFBaUI7QUFDbkRGLDJCQUNJLHVCQUFDLFVBQUssV0FBV0ssWUFDWkQ7QUFBQUE7QUFBQUEsZ0JBQUs7QUFBQSxnQkFBRVQsZUFBZUUsY0FBYztBQUFBLG1CQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsWUFFUixXQUFXQSxtQkFBbUIsR0FBRztBQUM3QkcsMkJBQWEsdUJBQUMsVUFBSyxXQUFVLGtCQUFrQkwseUJBQWVFLGNBQWMsS0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUU7QUFBQSxZQUNsRjtBQUVBLG1CQUFPO0FBQUEsY0FDSFMsSUFBSVosUUFBUTtBQUFBLGNBQ1phLE1BQU1wRyxLQUFLcUcsbUJBQW1CMVUsTUFBTXFPLEtBQUtxRyxnQkFBZ0IsRUFBRUMsT0FBTyxZQUFZLElBQUk7QUFBQSxjQUNsRkMsV0FBV3ZHLEtBQUt3RyxXQUFXdlEsU0FBU3FJLGFBQWEwQixNQUFNOEIsVUFBVXpELFVBQVVDLGFBQWE7QUFBQSxjQUN4Rm1JLFlBQVl6RyxLQUFLd0csV0FBV3hRLFVBQVV5USxjQUFjekcsTUFBTThCLFVBQVVBLFlBQVk7QUFBQSxjQUNoRnlDLFFBQVF2RSxLQUFLd0csV0FBV2hDLFdBQVd4RSxNQUFNOEIsVUFBVWtFLGdCQUFnQjtBQUFBLGNBQ25FL0osUUFBUXVKLGVBQWV4RixLQUFLL0QsTUFBTTtBQUFBLGNBQ2xDeUssY0FBY2xCLGVBQWV4RixLQUFLMEcsWUFBWTtBQUFBLGNBQzlDWixZQUFZRDtBQUFBQSxjQUNaYyxnQkFBZ0JuQixlQUFleEYsS0FBSzJHLGNBQWM7QUFBQSxjQUNsRHZGLFFBQVFwQixLQUFLb0IsVUFBVTtBQUFBLGNBQ3ZCL0YsTUFDSSx1QkFBQyxPQUFJLE9BQU8yRSxLQUFLNEcscUJBQXFCLFdBQVcsVUFBVSxVQUN0RDVHLGVBQUs0RyxrQkFBa0JDLFlBQVksS0FBSyxTQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFSi9DLE9BQU85RCxLQUFLOEcsVUFBVXZJLFFBQVE7QUFBQSxZQUNsQztBQUFBLFVBQ0osQ0FBQztBQUNEbEosMEJBQWdCaVEsYUFBYTtBQUM3QjNQLHNCQUFZO0FBQUEsWUFDUkMsWUFBWTBQLGNBQWMzQjtBQUFBQSxZQUMxQjlOLGFBQWFvTixTQUFTaEcsS0FBS0EsS0FBSzhKLE9BQU8sQ0FBQ0MsS0FBS0MsU0FBU0QsT0FBT0MsS0FBS2hMLFVBQVUsSUFBSSxDQUFDO0FBQUEsVUFDckYsQ0FBQztBQUFBLFFBQ0wsT0FBTztBQUNINUcsMEJBQWdCLEVBQUU7QUFBQSxRQUN0QjtBQUFBLE1BQ0osU0FBUzZILE9BQU87QUFDWkMsZ0JBQVFELE1BQU0sZ0NBQWdDQSxLQUFLO0FBQ25EN0gsd0JBQWdCLEVBQUU7QUFBQSxNQUN0QixVQUFDO0FBQ0dFLHFCQUFhLEtBQUs7QUFBQSxNQUN0QjtBQUFBLElBQ0o7QUFDQTZQLHNCQUFrQjtBQUFBLEVBQ3RCLEdBQUcsQ0FBQ3RQLFNBQVNkLGFBQWEsQ0FBQztBQUUzQixRQUFNa1MsUUFBUXRZLFFBQVEsTUFBTTtBQUN4QixRQUFJLENBQUN5TCxnQkFBZ0JzSixPQUFRLFFBQU87QUFFcEMsVUFBTXdELGFBQWE5TSxnQkFBZ0I4RjtBQUFBQSxNQUMvQixDQUFBaUgsTUFBS0EsRUFBRWhHLFVBQVVnRyxFQUFFaEcsT0FBT21CLFlBQVksRUFBRUMsU0FBUyxRQUFRO0FBQUEsSUFDN0Q7QUFDQSxVQUFNNkUsUUFBUWhOLGdCQUFnQjhGLE9BQU8sQ0FBQWlILE1BQUtBLEVBQUV0RixRQUFRO0FBQ3BELFVBQU13RixPQUFPak4sZ0JBQWdCOEYsT0FBTyxDQUFBaUgsTUFBS0EsRUFBRUcsT0FBTztBQUdsRCxVQUFNQyxZQUFZQSxDQUFDQyxRQUFRQSxJQUFJVixPQUFPLENBQUNXLEdBQUdOLE1BQU1NLEtBQUtOLEVBQUVuTCxVQUFVLElBQUksQ0FBQztBQUV0RSxXQUFPO0FBQUEsTUFDSGtMLFlBQVksRUFBRVEsT0FBT1IsV0FBV3hELFFBQVExSCxRQUFRdUwsVUFBVUwsVUFBVSxFQUFFO0FBQUEsTUFDdEVFLE9BQU8sRUFBRU0sT0FBT04sTUFBTTFELFFBQVExSCxRQUFRdUwsVUFBVUgsS0FBSyxFQUFFO0FBQUEsTUFDdkRDLE1BQU0sRUFBRUssT0FBT0wsS0FBSzNELFFBQVExSCxRQUFRdUwsVUFBVUYsSUFBSSxFQUFFO0FBQUEsTUFDcERNLE9BQU87QUFBQSxRQUNIRCxPQUFPdE4sZ0JBQWdCc0o7QUFBQUEsUUFDdkIxSCxRQUFRNUIsZ0JBQWdCME0sT0FBTyxDQUFDVyxHQUFHTixNQUFNTSxLQUFLTixFQUFFbkwsVUFBVSxJQUFJLENBQUM7QUFBQSxNQUNuRTtBQUFBLElBQ0o7QUFBQSxFQUNKLEdBQUcsQ0FBQzVCLGVBQWUsQ0FBQztBQUVwQixRQUFNd04sb0JBQW9CQSxDQUFDQyxVQUFVO0FBQ2pDL1IsZUFBVyxDQUFDOEksVUFBVTtBQUFBLE1BQ2xCLEdBQUdBO0FBQUFBLE1BQ0gzSSxXQUFXNFIsUUFBUUEsTUFBTSxDQUFDLEVBQUV4QixPQUFPLFlBQVksSUFBSTtBQUFBLE1BQ25EblEsU0FBUzJSLFFBQVFBLE1BQU0sQ0FBQyxFQUFFeEIsT0FBTyxZQUFZLElBQUk7QUFBQSxJQUNyRCxFQUFFO0FBQUEsRUFDTjtBQUVBLFFBQU15QixlQUFlQSxDQUFDbkksVUFBVTtBQUM1QixVQUFNb0ksU0FBU3RSLFlBQVlzSyxLQUFLLENBQUNpSCxNQUFNQSxFQUFFcEwsUUFBUStDLEtBQUs7QUFDdEQvSSx3QkFBb0IrSSxLQUFLO0FBQ3pCN0ksc0JBQWtCaVIsTUFBTTtBQUN4QmxRLHNCQUFrQmtRLFFBQVEvUixTQUFTNEcsR0FBRztBQUN0QzdGLG1CQUFlLElBQUk7QUFBQSxFQUN2QjtBQUVBLFFBQU1tTyxtQkFBbUIsWUFBWTtBQUNqQyxRQUFJLENBQUN2TyxpQkFBa0I7QUFDdkIsUUFBSTtBQUNBTSxpQkFBVyxJQUFJO0FBQ2YsWUFBTTZGLE1BQU0sTUFBTTFLLElBQUkySyxJQUFJLHFCQUFxQnBHLGdCQUFnQixpQkFBaUI7QUFDaEZJLHFCQUFlK0YsSUFBSUUsTUFBTUEsTUFBTWlMLGdCQUFnQixDQUFDO0FBQUEsSUFDcEQsU0FBU2hMLE9BQU87QUFDWjdOLGNBQVE2TixNQUFNLDhCQUE4QjtBQUFBLElBQ2hELFVBQUM7QUFDR2hHLGlCQUFXLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFFQSxRQUFNaVIsb0JBQW9CQSxNQUFNO0FBQzVCLFFBQUksQ0FBQ3ZSLG9CQUFvQixDQUFDZixhQUFhO0FBQ25DeEcsY0FBUW9ULFFBQVEsK0NBQStDO0FBQy9EO0FBQUEsSUFDSjtBQUNBLFVBQU0yRixjQUFjalIsZUFBZSxVQUFVRSxlQUFlRjtBQUM1RCxRQUFJLENBQUNpUixlQUFlLENBQUNBLFlBQVk5RixLQUFLLEdBQUc7QUFDckNqVCxjQUFRb1QsUUFBUSwrQkFBK0I7QUFDL0M7QUFBQSxJQUNKO0FBQ0FqTCxrQkFBYzRRLFdBQVc7QUFDekIzUixZQUFRLENBQUM7QUFBQSxFQUNiO0FBRUEsUUFBTTRSLG1CQUFtQixZQUFZO0FBQ2pDLFVBQU10RSxVQUFVO0FBQUEsTUFDWjNFLFFBQVF2SDtBQUFBQSxNQUNSbU0sZUFBZXNFLG9CQUFvQjFULGdCQUFnQixNQUFNLFVBQVUsZ0JBQWdCMkM7QUFBQUEsTUFDbkZvQyxhQUFhQSxjQUFjQSxZQUFZMk0sT0FBTyxZQUFZLElBQUk7QUFBQSxNQUM5RHJDLFlBQVl0TDtBQUFBQSxNQUNaRjtBQUFBQSxNQUNBSTtBQUFBQSxNQUNBMFAsYUFBYTFTO0FBQUFBLE1BQ2I4RSxlQUFlRixrQkFBa0JFO0FBQUFBLE1BQ2pDQyxZQUFZSCxrQkFBa0JHO0FBQUFBLE1BQzlCQyxVQUFVSixrQkFBa0JJO0FBQUFBLElBQ2hDO0FBRUEsUUFBSTtBQUNBM0QsaUJBQVcsSUFBSTtBQUNmLFlBQU03RSxJQUFJcU4sS0FBSyxxQkFBcUI5SSxnQkFBZ0IsV0FBV3FELE9BQU8sV0FBVzhKLE9BQU87QUFDeEYxVSxjQUFRc08sUUFBUSxpQ0FBaUM7QUFDakQvRix5QkFBbUIvQixXQUFXO0FBQzlCNkIsc0JBQWdCLEVBQUU7QUFDbEJqQixjQUFRLENBQUM7QUFBQSxJQUNiLFNBQVN5RyxPQUFPO0FBQ1o3TixjQUFRNk4sTUFBTSx5QkFBeUI7QUFBQSxJQUMzQyxVQUFDO0FBQ0doRyxpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBRUEsUUFBTXNSLGtCQUFrQkEsQ0FBQ0MsUUFBUTtBQUM3QnpRLG9CQUFnQnlRLEdBQUc7QUFFbkIsUUFBSUEsUUFBUSx1QkFBdUI7QUFDL0J4VCx1QkFBaUIsQ0FBQzRKLFNBQVNBLE9BQU8sQ0FBQztBQUFBLElBQ3ZDO0FBQUEsRUFDSjtBQUVBLFFBQU02Six1QkFBdUIsWUFBWTtBQUNyQyxRQUFJLENBQUM5UixrQkFBa0I7QUFDbkJ2SCxjQUFRb1QsUUFBUSxnQ0FBZ0M7QUFDaEQ7QUFBQSxJQUNKO0FBQ0EsUUFBSTtBQUNBdkwsaUJBQVcsSUFBSTtBQUNmb0Isd0JBQWtCLElBQUk7QUFDdEIsWUFBTXlFLE1BQU0sTUFBTTFLLElBQUkySyxJQUFJLHFCQUFxQnBHLGdCQUFnQixXQUFXO0FBQzFFNEIseUJBQW1CdUUsSUFBSUUsTUFBTUEsUUFBUSxFQUFFO0FBQUEsSUFDM0MsU0FBU0MsT0FBTztBQUNaN04sY0FBUTZOLE1BQU0sOEJBQThCO0FBQzVDMUUseUJBQW1CLEVBQUU7QUFBQSxJQUN6QixVQUFDO0FBQ0d0QixpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBRUEsUUFBTXlSLHNCQUFzQixPQUFPQyxVQUFVO0FBQ3pDeFEsdUJBQW1CLElBQUk7QUFDdkIsVUFBTW1NLFNBQVNxRSxNQUFNM0ksV0FBV3VFO0FBQ2hDLFVBQU1sRSxVQUFVc0ksTUFBTTNJLFdBQVdDLE1BQU1yRDtBQUN2QyxRQUFJO0FBQ0EsWUFBTW9HLFdBQVcsTUFBTTVRLElBQUkySyxJQUFJLHFDQUFxQztBQUFBLFFBQ2hFcUksUUFBUSxFQUFFZCxRQUFRakUsUUFBUTtBQUFBLE1BQzlCLENBQUM7QUFDRCxZQUFNNUosZUFBY3VNLFNBQVNoRyxLQUFLQSxRQUFRZ0csU0FBU2hHLEtBQUs0TCxXQUFXO0FBQ25FLFlBQU1DLG1CQUFtQnBTLGFBQVlzSztBQUFBQSxRQUFLLENBQUFpSCxPQUNyQ0EsRUFBRXpELFdBQVd5RCxFQUFFMUQsV0FBV0EsVUFBVTBELEVBQUVqUyxVQUFVNkcsUUFBUXlEO0FBQUFBLE1BQzdEO0FBQ0EsVUFBSSxDQUFDd0ksa0JBQWtCO0FBQ25CM0wsZ0JBQVFELE1BQU0sa0NBQWtDcUgsUUFBUSxTQUFTakUsT0FBTztBQUN4RTtBQUFBLE1BQ0o7QUFDQSxZQUFNeUkscUJBQXFCRCxpQkFBaUJqTTtBQUM1Qy9KLGVBQVMscUNBQXFDaVcsa0JBQWtCLEVBQUU7QUFBQSxJQUN0RSxTQUFTQyxLQUFLO0FBQ1Y3TCxjQUFRRCxNQUFNLGtDQUFrQzhMLEdBQUc7QUFBQSxJQUN2RCxVQUFDO0FBQ0c1USx5QkFBbUIsS0FBSztBQUFBLElBQzVCO0FBQUEsRUFDSjtBQUVBLFFBQU02USxlQUFlQSxNQUFNO0FBQ3ZCblc7QUFBQUEsTUFDSSxrRkFBa0Y2RixXQUFXLFdBQVdkLGNBQWMsZ0JBQWdCaEMsV0FBVyxlQUFlNEMsYUFBYTtBQUFBLElBQ2pMO0FBQ0E4QyxxQkFBaUI7QUFBQSxFQUNyQjtBQUVBLFFBQU0yTixtQ0FBbUNBLE1BQU07QUFDM0NwVztBQUFBQSxNQUNJLGdGQUFnRjZFLGVBQWUsV0FBV0UsY0FBYztBQUFBLElBQzVIO0FBQ0EwRCxxQkFBaUI7QUFBQSxFQUNyQjtBQUVBLFFBQU00TixVQUFVO0FBQUEsSUFDWixFQUFFVixLQUFLLE1BQU1XLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVYLEtBQUssUUFBUVcsUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRVgsS0FBSyxhQUFhVyxRQUFRLGdCQUFnQjtBQUFBLElBQzVDLEVBQUVYLEtBQUssY0FBY1csUUFBUSxRQUFRO0FBQUEsSUFDckMsRUFBRVgsS0FBSyxVQUFVVyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFWCxLQUFLLGdCQUFnQlcsUUFBUSxnQkFBZ0JDLE9BQU8sSUFBSTtBQUFBLElBQzFELEVBQUVaLEtBQUssa0JBQWtCVyxRQUFRLGlCQUFpQjtBQUFBLElBQ2xELEVBQUVYLEtBQUssY0FBY1csUUFBUSx3QkFBd0I7QUFBQSxJQUNyRCxFQUFFWCxLQUFLLFVBQVVXLFFBQVEsc0JBQXNCQyxPQUFPLElBQUk7QUFBQSxJQUMxRCxFQUFFWixLQUFLLFVBQVVXLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVYLEtBQUssUUFBUVcsUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRVgsS0FBSyxTQUFTVyxRQUFRLGVBQWU7QUFBQSxFQUFDO0FBRzVDLFFBQU1FLGdCQUFnQjtBQUFBLElBQ2xCLEVBQUViLEtBQUssTUFBTVcsUUFBUSxLQUFLO0FBQUEsSUFDMUIsRUFBRVgsS0FBSyxpQkFBaUJXLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRVgsS0FBSyxjQUFjVyxRQUFRLFFBQVE7QUFBQSxJQUNyQyxFQUFFWCxLQUFLLFVBQVVXLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVYLEtBQUssVUFBVVcsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRVgsS0FBSyxnQkFBZ0JXLFFBQVEsT0FBTztBQUFBLElBQ3RDLEVBQUVYLEtBQUssVUFBVVcsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRVgsS0FBSyxnQkFBZ0JXLFFBQVEsZUFBZTtBQUFBLEVBQUM7QUFHbkQsUUFBTUcscUJBQXFCQSxNQUFNO0FBQzdCLFdBQU94VyxlQUFlZ04sSUFBSSxDQUFDeUosS0FBS0MsU0FBUztBQUFBLE1BQ3JDdEQsSUFBSXNELE1BQU07QUFBQSxNQUNWQyxlQUFlRixJQUFJakQsYUFBYWlELElBQUlFLGlCQUFpQjtBQUFBLE1BQ3JEakQsWUFBWStDLElBQUkvQyxjQUFjO0FBQUEsTUFDOUJsQyxRQUFRaUYsSUFBSWpGLFVBQVU7QUFBQSxNQUN0QnRJLFFBQVEsS0FBS3VOLElBQUl2TixVQUFVLEdBQUd3SixlQUFlLE9BQU8sQ0FBQztBQUFBLE1BQ3JEZCxjQUFjLHVCQUFDLE9BQUksT0FBTSxRQUFRNkUsY0FBSTdFLGNBQWNrQyxZQUFZLEtBQUt6VCxrQkFBa0J5VCxZQUFZLEtBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0Y7QUFBQSxNQUNwR3BKLFFBQVEsdUJBQUMsT0FBSSxPQUFPK0wsSUFBSS9MLFdBQVcsYUFBYSxVQUFVLFVBQVcrTCxjQUFJL0wsVUFBVSxhQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFGO0FBQUEsTUFDN0ZrTSxjQUFjaFksTUFBTTZYLElBQUlJLFVBQVUsRUFBRXRELE9BQU8sWUFBWTtBQUFBLElBQzNELEVBQUU7QUFBQSxFQUNOO0FBRUEsUUFBTXVELHdCQUF3QixPQUFPMUksY0FBYzJJLFlBQVksV0FBVztBQUN0RSxRQUFJO0FBQ0EsWUFBTTdHLFdBQVcsTUFBTTVRLElBQUkySztBQUFBQSxRQUN2Qiw0QkFBNEJtRSxZQUFZO0FBQUEsTUFDNUM7QUFFQSxZQUFNNEksaUJBQWlCOUcsU0FBU2hHO0FBRWhDLFVBQUkrTSxpQkFBaUJGO0FBRXJCLFVBQUlBLGNBQWMsbUJBQW1CO0FBQ2pDLGNBQU1HLGdCQUFnQkYsZ0JBQWdCM0gsaUJBQWlCRyxZQUFZO0FBRW5FLFlBQUkwSCxrQkFBa0IsVUFBVTtBQUM1QkQsMkJBQWlCO0FBQUEsUUFDckIsT0FBTztBQUNIQSwyQkFBaUI7QUFBQSxRQUNyQjtBQUFBLE1BQ0o7QUFFQWhRLHNCQUFnQitQLGNBQWM7QUFDOUJoUCw2QkFBdUJpUCxjQUFjO0FBQ3JDbFEseUJBQW1CLElBQUk7QUFBQSxJQUMzQixTQUFTb0QsT0FBTztBQUNaQyxjQUFRRDtBQUFBQSxRQUNKO0FBQUEsUUFDQUE7QUFBQUEsTUFDSjtBQUVBN04sY0FBUTZOLE1BQU0sbUNBQW1DO0FBQUEsSUFDckQ7QUFBQSxFQUNKO0FBRUEsUUFBTWdOLG9CQUFvQixPQUFPakMsTUFBTTtBQUNuQ0EsTUFBRWtDLGVBQWU7QUFFakIsUUFBSSxDQUFDcFEsYUFBYztBQUVuQixVQUFNcUYsU0FBU3JGLGNBQWM5RCxTQUFTNEc7QUFFdEMsUUFBSSxDQUFDdUMsUUFBUTtBQUNUL1AsY0FBUTZOLE1BQU0saUJBQWlCO0FBQy9CO0FBQUEsSUFDSjtBQUVBLFFBQUk7QUFDQSxZQUFNakQsV0FBVTBDLEtBQUtDLE1BQU1KLGFBQWFDLFFBQVEsTUFBTSxDQUFDLEdBQUdJO0FBRTFELFVBQUkvQix3QkFBd0IsV0FBVztBQUNuQyxjQUFNekksSUFBSXVSLElBQUksa0JBQWtCN0osYUFBYThDLEdBQUcsSUFBSTtBQUFBLFVBQ2hENUcsU0FBU21KO0FBQUFBLFVBQ1RnTCxZQUFZblE7QUFBQUEsVUFDWm9RLGFBQVksb0JBQUlDLEtBQUssR0FBRUMsWUFBWTtBQUFBLFVBQ25DdkcsZUFBZTtBQUFBLFFBQ25CLENBQUM7QUFFRDNVLGdCQUFRc08sUUFBUSxtQ0FBbUM7QUFBQSxNQUN2RCxXQUFXN0Msd0JBQXdCLFlBQVk7QUFDM0MsY0FBTXpJLElBQUl1UixJQUFJLGtCQUFrQjdKLGFBQWE4QyxHQUFHLElBQUk7QUFBQSxVQUNoRDVHLFNBQVNtSjtBQUFBQSxVQUNUZ0wsWUFBWW5RO0FBQUFBLFVBQ1pvUSxhQUFZLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVk7QUFBQSxVQUNuQ3ZHLGVBQWU7QUFBQSxRQUNuQixDQUFDO0FBRUQzVSxnQkFBUXNPLFFBQVEscUNBQXFDO0FBQUEsTUFDekQsV0FBVzdDLHdCQUF3QixRQUFRO0FBQ3ZDLGNBQU16SSxJQUFJdVIsSUFBSSw2QkFBNkI3SixhQUFhOEMsR0FBRyxJQUFJO0FBQUEsVUFDM0Q1RyxTQUFTbUo7QUFBQUEsVUFDVGdELGlCQUFpQjtBQUFBLFFBQ3JCLENBQUM7QUFFRC9TLGdCQUFRc08sUUFBUSx3Q0FBd0M7QUFBQSxNQUM1RCxXQUFXN0Msd0JBQXdCLFVBQVU7QUFDekMsY0FBTXpJLElBQUl1UixJQUFJLDhCQUE4QjdKLGNBQWM4QyxHQUFHLElBQUk7QUFBQSxVQUM3RDVHLFNBQVNtSjtBQUFBQSxVQUNUZ0QsaUJBQWlCO0FBQUEsUUFDckIsQ0FBQztBQUVEL1MsZ0JBQVFzTyxRQUFRLG1DQUFtQztBQUFBLE1BQ3ZEO0FBRUE3RCx5QkFBbUIsS0FBSztBQUN4QkUsc0JBQWdCLElBQUk7QUFDcEJlLDZCQUF1QixJQUFJO0FBRTNCLFVBQUl2RyxrQkFBa0JxSSxLQUFLO0FBQ3ZCK0IsK0JBQXVCcEssaUJBQWlCcUksR0FBRztBQUFBLE1BQy9DO0FBQUEsSUFDSixTQUFTSyxPQUFPO0FBQ1pDLGNBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBRWpEN04sY0FBUTZOLE1BQU0sNkJBQTZCO0FBQUEsSUFDL0M7QUFBQSxFQUNKO0FBR0EsUUFBTXNOLDRCQUE0QkEsTUFBTTtBQUNwQyxRQUFJLENBQUMzVSxhQUFhO0FBQ2R4RyxjQUFRb1QsUUFBUSxzQ0FBc0M7QUFDdEQ7QUFBQSxJQUNKO0FBQ0EsUUFBSSxDQUFDN0wsa0JBQWtCO0FBQ25CdkgsY0FBUW9ULFFBQVEsd0JBQXdCO0FBQ3hDO0FBQUEsSUFDSjtBQUVBLFVBQU1nSSxTQUFTO0FBQ2ZyVCxrQkFBY3FULE1BQU07QUFDcEJqVCxrQkFBY2lULE1BQU07QUFDcEIvUyxvQkFBZ0IsRUFBRTtBQUVsQixVQUFNZ1QsYUFBYWhXLHdCQUF3QnVMLFlBQVlDLE9BQU95SyxjQUN4RHROLE9BQU8zSSx1QkFBdUJ1TCxXQUFXQyxNQUFNeUssV0FBVyxJQUMxRDtBQUNOLFVBQU1DLGdCQUFnQkYsYUFDaEJHLEtBQUtDLE1BQU1KLGFBQWEsSUFBSSxJQUM1QkcsS0FBS0MsT0FBT3pOLE9BQU94SCxXQUFXLEtBQUssS0FBSyxJQUFJO0FBRWxENkMscUJBQWlCa1MsYUFBYTtBQUM5QjlSLGlCQUFhOFIsZ0JBQWdCLElBQUk7QUFHakNyVSxpQkFBYSxJQUFJO0FBQ2pCRSxZQUFRLENBQUM7QUFBQSxFQUNiO0FBRUEsUUFBTXNVLG1DQUFtQ0EsTUFBTTtBQUMzQyxRQUFJLENBQUNsVixhQUFhO0FBQ2R4RyxjQUFRb1QsUUFBUSxzQ0FBc0M7QUFDdEQ7QUFBQSxJQUNKO0FBQ0EsUUFBSSxDQUFDN0wsa0JBQWtCO0FBQ25CdkgsY0FBUW9ULFFBQVEsd0JBQXdCO0FBQ3hDO0FBQUEsSUFDSjtBQUVBNVMsYUFBU21iLFFBQVE7QUFBQSxNQUNiOU0sT0FBTztBQUFBLE1BQ1ArTSxTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLE1BQ1JDLFlBQVk7QUFBQSxNQUNaQyxNQUFNQSxNQUFNO0FBQ1JaLGtDQUEwQjtBQUFBLE1BQzlCO0FBQUEsSUFDSixDQUFDO0FBQUEsRUFDTDtBQUVBLFFBQU1sQyxzQkFBc0JBLENBQUNsRSxlQUFlO0FBQ3hDLFlBQVFBLFlBQVU7QUFBQSxNQUNkLEtBQUs7QUFBZSxlQUFPO0FBQUEsTUFDM0IsS0FBSztBQUFjLGVBQU87QUFBQSxNQUMxQixLQUFLO0FBQWlCLGVBQU87QUFBQSxNQUM3QixLQUFLO0FBQW9CLGVBQU87QUFBQSxNQUNoQyxLQUFLO0FBQWlCLGVBQU87QUFBQSxNQUM3QixLQUFLO0FBQWlCLGVBQU87QUFBQSxNQUM3QjtBQUFTLGVBQU87QUFBQSxJQUNwQjtBQUFBLEVBQ0o7QUFJQSxRQUFNaUgsMEJBQTBCQSxNQUFNO0FBQ2xDLFFBQUksQ0FBQzdXLGlCQUFrQixRQUFPO0FBQzlCLFVBQU04VyxtQkFBbUJ4WCxVQUFVaVQsT0FBTyxDQUFDQyxLQUFLQyxTQUFTRCxPQUFPQyxLQUFLbEUsMEJBQTBCLElBQUksQ0FBQztBQUNwRyxVQUFNd0ksV0FBV3pYLFVBQVU2UCxTQUFTO0FBQ3BDLFVBQU02SCxXQUFXeFgsVUFBVTJQLFNBQVM7QUFDcEMsVUFBTThILFdBQVc3WCxvQkFBb0IrUCxTQUFTO0FBRzlDLFVBQU0rSCxlQUFlNVgsVUFBVSxDQUFDO0FBQ2hDLFVBQU02WCxxQkFBcUJELGNBQWNoTztBQUV6QyxVQUFNa08sY0FBY0QsdUJBQXVCO0FBQzNDLFVBQU1FLGFBQWFGLHVCQUF1QjtBQUMxQyxVQUFNRyxjQUFjRDtBQUVwQixVQUFNRSxrQkFBa0JILGNBQ2xCLG1CQUNBQyxhQUNJLDRCQUNBO0FBQ1YsVUFBTUcsbUJBQW1CQSxNQUFNO0FBQzNCLFVBQUksQ0FBQ04sYUFBYztBQUduQixVQUFJRyxZQUFZO0FBQ1p4YyxnQkFBUW9UO0FBQUFBLFVBQ0o7QUFBQSxRQUNKO0FBQ0E7QUFBQSxNQUNKO0FBRUEsVUFBSW1KLGFBQWE7QUFDYnpJLGdDQUF3QnVJLGFBQWE3TyxHQUFHO0FBQUEsTUFDNUMsT0FBTztBQUNINkYsbUNBQTJCZ0osYUFBYTdPLEdBQUc7QUFBQSxNQUMvQztBQUFBLElBQ0o7QUFJQSxXQUNJLHVCQUFDLFNBQUksV0FBVSxnQ0FBK0IsSUFBRyxzQkFDN0M7QUFBQSw2QkFBQyxRQUFLLFdBQVUsMENBQ1osaUNBQUMsZ0JBQWEsUUFBUSxFQUFFb1AsSUFBSSxHQUFHQyxJQUFJLEdBQUdDLElBQUksRUFBRSxHQUFHLE1BQUssU0FDaEQ7QUFBQSwrQkFBQyxhQUFhLE1BQWIsRUFBa0IsT0FBTSxpQkFBaUIzWCwyQkFBaUI4SixhQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFFO0FBQUEsUUFDckUsdUJBQUMsYUFBYSxNQUFiLEVBQWtCLE9BQU0sZUFBZTlKLDJCQUFpQmlLLGVBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUU7QUFBQSxRQUNyRSx1QkFBQyxhQUFhLE1BQWIsRUFBa0IsT0FBTSxTQUFTakssMkJBQWlCZ0ssZ0JBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0U7QUFBQSxRQUNoRSx1QkFBQyxhQUFhLE1BQWIsRUFBa0IsT0FBTSxXQUFXaEssMkJBQWlCa0ssYUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErRDtBQUFBLFdBSm5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQSxLQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLE1BQ0EsdUJBQUMsT0FBSSxRQUFRLElBQ1Q7QUFBQSwrQkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUNyQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0csT0FBTyx1QkFBQyxVQUFLLFdBQVUseUNBQXdDO0FBQUEscUNBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBYztBQUFBLGNBQUc7QUFBQSxjQUFnQjlLLG9CQUFvQitQO0FBQUFBLGNBQU87QUFBQSxpQkFBcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUg7QUFBQSxZQUM1SCxXQUFVO0FBQUEsWUFDVixXQUFXLEVBQUV5SSxTQUFTWCxXQUFXLE1BQU0sSUFBSTtBQUFBLFlBRTFDdlgsK0JBQ0csdUJBQUMsU0FBSSxXQUFVLG1CQUFrQixpQ0FBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQUssS0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUMsSUFDekN1WCxXQUNBLHVCQUFDLFNBQUksV0FBVSwrQ0FDVjdYLDhCQUFvQm1NO0FBQUFBLGNBQUksQ0FBQ0MsTUFBTXlKLFFBQzVCLHVCQUFDLFNBQWMsV0FBVSxvREFDckI7QUFBQSx1Q0FBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSx5Q0FBQyxTQUNHO0FBQUEsMkNBQUMsU0FBSSxXQUFVLCtCQUErQnpKLGVBQUtDLFdBQVdDLE1BQU11RyxjQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErRTtBQUFBLG9CQUMvRSx1QkFBQyxTQUFJLFdBQVUseUJBQXdCO0FBQUE7QUFBQSxzQkFBU3pHLEtBQUtDLFdBQVd1RTtBQUFBQSx5QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0U7QUFBQSx1QkFGNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLE9BQ0l4RSxNQUFNQyxZQUFZbUMsb0JBQW9CLFdBQ2hDLFNBQ0FwQyxNQUFNQyxZQUFZbUMsb0JBQW9CLFlBQ2xDLFdBQ0E7QUFBQSxzQkFHYnBDLGdCQUFNQyxZQUFZbUMsbUJBQW1CO0FBQUE7QUFBQSxvQkFUMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVVBO0FBQUEscUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpQkE7QUFBQSxnQkFFQSx1QkFBQyxTQUFNLE1BQUssU0FBUSxNQUFJLE1BQ3BCO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csTUFBSztBQUFBLHNCQUNMLE1BQUs7QUFBQSxzQkFDTCxNQUFNLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBUTtBQUFBLHNCQUNkLFNBQVMsTUFBTStCLGtCQUFrQixlQUFlbkUsSUFBSTtBQUFBLHNCQUFFO0FBQUE7QUFBQSxvQkFKMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9BO0FBQUEsa0JBQ0NBLE1BQU1xTSxRQUFRQyxjQUFjLFVBQ3pCO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLE9BQU07QUFBQSxzQkFDTixXQUFVO0FBQUEsc0JBQXNFO0FBQUE7QUFBQSxvQkFGcEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEscUJBZlI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQ0E7QUFBQSxtQkF2RE03QyxLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBd0RBO0FBQUEsWUFDSCxLQTNETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTREQSxJQUVBLHVCQUFDLFNBQU0sT0FBTzNaLE1BQU15Yyx3QkFBd0IsYUFBWSxtQkFBa0IsV0FBVSxVQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwRjtBQUFBO0FBQUEsVUF0RWxHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXdFQSxLQXpFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMEVBO0FBQUEsUUFDQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUNyQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBRUcsT0FDSSx1QkFBQyxVQUFLLFdBQVUsbURBQ1o7QUFBQSxxQ0FBQyxlQUFZLFdBQVUsYUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBZ0M7QUFBQSxjQUNoQyx1QkFBQyxVQUFLLDZCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsaUJBRnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUVKLFdBQVU7QUFBQSxZQUNWLFdBQVcsRUFBRUgsU0FBU2IsV0FBVyxTQUFTLElBQUk7QUFBQSxZQUU3Q25YLHlCQUNHLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsaUNBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFLLEtBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlDLElBQ3pDbVgsV0FDQSx1QkFBQyxTQUFJLFdBQVUsYUFFWDtBQUFBLHFDQUFDLFNBQUksV0FBVSwwREFDWDtBQUFBLHVDQUFDLFNBQUksV0FBVSxnREFBK0MsK0JBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZFO0FBQUEsZ0JBQzdFLHVCQUFDLFNBQUksV0FBVSx1Q0FBc0M7QUFBQTtBQUFBLGtCQUMvQ0QsaUJBQWlCN0YsZUFBZTtBQUFBLHFCQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGNBR0MzUixVQUFVaU07QUFBQUEsZ0JBQUksQ0FBQ3NILE9BQU9vQyxRQUNuQix1QkFBQyxTQUFjLFdBQVUsNERBQ3JCO0FBQUEseUNBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlCQUF3Qix3QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0Q7QUFBQSxvQkFDaEQsdUJBQUMsVUFBSyxXQUFVLG1DQUFtQ3BDLGdCQUFNdkYsWUFBWSxPQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5RTtBQUFBLHVCQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlCQUF3Qiw0QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0Q7QUFBQSxvQkFDcEQsdUJBQUMsVUFBSyxXQUFVLGtDQUFrQ3VGLGdCQUFNM0YsbUJBQW1CLE9BQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStFO0FBQUEsdUJBRm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1g7QUFBQSwyQ0FBQyxPQUFFLFdBQVUseUJBQ1IyRjtBQUFBQSw0QkFBTTNGLGlCQUNEYSxZQUFZLEVBQ2JpSyxRQUFRLFNBQVMsQ0FBQ0MsU0FBU0EsS0FBSzVGLFlBQVksQ0FBQztBQUFBLHNCQUFHO0FBQUEsc0JBQUk7QUFBQSx5QkFIN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLG9CQUNBLHVCQUFDLFVBQUssV0FBVSx1QkFBc0I7QUFBQTtBQUFBLHNCQUFFeEosT0FBT2dLLE1BQU0xRixrQkFBa0IsQ0FBQyxFQUFFOEQsZUFBZTtBQUFBLHlCQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyRjtBQUFBLHVCQVAvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlCQUF3Qix3QkFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0Q7QUFBQSxvQkFDaEQsdUJBQUMsVUFBSyxXQUFVLHVCQUF1QjRCO0FBQUFBLDRCQUFNekYsWUFBWTtBQUFBLHNCQUFJO0FBQUEseUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9FO0FBQUEsdUJBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsd0JBQ1g7QUFBQSwyQ0FBQyxVQUFLLFdBQVUseUJBQXdCLDBCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRDtBQUFBLG9CQUNsRCx1QkFBQyxVQUFLLFdBQVUsdUJBQ1h5RixnQkFBTXhGLGFBQWFsUSxNQUFNMFYsTUFBTXhGLFVBQVUsRUFBRXlFLE9BQU8sWUFBWSxJQUFJLE9BRHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNYO0FBQUEsMkNBQUMsVUFBSyxXQUFVLHlCQUF3QixnQ0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBd0Q7QUFBQSxvQkFDeEQsdUJBQUMsVUFBSyxXQUFVLHFDQUNYZSxnQkFBTXhGLGNBQWMsTUFBTTtBQUN2Qiw0QkFBTTZLLFFBQVEvYSxNQUFNMFYsTUFBTXhGLFVBQVU7QUFDcEMsNEJBQU04SyxRQUFRaGIsTUFBTTtBQUNwQiwwQkFBSWliLFVBQVVELE1BQU1FLEtBQUssSUFBSUgsTUFBTUcsS0FBSyxLQUFLLE1BQU1GLE1BQU1HLE1BQU0sSUFBSUosTUFBTUksTUFBTTtBQUMvRUYsK0JBQVMvQixLQUFLa0MsSUFBSSxHQUFHSCxNQUFNO0FBQzNCLDZCQUFPLEdBQUdBLE1BQU0sTUFBTXZGLE1BQU16RixZQUFZLEdBQUc7QUFBQSxvQkFDL0MsR0FBRyxJQUFJLE9BUFg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFRQTtBQUFBLHVCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBV0E7QUFBQSxxQkF2Q002SCxLQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBd0NBO0FBQUEsY0FDSDtBQUFBLGNBR0QsdUJBQUMsU0FBSSxXQUFVLDBCQUNUO0FBQUEsdUJBQU07QUFDSix3QkFBTWlDLGdCQUFlNVgsVUFBVSxDQUFDO0FBQ2hDLHdCQUFNa1osU0FBUyxDQUFDdEIsZUFBY2hPLGtCQUFrQmdPLGVBQWNoTyxtQkFBbUI7QUFDakYsd0JBQU1rTyxlQUFjRixlQUFjaE8sbUJBQW1CO0FBQ3JELHdCQUFNbU8sY0FBYUgsZUFBY2hPLG1CQUFtQjtBQUNwRCx3QkFBTXVQLFlBQVl2QixlQUFjaE8sbUJBQW1CO0FBSW5ELHNCQUFJc1AsUUFBUTtBQUNSLDJCQUNJO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNHO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLE1BQU0sdUJBQUMsK0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBMEI7QUFBQSx3QkFDaEMsU0FBU3pUO0FBQUFBLHdCQUNULFNBQVMsTUFBTW1KLDJCQUEyQmdKLGNBQWE3TyxHQUFHO0FBQUEsd0JBQzFELFdBQVU7QUFBQSx3QkFBbUY7QUFBQTtBQUFBLHNCQU5qRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBU0E7QUFBQSxrQkFFUjtBQUdBLHdCQUFNcVEsUUFBUTtBQUFBLG9CQUNWO0FBQUEsc0JBQ0l6RSxLQUFLO0FBQUEsc0JBQ0wwRSxPQUFPO0FBQUEsc0JBQ1BDLE1BQU07QUFBQSxzQkFDTjNQLFFBQVE7QUFBQSxvQkFDWjtBQUFBLG9CQUNBO0FBQUEsc0JBQ0lnTCxLQUFLO0FBQUEsc0JBQ0wwRSxPQUFPO0FBQUEsc0JBQ1BDLE1BQU12QixjQUNBLCtDQUNBO0FBQUEsc0JBQ05wTyxRQUFRb08sY0FBYSxTQUFTO0FBQUE7QUFBQSxzQkFFOUJqSCxRQUFRLENBQUNpSCxlQUFjLENBQUNvQixZQUNwQjtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDRyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLFNBQVMxVDtBQUFBQSwwQkFDVCxNQUFNLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWE7QUFBQSwwQkFDbkIsU0FBUyxNQUFNNEosd0JBQXdCdUksY0FBYTdPLEdBQUc7QUFBQSwwQkFDdkQsV0FBVTtBQUFBLDBCQUFvQztBQUFBO0FBQUEsd0JBTmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFTQSxJQUNBO0FBQUEsb0JBQ1I7QUFBQSxvQkFDQTtBQUFBLHNCQUNJNEwsS0FBSztBQUFBLHNCQUNMMEUsT0FBT0YsWUFBWSxtQkFBbUI7QUFBQSxzQkFDdENHLE1BQU1ILFlBQ0EsK0VBQ0E7QUFBQSxzQkFDTnhQLFFBQVF3UCxZQUFZLFNBQVNwQixjQUFhLFdBQVc7QUFBQSxzQkFDckRqSCxRQUFRcUksWUFBWSxPQUFPcEIsY0FDdkI7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0csTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxNQUFNLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQW1CO0FBQUEsMEJBQ3pCLFNBQVMsTUFBTS9ZLFNBQVMsNkRBQTZEO0FBQUEsMEJBQ3JGLFdBQVU7QUFBQSwwQkFBMEM7QUFBQTtBQUFBLHdCQUx4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBUUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0hBQ1g7QUFBQSwrQ0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFhO0FBQUEsd0JBQUc7QUFBQSwyQkFEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUVSO0FBQUEsa0JBQUM7QUFHTCx3QkFBTXVhLGVBQWU7QUFBQSxvQkFDakJDLE1BQU0sRUFBRUMsTUFBTSxxREFBcURKLE9BQU8sb0JBQW9CSyxNQUFNLGlCQUFpQjtBQUFBLG9CQUNySEMsUUFBUSxFQUFFRixNQUFNLDRDQUE0Q0osT0FBTyxpQkFBaUJLLE1BQU0sY0FBYztBQUFBLG9CQUN4R0UsU0FBUyxFQUFFSCxNQUFNLDZDQUE2Q0osT0FBTyxpQkFBaUJLLE1BQU0sY0FBYztBQUFBLGtCQUM5RztBQUVBLHlCQUNJLHVCQUFDLFNBQUksV0FBVSxRQUNYO0FBQUEsMkNBQUMsU0FBSSxXQUFVLHFFQUFvRSxtQ0FBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNDTixNQUFNbk4sSUFBSSxDQUFDdkosT0FBTWlULFFBQVE7QUFDdEIsNEJBQU0vQixJQUFJMkYsYUFBYTdXLE1BQUtpSCxNQUFNO0FBQ2xDLDRCQUFNa1EsU0FBU2xFLFFBQVF5RCxNQUFNdkosU0FBUztBQUN0Qyw2QkFDSSx1QkFBQyxTQUFtQixXQUFVLGNBQzFCO0FBQUEsK0NBQUMsU0FBSSxXQUFVLDhCQUNYO0FBQUEsaURBQUMsU0FBSSxXQUFXLHNGQUFzRitELEVBQUU2RixJQUFJLElBQ3ZHL1csZ0JBQUtpSCxXQUFXLFNBQVMsdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBb0IsSUFBTWpILE1BQUtpSCxXQUFXLFdBQVcsdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBbUIsSUFBTSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFhLEtBRHpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQyxDQUFDa1EsVUFDRSx1QkFBQyxTQUFJLFdBQVcscUNBQXFDakcsRUFBRThGLElBQUksTUFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBOEQ7QUFBQSw2QkFMdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFPQTtBQUFBLHdCQUNBLHVCQUFDLFNBQUksV0FBVSxlQUNYO0FBQUEsaURBQUMsU0FBSSxXQUFXLHVCQUF1QjlGLEVBQUV5RixLQUFLLElBQUszVyxnQkFBSzJXLFNBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQThEO0FBQUEsMEJBQzlELHVCQUFDLFNBQUksV0FBVSxnREFBZ0QzVyxnQkFBSzRXLFFBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXlFO0FBQUEsMEJBQ3hFNVcsTUFBS29PO0FBQUFBLDZCQUhWO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBSUE7QUFBQSwyQkFiTXBPLE1BQUtpUyxLQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBY0E7QUFBQSxvQkFFUixDQUFDO0FBQUEsb0JBRUQsdUJBQUMsU0FBSSxXQUFXLHFEQUFxRG9ELGNBQWEsNkRBQTZELGlEQUFpRCxJQUMzTEQ7QUFBQUEsc0NBQWUsbUNBQUU7QUFBQSwrQ0FBQyxZQUFPLHFCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWE7QUFBQSx3QkFBUztBQUFBLDJCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4RjtBQUFBLHNCQUM3R0MsZUFBYyxtQ0FBRTtBQUFBLCtDQUFDLFlBQU8scUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBYTtBQUFBLHdCQUFTO0FBQUEsMkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtGO0FBQUEseUJBRnJHO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSx1QkE3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkE4QkE7QUFBQSxnQkFFUixHQUFHO0FBQUEsZ0JBR0g7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0c7QUFBQSxvQkFDQSxNQUFLO0FBQUEsb0JBRUwsU0FBUyxNQUFNL04sT0FBTzhQLEtBQUssMkJBQTJCbEMsYUFBYTdPLEdBQUcsSUFBSSxRQUFRO0FBQUEsb0JBQ2xGLFdBQVU7QUFBQSxvQkFBdUY7QUFBQTtBQUFBLGtCQUxyRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRztBQUFBLG9CQUNBLE1BQUs7QUFBQSxvQkFDTCxNQUFNLHVCQUFDLHdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1CO0FBQUEsb0JBQ3pCO0FBQUEsb0JBQ0EsV0FBVTtBQUFBLG9CQUFxSDtBQUFBO0FBQUEsa0JBTG5JO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHO0FBQUEsb0JBQ0EsTUFBSztBQUFBLG9CQUNMLE1BQU0sdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBYTtBQUFBLG9CQUNuQjtBQUFBLG9CQUNBLFdBQVU7QUFBQSxvQkFBNkg7QUFBQTtBQUFBLGtCQUwzSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUE7QUFBQSxtQkFwSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxSkE7QUFBQSxpQkFqTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrTkEsSUFFQSx1QkFBQyxTQUFNLE9BQU8vTSxNQUFNeWMsd0JBQXdCLGFBQVksaUJBQWdCLFdBQVUsVUFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Y7QUFBQTtBQUFBLFVBbE9oRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFvT0EsS0FyT0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNPQTtBQUFBLFFBQ0EsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FDckI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE9BQ0ksdUJBQUMsVUFBSyxXQUFVLGtEQUNaO0FBQUEscUNBQUMsZUFBWSxXQUFVLGFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsY0FDaEMsdUJBQUMsVUFBSyw0QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrQjtBQUFBLGlCQUZ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFFSixXQUFVO0FBQUEsWUFDVixXQUFXLEVBQUVILFNBQVNwWSxTQUFTMlAsU0FBUyxTQUFTLElBQUk7QUFBQSxZQUVwRHJQLHlCQUNHLHVCQUFDLFNBQUksV0FBVSxtQkFBa0IsaUNBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFLLEtBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlDLElBQ3pDTixTQUFTMlAsU0FBUyxJQUNsQix1QkFBQyxTQUFJLFdBQVUsd0JBQ1g7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsdUJBQ1YzUCxtQkFBUytMLElBQUksQ0FBQ0MsTUFBTXlKLFFBQVE7QUFDekIsc0JBQU1uQyxPQUFPdEgsS0FBSzZOLGNBQWN2RyxRQUFRLENBQUM7QUFDekMsc0JBQU13RyxZQUFZOU4sS0FBSytOLGNBQWN6RyxLQUFLMEc7QUFDMUMsc0JBQU1DLFVBQVVqTyxLQUFLaU8sV0FBVztBQUNoQyxzQkFBTUMsYUFBYWxPLEtBQUttTyxxQkFBcUI7QUFFN0MsdUJBQ0k7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBRUcsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsK0NBQUMsU0FDRztBQUFBLGlEQUFDLFNBQUksV0FBVSxzRUFBcUU7QUFBQTtBQUFBLDRCQUN6RTdHLEtBQUtDLFdBQVdrQyxNQUFNO0FBQUEsK0JBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSwwQkFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQW9DO0FBQUE7QUFBQSw0QkFDN0NwTSxPQUFPeVEsU0FBUyxFQUFFckksZUFBZTtBQUFBLCtCQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsNkJBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFPQTtBQUFBLHdCQUNBLHVCQUFDLE9BQUksT0FBTSxVQUFTLFdBQVUsb0VBQW1FLHNCQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsMkJBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFZQTtBQUFBLHNCQUVBLHVCQUFDLFNBQUksV0FBVSw0Q0FDWDtBQUFBLCtDQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLGlEQUFDLFVBQUssV0FBVSwwQkFBeUIsMEJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQW1EO0FBQUEsMEJBQ25ELHVCQUFDLFVBQUssV0FBVSw4QkFBNkI7QUFBQTtBQUFBLDRCQUFFeUksV0FBV3pJLGVBQWU7QUFBQSwrQkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBMkU7QUFBQSw2QkFGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFHQTtBQUFBLHdCQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLGlEQUFDLFVBQUssV0FBVSwwQkFBeUIsc0JBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQStDO0FBQUEsMEJBQy9DLHVCQUFDLFVBQUssV0FBVSw4QkFBOEI2QjtBQUFBQSxpQ0FBSzhHO0FBQUFBLDRCQUFPO0FBQUEsK0JBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQStEO0FBQUEsNkJBRm5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBR0E7QUFBQSx3QkFFQzlHLEtBQUsrRyx3QkFDRix1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSxpREFBQyxVQUFLLFdBQVUsMEJBQXlCLHlCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFrRDtBQUFBLDBCQUNsRCx1QkFBQyxVQUFLLFdBQVUsOEJBQTZCO0FBQUE7QUFBQSw0QkFBRWhSLE9BQU9pSyxLQUFLK0csb0JBQW9CLEVBQUU1SSxlQUFlO0FBQUEsK0JBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWtHO0FBQUEsNkJBRnRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBR0E7QUFBQSx3QkFHSix1QkFBQyxTQUFJLFdBQVUsZ0VBQ1gsaUNBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUEsaURBQUMsVUFBSyxXQUFVLDRCQUEyQixtQ0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBOEQ7QUFBQSwwQkFDOUQsdUJBQUMsVUFBSyxXQUFVLGtDQUFpQztBQUFBO0FBQUEsNEJBQUV3SSxRQUFReEksZUFBZTtBQUFBLCtCQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUE0RTtBQUFBLDZCQUZoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUdBLEtBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFLQTtBQUFBLDJCQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXVCQTtBQUFBO0FBQUE7QUFBQSxrQkF4Q0tnRTtBQUFBQSxrQkFEVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQTBDQTtBQUFBLGNBRVIsQ0FBQyxLQXBETDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFEQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLHVDQUNYO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLE1BQU0sdUJBQUMsK0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEI7QUFBQSxrQkFDaEMsU0FBUyxNQUFNdEYsa0JBQWtCLGlCQUFpQixFQUFFblEsVUFBVUEsU0FBUyxDQUFDLEVBQUUsQ0FBQztBQUFBLGtCQUMzRSxXQUFVO0FBQUEsa0JBQWtJO0FBQUE7QUFBQSxnQkFQaEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVUEsS0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsaUJBcEVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUVBLElBRUEsdUJBQUMsU0FBTSxPQUFPbEUsTUFBTXljLHdCQUF3QixhQUFZLG1CQUFrQixXQUFVLFVBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTBGO0FBQUE7QUFBQSxVQXBGbEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBc0ZBLEtBdkZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3RkE7QUFBQSxXQTNZSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNFlBO0FBQUEsU0FyWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNaQTtBQUFBLEVBRVI7QUFFQSxRQUFNK0Isa0JBQWtCO0FBQUEsSUFDcEJDLE1BQU07QUFBQSxNQUNGclEsT0FBTztBQUFBLE1BQ1BOLGFBQ0k7QUFBQSxNQUNKNFEsWUFBWTtBQUFBLE1BQ1pDLGFBQ0k7QUFBQSxNQUNKQyxXQUNJO0FBQUEsTUFDSkMsYUFBYTtBQUFBLElBQ2pCO0FBQUEsSUFFQUMsU0FBUztBQUFBLE1BQ0wxUSxPQUFPO0FBQUEsTUFDUE4sYUFDSTtBQUFBLE1BQ0o0USxZQUFZO0FBQUEsTUFDWkMsYUFDSTtBQUFBLE1BQ0pDLFdBQ0k7QUFBQSxNQUNKQyxhQUFhO0FBQUEsSUFDakI7QUFBQSxJQUVBbEIsUUFBUTtBQUFBLE1BQ0p2UCxPQUFPO0FBQUEsTUFDUE4sYUFDSTtBQUFBLE1BQ0o0USxZQUFZO0FBQUEsTUFDWkMsYUFDSTtBQUFBLE1BQ0pDLFdBQ0k7QUFBQSxNQUNKQyxhQUFhO0FBQUEsSUFDakI7QUFBQSxFQUNKO0FBRUEsUUFBTUUsbUJBQ0ZQLGdCQUFnQnhULG1CQUFtQixLQUFLd1QsZ0JBQWdCQztBQUk1RCxRQUFNTyxXQUFXO0FBQUEsSUFDYjtBQUFBLE1BQ0lyRyxLQUFLO0FBQUEsTUFDTDBFLE9BQU87QUFBQSxNQUNQNEIsVUFDSSx1QkFBQyxTQUFJLFdBQVUsYUFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxxREFDWCxpQ0FBQyxNQUFNLE9BQU4sRUFBWSxPQUFPM2IsbUJBQW1CLFVBQVUsQ0FBQzZVLE1BQU01VSxxQkFBcUI0VSxFQUFFK0csT0FBT3BQLEtBQUssR0FBRyxhQUFZLFdBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBSUEsdUJBQUMsU0FBSSxXQUFVLHdIQUdYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGtCQUNYLGlDQUFDLFNBQUksV0FBVSwyQ0FDWDtBQUFBLG1DQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLHFDQUFDLFNBQUksV0FBVSxpSUFDWCxpQ0FBQyx1QkFBb0IsV0FBVSx3QkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUQsS0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUEsdUJBQUMsU0FDRztBQUFBLHVDQUFDLFFBQUcsV0FBVSxxQ0FBb0Msb0NBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQSx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLG9GQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGlCQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxZQUdDbEwsd0JBQXdCeU0sZ0JBQ3JCLHVCQUFDLFNBQUksV0FBVSxrR0FDWDtBQUFBLHFDQUFDLFVBQUssV0FBVSxxREFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0U7QUFBQSxjQUVsRSx1QkFBQyxVQUFLLFdBQVUsd0NBQXVDLCtCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLGVBekJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkJBLEtBNUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkJBO0FBQUEsVUFJQSx1QkFBQyxTQUFJLFdBQVUsa0VBR1g7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFFTCxTQUFTLE1BQU07QUFDWHRNLHNDQUFvQixhQUFhO0FBQUEsZ0JBQ3JDO0FBQUEsZ0JBQ0EsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSWpDRCxxQkFBcUIsZ0JBQ1csOERBQ0EsNkZBQTZGO0FBQUE7QUFBQSxnQkFNdEdBO0FBQUFBLHVDQUFxQixpQkFDbEIsdUJBQUMsU0FBSSxXQUFVLDJHQUNYLGlDQUFDLFdBQVEsV0FBVSx3QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUlKLHVCQUFDLFNBQUksV0FBVSxnSkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0SjtBQUFBLGtCQUc1Six1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRyxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1qQ0EscUJBQXFCLGdCQUNXLGNBQ0EsdUJBQXVCO0FBQUE7QUFBQSx3QkFJakMsaUNBQUMsWUFBUyxXQUFVLHdCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF3QztBQUFBO0FBQUEsc0JBYjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFjQTtBQUFBLG9CQUVBLHVCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsMkJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQSx1QkFBQyxPQUFFLFdBQVUsNkNBQTRDLDZFQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBRUEsdUJBQUMsU0FBSSxXQUFVLGtDQUNYO0FBQUEsNkNBQUMsVUFBSyxXQUFVLHlDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFzRDtBQUFBLHNCQUV0RCx1QkFBQyxVQUFLLFdBQVUsbUVBQWtFLDJCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLHVCQS9CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWdDQTtBQUFBO0FBQUE7QUFBQSxjQTVESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUE2REE7QUFBQSxZQUdBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUVMLFNBQVMsTUFBTTtBQUdYQyxzQ0FBb0IsWUFBWTtBQUFBLGdCQUVwQztBQUFBLGdCQUNBLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlqQ0QscUJBQXFCLGVBQ1csOERBQ0EsNkZBQTZGO0FBQUE7QUFBQSxnQkFNdEdBO0FBQUFBLHVDQUFxQixnQkFDbEIsdUJBQUMsU0FBSSxXQUFVLDJHQUNYLGlDQUFDLFdBQVEsV0FBVSx3QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVKLHVCQUFDLFNBQUksV0FBVSxtSkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErSjtBQUFBLGtCQUUvSix1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRyxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1qQ0EscUJBQXFCLGVBQ1csY0FDQSx1QkFBdUI7QUFBQTtBQUFBLHdCQUdqQyxpQ0FBQyxnQkFBYSxXQUFVLHdCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUE0QztBQUFBO0FBQUEsc0JBWmhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFhQTtBQUFBLG9CQUVBLHVCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsMEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQSx1QkFBQyxPQUFFLFdBQVUsNkNBQTRDLG1FQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBRUEsdUJBQUMsU0FBSSxXQUFVLGtDQUNYO0FBQUEsNkNBQUMsVUFBSyxXQUFVLDRDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5RDtBQUFBLHNCQUV6RCx1QkFBQyxVQUFLLFdBQVUsc0VBQXFFLDBCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLHVCQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQStCQTtBQUFBO0FBQUE7QUFBQSxjQTNESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUE0REE7QUFBQSxZQUlBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUtMLFNBQVMsTUFBTTtBQUVYQyxzQ0FBb0IsZUFBZTtBQUFBLGdCQUV2QztBQUFBLGdCQUNBLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUlqQ0QscUJBQXFCLGtCQUNXLDhEQUNBLDZGQUE2RjtBQUFBO0FBQUEsZ0JBTXRHQTtBQUFBQSx1Q0FBcUIsbUJBQ2xCLHVCQUFDLFNBQUksV0FBVSwyR0FDWCxpQ0FBQyxXQUFRLFdBQVUsd0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFSix1QkFBQyxTQUFJLFdBQVUsaUpBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNko7QUFBQSxrQkFFN0osdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNakNBLHFCQUFxQixnQkFDVyxjQUNBLHVCQUF1QjtBQUFBO0FBQUEsd0JBR2hDdUQsNEJBQ0c7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0c7QUFBQSw0QkFDQSxXQUFVO0FBQUE7QUFBQSwwQkFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBRWtDLElBR2xDLHVCQUFDLGdCQUFhLFdBQVUsd0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQTRDO0FBQUE7QUFBQSxzQkFsQnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFvQkE7QUFBQSxvQkFFQSx1QkFBQyxRQUFHLFdBQVUsd0NBQ1RBLDRCQUNLLG9CQUNBLG1CQUhWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSxvQkFFQSx1QkFBQyxPQUFFLFdBQVUsNkNBQTRDLG1FQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBRUEsdUJBQUMsU0FBSSxXQUFVLGtDQUNYO0FBQUEsNkNBQUMsVUFBSyxXQUFVLDBDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF1RDtBQUFBLHNCQUV2RCx1QkFBQyxVQUFLLFdBQVUsb0VBQW1FLHdCQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLHVCQXZDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXdDQTtBQUFBO0FBQUE7QUFBQSxjQXRFSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF1RUE7QUFBQSxZQUlBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUVMLFNBQVMsTUFBTTtBQUVYdEQsc0NBQW9CLFNBQVM7QUFBQSxnQkFLakM7QUFBQSxnQkFDQSxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFJakNELHFCQUFxQixZQUNXLDhEQUNBLDZGQUE2RjtBQUFBO0FBQUEsZ0JBTXRHQTtBQUFBQSx1Q0FBcUIsYUFDbEIsdUJBQUMsU0FBSSxXQUFVLDJHQUNYLGlDQUFDLFdBQVEsV0FBVSx3QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUMsS0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVKLHVCQUFDLFNBQUksV0FBVSxtSkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErSjtBQUFBLGtCQUUvSix1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwyQ0FBQyxTQUFJLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTWxDQSxxQkFBcUIsWUFDTyxjQUNBLHVCQUF1QjtBQUFBLGVBSTdCLGlDQUFDLHVCQUFvQixXQUFVLHdCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtRCxLQVp2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWFBO0FBQUEsb0JBRUEsdUJBQUMsUUFBRyxXQUFVLHdDQUF1Qyx1QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUVBLHVCQUFDLE9BQUUsV0FBVSw2Q0FBNEMsd0VBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ1g7QUFBQSw2Q0FBQyxVQUFLLFdBQVUsNENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlEO0FBQUEsc0JBRXpELHVCQUFDLFVBQUssV0FBVSxzRUFBcUUscUJBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU1BO0FBQUEsdUJBOUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBK0JBO0FBQUE7QUFBQTtBQUFBLGNBN0RKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQThEQTtBQUFBLFlBSUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBRUwsU0FBUyxNQUFNO0FBRVhDLHNDQUFvQixNQUFNO0FBQUEsZ0JBSzlCO0FBQUEsZ0JBQ0EsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSWpDRCxxQkFBcUIsU0FDVyw4REFDQSw2RkFBNkY7QUFBQTtBQUFBLGdCQU10R0E7QUFBQUEsdUNBQXFCLFVBQ2xCLHVCQUFDLFNBQUksV0FBVSwyR0FDWCxpQ0FBQyxXQUFRLFdBQVUsd0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFSix1QkFBQyxTQUFJLFdBQVUsbUpBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0o7QUFBQSxrQkFFL0osdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNakNBLHFCQUFxQixXQUNXLGNBQ0EsdUJBQXVCO0FBQUE7QUFBQSx3QkFJakMsaUNBQUMsYUFBVSxXQUFVLHdCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF5QztBQUFBO0FBQUEsc0JBYjdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFjQTtBQUFBLG9CQUVBLHVCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsdUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQSx1QkFBQyxPQUFFLFdBQVUsNkNBQTRDLHFFQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBRUEsdUJBQUMsU0FBSSxXQUFVLGtDQUNYO0FBQUEsNkNBQUMsVUFBSyxXQUFVLDRDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5RDtBQUFBLHNCQUV6RCx1QkFBQyxVQUFLLFdBQVUsc0VBQXFFLHVCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQTtBQUFBLHVCQS9CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWdDQTtBQUFBO0FBQUE7QUFBQSxjQTlESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUErREE7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUVMLFNBQVMsTUFBTTtBQUVYLHNCQUFJRix3QkFBd0J1TCxZQUFZbUMsaUJBQWlCRyxZQUFZLE1BQU07QUFDdkUxTix3Q0FBb0IsaUJBQWlCO0FBQUEsZ0JBSzdDO0FBQUEsZ0JBQ0EsV0FBVztBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSWpDSCx3QkFBd0J1TCxZQUFZbUMsaUJBQWlCRyxZQUFZLE1BQU0sWUFDdkMsb0dBQ0EsK0NBQStDO0FBQUE7QUFBQSxnQkFLeEQzTjtBQUFBQSx1Q0FBcUIscUJBQ2xCLHVCQUFDLFNBQUksV0FBVSwyR0FDWCxpQ0FBQyxXQUFRLFdBQVUsd0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVDLEtBRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFFSix1QkFBQyxTQUFJLFdBQVUsa0pBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEo7QUFBQSxrQkFFOUosdUJBQUMsU0FBSSxXQUFVLGlCQUVYO0FBQUEsMkNBQUMsU0FBSSxXQUFVLG9NQUNYLGlDQUFDLHVCQUFvQixXQUFVLHdCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtRCxLQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBRUEsdUJBQUMsUUFBRyxXQUFVLHdDQUF1QyxzQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUVBLHVCQUFDLE9BQUUsV0FBVSw2Q0FBNEMseUVBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ1g7QUFBQSw2Q0FBQyxVQUFLLFdBQVUsMkNBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXdEO0FBQUEsc0JBRXhELHVCQUFDLFVBQUssV0FBVSxxRUFBb0UsNkJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU1BO0FBQUEsdUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBc0JBO0FBQUE7QUFBQTtBQUFBLGNBcERKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXFEQTtBQUFBLGVBdFlKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd1lBO0FBQUEsVUFJQSx1QkFBQyxTQUFJLFdBQVUsYUFDWCxpQ0FBQyxTQUFJLFdBQVUsdUZBQ1g7QUFBQSxtQ0FBQyxzQkFBbUIsV0FBVSx5Q0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUU7QUFBQSxZQUVuRSx1QkFBQyxPQUFFLFdBQVUsNkJBQ1Q7QUFBQSxxQ0FBQyxVQUFLLFdBQVUsK0JBQThCLG9CQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FBUTtBQUFBLGNBQUk7QUFBQSxpQkFIaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLGVBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQSxLQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSw0REFDWCxpQ0FBQyxzQkFBd0MsVUFBVXVKLDJCQUExQmpKLGdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRSxLQUQvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFoY0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWljQTtBQUFBLFFBR0NtVyx3QkFBd0I7QUFBQSxRQUd4QnpXLG9CQUFvQkYsMEJBQ2pCLHVCQUFDLFNBQUksSUFBRyx1QkFBc0IsV0FBVSxrRkFDbkNzRztBQUFBQSwyQkFDRyx1QkFBQyxTQUFJLFdBQVUsa0dBQ1gsaUNBQUMsU0FBSSxXQUFVLG9DQUNYO0FBQUEsbUNBQUMsUUFBSyxNQUFLLFdBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0I7QUFBQSxZQUNsQix1QkFBQyxVQUFLLFdBQVUscUNBQW9DLDJDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBLEtBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBRUosdUJBQUMsUUFBRyxXQUFVLGdFQUNWO0FBQUEsbUNBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUI7QUFBQSxZQUFHO0FBQUEsZUFEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsUUFBSyxNQUFNeEgsZ0JBQWdCLFFBQU8sWUFDL0I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSxxQ0FBQyxLQUFLLE1BQUwsRUFBVSxPQUFNLG1CQUNiLGlDQUFDLFNBQU0sT0FBT2dCLGtCQUFrQjhKLGFBQWEsSUFBSSxVQUFRLE1BQUMsT0FBTyxFQUFFMlEsaUJBQWlCLFdBQVdDLE9BQU8sT0FBTyxLQUE3RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRyxLQURuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxPQUFNLGlCQUNiLGlDQUFDLFNBQU0sT0FBTzFhLGtCQUFrQmdLLGdCQUFnQixJQUFJLFVBQVEsTUFBQyxPQUFPLEVBQUV5USxpQkFBaUIsV0FBV0MsT0FBTyxPQUFPLEtBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtILEtBRHRIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE9BQU0sY0FDYixpQ0FBQyxTQUFNLE9BQU94YSx3QkFBd0J1TCxZQUFZQyxNQUFNdUcsWUFBWSxVQUFRLE1BQUMsT0FBTyxFQUFFd0ksaUJBQWlCLFdBQVdDLE9BQU8sT0FBTyxLQUFoSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrSSxLQUR0STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxPQUFNLGlCQUNiLGlDQUFDLFNBQU0sT0FBT3hhLHdCQUF3QnVMLFlBQVl1RSxTQUFTLFVBQVEsTUFBQyxPQUFPLEVBQUV5SyxpQkFBaUIsV0FBV0MsT0FBTyxPQUFPLEtBQXZIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlILEtBRDdIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFDWDtBQUFBLHFDQUFDLFFBQUcsV0FBVSx1RUFBc0Usc0NBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBHO0FBQUEsY0FDMUcsdUJBQUMsU0FBSSxXQUFVLHFHQUNYO0FBQUEsdUNBQUMsVUFBTyxNQUFLLFdBQVUsTUFBSyxTQUFRLFNBQVMvSixrQkFBa0IsVUFBVSxDQUFDdk8sb0JBQW9CSyxTQUFTLFdBQVUsNEVBQzVHQSxvQkFBVSx1QkFBQyxRQUFLLE1BQUssV0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQixJQUFNLDBCQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0NwQixnQkFBZ0IsUUFDYix1QkFBQyxTQUFJLFdBQVUsdUNBQ1g7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsZ0VBQStELHVDQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRztBQUFBLGtCQUNuRyx1QkFBQyxRQUFHLFdBQVUsc0NBQXFDO0FBQUE7QUFBQSxvQkFBR3dILE9BQU94SCxXQUFXLEVBQUU0UCxlQUFlO0FBQUEsdUJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJGO0FBQUEscUJBRi9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFSUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUseUJBQ1gsaUNBQUMsVUFBTyxNQUFLLFFBQU8sU0FBU2lELHNCQUFzQixXQUFVLDJCQUEwQix1Q0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEcsS0FEbEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFrREEsdUJBQUMsU0FBSSxXQUFVLHVFQUNYO0FBQUEscUNBQUMsVUFBTyxTQUFTLE1BQU03VCxvQkFBb0IsSUFBSSxHQUFHLHNCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFQ0QscUJBQXFCLGlCQUNsQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0wsVUFBVSxDQUFDaUIsZUFBZW9CO0FBQUFBLGtCQUMxQixTQUFTLE1BQU07QUFDWCx3QkFBSSxDQUFDa0wsOEJBQThCLEVBQUc7QUFFdEN0Tix3Q0FBb0IsYUFBYTtBQUNqQ2tXLHFEQUFpQztBQUFBLGtCQUNyQztBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFDVixNQUFNLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBUztBQUFBLGtCQUFJO0FBQUE7QUFBQSxnQkFWdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYUE7QUFBQSxjQUdIblcscUJBQXFCLGdCQUNsQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0w7QUFBQSxrQkFDQSxVQUFVLENBQUNpQixlQUFlb0I7QUFBQUEsa0JBQzFCLFNBQVMsTUFBTTtBQUNYLHdCQUFJLENBQUNrTCw4QkFBOEIsRUFBRztBQUV0Q3ROLHdDQUFvQixZQUFZO0FBQ2hDa1cscURBQWlDO0FBQUEsa0JBQ3JDO0FBQUEsa0JBQ0EsTUFBTSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFhO0FBQUEsa0JBQUk7QUFBQTtBQUFBLGdCQVYzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGNBR0huVyxxQkFBcUIsbUJBQ2xCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLE1BQUs7QUFBQSxrQkFDTCxVQUFVdUQ7QUFBQUEsa0JBQ1YsU0FBUyxNQUFNO0FBQ1gsd0JBQUksQ0FBQ2dLLDhCQUE4QixFQUFHO0FBRXRDd0csd0NBQW9CalUsc0JBQXNCO0FBQUEsa0JBQzlDO0FBQUEsa0JBQ0EsTUFDSXlELGtCQUNJLHVCQUFDLGdCQUFhLE1BQUksUUFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0IsSUFFbEIsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBYTtBQUFBLGtCQUdyQixXQUFVO0FBQUEsa0JBRVRBLDRCQUFrQixvQkFBb0I7QUFBQTtBQUFBLGdCQWpCM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBa0JBO0FBQUEsY0FHSHZELHFCQUFxQixVQUNsQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUFNO0FBQ1gsd0JBQUksQ0FBQ3VOLDhCQUE4QixFQUFHO0FBRXRDMEg7QUFBQUEsc0JBQ0luVix3QkFBd0J5TTtBQUFBQSxvQkFDNUI7QUFBQSxrQkFDSjtBQUFBLGtCQUNBLE1BQU0sdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFVO0FBQUEsa0JBQ2hCLFdBQVU7QUFBQSxrQkFBb0U7QUFBQTtBQUFBLGdCQVZsRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGNBR0h2TSxxQkFBcUIsYUFDbEI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTTtBQUNYLHdCQUFJLENBQUN1Tiw4QkFBOEIsRUFBRztBQUV0QzBIO0FBQUFBLHNCQUNJblYsd0JBQXdCeU07QUFBQUEsc0JBQ3hCO0FBQUEsb0JBQ0o7QUFBQSxrQkFDSjtBQUFBLGtCQUNBLE1BQU0sdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0I7QUFBQSxrQkFDMUIsV0FBVTtBQUFBLGtCQUFvRTtBQUFBO0FBQUEsZ0JBWGxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWNBO0FBQUEsY0FHSHZNLHFCQUFxQixxQkFDbEI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0csTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTTtBQUdYaVY7QUFBQUEsc0JBQ0luVix3QkFBd0J5TTtBQUFBQSxzQkFDeEI7QUFBQSxvQkFDSjtBQUFBLGtCQUNKO0FBQUEsa0JBQ0EsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQjtBQUFBLGtCQUMxQixXQUFVO0FBQUEsa0JBQWtFO0FBQUE7QUFBQSxnQkFYaEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBY0E7QUFBQSxpQkEvR1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpSEE7QUFBQSxlQW5NSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9NQTtBQUFBLGFBbE5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtTkE7QUFBQSxXQXBxQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdxQkE7QUFBQSxJQUVSO0FBQUEsSUFDQTtBQUFBLE1BQ0lzSCxLQUFLO0FBQUEsTUFDTDBFLE9BQU87QUFBQSxNQUNQNEIsVUFDSSxtQ0FDSzdIO0FBQUFBLGlCQUNHLHVCQUFDLFNBQUksV0FBVSw2REFFWDtBQUFBLGlDQUFDLFNBQUksV0FBVSwrRkFDWDtBQUFBLG1DQUFDLE9BQUUsV0FBVSxxQ0FBb0Msa0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSx5Q0FDVEEsZ0JBQU1VLE1BQU1ELFNBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSw0Q0FBMkM7QUFBQTtBQUFBLGNBQ2xEVCxNQUFNVSxNQUFNM0wsT0FBT3dKLGVBQWUsT0FBTztBQUFBLGlCQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsOEZBQ1g7QUFBQSxtQ0FBQyxPQUFFLFdBQVUscUNBQW9DLGtDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxRQUFHLFdBQVUseUNBQ1R5QixnQkFBTUMsV0FBV1EsU0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDJDQUEwQztBQUFBO0FBQUEsY0FDakRULE1BQU1DLFdBQVdsTCxPQUFPd0osZUFBZSxPQUFPO0FBQUEsaUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxrR0FDWDtBQUFBLG1DQUFDLE9BQUUsV0FBVSxxQ0FBb0MsaUNBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFFBQUcsV0FBVSx5Q0FDVHlCLGdCQUFNRyxNQUFNTSxTQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsK0NBQThDO0FBQUE7QUFBQSxjQUNyRFQsTUFBTUcsTUFBTXBMLE9BQU93SixlQUFlLE9BQU87QUFBQSxpQkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBdENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvREE7QUFBQSxRQUlKLHVCQUFDLFNBQUksV0FBVSw0REFDVm5RLHNCQUNHLHVCQUFDLGtCQUFlLFdBQVcsTUFBTSxNQUFLLGtCQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9ELElBQ3BERixhQUFhdU8sV0FBVyxJQUN4Qix1QkFBQyxTQUFNLGFBQVksMkJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEMsSUFFMUM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNHLE1BQU12TztBQUFBQSxZQUNOO0FBQUEsWUFDQSxpQkFBZ0I7QUFBQSxZQUNoQixrQkFBaUI7QUFBQTtBQUFBLFVBSnJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk2QyxLQVZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBYUE7QUFBQSxXQXZFSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0VBO0FBQUEsSUFFUjtBQUFBLElBQ0E7QUFBQSxNQUNJcVQsS0FBSztBQUFBLE1BQ0wwRSxPQUFPO0FBQUEsTUFDUDRCLFVBQ0ksdUJBQUMsU0FBSSxXQUFVLDREQUNYLGlDQUFDLDZCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0IsS0FENUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsSUFFUjtBQUFBLEVBQUM7QUFHTCxTQUNJLG1DQUNJLGlDQUFDLFNBQUksV0FBVSw4QkFDWDtBQUFBLDJCQUFDLFVBQU8sNkJBQTZCLE1BQU07QUFBQSxJQUFFLEdBQUcsWUFBWSxRQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlFO0FBQUEsSUFDakUsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSLHVCQUFDLGVBQVksTUFBTTdULFlBQVlHLE1BQU0sV0FBV0gsWUFBWUUsWUFBWSxTQUFTRixZQUFZN0wsV0FBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRztBQUFBLElBQ3JHLHVCQUFDLFNBQUksV0FBVSxpREFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSwwQ0FDWCxpQ0FBQyxRQUFHLFdBQVUsOENBQ1Y7QUFBQSwrQkFBQyxhQUFVLFdBQVUsbUJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0M7QUFBQSxRQUFHO0FBQUEsV0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFFQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0csV0FBVzBJO0FBQUFBLFVBRVgsVUFBVXlRO0FBQUFBLFVBQ1YsT0FBT3NHO0FBQUFBLFVBQ1AsTUFBSztBQUFBLFVBQ0wsb0JBQ0ksdUJBQUMsU0FBSSxXQUFVLGNBQ1g7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLElBQUc7QUFBQSxnQkFDSCxXQUFVO0FBQUEsZ0JBQThFO0FBQUE7QUFBQSxjQUY1RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxJQUFHO0FBQUEsZ0JBQ0gsV0FBVTtBQUFBLGdCQUFpRjtBQUFBO0FBQUEsY0FGL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxlQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQTtBQUFBLFFBckJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXNCSztBQUFBLE1BR0wsdUJBQUMsWUFBUyxPQUFNLG1DQUFrQyxNQUFNeGIsdUJBQXVCLFVBQVUsTUFBTTtBQUFFQyxpQ0FBeUIsS0FBSztBQUFHQyx1QkFBZXFSLFlBQVk7QUFBR3BRLDRCQUFvQixJQUFJO0FBQUdFLGtDQUEwQixJQUFJO0FBQUdkLCtCQUF1QixFQUFFO0FBQUdnQiw0QkFBb0IsSUFBSTtBQUFBLE1BQUcsR0FBRyxRQUFRLE1BQU0sT0FBTyxLQUN2UyxpQ0FBQyxTQUFJLFdBQVUsYUFDWDtBQUFBLCtCQUFDLEtBQUssTUFBTCxFQUFVLE9BQU0sbUJBQ2IsaUNBQUMsVUFBTyxZQUFVLE1BQUMsYUFBWSxxQ0FBb0MsY0FBYyxDQUFDc2EsT0FBT0MsWUFBWUEsUUFBUWpDLFNBQVMsSUFBSTVLLFlBQVksRUFBRUMsU0FBUzJNLE1BQU01TSxZQUFZLENBQUMsR0FBRyxVQUFVLENBQUM4TSxRQUFRQyxxQkFBcUJELEdBQUcsR0FBRyxPQUFPN2Esa0JBQWtCcUksS0FBSyxTQUFTbkosTUFBTXFNLElBQUksQ0FBQ3hELFVBQVUsRUFBRXFELE9BQU9yRCxLQUFLTSxLQUFLc1EsT0FBTyxHQUFHNVEsS0FBSytCLFNBQVMsTUFBTS9CLEtBQUtpQyxZQUFZLEdBQUcsRUFBRSxLQUF4VjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBWLEtBRDlWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0M2TSx3QkFBd0I7QUFBQSxRQUN4QnpXLG9CQUNHLHVCQUFDLFNBQUksV0FBVSxpQ0FDWCxpQ0FBQyxRQUFLLE1BQU1wQixnQkFBZ0IsUUFBTyxZQUFXLFVBQVVpUix3QkFDcEQ7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMEJBQ1g7QUFBQSxtQ0FBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLFVBQVMsT0FBTSxVQUFTLE9BQU8sQ0FBQyxFQUFFOEssVUFBVSxLQUFLLENBQUMsR0FBRyxpQ0FBQyxTQUFNLE1BQUssVUFBUyxRQUFPLE9BQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStCLEtBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVHO0FBQUEsWUFDdkcsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxVQUFTLE9BQU0sVUFBUyxPQUFPLENBQUMsRUFBRUEsVUFBVSxLQUFLLENBQUMsR0FBRyxpQ0FBQyxNQUFNLFVBQU4sRUFBZSxNQUFNLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdCLEtBQTdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdHO0FBQUEsZUFGcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDBCQUNYO0FBQUEsbUNBQUMsVUFBTyxTQUFTLE1BQU1oYyx5QkFBeUIsS0FBSyxHQUFHLHNCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLFlBQzlELHVCQUFDLFVBQU8sTUFBSyxXQUFVLFVBQVMsVUFBUyxTQUFTTCx1QkFBdUIsc0JBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStFO0FBQUEsZUFGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBLEtBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0FqQlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW1CQSxLQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsTUFHQSx1QkFBQyxTQUFNLFdBQVdvRCxXQUFXLFNBQVNpRixrQkFBa0IsaUJBQWlCLE9BQ3BFL0U7QUFBQUEsaUJBQVMsS0FDTixtQ0FDSSxpQ0FBQyxTQUFJLFdBQVUsWUFDWDtBQUFBLGlDQUFDLFlBQU8sU0FBUytFLGtCQUFrQixXQUFVLDJFQUEwRSxpQkFBdkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0g7QUFBQSxVQUN4SCx1QkFBQyxTQUFJLFdBQVUsZ0ZBQ1g7QUFBQSxtQ0FBQyxnQ0FBNkIsV0FBVSx5Q0FBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkU7QUFBQSxZQUM3RSx1QkFBQyxRQUFHLFdBQVUsNERBQTJELCtDQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RztBQUFBLFlBQ3hHLHVCQUFDLE9BQUUsV0FBVSxnQ0FBK0IsMkRBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVGO0FBQUEsZUFIM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ1g7QUFBQSxtQ0FBQyxXQUFRLFdBQVUsNkJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRDO0FBQUEsWUFDNUMsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEscUNBQUMsT0FBRSxNQUFLLDJFQUEwRSxXQUFVLHdIQUF1SDtBQUFBLHVDQUFDLFVBQUssV0FBVSxlQUFjLHlDQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RDtBQUFBLGdCQUFPLHVCQUFDLFVBQUssaUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBTztBQUFBLG1CQUF4UjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErUjtBQUFBLGNBQy9SLHVCQUFDLE9BQUUsTUFBSyx5RUFBd0UsV0FBVSxvSUFBbUk7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsZUFBYyx3Q0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0Q7QUFBQSxnQkFBTyx1QkFBQyxVQUFLLGlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQU87QUFBQSxtQkFBalM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd1M7QUFBQSxpQkFGNVM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNYO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHlDQUNWO0FBQUEsY0FDRyxFQUFFNFIsT0FBTyxxQkFBcUJ2TixPQUFPLHFCQUFxQjJOLE1BQU0sdUJBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFTLEdBQUsyQixPQUFPLDJCQUEyQk0sT0FBTyxzQ0FBc0M7QUFBQSxjQUM3SixFQUFFckMsT0FBTyxnQkFBZ0J2TixPQUFPLGdCQUFnQjJOLE1BQU0sdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBYSxHQUFLMkIsT0FBTywrQkFBK0JNLE9BQU8sMENBQTBDO0FBQUEsY0FDL0osRUFBRXJDLE9BQU8sZUFBZXZOLE9BQU8sZ0JBQWdCMk4sTUFBTSx1QkFBQyxtQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFjLEdBQUsyQixPQUFPLGlDQUFpQ00sT0FBTyw0Q0FBNEM7QUFBQSxjQUNuSyxFQUFFckMsT0FBTyxTQUFTdk4sT0FBTyxTQUFTMk4sTUFBTSx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQixHQUFLMkIsT0FBTywrQkFBK0JNLE9BQU8sMENBQTBDO0FBQUEsWUFBQyxFQUN4SnpQO0FBQUFBLGNBQUksQ0FBQzZFLFdBQ0g7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUcsU0FBUyxNQUFNO0FBQUV4TixrQ0FBY3dOLE9BQU9oRixLQUFLO0FBQUd0SSxvQ0FBZ0IsRUFBRTtBQUFBLGtCQUFHO0FBQUEsa0JBQ25FLFdBQVcsNkZBQTZGc04sT0FBT3NLLEtBQUssSUFBSXRLLE9BQU80SyxLQUFLLDBGQUEwRnJZLGVBQWV5TixPQUFPaEYsUUFBUSxtREFBbUQsRUFBRTtBQUFBLGtCQUVqVDtBQUFBLDJDQUFDLFVBQUssV0FBVSxpQkFBaUJnRixpQkFBTzJJLFFBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZDO0FBQUEsb0JBQzdDLHVCQUFDLFVBQUssV0FBVSxzQ0FBc0MzSSxpQkFBT3VJLFNBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1FO0FBQUEsb0JBQ2xFaFcsZUFBZXlOLE9BQU9oRixTQUFTLHVCQUFDLFVBQUssV0FBVSxnR0FBK0YsaUJBQS9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdIO0FBQUE7QUFBQTtBQUFBLGdCQU4zSWdGLE9BQU9oRjtBQUFBQSxnQkFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsWUFDSCxLQWhCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBQ0N6SSxjQUFjLHVCQUFDLE9BQUUsV0FBVSx3REFBdUQ7QUFBQTtBQUFBLGNBQVdBLFdBQVdxVixRQUFRLEtBQUssR0FBRztBQUFBLGlCQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE0RztBQUFBLGVBbkIvSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLG9DQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQStDO0FBQUEsVUFDL0MsdUJBQUMsU0FBSSxXQUFVLE9BQ1g7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsUUFDWDtBQUFBLHFDQUFDLFFBQUcsV0FBVSwrRkFBOEY7QUFBQSx1Q0FBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFhO0FBQUEsZ0JBQUc7QUFBQSxtQkFBNUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkk7QUFBQSxjQUM3STtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDRyxZQUFVO0FBQUEsa0JBQUMsTUFBSztBQUFBLGtCQUFRLGFBQVk7QUFBQSxrQkFBMEMsV0FBVTtBQUFBLGtCQUN4RixPQUFPNVY7QUFBQUEsa0JBQWtCLFVBQVVtUjtBQUFBQSxrQkFDbkMsU0FBU3JSLFlBQVlxSixJQUFJLENBQUNrSSxPQUFPLEVBQUVySSxPQUFPcUksRUFBRXBMLEtBQUtzUSxPQUFPLEdBQUdsRixFQUFFaFMsU0FBU3FJLGFBQWEsS0FBSyxNQUFNMkosRUFBRWhTLFNBQVN1SSxZQUFZLE1BQU15SixFQUFFalMsVUFBVXlRLGNBQWMsS0FBSyxjQUFjd0IsRUFBRXpELE9BQU8sR0FBRyxFQUFFO0FBQUEsa0JBQ3RMLGNBQWMsQ0FBQzJLLE9BQU9DLFlBQVlBLFFBQVFqQyxTQUFTLElBQUk1SyxZQUFZLEVBQUVDLFNBQVMyTSxNQUFNNU0sWUFBWSxDQUFDO0FBQUE7QUFBQSxnQkFKckc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSXVHO0FBQUEsaUJBTjNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUNDekwsa0JBQ0csdUJBQUMsUUFBSyxXQUFVLG9GQUNaLGlDQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLHFDQUFDLFVBQU8sTUFBTSxJQUFJLE1BQU0sdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBYSxHQUFLLFdBQVUsbUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1GO0FBQUEsY0FDbkYsdUJBQUMsU0FDRztBQUFBLHVDQUFDLFFBQUcsV0FBVSwwQ0FBMENBLHlCQUFlYixTQUFTcUksYUFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEY7QUFBQSxnQkFDMUYsdUJBQUMsU0FBSSxXQUFVLG9EQUNYO0FBQUEseUNBQUMsVUFBSyxXQUFVLDJCQUEwQjtBQUFBLDJDQUFDLG1CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWM7QUFBQSxvQkFBRztBQUFBLG9CQUFFeEgsZUFBZWQsVUFBVXlRO0FBQUFBLHVCQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpRztBQUFBLGtCQUNqRyx1QkFBQyxVQUFLLFdBQVUsMkJBQTBCO0FBQUEsMkNBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUI7QUFBQSxvQkFBRztBQUFBLG9CQUFVM1AsZUFBZTBOO0FBQUFBLHVCQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErRjtBQUFBLHFCQUZuRztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFNQTtBQUFBLGlCQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0EsS0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVdBO0FBQUEsWUFFSix1QkFBQyxTQUFJLFdBQVUsUUFDWDtBQUFBLHFDQUFDLFFBQUcsV0FBVSx1RUFBc0Usc0NBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBHO0FBQUEsY0FDMUcsdUJBQUMsU0FBSSxXQUFVLHFHQUNYO0FBQUEsdUNBQUMsVUFBTyxNQUFLLFdBQVUsTUFBSyxTQUFRLFNBQVNXLGtCQUFrQixVQUFVLENBQUN2TyxvQkFBb0JLLFNBQVMsV0FBVSw0RUFDNUdBLG9CQUFVLHVCQUFDLFFBQUssTUFBSyxXQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtCLElBQU0sNkJBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQ3BCLGdCQUFnQixRQUNiLHVCQUFDLFNBQUksV0FBVSx1Q0FDWDtBQUFBLHlDQUFDLE9BQUUsV0FBVSxnRUFBK0QsdUNBQTVFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQW1HO0FBQUEsa0JBQ25HLHVCQUFDLFFBQUcsV0FBVSxzQ0FBcUM7QUFBQTtBQUFBLG9CQUFHd0gsT0FBT3hILFdBQVcsRUFBRTRQLGVBQWU7QUFBQSx1QkFBekY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkY7QUFBQSxxQkFGL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLG1CQVJSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSx5QkFBd0IsaUNBQUMsVUFBTyxNQUFLLFFBQU8sU0FBU2lELHNCQUFzQixXQUFVLDJCQUEwQix1Q0FBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEcsS0FBcko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEo7QUFBQSxpQkFibEs7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLFlBQ0M3UyxnQkFBZ0IsUUFBUXNCLGNBQ3JCLHVCQUFDLFNBQUksV0FBVSx1Q0FDWCxpQ0FBQyxVQUFPLE1BQUssV0FBVSxNQUFLLFNBQVEsTUFBTSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFhLEdBQUssU0FBU2dSLG1CQUFtQixVQUFVbFIsV0FBWUUsZUFBZSxXQUFXLENBQUNFLGNBQWNpTCxLQUFLLEdBQUksV0FBVSxzSkFBcUo7QUFBQTtBQUFBLGNBQzdTbkwsV0FBV3FWLFFBQVEsS0FBSyxHQUFHO0FBQUEsaUJBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsZUE1Q1I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4Q0E7QUFBQSxhQWxGSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUZBLEtBcEZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFxRkE7QUFBQSxRQUVIaFcsU0FBUyxLQUNOLHVCQUFDLFNBQUksV0FBVSxrREFDWDtBQUFBLGlDQUFDLFNBQUksV0FBVSxvRkFDWDtBQUFBLG1DQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLHFDQUFDLFNBQUksV0FBVSxvSEFDWCxpQ0FBQyxlQUFZLFdBQVUsOEJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWlELEtBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQ0c7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsb0RBQW1EO0FBQUE7QUFBQSxrQkFBYzhSLG9CQUFvQjFULGdCQUFnQjtBQUFBLHFCQUFuSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxSDtBQUFBLGdCQUNySCx1QkFBQyxPQUFFLFdBQVUsMkNBQTBDLHVEQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE4RjtBQUFBLGdCQUM5Rix1QkFBQyxZQUFPLFNBQVMsTUFBTTJCLGFBQWEsS0FBSyxHQUFHLFdBQVUsMkVBQTBFLGlCQUFoSTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpSTtBQUFBLG1CQUhySTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQTtBQUFBLFlBQ0EsdUJBQUMsT0FBSSxPQUFNLFVBQVMsV0FBVSwyR0FBMEcscUNBQXhJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSwrRUFDWDtBQUFBLG1DQUFDLFNBQUksV0FBVSx3RkFDWDtBQUFBLHFDQUFDLFFBQUcsV0FBVSw2REFBNEQsNkNBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVHO0FBQUEsY0FDdkcsdUJBQUMsVUFBSyxXQUFVLDBFQUF5RTtBQUFBO0FBQUEsZ0JBQ25FOEcsT0FBTzNJLHdCQUF3QnVMLFlBQVlDLE9BQU95SyxlQUFlLENBQUMsRUFBRWxGLGVBQWU7QUFBQSxtQkFEekc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxPQUNYO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csWUFBWTtBQUFBLGtCQUNSLEVBQUVnSyxNQUFNLFlBQVluUyxRQUFRLFVBQVU7QUFBQSxrQkFDdEMsRUFBRW1TLE1BQU0sY0FBY25TLFFBQVEsVUFBVTtBQUFBLGtCQUN4QyxFQUFFbVMsTUFBTSxjQUFjblMsUUFBUSxXQUFXO0FBQUEsa0JBQ3pDLEVBQUVtUyxNQUFNLGVBQWVuUyxRQUFRLFdBQVc7QUFBQSxnQkFBQyxFQUM3Q29TO0FBQUFBLG1CQUNHLE1BQU07QUFDSCwwQkFBTUMsV0FBV2piLHdCQUF3QnVMLFlBQVlDLE9BQU95SztBQUM1RCx3QkFBSWdGLFlBQVksQ0FBQyxDQUFDLFNBQVMsVUFBVSxVQUFVLFNBQVMsRUFBRW5OLFNBQVN0QixPQUFPeU8sUUFBUSxDQUFDLEdBQUc7QUFDbEYsNkJBQU8sQ0FBQyxFQUFFRixNQUFNLEtBQUtwUyxPQUFPc1MsUUFBUSxFQUFFbEssZUFBZSxDQUFDLElBQUluSSxRQUFRLEtBQUt1TixLQUFLQyxNQUFNek4sT0FBT3NTLFFBQVEsSUFBSSxJQUFJLEVBQUVsSyxlQUFlLENBQUMsR0FBRyxDQUFDO0FBQUEsb0JBQ25JO0FBQ0EsMkJBQU87QUFBQSxrQkFDWCxHQUFHO0FBQUEsZ0JBQ1A7QUFBQSxnQkFDQSxTQUFTO0FBQUEsa0JBQ0wsRUFBRXZILE9BQU8sY0FBYzBSLFdBQVcsUUFBUW5ILEtBQUssUUFBUW9ILFdBQVcsaUJBQWlCO0FBQUEsa0JBQ25GLEVBQUUzUixPQUFPLHVCQUF1QjBSLFdBQVcsVUFBVW5ILEtBQUssVUFBVW9ILFdBQVcsK0JBQStCO0FBQUEsZ0JBQUM7QUFBQSxnQkFFbkgsWUFBWTtBQUFBLGdCQUNaLE1BQUs7QUFBQSxnQkFDTCxjQUFjLENBQUN6UixXQUNYQSxPQUFPcVIsU0FBUyxLQUFLcFMsT0FBTzNJLHdCQUF3QnVMLFlBQVlDLE9BQU95SyxlQUFlLENBQUMsRUFBRWxGLGVBQWUsQ0FBQyxLQUNuRyxxQ0FDQTtBQUFBLGdCQUVWLFdBQVU7QUFBQTtBQUFBLGNBMUJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTBCNEIsS0EzQmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsZUFwQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQ0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxzSkFHWDtBQUFBLG1DQUFDLFFBQUcsV0FBVSwrRUFBOEUscUNBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlIO0FBQUEsWUFHakgsdUJBQUMsU0FBSSxXQUFVLGtFQUVYO0FBQUEscUNBQUMsU0FBSSxXQUFVLDJKQUNYO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHFFQUFvRSw0QkFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0c7QUFBQSxnQkFDaEcsdUJBQUMsU0FBSSxXQUFVLG1EQUFrRDtBQUFBO0FBQUEsa0JBQzFEcEksT0FBT3hILFdBQVcsRUFBRWtHLFFBQVEsQ0FBQztBQUFBLHFCQURwQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLGdFQUErRCxpQkFBOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0U7QUFBQSxjQUcvRSx1QkFBQyxTQUFJLFdBQVUsb01BQ1g7QUFBQSx1Q0FBQyxVQUFLLFdBQVUsdUVBQXNFLDhCQUF0RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRztBQUFBLGdCQUNwRyx1QkFBQyxTQUFJLFdBQVUsWUFDWDtBQUFBLHlDQUFDLFVBQUssV0FBVSw2RUFBNEUsaUJBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTZGO0FBQUEsa0JBQzdGO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLE1BQUs7QUFBQSxzQkFFTCxLQUFLO0FBQUEsc0JBQ0wsT0FBT3REO0FBQUFBLHNCQUNQLFVBQVUsQ0FBQ3dQLE1BQU12UCxpQkFBaUJrRCxXQUFXcU0sRUFBRStHLE9BQU9wUCxLQUFLLEtBQUssQ0FBQztBQUFBLHNCQUNqRSxXQUFVO0FBQUE7QUFBQSxvQkFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBTTZIO0FBQUEscUJBUmpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVUE7QUFBQSxtQkFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsZ0VBQStELGlCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUErRTtBQUFBLGNBRy9FLHVCQUFDLFNBQUksV0FBVSxvTUFDWDtBQUFBLHVDQUFDLFVBQUssV0FBVSx1RUFBc0Usd0JBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThGO0FBQUEsZ0JBQzlGLHVCQUFDLFNBQUksV0FBVSxZQUNYO0FBQUEseUNBQUMsVUFBSyxXQUFVLDhFQUE2RSxpQkFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEY7QUFBQSxrQkFDOUY7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csTUFBSztBQUFBLHNCQUVMLEtBQUs7QUFBQSxzQkFDTCxPQUFPL0csV0FBV2tELFFBQVEsQ0FBQztBQUFBLHNCQUMzQixVQUFVLENBQUNrTSxNQUFNblAsYUFBYThDLFdBQVdxTSxFQUFFK0csT0FBT3BQLEtBQUssS0FBSyxDQUFDO0FBQUEsc0JBQzdELFdBQVU7QUFBQTtBQUFBLG9CQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNNEg7QUFBQSxxQkFSaEk7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLG1CQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYUE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSxnRUFBK0QsaUJBQTlFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStFO0FBQUEsY0FHL0UsdUJBQUMsU0FBSSxXQUFVLHlMQUNYO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHdFQUF1RSwyQkFBdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0c7QUFBQSxnQkFDbEcsdUJBQUMsU0FBSSxXQUFVLG1FQUFrRTtBQUFBO0FBQUEsbUJBQ3pFakgsZUFBZSxJQUFJQSxjQUFjLEdBQUdvRCxRQUFRLENBQUM7QUFBQSxxQkFEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkF4REo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5REE7QUFBQSxlQS9ESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdFQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDhDQVFYLGlDQUFDLFNBQUksV0FBVSx5R0FDWCxpQ0FBQyxTQUFJLFdBQVUsNEJBQ1g7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsdUJBQ1gsaUNBQUMsNkJBQTBCLFdBQVUsYUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEMsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FDRztBQUFBLHFDQUFDLFFBQUcsV0FBVSx1Q0FBc0MsbUNBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFO0FBQUEsY0FDdkUsdUJBQUMsT0FBRSxXQUFVLHdDQUF1QyxzR0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0E7QUFBQSxlQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBVUEsS0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBLEtBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFDWDtBQUFBLG1DQUFDLFdBQU0sV0FBVSxpRkFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVSwyQkFDWjtBQUFBLHVDQUFDLGdCQUFhLFdBQVUsb0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdDO0FBQUEsZ0JBQUc7QUFBQSxtQkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsVUFBSyxXQUFVLDhGQUE2RjtBQUFBO0FBQUEsZ0JBQzdGcEQsZUFBZSxJQUFJQSxjQUFjO0FBQUEsbUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNHLE1BQUs7QUFBQSxnQkFDTCxhQUFZO0FBQUEsZ0JBQ1osT0FBT2xCO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ3dRLE1BQU12USxnQkFBZ0J1USxFQUFFK0csT0FBT3BQLEtBQUs7QUFBQSxnQkFDL0MsUUFBUW5JLGdCQUFnQkEsaUJBQWlCeUosT0FBT3ZJLFdBQVcsSUFBSSxVQUFVbVg7QUFBQUEsZ0JBQ3pFLFdBQVU7QUFBQSxnQkFDVixRQUFRLHVCQUFDLGtCQUFlLFdBQVUsb0JBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBDO0FBQUE7QUFBQSxjQVB0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPMEQ7QUFBQSxZQUV6RHJZLGdCQUFnQkEsaUJBQWlCeUosT0FBT3ZJLFdBQVcsS0FDaEQsdUJBQUMsU0FBSSxXQUFVLG1FQUNYO0FBQUEscUNBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0I7QUFBQSxjQUFHO0FBQUEsaUJBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXRCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdCQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDZCQUNYO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDBDQUNYLGlDQUFDLFFBQUcsV0FBVSxxQ0FBb0MsNEJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsS0FISjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBR1g7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsb0pBRWI7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFLO0FBQUEsb0JBQ0wsU0FBUzhCLGlCQUFpQkU7QUFBQUEsb0JBQzFCLFVBQVUsTUFDTkQsb0JBQW9CLENBQUNtRSxVQUFVO0FBQUEsc0JBQzNCLEdBQUdBO0FBQUFBLHNCQUNIbEUsZUFBZSxDQUFDa0UsS0FBS2xFO0FBQUFBLG9CQUN6QixFQUFFO0FBQUEsb0JBRU4sV0FBVTtBQUFBO0FBQUEsa0JBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNxRTtBQUFBLGdCQUdyRSx1QkFBQyxvQkFBaUIsV0FBVSw2QkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUQ7QUFBQSxnQkFFckQsdUJBQUMsVUFBSyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsa0JBRWxELHVCQUFDLFdBQU0sV0FBVSwyQ0FBMEMsaUNBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsY0FJQSx1QkFBQyxXQUFNLFdBQVUsZ0pBRWI7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFLO0FBQUEsb0JBQ0wsU0FBU0YsaUJBQWlCRztBQUFBQSxvQkFDMUIsVUFBVSxNQUNORixvQkFBb0IsQ0FBQ21FLFVBQVU7QUFBQSxzQkFDM0IsR0FBR0E7QUFBQUEsc0JBQ0hqRSxZQUFZLENBQUNpRSxLQUFLakU7QUFBQUEsb0JBQ3RCLEVBQUU7QUFBQSxvQkFFTixXQUFVO0FBQUE7QUFBQSxrQkFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU2lFO0FBQUEsZ0JBR2pFLHVCQUFDLFVBQUssV0FBVSxZQUFXLGtCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUEsdUJBQUMsVUFBSyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsa0JBRWxELHVCQUFDLFdBQU0sV0FBVSwyQ0FBMEMsMEJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBd0JBO0FBQUEsY0FJQSx1QkFBQyxXQUFNLFdBQVUsa0pBRWI7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDRyxNQUFLO0FBQUEsb0JBQ0wsU0FBU0gsaUJBQWlCSTtBQUFBQSxvQkFDMUIsVUFBVSxNQUNOSCxvQkFBb0IsQ0FBQ21FLFVBQVU7QUFBQSxzQkFDM0IsR0FBR0E7QUFBQUEsc0JBQ0hoRSxVQUFVLENBQUNnRSxLQUFLaEU7QUFBQUEsb0JBQ3BCLEVBQUU7QUFBQSxvQkFFTixXQUFVO0FBQUE7QUFBQSxrQkFUZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU21FO0FBQUEsZ0JBR25FLHVCQUFDLFVBQUssV0FBVSxZQUFXLGtCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUEsdUJBQUMsVUFBSyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsa0JBRWxELHVCQUFDLFdBQU0sV0FBVSwyQ0FBMEMsNEJBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBd0JBO0FBQUEsaUJBakZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUZBO0FBQUEsZUExRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyRkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxzRkFDWDtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTXRFLGFBQWEsS0FBSztBQUFBLGdCQUNqQyxXQUFVO0FBQUEsZ0JBQTJHO0FBQUE7QUFBQSxjQUh6SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDRyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLFNBQVM4UjtBQUFBQSxnQkFDVCxVQUFVcFIsV0FBVyxDQUFDUSxnQkFBZ0J5SixPQUFPekosWUFBWSxFQUFFNkssS0FBSyxNQUFNcEIsT0FBT3ZJLFdBQVc7QUFBQSxnQkFDeEY7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQ1YsTUFBTSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFhO0FBQUEsZ0JBRWxCMUIsb0JBQVUsdUJBQUMsUUFBSyxNQUFLLFNBQVEsV0FBVSxnQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUMsSUFBTSxnQkFBZ0JxUixvQkFBb0IxVCxnQkFBZ0IsQ0FBQztBQUFBO0FBQUEsY0FUbkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUE7QUFBQSxlQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBM1JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0UkE7QUFBQSxRQUVINEIsU0FBUyxLQUNOLHVCQUFDLFNBQUksV0FBVSxhQUNYO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGdDQUNYO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGdDQUErQixpQ0FBQyxnQkFBYSxXQUFVLDJCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErQyxLQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnRztBQUFBLFlBQ2hHLHVCQUFDLFFBQUcsV0FBVSxvQ0FBbUMsMENBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJFO0FBQUEsZUFGL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ1g7QUFBQSxtQ0FBQyxVQUFPLE9BQUssTUFBQyxNQUFLLFNBQVEsU0FBU3lTLGNBQWMsV0FBVSwwREFBeUQsdUNBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRJO0FBQUEsWUFDNUksdUJBQUMsV0FBUSxPQUFLLE1BQUMsa0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUI7QUFBQSxZQUNqQix1QkFBQyxVQUFPLE9BQUssTUFBQyxNQUFLLFNBQVEsU0FBU0Msa0NBQWtDLFdBQVUsOERBQTZELG9EQUE3STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpTDtBQUFBLGVBSHJMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSx5QkFDWDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csU0FBUyxNQUFNO0FBQ1gzUyw2QkFBYSxLQUFLO0FBQ2xCdUgsdUJBQU96SCxTQUFTMFosT0FBTztBQUFBLGNBQzNCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBYTtBQUFBO0FBQUEsWUFMM0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUEsS0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVVBO0FBQUEsYUFyQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQTtBQUFBLFdBL1lSO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpWkE7QUFBQSxNQUdBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxXQUFXaFg7QUFBQUEsVUFDWCxTQUFTLE1BQU07QUFDWEMsaUNBQXFCLEtBQUs7QUFDMUJFLDRCQUFnQixJQUFJO0FBQ3BCRSw4QkFBa0IsS0FBSztBQUFBLFVBQzNCO0FBQUEsVUFDQSxpQkFBaUI7QUFBQSxVQUVqQixpQ0FBQyxTQUFJLFdBQVUsWUFFWDtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csU0FBUyxNQUFNO0FBQ1hKLHVDQUFxQixLQUFLO0FBQzFCRSxrQ0FBZ0IsSUFBSTtBQUNwQkUsb0NBQWtCLEtBQUs7QUFBQSxnQkFDM0I7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQ1YsY0FBVztBQUFBLGdCQUFPO0FBQUE7QUFBQSxjQVB0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDhGQUNYO0FBQUEscUNBQUMsU0FDRztBQUFBLHVDQUFDLFFBQUcsV0FBVSxpQ0FBZ0Msc0NBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9FO0FBQUEsZ0JBQ3BFLHVCQUFDLE9BQUUsV0FBVSxnQ0FBK0IsMkRBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVGO0FBQUEsbUJBRjNGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUNDSCxnQkFDRyx1QkFBQyxTQUNJQTtBQUFBQSw2QkFBYXlFLG1CQUFtQixjQUM3Qix1QkFBQyxVQUFLLFdBQVUsNEVBQTJFLHdCQUEzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtRztBQUFBLGdCQUV0R3pFLGFBQWF5RSxtQkFBbUIsZUFDN0IsdUJBQUMsVUFBSyxXQUFVLDhFQUE2RSx5QkFBN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0c7QUFBQSxnQkFFekd6RSxhQUFheUUsbUJBQW1CLGVBQzdCLHVCQUFDLFVBQUssV0FBVSwwRUFBeUUseUJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWtHO0FBQUEsZ0JBRXJHekUsYUFBYXlFLG1CQUFtQixZQUM3Qix1QkFBQyxVQUFLLFdBQVUsMEVBQXlFLHNCQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErRjtBQUFBLG1CQVh2RztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsaUJBbkJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcUJBO0FBQUEsWUFFQ3pFLGdCQUNHLHVCQUFDLFNBRUc7QUFBQSxxQ0FBQyxTQUFJLFdBQVUseURBQ1g7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsNENBQTJDLDZCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzRTtBQUFBLGdCQUN0RSx1QkFBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSx5Q0FBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSwyQ0FBQyxPQUFFLFdBQVUseUJBQXdCLHdCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QztBQUFBLG9CQUM3Qyx1QkFBQyxPQUFFLFdBQVUsK0JBQStCQSx1QkFBYTZJLFlBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtFO0FBQUEsdUJBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSwyQ0FBQyxPQUFFLFdBQVUseUJBQXdCLDZCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRDtBQUFBLG9CQUNsRCx1QkFBQyxPQUFFLFdBQVUsK0JBQStCN0ksdUJBQWFvRixVQUFVQyxhQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2RTtBQUFBLHVCQUZqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHlCQUF3Qiw0QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUQ7QUFBQSxvQkFDakQsdUJBQUMsT0FBRSxXQUFVLCtCQUErQnJGLHVCQUFheUksbUJBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlFO0FBQUEsdUJBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ1g7QUFBQSwyQ0FBQyxPQUFFLFdBQVUseUJBQ1J6STtBQUFBQSxtQ0FBYXlJLGlCQUNSYSxZQUFZLEVBQ2JpSyxRQUFRLFNBQVMsQ0FBQ0MsU0FBU0EsS0FBSzVGLFlBQVksQ0FBQztBQUFBLHNCQUFHO0FBQUEsc0JBQUk7QUFBQSx5QkFIN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSx1Q0FBc0M7QUFBQTtBQUFBLHNCQUFFNU4sYUFBYTBJO0FBQUFBLHlCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRjtBQUFBLHVCQVByRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBS0MxSSxjQUFjK00saUJBQWlCLGFBQzVCLHVCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLDJDQUFDLE9BQUUsV0FBVSx5QkFBd0IsNkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWtEO0FBQUEsb0JBQ2xELHVCQUFDLE9BQUUsV0FBVSxnQ0FBZ0MvTTtBQUFBQSxtQ0FBYThJO0FBQUFBLHNCQUFrQjtBQUFBLHlCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2RTtBQUFBLHVCQUZqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBSUosdUJBQUMsU0FBSSxXQUFVLHFDQUNYO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHlCQUF3QiwwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0M7QUFBQSxvQkFDL0MsdUJBQUMsT0FBRSxXQUFVLCtCQUNSLGNBQUl1SSxLQUFLclIsYUFBYTRJLFVBQVUsRUFBRW1PLG1CQUFtQixPQUFPLEtBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHlCQUF3QiwwQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0M7QUFBQSxvQkFDL0MsdUJBQUMsT0FBRSxXQUFVLG1DQUFrQztBQUFBO0FBQUEsc0JBQUUvVyxhQUFhd0M7QUFBQUEseUJBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlFO0FBQUEsdUJBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBRVg7QUFBQSwyQ0FBQyxPQUFFLFdBQVUseUJBQXdCLGdDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxRDtBQUFBLG9CQUNyRCx1QkFBQyxPQUFFLFdBQVUsK0JBQ1J4Qyx1QkFBYTRJLGNBQWMsTUFBTTtBQUM5Qiw0QkFBTTZLLFFBQVEvYSxNQUFNc0gsYUFBYTRJLFVBQVU7QUFDM0MsNEJBQU04SyxRQUFRaGIsTUFBTTtBQUNwQiwwQkFBSWliLFVBQVVELE1BQU1FLEtBQUssSUFBSUgsTUFBTUcsS0FBSyxLQUFLLE1BQU1GLE1BQU1HLE1BQU0sSUFBSUosTUFBTUksTUFBTTtBQUMvRUYsK0JBQVMvQixLQUFLa0MsSUFBSSxHQUFHSCxNQUFNO0FBQzNCLDZCQUFPLEdBQUdBLE1BQU0sTUFBTTNULGFBQWEySSxZQUFZLEdBQUc7QUFBQSxvQkFDdEQsR0FBRyxJQUFJLE9BUFg7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFRQTtBQUFBLHVCQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWUE7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQSwyQ0FBQyxPQUFFLFdBQVUseUJBQXdCLDRCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRDtBQUFBLG9CQUNqRCx1QkFBQyxVQUFLLFdBQVUsNkZBQ1gzSSx1QkFBYStNLGdCQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWDtBQUFBLDJDQUFDLE9BQUUsV0FBVSx5QkFBd0IsOEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1EO0FBQUEsb0JBQ25ELHVCQUFDLE9BQUUsV0FBVSwrQkFBK0IvTTtBQUFBQSxtQ0FBYTJJO0FBQUFBLHNCQUFTO0FBQUEseUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlFO0FBQUEsdUJBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsUUFDWDtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFDWjNJLHVCQUFhK00saUJBQWlCLGdCQUFnQixtQ0FBbUMsY0FEdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFDWDtBQUFBLDZDQUFDLFNBQUksV0FBVSxVQUNYO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0csTUFBSztBQUFBLDRCQUNMLE1BQUs7QUFBQSw0QkFDTCxPQUFPM007QUFBQUEsNEJBQ1AsVUFBVSxDQUFDNE8sTUFBTTNPLG9CQUFvQjJPLEVBQUUrRyxPQUFPcFAsS0FBSztBQUFBLDRCQUNuRCxRQUFRbEU7QUFBQUEsNEJBQ1IsV0FBVTtBQUFBLDRCQUNWLGFBQVk7QUFBQTtBQUFBLDBCQVBoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBT21CO0FBQUEsd0JBRWxCNUcsT0FBT3VFLG9CQUNKLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJ2RSxpQkFBT3VFLG9CQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFrRTtBQUFBLDJCQVgxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWFBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0csTUFBSztBQUFBLDBCQUNMLFNBQVM4QztBQUFBQSwwQkFDVCxXQUFVO0FBQUEsMEJBQ1YsT0FBTTtBQUFBLDBCQUVOLGlDQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWE7QUFBQTtBQUFBLHdCQU5qQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBT0E7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDWDtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDRyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQU81QjtBQUFBQSwwQkFDUCxVQUFVLENBQUMwTixNQUFNek4sbUJBQW1CeU4sRUFBRStHLE9BQU9wUCxLQUFLO0FBQUEsMEJBQ2xELFFBQVE1RDtBQUFBQSwwQkFDUixXQUFVO0FBQUEsMEJBQ1YsYUFBWTtBQUFBO0FBQUEsd0JBUGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFPMEIsS0FSOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFVQTtBQUFBLHlCQWpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWtDQTtBQUFBLHVCQXRDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXVDQTtBQUFBLHFCQTNHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTRHQTtBQUFBLG1CQTlHSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQStHQTtBQUFBLGNBR0M3QyxrQkFDRyx1QkFBQyxTQUFJLFdBQVUsNkZBQ1g7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsNENBQTJDLGlDQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwRTtBQUFBLGdCQUMxRSx1QkFBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsMkJBQ1g7QUFBQSwyQ0FBQyxPQUFFLFdBQVUseUJBQXdCLDBCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQztBQUFBLG9CQUMvQyx1QkFBQyxPQUFFLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSxzQkFBRUYsYUFBYXdDO0FBQUFBLHlCQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5RTtBQUFBLHVCQUY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHlCQUF5QnhDLHVCQUFhK00saUJBQWlCLGdCQUFnQix3Q0FBd0MsMkJBQTVIO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9KO0FBQUEsb0JBQ3BKLHVCQUFDLE9BQUUsV0FBVyxxQkFBcUIvTSxhQUFhK00saUJBQWlCLGdCQUFnQixpQkFBaUIsZ0JBQWdCLElBQUsvTTtBQUFBQSxtQ0FBYStNLGlCQUFpQixnQkFBZ0IvTSxhQUFhb0ssdUJBQXVCcEssYUFBYThJO0FBQUFBLHNCQUFrQjtBQUFBLHlCQUF4TztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5TztBQUFBLHVCQUY3TztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJCQUNYO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0Q7QUFBQSxvQkFDcEQsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsc0JBQUU5SSxhQUFhaUw7QUFBQUEseUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdGO0FBQUEsdUJBRnBGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlCQTtBQUFBLG1CQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQTtBQUFBLGNBSUosdUJBQUMsU0FBSSxXQUFVLHdDQVdYO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0csU0FBU1g7QUFBQUEsb0JBQ1QsV0FBVTtBQUFBLG9CQUErRztBQUFBO0FBQUEsa0JBRjdIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLFNBQVNNO0FBQUFBLG9CQUNULFVBQVUxSixtQkFBbUIsQ0FBQ2hCO0FBQUFBLG9CQUM5QixXQUFXLGtHQUFrR2dCLG1CQUFtQixDQUFDaEIsaUJBQzNILGlEQUNBLDJFQUEyRTtBQUFBLG9CQUdoRmdCLDRCQUFrQix1QkFBQyxRQUFLLE1BQUssU0FBUSxXQUFVLGdCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF5QyxJQUFNO0FBQUE7QUFBQSxrQkFSdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNBO0FBQUEsbUJBMUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMkJBO0FBQUEsaUJBeEtKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUtBO0FBQUEsZUE5TVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnTkE7QUFBQTtBQUFBLFFBek5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTBOQTtBQUFBLE1BR0EsdUJBQUMsVUFBTyxVQUFRLE1BQUMsT0FBTyx1QkFBQyxTQUFJLFdBQVUsMkJBQTBCO0FBQUEsK0JBQUMsb0JBQWlCLFdBQVUscUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkM7QUFBQSxRQUFHLHVCQUFDLFVBQUssV0FBVSwrQkFBOEIsbUNBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUU7QUFBQSxXQUExSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlLLEdBQVEsV0FBVSxTQUFRLE1BQU05QixnQkFBZ0IsU0FBUyxNQUFNQyxrQkFBa0IsS0FBSyxHQUFHLE9BQU8sS0FDcFJyQixvQkFDRyx1QkFBQyxTQUFJLFdBQVUseUNBQXdDLGlDQUFDLFFBQUssTUFBSyxXQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0IsS0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RSxJQUM1RXNCLGlCQUFpQm9MLFdBQVcsSUFDNUIsdUJBQUMsU0FBSSxXQUFVLHFCQUFvQjtBQUFBLCtCQUFDLG9CQUFpQixXQUFVLGtDQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFBRyx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLHFDQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStEO0FBQUEsV0FBL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtSyxJQUVuSyx1QkFBQyxZQUFTLE9BQU9wTCxnQkFBZ0J3SCxJQUFJLENBQUNrUSxTQUFTMUssV0FBVztBQUFBLFFBQ3REMkosT0FBTztBQUFBLFFBQ1BILFVBQ0ksdUJBQUMsU0FBZ0IsV0FBVSxrRUFDdkI7QUFBQSxpQ0FBQyxTQUFJLFdBQVUseUNBQ1g7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsc0NBQ1hrQixrQkFBUUMsV0FBVyxJQUFJNUYsS0FBSzJGLFFBQVFDLFFBQVEsRUFBRUYsbUJBQW1CLE9BQU8sSUFBSSxPQURqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxPQUFJLE9BQU0sVUFBUyxXQUFVLHFCQUFvQjtBQUFBO0FBQUEsY0FBRUMsU0FBU2hVLFFBQVF3SixlQUFlO0FBQUEsaUJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNGO0FBQUEsZUFKMUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLDZDQUE2Q3dLLGtCQUFRaGEsU0FBU3FJLGFBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXFGO0FBQUEsVUFDckYsdUJBQUMsU0FBSSxXQUFVLHdCQUNWMlI7QUFBQUEsb0JBQVFqYSxZQUFZLHVCQUFDLFVBQUssV0FBVSwyREFBMkRpYSxrQkFBUWphLFVBQVV5USxjQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RztBQUFBLFlBQzVId0osUUFBUTFMLFVBQVUsdUJBQUMsVUFBSyxXQUFVLDJEQUEwRDtBQUFBO0FBQUEsY0FBUzBMLFNBQVMxTDtBQUFBQSxpQkFBNUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUc7QUFBQSxZQUN0SCx1QkFBQyxVQUFLLFdBQVUsNERBQTREMEwsbUJBQVNFLFlBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThGO0FBQUEsZUFIbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLGFBWk01SyxPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLE1BRVIsRUFBRSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JJLEtBeEJaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQkE7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxXQUFXMUw7QUFBQUEsVUFDWCxTQUFTLE1BQU07QUFDWEMsK0JBQW1CLEtBQUs7QUFDeEJFLDRCQUFnQixJQUFJO0FBQ3BCZSxtQ0FBdUIsSUFBSTtBQUFBLFVBQy9CO0FBQUEsVUFFQSxpQ0FBQyxTQUFJLFdBQVUsNkJBRVgsaUNBQUMsU0FBSSxXQUFVLDBCQUdYO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0csV0FBVztBQUFBO0FBQUE7QUFBQSwwQkFHekI4VCxpQkFBaUJILFNBQVM7QUFBQTtBQUFBLGdCQUdaO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNHLFdBQVU7QUFBQSxvQkFDVixNQUFLO0FBQUEsb0JBQ0wsUUFBTztBQUFBLG9CQUNQLFNBQVE7QUFBQSxvQkFDUixhQUFhO0FBQUEsb0JBRVo1VCxrQ0FBd0IsV0FDckI7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csZUFBYztBQUFBLHdCQUNkLGdCQUFlO0FBQUEsd0JBQ2YsR0FBRTtBQUFBO0FBQUEsc0JBSE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUdzQixJQUd0QjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRyxlQUFjO0FBQUEsd0JBQ2QsZ0JBQWU7QUFBQSx3QkFDZixHQUFFO0FBQUE7QUFBQSxzQkFITjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBR3lHO0FBQUE7QUFBQSxrQkFqQmpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFvQkE7QUFBQTtBQUFBLGNBM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQTRCQSxLQTdCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQThCQTtBQUFBLFlBSUEsdUJBQUMsU0FBSSxXQUFVLFVBR1g7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsbUNBQ1QrVCwyQkFBaUIzUSxTQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FHQSx1QkFBQyxPQUFFLFdBQVUsOENBQ1IyUSwyQkFBaUJqUixlQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FJQzdELGdCQUNHLHVCQUFDLFNBQUksV0FBVSxpRUFFWDtBQUFBLHVDQUFDLFNBQUksV0FBVSxnQ0FDWDtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNHLFdBQVc7QUFBQTtBQUFBLHNDQUV6QjhVLGlCQUFpQkYsV0FBVztBQUFBO0FBQUE7QUFBQSxvQkFIbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUlkO0FBQUEsa0JBR2MsdUJBQUMsUUFBRyxXQUFVLHVDQUFzQyxnQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUseUNBR1g7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsNkJBQ1g7QUFBQSwyQ0FBQyxPQUFFLFdBQVUscUNBQW9DLHdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBRUEsdUJBQUMsT0FBRSxXQUFVLDRDQUNSNVUsd0JBQWM5RCxTQUFTcUksYUFBYSxPQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFRQTtBQUFBLGtCQUlBLHVCQUFDLFNBQUksV0FBVSw2QkFDWDtBQUFBLDJDQUFDLE9BQUUsV0FBVSxxQ0FBb0MscUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQSx1QkFBQyxPQUFFLFdBQVUsNENBQ1J2RSx3QkFBYy9ELFVBQVV5USxjQUFjLE9BRDNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVFBO0FBQUEsa0JBSUEsdUJBQUMsU0FBSSxXQUFVLDZCQUNYO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHFDQUFvQyxxQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUVBLHVCQUFDLE9BQUUsV0FBVSw0Q0FDUjFNLHdCQUFjOUQsU0FBU3VJLGdCQUFnQixPQUQ1QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFRQTtBQUFBLGtCQUlBLHVCQUFDLFNBQUksV0FBVSw2QkFDWDtBQUFBLDJDQUFDLE9BQUUsV0FBVSxxQ0FBb0Msc0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQSx1QkFBQyxPQUFFLFdBQVUsNENBQ1J6RSx3QkFBY3lLLFdBQVcsT0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQSxxQkEvQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpREE7QUFBQSxnQkFJQSx1QkFBQyxTQUFJLFdBQVUsaUdBRVg7QUFBQSx5Q0FBQyxVQUFLLFdBQVUscUNBQW9DLDhCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0csT0FDSXpLLGNBQWNxSSxvQkFBb0IsWUFDNUIsV0FDQXJJLGNBQWNxSSxvQkFBb0IsV0FDOUIsU0FDQTtBQUFBLHNCQUdickksd0JBQWNxSSxtQkFBbUI7QUFBQTtBQUFBLG9CQVR0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxxQkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrQkE7QUFBQSxnQkFJQSx1QkFBQyxTQUFJLFdBQVUsa0ZBRVg7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDRyxXQUFVO0FBQUEsc0JBQ1YsTUFBSztBQUFBLHNCQUNMLFNBQVE7QUFBQSxzQkFFUjtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDRyxVQUFTO0FBQUEsMEJBQ1QsR0FBRTtBQUFBLDBCQUNGLFVBQVM7QUFBQTtBQUFBLHdCQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFHc0I7QUFBQTtBQUFBLG9CQVIxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxrQkFFQSx1QkFBQyxPQUFFLFdBQVUsd0JBQ1Q7QUFBQSwyQ0FBQyxVQUFLLFdBQVUsaUJBQWdCLDBCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQVE7QUFBQSxvQkFBSTtBQUFBLHVCQUhoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEscUJBbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcUJBO0FBQUEsbUJBaEhKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0hBO0FBQUEsY0FLSHJJLGdCQUNHO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNHLFVBQVVtUTtBQUFBQSxrQkFDVixXQUFVO0FBQUEsa0JBRVYsaUNBQUMsU0FBSSxXQUFVLHVEQUdYO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csTUFBSztBQUFBLHdCQUNMLFNBQVMsTUFBTTtBQUNYcFEsNkNBQW1CLEtBQUs7QUFDeEJFLDBDQUFnQixJQUFJO0FBQ3BCZSxpREFBdUIsSUFBSTtBQUFBLHdCQUMvQjtBQUFBLHdCQUNBLFdBQVU7QUFBQSx3QkFVN0I7QUFBQTtBQUFBLHNCQWpCZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBb0JBO0FBQUEsb0JBSUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csTUFBSztBQUFBLHdCQUNMLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNDQVF6QjhULGlCQUFpQkosV0FBVztBQUFBO0FBQUEsd0JBR2JJLDJCQUFpQkw7QUFBQUE7QUFBQUEsc0JBYnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFjQTtBQUFBLHVCQXpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTJDQTtBQUFBO0FBQUEsZ0JBL0NKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWdEQTtBQUFBLGlCQXZMUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBMQTtBQUFBLGVBL05KO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ09BLEtBbE9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbU9BO0FBQUE7QUFBQSxRQTNPSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUE0T0E7QUFBQSxTQWo3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWs3QkE7QUFBQSxPQXQ3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXU3QkEsS0F4N0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5N0JBO0FBRVI7QUFBRTNiLEdBOXZHSUQsa0JBQWdCO0FBQUEsVUFDRDdELGFBU1FvQixLQUFLc0QsU0FpQ2IzRSxXQUFXO0FBQUE7QUFBQXNoQixLQTNDMUJ4ZDtBQWd3R04sZUFBZUE7QUFBaUIsSUFBQXdkO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VNZW1vIiwiTGluayIsInVzZUxvY2F0aW9uIiwidXNlTmF2aWdhdGUiLCJTZWxlY3QiLCJCdXR0b24iLCJTcGluIiwiSW5wdXQiLCJEcmF3ZXIiLCJtZXNzYWdlIiwiRGl2aWRlciIsIkFsZXJ0IiwiVGltZWxpbmUiLCJUYWciLCJBdmF0YXIiLCJDYXJkIiwiTW9kYWwiLCJhbnRNb2RhbCIsIkVtcHR5IiwiRGF0ZVBpY2tlciIsIlRhYnMiLCJSYWRpbyIsIkFudE1vZGFsIiwiRm9ybSIsIkRlc2NyaXB0aW9ucyIsIlNwYWNlIiwiUm93IiwiQ29sIiwiVGFibGUiLCJub3RpZmljYXRpb24iLCJDYWxlbmRhck91dGxpbmVkIiwiRXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCIsIkZpbGVUZXh0T3V0bGluZWQiLCJGdW5kUHJvamVjdGlvblNjcmVlbk91dGxpbmVkIiwiR3JvdXBPdXRsaW5lZCIsIlN3YXBPdXRsaW5lZCIsIlVzZXJPdXRsaW5lZCIsIlN0b3BPdXRsaW5lZCIsIkFycm93UmlnaHRPdXRsaW5lZCIsIlRyYW5zYWN0aW9uT3V0bGluZWQiLCJMb2NrT3V0bGluZWQiLCJTYWZldHlPdXRsaW5lZCIsIkNsb3NlQ2lyY2xlT3V0bGluZWQiLCJDaGVja0NpcmNsZU91dGxpbmVkIiwiSW5mb0NpcmNsZU91dGxpbmVkIiwiVGh1bmRlcmJvbHRPdXRsaW5lZCIsIlBhdXNlQ2lyY2xlT3V0bGluZWQiLCJkYXlqcyIsIkZhQ2FsY3VsYXRvciIsIkZhUnVwZWVTaWduIiwiRmFXaGF0c2FwcFNxdWFyZSIsIlNpZGViYXIiLCJOYXZiYXIiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIkNpcmN1bGFyTG9hZGVyIiwiUXVpY2tTZWFyY2hDb250ZW50IiwiYXBpIiwiTWRDYW5jZWwiLCJNZENoZWNrIiwiRmlTaHVmZmxlIiwiVnNjUmVtb3ZlIiwiSW5kaWFuUnVwZWUiLCJTdXNwZW5kZWRDdXN0b21lclJlcG9ydCIsIlVzZXJBY2NvdW50c01lbnUiLCJfcyIsIm5hdmlnYXRlIiwiY2FuY2VsUmVxdWVzdHMiLCJzZXRDYW5jZWxSZXF1ZXN0cyIsInVzZVN0YXRlIiwiY2FuY2VsUmVxdWVzdHNMb2FkaW5nIiwic2V0Q2FuY2VsUmVxdWVzdHNMb2FkaW5nIiwicmVxdWVzdFR5cGVGaWx0ZXIiLCJzZXRSZXF1ZXN0VHlwZUZpbHRlciIsImlzQWRkUmVxdWVzdE1vZGFsT3BlbiIsInNldElzQWRkUmVxdWVzdE1vZGFsT3BlbiIsImFkZFJlcXVlc3RGb3JtIiwidXNlRm9ybSIsInVzZXJzIiwic2V0VXNlcnMiLCJjdXN0b21lckVucm9sbG1lbnRzIiwic2V0Q3VzdG9tZXJFbnJvbGxtZW50cyIsInBpZ215RGF0YSIsInNldFBpZ215RGF0YSIsImxvYW5EYXRhIiwic2V0TG9hbkRhdGEiLCJsb2FkaW5nRW5yb2xsbWVudHMiLCJzZXRMb2FkaW5nRW5yb2xsbWVudHMiLCJsb2FkaW5nUGlnbXkiLCJzZXRMb2FkaW5nUGlnbXkiLCJsb2FkaW5nTG9hbnMiLCJzZXRMb2FkaW5nTG9hbnMiLCJzZWxlY3RlZEN1c3RvbWVyIiwic2V0U2VsZWN0ZWRDdXN0b21lciIsInNlbGVjdGVkRW5yb2xsbWVudERhdGEiLCJzZXRTZWxlY3RlZEVucm9sbG1lbnREYXRhIiwiYWN0aXZlQWN0aW9uVHlwZSIsInNldEFjdGl2ZUFjdGlvblR5cGUiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsInF1aWNrU2VhcmNoS2V5Iiwic2V0UXVpY2tTZWFyY2hLZXkiLCJ0cmFuc2FjdGlvbnMiLCJzZXRUcmFuc2FjdGlvbnMiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJncm91cHMiLCJzZXRHcm91cHMiLCJvdmVydmlldyIsInNldE92ZXJ2aWV3IiwidG90YWxDb3VudCIsInRvdGFsQW1vdW50IiwiZmlsdGVycyIsInNldEZpbHRlcnMiLCJncm91cF9pZCIsInVzZXJfaWQiLCJzdGFydERhdGUiLCJlbmREYXRlIiwiUmFuZ2VQaWNrZXIiLCJsb2NhdGlvbiIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInN0ZXAiLCJzZXRTdGVwIiwiZW5yb2xsbWVudHMiLCJzZXRFbnJvbGxtZW50cyIsInNlbGVjdGVkRW5yb2xsSWQiLCJzZXRTZWxlY3RlZEVucm9sbElkIiwic2VsZWN0ZWRFbnJvbGwiLCJzZXRTZWxlY3RlZEVucm9sbCIsInNldFRvdGFsQW1vdW50IiwibG9hZGluZyIsInNldExvYWRpbmciLCJyZW1hcmtUeXBlIiwic2V0UmVtYXJrVHlwZSIsImN1c3RvbVJlbWFyayIsInNldEN1c3RvbVJlbWFyayIsIm1vdmVSZW1hcmsiLCJzZXRNb3ZlUmVtYXJrIiwiY29uZmlybUlucHV0Iiwic2V0Q29uZmlybUlucHV0IiwiYXZhaWxhYmxlQW1vdW50Iiwic2V0QXZhaWxhYmxlQW1vdW50Iiwic2VsZWN0ZWRVc2VySWQiLCJzZXRTZWxlY3RlZFVzZXJJZCIsImFjdGl2ZVRhYktleSIsInNldEFjdGl2ZVRhYktleSIsInN0YXRlIiwiYWN0aXZlVGFiIiwidHJhbnNmZXJMb2FkaW5nIiwic2V0VHJhbnNmZXJMb2FkaW5nIiwib3BlbkFudEREcmF3ZXIiLCJzZXRPcGVuQW50RERyYXdlciIsImxhc3RBbGxQYXltZW50cyIsInNldExhc3RBbGxQYXltZW50cyIsInNlcnZpY2VDaGFyZ2UiLCJzZXRTZXJ2aWNlQ2hhcmdlIiwiZmluYWxBbW91bnQiLCJzZXRGaW5hbEFtb3VudCIsImdzdEFtb3VudCIsInNldEdzdEFtb3VudCIsInNob3dXaXRoZHJhd01vZGFsIiwic2V0U2hvd1dpdGhkcmF3TW9kYWwiLCJ3aXRoZHJhd0RhdGEiLCJzZXRXaXRoZHJhd0RhdGEiLCJzaG93Q2FsY3VsYXRlZCIsInNldFNob3dDYWxjdWxhdGVkIiwiZWRpdGFibGVJbnRlcmVzdCIsInNldEVkaXRhYmxlSW50ZXJlc3QiLCJyYWlzaW5nUmVxdWVzdExvYWRpbmciLCJzZXRSYWlzaW5nUmVxdWVzdExvYWRpbmciLCJnc3RQZXJjZW50YWdlIiwic2V0R3N0UGVyY2VudGFnZSIsInBheW1lbnREYXRlIiwic2V0UGF5bWVudERhdGUiLCJzaG93TW9kZWxPbkhvbGQiLCJzZXRTaG93TW9kZWxPbkhvbGQiLCJjdXJyZW50R3JvdXAiLCJzZXRDdXJyZW50R3JvdXAiLCJhZG1pbklkIiwic2V0QWRtaW5JZCIsIndpdGhkcmF3TG9hZGluZyIsInNldFdpdGhkcmF3TG9hZGluZyIsInJhd1RyYW5zYWN0aW9ucyIsInNldFJhd1RyYW5zYWN0aW9ucyIsImRlZHVjdGlvbkFtb3VudCIsInNldERlZHVjdGlvbkFtb3VudCIsInRoaXJkUGFydHlFbmFibGUiLCJzZXRUaGlyZFBhcnR5RW5hYmxlIiwic2VuZF93aGF0c2FwcCIsInNlbmRfZ21haWwiLCJzZW5kX3NtcyIsImVucm9sbG1lbnRPcGVyYXRpb24iLCJzZXRFbnJvbGxtZW50T3BlcmF0aW9uIiwiYWN0aW9uTG9hZGluZyIsInNldEFjdGlvbkxvYWRpbmciLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsInR5cGUiLCJyZXNldEZvcm0iLCJoYW5kbGVDbG9zZU1vZGFsIiwidG90YWxQYWlkIiwidG90YWxfcGFpZCIsImhhbmRsZVBlcmNlbnRCbHVyIiwicGVyY2VudCIsInBhcnNlRmxvYXQiLCJpc05hTiIsImNhbGN1bGF0ZWRBbW91bnQiLCJ0b0ZpeGVkIiwiaGFuZGxlQW1vdW50Qmx1ciIsImFtb3VudCIsImNhbGN1bGF0ZWRQZXJjZW50IiwiaGFuZGxlU3luY0ZpZWxkcyIsImFtdCIsInBjdCIsInVzZUVmZmVjdCIsInVzZXIiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidXNlck9iaiIsIkpTT04iLCJwYXJzZSIsIl9pZCIsImZldGNoVXNlcnMiLCJyZXMiLCJnZXQiLCJkYXRhIiwiZXJyb3IiLCJjb25zb2xlIiwiZ3Jvc3MiLCJOdW1iZXIiLCJjaGFyZ2UiLCJnc3QiLCJuZXQiLCJzdGF0dXMiLCJyZXF1ZXN0X3N0YXR1cyIsInN1Y2Nlc3MiLCJkZXNjcmlwdGlvbiIsInBsYWNlbWVudCIsIndpbmRvdyIsImhpc3RvcnkiLCJyZXBsYWNlU3RhdGUiLCJkb2N1bWVudCIsInRpdGxlIiwiaGFuZGxlUXVpY2tTZWFyY2hTZWxlY3QiLCJyZWNvcmQiLCJjdXN0b21lciIsImZ1bGxfbmFtZSIsIm5hbWUiLCJwaG9uZV9udW1iZXIiLCJjdXN0b21lcl9pZCIsImFkaGFhcl9ubyIsImFhZGhhYXJfbnVtYmVyIiwiZmV0Y2hDdXN0b21lclBvcnRmb2xpbyIsInByZXYiLCJzZXRUaW1lb3V0IiwicG9ydGZvbGlvRWxlbWVudCIsImdldEVsZW1lbnRCeUlkIiwic2Nyb2xsSW50b1ZpZXciLCJiZWhhdmlvciIsImJsb2NrIiwidXNlcklkIiwiZW5yb2xsUmVzdWx0IiwicGlnbXlSZXN1bHQiLCJsb2FuUmVzdWx0IiwiUHJvbWlzZSIsImFsbFNldHRsZWQiLCJwb3N0IiwicmVwb3J0RGF0YSIsInZhbHVlIiwiZ3JvdXBJZHMiLCJTZXQiLCJtYXAiLCJpdGVtIiwiZW5yb2xsbWVudCIsImdyb3VwIiwiZmlsdGVyIiwiQm9vbGVhbiIsImdyb3VwRW5yb2xsUmVzdWx0cyIsImdyb3VwSWQiLCJ1cGRhdGVkRW5yb2xsbWVudHMiLCJyZXN1bHRJbmRleCIsImluZGV4T2YiLCJncm91cEVucm9sbFJlc3VsdCIsImVucm9sbG1lbnREZXRhaWxzIiwicmVzcG9uc2VEYXRhIiwiZ3JvdXBFbnJvbGxtZW50cyIsIkFycmF5IiwiaXNBcnJheSIsImZpbmQiLCJlbnJvbGxtZW50VXNlcklkIiwiU3RyaW5nIiwiZW5yb2xsbWVudElkIiwicmVhc29uIiwicmF3RGF0YSIsIm92ZXJhbGxfcGlnbWUiLCJ0cmFuc2Zvcm1lZFBpZ215IiwicGlnbWUiLCJwaWdtZV9kZXRhaWxzIiwibWF0dXJpdHlfcGVyaW9kIiwicGF5YWJsZV9hbW91bnQiLCJkdXJhdGlvbiIsInN0YXJ0X2RhdGUiLCJwaWdtZV9pZCIsIm1hdHVyaXR5X2ludGVyZXN0Iiwid2FybiIsImxvYW5zIiwib3ZlcmFsbF9sb2FuIiwiY2hlY2tDdXN0b21lck9wZXJhdGlvbkFsbG93ZWQiLCJjdXN0b21lcl9zdGF0dXMiLCJub3JtYWxpemVkU3RhdHVzIiwidHJpbSIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ3YXJuaW5nIiwiaGFuZGxlUmFpc2VXaXRoZHJhd1JlcXVlc3QiLCJwaWdteUlkIiwicGF0Y2giLCJwIiwiY3VzdG9tZXJOYW1lIiwidG90YWxfZGVwb3NpdGVkX2Ftb3VudCIsImZldGNoUGlnbXlEZXRhaWxzIiwicmVzcG9uc2UiLCJFcnJvciIsImhhbmRsZU9wZW5XaXRoZHJhd01vZGFsIiwiZGV0YWlscyIsInByZV9tYXR1cmVkX2ludGVyZXN0IiwidG9TdHJpbmciLCJoYW5kbGVSZWNhbGN1bGF0ZSIsIm5ld0Vycm9ycyIsIk9iamVjdCIsImtleXMiLCJsZW5ndGgiLCJwdXQiLCJoYW5kbGVXaXRoZHJhdyIsImFkbWluIiwicGF5bG9hZCIsInJlbW92YWxSZWFzb24iLCJuZXRQYXlhYmxlIiwibWF0dXJpdHlfYW1vdW50IiwiaGFuZGxlQWN0aW9uQ2xpY2siLCJhY3Rpb25UeXBlIiwiY29udGV4dERhdGEiLCJzZXRGaWVsZHNWYWx1ZSIsInRpY2tldCIsInRpY2tldHMiLCJoYW5kbGVBZGRDYW5jZWxSZXF1ZXN0IiwidmFsdWVzIiwicmVxdWVzdF90eXBlIiwiYWN0aW9uIiwicmVzZXRGaWVsZHMiLCJmZXRjaEVucm9sbG1lbnRzIiwiZmV0Y2hJbml0aWFsRGF0YSIsImdyb3VwUmVzIiwidXNlclJlcyIsImFsbCIsImZldGNoVG90YWxBbW91bnQiLCJmZXRjaFRyYW5zYWN0aW9ucyIsInBhcmFtcyIsImZvcm1hdHRlZERhdGEiLCJpbmRleCIsImZvcm1hdEN1cnJlbmN5IiwidG9Mb2NhbGVTdHJpbmciLCJpbnRlcmVzdEFtb3VudCIsImludGVyZXN0X2Ftb3VudCIsImludHJlc3RfYW1vdW50IiwiZ3N0RGlzcGxheSIsImdzdF9hbW91bnQiLCJpc1ByZU1hdHVyZWQiLCJjbG9zdXJlX3R5cGUiLCJzaWduIiwiY29sb3JDbGFzcyIsImlkIiwiZGF0ZSIsInRyYW5zYWN0aW9uX2RhdGUiLCJmb3JtYXQiLCJ1c2VyX25hbWUiLCJlbnJvbGxfaWQiLCJncm91cF9uYW1lIiwiZ3Jvc3NfYW1vdW50Iiwic2VydmljZV9jaGFyZ2UiLCJ0cmFuc2FjdGlvbl90eXBlIiwidG9VcHBlckNhc2UiLCJhZG1pbl9pZCIsInJlZHVjZSIsImFjYyIsImN1cnIiLCJzdGF0cyIsImNoaXRDYW5jZWwiLCJ0IiwicGlnbXkiLCJsb2FuIiwibG9hbl9pZCIsInN1bUFtb3VudCIsImFyciIsInMiLCJjb3VudCIsInRvdGFsIiwib25EYXRlUmFuZ2VDaGFuZ2UiLCJkYXRlcyIsImhhbmRsZUNoYW5nZSIsImVucm9sbCIsImUiLCJ0b3RhbF9hbW91bnQiLCJvcGVuVHJhbnNmZXJNb2RhbCIsImZpbmFsUmVtYXJrIiwiaGFuZGxlTW92ZUFtb3VudCIsImdldEFjdGlvbkJ1dHRvblRleHQiLCJncm9zc0Ftb3VudCIsImhhbmRsZVRhYkNoYW5nZSIsImtleSIsImZldGNoQWxsVHJhbnNhY3Rpb25zIiwiaGFuZGxlVHJhbnNmZXJDbGljayIsIml0ZW1zIiwiZW5yb2xscyIsInNvdXJjZUVucm9sbG1lbnQiLCJzb3VyY2VFbnJvbGxtZW50SWQiLCJlcnIiLCJoYW5kbGVSZWZ1bmQiLCJoYW5kbGVUcmFuc2ZlclRvRGlmZmVyZW50QWNjb3VudCIsImNvbHVtbnMiLCJoZWFkZXIiLCJ3aWR0aCIsImNhbmNlbENvbHVtbnMiLCJnZXRDYW5jZWxUYWJsZURhdGEiLCJyZXEiLCJpZHgiLCJjdXN0b21lcl9uYW1lIiwicmVxdWVzdF9kYXRlIiwiY3JlYXRlZF9hdCIsImhhbmRsZU9uSG9sZE1vZGVsT3BlbiIsIm9wZXJhdGlvbiIsImVucm9sbG1lbnREYXRhIiwiZmluYWxPcGVyYXRpb24iLCJjdXJyZW50U3RhdHVzIiwiaGFuZGxlT25Ib2xkR3JvdXAiLCJwcmV2ZW50RGVmYXVsdCIsImRlbGV0ZWRfYnkiLCJkZWxldGVkX2F0IiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwiaGFuZGxlUHJvY2VlZFRvU2V0dGxlbWVudCIsInJlbWFyayIsImdyb3VwVmFsdWUiLCJncm91cF92YWx1ZSIsImRlZmF1bHRDaGFyZ2UiLCJNYXRoIiwicm91bmQiLCJoYW5kbGVQcm9jZWVkVG9TZXR0bGVtZW50Q29uZmlybSIsImNvbmZpcm0iLCJjb250ZW50Iiwib2tUZXh0IiwiY2FuY2VsVGV4dCIsIm9uT2siLCJyZW5kZXJDdXN0b21lclBvcnRmb2xpbyIsInRvdGFsUGlnbXlBbW91bnQiLCJoYXNQaWdteSIsImhhc0xvYW5zIiwiaGFzQ2hpdHMiLCJwcmltYXJ5UGlnbXkiLCJwaWdteVJlcXVlc3RTdGF0dXMiLCJpc1JlcXVlc3RlZCIsImlzQXBwcm92ZWQiLCJpc0NvbXBsZXRlZCIsInBpZ215QnV0dG9uVGV4dCIsImhhbmRsZVBpZ215Q2xpY2siLCJ4cyIsInNtIiwibWQiLCJwYWRkaW5nIiwicHJpemVkIiwiaXNfcHJpemVkIiwiUFJFU0VOVEVEX0lNQUdFX1NJTVBMRSIsInJlcGxhY2UiLCJjaGFyIiwic3RhcnQiLCJ0b2RheSIsIm1vbnRocyIsInllYXIiLCJtb250aCIsIm1heCIsImlzTm9uZSIsImlzRGVsZXRlZCIsInN0ZXBzIiwibGFiZWwiLCJkZXNjIiwic3RhdHVzU3R5bGVzIiwiZG9uZSIsImljb24iLCJsaW5lIiwiYWN0aXZlIiwicGVuZGluZyIsImlzTGFzdCIsIm9wZW4iLCJsb2FuX2RldGFpbHMiLCJsb2FuVmFsdWUiLCJsb2FuX3ZhbHVlIiwibG9hbl9hbW91bnQiLCJiYWxhbmNlIiwicGFpZEFtb3VudCIsInRvdGFsX3BhaWRfYW1vdW50IiwidGVudXJlIiwiZGFpbHlfcGF5bWVudF9hbW91bnQiLCJvcGVyYXRpb25Db25maWciLCJob2xkIiwiYnV0dG9uVGV4dCIsImJ1dHRvbkNsYXNzIiwiaWNvbkNsYXNzIiwiYWNjZW50Q2xhc3MiLCJzdXNwZW5kIiwiY3VycmVudE9wZXJhdGlvbiIsInRhYkl0ZW1zIiwiY2hpbGRyZW4iLCJ0YXJnZXQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJjb2xvciIsImlucHV0Iiwib3B0aW9uIiwidmFsIiwiaGFuZGxlQ3VzdG9tZXJDaGFuZ2UiLCJyZXF1aXJlZCIsImhvdmVyIiwiY2hpdCIsImNvbmNhdCIsImdyb3VwVmFsIiwiZGF0YUluZGV4IiwiY2xhc3NOYW1lIiwidW5kZWZpbmVkIiwicmVsb2FkIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwicGF5bWVudCIsInBheV9kYXRlIiwicGF5X3R5cGUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJVc2VyQWNjb3VudHNNZW51LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZU1lbW8sIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmssIHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7XHJcbiAgICBTZWxlY3QsXHJcbiAgICBCdXR0b24sXHJcbiAgICBTcGluLFxyXG4gICAgSW5wdXQsXHJcbiAgICBEcmF3ZXIsXHJcbiAgICBtZXNzYWdlLFxyXG4gICAgRGl2aWRlcixcclxuICAgIEFsZXJ0LFxyXG4gICAgVGltZWxpbmUsXHJcbiAgICBUYWcsXHJcbiAgICBBdmF0YXIsXHJcbiAgICBDYXJkLFxyXG4gICAgTW9kYWwgYXMgYW50TW9kYWwsXHJcbiAgICBFbXB0eSxcclxuICAgIERhdGVQaWNrZXIsXHJcbiAgICBUYWJzLFxyXG4gICAgUmFkaW8sXHJcbiAgICBNb2RhbCBhcyBBbnRNb2RhbCxcclxuICAgIEZvcm0sXHJcbiAgICBEZXNjcmlwdGlvbnMsXHJcbiAgICBTcGFjZSxcclxuICAgIFJvdyxcclxuICAgIENvbCxcclxuICAgIFRhYmxlLFxyXG4gICAgbm90aWZpY2F0aW9uLFxyXG59IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7XHJcbiAgICBDYWxlbmRhck91dGxpbmVkLFxyXG4gICAgRXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCxcclxuICAgIEZpbGVUZXh0T3V0bGluZWQsXHJcbiAgICBGdW5kUHJvamVjdGlvblNjcmVlbk91dGxpbmVkLFxyXG4gICAgR3JvdXBPdXRsaW5lZCxcclxuICAgIFN3YXBPdXRsaW5lZCxcclxuICAgIFVzZXJPdXRsaW5lZCxcclxuICAgIFN0b3BPdXRsaW5lZCxcclxuICAgIEFycm93UmlnaHRPdXRsaW5lZCxcclxuICAgIFRyYW5zYWN0aW9uT3V0bGluZWQsXHJcbiAgICBMb2NrT3V0bGluZWQsXHJcbiAgICBTYWZldHlPdXRsaW5lZCxcclxuICAgIENsb3NlQ2lyY2xlT3V0bGluZWQsXHJcbiAgICBDaGVja0NpcmNsZU91dGxpbmVkLFxyXG4gICAgSW5mb0NpcmNsZU91dGxpbmVkLFxyXG4gICAgVGh1bmRlcmJvbHRPdXRsaW5lZCxcclxuICAgIFBhdXNlQ2lyY2xlT3V0bGluZWQsXHJcbn0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuaW1wb3J0IHsgRmFDYWxjdWxhdG9yLCBGYVJ1cGVlU2lnbiwgRmFXaGF0c2FwcFNxdWFyZSB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5cclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydCBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnRcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IFF1aWNrU2VhcmNoQ29udGVudCBmcm9tIFwiLi4vLi4vc3JjL3BhZ2VzL1F1aWNrU2VhcmNoQ29udGVudFwiO1xyXG5cclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBNZENhbmNlbCwgTWRDaGVjayB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBGaVNodWZmbGUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuaW1wb3J0IHsgVnNjUmVtb3ZlIH0gZnJvbSBcInJlYWN0LWljb25zL3ZzY1wiO1xyXG5pbXBvcnQgeyBJbmRpYW5SdXBlZSB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IFN1c3BlbmRlZEN1c3RvbWVyUmVwb3J0IGZyb20gXCIuL1N1c3BlbmRlZEN1c3RvbWVyUmVwb3J0XCI7XHJcblxyXG5jb25zdCBVc2VyQWNjb3VudHNNZW51ID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG5cclxuICAgIC8vID09PT09PT09PT09PT09PT09PT09IENhbmNlbCBSZXF1ZXN0cyBTdGF0ZSA9PT09PT09PT09PT09PT09PT09PVxyXG4gICAgY29uc3QgW2NhbmNlbFJlcXVlc3RzLCBzZXRDYW5jZWxSZXF1ZXN0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbY2FuY2VsUmVxdWVzdHNMb2FkaW5nLCBzZXRDYW5jZWxSZXF1ZXN0c0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3JlcXVlc3RUeXBlRmlsdGVyLCBzZXRSZXF1ZXN0VHlwZUZpbHRlcl0gPSB1c2VTdGF0ZShcImNoaXRcIik7XHJcbiAgICBjb25zdCBbaXNBZGRSZXF1ZXN0TW9kYWxPcGVuLCBzZXRJc0FkZFJlcXVlc3RNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAgIC8vIEZvcm0gU3RhdGVcclxuICAgIGNvbnN0IFthZGRSZXF1ZXN0Rm9ybV0gPSBGb3JtLnVzZUZvcm0oKTtcclxuICAgIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICAgIC8vIEN1c3RvbWVyIERhdGEgU3RhdGVcclxuICAgIGNvbnN0IFtjdXN0b21lckVucm9sbG1lbnRzLCBzZXRDdXN0b21lckVucm9sbG1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtwaWdteURhdGEsIHNldFBpZ215RGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgICBjb25zdCBbbG9hbkRhdGEsIHNldExvYW5EYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtsb2FkaW5nRW5yb2xsbWVudHMsIHNldExvYWRpbmdFbnJvbGxtZW50c10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbbG9hZGluZ1BpZ215LCBzZXRMb2FkaW5nUGlnbXldID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2xvYWRpbmdMb2Fucywgc2V0TG9hZGluZ0xvYW5zXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgICAvLyBTZWxlY3Rpb24gU3RhdGVcclxuICAgIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVyLCBzZXRTZWxlY3RlZEN1c3RvbWVyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gICAgY29uc3QgW3NlbGVjdGVkRW5yb2xsbWVudERhdGEsIHNldFNlbGVjdGVkRW5yb2xsbWVudERhdGFdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgICBjb25zdCBbYWN0aXZlQWN0aW9uVHlwZSwgc2V0QWN0aXZlQWN0aW9uVHlwZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICAgIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgICAvLyBRdWlja1NlYXJjaCByZXNldCBrZXlcclxuICAgIGNvbnN0IFtxdWlja1NlYXJjaEtleSwgc2V0UXVpY2tTZWFyY2hLZXldID0gdXNlU3RhdGUoMCk7XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT0gVHJhbnNhY3Rpb24gSGlzdG9yeSBTdGF0ZSA9PT09PT09PT09PT09PT09PT09PVxyXG4gICAgY29uc3QgW3RyYW5zYWN0aW9ucywgc2V0VHJhbnNhY3Rpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW292ZXJ2aWV3LCBzZXRPdmVydmlld10gPSB1c2VTdGF0ZSh7IHRvdGFsQ291bnQ6IDAsIHRvdGFsQW1vdW50OiAwIH0pO1xyXG4gICAgY29uc3QgW2ZpbHRlcnMsIHNldEZpbHRlcnNdID0gdXNlU3RhdGUoe1xyXG4gICAgICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICAgICAgc3RhcnREYXRlOiBcIlwiLFxyXG4gICAgICAgIGVuZERhdGU6IFwiXCIsXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IHsgUmFuZ2VQaWNrZXIgfSA9IERhdGVQaWNrZXI7XHJcbiAgICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT0gVXNlciBBY2NvdW50IE1hbmFnZW1lbnQgTW9kYWwgU3RhdGUgPT09PT09PT09PT09PT09PT09PT1cclxuICAgIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbc3RlcCwgc2V0U3RlcF0gPSB1c2VTdGF0ZSgxKTtcclxuICAgIGNvbnN0IFtlbnJvbGxtZW50cywgc2V0RW5yb2xsbWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW3NlbGVjdGVkRW5yb2xsSWQsIHNldFNlbGVjdGVkRW5yb2xsSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWRFbnJvbGwsIHNldFNlbGVjdGVkRW5yb2xsXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gICAgY29uc3QgW3RvdGFsQW1vdW50LCBzZXRUb3RhbEFtb3VudF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtyZW1hcmtUeXBlLCBzZXRSZW1hcmtUeXBlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gICAgY29uc3QgW2N1c3RvbVJlbWFyaywgc2V0Q3VzdG9tUmVtYXJrXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW21vdmVSZW1hcmssIHNldE1vdmVSZW1hcmtdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbY29uZmlybUlucHV0LCBzZXRDb25maXJtSW5wdXRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbYXZhaWxhYmxlQW1vdW50LCBzZXRBdmFpbGFibGVBbW91bnRdID0gdXNlU3RhdGUoMCk7XHJcbiAgICBjb25zdCBbc2VsZWN0ZWRVc2VySWQsIHNldFNlbGVjdGVkVXNlcklkXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gICAgY29uc3QgW2FjdGl2ZVRhYktleSwgc2V0QWN0aXZlVGFiS2V5XSA9IHVzZVN0YXRlKCgpID0+IHtcclxuICAgICAgICByZXR1cm4gbG9jYXRpb24uc3RhdGU/LmFjdGl2ZVRhYiB8fCBcImNhbmNlbC1yZXF1ZXN0c1wiO1xyXG4gICAgfSk7XHJcbiAgICBjb25zdCBbdHJhbnNmZXJMb2FkaW5nLCBzZXRUcmFuc2ZlckxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAgIC8vIFRyYW5zYWN0aW9uIGRyYXdlclxyXG4gICAgY29uc3QgW29wZW5BbnRERHJhd2VyLCBzZXRPcGVuQW50RERyYXdlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbbGFzdEFsbFBheW1lbnRzLCBzZXRMYXN0QWxsUGF5bWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gICAgY29uc3QgW3NlcnZpY2VDaGFyZ2UsIHNldFNlcnZpY2VDaGFyZ2VdID0gdXNlU3RhdGUoMCk7XHJcbiAgICBjb25zdCBbZmluYWxBbW91bnQsIHNldEZpbmFsQW1vdW50XSA9IHVzZVN0YXRlKDApO1xyXG4gICAgY29uc3QgW2dzdEFtb3VudCwgc2V0R3N0QW1vdW50XSA9IHVzZVN0YXRlKClcclxuXHJcbiAgICAvLyBXaXRoZHJhdyBtb2RhbCBzdGF0ZVxyXG4gICAgY29uc3QgW3Nob3dXaXRoZHJhd01vZGFsLCBzZXRTaG93V2l0aGRyYXdNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbd2l0aGRyYXdEYXRhLCBzZXRXaXRoZHJhd0RhdGFdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgICBjb25zdCBbc2hvd0NhbGN1bGF0ZWQsIHNldFNob3dDYWxjdWxhdGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtlZGl0YWJsZUludGVyZXN0LCBzZXRFZGl0YWJsZUludGVyZXN0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW3JhaXNpbmdSZXF1ZXN0TG9hZGluZywgc2V0UmFpc2luZ1JlcXVlc3RMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFtnc3RQZXJjZW50YWdlLCBzZXRHc3RQZXJjZW50YWdlXSA9IHVzZVN0YXRlKDE4KTtcclxuICAgIGNvbnN0IFtwYXltZW50RGF0ZSwgc2V0UGF5bWVudERhdGVdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgICBjb25zdCBbc2hvd01vZGVsT25Ib2xkLCBzZXRTaG93TW9kZWxPbkhvbGRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2N1cnJlbnRHcm91cCwgc2V0Q3VycmVudEdyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gICAgY29uc3QgW2FkbWluSWQsIHNldEFkbWluSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbd2l0aGRyYXdMb2FkaW5nLCBzZXRXaXRoZHJhd0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3Jhd1RyYW5zYWN0aW9ucywgc2V0UmF3VHJhbnNhY3Rpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuICAgIGNvbnN0IFtkZWR1Y3Rpb25BbW91bnQsIHNldERlZHVjdGlvbkFtb3VudF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICAgIGNvbnN0IFt0aGlyZFBhcnR5RW5hYmxlLCBzZXRUaGlyZFBhcnR5RW5hYmxlXSA9IHVzZVN0YXRlKHtcclxuICAgICAgICBzZW5kX3doYXRzYXBwOiBmYWxzZSxcclxuICAgICAgICBzZW5kX2dtYWlsOiBmYWxzZSxcclxuICAgICAgICBzZW5kX3NtczogZmFsc2UsXHJcbiAgICB9KTtcclxuICAgIGNvbnN0IFtlbnJvbGxtZW50T3BlcmF0aW9uLCBzZXRFbnJvbGxtZW50T3BlcmF0aW9uXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gICAgY29uc3QgW2FjdGlvbkxvYWRpbmcsIHNldEFjdGlvbkxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAgIC8vIEFsZXJ0IHN0YXRlXHJcbiAgICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT0gSGVscGVyIEZ1bmN0aW9ucyA9PT09PT09PT09PT09PT09PT09PVxyXG4gICAgY29uc3QgcmVzZXRGb3JtID0gKCkgPT4ge1xyXG4gICAgICAgIHNldFRvdGFsQW1vdW50KG51bGwpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkRW5yb2xsSWQobnVsbCk7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRFbnJvbGwobnVsbCk7XHJcbiAgICAgICAgc2V0TW92ZVJlbWFyayhcIlwiKTtcclxuICAgICAgICBzZXRSZW1hcmtUeXBlKG51bGwpO1xyXG4gICAgICAgIHNldEN1c3RvbVJlbWFyayhcIlwiKTtcclxuICAgICAgICBzZXRBdmFpbGFibGVBbW91bnQoMCk7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRVc2VySWQobnVsbCk7XHJcbiAgICAgICAgc2V0Q29uZmlybUlucHV0KFwiXCIpO1xyXG4gICAgICAgIHNldFN0ZXAoMSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNsb3NlTW9kYWwgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICByZXNldEZvcm0oKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgdG90YWxQYWlkID0gd2l0aGRyYXdEYXRhPy50b3RhbF9wYWlkO1xyXG5cclxuICAgIC8vIFJlY2FsY3VsYXRlIGFtb3VudCBmcm9tIHBlcmNlbnRhZ2UgKGNhbGxlZCBvbkJsdXIpXHJcbiAgICBjb25zdCBoYW5kbGVQZXJjZW50Qmx1ciA9ICgpID0+IHtcclxuICAgICAgICBpZiAoIWVkaXRhYmxlSW50ZXJlc3QgfHwgdG90YWxQYWlkIDw9IDApIHtcclxuICAgICAgICAgICAgc2V0RGVkdWN0aW9uQW1vdW50KFwiXCIpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHBlcmNlbnQgPSBwYXJzZUZsb2F0KGVkaXRhYmxlSW50ZXJlc3QpO1xyXG4gICAgICAgIGlmIChpc05hTihwZXJjZW50KSB8fCBwZXJjZW50IDwgMCkge1xyXG4gICAgICAgICAgICBzZXREZWR1Y3Rpb25BbW91bnQoXCJcIik7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgY2FsY3VsYXRlZEFtb3VudCA9IChwZXJjZW50IC8gMTAwKSAqIHRvdGFsUGFpZDtcclxuICAgICAgICBzZXREZWR1Y3Rpb25BbW91bnQoY2FsY3VsYXRlZEFtb3VudC50b0ZpeGVkKDIpKTtcclxuICAgIH07XHJcblxyXG4gICAgLy8gUmVjYWxjdWxhdGUgcGVyY2VudGFnZSBmcm9tIGFtb3VudCAoY2FsbGVkIG9uQmx1cilcclxuICAgIGNvbnN0IGhhbmRsZUFtb3VudEJsdXIgPSAoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFkZWR1Y3Rpb25BbW91bnQgfHwgdG90YWxQYWlkIDw9IDApIHtcclxuICAgICAgICAgICAgc2V0RWRpdGFibGVJbnRlcmVzdChcIlwiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCBhbW91bnQgPSBwYXJzZUZsb2F0KGRlZHVjdGlvbkFtb3VudCk7XHJcbiAgICAgICAgaWYgKGlzTmFOKGFtb3VudCkgfHwgYW1vdW50IDwgMCkge1xyXG4gICAgICAgICAgICBzZXRFZGl0YWJsZUludGVyZXN0KFwiXCIpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGNhbGN1bGF0ZWRQZXJjZW50ID0gKGFtb3VudCAvIHRvdGFsUGFpZCkgKiAxMDA7XHJcbiAgICAgICAgc2V0RWRpdGFibGVJbnRlcmVzdChjYWxjdWxhdGVkUGVyY2VudC50b0ZpeGVkKDIpKTtcclxuICAgIH07XHJcblxyXG4gICAgLy8gU3luY2hyb25pemUgYm90aCBmaWVsZHMgKGNhbGxlZCBvbiBidXR0b24gY2xpY2spXHJcbiAgICBjb25zdCBoYW5kbGVTeW5jRmllbGRzID0gKCkgPT4ge1xyXG4gICAgICAgIGlmIChlZGl0YWJsZUludGVyZXN0ICYmIHRvdGFsUGFpZCA+IDApIHtcclxuICAgICAgICAgICAgY29uc3QgcGVyY2VudCA9IHBhcnNlRmxvYXQoZWRpdGFibGVJbnRlcmVzdCk7XHJcbiAgICAgICAgICAgIGlmICghaXNOYU4ocGVyY2VudCkgJiYgcGVyY2VudCA+PSAwKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBhbXQgPSAocGVyY2VudCAvIDEwMCkgKiB0b3RhbFBhaWQ7XHJcbiAgICAgICAgICAgICAgICBzZXREZWR1Y3Rpb25BbW91bnQoYW10LnRvRml4ZWQoMCkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmIChkZWR1Y3Rpb25BbW91bnQgJiYgdG90YWxQYWlkID4gMCkge1xyXG4gICAgICAgICAgICBjb25zdCBhbXQgPSBwYXJzZUZsb2F0KGRlZHVjdGlvbkFtb3VudCk7XHJcbiAgICAgICAgICAgIGlmICghaXNOYU4oYW10KSAmJiBhbXQgPj0gMCkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcGN0ID0gKGFtdCAvIHRvdGFsUGFpZCkgKiAxMDA7XHJcbiAgICAgICAgICAgICAgICBzZXRFZGl0YWJsZUludGVyZXN0KHBjdC50b0ZpeGVkKDIpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCB1c2VyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgICAgIGlmICh1c2VyKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG4gICAgICAgICAgICBzZXRBZG1pbklkKHVzZXJPYmo/Ll9pZCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgW10pO1xyXG5cclxuICAgIC8vIEZldGNoIHVzZXJzIGZvciBkcm9wZG93biAodXNlZCBpbiBUcmFuc2FjdGlvbiBIaXN0b3J5KVxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcInVzZXIvdmVyaWZpZWRcIik7XHJcbiAgICAgICAgICAgICAgICBzZXRVc2VycyhyZXMuZGF0YT8uZGF0YSB8fCBbXSk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlcnNcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBmZXRjaFVzZXJzKCk7XHJcbiAgICB9LCBbXSk7XHJcblxyXG5cclxuICAgIC8vIFJlY2FsY3VsYXRlIE5ldCBQYXlhYmxlIHdoZW5ldmVyIEdyb3NzIEFtb3VudCBvciBTZXJ2aWNlIENoYXJnZSBjaGFuZ2VzXHJcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGdyb3NzID0gTnVtYmVyKHRvdGFsQW1vdW50KSB8fCAwO1xyXG4gICAgICAgIGNvbnN0IGNoYXJnZSA9IE51bWJlcihzZXJ2aWNlQ2hhcmdlKSB8fCAwO1xyXG4gICAgICAgIGNvbnN0IGdzdCA9IE51bWJlcihnc3RBbW91bnQpIHx8IDA7XHJcbiAgICAgICAgY29uc3QgbmV0ID0gZ3Jvc3MgLSBjaGFyZ2UgLSBnc3Q7XHJcbiAgICAgICAgc2V0RmluYWxBbW91bnQobmV0ID49IDAgPyBuZXQgOiAwKTtcclxuICAgIH0sIFt0b3RhbEFtb3VudCwgc2VydmljZUNoYXJnZSwgZ3N0QW1vdW50XSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCBzdGF0dXMgPSBwaWdteURhdGE/LlswXT8ucmVxdWVzdF9zdGF0dXM7XHJcbiAgICAgICAgaWYgKHN0YXR1cyA9PT0gXCJBUFBST1ZFRFwiKSB7XHJcbiAgICAgICAgICAgIG5vdGlmaWNhdGlvbi5zdWNjZXNzKHtcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGlnbXkgV2l0aGRyYXdhbCBDb21wbGV0ZWRcIixcclxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBcIlBpZ215IHdpdGhkcmF3YWwgY29tcGxldGVkLiBHbyB0byBQaWdteSBQYXltZW50IE91dCBwYWdlIHRvIHZpZXcgcmVtYWluaW5nIHBheW91dC5cIixcclxuICAgICAgICAgICAgICAgIHBsYWNlbWVudDogXCJ0b3BSaWdodFwiLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICB9LCBbcGlnbXlEYXRhXSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAobG9jYXRpb24uc3RhdGU/LmFjdGl2ZVRhYikge1xyXG4gICAgICAgICAgICB3aW5kb3cuaGlzdG9yeS5yZXBsYWNlU3RhdGUoe30sIGRvY3VtZW50LnRpdGxlKTtcclxuICAgICAgICB9XHJcbiAgICB9LCBbbG9jYXRpb25dKTtcclxuXHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT0gUXVpY2tTZWFyY2ggc2VsZWN0aW9uIGhhbmRsZXIgPT09PT09PT09PT09PT09PT09PT1cclxuICAgIGNvbnN0IGhhbmRsZVF1aWNrU2VhcmNoU2VsZWN0ID0gKHJlY29yZCkgPT4ge1xyXG4gICAgICAgIGlmICghcmVjb3JkKSByZXR1cm47XHJcbiAgICAgICAgY29uc3QgY3VzdG9tZXIgPSB7XHJcbiAgICAgICAgICAgIF9pZDogcmVjb3JkLl9pZCxcclxuICAgICAgICAgICAgZnVsbF9uYW1lOiByZWNvcmQubmFtZSxcclxuICAgICAgICAgICAgcGhvbmVfbnVtYmVyOiByZWNvcmQucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICBhZGhhYXJfbm86IHJlY29yZC5hYWRoYWFyX251bWJlcixcclxuICAgICAgICB9O1xyXG4gICAgICAgIHNldFNlbGVjdGVkQ3VzdG9tZXIoY3VzdG9tZXIpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkRW5yb2xsbWVudERhdGEobnVsbCk7XHJcbiAgICAgICAgLy8gc2V0QWN0aXZlQWN0aW9uVHlwZShudWxsKTtcclxuICAgICAgICBmZXRjaEN1c3RvbWVyUG9ydGZvbGlvKHJlY29yZC5faWQpO1xyXG5cclxuICAgICAgICAvLyBSZXNldCBRdWlja1NlYXJjaENvbnRlbnQgYnkgdXBkYXRpbmcgaXRzIGtleVxyXG4gICAgICAgIHNldFF1aWNrU2VhcmNoS2V5KChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcblxyXG4gICAgICAgIC8vIFNjcm9sbCB0byB0aGUgcG9ydGZvbGlvIHNlY3Rpb24gYWZ0ZXIgYSBzaG9ydCBkZWxheVxyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBwb3J0Zm9saW9FbGVtZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjdXN0b21lci1wb3J0Zm9saW9cIik7XHJcbiAgICAgICAgICAgIGlmIChwb3J0Zm9saW9FbGVtZW50KSB7XHJcbiAgICAgICAgICAgICAgICBwb3J0Zm9saW9FbGVtZW50LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6IFwic21vb3RoXCIsIGJsb2NrOiBcInN0YXJ0XCIgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LCAzMDApO1xyXG4gICAgfTtcclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PSBQb3J0Zm9saW8gTG9naWMgPT09PT09PT09PT09PT09PT09PT1cclxuICAgIGNvbnN0IGZldGNoQ3VzdG9tZXJQb3J0Zm9saW8gPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICAgICAgaWYgKCF1c2VySWQpIHtcclxuICAgICAgICAgICAgc2V0Q3VzdG9tZXJFbnJvbGxtZW50cyhbXSk7XHJcbiAgICAgICAgICAgIHNldFBpZ215RGF0YShbXSk7XHJcbiAgICAgICAgICAgIHNldExvYW5EYXRhKFtdKTtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50RGF0YShudWxsKTtcclxuICAgICAgICAgICAgLy8gc2V0QWN0aXZlQWN0aW9uVHlwZShudWxsKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc2V0TG9hZGluZ0Vucm9sbG1lbnRzKHRydWUpO1xyXG4gICAgICAgIHNldExvYWRpbmdQaWdteSh0cnVlKTtcclxuICAgICAgICBzZXRMb2FkaW5nTG9hbnModHJ1ZSk7XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IFtlbnJvbGxSZXN1bHQsIHBpZ215UmVzdWx0LCBsb2FuUmVzdWx0XSA9XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBQcm9taXNlLmFsbFNldHRsZWQoW1xyXG4gICAgICAgICAgICAgICAgICAgIGFwaS5wb3N0KGAvZW5yb2xsL2dldC11c2VyLXRpY2tldHMtcmVwb3J0LyR7dXNlcklkfWApLFxyXG4gICAgICAgICAgICAgICAgICAgIGFwaS5nZXQoYC9wYXltZW50L3BpZ21lL3VzZXIvJHt1c2VySWR9YCksXHJcbiAgICAgICAgICAgICAgICAgICAgYXBpLmdldChgL3BheW1lbnQvbG9hbi91c2VyLyR7dXNlcklkfWApLFxyXG4gICAgICAgICAgICAgICAgXSk7XHJcblxyXG4gICAgICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgICAgICAgLy8gRU5ST0xMTUVOVCBEQVRBXHJcbiAgICAgICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAgICAgICBpZiAoZW5yb2xsUmVzdWx0LnN0YXR1cyA9PT0gXCJmdWxmaWxsZWRcIikge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVwb3J0RGF0YSA9IGVucm9sbFJlc3VsdC52YWx1ZT8uZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgICAgICAgICAgICAvLyBHZXQgdW5pcXVlIGdyb3VwIElEcyBmcm9tIGN1c3RvbWVyIHBvcnRmb2xpb1xyXG4gICAgICAgICAgICAgICAgY29uc3QgZ3JvdXBJZHMgPSBbXHJcbiAgICAgICAgICAgICAgICAgICAgLi4ubmV3IFNldChcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVwb3J0RGF0YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLm1hcCgoaXRlbSkgPT4gaXRlbT8uZW5yb2xsbWVudD8uZ3JvdXA/Ll9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoQm9vbGVhbilcclxuICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgXTtcclxuXHJcbiAgICAgICAgICAgICAgICAvLyBGZXRjaCBlbnJvbGxtZW50IGRldGFpbHMgZm9yIGV2ZXJ5IGdyb3VwXHJcbiAgICAgICAgICAgICAgICBjb25zdCBncm91cEVucm9sbFJlc3VsdHMgPSBhd2FpdCBQcm9taXNlLmFsbFNldHRsZWQoXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBJZHMubWFwKChncm91cElkKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcGkuZ2V0KGAvZW5yb2xsL2dldC1ncm91cC1lbnJvbGwvJHtncm91cElkfWApXHJcbiAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgICAvLyBBZGQgYWN0dWFsIGVucm9sbG1lbnQgSUQgdG8gcG9ydGZvbGlvIGRhdGFcclxuICAgICAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRFbnJvbGxtZW50cyA9IHJlcG9ydERhdGEubWFwKChpdGVtKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZ3JvdXBJZCA9IGl0ZW0/LmVucm9sbG1lbnQ/Lmdyb3VwPy5faWQ7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlc3VsdEluZGV4ID0gZ3JvdXBJZHMuaW5kZXhPZihncm91cElkKTtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBncm91cEVucm9sbFJlc3VsdCA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwRW5yb2xsUmVzdWx0c1tyZXN1bHRJbmRleF07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGxldCBlbnJvbGxtZW50RGV0YWlscyA9IG51bGw7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChncm91cEVucm9sbFJlc3VsdD8uc3RhdHVzID09PSBcImZ1bGZpbGxlZFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cEVucm9sbFJlc3VsdC52YWx1ZT8uZGF0YTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyb3VwRW5yb2xsbWVudHMgPSBBcnJheS5pc0FycmF5KHJlc3BvbnNlRGF0YSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gcmVzcG9uc2VEYXRhXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHJlc3BvbnNlRGF0YT8uZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZpbmQgZW5yb2xsbWVudCBiZWxvbmdpbmcgdG8gc2VsZWN0ZWQgY3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZW5yb2xsbWVudERldGFpbHMgPSBncm91cEVucm9sbG1lbnRzLmZpbmQoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZW5yb2xsbWVudCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGVucm9sbG1lbnRVc2VySWQgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnJvbGxtZW50Py51c2VyX2lkPy5faWQgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW5yb2xsbWVudD8udXNlcl9pZDtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RyaW5nKGVucm9sbG1lbnRVc2VySWQpID09PVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTdHJpbmcodXNlcklkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5pdGVtLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQWN0dWFsIGVucm9sbG1lbnQgZG9jdW1lbnQgSURcclxuICAgICAgICAgICAgICAgICAgICAgICAgZW5yb2xsbWVudElkOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW5yb2xsbWVudERldGFpbHM/Ll9pZCB8fCBudWxsLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gS2VlcCBjb21wbGV0ZSBlbnJvbGxtZW50IG9iamVjdCBpZiByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbnJvbGxtZW50RGV0YWlsczpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVucm9sbG1lbnREZXRhaWxzIHx8IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgc2V0Q3VzdG9tZXJFbnJvbGxtZW50cyh1cGRhdGVkRW5yb2xsbWVudHMpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcclxuICAgICAgICAgICAgICAgICAgICBcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnRzOlwiLFxyXG4gICAgICAgICAgICAgICAgICAgIGVucm9sbFJlc3VsdC5yZWFzb25cclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgICAgc2V0Q3VzdG9tZXJFbnJvbGxtZW50cyhbXSk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAgICAgICAvLyBQSUdNWSBEQVRBXHJcbiAgICAgICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAgICAgICBpZiAocGlnbXlSZXN1bHQuc3RhdHVzID09PSBcImZ1bGZpbGxlZFwiKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCByYXdEYXRhID1cclxuICAgICAgICAgICAgICAgICAgICBwaWdteVJlc3VsdC52YWx1ZS5kYXRhPy5vdmVyYWxsX3BpZ21lIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgcGlnbXlSZXN1bHQudmFsdWU/Lm92ZXJhbGxfcGlnbWUgfHxcclxuICAgICAgICAgICAgICAgICAgICBbXTtcclxuXHJcbiAgICAgICAgICAgICAgICBjb25zdCB0cmFuc2Zvcm1lZFBpZ215ID0gcmF3RGF0YS5tYXAoKGl0ZW0pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBwaWdtZSA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ucGlnbWVfZGV0YWlscz8ucGlnbWUgfHwge307XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLml0ZW0sXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBfaWQ6IHBpZ21lLl9pZCxcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVlc3Rfc3RhdHVzOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGlnbWUucmVxdWVzdF9zdGF0dXMgfHwgbnVsbCxcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEZsYXR0ZW4gdXNlZnVsIGZpZWxkc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXR1cml0eV9wZXJpb2Q6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWdtZS5tYXR1cml0eV9wZXJpb2QsXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXlhYmxlX2Ftb3VudDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBpZ21lLnBheWFibGVfYW1vdW50LFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgZHVyYXRpb246XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWdtZS5kdXJhdGlvbixcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXJ0X2RhdGU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWdtZS5zdGFydF9kYXRlLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGlnbWVfaWQ6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWdtZS5waWdtZV9pZCxcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1hdHVyaXR5X2ludGVyZXN0OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGlnbWUubWF0dXJpdHlfaW50ZXJlc3QsXHJcbiAgICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHNldFBpZ215RGF0YSh0cmFuc2Zvcm1lZFBpZ215KTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihcclxuICAgICAgICAgICAgICAgICAgICBcIlVzZXIgaGFzIG5vIHBpZ215IGRhdGEgb3IgQVBJIGZhaWxlZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIHBpZ215UmVzdWx0LnJlYXNvblxyXG4gICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgICBzZXRQaWdteURhdGEoW10pO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgICAgICAgLy8gTE9BTiBEQVRBXHJcbiAgICAgICAgICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICAgICAgICBpZiAobG9hblJlc3VsdC5zdGF0dXMgPT09IFwiZnVsZmlsbGVkXCIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IGxvYW5zID1cclxuICAgICAgICAgICAgICAgICAgICBsb2FuUmVzdWx0LnZhbHVlLmRhdGE/Lm92ZXJhbGxfbG9hbiB8fCBbXTtcclxuXHJcbiAgICAgICAgICAgICAgICBzZXRMb2FuRGF0YShsb2Fucyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKFxyXG4gICAgICAgICAgICAgICAgICAgIFwiRXJyb3IgZmV0Y2hpbmcgbG9hbnM6XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgbG9hblJlc3VsdC5yZWFzb25cclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgICAgc2V0TG9hbkRhdGEoW10pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcclxuICAgICAgICAgICAgICAgIFwiVW5leHBlY3RlZCBlcnJvciBpbiBwb3J0Zm9saW8gZmV0Y2g6XCIsXHJcbiAgICAgICAgICAgICAgICBlcnJvclxyXG4gICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgc2V0Q3VzdG9tZXJFbnJvbGxtZW50cyhbXSk7XHJcbiAgICAgICAgICAgIHNldFBpZ215RGF0YShbXSk7XHJcbiAgICAgICAgICAgIHNldExvYW5EYXRhKFtdKTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nRW5yb2xsbWVudHMoZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nUGlnbXkoZmFsc2UpO1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nTG9hbnMoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgY2hlY2tDdXN0b21lck9wZXJhdGlvbkFsbG93ZWQgPSAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgc3RhdHVzID1cclxuICAgICAgICAgICAgc2VsZWN0ZWRFbnJvbGxtZW50RGF0YT8uZW5yb2xsbWVudD8uY3VzdG9tZXJfc3RhdHVzIHx8XHJcbiAgICAgICAgICAgIHNlbGVjdGVkRW5yb2xsbWVudERhdGE/LmN1c3RvbWVyX3N0YXR1cyB8fFxyXG4gICAgICAgICAgICBzZWxlY3RlZEVucm9sbG1lbnREYXRhPy5lbnJvbGxtZW50RGV0YWlscz8uY3VzdG9tZXJfc3RhdHVzIHx8XHJcbiAgICAgICAgICAgIFwiXCI7XHJcblxyXG4gICAgICAgIGNvbnN0IG5vcm1hbGl6ZWRTdGF0dXMgPSBzdGF0dXMudHJpbSgpLnRvTG93ZXJDYXNlKCk7XHJcblxyXG4gICAgICAgIGlmIChbXCJvbiBob2xkXCIsIFwiaW5hY3RpdmVcIl0uaW5jbHVkZXMobm9ybWFsaXplZFN0YXR1cykpIHtcclxuICAgICAgICAgICAgbWVzc2FnZS53YXJuaW5nKFxyXG4gICAgICAgICAgICAgICAgYEN1c3RvbWVyIGlzICR7c3RhdHVzfS4gTm8gb3BlcmF0aW9ucyBhcmUgYWxsb3dlZC5gXHJcbiAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdHJ1ZTtcclxuICAgIH07XHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PT09PSBQaWdteSBXaXRoZHJhdyBSZXF1ZXN0ID09PT09PT09PT09PT09PT09PT09XHJcbiAgICBjb25zdCBoYW5kbGVSYWlzZVdpdGhkcmF3UmVxdWVzdCA9IGFzeW5jIChwaWdteUlkKSA9PiB7XHJcbiAgICAgICAgaWYgKCFwaWdteUlkKSB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJJbnZhbGlkIHBpZ215IElEXCIpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldFJhaXNpbmdSZXF1ZXN0TG9hZGluZyh0cnVlKTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBhd2FpdCBhcGkucGF0Y2goYC92MS9hZG1pbi9waWdtZXMvc3RhdHVzLyR7cGlnbXlJZH1gLCB7XHJcbiAgICAgICAgICAgICAgICByZXF1ZXN0X3N0YXR1czogXCJSRVFVRVNURURcIlxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgc2V0UGlnbXlEYXRhKHByZXYgPT5cclxuICAgICAgICAgICAgICAgIHByZXYubWFwKHAgPT5cclxuICAgICAgICAgICAgICAgICAgICBwLl9pZCA9PT0gcGlnbXlJZCA/IHsgLi4ucCwgcmVxdWVzdF9zdGF0dXM6IFwiUkVRVUVTVEVEXCIgfSA6IHBcclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgY29uc3QgY3VzdG9tZXJOYW1lID0gc2VsZWN0ZWRDdXN0b21lcj8uZnVsbF9uYW1lIHx8IFwiQ3VzdG9tZXJcIjtcclxuICAgICAgICAgICAgY29uc3QgYW1vdW50ID0gcGlnbXlEYXRhLmZpbmQocCA9PiBwLl9pZCA9PT0gcGlnbXlJZCk/LnRvdGFsX2RlcG9zaXRlZF9hbW91bnQgfHwgMDtcclxuICAgICAgICAgICAgbm90aWZpY2F0aW9uLnN1Y2Nlc3Moe1xyXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJQaWdteSBXaXRoZHJhd2FsIFJlcXVlc3RcIixcclxuICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBgJHtjdXN0b21lck5hbWV9IGhhcyByYWlzZWQgYSB3aXRoZHJhd2FsIHJlcXVlc3Qgb2Yg4oK5JHthbW91bnR9YCxcclxuICAgICAgICAgICAgICAgIHBsYWNlbWVudDogXCJ0b3BSaWdodFwiLFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgcmFpc2luZyB3aXRoZHJhdyByZXF1ZXN0OlwiLCBlcnJvcik7XHJcbiAgICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gcmFpc2Ugd2l0aGRyYXcgcmVxdWVzdFwiKTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRSYWlzaW5nUmVxdWVzdExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgLy8gRmV0Y2ggcGlnbXkgZGV0YWlscyBmb3Igd2l0aGRyYXdhbCBtb2RhbFxyXG4gICAgY29uc3QgZmV0Y2hQaWdteURldGFpbHMgPSBhc3luYyAocGlnbXlJZCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3YxL2FkbWluL3BpZ21lcy8ke3BpZ215SWR9YCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhLnN1Y2Nlc3MpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhLmRhdGE7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcGlnbXkgZGF0YVwiKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBwaWdteSBkZXRhaWxzOlwiLCBlcnJvcik7XHJcbiAgICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJDb3VsZCBub3QgbG9hZCBwaWdteSBkZXRhaWxzXCIpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZU9wZW5XaXRoZHJhd01vZGFsID0gYXN5bmMgKHBpZ215SWQpID0+IHtcclxuICAgICAgICBjb25zdCBkZXRhaWxzID0gYXdhaXQgZmV0Y2hQaWdteURldGFpbHMocGlnbXlJZCk7XHJcbiAgICAgICAgaWYgKGRldGFpbHMpIHtcclxuICAgICAgICAgICAgc2V0V2l0aGRyYXdEYXRhKGRldGFpbHMpO1xyXG4gICAgICAgICAgICBzZXRFZGl0YWJsZUludGVyZXN0KGRldGFpbHMucHJlX21hdHVyZWRfaW50ZXJlc3Q/LnRvU3RyaW5nKCkgfHwgXCJcIik7XHJcbiAgICAgICAgICAgIHNldFNob3dDYWxjdWxhdGVkKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0U2hvd1dpdGhkcmF3TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVSZWNhbGN1bGF0ZSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgICAgICBpZiAoIWVkaXRhYmxlSW50ZXJlc3QpIHtcclxuICAgICAgICAgICAgbmV3RXJyb3JzLmVkaXRhYmxlSW50ZXJlc3QgPSBcIkVudGVyIHRoZSBJbnRlcmVzdCByZXF1aXJlZCB0byBjYWxjdWxhdGUgTWF0dXJpdHkgYW1vdW50XCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgICAgIGlmIChPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA+IDApIHJldHVybjtcclxuXHJcbiAgICAgICAgaWYgKCF3aXRoZHJhd0RhdGEpIHJldHVybjtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wdXQoYC92MS9hZG1pbi9waWdtZXMvcGlnbWUtY2xvc2VyLyR7d2l0aGRyYXdEYXRhLl9pZH1gLCB7XHJcbiAgICAgICAgICAgICAgICBwcmVfbWF0dXJlZF9pbnRlcmVzdDogZWRpdGFibGVJbnRlcmVzdCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZS5kYXRhLnN0YXR1cykge1xyXG4gICAgICAgICAgICAgICAgc2V0V2l0aGRyYXdEYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCAuLi5yZXNwb25zZS5kYXRhLmRhdGEgfSkpO1xyXG4gICAgICAgICAgICAgICAgc2V0U2hvd0NhbGN1bGF0ZWQodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJSZWNhbGN1bGF0aW9uIHN1Y2Nlc3NmdWxcIik7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYWxjdWxhdGlvbiBmYWlsZWRcIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgY2FsY3VsYXRpbmcgd2l0aGRyYXdhbDpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICBtZXNzYWdlLmVycm9yKGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIGNhbGN1bGF0ZVwiKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG4gICAgY29uc3QgaGFuZGxlV2l0aGRyYXcgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgYWRtaW4gPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKSB8fCBcInt9XCIpO1xyXG4gICAgICAgIGlmICghd2l0aGRyYXdEYXRhKSByZXR1cm47XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgc2V0V2l0aGRyYXdMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgICAgICAgcmVtb3ZhbFJlYXNvbjogXCJQaWdteSBXaXRoZHJhd2FsXCIsXHJcbiAgICAgICAgICAgICAgICBuZXRQYXlhYmxlOiB3aXRoZHJhd0RhdGEubWF0dXJpdHlfYW1vdW50LFxyXG4gICAgICAgICAgICAgICAgYWRtaW5JZDogYWRtaW4uX2lkLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBhd2FpdCBhcGkucG9zdChgL3YxL2FkbWluL3BpZ21lcy8ke3dpdGhkcmF3RGF0YS5faWR9L2FkbWlucy8ke2FkbWluSWR9L3JlbW92ZWAsIHBheWxvYWQpO1xyXG4gICAgICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJQaWdteSB3aXRoZHJhd2FsIGNvbXBsZXRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgICAgICAgIHNldFNob3dXaXRoZHJhd01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0V2l0aGRyYXdEYXRhKG51bGwpO1xyXG4gICAgICAgICAgICBzZXRTaG93Q2FsY3VsYXRlZChmYWxzZSk7XHJcbiAgICAgICAgICAgIC8vIFJlZnJlc2ggcG9ydGZvbGlvIHRvIHJlZmxlY3QgdXBkYXRlZCBzdGF0dXNcclxuICAgICAgICAgICAgaWYgKHNlbGVjdGVkQ3VzdG9tZXI/Ll9pZCkge1xyXG4gICAgICAgICAgICAgICAgZmV0Y2hDdXN0b21lclBvcnRmb2xpbyhzZWxlY3RlZEN1c3RvbWVyLl9pZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgcmVtb3ZpbmcgcGlnbXk6XCIsIGVycm9yKTtcclxuICAgICAgICAgICAgbWVzc2FnZS5lcnJvcihlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBjb21wbGV0ZSB3aXRoZHJhd2FsXCIpO1xyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldFdpdGhkcmF3TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVBY3Rpb25DbGljayA9IChhY3Rpb25UeXBlLCBjb250ZXh0RGF0YSkgPT4ge1xyXG4gICAgICAgIHNldEFjdGlvbkxvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICAgIGlmICghYWN0aXZlQWN0aW9uVHlwZSkge1xyXG4gICAgICAgICAgICBzZXRBY3RpdmVBY3Rpb25UeXBlKGFjdGlvblR5cGUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgeyBlbnJvbGxtZW50IH0gPSBjb250ZXh0RGF0YSB8fCB7fTtcclxuICAgICAgICBjb25zdCBlbnJvbGxtZW50SWQgPSBjb250ZXh0RGF0YT8uZW5yb2xsbWVudElkOyAgICAgICBcclxuICAgICAgICBjb25zdCBlbnJvbGxtZW50RGV0YWlscyA9IGNvbnRleHREYXRhPy5lbnJvbGxtZW50RGV0YWlscztcclxuXHJcbiAgICAgICAgaWYgKCFlbnJvbGxtZW50SWQpIHtcclxuICAgICAgICAgICAgbWVzc2FnZS5lcnJvcihcIkVucm9sbG1lbnQgSUQgbWlzc2luZy4gUGxlYXNlIHJlZnJlc2ggdGhlIHBhZ2Ugb3IgY29udGFjdCBzdXBwb3J0LlwiKTtcclxuICAgICAgICAgICAgc2V0QWN0aW9uTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNldFNlbGVjdGVkRW5yb2xsSWQoZW5yb2xsbWVudElkKTtcclxuICAgICAgICBzZXRTZWxlY3RlZEVucm9sbChlbnJvbGxtZW50RGV0YWlscyB8fCBlbnJvbGxtZW50KTtcclxuICAgICAgICBzZXRTZWxlY3RlZFVzZXJJZChcclxuICAgICAgICAgICAgZW5yb2xsbWVudERldGFpbHM/LnVzZXJfaWQ/Ll9pZCB8fFxyXG4gICAgICAgICAgICBlbnJvbGxtZW50Py51c2VyX2lkPy5faWQgfHxcclxuICAgICAgICAgICAgc2VsZWN0ZWRDdXN0b21lcj8uX2lkXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRTZWxlY3RlZEVucm9sbG1lbnREYXRhKGNvbnRleHREYXRhKTtcclxuXHJcbiAgICAgICAgaWYgKGFjdGlvblR5cGUuaW5jbHVkZXMoXCJDSElUXCIpKSB7XHJcbiAgICAgICAgICAgIGFkZFJlcXVlc3RGb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgICAgICAgICAgIGdyb3VwX2lkOiBlbnJvbGxtZW50RGV0YWlscz8uZ3JvdXBfaWQ/Ll9pZCB8fCBlbnJvbGxtZW50Py5ncm91cD8uX2lkLFxyXG4gICAgICAgICAgICAgICAgdGlja2V0OiBlbnJvbGxtZW50RGV0YWlscz8udGlja2V0cyB8fCBlbnJvbGxtZW50Py50aWNrZXRzLFxyXG4gICAgICAgICAgICAgICAgdXNlcl9pZDogZW5yb2xsbWVudERldGFpbHM/LnVzZXJfaWQ/Ll9pZCB8fCBlbnJvbGxtZW50Py51c2VyX2lkPy5faWQsXHJcbiAgICAgICAgICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICByZWFzb246IFwiXCIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gZWxzZSBpZiAoYWN0aW9uVHlwZS5pbmNsdWRlcyhcIlBJR01ZXCIpICYmIHNlbGVjdGVkQ3VzdG9tZXIpIHtcclxuICAgICAgICAgICAgYWRkUmVxdWVzdEZvcm0uc2V0RmllbGRzVmFsdWUoe1xyXG4gICAgICAgICAgICAgICAgdXNlcl9pZDogc2VsZWN0ZWRDdXN0b21lci5faWQsXHJcbiAgICAgICAgICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICByZWFzb246IFwiXCIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYWN0aW9uLWZvcm0tc2VjdGlvblwiKT8uc2Nyb2xsSW50b1ZpZXcoe1xyXG4gICAgICAgICAgICAgICAgYmVoYXZpb3I6IFwic21vb3RoXCIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBzZXRBY3Rpb25Mb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICB9LCAzMDApO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVBZGRDYW5jZWxSZXF1ZXN0ID0gYXN5bmMgKHZhbHVlcykgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIHNldENhbmNlbFJlcXVlc3RzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICAgICAgY29uc3QgcGF5bG9hZCA9IHsgLi4udmFsdWVzLCByZXF1ZXN0X3R5cGU6IGFjdGl2ZUFjdGlvblR5cGUgfHwgcmVxdWVzdFR5cGVGaWx0ZXIsIGFjdGlvbjogYWN0aXZlQWN0aW9uVHlwZSB9O1xyXG4gICAgICAgICAgICBhd2FpdCBhcGkucG9zdChcIi9jaGl0LWNhbmNsZS9jYW5jZWwtcmVxdWVzdHNcIiwgcGF5bG9hZCk7XHJcbiAgICAgICAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIlJlcXVlc3Qgc3VibWl0dGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICAgICAgc2V0SXNBZGRSZXF1ZXN0TW9kYWxPcGVuKGZhbHNlKTtcclxuICAgICAgICAgICAgYWRkUmVxdWVzdEZvcm0ucmVzZXRGaWVsZHMoKTtcclxuICAgICAgICAgICAgc2V0QWN0aXZlQWN0aW9uVHlwZShudWxsKTtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRDdXN0b21lcihudWxsKTtcclxuICAgICAgICAgICAgc2V0Q3VzdG9tZXJFbnJvbGxtZW50cyhbXSk7XHJcbiAgICAgICAgICAgIHNldFBpZ215RGF0YShbXSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBzdWJtaXQgcmVxdWVzdFwiKTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRDYW5jZWxSZXF1ZXN0c0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT09PT0gVHJhbnNhY3Rpb24gSGlzdG9yeSBMb2dpYyA9PT09PT09PT09PT09PT09PT09PVxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCBmZXRjaEVucm9sbG1lbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9lbnJvbGwvZ2V0LWVucm9sbFwiKTtcclxuICAgICAgICAgICAgICAgIHNldEVucm9sbG1lbnRzKFxyXG4gICAgICAgICAgICAgICAgICAgIChyZXMuZGF0YSB8fCBbXSkuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAoaXRlbSkgPT4gaXRlbS5ncm91cF9pZCAhPSBudWxsICYmIGl0ZW0udXNlcl9pZCAhPSBudWxsICYmIGl0ZW0udGlja2V0cyAhPSBudWxsXHJcbiAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50czpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBmZXRjaEVucm9sbG1lbnRzKCk7XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBjb25zdCBmZXRjaEluaXRpYWxEYXRhID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgW2dyb3VwUmVzLCB1c2VyUmVzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgICAgICAgICAgICBhcGkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKSxcclxuICAgICAgICAgICAgICAgICAgICBhcGkuZ2V0KFwidXNlci92ZXJpZmllZFwiKSxcclxuICAgICAgICAgICAgICAgIF0pO1xyXG4gICAgICAgICAgICAgICAgc2V0R3JvdXBzKGdyb3VwUmVzLmRhdGEgfHwgW10pO1xyXG4gICAgICAgICAgICAgICAgc2V0VXNlcnModXNlclJlcy5kYXRhPy5kYXRhIHx8IFtdKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBpbml0aWFsIGRhdGFcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBmZXRjaEluaXRpYWxEYXRhKCk7XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoc2VsZWN0ZWRFbnJvbGxJZCkgZmV0Y2hUb3RhbEFtb3VudCgpO1xyXG4gICAgICAgIGVsc2Ugc2V0VG90YWxBbW91bnQobnVsbCk7XHJcbiAgICB9LCBbc2VsZWN0ZWRFbnJvbGxJZF0pO1xyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgZmV0Y2hUcmFuc2FjdGlvbnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHBhcmFtcyA9IHt9O1xyXG4gICAgICAgICAgICAgICAgaWYgKGZpbHRlcnMuZ3JvdXBfaWQpIHBhcmFtcy5ncm91cF9pZCA9IGZpbHRlcnMuZ3JvdXBfaWQ7XHJcbiAgICAgICAgICAgICAgICBpZiAoZmlsdGVycy51c2VyX2lkKSBwYXJhbXMudXNlcl9pZCA9IGZpbHRlcnMudXNlcl9pZDtcclxuICAgICAgICAgICAgICAgIGlmIChmaWx0ZXJzLnN0YXJ0RGF0ZSkgcGFyYW1zLnN0YXJ0RGF0ZSA9IGZpbHRlcnMuc3RhcnREYXRlO1xyXG4gICAgICAgICAgICAgICAgaWYgKGZpbHRlcnMuZW5kRGF0ZSkgcGFyYW1zLmVuZERhdGUgPSBmaWx0ZXJzLmVuZERhdGU7XHJcbiAgICAgICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvdjEvYWRtaW4vdHJhbnNhY3Rpb24taGlzdG9yeS9cIiwgeyBwYXJhbXMgfSk7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8uZGF0YSkge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFJhd1RyYW5zYWN0aW9ucyhyZXNwb25zZS5kYXRhLmRhdGEgfHwgW10pO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLmRhdGEubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBIZWxwZXIgdG8gZm9ybWF0IGN1cnJlbmN5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGZvcm1hdEN1cnJlbmN5ID0gKHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUgIT0gbnVsbCAmJiAhaXNOYU4odmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBg4oK5JHtOdW1iZXIodmFsdWUpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCItXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGludGVyZXN0QW1vdW50ID0gaXRlbT8uaW50ZXJlc3RfYW1vdW50ID8/IGl0ZW0/LmludHJlc3RfYW1vdW50ID8/IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgZ3N0RGlzcGxheSA9IFwiLVwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXRlbS5nc3RfYW1vdW50ICE9IG51bGwgJiYgaXRlbS5nc3RfYW1vdW50ICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBGb3IgY2hpdCB0cmFuc2FjdGlvbnMsIHNob3cgR1NUIGFzIHJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3N0RGlzcGxheSA9IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiPntmb3JtYXRDdXJyZW5jeShpdGVtLmdzdF9hbW91bnQpfTwvc3Bhbj47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoaXRlbS5waWdtZV9pZCAmJiBPYmplY3Qua2V5cyhpdGVtLnBpZ21lX2lkKS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBGb3IgcGlnbXkgdHJhbnNhY3Rpb25zLCBzaG93IGludGVyZXN0IHdpdGggc2lnblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNQcmVNYXR1cmVkID0gaXRlbS5waWdtZV9pZD8uY2xvc3VyZV90eXBlID09PSBcIlBSRS1NQVRVUkVEXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzaWduID0gaXNQcmVNYXR1cmVkID8gXCItXCIgOiBcIitcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvbG9yQ2xhc3MgPSBpc1ByZU1hdHVyZWQgPyBcInRleHQtcmVkLTYwMFwiIDogXCJ0ZXh0LWdyZWVuLTYwMFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3N0RGlzcGxheSA9IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2NvbG9yQ2xhc3N9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2lnbn0ge2Zvcm1hdEN1cnJlbmN5KGludGVyZXN0QW1vdW50KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGludGVyZXN0QW1vdW50ICE9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBnc3REaXNwbGF5ID0gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIj57Zm9ybWF0Q3VycmVuY3koaW50ZXJlc3RBbW91bnQpfTwvc3Bhbj47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0ZTogaXRlbS50cmFuc2FjdGlvbl9kYXRlID8gZGF5anMoaXRlbS50cmFuc2FjdGlvbl9kYXRlKS5mb3JtYXQoXCJERC1NTS1ZWVlZXCIpIDogXCItXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyX25hbWU6IGl0ZW0uZW5yb2xsX2lkPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgaXRlbT8ucGlnbWVfaWQ/LmN1c3RvbWVyPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwX25hbWU6IGl0ZW0uZW5yb2xsX2lkPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBpdGVtPy5waWdtZV9pZD8ucGlnbWVfaWQgfHwgXCJOL0FcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpY2tldDogaXRlbS5lbnJvbGxfaWQ/LnRpY2tldHMgfHwgaXRlbT8ucGlnbWVfaWQ/LmNsb3N1cmVfdHlwZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYW1vdW50OiBmb3JtYXRDdXJyZW5jeShpdGVtLmFtb3VudCksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm9zc19hbW91bnQ6IGZvcm1hdEN1cnJlbmN5KGl0ZW0uZ3Jvc3NfYW1vdW50KSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdzdF9hbW91bnQ6IGdzdERpc3BsYXksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXJ2aWNlX2NoYXJnZTogZm9ybWF0Q3VycmVuY3koaXRlbS5zZXJ2aWNlX2NoYXJnZSksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWFzb246IGl0ZW0ucmVhc29uIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhZyBjb2xvcj17aXRlbS50cmFuc2FjdGlvbl90eXBlID09PSBcImNyZWRpdFwiID8gXCJncmVlblwiIDogXCJvcmFuZ2VcIn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRyYW5zYWN0aW9uX3R5cGU/LnRvVXBwZXJDYXNlKCkgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RhZz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhZG1pbjogaXRlbS5hZG1pbl9pZD8ubmFtZSB8fCBcIlN5c3RlbVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFRyYW5zYWN0aW9ucyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRPdmVydmlldyh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsQ291bnQ6IGZvcm1hdHRlZERhdGEubGVuZ3RoLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0b3RhbEFtb3VudDogcmVzcG9uc2UuZGF0YS5kYXRhLnJlZHVjZSgoYWNjLCBjdXJyKSA9PiBhY2MgKyAoY3Vyci5hbW91bnQgfHwgMCksIDApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRUcmFuc2FjdGlvbnMoW10pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHRyYW5zYWN0aW9uczpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICAgICAgc2V0VHJhbnNhY3Rpb25zKFtdKTtcclxuICAgICAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9O1xyXG4gICAgICAgIGZldGNoVHJhbnNhY3Rpb25zKCk7XHJcbiAgICB9LCBbZmlsdGVycywgcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICAgIGNvbnN0IHN0YXRzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFyYXdUcmFuc2FjdGlvbnMubGVuZ3RoKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgICAgICAgY29uc3QgY2hpdENhbmNlbCA9IHJhd1RyYW5zYWN0aW9ucy5maWx0ZXIoXHJcbiAgICAgICAgICAgIHQgPT4gdC5yZWFzb24gJiYgdC5yZWFzb24udG9Mb3dlckNhc2UoKS5pbmNsdWRlcygnY2FuY2VsJylcclxuICAgICAgICApO1xyXG4gICAgICAgIGNvbnN0IHBpZ215ID0gcmF3VHJhbnNhY3Rpb25zLmZpbHRlcih0ID0+IHQucGlnbWVfaWQpO1xyXG4gICAgICAgIGNvbnN0IGxvYW4gPSByYXdUcmFuc2FjdGlvbnMuZmlsdGVyKHQgPT4gdC5sb2FuX2lkKTtcclxuICAgICAgICAvLyBjb25zdCBsb2FuID0gcmF3VHJhbnNhY3Rpb25zLmZpbHRlcih0ID0+IHQucmVhc29uICYmIHQucmVhc29uLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ2xvYW4nKSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHN1bUFtb3VudCA9IChhcnIpID0+IGFyci5yZWR1Y2UoKHMsIHQpID0+IHMgKyAodC5hbW91bnQgfHwgMCksIDApO1xyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBjaGl0Q2FuY2VsOiB7IGNvdW50OiBjaGl0Q2FuY2VsLmxlbmd0aCwgYW1vdW50OiBzdW1BbW91bnQoY2hpdENhbmNlbCkgfSxcclxuICAgICAgICAgICAgcGlnbXk6IHsgY291bnQ6IHBpZ215Lmxlbmd0aCwgYW1vdW50OiBzdW1BbW91bnQocGlnbXkpIH0sXHJcbiAgICAgICAgICAgIGxvYW46IHsgY291bnQ6IGxvYW4ubGVuZ3RoLCBhbW91bnQ6IHN1bUFtb3VudChsb2FuKSB9LFxyXG4gICAgICAgICAgICB0b3RhbDoge1xyXG4gICAgICAgICAgICAgICAgY291bnQ6IHJhd1RyYW5zYWN0aW9ucy5sZW5ndGgsXHJcbiAgICAgICAgICAgICAgICBhbW91bnQ6IHJhd1RyYW5zYWN0aW9ucy5yZWR1Y2UoKHMsIHQpID0+IHMgKyAodC5hbW91bnQgfHwgMCksIDApLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgIH07XHJcbiAgICB9LCBbcmF3VHJhbnNhY3Rpb25zXSk7XHJcblxyXG4gICAgY29uc3Qgb25EYXRlUmFuZ2VDaGFuZ2UgPSAoZGF0ZXMpID0+IHtcclxuICAgICAgICBzZXRGaWx0ZXJzKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICBzdGFydERhdGU6IGRhdGVzID8gZGF0ZXNbMF0uZm9ybWF0KFwiWVlZWS1NTS1ERFwiKSA6IFwiXCIsXHJcbiAgICAgICAgICAgIGVuZERhdGU6IGRhdGVzID8gZGF0ZXNbMV0uZm9ybWF0KFwiWVlZWS1NTS1ERFwiKSA6IFwiXCIsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAodmFsdWUpID0+IHtcclxuICAgICAgICBjb25zdCBlbnJvbGwgPSBlbnJvbGxtZW50cy5maW5kKChlKSA9PiBlLl9pZCA9PT0gdmFsdWUpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkRW5yb2xsSWQodmFsdWUpO1xyXG4gICAgICAgIHNldFNlbGVjdGVkRW5yb2xsKGVucm9sbCk7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRVc2VySWQoZW5yb2xsPy51c2VyX2lkPy5faWQpO1xyXG4gICAgICAgIHNldFRvdGFsQW1vdW50KG51bGwpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBmZXRjaFRvdGFsQW1vdW50ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGlmICghc2VsZWN0ZWRFbnJvbGxJZCkgcmV0dXJuO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoYC92MS9hZG1pbi9lbnJvbGxzLyR7c2VsZWN0ZWRFbnJvbGxJZH0vcGF5bWVudHMvdG90YWxgKTtcclxuICAgICAgICAgICAgc2V0VG90YWxBbW91bnQocmVzLmRhdGE/LmRhdGE/LnRvdGFsX2Ftb3VudCB8fCAwKTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHRvdGFsIGFtb3VudFwiKTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IG9wZW5UcmFuc2Zlck1vZGFsID0gKCkgPT4ge1xyXG4gICAgICAgIGlmICghc2VsZWN0ZWRFbnJvbGxJZCB8fCAhdG90YWxBbW91bnQpIHtcclxuICAgICAgICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIHNlbGVjdCB1c2VyIGFuZCBjYWxjdWxhdGUgYW1vdW50IGZpcnN0XCIpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGZpbmFsUmVtYXJrID0gcmVtYXJrVHlwZSA9PT0gXCJPVEhFUlwiID8gY3VzdG9tUmVtYXJrIDogcmVtYXJrVHlwZTtcclxuICAgICAgICBpZiAoIWZpbmFsUmVtYXJrIHx8ICFmaW5hbFJlbWFyay50cmltKCkpIHtcclxuICAgICAgICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIHNlbGVjdCBvciBlbnRlciByZWFzb25cIik7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgc2V0TW92ZVJlbWFyayhmaW5hbFJlbWFyayk7XHJcbiAgICAgICAgc2V0U3RlcCgyKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlTW92ZUFtb3VudCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgICB1c2VySWQ6IHNlbGVjdGVkVXNlcklkLFxyXG4gICAgICAgICAgICByZW1vdmFsUmVhc29uOiBnZXRBY3Rpb25CdXR0b25UZXh0KGFjdGl2ZUFjdGlvblR5cGUpID09PSBcIkNsb3NlXCIgPyBcIkNoaXQgQ2xvc2VkXCIgOiBtb3ZlUmVtYXJrLFxyXG4gICAgICAgICAgICBwYXltZW50RGF0ZTogcGF5bWVudERhdGUgPyBwYXltZW50RGF0ZS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpIDogbnVsbCxcclxuICAgICAgICAgICAgbmV0UGF5YWJsZTogZmluYWxBbW91bnQsXHJcbiAgICAgICAgICAgIHNlcnZpY2VDaGFyZ2U6IHNlcnZpY2VDaGFyZ2UsXHJcbiAgICAgICAgICAgIGdzdEFtb3VudDogZ3N0QW1vdW50LFxyXG4gICAgICAgICAgICBncm9zc0Ftb3VudDogdG90YWxBbW91bnQsXHJcbiAgICAgICAgICAgIHNlbmRfd2hhdHNhcHA6IHRoaXJkUGFydHlFbmFibGU/LnNlbmRfd2hhdHNhcHAsXHJcbiAgICAgICAgICAgIHNlbmRfZ21haWw6IHRoaXJkUGFydHlFbmFibGU/LnNlbmRfZ21haWwsXHJcbiAgICAgICAgICAgIHNlbmRfc21zOiB0aGlyZFBhcnR5RW5hYmxlPy5zZW5kX3NtcyxcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgICAgICBhd2FpdCBhcGkucG9zdChgL3YxL2FkbWluL2Vucm9sbHMvJHtzZWxlY3RlZEVucm9sbElkfS9hZG1pbnMvJHthZG1pbklkfS9yZW1vdmVgLCBwYXlsb2FkKTtcclxuICAgICAgICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiQW1vdW50IHRyYW5zZmVycmVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICAgICAgc2V0QXZhaWxhYmxlQW1vdW50KHRvdGFsQW1vdW50KTtcclxuICAgICAgICAgICAgc2V0Q29uZmlybUlucHV0KFwiXCIpO1xyXG4gICAgICAgICAgICBzZXRTdGVwKDMpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gc3VibWl0IGFtb3VudFwiKTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZVRhYkNoYW5nZSA9IChrZXkpID0+IHtcclxuICAgICAgICBzZXRBY3RpdmVUYWJLZXkoa2V5KTtcclxuXHJcbiAgICAgICAgaWYgKGtleSA9PT0gXCJ0cmFuc2FjdGlvbi1oaXN0b3J5XCIpIHtcclxuICAgICAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgZmV0Y2hBbGxUcmFuc2FjdGlvbnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgaWYgKCFzZWxlY3RlZEVucm9sbElkKSB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2Uud2FybmluZyhcIlBsZWFzZSBzZWxlY3QgZW5yb2xsbWVudCBmaXJzdFwiKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgICAgICBzZXRPcGVuQW50RERyYXdlcih0cnVlKTtcclxuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChgL3YxL2FkbWluL2Vucm9sbHMvJHtzZWxlY3RlZEVucm9sbElkfS9wYXltZW50c2ApO1xyXG4gICAgICAgICAgICBzZXRMYXN0QWxsUGF5bWVudHMocmVzLmRhdGE/LmRhdGEgfHwgW10pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggdHJhbnNhY3Rpb25zXCIpO1xyXG4gICAgICAgICAgICBzZXRMYXN0QWxsUGF5bWVudHMoW10pO1xyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlVHJhbnNmZXJDbGljayA9IGFzeW5jIChpdGVtcykgPT4ge1xyXG4gICAgICAgIHNldFRyYW5zZmVyTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCB0aWNrZXQgPSBpdGVtcy5lbnJvbGxtZW50LnRpY2tldHM7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBJZCA9IGl0ZW1zLmVucm9sbG1lbnQuZ3JvdXAuX2lkO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldCgnL3YxL2FkbWluL2Vucm9sbHMvZ2V0LWFsbC1lbnJvbGxzJywge1xyXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7IHRpY2tldCwgZ3JvdXBJZCB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBjb25zdCBlbnJvbGxtZW50cyA9IHJlc3BvbnNlLmRhdGEuZGF0YSB8fCByZXNwb25zZS5kYXRhLmVucm9sbHMgfHwgW107XHJcbiAgICAgICAgICAgIGNvbnN0IHNvdXJjZUVucm9sbG1lbnQgPSBlbnJvbGxtZW50cy5maW5kKGUgPT5cclxuICAgICAgICAgICAgICAgIChlLnRpY2tldHMgfHwgZS50aWNrZXQpID09IHRpY2tldCAmJiBlLmdyb3VwX2lkPy5faWQgPT09IGdyb3VwSWRcclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgaWYgKCFzb3VyY2VFbnJvbGxtZW50KSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdObyBlbnJvbGxtZW50IGZvdW5kIGZvciB0aWNrZXQnLCB0aWNrZXQsICdncm91cCcsIGdyb3VwSWQpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbnN0IHNvdXJjZUVucm9sbG1lbnRJZCA9IHNvdXJjZUVucm9sbG1lbnQuX2lkO1xyXG4gICAgICAgICAgICBuYXZpZ2F0ZShgL3RyYW5zZmVyLW1lbnU/c291cmNlRW5yb2xsbWVudElkPSR7c291cmNlRW5yb2xsbWVudElkfWApO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gZmV0Y2ggZW5yb2xsbWVudCBJRDonLCBlcnIpO1xyXG4gICAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgICAgIHNldFRyYW5zZmVyTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVSZWZ1bmQgPSAoKSA9PiB7XHJcbiAgICAgICAgbmF2aWdhdGUoXHJcbiAgICAgICAgICAgIGAvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L2NoaXQtY2FuY2VsYXRpb24tcGF5LW91dD9hbW91bnQ9JHtmaW5hbEFtb3VudH0mdXNlcklkPSR7c2VsZWN0ZWRVc2VySWR9JnRvdGFsQW1vdW50PSR7dG90YWxBbW91bnR9JmRlZHVjdGlvbnM9JHtzZXJ2aWNlQ2hhcmdlfWBcclxuICAgICAgICApO1xyXG4gICAgICAgIGhhbmRsZUNsb3NlTW9kYWwoKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlVHJhbnNmZXJUb0RpZmZlcmVudEFjY291bnQgPSAoKSA9PiB7XHJcbiAgICAgICAgbmF2aWdhdGUoXHJcbiAgICAgICAgICAgIGAvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LWluLW1lbnUvY2hpdC1jYW5jZWxhdGlvbi1wYXktaW4/YW1vdW50PSR7YXZhaWxhYmxlQW1vdW50fSZ1c2VySWQ9JHtzZWxlY3RlZFVzZXJJZH1gXHJcbiAgICAgICAgKTtcclxuICAgICAgICBoYW5kbGVDbG9zZU1vZGFsKCk7XHJcbiAgICB9O1xyXG4gICAgLy8gVGFibGUgY29sdW1uc1xyXG4gICAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgICAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgICAgICB7IGtleTogXCJkYXRlXCIsIGhlYWRlcjogXCJEYXRlXCIgfSxcclxuICAgICAgICB7IGtleTogXCJ1c2VyX25hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwXCIgfSxcclxuICAgICAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiZ3Jvc3NfYW1vdW50XCIsIGhlYWRlcjogXCJHcm9zcyBBbW91bnRcIiwgd2lkdGg6IDE1MCB9LFxyXG4gICAgICAgIHsga2V5OiBcInNlcnZpY2VfY2hhcmdlXCIsIGhlYWRlcjogXCJTZXJ2aWNlIENoYXJnZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiZ3N0X2Ftb3VudFwiLCBoZWFkZXI6IFwiR1NUIC8gSW50ZXJlc3QgQW1vdW50XCIgfSxcclxuICAgICAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIk5ldCBQYXlhYmxlIEFtb3VudFwiLCB3aWR0aDogMTUwIH0sXHJcbiAgICAgICAgeyBrZXk6IFwicmVhc29uXCIsIGhlYWRlcjogXCJSZWFzb25cIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInR5cGVcIiwgaGVhZGVyOiBcIlR5cGVcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcImFkbWluXCIsIGhlYWRlcjogXCJQcm9jZXNzZWQgQnlcIiB9LFxyXG4gICAgXTtcclxuXHJcbiAgICBjb25zdCBjYW5jZWxDb2x1bW5zID0gW1xyXG4gICAgICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJJRFwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXBcIiB9LFxyXG4gICAgICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgICAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudFwiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwicmVxdWVzdF90eXBlXCIsIGhlYWRlcjogXCJUeXBlXCIgfSxcclxuICAgICAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICAgICAgeyBrZXk6IFwicmVxdWVzdF9kYXRlXCIsIGhlYWRlcjogXCJSZXF1ZXN0IERhdGVcIiB9LFxyXG4gICAgXTtcclxuXHJcbiAgICBjb25zdCBnZXRDYW5jZWxUYWJsZURhdGEgPSAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGNhbmNlbFJlcXVlc3RzLm1hcCgocmVxLCBpZHgpID0+ICh7XHJcbiAgICAgICAgICAgIGlkOiBpZHggKyAxLFxyXG4gICAgICAgICAgICBjdXN0b21lcl9uYW1lOiByZXEudXNlcl9uYW1lIHx8IHJlcS5jdXN0b21lcl9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIGdyb3VwX25hbWU6IHJlcS5ncm91cF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIHRpY2tldDogcmVxLnRpY2tldCB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICBhbW91bnQ6IGDigrkkeyhyZXEuYW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgcmVxdWVzdF90eXBlOiA8VGFnIGNvbG9yPVwiYmx1ZVwiPntyZXEucmVxdWVzdF90eXBlPy50b1VwcGVyQ2FzZSgpIHx8IHJlcXVlc3RUeXBlRmlsdGVyLnRvVXBwZXJDYXNlKCl9PC9UYWc+LFxyXG4gICAgICAgICAgICBzdGF0dXM6IDxUYWcgY29sb3I9e3JlcS5zdGF0dXMgPT09IFwiYXBwcm92ZWRcIiA/IFwiZ3JlZW5cIiA6IFwib3JhbmdlXCJ9PntyZXEuc3RhdHVzIHx8IFwiUGVuZGluZ1wifTwvVGFnPixcclxuICAgICAgICAgICAgcmVxdWVzdF9kYXRlOiBkYXlqcyhyZXEuY3JlYXRlZF9hdCkuZm9ybWF0KFwiREQtTU0tWVlZWVwiKSxcclxuICAgICAgICB9KSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZU9uSG9sZE1vZGVsT3BlbiA9IGFzeW5jIChlbnJvbGxtZW50SWQsIG9wZXJhdGlvbiA9IFwiaG9sZFwiKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgICAgICAgYC9lbnJvbGwvZ2V0LWVucm9sbC1ieS1pZC8ke2Vucm9sbG1lbnRJZH1gXHJcbiAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICBjb25zdCBlbnJvbGxtZW50RGF0YSA9IHJlc3BvbnNlLmRhdGE7XHJcblxyXG4gICAgICAgICAgICBsZXQgZmluYWxPcGVyYXRpb24gPSBvcGVyYXRpb247XHJcblxyXG4gICAgICAgICAgICBpZiAob3BlcmF0aW9uID09PSBcImFjdGl2ZS1pbmFjdGl2ZVwiKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBjdXJyZW50U3RhdHVzID0gZW5yb2xsbWVudERhdGE/LmN1c3RvbWVyX3N0YXR1cz8udG9Mb3dlckNhc2UoKTtcclxuXHJcbiAgICAgICAgICAgICAgICBpZiAoY3VycmVudFN0YXR1cyA9PT0gXCJhY3RpdmVcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIGZpbmFsT3BlcmF0aW9uID0gXCJpbmFjdGl2ZVwiO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICBmaW5hbE9wZXJhdGlvbiA9IFwiYWN0aXZlXCI7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRHcm91cChlbnJvbGxtZW50RGF0YSk7XHJcbiAgICAgICAgICAgIHNldEVucm9sbG1lbnRPcGVyYXRpb24oZmluYWxPcGVyYXRpb24pO1xyXG4gICAgICAgICAgICBzZXRTaG93TW9kZWxPbkhvbGQodHJ1ZSk7XHJcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihcclxuICAgICAgICAgICAgICAgIFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsbWVudDpcIixcclxuICAgICAgICAgICAgICAgIGVycm9yXHJcbiAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGxvYWQgZW5yb2xsbWVudCBkZXRhaWxzXCIpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlT25Ib2xkR3JvdXAgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICAgICAgaWYgKCFjdXJyZW50R3JvdXApIHJldHVybjtcclxuXHJcbiAgICAgICAgY29uc3QgdXNlcklkID0gY3VycmVudEdyb3VwPy51c2VyX2lkPy5faWQ7XHJcblxyXG4gICAgICAgIGlmICghdXNlcklkKSB7XHJcbiAgICAgICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJVc2VyIElEIG1pc3NpbmdcIik7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGFkbWluSWQgPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKSk/Ll9pZDtcclxuXHJcbiAgICAgICAgICAgIGlmIChlbnJvbGxtZW50T3BlcmF0aW9uID09PSBcInN1c3BlbmRcIikge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgYXBpLnB1dChgL2Vucm9sbC9yZW1vdmUvJHtjdXJyZW50R3JvdXAuX2lkfWAsIHtcclxuICAgICAgICAgICAgICAgICAgICB1c2VyX2lkOiB1c2VySWQsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlZF9ieTogYWRtaW5JZCxcclxuICAgICAgICAgICAgICAgICAgICBkZWxldGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgICAgICAgICAgICAgcmVtb3ZhbFJlYXNvbjogXCJTdXNwZW5kXCIsXHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJFbnJvbGxtZW50IHN1c3BlbmRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoZW5yb2xsbWVudE9wZXJhdGlvbiA9PT0gXCJpbmFjdGl2ZVwiKSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBhcGkucHV0KGAvZW5yb2xsL3JlbW92ZS8ke2N1cnJlbnRHcm91cC5faWR9YCwge1xyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJfaWQ6IHVzZXJJZCxcclxuICAgICAgICAgICAgICAgICAgICBkZWxldGVkX2J5OiBhZG1pbklkLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlbGV0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgICAgICAgICAgICByZW1vdmFsUmVhc29uOiBcIkluIEFjdGl2ZSBDdXN0b21lclwiLFxyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiQ3VzdG9tZXIgbWFkZSBpbmFjdGl2ZSBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoZW5yb2xsbWVudE9wZXJhdGlvbiA9PT0gXCJob2xkXCIpIHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5wdXQoYC92MS9hZG1pbi9lbnJvbGxzL29uLWhvbGQvJHtjdXJyZW50R3JvdXAuX2lkfWAsIHtcclxuICAgICAgICAgICAgICAgICAgICB1c2VyX2lkOiB1c2VySWQsXHJcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfc3RhdHVzOiBcIk9uIEhvbGRcIixcclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIkVucm9sbG1lbnQgcGxhY2VkIG9uIGhvbGQgc3VjY2Vzc2Z1bGx5XCIpO1xyXG4gICAgICAgICAgICB9IGVsc2UgaWYgKGVucm9sbG1lbnRPcGVyYXRpb24gPT09IFwiYWN0aXZlXCIpIHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5wdXQoYC92MS9hZG1pbi9lbnJvbGxzL2FjdGl2YXRlLyR7Y3VycmVudEdyb3VwPy5faWR9YCwge1xyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJfaWQ6IHVzZXJJZCxcclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21lcl9zdGF0dXM6IFwiQWN0aXZhdGVcIixcclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIG1lc3NhZ2Uuc3VjY2VzcyhcIkN1c3RvbWVyIG1hZGUgYWN0aXZlIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgc2V0U2hvd01vZGVsT25Ib2xkKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4gICAgICAgICAgICBzZXRFbnJvbGxtZW50T3BlcmF0aW9uKG51bGwpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHNlbGVjdGVkQ3VzdG9tZXI/Ll9pZCkge1xyXG4gICAgICAgICAgICAgICAgZmV0Y2hDdXN0b21lclBvcnRmb2xpbyhzZWxlY3RlZEN1c3RvbWVyLl9pZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgZW5yb2xsbWVudDpcIiwgZXJyb3IpO1xyXG5cclxuICAgICAgICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgZW5yb2xsbWVudFwiKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuXHJcbiAgICBjb25zdCBoYW5kbGVQcm9jZWVkVG9TZXR0bGVtZW50ID0gKCkgPT4ge1xyXG4gICAgICAgIGlmICghdG90YWxBbW91bnQpIHtcclxuICAgICAgICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIGNhbGN1bGF0ZSB0b3RhbCBwYXltZW50IGZpcnN0XCIpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghc2VsZWN0ZWRFbnJvbGxJZCkge1xyXG4gICAgICAgICAgICBtZXNzYWdlLndhcm5pbmcoXCJObyBlbnJvbGxtZW50IHNlbGVjdGVkXCIpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCByZW1hcmsgPSBcIkNoaXQgQ2FuY2VsbGF0aW9uXCI7XHJcbiAgICAgICAgc2V0UmVtYXJrVHlwZShyZW1hcmspO1xyXG4gICAgICAgIHNldE1vdmVSZW1hcmsocmVtYXJrKTtcclxuICAgICAgICBzZXRDb25maXJtSW5wdXQoXCJcIik7XHJcblxyXG4gICAgICAgIGNvbnN0IGdyb3VwVmFsdWUgPSBzZWxlY3RlZEVucm9sbG1lbnREYXRhPy5lbnJvbGxtZW50Py5ncm91cD8uZ3JvdXBfdmFsdWVcclxuICAgICAgICAgICAgPyBOdW1iZXIoc2VsZWN0ZWRFbnJvbGxtZW50RGF0YS5lbnJvbGxtZW50Lmdyb3VwLmdyb3VwX3ZhbHVlKVxyXG4gICAgICAgICAgICA6IG51bGw7XHJcbiAgICAgICAgY29uc3QgZGVmYXVsdENoYXJnZSA9IGdyb3VwVmFsdWVcclxuICAgICAgICAgICAgPyBNYXRoLnJvdW5kKGdyb3VwVmFsdWUgKiAwLjA1KVxyXG4gICAgICAgICAgICA6IE1hdGgucm91bmQoKE51bWJlcih0b3RhbEFtb3VudCkgfHwgMCkgKiAwLjA1KTtcclxuXHJcbiAgICAgICAgc2V0U2VydmljZUNoYXJnZShkZWZhdWx0Q2hhcmdlKTtcclxuICAgICAgICBzZXRHc3RBbW91bnQoZGVmYXVsdENoYXJnZSAqIDAuMTgpO1xyXG4gICAgICAgIC8vIGZpbmFsQW1vdW50IGlzIG5vdyBoYW5kbGVkIGJ5IHRoZSB1c2VFZmZlY3QgYWJvdmVcclxuXHJcbiAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICAgIHNldFN0ZXAoMik7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZVByb2NlZWRUb1NldHRsZW1lbnRDb25maXJtID0gKCkgPT4ge1xyXG4gICAgICAgIGlmICghdG90YWxBbW91bnQpIHtcclxuICAgICAgICAgICAgbWVzc2FnZS53YXJuaW5nKFwiUGxlYXNlIGNhbGN1bGF0ZSB0b3RhbCBwYXltZW50IGZpcnN0XCIpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghc2VsZWN0ZWRFbnJvbGxJZCkge1xyXG4gICAgICAgICAgICBtZXNzYWdlLndhcm5pbmcoXCJObyBlbnJvbGxtZW50IHNlbGVjdGVkXCIpO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBhbnRNb2RhbC5jb25maXJtKHtcclxuICAgICAgICAgICAgdGl0bGU6IFwiQ29uZmlybSBQcm9jZWVkXCIsXHJcbiAgICAgICAgICAgIGNvbnRlbnQ6IFwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIHByb2NlZWQgd2l0aCBjaGl0IHNldHRsZW1lbnQ/XCIsXHJcbiAgICAgICAgICAgIG9rVGV4dDogXCJZZXMsIFByb2NlZWRcIixcclxuICAgICAgICAgICAgY2FuY2VsVGV4dDogXCJDYW5jZWxcIixcclxuICAgICAgICAgICAgb25PazogKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaGFuZGxlUHJvY2VlZFRvU2V0dGxlbWVudCgpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBnZXRBY3Rpb25CdXR0b25UZXh0ID0gKGFjdGlvblR5cGUpID0+IHtcclxuICAgICAgICBzd2l0Y2ggKGFjdGlvblR5cGUpIHtcclxuICAgICAgICAgICAgY2FzZSBcIkNISVRfQ0FOQ0VMXCI6IHJldHVybiBcIkNhbmNlbFwiO1xyXG4gICAgICAgICAgICBjYXNlIFwiQ0hJVF9DTE9TRVwiOiByZXR1cm4gXCJDbG9zZVwiO1xyXG4gICAgICAgICAgICBjYXNlIFwiQ0hJVF9UUkFOU0ZFUlwiOiByZXR1cm4gXCJUcmFuc2ZlclwiO1xyXG4gICAgICAgICAgICBjYXNlIFwiUElHTVlfUFJFQ0xPU1VSRVwiOiByZXR1cm4gXCJQcmVjbG9zdXJlXCI7XHJcbiAgICAgICAgICAgIGNhc2UgXCJQSUdNWV9UT19DSElUXCI6IHJldHVybiBcIkNvbnZlcnQgdG8gQ2hpdFwiO1xyXG4gICAgICAgICAgICBjYXNlIFwiUElHTVlfVE9fTE9BTlwiOiByZXR1cm4gXCJDb252ZXJ0IHRvIExvYW5cIjtcclxuICAgICAgICAgICAgZGVmYXVsdDogcmV0dXJuIFwiUHJvY2VlZFwiO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcblxyXG5cclxuICAgIC8vIFBvcnRmb2xpbyBWaWV3XHJcbiAgICBjb25zdCByZW5kZXJDdXN0b21lclBvcnRmb2xpbyA9ICgpID0+IHtcclxuICAgICAgICBpZiAoIXNlbGVjdGVkQ3VzdG9tZXIpIHJldHVybiBudWxsO1xyXG4gICAgICAgIGNvbnN0IHRvdGFsUGlnbXlBbW91bnQgPSBwaWdteURhdGEucmVkdWNlKChhY2MsIGN1cnIpID0+IGFjYyArIChjdXJyLnRvdGFsX2RlcG9zaXRlZF9hbW91bnQgfHwgMCksIDApO1xyXG4gICAgICAgIGNvbnN0IGhhc1BpZ215ID0gcGlnbXlEYXRhLmxlbmd0aCA+IDA7XHJcbiAgICAgICAgY29uc3QgaGFzTG9hbnMgPSBsb2FuRGF0YT8ubGVuZ3RoID4gMDtcclxuICAgICAgICBjb25zdCBoYXNDaGl0cyA9IGN1c3RvbWVyRW5yb2xsbWVudHMubGVuZ3RoID4gMDtcclxuXHJcbiAgICAgICAgLy8gRGV0ZXJtaW5lIHBpZ215IGJ1dHRvbiB0ZXh0IGFuZCBhY3Rpb25cclxuICAgICAgICBjb25zdCBwcmltYXJ5UGlnbXkgPSBwaWdteURhdGFbMF07XHJcbiAgICAgICAgY29uc3QgcGlnbXlSZXF1ZXN0U3RhdHVzID0gcHJpbWFyeVBpZ215Py5yZXF1ZXN0X3N0YXR1cztcclxuXHJcbiAgICAgICAgY29uc3QgaXNSZXF1ZXN0ZWQgPSBwaWdteVJlcXVlc3RTdGF0dXMgPT09IFwiUkVRVUVTVEVEXCI7XHJcbiAgICAgICAgY29uc3QgaXNBcHByb3ZlZCA9IHBpZ215UmVxdWVzdFN0YXR1cyA9PT0gXCJBUFBST1ZFRFwiO1xyXG4gICAgICAgIGNvbnN0IGlzQ29tcGxldGVkID0gaXNBcHByb3ZlZDsgLy8gdHJlYXQgYXBwcm92ZWQgYXMgZmluYWwgc3RhZ2VcclxuXHJcbiAgICAgICAgY29uc3QgcGlnbXlCdXR0b25UZXh0ID0gaXNSZXF1ZXN0ZWRcclxuICAgICAgICAgICAgPyBcIldpdGhkcmF3IFBpZ215XCJcclxuICAgICAgICAgICAgOiBpc0FwcHJvdmVkXHJcbiAgICAgICAgICAgICAgICA/IFwiV2l0aGRyYXcgQXBwcm92ZWQgUGlnbXlcIlxyXG4gICAgICAgICAgICAgICAgOiBcIlJhaXNlIFJlcXVlc3QgdG8gV2l0aGRyYXdcIjtcclxuICAgICAgICBjb25zdCBoYW5kbGVQaWdteUNsaWNrID0gKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIXByaW1hcnlQaWdteSkgcmV0dXJuO1xyXG5cclxuICAgICAgICAgICAgLy8gIEJMT0NLIEFDVElPTiBJRiBBTFJFQURZIEFQUFJPVkVEXHJcbiAgICAgICAgICAgIGlmIChpc0FwcHJvdmVkKSB7XHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlLndhcm5pbmcoXHJcbiAgICAgICAgICAgICAgICAgICAgXCJHbyB0byBQaWdteSBQYXltZW50IE91dCBwYWdlIHRvIHZpZXcgcmVtYWluaW5nIHBheW91dCBmb3IgUGlnbXlcIlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaWYgKGlzUmVxdWVzdGVkKSB7XHJcbiAgICAgICAgICAgICAgICBoYW5kbGVPcGVuV2l0aGRyYXdNb2RhbChwcmltYXJ5UGlnbXkuX2lkKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGhhbmRsZVJhaXNlV2l0aGRyYXdSZXF1ZXN0KHByaW1hcnlQaWdteS5faWQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuXHJcblxyXG5cclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNiBhbmltYXRlLWZhZGUtaW4tdXBcIiBpZD1cImN1c3RvbWVyLXBvcnRmb2xpb1wiPlxyXG4gICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiYm9yZGVyLWwtNCBib3JkZXItbC1ibHVlLTYwMCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICA8RGVzY3JpcHRpb25zIGNvbHVtbj17eyB4czogMSwgc206IDIsIG1kOiA0IH19IHNpemU9XCJzbWFsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RGVzY3JpcHRpb25zLkl0ZW0gbGFiZWw9XCJDdXN0b21lciBOYW1lXCI+e3NlbGVjdGVkQ3VzdG9tZXIuZnVsbF9uYW1lfTwvRGVzY3JpcHRpb25zLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxEZXNjcmlwdGlvbnMuSXRlbSBsYWJlbD1cIkN1c3RvbWVyIElEXCI+e3NlbGVjdGVkQ3VzdG9tZXIuY3VzdG9tZXJfaWR9PC9EZXNjcmlwdGlvbnMuSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPERlc2NyaXB0aW9ucy5JdGVtIGxhYmVsPVwiUGhvbmVcIj57c2VsZWN0ZWRDdXN0b21lci5waG9uZV9udW1iZXJ9PC9EZXNjcmlwdGlvbnMuSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPERlc2NyaXB0aW9ucy5JdGVtIGxhYmVsPVwiQWFkaGFhclwiPntzZWxlY3RlZEN1c3RvbWVyLmFkaGFhcl9ub308L0Rlc2NyaXB0aW9ucy5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvRGVzY3JpcHRpb25zPlxyXG4gICAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9ezE2fT5cclxuICAgICAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gbWQ9ezEyfSBsZz17OH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17PHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1ibHVlLTgwMFwiPjxHcm91cE91dGxpbmVkIC8+IEFjdGl2ZSBDaGl0cyAoe2N1c3RvbWVyRW5yb2xsbWVudHMubGVuZ3RofSk8L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvZHlTdHlsZT17eyBwYWRkaW5nOiBoYXNDaGl0cyA/ICcwJyA6ICcwJyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZ0Vucm9sbG1lbnRzID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyXCI+PFNwaW4gLz48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBoYXNDaGl0cyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC1oLVs0MDBweF0gb3ZlcmZsb3cteS1hdXRvIHAtMyBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVyRW5yb2xsbWVudHMubWFwKChpdGVtLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBwLTMgYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj57aXRlbS5lbnJvbGxtZW50Lmdyb3VwLmdyb3VwX25hbWV9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlRpY2tldDoge2l0ZW0uZW5yb2xsbWVudC50aWNrZXRzfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0/LmVucm9sbG1lbnQ/LmN1c3RvbWVyX3N0YXR1cyA9PT0gXCJBY3RpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogaXRlbT8uZW5yb2xsbWVudD8uY3VzdG9tZXJfc3RhdHVzID09PSBcIk9uIEhvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIm9yYW5nZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwicmVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0/LmVucm9sbG1lbnQ/LmN1c3RvbWVyX3N0YXR1cyB8fCBcIkFjdGl2ZVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RhZz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTcGFjZSBzaXplPVwic21hbGxcIiB3cmFwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PE1kQ2hlY2sgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBY3Rpb25DbGljaygnQ0hJVF9DQU5DRUwnLCBpdGVtKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFRoaXMgVGlja2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbT8ucHJpemVkPy5pc19wcml6ZWQgPT09IFwidHJ1ZVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUYWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cImJsdWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIiFyb3VuZGVkLWZ1bGwgIXB4LTMgIXB5LTEgIXRleHQteHMgIWZvbnQtc2VtaWJvbGQgc2hhZG93LXNtIGJvcmRlci0wXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn4+GIFByaXplZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UYWc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb249ezxTdG9wT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBY3Rpb25DbGljaygnQ0hJVF9DTE9TRScsIGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDaGl0IENsb3NlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ2hvc3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRyYW5zZmVyQ2xpY2soaXRlbSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uPXt0cmFuc2ZlckxvYWRpbmcgPyA8U3dhcE91dGxpbmVkIHNwaW4gLz4gOiA8U3dhcE91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3RyYW5zZmVyTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyF0cmFuc2ZlckxvYWRpbmcgPyBcIkNoaXQgVHJhbnNmZXJcIiA6IFwiVHJhbnNmZXJyaW5nLi4uXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NwYWNlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RW1wdHkgaW1hZ2U9e0VtcHR5LlBSRVNFTlRFRF9JTUFHRV9TSU1QTEV9IGRlc2NyaXB0aW9uPVwiTm8gQWN0aXZlIENoaXRzXCIgY2xhc3NOYW1lPVwicHktOFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPENvbCB4cz17MjR9IG1kPXsxMn0gbGc9ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2FyZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdGl0bGU9ezxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtZW1lcmFsZC04MDBcIj48RmFSdXBlZVNpZ24gLz4gUGlnbXkgQWNjb3VudDwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtZW1lcmFsZC04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhUnVwZWVTaWduIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QaWdteSBBY2NvdW50PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib2R5U3R5bGU9e3sgcGFkZGluZzogaGFzUGlnbXkgPyAnMTZweCcgOiAnMCcgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2xvYWRpbmdQaWdteSA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOCB0ZXh0LWNlbnRlclwiPjxTcGluIC8+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogaGFzUGlnbXkgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEV4aXN0aW5nIHRvdGFsIGRlcG9zaXRlZCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwIHAtNCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZW1lcmFsZC0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWVtZXJhbGQtNjAwIHVwcGVyY2FzZSBmb250LWJvbGRcIj5Ub3RhbCBEZXBvc2l0ZWQ8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZW1lcmFsZC04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7dG90YWxQaWdteUFtb3VudC50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Lyoge3BpZ215RGF0YVswXT8uYmFsYW5jZSAhPT0gdW5kZWZpbmVkICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJhbGFuY2U6IHtwaWdteURhdGFbMF0uYmFsYW5jZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBOZXc6IFBpZ215IERldGFpbHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwaWdteURhdGEubWFwKChwaWdteSwgaWR4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcC0zIHNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+UGlnbXkgSUQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIGZvbnQtc2VtaWJvbGRcIj57cGlnbXkucGlnbWVfaWQgfHwgJy0nfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlBheW1lbnQgVHlwZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSBjYXBpdGFsaXplXCI+e3BpZ215Lm1hdHVyaXR5X3BlcmlvZCB8fCAnLSd9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGlnbXkubWF0dXJpdHlfcGVyaW9kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPy50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcYlxcdy9nLCAoY2hhcikgPT4gY2hhci50b1VwcGVyQ2FzZSgpKX17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWlkIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW1cIj7igrl7TnVtYmVyKHBpZ215LnBheWFibGVfYW1vdW50IHx8IDApLnRvTG9jYWxlU3RyaW5nKCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+RHVyYXRpb248L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW1cIj57cGlnbXkuZHVyYXRpb24gfHwgJy0nfSBtb250aHM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5TdGFydCBEYXRlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGlnbXkuc3RhcnRfZGF0ZSA/IGRheWpzKHBpZ215LnN0YXJ0X2RhdGUpLmZvcm1hdCgnREQtTU0tWVlZWScpIDogJy0nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5Nb250aHMgQ29tcGxldGVkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwaWdteS5zdGFydF9kYXRlID8gKCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzdGFydCA9IGRheWpzKHBpZ215LnN0YXJ0X2RhdGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRvZGF5ID0gZGF5anMoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbW9udGhzID0gKHRvZGF5LnllYXIoKSAtIHN0YXJ0LnllYXIoKSkgKiAxMiArICh0b2RheS5tb250aCgpIC0gc3RhcnQubW9udGgoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9udGhzID0gTWF0aC5tYXgoMCwgbW9udGhzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYCR7bW9udGhzfSAvICR7cGlnbXkuZHVyYXRpb24gfHwgJz8nfSBtb250aHNgO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkoKSA6ICctJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEJ1dHRvbnMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeygoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcHJpbWFyeVBpZ215ID0gcGlnbXlEYXRhWzBdO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzTm9uZSA9ICFwcmltYXJ5UGlnbXk/LnJlcXVlc3Rfc3RhdHVzIHx8IHByaW1hcnlQaWdteT8ucmVxdWVzdF9zdGF0dXMgPT09IFwiUEVORElOR1wiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzUmVxdWVzdGVkID0gcHJpbWFyeVBpZ215Py5yZXF1ZXN0X3N0YXR1cyA9PT0gXCJSRVFVRVNURURcIjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0FwcHJvdmVkID0gcHJpbWFyeVBpZ215Py5yZXF1ZXN0X3N0YXR1cyA9PT0gXCJBUFBST1ZFRFwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzRGVsZXRlZCA9IHByaW1hcnlQaWdteT8ucmVxdWVzdF9zdGF0dXMgPT09IFwiRE9ORVwiO1xyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU1RBR0UgMCDigJQgTm8gcmVxdWVzdCB5ZXQ6IHNob3cgb25seSB0aGUgcmFpc2UgcmVxdWVzdCBidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaXNOb25lKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb249ezxFeGNsYW1hdGlvbkNpcmNsZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e3JhaXNpbmdSZXF1ZXN0TG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSYWlzZVdpdGhkcmF3UmVxdWVzdChwcmltYXJ5UGlnbXkuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItcmVkLTIwMCB0ZXh0LXJlZC02MDAgaG92ZXI6YmctcmVkLTUwIGhvdmVyOmJvcmRlci1yZWQtMzAwIGZvbnQtbWVkaXVtIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFJhaXNlIFJlcXVlc3QgdG8gV2l0aGRyYXdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gU1RBR0UgMSsg4oCUIFJlcXVlc3QgcmFpc2VkOiBzaG93IHByb2dyZXNzIHRyYWNrZXIgaW5zdGVhZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHN0ZXBzID0gW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwicmFpc2VkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogXCJSZXF1ZXN0IHJhaXNlZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVzYzogXCJXaXRoZHJhd2FsIHJlcXVlc3Qgc3VibWl0dGVkIHN1Y2Nlc3NmdWxseS5cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogXCJkb25lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJjYWxjdWxhdGVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBcIkNhbGN1bGF0ZSAmIGFwcHJvdmVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlc2M6IGlzQXBwcm92ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiV2l0aGRyYXdhbCBhbW91bnQgY2FsY3VsYXRlZCBhbmQgYXBwcm92ZWQuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiT3BlbiB0aGUgd2l0aGRyYXdhbCBtb2RhbCwgYWRqdXN0IGludGVyZXN0IGlmIG5lZWRlZCwgdGhlbiBjYWxjdWxhdGUgYW5kIGNvbmZpcm0uXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGlzQXBwcm92ZWQgPyBcImRvbmVcIiA6IFwiYWN0aXZlXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBIaWRlIHRoZSBhY3Rpb24gYnV0dG9uIGlmIHRoZSBhY2NvdW50IGlzIGRlbGV0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbjogIWlzQXBwcm92ZWQgJiYgIWlzRGVsZXRlZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17cmFpc2luZ1JlcXVlc3RMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uPXs8RmFDYWxjdWxhdG9yIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVPcGVuV2l0aGRyYXdNb2RhbChwcmltYXJ5UGlnbXkuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMiBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPcGVuIHdpdGhkcmF3YWwgbW9kYWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwicGF5b3V0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogaXNEZWxldGVkID8gXCJBY2NvdW50IGNsb3NlZFwiIDogXCJQcm9jZXNzIHBheW91dFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVzYzogaXNEZWxldGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIlRoZSBwaWdteSBhY2NvdW50IGhhcyBiZWVuIGNsb3NlZCBhbmQgdGhlIGZpbmFsIGFtb3VudCBoYXMgYmVlbiB3aXRoZHJhd24uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiR28gdG8gUGlnbXkgUGF5bWVudCBPdXQgcGFnZSB0byBkaXNidXJzZSB0aGUgZmluYWwgYW1vdW50IHRvIHRoZSBjdXN0b21lci5cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogaXNEZWxldGVkID8gXCJkb25lXCIgOiBpc0FwcHJvdmVkID8gXCJhY3RpdmVcIiA6IFwicGVuZGluZ1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uOiBpc0RlbGV0ZWQgPyBudWxsIDogaXNBcHByb3ZlZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PEFycm93UmlnaHRPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gbmF2aWdhdGUoXCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LW91dC1tZW51L3BpZ215LXBheW91dFwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMiBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHbyB0byBQaWdteSBQYXlvdXQgcGFnZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMCBib3JkZXIgYm9yZGVyLWRhc2hlZCBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC0zIHB5LTIgbXQtMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TG9ja091dGxpbmVkIC8+IFVubG9ja3MgYWZ0ZXIgYXBwcm92YWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXTtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3RhdHVzU3R5bGVzID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkb25lOiB7IGljb246IFwiYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGJvcmRlci1lbWVyYWxkLTQwMFwiLCBsYWJlbDogXCJ0ZXh0LWVtZXJhbGQtODAwXCIsIGxpbmU6IFwiYmctZW1lcmFsZC00MDBcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3RpdmU6IHsgaWNvbjogXCJiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDAgYm9yZGVyLWJsdWUtNDAwXCIsIGxhYmVsOiBcInRleHQtYmx1ZS05MDBcIiwgbGluZTogXCJiZy1ncmF5LTIwMFwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBlbmRpbmc6IHsgaWNvbjogXCJiZy1ncmF5LTEwMCB0ZXh0LWdyYXktNDAwIGJvcmRlci1ncmF5LTMwMFwiLCBsYWJlbDogXCJ0ZXh0LWdyYXktNDAwXCIsIGxpbmU6IFwiYmctZ3JheS0yMDBcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFdpdGhkcmF3YWwgcHJvZ3Jlc3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXBzLm1hcCgoc3RlcCwgaWR4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcyA9IHN0YXR1c1N0eWxlc1tzdGVwLnN0YXR1c107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNMYXN0ID0gaWR4ID09PSBzdGVwcy5sZW5ndGggLSAxO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtzdGVwLmtleX0gY2xhc3NOYW1lPVwiZmxleCBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy03IGgtNyByb3VuZGVkLWZ1bGwgYm9yZGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc20gZmxleC1zaHJpbmstMCAke3MuaWNvbn1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXAuc3RhdHVzID09PSBcImRvbmVcIiA/IDxDaGVja0NpcmNsZU91dGxpbmVkIC8+IDogc3RlcC5zdGF0dXMgPT09IFwiYWN0aXZlXCIgPyA8QXJyb3dSaWdodE91dGxpbmVkIC8+IDogPExvY2tPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IWlzTGFzdCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdy0wLjUgZmxleC1ncm93IG10LTEgbWItMSBtaW4taC02ICR7cy5saW5lfWB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwYi00IGZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LW1lZGl1bSAke3MubGFiZWx9YH0+e3N0ZXAubGFiZWx9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMC41IGxlYWRpbmctcmVsYXhlZFwiPntzdGVwLmRlc2N9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXAuYWN0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YG10LTEgcm91bmRlZC1sZyBweC0zIHB5LTIgdGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgJHtpc0FwcHJvdmVkID8gXCJiZy1lbWVyYWxkLTUwIGJvcmRlciBib3JkZXItZW1lcmFsZC0xMDAgdGV4dC1lbWVyYWxkLTcwMFwiIDogXCJiZy1ibHVlLTUwIGJvcmRlciBib3JkZXItYmx1ZS0xMDAgdGV4dC1ibHVlLTcwMFwifWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1JlcXVlc3RlZCAmJiA8PjxzdHJvbmc+TmV4dDo8L3N0cm9uZz4gT3BlbiB0aGUgd2l0aGRyYXdhbCBtb2RhbCB0byBjYWxjdWxhdGUgYW5kIGFwcHJvdmUgdGhlIHBheW91dCBhbW91bnQuPC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc0FwcHJvdmVkICYmIDw+PHN0cm9uZz5OZXh0Ojwvc3Ryb25nPiBHbyB0byB0aGUgUGlnbXkgUGF5b3V0IHBhZ2UgdG8gY29tcGxldGUgdGhlIGRpc2J1cnNlbWVudC48Lz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKCl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFByaW50IENsb3N1cmUgRm9ybSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaWNvbj17PEZpbGVUZXh0T3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93Lm9wZW4oYC9waWdteS1wcmVjbG9zdXJlLXByaW50LyR7cHJpbWFyeVBpZ215Ll9pZH1gLCBcIl9ibGFua1wiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItZ3JheS0yMDAgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTUwIGhvdmVyOmJvcmRlci1ncmF5LTMwMCBmb250LW1lZGl1bSBoLTExXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5ao77iPIFByaW50IENsb3N1cmUgRm9ybVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogT3RoZXIgZGlzYWJsZWQgYnV0dG9ucyByZW1haW4gc2FtZSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBibG9ja1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PEFycm93UmlnaHRPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlci1ibHVlLTIwMCB0ZXh0LWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAgaG92ZXI6Ym9yZGVyLWJsdWUtMzAwIGZvbnQtbWVkaXVtIGgtMTEgb3BhY2l0eS01MCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRyYW5zZmVyIHRvIENoaXQgKERpc2FibGVkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYmxvY2tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb249ezxTd2FwT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItcHVycGxlLTIwMCB0ZXh0LXB1cnBsZS02MDAgaG92ZXI6YmctcHVycGxlLTUwIGhvdmVyOmJvcmRlci1wdXJwbGUtMzAwIGZvbnQtbWVkaXVtIGgtMTEgb3BhY2l0eS01MCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRyYW5zZmVyIHRvIExvYW4gKERpc2FibGVkKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RW1wdHkgaW1hZ2U9e0VtcHR5LlBSRVNFTlRFRF9JTUFHRV9TSU1QTEV9IGRlc2NyaXB0aW9uPVwiTm8gUGlnbXkgRGF0YVwiIGNsYXNzTmFtZT1cInB5LThcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29sPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBtZD17MTJ9IGxnPXs4fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENhcmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1wdXJwbGUtODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYVJ1cGVlU2lnbiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+TG9hbiBEZXRhaWxzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtZnVsbCBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9keVN0eWxlPXt7IHBhZGRpbmc6IGxvYW5EYXRhLmxlbmd0aCA/ICcyMHB4JyA6ICcwJyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZ0xvYW5zID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyXCI+PFNwaW4gLz48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBsb2FuRGF0YS5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBoLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgZmxleC1ncm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bG9hbkRhdGEubWFwKChpdGVtLCBpZHgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBsb2FuID0gaXRlbS5sb2FuX2RldGFpbHM/LmxvYW4gfHwge307XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbG9hblZhbHVlID0gaXRlbS5sb2FuX3ZhbHVlIHx8IGxvYW4ubG9hbl9hbW91bnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYmFsYW5jZSA9IGl0ZW0uYmFsYW5jZSB8fCAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHBhaWRBbW91bnQgPSBpdGVtLnRvdGFsX3BhaWRfYW1vdW50IHx8IDA7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aWR4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgcC01IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgaG92ZXI6Ym9yZGVyLXB1cnBsZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZvbnQtc2VtaWJvbGQgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTG9hbiAje2xvYW4ubG9hbl9pZCB8fCBpZHggKyAxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtOdW1iZXIobG9hblZhbHVlKS50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFnIGNvbG9yPVwicHVycGxlXCIgY2xhc3NOYW1lPVwiYmctcHVycGxlLTEwMCB0ZXh0LXB1cnBsZS03MDAgYm9yZGVyLW5vbmUgcHgtMyBweS0xIHJvdW5kZWQtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBY3RpdmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RhZz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAteS0zIGdhcC14LTQgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCB0ZXh0LXhzXCI+VG90YWwgUGFpZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj7igrl7cGFpZEFtb3VudC50b0xvY2FsZVN0cmluZygpfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC14c1wiPlRlbnVyZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj57bG9hbi50ZW51cmV9IGRheXM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2FuLmRhaWx5X3BheW1lbnRfYW1vdW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCB0ZXh0LXhzXCI+RGFpbHkgRU1JPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIj7igrl7TnVtYmVyKGxvYW4uZGFpbHlfcGF5bWVudF9hbW91bnQpLnRvTG9jYWxlU3RyaW5nKCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgY29sLXNwYW4tMiBtdC0xIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIGZvbnQtbWVkaXVtXCI+T3V0c3RhbmRpbmcgQmFsYW5jZTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtcmVkLTYwMFwiPuKCuXtiYWxhbmNlLnRvTG9jYWxlU3RyaW5nKCl9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC02IG10LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJsb2NrXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYW5nZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGVmYXVsdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PEV4Y2xhbWF0aW9uQ2lyY2xlT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQWN0aW9uQ2xpY2soJ0xPQU5fUFJFQ0xPU0UnLCB7IGxvYW5EYXRhOiBsb2FuRGF0YVswXSB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEyIGZvbnQtbWVkaXVtIGJvcmRlci1yZWQtMjAwIHRleHQtcmVkLTYwMCBob3ZlcjohYm9yZGVyLXJlZC01MDAgaG92ZXI6IXRleHQtcmVkLTcwMCBob3ZlcjohYmctcmVkLTUwIHRyYW5zaXRpb24tYWxsIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJlY2xvc2UgTG9hblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RW1wdHkgaW1hZ2U9e0VtcHR5LlBSRVNFTlRFRF9JTUFHRV9TSU1QTEV9IGRlc2NyaXB0aW9uPVwiTm8gQWN0aXZlIExvYW5zXCIgY2xhc3NOYW1lPVwicHktOFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Db2w+XHJcbiAgICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3Qgb3BlcmF0aW9uQ29uZmlnID0ge1xyXG4gICAgICAgIGhvbGQ6IHtcclxuICAgICAgICAgICAgdGl0bGU6IFwiQ29uZmlybSBFbnJvbGxtZW50IEhvbGQ/XCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOlxyXG4gICAgICAgICAgICAgICAgXCJBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gcGxhY2UgdGhpcyBlbnJvbGxtZW50IG9uIGhvbGQ/IFRoZSBjdXN0b21lciB3aWxsIGJlIHRlbXBvcmFyaWx5IGV4Y2x1ZGVkIGZyb20gcGFydGljaXBhdGlvbiB1bnRpbCB0aGUgZW5yb2xsbWVudCBpcyByZWFjdGl2YXRlZC5cIixcclxuICAgICAgICAgICAgYnV0dG9uVGV4dDogXCJDb25maXJtIEhvbGRcIixcclxuICAgICAgICAgICAgYnV0dG9uQ2xhc3M6XHJcbiAgICAgICAgICAgICAgICBcImJnLXllbGxvdy01MDAgaG92ZXI6YmcteWVsbG93LTYwMCBmb2N1czpyaW5nLXllbGxvdy0zMDBcIixcclxuICAgICAgICAgICAgaWNvbkNsYXNzOlxyXG4gICAgICAgICAgICAgICAgXCJiZy1ncmFkaWVudC10by1iciBmcm9tLXllbGxvdy00MDAgdG8teWVsbG93LTYwMFwiLFxyXG4gICAgICAgICAgICBhY2NlbnRDbGFzczogXCJiZy15ZWxsb3ctNTAwXCIsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgc3VzcGVuZDoge1xyXG4gICAgICAgICAgICB0aXRsZTogXCJDb25maXJtIEVucm9sbG1lbnQgU3VzcGVuc2lvbj9cIixcclxuICAgICAgICAgICAgZGVzY3JpcHRpb246XHJcbiAgICAgICAgICAgICAgICBcIkFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBzdXNwZW5kIHRoaXMgZW5yb2xsbWVudD8gVGhlIGN1c3RvbWVyIHdpbGwgYmUgdGVtcG9yYXJpbHkgc3VzcGVuZGVkIGZyb20gcGFydGljaXBhdGlvbi5cIixcclxuICAgICAgICAgICAgYnV0dG9uVGV4dDogXCJDb25maXJtIFN1c3BlbmRcIixcclxuICAgICAgICAgICAgYnV0dG9uQ2xhc3M6XHJcbiAgICAgICAgICAgICAgICBcImJnLW9yYW5nZS01MDAgaG92ZXI6Ymctb3JhbmdlLTYwMCBmb2N1czpyaW5nLW9yYW5nZS0zMDBcIixcclxuICAgICAgICAgICAgaWNvbkNsYXNzOlxyXG4gICAgICAgICAgICAgICAgXCJiZy1ncmFkaWVudC10by1iciBmcm9tLW9yYW5nZS00MDAgdG8tb3JhbmdlLTYwMFwiLFxyXG4gICAgICAgICAgICBhY2NlbnRDbGFzczogXCJiZy1vcmFuZ2UtNTAwXCIsXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgYWN0aXZlOiB7XHJcbiAgICAgICAgICAgIHRpdGxlOiBcIkFjdGl2YXRlIEVucm9sbG1lbnQ/XCIsXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOlxyXG4gICAgICAgICAgICAgICAgXCJBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gYWN0aXZhdGUgdGhpcyBlbnJvbGxtZW50PyBUaGUgY3VzdG9tZXIgd2lsbCBiZSBhbGxvd2VkIHRvIHBhcnRpY2lwYXRlIGFnYWluLlwiLFxyXG4gICAgICAgICAgICBidXR0b25UZXh0OiBcIkNvbmZpcm0gQWN0aXZhdGVcIixcclxuICAgICAgICAgICAgYnV0dG9uQ2xhc3M6XHJcbiAgICAgICAgICAgICAgICBcImJnLWdyZWVuLTUwMCBob3ZlcjpiZy1ncmVlbi02MDAgZm9jdXM6cmluZy1ncmVlbi0zMDBcIixcclxuICAgICAgICAgICAgaWNvbkNsYXNzOlxyXG4gICAgICAgICAgICAgICAgXCJiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTQwMCB0by1ncmVlbi02MDBcIixcclxuICAgICAgICAgICAgYWNjZW50Q2xhc3M6IFwiYmctZ3JlZW4tNTAwXCIsXHJcbiAgICAgICAgfSxcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgY3VycmVudE9wZXJhdGlvbiA9XHJcbiAgICAgICAgb3BlcmF0aW9uQ29uZmlnW2Vucm9sbG1lbnRPcGVyYXRpb25dIHx8IG9wZXJhdGlvbkNvbmZpZy5ob2xkO1xyXG5cclxuXHJcbiAgICAvLyBUYWIgaXRlbXNcclxuICAgIGNvbnN0IHRhYkl0ZW1zID0gW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcImNhbmNlbC1yZXF1ZXN0c1wiLFxyXG4gICAgICAgICAgICBsYWJlbDogXCJUcmFuc2FjdGlvbiBEZXRhaWxzXCIsXHJcbiAgICAgICAgICAgIGNoaWxkcmVuOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UmFkaW8uR3JvdXAgdmFsdWU9e3JlcXVlc3RUeXBlRmlsdGVyfSBvbkNoYW5nZT17KGUpID0+IHNldFJlcXVlc3RUeXBlRmlsdGVyKGUudGFyZ2V0LnZhbHVlKX0gYnV0dG9uU3R5bGU9XCJzb2xpZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIHJhZGlvIGJ1dHRvbnMgY2FuIGJlIGFkZGVkIGlmIG5lZWRlZCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9SYWRpby5Hcm91cD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiA9PT09PT09PT09IEFWQUlMQUJMRSBPUEVSQVRJT05TID09PT09PT09PT0gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTUwIHZpYS13aGl0ZSB0by1ibHVlLTUwIHJvdW5kZWQtMnhsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwLzYwIG92ZXJmbG93LWhpZGRlblwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB0LTYgcGItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyIGZyb20taW5kaWdvLTUwMCB0by1ibHVlLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbWQgc2hhZG93LWluZGlnby0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUaHVuZGVyYm9sdE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC1zbVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBdmFpbGFibGUgT3BlcmF0aW9uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgYSBjdXN0b21lciBlbnJvbGxtZW50IHRvIHBlcmZvcm0gYW55IG9mIHRoZSBmb2xsb3dpbmcgYWN0aW9uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFNlbGVjdGVkIHRpY2tldCBpbmRpY2F0b3IgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRW5yb2xsbWVudERhdGE/LmVucm9sbG1lbnRJZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMS41IHJvdW5kZWQtZnVsbCBiZy1ncmVlbi01MCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZ3JlZW4tNTAwIGFuaW1hdGUtcHVsc2VcIj48L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlja2V0IFNlbGVjdGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIE9wZXJhdGlvbiBDYXJkcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHBiLTYgZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNiBnYXAtM1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBDSElUIENBTkNFTCA9PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkaXNhYmxlZD17IXNlbGVjdGVkRW5yb2xsbWVudERhdGE/LmVucm9sbG1lbnRJZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZUFjdGlvblR5cGUoXCJDSElUX0NBTkNFTFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YFxyXG4gICAgICAgIGdyb3VwIHJlbGF0aXZlIHRleHQtbGVmdCBiZy13aGl0ZSByb3VuZGVkLXhsXHJcbiAgICAgICAgYm9yZGVyIHAtNCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcclxuICAgICAgICBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcmVkLTMwMFxyXG4gICAgICAgICR7YWN0aXZlQWN0aW9uVHlwZSA9PT0gXCJDSElUX0NBTkNFTFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXJlZC01MDAgYmctcmVkLTUwLzUwIHNoYWRvdy1sZyByaW5nLTIgcmluZy1yZWQtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItZ3JheS0xNTAgaG92ZXI6c2hhZG93LWxnIGhvdmVyOnNoYWRvdy1yZWQtMTAwLzUwIGhvdmVyOmJvcmRlci1yZWQtMjAwIGN1cnNvci1wb2ludGVyXCJcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgIGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJJR0hUIENIRUNLIE1BUksgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZUFjdGlvblR5cGUgPT09IFwiQ0hJVF9DQU5DRUxcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgcmlnaHQtMyB6LTUwIHctNyBoLTcgcm91bmRlZC1mdWxsIGJnLWJsdWUtNTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1kQ2hlY2sgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEJhY2tncm91bmQgaG92ZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1yZWQtNTAgdG8tdHJhbnNwYXJlbnQgb3BhY2l0eS0wIGdyb3VwLWhvdmVyOm9wYWNpdHktMTAwIHRyYW5zaXRpb24tb3BhY2l0eSBkdXJhdGlvbi0zMDBcIj48L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIENvbnRlbnQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YFxyXG4gICAgICAgICAgICAgICAgdy0xMSBoLTExIHJvdW5kZWQteGxcclxuICAgICAgICAgICAgICAgIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tcmVkLTkwMCB0by1yb3NlLTYwMFxyXG4gICAgICAgICAgICAgICAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWItM1xyXG4gICAgICAgICAgICAgICAgc2hhZG93LW1kIHNoYWRvdy1yZWQtMjAwLzYwXHJcbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcclxuICAgICAgICAgICAgICAgICR7YWN0aXZlQWN0aW9uVHlwZSA9PT0gXCJDSElUX0NBTkNFTFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJzY2FsZS0xMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiZ3JvdXAtaG92ZXI6c2NhbGUtMTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZENhbmNlbCBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQteGxcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoaXQgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGVybWFuZW50bHkgY2FuY2VsIHRoZSBlbnJvbGxtZW50IHdpdGggc2V0dGxlbWVudCBjYWxjdWxhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xLjUgaC0xLjUgcm91bmRlZC1mdWxsIGJnLXJlZC00MDBcIj48L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXJlZC01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVybWluYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPT09PT09PT09PT09PT09PT0gQ0hJVCBDTE9TRSA9PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkaXNhYmxlZD17IXNlbGVjdGVkRW5yb2xsbWVudERhdGE/LmVucm9sbG1lbnRJZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlmICghY2hlY2tDdXN0b21lck9wZXJhdGlvbkFsbG93ZWQoKSkgcmV0dXJuO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlQWN0aW9uVHlwZShcIkNISVRfQ0xPU0VcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGhhbmRsZVByb2NlZWRUb1NldHRsZW1lbnRDb25maXJtKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BcclxuICAgICAgICBncm91cCByZWxhdGl2ZSB0ZXh0LWxlZnQgYmctd2hpdGUgcm91bmRlZC14bFxyXG4gICAgICAgIGJvcmRlciBwLTQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXHJcbiAgICAgICAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXJlZC0zMDBcclxuICAgICAgICAke2FjdGl2ZUFjdGlvblR5cGUgPT09IFwiQ0hJVF9DTE9TRVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYm9yZGVyLXJlZC01MDAgYmctcmVkLTUwLzUwIHNoYWRvdy1sZyByaW5nLTIgcmluZy1yZWQtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJib3JkZXItZ3JheS0xNTAgaG92ZXI6c2hhZG93LWxnIGhvdmVyOnNoYWRvdy1yZWQtMTAwLzUwIGhvdmVyOmJvcmRlci1yZWQtMjAwIGN1cnNvci1wb2ludGVyXCJcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgIGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJJR0hUIENIRUNLIE1BUksgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZUFjdGlvblR5cGUgPT09IFwiQ0hJVF9DTE9TRVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMyByaWdodC0zIHotNTAgdy03IGgtNyByb3VuZGVkLWZ1bGwgYmctYmx1ZS01MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LW1kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWRDaGVjayBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tb3JhbmdlLTUwIHRvLXRyYW5zcGFyZW50IG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgZHVyYXRpb24tMzAwXCI+PC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BcclxuICAgICAgICAgICAgICAgIHctMTEgaC0xMSByb3VuZGVkLXhsXHJcbiAgICAgICAgICAgICAgICBiZy1ncmFkaWVudC10by1iciBmcm9tLXJlZC02MDAgdG8tcm9zZS00MDBcclxuICAgICAgICAgICAgICAgIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTNcclxuICAgICAgICAgICAgICAgIHNoYWRvdy1tZCBzaGFkb3ctcmVkLTIwMC82MFxyXG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwXHJcbiAgICAgICAgICAgICAgICAke2FjdGl2ZUFjdGlvblR5cGUgPT09IFwiQ0hJVF9DTE9TRVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJzY2FsZS0xMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiZ3JvdXAtaG92ZXI6c2NhbGUtMTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFN0b3BPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoaXQgQ2xvc2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGxlYWRpbmctcmVsYXhlZCB0ZXh0LWdyYXktNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbG9zZSB0aGUgY2hpdCBhZnRlciBhbGwgaW5zdGFsbG1lbnRzIGFyZSBjb21wbGV0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1vcmFuZ2UtNDAwXCI+PC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1vcmFuZ2UtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENvbXBsZXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qID09PT09PT09PT09PT09PT09IENISVQgVFJBTlNGRVIgPT09PT09PT09PT09PT09PT0gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZGlzYWJsZWQ9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAhc2VsZWN0ZWRFbnJvbGxtZW50RGF0YT8uZW5yb2xsbWVudElkIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgIHRyYW5zZmVyTG9hZGluZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlmICghY2hlY2tDdXN0b21lck9wZXJhdGlvbkFsbG93ZWQoKSkgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVBY3Rpb25UeXBlKFwiQ0hJVF9UUkFOU0ZFUlwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaGFuZGxlVHJhbnNmZXJDbGljayhzZWxlY3RlZEVucm9sbG1lbnREYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YFxyXG4gICAgICAgIGdyb3VwIHJlbGF0aXZlIHRleHQtbGVmdCBiZy13aGl0ZSByb3VuZGVkLXhsXHJcbiAgICAgICAgYm9yZGVyIHAtNCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcclxuICAgICAgICBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcmVkLTMwMFxyXG4gICAgICAgICR7YWN0aXZlQWN0aW9uVHlwZSA9PT0gXCJDSElUX1RSQU5TRkVSXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItcmVkLTUwMCBiZy1yZWQtNTAvNTAgc2hhZG93LWxnIHJpbmctMiByaW5nLXJlZC0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJvcmRlci1ncmF5LTE1MCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6c2hhZG93LXJlZC0xMDAvNTAgaG92ZXI6Ym9yZGVyLXJlZC0yMDAgY3Vyc29yLXBvaW50ZXJcIlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUklHSFQgQ0hFQ0sgTUFSSyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZlQWN0aW9uVHlwZSA9PT0gXCJDSElUX1RSQU5TRkVSXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIHJpZ2h0LTMgei01MCB3LTcgaC03IHJvdW5kZWQtZnVsbCBiZy1ibHVlLTUwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZENoZWNrIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwIHRvLXRyYW5zcGFyZW50IG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgZHVyYXRpb24tMzAwXCI+PC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BcclxuICAgICAgICAgICAgICAgIHctMTEgaC0xMSByb3VuZGVkLXhsXHJcbiAgICAgICAgICAgICAgICBiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAwIHRvLXJvc2UtNTAwXHJcbiAgICAgICAgICAgICAgICBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi0zXHJcbiAgICAgICAgICAgICAgICBzaGFkb3ctbWQgc2hhZG93LXJlZC0yMDAvNjBcclxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMFxyXG4gICAgICAgICAgICAgICAgJHthY3RpdmVBY3Rpb25UeXBlID09PSBcIkNISVRfQ0FOQ0VMXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInNjYWxlLTExMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJncm91cC1ob3ZlcjpzY2FsZS0xMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNmZXJMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTd2FwT3V0bGluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3BpblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTd2FwT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RyYW5zZmVyTG9hZGluZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJUcmFuc2ZlcnJpbmcuLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJDaGl0IFRyYW5zZmVyXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVHJhbnNmZXIgZW5yb2xsbWVudCBvd25lcnNoaXAgdG8gYW5vdGhlciBzdWJzY3JpYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEuNSBoLTEuNSByb3VuZGVkLWZ1bGwgYmctYmx1ZS00MDBcIj48L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWJsdWUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRyYW5zZmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBTVVNQRU5EID09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRpc2FibGVkPXshc2VsZWN0ZWRFbnJvbGxtZW50RGF0YT8uZW5yb2xsbWVudElkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaWYgKCFjaGVja0N1c3RvbWVyT3BlcmF0aW9uQWxsb3dlZCgpKSByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZUFjdGlvblR5cGUoXCJTVVNQRU5EXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBoYW5kbGVPbkhvbGRNb2RlbE9wZW4oXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBzZWxlY3RlZEVucm9sbG1lbnREYXRhPy5lbnJvbGxtZW50SWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBcInN1c3BlbmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgXHJcbiAgICAgICAgZ3JvdXAgcmVsYXRpdmUgdGV4dC1sZWZ0IGJnLXdoaXRlIHJvdW5kZWQteGxcclxuICAgICAgICBib3JkZXIgcC00IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFxyXG4gICAgICAgIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1yZWQtMzAwXHJcbiAgICAgICAgJHthY3RpdmVBY3Rpb25UeXBlID09PSBcIlNVU1BFTkRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1yZWQtNTAwIGJnLXJlZC01MC81MCBzaGFkb3ctbGcgcmluZy0yIHJpbmctcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLWdyYXktMTUwIGhvdmVyOnNoYWRvdy1sZyBob3ZlcjpzaGFkb3ctcmVkLTEwMC81MCBob3Zlcjpib3JkZXItcmVkLTIwMCBjdXJzb3ItcG9pbnRlclwiXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSSUdIVCBDSEVDSyBNQVJLICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthY3RpdmVBY3Rpb25UeXBlID09PSBcIlNVU1BFTkRcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgcmlnaHQtMyB6LTUwIHctNyBoLTcgcm91bmRlZC1mdWxsIGJnLWJsdWUtNTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1kQ2hlY2sgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1iciBmcm9tLXllbGxvdy01MCB0by10cmFuc3BhcmVudCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTMwMFwiPjwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BcclxuICAgICAgICAgICAgICAgIHctMTEgaC0xMSByb3VuZGVkLXhsXHJcbiAgICAgICAgICAgICAgICBiZy1ncmFkaWVudC10by1iciBmcm9tLWluZGlnby03MDAgdG8tdmlvbGV0LTQwMFxyXG4gICAgICAgICAgICAgICAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbWItM1xyXG4gICAgICAgICAgICAgICAgc2hhZG93LW1kIHNoYWRvdy1yZWQtMjAwLzYwXHJcbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcclxuICAgICAgICAgICAgICAgICR7YWN0aXZlQWN0aW9uVHlwZSA9PT0gXCJTVVNQRU5EXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwic2NhbGUtMTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiZ3JvdXAtaG92ZXI6c2NhbGUtMTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFBhdXNlQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTdXNwZW5kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVtcG9yYXJpbHkgc3VzcGVuZCB0aGUgZW5yb2xsbWVudCBmb3IgYSBzcGVjaWZpYyBwZXJpb2RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy15ZWxsb3ctNDAwXCI+PC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC15ZWxsb3ctNjAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBhdXNlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBPTiBIT0xEID09PT09PT09PT09PT09PT09ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRpc2FibGVkPXshc2VsZWN0ZWRFbnJvbGxtZW50RGF0YT8uZW5yb2xsbWVudElkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaWYgKCFjaGVja0N1c3RvbWVyT3BlcmF0aW9uQWxsb3dlZCgpKSByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZUFjdGlvblR5cGUoXCJob2xkXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBoYW5kbGVPbkhvbGRNb2RlbE9wZW4oXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBzZWxlY3RlZEVucm9sbG1lbnREYXRhPy5lbnJvbGxtZW50SWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBcImhvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgXHJcbiAgICAgICAgZ3JvdXAgcmVsYXRpdmUgdGV4dC1sZWZ0IGJnLXdoaXRlIHJvdW5kZWQteGxcclxuICAgICAgICBib3JkZXIgcC00IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFxyXG4gICAgICAgIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1yZWQtMzAwXHJcbiAgICAgICAgJHthY3RpdmVBY3Rpb25UeXBlID09PSBcImhvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJvcmRlci1yZWQtNTAwIGJnLXJlZC01MC81MCBzaGFkb3ctbGcgcmluZy0yIHJpbmctcmVkLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLWdyYXktMTUwIGhvdmVyOnNoYWRvdy1sZyBob3ZlcjpzaGFkb3ctcmVkLTEwMC81MCBob3Zlcjpib3JkZXItcmVkLTIwMCBjdXJzb3ItcG9pbnRlclwiXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSSUdIVCBDSEVDSyBNQVJLICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthY3RpdmVBY3Rpb25UeXBlID09PSBcImhvbGRcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgcmlnaHQtMyB6LTUwIHctNyBoLTcgcm91bmRlZC1mdWxsIGJnLWJsdWUtNTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1kQ2hlY2sgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1iciBmcm9tLXB1cnBsZS01MCB0by10cmFuc3BhcmVudCBvcGFjaXR5LTAgZ3JvdXAtaG92ZXI6b3BhY2l0eS0xMDAgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTMwMFwiPjwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHotMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgXHJcbiAgICAgICAgICAgICAgICB3LTExIGgtMTEgcm91bmRlZC14bFxyXG4gICAgICAgICAgICAgICAgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS15ZWxsb3ctNTAwIHRvLXJvc2UtNjAwXHJcbiAgICAgICAgICAgICAgICBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi0zXHJcbiAgICAgICAgICAgICAgICBzaGFkb3ctbWQgc2hhZG93LXJlZC0yMDAvNjBcclxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTMwMFxyXG4gICAgICAgICAgICAgICAgJHthY3RpdmVBY3Rpb25UeXBlID09PSBcImhvbGRzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJzY2FsZS0xMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiZ3JvdXAtaG92ZXI6c2NhbGUtMTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxWc2NSZW1vdmUgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPbiBIb2xkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBsZWFkaW5nLXJlbGF4ZWQgdGV4dC1ncmF5LTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGxhY2UgdGhlIGVucm9sbG1lbnQgb24gaG9sZCBwZW5kaW5nIHJldmlldyBvciBhY3Rpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IHJvdW5kZWQtZnVsbCBiZy1wdXJwbGUtNDAwXCI+PC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1wdXJwbGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlbmRpbmdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA9PT09PT09PT09PT09PT09PSBBQ1RJVkUgLyBJTkFDVElWRSA9PT09PT09PT09PT09PT09PSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBkaXNhYmxlZD17c2VsZWN0ZWRFbnJvbGxtZW50RGF0YT8uZW5yb2xsbWVudD8uY3VzdG9tZXJfc3RhdHVzPy50b0xvd2VyQ2FzZSgpICE9PSBcIm9uIGhvbGRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlmIChnZXRDdXN0b21lclN0YXR1cygpLnRvTG93ZXJDYXNlKCkgIT09IFwib24gaG9sZFwiKSByZXR1cm47XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzZWxlY3RlZEVucm9sbG1lbnREYXRhPy5lbnJvbGxtZW50Py5jdXN0b21lcl9zdGF0dXM/LnRvTG93ZXJDYXNlKCkgPT09IFwib24gaG9sZFwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlQWN0aW9uVHlwZShcImFjdGl2ZS1pbmFjdGl2ZVwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaGFuZGxlT25Ib2xkTW9kZWxPcGVuKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgc2VsZWN0ZWRFbnJvbGxtZW50RGF0YT8uZW5yb2xsbWVudElkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgXCJhY3RpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgXHJcbiAgICAgICAgZ3JvdXAgcmVsYXRpdmUgdGV4dC1sZWZ0IGJnLXdoaXRlIHJvdW5kZWQteGxcclxuICAgICAgICBib3JkZXIgcC00IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMFxyXG4gICAgICAgIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ncmVlbi0zMDBcclxuICAgICAgICAke3NlbGVjdGVkRW5yb2xsbWVudERhdGE/LmVucm9sbG1lbnQ/LmN1c3RvbWVyX3N0YXR1cz8udG9Mb3dlckNhc2UoKSA9PT0gXCJvbiBob2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJib3JkZXItZ3JheS0xNTAgaG92ZXI6c2hhZG93LWxnIGhvdmVyOnNoYWRvdy1ncmVlbi0xMDAvNTAgaG92ZXI6Ym9yZGVyLWdyZWVuLTIwMCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYm9yZGVyLWdyYXktMTUwIG9wYWNpdHktNTAgY3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUklHSFQgQ0hFQ0sgTUFSSyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZlQWN0aW9uVHlwZSA9PT0gXCJhY3RpdmUtaW5hY3RpdmVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgcmlnaHQtMyB6LTUwIHctNyBoLTcgcm91bmRlZC1mdWxsIGJnLWJsdWUtNTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1kQ2hlY2sgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTUwIHRvLXRyYW5zcGFyZW50IG9wYWNpdHktMCBncm91cC1ob3ZlcjpvcGFjaXR5LTEwMCB0cmFuc2l0aW9uLW9wYWNpdHkgZHVyYXRpb24tMzAwXCI+PC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgei0xMFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTExIGgtMTEgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTUwMCB0by1lbWVyYWxkLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBtYi0zIHNoYWRvdy1tZCBzaGFkb3ctZ3JlZW4tMjAwLzYwIGdyb3VwLWhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTWFrZSBBY3RpdmUgLyBJbmFjdGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gbGVhZGluZy1yZWxheGVkIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoYW5nZSBjdXN0b21lciBzdGF0dXMgZnJvbSBPbiBIb2xkIHRvIEFjdGl2ZSBvciBJbmFjdGl2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xLjUgaC0xLjUgcm91bmRlZC1mdWxsIGJnLWdyZWVuLTQwMFwiPjwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JlZW4tNjAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0YXR1cyBDaGFuZ2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogVGlwICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcGItNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1ncmF5LTUwLzgwIHJvdW5kZWQtbGcgcHgtNCBweS0yLjUgYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbmZvQ2lyY2xlT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMCB0ZXh0LXNtIGZsZXgtc2hyaW5rLTBcIiAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlwOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgYSBjdXN0b21lciBmcm9tIHRoZSBzZWFyY2ggYmVsb3csIHRoZW4gY2hvb3NlIGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGlja2V0IHRvIGFjdGl2YXRlIHRoZXNlIG9wZXJhdGlvbnMuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFF1aWNrU2VhcmNoQ29udGVudCBrZXk9e3F1aWNrU2VhcmNoS2V5fSBvblNlbGVjdD17aGFuZGxlUXVpY2tTZWFyY2hTZWxlY3R9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogMi4gQ3VzdG9tZXIgUG9ydGZvbGlvIFZpZXcgKi99XHJcbiAgICAgICAgICAgICAgICAgICAge3JlbmRlckN1c3RvbWVyUG9ydGZvbGlvKCl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiAzLiBBY3Rpb24gRm9ybSAqL31cclxuICAgICAgICAgICAgICAgICAgICB7YWN0aXZlQWN0aW9uVHlwZSAmJiBzZWxlY3RlZEVucm9sbG1lbnREYXRhICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBpZD1cImFjdGlvbi1mb3JtLXNlY3Rpb25cIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBiZy1ibHVlLTUwIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgcm91bmRlZC14bCBwLTYgbXQtNiBhbmltYXRlLWZhZGUtaW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthY3Rpb25Mb2FkaW5nICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy13aGl0ZS83MCBiYWNrZHJvcC1ibHVyLXNtIHJvdW5kZWQteGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNwaW4gc2l6ZT1cImxhcmdlXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ibHVlLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIExvYWRpbmcgY3VzdG9tZXIgZGV0YWlscy4uLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ibHVlLTkwMCBtYi00IGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0T3V0bGluZWQgLz4gQ3VzdG9tZXIgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtIGZvcm09e2FkZFJlcXVlc3RGb3JtfSBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIGxhYmVsPVwiU3Vic2NyaWJlciBOYW1lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXQgdmFsdWU9e3NlbGVjdGVkQ3VzdG9tZXI/LmZ1bGxfbmFtZSB8fCBcIlwifSBkaXNhYmxlZCBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6ICcjZjBmMGYwJywgY29sb3I6ICcjMzMzJyB9fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBsYWJlbD1cIk1vYmlsZSBOdW1iZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dCB2YWx1ZT17c2VsZWN0ZWRDdXN0b21lcj8ucGhvbmVfbnVtYmVyIHx8IFwiXCJ9IGRpc2FibGVkIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogJyNmMGYwZjAnLCBjb2xvcjogJyMzMzMnIH19IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIGxhYmVsPVwiR3JvdXAgTmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0IHZhbHVlPXtzZWxlY3RlZEVucm9sbG1lbnREYXRhPy5lbnJvbGxtZW50Py5ncm91cC5ncm91cF9uYW1lfSBkaXNhYmxlZCBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6ICcjZjBmMGYwJywgY29sb3I6ICcjMzMzJyB9fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBsYWJlbD1cIlRpY2tldCBOdW1iZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dCB2YWx1ZT17c2VsZWN0ZWRFbnJvbGxtZW50RGF0YT8uZW5yb2xsbWVudD8udGlja2V0c30gZGlzYWJsZWQgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiAnI2YwZjBmMCcsIGNvbG9yOiAnIzMzMycgfX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgbWItM1wiPjIuIFBheW1lbnQgQ2FsY3VsYXRpb248L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgbWQ6ZmxleC1yb3cgaXRlbXMtY2VudGVyIGdhcC01IGJnLWluZGlnby01MCBwLTUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWluZGlnby0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInByaW1hcnlcIiBzaXplPVwibGFyZ2VcIiBvbkNsaWNrPXtmZXRjaFRvdGFsQW1vdW50fSBkaXNhYmxlZD17IXNlbGVjdGVkRW5yb2xsSWQgfHwgbG9hZGluZ30gY2xhc3NOYW1lPVwidy1mdWxsIG1kOnctYXV0byBiZy1pbmRpZ28tNjAwIGhvdmVyOmJnLWluZGlnby03MDAgZm9udC1tZWRpdW0gc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyA8U3BpbiBzaXplPVwic21hbGxcIiAvPiA6IFwiUmVmcmVzaCBUb3RhbCBBbW91bnRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3RvdGFsQW1vdW50ICE9PSBudWxsICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyB0ZXh0LWNlbnRlciBtZDp0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTUwMCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlRvdGFsIENhbGN1bGF0ZWQgQW1vdW50PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtaW5kaWdvLTgwMFwiPuKCuSB7TnVtYmVyKHRvdGFsQW1vdW50KS50b0xvY2FsZVN0cmluZygpfTwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImxpbmtcIiBvbkNsaWNrPXtmZXRjaEFsbFRyYW5zYWN0aW9uc30gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNTAwIHRleHQteHNcIj5WaWV3IEFsbCBUcmFuc2FjdGlvbnMg4oaSPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0yIG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVBY3Rpb25UeXBlKG51bGwpfT5DYW5jZWw8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRlZmF1bHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PFZzY1JlbW92ZSAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU9uSG9sZE1vZGVsT3BlbihzZWxlY3RlZEVucm9sbG1lbnREYXRhLmVucm9sbG1lbnQuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLW9yYW5nZS01MDAgaG92ZXI6Ymctb3JhbmdlLTYwMCBib3JkZXItbm9uZSB0ZXh0LXdoaXRlIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBsYWNlIE9uIEhvbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVByb2NlZWRUb1NldHRsZW1lbnRDb25maXJtfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyF0b3RhbEFtb3VudCB8fCBsb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctaW5kaWdvLTYwMCBob3ZlcjpiZy1pbmRpZ28tNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJvY2VlZCB3aXRoIENoaXQge2dldEFjdGlvbkJ1dHRvblRleHQoYWN0aXZlQWN0aW9uVHlwZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNwYWNlIHNpemU9XCJzbWFsbFwiIHdyYXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PE1kQ2hlY2sgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBY3Rpb25DbGljaygnQ0hJVF9DQU5DRUwnLCBpdGVtKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFRoaXMgVGlja2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJtZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PFN0b3BPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBY3Rpb25DbGljaygnQ0hJVF9DTE9TRScsIGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoaXQgQ2xvc2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJtZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnaG9zdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRyYW5zZmVyQ2xpY2soaXRlbSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17dHJhbnNmZXJMb2FkaW5nID8gPFN3YXBPdXRsaW5lZCBzcGluIC8+IDogPFN3YXBPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17dHJhbnNmZXJMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshdHJhbnNmZXJMb2FkaW5nID8gXCJDaGl0IFRyYW5zZmVyXCIgOiBcIlRyYW5zZmVycmluZy4uLlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU3BhY2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAganVzdGlmeS1lbmQgZ2FwLTMgbXQtNiBwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZUFjdGlvblR5cGUobnVsbCl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZUFjdGlvblR5cGUgPT09IFwiQ0hJVF9DQU5DRUxcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshdG90YWxBbW91bnQgfHwgbG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghY2hlY2tDdXN0b21lck9wZXJhdGlvbkFsbG93ZWQoKSkgcmV0dXJuO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWN0aXZlQWN0aW9uVHlwZShcIkNISVRfQ0FOQ0VMXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVQcm9jZWVkVG9TZXR0bGVtZW50Q29uZmlybSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctaW5kaWdvLTYwMCBob3ZlcjpiZy1pbmRpZ28tNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uPXs8TWRDYW5jZWwgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJvY2VlZCB0byBDaGl0IENhbmNlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZlQWN0aW9uVHlwZSA9PT0gXCJDSElUX0NMT1NFXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYW5nZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXRvdGFsQW1vdW50IHx8IGxvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWNoZWNrQ3VzdG9tZXJPcGVyYXRpb25BbGxvd2VkKCkpIHJldHVybjtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZUFjdGlvblR5cGUoXCJDSElUX0NMT1NFXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVQcm9jZWVkVG9TZXR0bGVtZW50Q29uZmlybSgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PFN0b3BPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcm9jZWVkIHRvIENoaXQgQ2xvc2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZUFjdGlvblR5cGUgPT09IFwiQ0hJVF9UUkFOU0ZFUlwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3RyYW5zZmVyTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghY2hlY2tDdXN0b21lck9wZXJhdGlvbkFsbG93ZWQoKSkgcmV0dXJuO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVHJhbnNmZXJDbGljayhzZWxlY3RlZEVucm9sbG1lbnREYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb249e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2ZlckxvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U3dhcE91dGxpbmVkIHNwaW4gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTd2FwT3V0bGluZWQgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJib3JkZXItYmx1ZS01MDAgdGV4dC1ibHVlLTEwMCBob3ZlcjpiZy1ibHVlLTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNmZXJMb2FkaW5nID8gXCJUcmFuc2ZlcnJpbmcuLi5cIiA6IFwiUHJvY2VlZCB3aXRoIENoaXQgVHJhbnNmZXJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZUFjdGlvblR5cGUgPT09IFwiaG9sZFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGVmYXVsdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWNoZWNrQ3VzdG9tZXJPcGVyYXRpb25BbGxvd2VkKCkpIHJldHVybjtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZU9uSG9sZE1vZGVsT3BlbihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW5yb2xsbWVudERhdGE/LmVucm9sbG1lbnRJZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PFZzY1JlbW92ZSAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1vcmFuZ2UtNTAwIGhvdmVyOmJnLW9yYW5nZS02MDAgYm9yZGVyLW5vbmUgdGV4dC13aGl0ZSBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBsYWNlIE9uIEhvbGRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2FjdGl2ZUFjdGlvblR5cGUgPT09IFwiU1VTUEVORFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGVmYXVsdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWNoZWNrQ3VzdG9tZXJPcGVyYXRpb25BbGxvd2VkKCkpIHJldHVybjtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZU9uSG9sZE1vZGVsT3BlbihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW5yb2xsbWVudERhdGE/LmVucm9sbG1lbnRJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwic3VzcGVuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uPXs8UGF1c2VDaXJjbGVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1pbmRpZ28tNjAwIGhvdmVyOmJnLWluZGlnby03MDAgYm9yZGVyLW5vbmUgdGV4dC13aGl0ZSBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByb2NlZWQgd2l0aCBTdXNwZW5kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHthY3RpdmVBY3Rpb25UeXBlID09PSBcImFjdGl2ZS1pbmFjdGl2ZVwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBpZiAoIWNoZWNrQ3VzdG9tZXJPcGVyYXRpb25BbGxvd2VkKCkpIHJldHVybjtcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZU9uSG9sZE1vZGVsT3BlbihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkRW5yb2xsbWVudERhdGE/LmVucm9sbG1lbnRJZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiYWN0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb249ezxDaGVja0NpcmNsZU91dGxpbmVkIC8+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyZWVuLTYwMCBob3ZlcjpiZy1ncmVlbi03MDAgYm9yZGVyLW5vbmUgdGV4dC13aGl0ZSBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1ha2UgQWN0aXZlIC8gSW5hY3RpdmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcInRyYW5zYWN0aW9uLWhpc3RvcnlcIixcclxuICAgICAgICAgICAgbGFiZWw6IFwiT3RoZXIgVHJhbnNhY3Rpb24gSGlzdG9yeVwiLFxyXG4gICAgICAgICAgICBjaGlsZHJlbjogKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICB7c3RhdHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTYgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRvdGFsIFRyYW5zYWN0aW9ucyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBib3JkZXItdC00IGJvcmRlci1ibHVlLTYwMCBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIHAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBUcmFuc2FjdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXRzLnRvdGFsLmNvdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtYmx1ZS02MDAgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7c3RhdHMudG90YWwuYW1vdW50LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIENoaXQgQ2FuY2VsbGF0aW9ucyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBib3JkZXItdC00IGJvcmRlci1yZWQtNTAwIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgcC01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoaXQgQ2FuY2VsbGF0aW9uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHMuY2hpdENhbmNlbC5jb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LXJlZC02MDAgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7c3RhdHMuY2hpdENhbmNlbC5hbW91bnQudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUGlnbXkgV2l0aGRyYXdhbHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgYm9yZGVyLXQtNCBib3JkZXItZW1lcmFsZC01MDAgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBwLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGlnbXkgV2l0aGRyYXdhbHNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXRzLnBpZ215LmNvdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC02MDAgbXQtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7c3RhdHMucGlnbXkuYW1vdW50LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIExvYW4gVHJhbnNhY3Rpb25zICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBib3JkZXItdC00IGJvcmRlci1wdXJwbGUtNTAwIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgcC01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIExvYW4gVHJhbnNhY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0cy5sb2FuLmNvdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtcHVycGxlLTYwMCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtzdGF0cy5sb2FuLmFtb3VudC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHNoYWRvdy1zbSBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IGRhdGE9XCJUcmFuc2FjdGlvbnNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogdHJhbnNhY3Rpb25zLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFbXB0eSBkZXNjcmlwdGlvbj1cIk5vIFRyYW5zYWN0aW9ucyBGb3VuZFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17dHJhbnNhY3Rpb25zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiVHJhbnNhY3Rpb25fUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiVHJhbnNhY3Rpb25fUmVwb3J0LmNzdlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgIClcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcInN1c3BlbmRlZC1jdXN0b21lcnNcIixcclxuICAgICAgICAgICAgbGFiZWw6IFwiU3VzcGVuZGVkIEN1c3RvbWVyc1wiLFxyXG4gICAgICAgICAgICBjaGlsZHJlbjogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgc2hhZG93LXNtIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdXNwZW5kZWRDdXN0b21lclJlcG9ydCAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgfSxcclxuICAgIF07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjAgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICA8TmF2YmFyIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KCkgPT4geyB9fSB2aXNpYmlsaXR5PXt0cnVlfSAvPlxyXG4gICAgICAgICAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICAgICAgICAgIDxDdXN0b21BbGVydCB0eXBlPXthbGVydENvbmZpZy50eXBlfSBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9IG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9IC8+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTcgYmctZ3JheS01MCBtaW4taC1zY3JlZW4gbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZpU2h1ZmZsZSBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtOTAwXCIgLz4gT3RoZXIgVHJhbnNhY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIDxUYWJzIGFjdGl2ZUtleT17YWN0aXZlVGFiS2V5fSBvbkNoYW5nZT17c2V0QWN0aXZlVGFiS2V5fSBpdGVtcz17dGFiSXRlbXN9IHR5cGU9XCJjYXJkXCIgIC8+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxUYWJzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2ZUtleT17YWN0aXZlVGFiS2V5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBvbkNoYW5nZT17c2V0QWN0aXZlVGFiS2V5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlVGFiQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpdGVtcz17dGFiSXRlbXN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjYXJkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGFiQmFyRXh0cmFDb250ZW50PXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9jaGl0LWNhbmNlbGF0aW9uLXBheS1vdXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBib3JkZXIgYm9yZGVyLWJsdWUtNTAwIHRleHQtYmx1ZS02MDAgcm91bmRlZC1tZCBob3ZlcjpiZy1ibHVlLTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoaXQgQ2FuY2VsL0Nsb3NlIFBheU91dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvcGF5bWVudC1tZW51L3BheW1lbnQtaW4tb3V0LW1lbnUvcGF5LWluLW1lbnUvY2hpdC10cmFuc2Zlci1wYXktaW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBib3JkZXIgYm9yZGVyLWdyZWVuLTUwMCB0ZXh0LWdyZWVuLTYwMCByb3VuZGVkLW1kIGhvdmVyOmJnLWdyZWVuLTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoaXQgVHJhbnNmZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEFkZCBSZXF1ZXN0IE1vZGFsIChrZXB0IHVuY2hhbmdlZCkgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPEFudE1vZGFsIHRpdGxlPVwiUHJvY2VzcyBDYW5jZWxsYXRpb24gLyBUcmFuc2ZlclwiIG9wZW49e2lzQWRkUmVxdWVzdE1vZGFsT3Blbn0gb25DYW5jZWw9eygpID0+IHsgc2V0SXNBZGRSZXF1ZXN0TW9kYWxPcGVuKGZhbHNlKTsgYWRkUmVxdWVzdEZvcm0ucmVzZXRGaWVsZHMoKTsgc2V0U2VsZWN0ZWRDdXN0b21lcihudWxsKTsgc2V0U2VsZWN0ZWRFbnJvbGxtZW50RGF0YShudWxsKTsgc2V0Q3VzdG9tZXJFbnJvbGxtZW50cyhbXSk7IHNldEFjdGl2ZUFjdGlvblR5cGUobnVsbCk7IH19IGZvb3Rlcj17bnVsbH0gd2lkdGg9ezgwMH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIGxhYmVsPVwiU2VhcmNoIEN1c3RvbWVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdCBzaG93U2VhcmNoIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IE5hbWUsIFBob25lLCBBYWRoYWFyLi4uXCIgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4gKG9wdGlvbj8ubGFiZWwgPz8gXCJcIikudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKX0gb25DaGFuZ2U9eyh2YWwpID0+IGhhbmRsZUN1c3RvbWVyQ2hhbmdlKHZhbCl9IHZhbHVlPXtzZWxlY3RlZEN1c3RvbWVyPy5faWR9IG9wdGlvbnM9e3VzZXJzLm1hcCgodXNlcikgPT4gKHsgdmFsdWU6IHVzZXIuX2lkLCBsYWJlbDogYCR7dXNlci5mdWxsX25hbWV9IC0gJHt1c2VyLnBob25lX251bWJlcn1gIH0pKX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbmRlckN1c3RvbWVyUG9ydGZvbGlvKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWN0aXZlQWN0aW9uVHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybSBmb3JtPXthZGRSZXF1ZXN0Rm9ybX0gbGF5b3V0PVwidmVydGljYWxcIiBvbkZpbmlzaD17aGFuZGxlQWRkQ2FuY2VsUmVxdWVzdH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJhbW91bnRcIiBsYWJlbD1cIkFtb3VudFwiIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSB9XX0+PElucHV0IHR5cGU9XCJudW1iZXJcIiBwcmVmaXg9XCLigrlcIiAvPjwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cInJlYXNvblwiIGxhYmVsPVwiUmVhc29uXCIgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlIH1dfT48SW5wdXQuVGV4dEFyZWEgcm93cz17MX0gLz48L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRJc0FkZFJlcXVlc3RNb2RhbE9wZW4oZmFsc2UpfT5DYW5jZWw8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgaHRtbFR5cGU9XCJzdWJtaXRcIiBsb2FkaW5nPXtjYW5jZWxSZXF1ZXN0c0xvYWRpbmd9PlN1Ym1pdDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQW50TW9kYWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBDYW5jZWxsYXRpb24gJiBUcmFuc2ZlciBNb2RhbCAodW5jaGFuZ2VkKSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8TW9kYWwgaXNWaXNpYmxlPXtzaG93TW9kYWx9IG9uQ2xvc2U9e2hhbmRsZUNsb3NlTW9kYWx9IHNob3dDbG9zZUJ1dHRvbj17ZmFsc2V9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c3RlcCA9PT0gMSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVDbG9zZU1vZGFsfSBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMiByaWdodC0yIHAtMSB0ZXh0LTJ4bCB0ZXh0LXJlZC01MDAgaG92ZXI6YmctZ3JheS0xMDAgei0xMFwiPuKclTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1pbmRpZ28tNzAwIHRvLXNsYXRlLTgwMCBweC04IHB5LTYgdGV4dC1jZW50ZXIgcmVsYXRpdmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGdW5kUHJvamVjdGlvblNjcmVlbk91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC0zeGwgbWItMiBvcGFjaXR5LTkwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBtZDp0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC13aGl0ZSB0cmFja2luZy10aWdodFwiPkNhbmNlbGxhdGlvbiAmIFRyYW5zZmVyIFByb2Nlc3M8L2gxPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tMjAwIHRleHQtc20gbXQtMVwiPlNlbGVjdCBhbiBhY3Rpb24sIGNob29zZSBtZW1iZXIsIGFuZCBzZXR0bGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcGItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPERpdmlkZXIgY2xhc3NOYW1lPVwiIW15LTIgIWJvcmRlci1zbGF0ZS0xMDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIi9wYXltZW50LW1lbnUvcGF5bWVudC1pbi1vdXQtbWVudS9wYXktb3V0LW1lbnUvY2hpdC1jYW5jZWxhdGlvbi1wYXktb3V0XCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTQgcHktMyByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItcmVkLTEwMCB0ZXh0LXJlZC02MDAgaG92ZXI6YmctcmVkLTUwIHRyYW5zaXRpb25cIj48c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPkNoaXQgQ2FuY2VsbGF0aW9uIFBheSBPdXQ8L3NwYW4+PHNwYW4+4oaSPC9zcGFuPjwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1pbi1tZW51L2NoaXQtY2FuY2VsYXRpb24tcGF5LWluXCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTQgcHktMyByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZW1lcmFsZC0xMDAgdGV4dC1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwIHRyYW5zaXRpb25cIj48c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPkNoaXQgQ2FuY2VsbGF0aW9uIFBheSBJbjwvc3Bhbj48c3Bhbj7ihpI8L3NwYW4+PC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHQtOCBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIkNoaXQgQ2FuY2VsbGF0aW9uXCIsIHZhbHVlOiBcIkNISVRfQ0FOQ0VMTEFUSU9OXCIsIGljb246IDxNZENhbmNlbCAvPiwgY29sb3I6IFwiZnJvbS1yZWQtNTAwIHRvLXJlZC02MDBcIiwgaG92ZXI6IFwiaG92ZXI6ZnJvbS1yZWQtNjAwIGhvdmVyOnRvLXJlZC03MDBcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGxhYmVsOiBcIkdyb3VwIENoYW5nZVwiLCB2YWx1ZTogXCJHUk9VUF9DSEFOR0VcIiwgaWNvbjogPFN3YXBPdXRsaW5lZCAvPiwgY29sb3I6IFwiZnJvbS1hbWJlci01MDAgdG8tYW1iZXItNjAwXCIsIGhvdmVyOiBcImhvdmVyOmZyb20tYW1iZXItNjAwIGhvdmVyOnRvLWFtYmVyLTcwMFwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiR3JvdXAgQ2xvc2VcIiwgdmFsdWU6IFwiR1JPVVBfQ0xPU0VEXCIsIGljb246IDxHcm91cE91dGxpbmVkIC8+LCBjb2xvcjogXCJmcm9tLW9yYW5nZS01MDAgdG8tb3JhbmdlLTYwMFwiLCBob3ZlcjogXCJob3Zlcjpmcm9tLW9yYW5nZS02MDAgaG92ZXI6dG8tb3JhbmdlLTcwMFwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgbGFiZWw6IFwiT3RoZXJcIiwgdmFsdWU6IFwiT1RIRVJcIiwgaWNvbjogPEZpbGVUZXh0T3V0bGluZWQgLz4sIGNvbG9yOiBcImZyb20tc2xhdGUtNTAwIHRvLXNsYXRlLTYwMFwiLCBob3ZlcjogXCJob3Zlcjpmcm9tLXNsYXRlLTYwMCBob3Zlcjp0by1zbGF0ZS03MDBcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0ubWFwKChhY3Rpb24pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXthY3Rpb24udmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IHNldFJlbWFya1R5cGUoYWN0aW9uLnZhbHVlKTsgc2V0Q3VzdG9tUmVtYXJrKFwiXCIpOyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgZ3JvdXAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tYnIgJHthY3Rpb24uY29sb3J9ICR7YWN0aW9uLmhvdmVyfSB0ZXh0LXdoaXRlIHNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCB0cmFuc2Zvcm0gaG92ZXI6LXRyYW5zbGF0ZS15LTEgZm9jdXM6b3V0bGluZS1ub25lICR7cmVtYXJrVHlwZSA9PT0gYWN0aW9uLnZhbHVlID8gXCJyaW5nLTQgcmluZy1vZmZzZXQtMiByaW5nLWluZGlnby0zMDAgc2NhbGUtMTA1XCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIG1iLTFcIj57YWN0aW9uLmljb259PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNtIG1kOnRleHQtYmFzZVwiPnthY3Rpb24ubGFiZWx9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbWFya1R5cGUgPT09IGFjdGlvbi52YWx1ZSAmJiA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMiByaWdodC0yIHRleHQteHMgYmctd2hpdGUgdGV4dC1pbmRpZ28tNzAwIHJvdW5kZWQtZnVsbCBweC0xLjUgcHktMC41IGZvbnQtYm9sZFwiPuKckzwvc3Bhbj59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVtYXJrVHlwZSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXhzIHRleHQtaW5kaWdvLTYwMCBtdC0zIGZvbnQtbWVkaXVtXCI+U2VsZWN0ZWQ6IHtyZW1hcmtUeXBlLnJlcGxhY2UoXCJfXCIsIFwiIFwiKX08L3A+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIG15LTFcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi04XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IG1iLTMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj48VXNlck91dGxpbmVkIC8+IDEuIFNlbGVjdCBNZW1iZXI8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaCBzaXplPVwibGFyZ2VcIiBwbGFjZWhvbGRlcj1cIlNlYXJjaCBieSBOYW1lLCBQaG9uZSwgR3JvdXAsIG9yIFRpY2tldFwiIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEVucm9sbElkfSBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtlbnJvbGxtZW50cy5tYXAoKGUpID0+ICh7IHZhbHVlOiBlLl9pZCwgbGFiZWw6IGAke2UudXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCJ9IHwgJHtlLnVzZXJfaWQ/LnBob25lX251bWJlcn0gfCAke2UuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIn0gfCBUaWNrZXQ6ICR7ZS50aWNrZXRzfWAgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiAob3B0aW9uPy5sYWJlbCA/PyBcIlwiKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZEVucm9sbCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwibWItOCBib3JkZXIgYm9yZGVyLWluZGlnby0xMDAgc2hhZG93LXNtIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1pbmRpZ28tNTAgdG8td2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEF2YXRhciBzaXplPXs0OH0gaWNvbj17PFVzZXJPdXRsaW5lZCAvPn0gY2xhc3NOYW1lPVwiYmctaW5kaWdvLTIwMCB0ZXh0LWluZGlnby03MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS04MDAgZm9udC1zZW1pYm9sZCB0ZXh0LWJhc2VcIj57c2VsZWN0ZWRFbnJvbGwudXNlcl9pZD8uZnVsbF9uYW1lfTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMyB0ZXh0LXNsYXRlLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj48R3JvdXBPdXRsaW5lZCAvPiB7c2VsZWN0ZWRFbnJvbGwuZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPjxGaWxlVGV4dE91dGxpbmVkIC8+IFRpY2tldDoge3NlbGVjdGVkRW5yb2xsLnRpY2tldHN9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgbWItM1wiPjIuIFBheW1lbnQgQ2FsY3VsYXRpb248L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBpdGVtcy1jZW50ZXIgZ2FwLTUgYmctaW5kaWdvLTUwIHAtNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItaW5kaWdvLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgc2l6ZT1cImxhcmdlXCIgb25DbGljaz17ZmV0Y2hUb3RhbEFtb3VudH0gZGlzYWJsZWQ9eyFzZWxlY3RlZEVucm9sbElkIHx8IGxvYWRpbmd9IGNsYXNzTmFtZT1cInctZnVsbCBtZDp3LWF1dG8gYmctaW5kaWdvLTYwMCBob3ZlcjpiZy1pbmRpZ28tNzAwIGZvbnQtbWVkaXVtIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xvYWRpbmcgPyA8U3BpbiBzaXplPVwic21hbGxcIiAvPiA6IFwiQ2FsY3VsYXRlIFRvdGFsIFBheW1lbnRcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0b3RhbEFtb3VudCAhPT0gbnVsbCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyB0ZXh0LWNlbnRlciBtZDp0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNTAwIHRleHQteHMgZm9udC1tZWRpdW0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+VG90YWwgQ2FsY3VsYXRlZCBBbW91bnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LWluZGlnby04MDBcIj7igrkge051bWJlcih0b3RhbEFtb3VudCkudG9Mb2NhbGVTdHJpbmcoKX08L2gyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG10LTJcIj48QnV0dG9uIHR5cGU9XCJsaW5rXCIgb25DbGljaz17ZmV0Y2hBbGxUcmFuc2FjdGlvbnN9IGNsYXNzTmFtZT1cInRleHQtaW5kaWdvLTUwMCB0ZXh0LXhzXCI+VmlldyBBbGwgVHJhbnNhY3Rpb25zIOKGkjwvQnV0dG9uPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dG90YWxBbW91bnQgIT09IG51bGwgJiYgcmVtYXJrVHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgc2l6ZT1cImxhcmdlXCIgaWNvbj17PFN3YXBPdXRsaW5lZCAvPn0gb25DbGljaz17b3BlblRyYW5zZmVyTW9kYWx9IGRpc2FibGVkPXtsb2FkaW5nIHx8IChyZW1hcmtUeXBlID09PSBcIk9USEVSXCIgJiYgIWN1c3RvbVJlbWFyaz8udHJpbSgpKX0gY2xhc3NOYW1lPVwidy1mdWxsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1hbWJlci01MDAgdG8tb3JhbmdlLTUwMCBob3Zlcjpmcm9tLWFtYmVyLTYwMCBob3Zlcjp0by1vcmFuZ2UtNjAwIGJvcmRlci0wIHRleHQtd2hpdGUgZm9udC1ib2xkIHB5LTIgdGV4dC1sZyBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByb2NlZWQgd2l0aCB7cmVtYXJrVHlwZS5yZXBsYWNlKFwiX1wiLCBcIiBcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXAgPT09IDIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS04IHB4LTYgbWF4LXctNXhsIG14LWF1dG8gYW5pbWF0ZS1mYWRlLWluLXVwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGl0ZW1zLXN0YXJ0IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgbWItNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20taW5kaWdvLTUwIHRvLWJsdWUtNTAgcC0zIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItaW5kaWdvLTEwMCBzaGFkb3ctc20gcmluZy00IHJpbmctd2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5kaWFuUnVwZWUgY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIHRleHQtMnhsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIHRyYWNraW5nLXRpZ2h0XCI+Q29uZmlybSBDaGl0IHtnZXRBY3Rpb25CdXR0b25UZXh0KGFjdGl2ZUFjdGlvblR5cGUpfTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTUwMCBtdC0xIGZvbnQtbWVkaXVtXCI+UmV2aWV3IGRlZHVjdGlvbiBicmVha2Rvd24gYW5kIGZpbmFsaXplPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd01vZGFsKGZhbHNlKX0gY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTIgcmlnaHQtMyBwLTEgdGV4dC0yeGwgdGV4dC1yZWQtNTAwIGhvdmVyOmJnLWdyYXktMTAwIHotMTBcIj7inJU8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhZyBjb2xvcj1cIm9yYW5nZVwiIGNsYXNzTmFtZT1cImJnLW9yYW5nZS01MCBib3JkZXItb3JhbmdlLTEwMCB0ZXh0LW9yYW5nZS03MDAgcHgtNCBweS0xLjUgcm91bmRlZC1mdWxsIHRleHQtc20gZm9udC1zZW1pYm9sZCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEF3YWl0aW5nIENvbmZpcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RhZz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi01IGJnLXdoaXRlIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy1zbSBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MC84MCBweC02IHB5LTEgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5TZXJ2aWNlIENoYXJnZSBSZWZlcmVuY2UgKDUlKTwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGJnLWluZGlnby0xMDAgdGV4dC1pbmRpZ28tNzAwIHB4LTIgcHktMSByb3VuZGVkLW1kIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ3VycmVudCBHcm91cDog4oK5IHtOdW1iZXIoc2VsZWN0ZWRFbnJvbGxtZW50RGF0YT8uZW5yb2xsbWVudD8uZ3JvdXA/Lmdyb3VwX3ZhbHVlIHx8IDApLnRvTG9jYWxlU3RyaW5nKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YVNvdXJjZT17W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGNoaXQ6IFwi4oK5IDUwLDAwMFwiLCBjaGFyZ2U6IFwi4oK5IDIsNTAwXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBjaGl0OiBcIuKCuSAxLDAwLDAwMFwiLCBjaGFyZ2U6IFwi4oK5IDUsMDAwXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBjaGl0OiBcIuKCuSA1LDAwLDAwMFwiLCBjaGFyZ2U6IFwi4oK5IDI1LDAwMFwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgY2hpdDogXCLigrkgMTAsMDAsMDAwXCIsIGNoYXJnZTogXCLigrkgNTAsMDAwXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLmNvbmNhdChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGdyb3VwVmFsID0gc2VsZWN0ZWRFbnJvbGxtZW50RGF0YT8uZW5yb2xsbWVudD8uZ3JvdXA/Lmdyb3VwX3ZhbHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGdyb3VwVmFsICYmICFbXCI1MDAwMFwiLCBcIjEwMDAwMFwiLCBcIjUwMDAwMFwiLCBcIjEwMDAwMDBcIl0uaW5jbHVkZXMoU3RyaW5nKGdyb3VwVmFsKSkpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gW3sgY2hpdDogYOKCuSAke051bWJlcihncm91cFZhbCkudG9Mb2NhbGVTdHJpbmcoKX1gLCBjaGFyZ2U6IGDigrkgJHtNYXRoLnJvdW5kKE51bWJlcihncm91cFZhbCkgKiAwLjA1KS50b0xvY2FsZVN0cmluZygpfWAgfV07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gW107XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0aXRsZTogXCJDaGl0IFZhbHVlXCIsIGRhdGFJbmRleDogXCJjaGl0XCIsIGtleTogXCJjaGl0XCIsIGNsYXNzTmFtZTogXCJ0ZXh0LXNsYXRlLTYwMFwiIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdGl0bGU6IFwiU2VydmljZSBDaGFyZ2UgKDUlKVwiLCBkYXRhSW5kZXg6IFwiY2hhcmdlXCIsIGtleTogXCJjaGFyZ2VcIiwgY2xhc3NOYW1lOiBcImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDBcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFnaW5hdGlvbj17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3dDbGFzc05hbWU9eyhyZWNvcmQpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlY29yZC5jaGl0ID09PSBg4oK5ICR7TnVtYmVyKHNlbGVjdGVkRW5yb2xsbWVudERhdGE/LmVucm9sbG1lbnQ/Lmdyb3VwPy5ncm91cF92YWx1ZSB8fCAwKS50b0xvY2FsZVN0cmluZygpfWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCIhYmctaW5kaWdvLTUwLzUwIHRleHQtaW5kaWdvLTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiaG92ZXI6Ymctc2xhdGUtNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCIhYm9yZGVyLW5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctZ3JhZGllbnQtdG8tYiBmcm9tLXNsYXRlLTUwIHRvLXdoaXRlIHJvdW5kZWQtM3hsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy14bCBzaGFkb3ctc2xhdGUtMjAwLzUwIHAtNiBtZDpwLTggbWItNCBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCBwLTMyIGJnLWluZGlnby01MDAvNSByb3VuZGVkLWZ1bGwgYmx1ci0zeGwgLXotMTAgcG9pbnRlci1ldmVudHMtbm9uZVwiPjwvZGl2PiAqL31cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0IG1iLTRcIj5DYWxjdWxhdGlvbiBCcmVha2Rvd248L2g0PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIE5PV1JBUCArIGhvcml6b250YWwgc2Nyb2xsIGlmIG5lZWRlZCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtbm93cmFwIGl0ZW1zLXN0cmV0Y2ggZ2FwLTQgb3ZlcmZsb3cteC1hdXRvIHBiLTIgcHgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEdyb3NzIEFtb3VudCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LVsxNjBweF0gYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC0yeGwgcC00IHRleHQtY2VudGVyIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+R3Jvc3MgQW1vdW50PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgdHJhY2tpbmctdGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5IHtOdW1iZXIodG90YWxBbW91bnQpLnRvRml4ZWQoMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTWludXMgc2lnbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkIHRleHQtMnhsIGZsZXggaXRlbXMtY2VudGVyIHNocmluay0wXCI+4oiSPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFNlcnZpY2UgQ2hhcmdlICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctWzE2MHB4XSBiZy13aGl0ZSBib3JkZXItMiAgYm9yZGVyLW9yYW5nZS0yMDAgcm91bmRlZC0yeGwgcC00IHRleHQtY2VudGVyIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgaG92ZXI6Ymctb3JhbmdlLTUwLzMwIHRyYW5zaXRpb24tYWxsIGZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgcmVsYXRpdmUgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1vcmFuZ2UtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+U2VydmljZSBDaGFyZ2U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTEgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCB0ZXh0LXNtXCI+4oK5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gYm9yZGVyZWQ9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluPXswfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlcnZpY2VDaGFyZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlcnZpY2VDaGFyZ2UocGFyc2VGbG9hdChlLnRhcmdldC52YWx1ZSkgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmb250LWJvbGQgdGV4dC14bCBweC01IGJnLXRyYW5zcGFyZW50IGhvdmVyOnRleHQtb3JhbmdlLTYwMCB0cmFuc2l0aW9uLWNvbG9ycyBmb2N1czpvdXRsaW5lLW5vbmUgXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBNaW51cyBzaWduICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGQgdGV4dC0yeGwgZmxleCBpdGVtcy1jZW50ZXIgc2hyaW5rLTBcIj7iiJI8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogR1NUICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctWzE2MHB4XSBiZy13aGl0ZSBib3JkZXItMiAgYm9yZGVyLXB1cnBsZS0yMDAgcm91bmRlZC0yeGwgcC00IHRleHQtY2VudGVyIHNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgaG92ZXI6YmctcHVycGxlLTUwLzMwIHRyYW5zaXRpb24tYWxsIGZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgcmVsYXRpdmUgZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1wdXJwbGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+R1NUKDE4JSk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTEgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCB0ZXh0LXNtIFwiPuKCuTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGJvcmRlcmVkPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnc3RBbW91bnQ/LnRvRml4ZWQoMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEdzdEFtb3VudChwYXJzZUZsb2F0KGUudGFyZ2V0LnZhbHVlKSB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZvbnQtYm9sZCB0ZXh0LXhsIHB4LTUgYmctdHJhbnNwYXJlbnQgaG92ZXI6dGV4dC1wdXJwbGUtNjAwIHRyYW5zaXRpb24tY29sb3JzIGZvY3VzOm91dGxpbmUtbm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRXF1YWxzIHNpZ24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCB0ZXh0LTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBzaHJpbmstMFwiPj08L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTmV0IFBheWFibGUgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy1bMTYwcHhdIGJnLWdyYWRpZW50LXRvLWJyIGZyb20taW5kaWdvLTYwMCB0by12aW9sZXQtNjAwIHJvdW5kZWQtMnhsIHAtNSB0ZXh0LWNlbnRlciBzaGFkb3ctbGcgc2hhZG93LWluZGlnby0yMDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBib3JkZXIgYm9yZGVyLWluZGlnby01MDAvMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1pbmRpZ28tMjAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlc3QgbWItMVwiPk5ldCBQYXlhYmxlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0IGRyb3Atc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuSB7KGZpbmFsQW1vdW50ID49IDAgPyBmaW5hbEFtb3VudCA6IDApLnRvRml4ZWQoMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMSBnYXAtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIHJvdW5kZWQtMnhsIHAtNSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMlwiPlN5c3RlbSBSZW1hcms8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy1zbSBpdGFsaWMgdGV4dC1zbGF0ZS02MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwie21vdmVSZW1hcmt9XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC01MCByb3VuZGVkLTJ4bCBwLTUgYm9yZGVyIGJvcmRlci1yZWQtMTAwIGZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTMgcmVsYXRpdmUgei0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMC41IHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RXhjbGFtYXRpb25DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXhsXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDUgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1yZWQtODAwIG1iLTFcIj5JcnJldmVyc2libGUgQWN0aW9uPC9oNT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXJlZC02MDAgbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBGdW5kcyB3aWxsIGJlIHBlcm1hbmVudGx5IGRlZHVjdGVkIGZyb20gdGhlIHVzZXIgbGVkZ2VyLiBUaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExvY2tPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VjdXJpdHkgQ2hlY2tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTYwMCBweC0zIHB5LTEgcm91bmRlZC1sZyBmb250LW1vbm8gdGV4dC14cyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRhcmdldDog4oK5IHsoZmluYWxBbW91bnQgPj0gMCA/IGZpbmFsQW1vdW50IDogMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIGFtb3VudCBhYm92ZSB0byBjb25maXJtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb25maXJtSW5wdXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvbmZpcm1JbnB1dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM9e2NvbmZpcm1JbnB1dCAmJiBjb25maXJtSW5wdXQgIT09IFN0cmluZyhmaW5hbEFtb3VudCkgPyBcImVycm9yXCIgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLXhsIGJvcmRlci1zbGF0ZS0zMDAgc2hhZG93LXNtIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwIGZvY3VzOnJpbmctNCBmb2N1czpyaW5nLWluZGlnby01MDAvMTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJlZml4PXs8U2FmZXR5T3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIiAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NvbmZpcm1JbnB1dCAmJiBjb25maXJtSW5wdXQgIT09IFN0cmluZyhmaW5hbEFtb3VudCkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0yIHRleHQtcmVkLTUwMCB0ZXh0LXhzIGFuaW1hdGUtcHVsc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2xvc2VDaXJjbGVPdXRsaW5lZCAvPiBBbW91bnQgZG9lcyBub3QgbWF0Y2ggY2FsY3VsYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHAtMSBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vdGlmaWNhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogV2hhdHNBcHAgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgcC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBcclxuICAgICAgICAgICAgaG92ZXI6Ym9yZGVyLWdyZWVuLTQwMCBob3ZlcjpiZy1ncmVlbi01MCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXJkUGFydHlFbmFibGUuc2VuZF93aGF0c2FwcH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUaGlyZFBhcnR5RW5hYmxlKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VuZF93aGF0c2FwcDogIXByZXYuc2VuZF93aGF0c2FwcCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgYWNjZW50LWdyZWVuLTYwMCByb3VuZGVkIGZvY3VzOnJpbmctZ3JlZW4tNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcFNxdWFyZSBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMCB0ZXh0LTN4bFwiIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFdoYXRzQXBwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzbWFsbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIHRleHQtZ3JheS00MDAgZm9udC1ub3JtYWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNlbmQgbm90aWZpY2F0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc21hbGw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEdtYWlsICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgXHJcbiAgICAgICAgICAgIGhvdmVyOmJvcmRlci1yZWQtNDAwIGhvdmVyOmJnLXJlZC01MCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXJkUGFydHlFbmFibGUuc2VuZF9nbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUaGlyZFBhcnR5RW5hYmxlKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VuZF9nbWFpbDogIXByZXYuc2VuZF9nbWFpbCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgYWNjZW50LXJlZC02MDAgcm91bmRlZCBmb2N1czpyaW5nLXJlZC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIPCfk6dcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdtYWlsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzbWFsbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIHRleHQtZ3JheS00MDAgZm9udC1ub3JtYWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNlbmQgZW1haWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zbWFsbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogU01TICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHAtNCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgXHJcbiAgICAgICAgICAgIGhvdmVyOmJvcmRlci1ibHVlLTQwMCBob3ZlcjpiZy1ibHVlLTUwIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcmRQYXJ0eUVuYWJsZS5zZW5kX3Ntc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUaGlyZFBhcnR5RW5hYmxlKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VuZF9zbXM6ICFwcmV2LnNlbmRfc21zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNSBhY2NlbnQtYmx1ZS02MDAgcm91bmRlZCBmb2N1czpyaW5nLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDwn5KsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTTVNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNtYWxsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgdGV4dC1ncmF5LTQwMCBmb250LW5vcm1hbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VuZCBtZXNzYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc21hbGw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wtcmV2ZXJzZSBzbTpmbGV4LXJvdyBnYXAtMyBqdXN0aWZ5LWVuZCBwdC02IGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEyIHB4LTggZm9udC1tZWRpdW0gcm91bmRlZC14bCBib3JkZXItc2xhdGUtMzAwIHRleHQtc2xhdGUtNjAwIGhvdmVyOmJnLXNsYXRlLTUwIGhvdmVyOmJvcmRlci1zbGF0ZS00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbG9zZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZU1vdmVBbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZyB8fCAhY29uZmlybUlucHV0IHx8IFN0cmluZyhjb25maXJtSW5wdXQpLnRyaW0oKSAhPT0gU3RyaW5nKGZpbmFsQW1vdW50KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhbmdlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMiBweC0xMCBmb250LWJvbGQgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1yIGZyb20tcmVkLTUwMCB0by1vcmFuZ2UtNTAwIGJvcmRlci1ub25lIHNoYWRvdy1sZyBzaGFkb3ctcmVkLTIwMCBob3ZlcjpzaGFkb3ctcmVkLTMwMCBob3ZlcjotdHJhbnNsYXRlLXktMC41IHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGljb249ezxTd2FwT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtsb2FkaW5nID8gPFNwaW4gc2l6ZT1cInNtYWxsXCIgY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiIC8+IDogYENvbmZpcm0gQ2hpdCAke2dldEFjdGlvbkJ1dHRvblRleHQoYWN0aXZlQWN0aW9uVHlwZSl9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXAgPT09IDMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS00IHB4LTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTEwMCBwLTIgcm91bmRlZC1mdWxsXCI+PFN3YXBPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIHRleHQteGxcIiAvPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDBcIj5XaGF0IHdvdWxkIHlvdSBsaWtlIHRvIGRvPzwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBibG9jayBzaXplPVwibGFyZ2VcIiBvbkNsaWNrPXtoYW5kbGVSZWZ1bmR9IGNsYXNzTmFtZT1cImJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci02MDAgdGV4dC13aGl0ZSBmb250LW1lZGl1bVwiPlByb2Nlc3MgRnVuZCBTZXR0bGVtZW50PC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEaXZpZGVyIHBsYWluPk9SPC9EaXZpZGVyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIGJsb2NrIHNpemU9XCJsYXJnZVwiIG9uQ2xpY2s9e2hhbmRsZVRyYW5zZmVyVG9EaWZmZXJlbnRBY2NvdW50fSBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwMCBob3ZlcjpiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIGZvbnQtbWVkaXVtXCI+RnVuZCBUcmFuc2ZlciB0byBDaGl0IC8gTG9hbiAvIFBpZ215PC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBmbGV4IGp1c3RpZnktZW5kXCI+PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfSBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPkJhY2s8L0J1dHRvbj48L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmFja1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBXaXRoZHJhdyBNb2RhbCAqL31cclxuICAgICAgICAgICAgICAgICAgICA8TW9kYWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93V2l0aGRyYXdNb2RhbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd1dpdGhkcmF3TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0V2l0aGRyYXdEYXRhKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd0NhbGN1bGF0ZWQoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93Q2xvc2VCdXR0b249e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEN1c3RvbSByZWQgY2xvc2UgaWNvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dXaXRoZHJhd01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0V2l0aGRyYXdEYXRhKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93Q2FsY3VsYXRlZChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMCByaWdodC0xIHRleHQtcmVkLTYwMCBob3Zlcjp0ZXh0LXJlZC04MDAgdGV4dC14bCBmb250LWJvbGQgei0xMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJDbG9zZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pyVXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXB1cnBsZS02MDAgdG8taW5kaWdvLTYwMCBweC0yIHB5LTUgZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+V2l0aGRyYXcgUGlnbXkgQWNjb3VudDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTEwMCB0ZXh0LXNtIG10LTFcIj5SZXZpZXcgZGV0YWlscyBiZWZvcmUgcHJvY2Vzc2luZyB3aXRoZHJhd2FsPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt3aXRoZHJhd0RhdGEgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3dpdGhkcmF3RGF0YS5yZXF1ZXN0X3N0YXR1cyA9PT0gXCJBUFBST1ZFRFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgYmctZ3JlZW4tMjAwIHRleHQtZ3JlZW4tODAwIHJvdW5kZWQtZnVsbCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5BcHByb3ZlZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7d2l0aGRyYXdEYXRhLnJlcXVlc3Rfc3RhdHVzID09PSBcIlJFUVVFU1RFRFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgYmcteWVsbG93LTIwMCB0ZXh0LXllbGxvdy04MDAgcm91bmRlZC1mdWxsIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlJlcXVlc3RlZDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7d2l0aGRyYXdEYXRhLnJlcXVlc3Rfc3RhdHVzID09PSBcIkNPTVBMRVRFRFwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0zIHB5LTEgYmctYmx1ZS0yMDAgdGV4dC1ibHVlLTgwMCByb3VuZGVkLWZ1bGwgdGV4dC1zbSBmb250LXNlbWlib2xkXCI+Q29tcGxldGVkPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt3aXRoZHJhd0RhdGEucmVxdWVzdF9zdGF0dXMgPT09IFwiQ0xPU0VEXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTMgcHktMSBiZy1ncmF5LTIwMCB0ZXh0LWdyYXktODAwIHJvdW5kZWQtZnVsbCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj5DbG9zZWQ8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3dpdGhkcmF3RGF0YSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFBpZ215IERldGFpbHMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHJvdW5kZWQteGwgcC01IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi00XCI+UGlnbXkgRGV0YWlsczwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC0zIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5QaWdteSBJRDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+e3dpdGhkcmF3RGF0YS5waWdtZV9pZH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHAtMyBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+Q3VzdG9tZXIgTmFtZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+e3dpdGhkcmF3RGF0YS5jdXN0b21lcj8uZnVsbF9uYW1lfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC0zIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5QYXltZW50IFR5cGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPnt3aXRoZHJhd0RhdGEubWF0dXJpdHlfcGVyaW9kfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC0zIHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt3aXRoZHJhd0RhdGEubWF0dXJpdHlfcGVyaW9kXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPy50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcYlxcdy9nLCAoY2hhcikgPT4gY2hhci50b1VwcGVyQ2FzZSgpKX17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWlkIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ibHVlLTYwMCB0ZXh0LWxnXCI+4oK5e3dpdGhkcmF3RGF0YS5wYXlhYmxlX2Ftb3VudH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTMgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlRvdGFsIEFtb3VudCBQYWlkPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JlZW4tNjAwXCI+4oK5e3dpdGhkcmF3RGF0YS50b3RhbF9wYWlkfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3dpdGhkcmF3RGF0YT8uY2xvc3VyZV90eXBlID09PSBcIk1BVFVSRURcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTMgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5JbnRlcmVzdCBSYXRlPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyZWVuLTYwMFwiPnt3aXRoZHJhd0RhdGEubWF0dXJpdHlfaW50ZXJlc3R9JTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTMgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlN0YXJ0IERhdGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge25ldyBEYXRlKHdpdGhkcmF3RGF0YS5zdGFydF9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+VG90YWwgUGFpZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ibHVlLTYwMFwiPuKCuXt3aXRoZHJhd0RhdGEudG90YWxfcGFpZH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHAtNFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+TW9udGhzIENvbXBsZXRlZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7d2l0aGRyYXdEYXRhLnN0YXJ0X2RhdGUgPyAoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHN0YXJ0ID0gZGF5anMod2l0aGRyYXdEYXRhLnN0YXJ0X2RhdGUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHRvZGF5ID0gZGF5anMoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgbW9udGhzID0gKHRvZGF5LnllYXIoKSAtIHN0YXJ0LnllYXIoKSkgKiAxMiArICh0b2RheS5tb250aCgpIC0gc3RhcnQubW9udGgoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9udGhzID0gTWF0aC5tYXgoMCwgbW9udGhzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYCR7bW9udGhzfSAvICR7d2l0aGRyYXdEYXRhLmR1cmF0aW9uIHx8ICc/J30gbW9udGhzYDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKCkgOiAnLSd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5DbG9zdXJlIFR5cGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1zbSBmb250LW1lZGl1bSBiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTgwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7d2l0aGRyYXdEYXRhLmNsb3N1cmVfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTMgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlBpZ215IER1cmF0aW9uPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj57d2l0aGRyYXdEYXRhLmR1cmF0aW9ufSBNb250aHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3dpdGhkcmF3RGF0YS5jbG9zdXJlX3R5cGUgPT09IFwiUFJFLU1BVFVSRURcIiA/IFwiUHJlbWF0dXJlIFdpdGhkcmF3YWwgRGVkdWN0aW9uXCIgOiBcIkludGVyZXN0XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPVwiYW55XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2VkaXRhYmxlSW50ZXJlc3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RWRpdGFibGVJbnRlcmVzdChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQmx1cj17aGFuZGxlUGVyY2VudEJsdXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGZvY3VzOnJpbmctcHVycGxlLTUwMCBmb2N1czpib3JkZXItcHVycGxlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiJVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVkaXRhYmxlSW50ZXJlc3QgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5lZGl0YWJsZUludGVyZXN0fTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3luY0ZpZWxkc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgYmctYmx1ZS01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLWJsdWUtNjAwIHRyYW5zaXRpb24gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ2FsY3VsYXRlIHRoZSBvdGhlciBmaWVsZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZhQ2FsY3VsYXRvciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD1cImFueVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkZWR1Y3Rpb25BbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RGVkdWN0aW9uQW1vdW50KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25CbHVyPXtoYW5kbGVBbW91bnRCbHVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLXB1cnBsZS01MDAgZm9jdXM6Ym9yZGVyLXB1cnBsZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuKCuSBBbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogQ2FsY3VsYXRlZCBWYWx1ZXMgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93Q2FsY3VsYXRlZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1ncmVlbi01MCB0by1lbWVyYWxkLTUwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwIHJvdW5kZWQtMnhsIHAtNSBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTRcIj5DYWxjdWxhdGVkIFZhbHVlczwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlRvdGFsIFBhaWQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNjAwXCI+4oK5e3dpdGhkcmF3RGF0YS50b3RhbF9wYWlkfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPnt3aXRoZHJhd0RhdGEuY2xvc3VyZV90eXBlID09PSBcIlBSRS1NQVRVUkVEXCIgPyBcIiBQcmVtYXR1cmUgV2l0aGRyYXdhbCBEZWR1Y3Rpb24gKCUpXCIgOiBcIk1hdHVyaXR5IEludGVyZXN0ICglKVwifTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT17YHRleHQteGwgZm9udC1ib2xkICR7d2l0aGRyYXdEYXRhLmNsb3N1cmVfdHlwZSA9PT0gXCJQUkUtTUFUVVJFRFwiID8gXCJ0ZXh0LXJlZC02MDBcIiA6IFwidGV4dC1ncmVlbi02MDBcIn1gfT57d2l0aGRyYXdEYXRhLmNsb3N1cmVfdHlwZSA9PT0gXCJQUkUtTUFUVVJFRFwiID8gd2l0aGRyYXdEYXRhLnByZV9tYXR1cmVkX2ludGVyZXN0IDogd2l0aGRyYXdEYXRhLm1hdHVyaXR5X2ludGVyZXN0fSU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5NYXR1cml0eSBBbW91bnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS02MDBcIj7igrl7d2l0aGRyYXdEYXRhLm1hdHVyaXR5X2Ftb3VudH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLXhsIHAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+VG90YWwgUGF5YWJsZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtYmx1ZS02MDBcIj7igrl7d2l0aGRyYXdEYXRhLnRvdGFsX3BheWFibGV9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBGb290ZXIgQnV0dG9ucyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIGJvcmRlci10IHB0LTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93V2l0aGRyYXdNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFdpdGhkcmF3RGF0YShudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd0NhbGN1bGF0ZWQoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTcwMCByb3VuZGVkLXhsIGhvdmVyOmJnLWdyYXktMTAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENsb3NlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUmVjYWxjdWxhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNiBweS0zIGJnLWJsdWUtNTAwIHRleHQtd2hpdGUgcm91bmRlZC14bCBmb250LW1lZGl1bSBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVjYWxjdWxhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVdpdGhkcmF3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXt3aXRoZHJhd0xvYWRpbmcgfHwgIXNob3dDYWxjdWxhdGVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTYgcHktMyByb3VuZGVkLXhsIGZvbnQtbWVkaXVtIHNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgJHt3aXRoZHJhd0xvYWRpbmcgfHwgIXNob3dDYWxjdWxhdGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmF5LTMwMCB0ZXh0LWdyYXktNTAwIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ncmFkaWVudC10by1yIGZyb20tcHVycGxlLTYwMCB0by1pbmRpZ28tNjAwIHRleHQtd2hpdGUgaG92ZXI6c2hhZG93LWxnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3dpdGhkcmF3TG9hZGluZyA/IDxTcGluIHNpemU9XCJzbWFsbFwiIGNsYXNzTmFtZT1cInRleHQtd2hpdGVcIiAvPiA6IFwiU3VibWl0XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogVHJhbnNhY3Rpb24gRHJhd2VyICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxEcmF3ZXIgY2xvc2FibGUgdGl0bGU9ezxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj48Q2FsZW5kYXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby01MDBcIiAvPjxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlRyYW5zYWN0aW9uIEhpc3Rvcnk8L3NwYW4+PC9kaXY+fSBwbGFjZW1lbnQ9XCJyaWdodFwiIG9wZW49e29wZW5BbnRERHJhd2VyfSBvbkNsb3NlPXsoKSA9PiBzZXRPcGVuQW50RERyYXdlcihmYWxzZSl9IHdpZHRoPXs0MjB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgaC00MFwiPjxTcGluIHNpemU9XCJsYXJnZVwiIC8+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiBsYXN0QWxsUGF5bWVudHM/Lmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTZcIj48RmlsZVRleHRPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LTR4bCB0ZXh0LXNsYXRlLTMwMCBtYi0zXCIgLz48cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bVwiPk5vIFRyYW5zYWN0aW9ucyBGb3VuZDwvcD48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUaW1lbGluZSBpdGVtcz17bGFzdEFsbFBheW1lbnRzLm1hcCgocGF5bWVudCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiYmx1ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpbmRleH0gY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBwLTQgc2hhZG93LXNtIGJvcmRlciBib3JkZXItc2xhdGUtMTAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnQucGF5X2RhdGUgPyBuZXcgRGF0ZShwYXltZW50LnBheV9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUdCJykgOiAnLSd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUYWcgY29sb3I9XCJpbmRpZ29cIiBjbGFzc05hbWU9XCJtLTAgZm9udC1zZW1pYm9sZFwiPuKCuXtwYXltZW50Py5hbW91bnQ/LnRvTG9jYWxlU3RyaW5nKCl9PC9UYWc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDAgdGV4dC1zbSBtYi0xXCI+e3BheW1lbnQudXNlcl9pZD8uZnVsbF9uYW1lfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMiBmbGV4LXdyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudC5ncm91cF9pZCAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTYwMCBweC0yIHB5LTAuNSByb3VuZGVkXCI+e3BheW1lbnQuZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9PC9zcGFuPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudC50aWNrZXQgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBiZy1zbGF0ZS0xMDAgdGV4dC1zbGF0ZS02MDAgcHgtMiBweS0wLjUgcm91bmRlZFwiPlRpY2tldDoge3BheW1lbnQ/LnRpY2tldH08L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgYmctaW5kaWdvLTUwIHRleHQtaW5kaWdvLTcwMCBweC0yIHB5LTAuNSByb3VuZGVkXCI+e3BheW1lbnQ/LnBheV90eXBlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvRHJhd2VyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8TW9kYWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kZWxPbkhvbGR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RlbE9uSG9sZChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRFbnJvbGxtZW50T3BlcmF0aW9uKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYmctZ3JheS01MCByb3VuZGVkLXhsXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC00XCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBJY29uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmxleCBoLTE0IHctMTQgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvdW5kZWQtZnVsbCBzaGFkb3ctbGdcclxuICAgICAgICAgICAgICAgICAgICAgICAgJHtjdXJyZW50T3BlcmF0aW9uLmljb25DbGFzc31cclxuICAgICAgICAgICAgICAgICAgICBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctOCB0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZW5yb2xsbWVudE9wZXJhdGlvbiA9PT0gXCJhY3RpdmVcIiA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNNSAxM2w0IDRMMTkgN1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNMTIgOXY0bTAgNGguMDFNMTAuMjkgMy44NmwtNy41IDEzQTEgMSAwIDAwMy42NiAxOGgxNi42OGExIDEgMCAwMC44Ny0xLjVsLTcuNS0xM2ExIDEgMCAwMC0xLjc0IDB6XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIENvbnRlbnQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBEeW5hbWljIHRpdGxlICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRPcGVyYXRpb24udGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRHluYW1pYyBkZXNjcmlwdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtZ3JheS02MDAgbGVhZGluZy1yZWxheGVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudE9wZXJhdGlvbi5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDdXN0b21lciBEZXRhaWxzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBiZy13aGl0ZSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC01IHNoYWRvdy1zbVwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGgtOCB3LTEgcm91bmRlZC1mdWxsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICR7Y3VycmVudE9wZXJhdGlvbi5hY2NlbnRDbGFzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDdXN0b21lciAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwPy51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBHcm91cCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFBob25lICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC1sZyBwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50R3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFRpY2tldCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaWNrZXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRHcm91cD8udGlja2V0cyB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEN1cnJlbnQgU3RhdHVzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYmctZ3JheS01MCByb3VuZGVkLWxnIHB4LTQgcHktMyBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEN1cnJlbnQgU3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUYWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50R3JvdXA/LmN1c3RvbWVyX3N0YXR1cyA9PT0gXCJPbiBIb2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIm9yYW5nZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogY3VycmVudEdyb3VwPy5jdXN0b21lcl9zdGF0dXMgPT09IFwiQWN0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJibHVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJyZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwPy5jdXN0b21lcl9zdGF0dXMgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UYWc+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIEltcG9ydGFudCBtZXNzYWdlICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yIGJnLXJlZC01MCByb3VuZGVkLWxnIHAtMyBib3JkZXItbC00IGJvcmRlci1yZWQtNTAwXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtcmVkLTUwMCBmbGV4LXNocmluay0wXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyMCAyMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsbFJ1bGU9XCJldmVub2RkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTE4IDEwYTggOCAwIDExLTE2IDAgOCA4IDAgMDExNiAwem0tNy00YTEgMSAwIDExLTIgMCAxIDEgMCAwMTIgMHpNOSA5YTEgMSAwIDAwMCAydjNhMSAxIDAgMDAxIDFoMWExIDEgMCAxMDAtMmgtMVY5YTEgMSAwIDAwLTEtMXpcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsaXBSdWxlPVwiZXZlbm9kZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1yZWQtNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSW1wb3J0YW50OlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZlcmlmeSBjdXN0b21lciBkZXRhaWxzIGJlZm9yZSBwcm9jZWVkaW5nLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTdWJtaXQgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50R3JvdXAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvblN1Ym1pdD17aGFuZGxlT25Ib2xkR3JvdXB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtNlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sLXJldmVyc2Ugc206ZmxleC1yb3cganVzdGlmeS1lbmQgZ2FwLTNcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBDYW5jZWwgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RlbE9uSG9sZChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEVucm9sbG1lbnRPcGVyYXRpb24obnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlubGluZS1mbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBweC02IHB5LTIuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQtZ3JheS03MDAgYmctd2hpdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvdmVyOmJnLWdyYXktNTBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaG92ZXI6Ym9yZGVyLWdyYXktNDAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvY3VzOm91dGxpbmUtbm9uZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ncmF5LTMwMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2l0aW9uLWFsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRHluYW1pYyBBY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlubGluZS1mbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBweC02IHB5LTIuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQtd2hpdGUgcm91bmRlZC1sZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb2N1czpvdXRsaW5lLW5vbmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9jdXM6cmluZy00XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbi1hbGxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJHtjdXJyZW50T3BlcmF0aW9uLmJ1dHRvbkNsYXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50T3BlcmF0aW9uLmJ1dHRvblRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8Lz5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBVc2VyQWNjb3VudHNNZW51OyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9Vc2VyQWNjb3VudHNNZW51LmpzeCJ9