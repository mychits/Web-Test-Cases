import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ComplaintForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import API from "/src/instance/TokenInstance.js";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { CloudUpload, X, FileText } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
function ComplaintForm() {
  _s();
  const [api, contextHolder] = notification.useNotification();
  const [attachments, setAttachments] = useState([]);
  const navigate = useNavigate();
  const handleCancel = () => {
    navigate(-1);
  };
  const handleRemoveFile = (index, e) => {
    e.stopPropagation();
    setAttachments((prev) => prev.filter((_, i) => i !== index));
  };
  const [userProfile, setUserProfile] = useState({
    name: "",
    mobile: ""
  });
  const [formData, setFormData] = useState({
    name: "",
    mobile: "",
    subject: "",
    designation: "",
    message: ""
  });
  const [errors, setErrors] = useState({});
  const [submissions, setSubmissions] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  useEffect(() => {
    const fetchUserProfile = async () => {
      try {
        const userStr = localStorage.getItem("user");
        console.log(JSON.parse(localStorage.getItem("user")));
        if (!userStr) {
          console.log("No user found in localStorage");
          return;
        }
        const user = JSON.parse(userStr);
        const userId = user?._id;
        if (!userId) {
          console.log("User ID not found");
          return;
        }
        const res = await API.get(`/admin/get-admin/${userId}`);
        console.log("User profile:", res.data);
        setFormData((prev) => ({
          ...prev,
          name: res.data?.name || "",
          mobile: res.data?.phoneNumber || ""
        }));
      } catch (error) {
        console.error("Failed to fetch user profile:", error);
      }
    };
    fetchUserProfile();
  }, []);
  const handleFileChange = (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    const allowedTypes = ["application/pdf", "image/png", "image/jpeg", "image/jpg"];
    const validFiles = [];
    for (let file of files) {
      if (!allowedTypes.includes(file.type)) {
        notify("warning", "Invalid File", "Only PDF, PNG, JPG allowed");
        continue;
      }
      if (file.size > 5 * 1024 * 1024) {
        notify("warning", "File Too Large", "Max size 5MB");
        continue;
      }
      validFiles.push(file);
    }
    if (validFiles.length) {
      setAttachments((prev) => [...prev, ...validFiles]);
    }
  };
  const notify = (type, title, description) => {
    api[type]({ title, description, placement: "top", duration: 2 });
  };
  const validateForm = (existingData = []) => {
    const newErrors = {};
    if (!/^[A-Za-z\s_-]{1,15}$/.test(formData.name.trim())) {
      newErrors.name = "Name must contain only alphabets, space, - or _ and max 15 characters";
    }
    if (!/^[6-9]\d{9}$/.test(formData.mobile)) {
      newErrors.mobile = "Mobile number must start with 6-9 and be exactly 10 digits";
    }
    if (formData.subject.trim().length < 3) {
      newErrors.subject = "Subject must be at least 3 characters";
    }
    if (formData.message.trim().length < 5) {
      newErrors.message = "Description must be at least 5 characters";
    }
    const isDuplicate = existingData.some(
      (item) => item.name === formData.name && item.mobile === formData.mobile && item.subject === formData.subject && item.message === formData.message
    );
    if (isDuplicate) {
      alert("❌ Data already stored");
      return false;
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const submitComplaint = async (e) => {
    e.preventDefault();
    if (isSubmitting) return;
    if (!validateForm(submissions)) {
      notify("warning", "Invalid Input", "Please fix the highlighted fields");
      return;
    }
    try {
      setIsSubmitting(true);
      const formPayload = new FormData();
      const userStr = localStorage.getItem("user");
      const userId = userStr ? JSON.parse(userStr)._id : null;
      if (userId) {
        formPayload.append("userId", userId);
      }
      formPayload.append("name", formData.name);
      formPayload.append("mobile", formData.mobile);
      formPayload.append("subject", formData.subject);
      formPayload.append("designation", formData.designation);
      formPayload.append("message", formData.message);
      attachments.forEach((file) => {
        formPayload.append("complaint_uploads", file);
      });
      const config = {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      };
      await API.post("/complaints/create", formPayload, config);
      setSubmissions((prev) => [...prev, formData]);
      notify("success", "Complaint Submitted", "Our support team will reply as soon as possible.");
      setFormData({
        name: userProfile.name,
        mobile: userProfile.mobile,
        subject: "",
        designation: "",
        message: ""
      });
      setAttachments([]);
      setErrors({});
      setTimeout(() => navigate("/help&support"), 1500);
    } catch (error) {
      console.error("Submission Error:", error);
      notify("error", "Submission Failed", error.response?.data?.message || "Something went wrong.");
    } finally {
      setIsSubmitting(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
      lineNumber: 205,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex w-screen mt-14", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
        lineNumber: 207,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-col w-full p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen flex items-start justify-center bg-gray-100 px-4 py-24", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-xl bg-white rounded-xl shadow-md border p-8 relative", children: [
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleCancel, className: "absolute top-4 right-4 text-gray-400 hover:text-red-500 transition", title: "Cancel", children: /* @__PURE__ */ jsxDEV(X, { size: 24 }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
          lineNumber: 212,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
          lineNumber: 211,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("form", { onSubmit: submitComplaint, className: "space-y-6", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-indigo-800 text-center pr-8", children: "Raise a Support Ticket" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
            lineNumber: 216,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-gray-600", children: "Name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 222,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: formData.name,
                  readOnly: true,
                  className: "w-full rounded-lg border border-gray-300 bg-gray-100 px-4 py-2 cursor-not-allowed outline-none"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                  lineNumber: 225,
                  columnNumber: 21
                },
                this
              ),
              errors.name && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                lineNumber: 233,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 224,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
            lineNumber: 221,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-gray-600", children: "Mobile" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 240,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: formData.mobile,
                  readOnly: true,
                  className: "w-full rounded-lg border border-gray-300 bg-gray-100 px-4 py-2 cursor-not-allowed outline-none"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                  lineNumber: 243,
                  columnNumber: 21
                },
                this
              ),
              errors.mobile && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.mobile }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                lineNumber: 251,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 242,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
            lineNumber: 239,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-gray-600", children: "Subject" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 258,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  placeholder: "Enter your Subject",
                  value: formData.subject,
                  onChange: (e) => setFormData({ ...formData, subject: e.target.value }),
                  className: "w-full rounded-lg border border-gray-300 px-4 py-2 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                  lineNumber: 260,
                  columnNumber: 21
                },
                this
              ),
              errors.subject && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.subject }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                lineNumber: 267,
                columnNumber: 40
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 259,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
            lineNumber: 257,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4 items-start", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-gray-600 pt-2", children: "Department" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 272,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    value: formData.designation,
                    onChange: (e) => setFormData({ ...formData, designation: e.target.value }),
                    className: "w-full rounded-lg border border-gray-300 px-4 py-2 appearance-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none pr-10",
                    required: true,
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Department" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                        lineNumber: 281,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Management", children: "Management" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                        lineNumber: 282,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Administration", children: "Administration" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                        lineNumber: 283,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Sales & Business", children: "Sales & Business" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                        lineNumber: 284,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Collection Operations", children: "Collection Operations" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                        lineNumber: 285,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Accounts & Finance", children: "Accounts & Finance" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                        lineNumber: 286,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Technical / IT", children: "Technical & IT" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                        lineNumber: 287,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "Others", children: "Others" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                        lineNumber: 288,
                        columnNumber: 25
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                    lineNumber: 275,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5 text-gray-400", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M19 9l-7 7-7-7" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                  lineNumber: 292,
                  columnNumber: 27
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                  lineNumber: 291,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                  lineNumber: 290,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                lineNumber: 274,
                columnNumber: 21
              }, this),
              errors.designation && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.designation }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                lineNumber: 297,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 273,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
            lineNumber: 271,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-gray-600", children: "Description" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 304,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: [
              /* @__PURE__ */ jsxDEV(
                "textarea",
                {
                  rows: "4",
                  placeholder: "Describe your issue in detail",
                  value: formData.message,
                  onChange: (e) => setFormData({ ...formData, message: e.target.value }),
                  className: "w-full rounded-lg border border-gray-300 px-4 py-2 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 outline-none"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                  lineNumber: 306,
                  columnNumber: 21
                },
                this
              ),
              errors.message && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-sm mt-1", children: errors.message }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                lineNumber: 313,
                columnNumber: 40
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 305,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
            lineNumber: 303,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-3 gap-4", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-gray-600", children: "Attachment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 319,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "col-span-2", children: /* @__PURE__ */ jsxDEV(
              "label",
              {
                htmlFor: "complaint_uploads",
                className: "relative flex flex-col items-center justify-center h-32 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 overflow-hidden",
                children: [
                  /* @__PURE__ */ jsxDEV(
                    "input",
                    {
                      id: "complaint_uploads",
                      type: "file",
                      multiple: true,
                      className: "hidden",
                      accept: ".pdf,.png,.jpg,.jpeg",
                      onChange: handleFileChange
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                      lineNumber: 325,
                      columnNumber: 23
                    },
                    this
                  ),
                  attachments.length === 0 ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center z-10 pointer-events-none", children: [
                    /* @__PURE__ */ jsxDEV(CloudUpload, { size: 40, className: "text-gray-400 mb-2" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                      lineNumber: 337,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-700", children: "Attach Documents" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                      lineNumber: 338,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "PDF, PNG, JPG, JPEG (Max 5MB)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                      lineNumber: 339,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                    lineNumber: 336,
                    columnNumber: 23
                  }, this) : /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-3 gap-2 w-full h-full p-2 overflow-y-auto z-10 bg-white/50", children: [
                    attachments.map(
                      (file, index) => /* @__PURE__ */ jsxDEV("div", { className: "relative group h-24 w-full rounded border overflow-hidden bg-gray-100 flex-shrink-0 flex flex-col", children: [
                        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 relative", children: [
                          file.type.startsWith("image/") ? /* @__PURE__ */ jsxDEV("img", { src: URL.createObjectURL(file), alt: "preview", className: "w-full h-full object-cover" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                            lineNumber: 347,
                            columnNumber: 29
                          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center h-full w-full text-gray-500", children: [
                            /* @__PURE__ */ jsxDEV(FileText, { size: 28 }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                              lineNumber: 350,
                              columnNumber: 37
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] truncate w-full text-center px-1 mt-1", children: "PDF" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                              lineNumber: 351,
                              columnNumber: 37
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                            lineNumber: 349,
                            columnNumber: 29
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "button",
                            {
                              type: "button",
                              onClick: (e) => handleRemoveFile(index, e),
                              className: "absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600 shadow-sm transition transform scale-90 hover:scale-100",
                              children: /* @__PURE__ */ jsxDEV(X, { size: 12 }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                                lineNumber: 359,
                                columnNumber: 35
                              }, this)
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                              lineNumber: 354,
                              columnNumber: 33
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                          lineNumber: 345,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "bg-white border-t border-gray-200 p-1", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] text-gray-700 truncate text-center", title: file.name, children: file.name.length > 15 ? file.name.substring(0, 15) + "..." : file.name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                          lineNumber: 363,
                          columnNumber: 33
                        }, this) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                          lineNumber: 362,
                          columnNumber: 31
                        }, this)
                      ] }, index, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                        lineNumber: 344,
                        columnNumber: 25
                      }, this)
                    ),
                    /* @__PURE__ */ jsxDEV("div", { className: "relative h-24 w-full rounded border border-dashed border-gray-300 flex flex-col items-center justify-center text-gray-400 hover:text-blue-500 hover:bg-gray-50 transition", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-2xl font-bold", children: "+" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                        lineNumber: 370,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] mt-1", children: "Add More" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                        lineNumber: 371,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                      lineNumber: 369,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                    lineNumber: 342,
                    columnNumber: 23
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
                lineNumber: 321,
                columnNumber: 21
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 320,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
            lineNumber: 318,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              disabled: isSubmitting,
              className: `px-8 py-2 rounded-lg font-medium transition ${isSubmitting ? "bg-gray-400 cursor-not-allowed" : "bg-blue-600 hover:bg-blue-700 text-white"}`,
              children: isSubmitting ? "Submitting..." : "Submit"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
              lineNumber: 381,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
            lineNumber: 380,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
          lineNumber: 215,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
        lineNumber: 210,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
        lineNumber: 209,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
        lineNumber: 208,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
      lineNumber: 206,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx",
    lineNumber: 203,
    columnNumber: 5
  }, this);
}
_s(ComplaintForm, "02I4a28T/Tx/nZXYLdOIrzElQ1k=", false, function() {
  return [notification.useNotification, useNavigate];
});
_c = ComplaintForm;
export default ComplaintForm;
var _c;
$RefreshReg$(_c, "ComplaintForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ComplaintForm.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBME1JLG1CQUVFLGNBRkY7MkJBMU1KO0FBQW1CQSxvQkFBaUIsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxPQUFPQyxTQUFTO0FBQ2hCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxtQkFBbUI7QUFDNUIsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLGFBQWFDLEdBQUdDLGdCQUFnQjtBQUV6QyxTQUFTQyxnQkFBZ0I7QUFBQUMsS0FBQTtBQUN2QixRQUFNLENBQUNDLEtBQUtDLGFBQWEsSUFBSVYsYUFBYVcsZ0JBQWdCO0FBQzFELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJQyxTQUFTLEVBQUU7QUFDakQsUUFBTUMsV0FBV2QsWUFBWTtBQUU3QixRQUFNZSxlQUFlQSxNQUFNO0FBQ3pCRCxhQUFTLEVBQUU7QUFBQSxFQUNiO0FBRUEsUUFBTUUsbUJBQW1CQSxDQUFDQyxPQUFPQyxNQUFNO0FBQ3JDQSxNQUFFQyxnQkFBZ0I7QUFDbEJQLG1CQUFlLENBQUNRLFNBQVNBLEtBQUtDLE9BQU8sQ0FBQ0MsR0FBR0MsTUFBTUEsTUFBTU4sS0FBSyxDQUFDO0FBQUEsRUFDN0Q7QUFFQSxRQUFNLENBQUNPLGFBQWFDLGNBQWMsSUFBSVosU0FBUztBQUFBLElBQzdDYSxNQUFNO0FBQUEsSUFDTkMsUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJaEIsU0FBUztBQUFBLElBQ3ZDYSxNQUFNO0FBQUEsSUFDTkMsUUFBUTtBQUFBLElBQ1JHLFNBQVM7QUFBQSxJQUNUQyxhQUFhO0FBQUEsSUFDYkMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJckIsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDc0IsYUFBYUMsY0FBYyxJQUFJdkIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3dCLGNBQWNDLGVBQWUsSUFBSXpCLFNBQVMsS0FBSztBQUd0RGhCLFlBQVUsTUFBTTtBQUNkLFVBQU0wQyxtQkFBbUIsWUFBWTtBQUNuQyxVQUFJO0FBQ0YsY0FBTUMsVUFBVUMsYUFBYUMsUUFBUSxNQUFNO0FBQzNDQyxnQkFBUUMsSUFBSUMsS0FBS0MsTUFBTUwsYUFBYUMsUUFBUSxNQUFNLENBQUMsQ0FBQztBQUVwRCxZQUFJLENBQUNGLFNBQVM7QUFDWkcsa0JBQVFDLElBQUksK0JBQStCO0FBQzNDO0FBQUEsUUFDRjtBQUVBLGNBQU1HLE9BQU9GLEtBQUtDLE1BQU1OLE9BQU87QUFDL0IsY0FBTVEsU0FBU0QsTUFBTUU7QUFFckIsWUFBSSxDQUFDRCxRQUFRO0FBQ1hMLGtCQUFRQyxJQUFJLG1CQUFtQjtBQUMvQjtBQUFBLFFBQ0Y7QUFFQSxjQUFNTSxNQUFNLE1BQU1wRCxJQUFJcUQsSUFBSSxvQkFBb0JILE1BQU0sRUFBRTtBQUV0REwsZ0JBQVFDLElBQUksaUJBQWlCTSxJQUFJRSxJQUFJO0FBRXJDdkIsb0JBQVksQ0FBQ1QsVUFBVTtBQUFBLFVBQ3JCLEdBQUdBO0FBQUFBLFVBQ0hNLE1BQU13QixJQUFJRSxNQUFNMUIsUUFBUTtBQUFBLFVBQ3hCQyxRQUFRdUIsSUFBSUUsTUFBTUMsZUFBZTtBQUFBLFFBQ25DLEVBQUU7QUFBQSxNQUVKLFNBQVNDLE9BQU87QUFDZFgsZ0JBQVFXLE1BQU0saUNBQWlDQSxLQUFLO0FBQUEsTUFDdEQ7QUFBQSxJQUNGO0FBRUFmLHFCQUFpQjtBQUFBLEVBQ25CLEdBQUcsRUFBRTtBQUVMLFFBQU1nQixtQkFBbUJBLENBQUNyQyxNQUFNO0FBQzlCLFVBQU1zQyxRQUFRQyxNQUFNQyxLQUFLeEMsRUFBRXlDLE9BQU9ILEtBQUs7QUFDdkMsUUFBSSxDQUFDQSxNQUFNSSxPQUFRO0FBRW5CLFVBQU1DLGVBQWUsQ0FBQyxtQkFBbUIsYUFBYSxjQUFjLFdBQVc7QUFDL0UsVUFBTUMsYUFBYTtBQUVuQixhQUFTQyxRQUFRUCxPQUFPO0FBQ3RCLFVBQUksQ0FBQ0ssYUFBYUcsU0FBU0QsS0FBS0UsSUFBSSxHQUFHO0FBQ3JDQyxlQUFPLFdBQVcsZ0JBQWdCLDRCQUE0QjtBQUM5RDtBQUFBLE1BQ0Y7QUFDQSxVQUFJSCxLQUFLSSxPQUFPLElBQUksT0FBTyxNQUFNO0FBQy9CRCxlQUFPLFdBQVcsa0JBQWtCLGNBQWM7QUFDbEQ7QUFBQSxNQUNGO0FBQ0FKLGlCQUFXTSxLQUFLTCxJQUFJO0FBQUEsSUFDdEI7QUFFQSxRQUFJRCxXQUFXRixRQUFRO0FBQ3JCaEQscUJBQWUsQ0FBQ1EsU0FBUyxDQUFDLEdBQUdBLE1BQU0sR0FBRzBDLFVBQVUsQ0FBQztBQUFBLElBQ25EO0FBQUEsRUFDRjtBQUVBLFFBQU1JLFNBQVNBLENBQUNELE1BQU1JLE9BQU9DLGdCQUFnQjtBQUMzQzlELFFBQUl5RCxJQUFJLEVBQUUsRUFBRUksT0FBT0MsYUFBYUMsV0FBVyxPQUFPQyxVQUFVLEVBQUUsQ0FBQztBQUFBLEVBQ2pFO0FBRUEsUUFBTUMsZUFBZUEsQ0FBQ0MsZUFBZSxPQUFPO0FBQzFDLFVBQU1DLFlBQVksQ0FBQztBQUNuQixRQUFJLENBQUMsdUJBQXVCQyxLQUFLaEQsU0FBU0YsS0FBS21ELEtBQUssQ0FBQyxHQUFHO0FBQ3RERixnQkFBVWpELE9BQU87QUFBQSxJQUNuQjtBQUNBLFFBQUksQ0FBQyxlQUFla0QsS0FBS2hELFNBQVNELE1BQU0sR0FBRztBQUN6Q2dELGdCQUFVaEQsU0FBUztBQUFBLElBQ3JCO0FBQ0EsUUFBSUMsU0FBU0UsUUFBUStDLEtBQUssRUFBRWpCLFNBQVMsR0FBRztBQUN0Q2UsZ0JBQVU3QyxVQUFVO0FBQUEsSUFDdEI7QUFDQSxRQUFJRixTQUFTSSxRQUFRNkMsS0FBSyxFQUFFakIsU0FBUyxHQUFHO0FBQ3RDZSxnQkFBVTNDLFVBQVU7QUFBQSxJQUN0QjtBQUVBLFVBQU04QyxjQUFjSixhQUFhSztBQUFBQSxNQUMvQixDQUFDQyxTQUNDQSxLQUFLdEQsU0FBU0UsU0FBU0YsUUFDdkJzRCxLQUFLckQsV0FBV0MsU0FBU0QsVUFDekJxRCxLQUFLbEQsWUFBWUYsU0FBU0UsV0FDMUJrRCxLQUFLaEQsWUFBWUosU0FBU0k7QUFBQUEsSUFDOUI7QUFFQSxRQUFJOEMsYUFBYTtBQUNmRyxZQUFNLHVCQUF1QjtBQUM3QixhQUFPO0FBQUEsSUFDVDtBQUVBL0MsY0FBVXlDLFNBQVM7QUFDbkIsV0FBT08sT0FBT0MsS0FBS1IsU0FBUyxFQUFFZixXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNd0Isa0JBQWtCLE9BQU9sRSxNQUFNO0FBQ25DQSxNQUFFbUUsZUFBZTtBQUVqQixRQUFJaEQsYUFBYztBQUVsQixRQUFJLENBQUNvQyxhQUFhdEMsV0FBVyxHQUFHO0FBQzlCK0IsYUFBTyxXQUFXLGlCQUFpQixtQ0FBbUM7QUFDdEU7QUFBQSxJQUNGO0FBRUEsUUFBSTtBQUNGNUIsc0JBQWdCLElBQUk7QUFDcEIsWUFBTWdELGNBQWMsSUFBSUMsU0FBUztBQUVqQyxZQUFNL0MsVUFBVUMsYUFBYUMsUUFBUSxNQUFNO0FBQzNDLFlBQU1NLFNBQVNSLFVBQVVLLEtBQUtDLE1BQU1OLE9BQU8sRUFBRVMsTUFBTTtBQUVuRCxVQUFJRCxRQUFRO0FBQ1ZzQyxvQkFBWUUsT0FBTyxVQUFVeEMsTUFBTTtBQUFBLE1BQ3JDO0FBRUFzQyxrQkFBWUUsT0FBTyxRQUFRNUQsU0FBU0YsSUFBSTtBQUN4QzRELGtCQUFZRSxPQUFPLFVBQVU1RCxTQUFTRCxNQUFNO0FBQzVDMkQsa0JBQVlFLE9BQU8sV0FBVzVELFNBQVNFLE9BQU87QUFDOUN3RCxrQkFBWUUsT0FBTyxlQUFlNUQsU0FBU0csV0FBVztBQUN0RHVELGtCQUFZRSxPQUFPLFdBQVc1RCxTQUFTSSxPQUFPO0FBRzlDckIsa0JBQVk4RSxRQUFRLENBQUMxQixTQUFTO0FBQzVCdUIsb0JBQVlFLE9BQU8scUJBQXFCekIsSUFBSTtBQUFBLE1BQzlDLENBQUM7QUFHRCxZQUFNMkIsU0FBUztBQUFBLFFBQ2JDLFNBQVM7QUFBQSxVQUNQLGdCQUFnQjtBQUFBLFFBQ2xCO0FBQUEsTUFDRjtBQUVBLFlBQU03RixJQUFJOEYsS0FBSyxzQkFBc0JOLGFBQWFJLE1BQU07QUFFeER0RCxxQkFBZSxDQUFDaEIsU0FBUyxDQUFDLEdBQUdBLE1BQU1RLFFBQVEsQ0FBQztBQUU1Q3NDLGFBQU8sV0FBVyx1QkFBdUIsa0RBQWtEO0FBRTNGckMsa0JBQVk7QUFBQSxRQUNWSCxNQUFNRixZQUFZRTtBQUFBQSxRQUNsQkMsUUFBUUgsWUFBWUc7QUFBQUEsUUFDcEJHLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsUUFDYkMsU0FBUztBQUFBLE1BQ1gsQ0FBQztBQUNEcEIscUJBQWUsRUFBRTtBQUNqQnNCLGdCQUFVLENBQUMsQ0FBQztBQUVaMkQsaUJBQVcsTUFBTS9FLFNBQVMsZUFBZSxHQUFHLElBQUk7QUFBQSxJQUNsRCxTQUFTd0MsT0FBTztBQUNkWCxjQUFRVyxNQUFNLHFCQUFxQkEsS0FBSztBQUN4Q1ksYUFBTyxTQUFTLHFCQUFxQlosTUFBTXdDLFVBQVUxQyxNQUFNcEIsV0FBVyx1QkFBdUI7QUFBQSxJQUMvRixVQUFDO0FBQ0NNLHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDRzdCO0FBQUFBO0FBQUFBLElBQ0QsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUNQLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLDZCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFDUix1QkFBQyxTQUFJLFdBQVUsdUJBQ2IsaUNBQUMsU0FBSSxXQUFVLHVFQUNiLGlDQUFDLFNBQUksV0FBVSxxRUFDYjtBQUFBLCtCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVNNLGNBQWMsV0FBVSxzRUFBcUUsT0FBTSxVQUNoSSxpQ0FBQyxLQUFFLE1BQU0sTUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVksS0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBLHVCQUFDLFVBQUssVUFBVXFFLGlCQUFpQixXQUFVLGFBQ3pDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDJEQUEwRCxzQ0FBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBR0EsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGlCQUFnQixvQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUM7QUFBQSxZQUVyQyx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPeEQsU0FBU0Y7QUFBQUEsa0JBQ2hCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTRHO0FBQUEsY0FHM0dPLE9BQU9QLFFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qk8saUJBQU9QLFFBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNEO0FBQUEsaUJBVDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxlQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxpQkFBZ0Isc0JBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVDO0FBQUEsWUFFdkMsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBT0UsU0FBU0Q7QUFBQUEsa0JBQ2hCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSTRHO0FBQUEsY0FHM0dNLE9BQU9OLFVBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qk0saUJBQU9OLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXdEO0FBQUEsaUJBVDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxlQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxpQkFBZ0IsdUJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdDO0FBQUEsWUFDeEMsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsYUFBWTtBQUFBLGtCQUNaLE9BQU9DLFNBQVNFO0FBQUFBLGtCQUNoQixVQUFVLENBQUNaLE1BQU1XLFlBQVksRUFBRSxHQUFHRCxVQUFVRSxTQUFTWixFQUFFeUMsT0FBT29DLE1BQU0sQ0FBQztBQUFBLGtCQUNyRSxXQUFVO0FBQUE7QUFBQSxnQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLb0k7QUFBQSxjQUVuSTlELE9BQU9ILFdBQVksdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkcsaUJBQU9ILFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsaUJBUi9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxlQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxzQkFBcUIsMEJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdEO0FBQUEsWUFDaEQsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsWUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU9GLFNBQVNHO0FBQUFBLG9CQUNoQixVQUFVLENBQUNiLE1BQU1XLFlBQVksRUFBRSxHQUFHRCxVQUFVRyxhQUFhYixFQUFFeUMsT0FBT29DLE1BQU0sQ0FBQztBQUFBLG9CQUN6RSxXQUFVO0FBQUEsb0JBQ1YsVUFBUTtBQUFBLG9CQUVSO0FBQUEsNkNBQUMsWUFBTyxPQUFNLElBQUcsaUNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtDO0FBQUEsc0JBQ2xDLHVCQUFDLFlBQU8sT0FBTSxjQUFhLDBCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxQztBQUFBLHNCQUNyQyx1QkFBQyxZQUFPLE9BQU0sa0JBQWlCLDhCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QztBQUFBLHNCQUM3Qyx1QkFBQyxZQUFPLE9BQU0sb0JBQW1CLGdDQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpRDtBQUFBLHNCQUNqRCx1QkFBQyxZQUFPLE9BQU0seUJBQXdCLHFDQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEyRDtBQUFBLHNCQUMzRCx1QkFBQyxZQUFPLE9BQU0sc0JBQXFCLGtDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFxRDtBQUFBLHNCQUNyRCx1QkFBQyxZQUFPLE9BQU0sa0JBQWlCLDhCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE2QztBQUFBLHNCQUM3Qyx1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkI7QUFBQTtBQUFBO0FBQUEsa0JBYi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFjQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSx5RUFDYixpQ0FBQyxTQUFJLFdBQVUseUJBQXdCLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDL0UsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFZLEtBQUksR0FBRSxvQkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0YsS0FEeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxQkE7QUFBQSxjQUNDOUQsT0FBT0YsZUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCRSxpQkFBT0YsZUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkQ7QUFBQSxpQkF4QmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsZUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxpQkFBZ0IsMkJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRDO0FBQUEsWUFDNUMsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsYUFBWTtBQUFBLGtCQUNaLE9BQU9ILFNBQVNJO0FBQUFBLGtCQUNoQixVQUFVLENBQUNkLE1BQU1XLFlBQVksRUFBRSxHQUFHRCxVQUFVSSxTQUFTZCxFQUFFeUMsT0FBT29DLE1BQU0sQ0FBQztBQUFBLGtCQUNyRSxXQUFVO0FBQUE7QUFBQSxnQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLb0k7QUFBQSxjQUVuSTlELE9BQU9ELFdBQVksdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkMsaUJBQU9ELFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsaUJBUi9FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxlQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxpQkFBZ0IsMEJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDO0FBQUEsWUFDM0MsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFRO0FBQUEsZ0JBQ1IsV0FBVTtBQUFBLGdCQUVWO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsSUFBRztBQUFBLHNCQUNILE1BQUs7QUFBQSxzQkFDTDtBQUFBLHNCQUNBLFdBQVU7QUFBQSxzQkFDVixRQUFPO0FBQUEsc0JBQ1AsVUFBVXVCO0FBQUFBO0FBQUFBLG9CQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNNkI7QUFBQSxrQkFJNUI1QyxZQUFZaUQsV0FBVyxJQUN0Qix1QkFBQyxTQUFJLFdBQVUsc0VBQ2I7QUFBQSwyQ0FBQyxlQUFZLE1BQU0sSUFBSSxXQUFVLHdCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxRDtBQUFBLG9CQUNyRCx1QkFBQyxPQUFFLFdBQVUscUNBQW9DLGdDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFpRTtBQUFBLG9CQUNqRSx1QkFBQyxPQUFFLFdBQVUseUJBQXdCLDZDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFrRTtBQUFBLHVCQUhwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDZFQUNaakQ7QUFBQUEsZ0NBQVlxRjtBQUFBQSxzQkFBSSxDQUFDakMsTUFBTTlDLFVBQ3RCLHVCQUFDLFNBQWdCLFdBQVUscUdBQ3pCO0FBQUEsK0NBQUMsU0FBSSxXQUFVLG1CQUNaOEM7QUFBQUEsK0JBQUtFLEtBQUtnQyxXQUFXLFFBQVEsSUFDNUIsdUJBQUMsU0FBSSxLQUFLQyxJQUFJQyxnQkFBZ0JwQyxJQUFJLEdBQUcsS0FBSSxXQUFVLFdBQVUsZ0NBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQXlGLElBRXpGLHVCQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLG1EQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFtQjtBQUFBLDRCQUNuQix1QkFBQyxVQUFLLFdBQVUscURBQW9ELG1CQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUF1RTtBQUFBLCtCQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUdBO0FBQUEsMEJBRUY7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsTUFBSztBQUFBLDhCQUNMLFNBQVMsQ0FBQzdDLE1BQU1GLGlCQUFpQkMsT0FBT0MsQ0FBQztBQUFBLDhCQUN6QyxXQUFVO0FBQUEsOEJBRVYsaUNBQUMsS0FBRSxNQUFNLE1BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBWTtBQUFBO0FBQUEsNEJBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQU1BO0FBQUEsNkJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFnQkE7QUFBQSx3QkFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsT0FBRSxXQUFVLGtEQUFpRCxPQUFPNkMsS0FBS3JDLE1BQ3ZFcUMsZUFBS3JDLEtBQUtrQyxTQUFTLEtBQUtHLEtBQUtyQyxLQUFLMEUsVUFBVSxHQUFHLEVBQUUsSUFBSSxRQUFRckMsS0FBS3JDLFFBRHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUlBO0FBQUEsMkJBdEJRVCxPQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBdUJBO0FBQUEsb0JBQ0Q7QUFBQSxvQkFDRCx1QkFBQyxTQUFJLFdBQVUsNktBQ2I7QUFBQSw2Q0FBQyxVQUFLLFdBQVUsc0JBQXFCLGlCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFzQztBQUFBLHNCQUN0Qyx1QkFBQyxVQUFLLFdBQVUsb0JBQW1CLHdCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEyQztBQUFBLHlCQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsdUJBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBK0JBO0FBQUE7QUFBQTtBQUFBLGNBcERKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXNEQSxLQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdEQTtBQUFBLGVBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkRBO0FBQUEsVUFHQSx1QkFBQyxTQUFJLFdBQVUsb0JBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFVBQVVvQjtBQUFBQSxjQUNWLFdBQVcsK0NBQStDQSxlQUFlLG1DQUFtQywwQ0FBMEM7QUFBQSxjQUdySkEseUJBQWUsa0JBQWtCO0FBQUE7QUFBQSxZQU5wQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBU0E7QUFBQSxhQTlLRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0tBO0FBQUEsV0FwTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFMQSxLQXRMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBdUxBLEtBeExGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF5TEE7QUFBQSxTQTNMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNExBO0FBQUEsT0EvTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdNQTtBQUVKO0FBQUM5QixHQXBZUUQsZUFBYTtBQUFBLFVBQ1NQLGFBQWFXLGlCQUV6QlYsV0FBVztBQUFBO0FBQUFxRyxLQUhyQi9GO0FBc1lULGVBQWVBO0FBQWMsSUFBQStGO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJBUEkiLCJub3RpZmljYXRpb24iLCJ1c2VOYXZpZ2F0ZSIsIlNpZGViYXIiLCJOYXZiYXIiLCJDbG91ZFVwbG9hZCIsIlgiLCJGaWxlVGV4dCIsIkNvbXBsYWludEZvcm0iLCJfcyIsImFwaSIsImNvbnRleHRIb2xkZXIiLCJ1c2VOb3RpZmljYXRpb24iLCJhdHRhY2htZW50cyIsInNldEF0dGFjaG1lbnRzIiwidXNlU3RhdGUiLCJuYXZpZ2F0ZSIsImhhbmRsZUNhbmNlbCIsImhhbmRsZVJlbW92ZUZpbGUiLCJpbmRleCIsImUiLCJzdG9wUHJvcGFnYXRpb24iLCJwcmV2IiwiZmlsdGVyIiwiXyIsImkiLCJ1c2VyUHJvZmlsZSIsInNldFVzZXJQcm9maWxlIiwibmFtZSIsIm1vYmlsZSIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJzdWJqZWN0IiwiZGVzaWduYXRpb24iLCJtZXNzYWdlIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwic3VibWlzc2lvbnMiLCJzZXRTdWJtaXNzaW9ucyIsImlzU3VibWl0dGluZyIsInNldElzU3VibWl0dGluZyIsImZldGNoVXNlclByb2ZpbGUiLCJ1c2VyU3RyIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsImNvbnNvbGUiLCJsb2ciLCJKU09OIiwicGFyc2UiLCJ1c2VyIiwidXNlcklkIiwiX2lkIiwicmVzIiwiZ2V0IiwiZGF0YSIsInBob25lTnVtYmVyIiwiZXJyb3IiLCJoYW5kbGVGaWxlQ2hhbmdlIiwiZmlsZXMiLCJBcnJheSIsImZyb20iLCJ0YXJnZXQiLCJsZW5ndGgiLCJhbGxvd2VkVHlwZXMiLCJ2YWxpZEZpbGVzIiwiZmlsZSIsImluY2x1ZGVzIiwidHlwZSIsIm5vdGlmeSIsInNpemUiLCJwdXNoIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsInBsYWNlbWVudCIsImR1cmF0aW9uIiwidmFsaWRhdGVGb3JtIiwiZXhpc3RpbmdEYXRhIiwibmV3RXJyb3JzIiwidGVzdCIsInRyaW0iLCJpc0R1cGxpY2F0ZSIsInNvbWUiLCJpdGVtIiwiYWxlcnQiLCJPYmplY3QiLCJrZXlzIiwic3VibWl0Q29tcGxhaW50IiwicHJldmVudERlZmF1bHQiLCJmb3JtUGF5bG9hZCIsIkZvcm1EYXRhIiwiYXBwZW5kIiwiZm9yRWFjaCIsImNvbmZpZyIsImhlYWRlcnMiLCJwb3N0Iiwic2V0VGltZW91dCIsInJlc3BvbnNlIiwidmFsdWUiLCJtYXAiLCJzdGFydHNXaXRoIiwiVVJMIiwiY3JlYXRlT2JqZWN0VVJMIiwic3Vic3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ29tcGxhaW50Rm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgQVBJIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IHsgQ2xvdWRVcGxvYWQsIFgsIEZpbGVUZXh0IH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5cclxuZnVuY3Rpb24gQ29tcGxhaW50Rm9ybSgpIHtcclxuICBjb25zdCBbYXBpLCBjb250ZXh0SG9sZGVyXSA9IG5vdGlmaWNhdGlvbi51c2VOb3RpZmljYXRpb24oKTtcclxuICBjb25zdCBbYXR0YWNobWVudHMsIHNldEF0dGFjaG1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNhbmNlbCA9ICgpID0+IHtcclxuICAgIG5hdmlnYXRlKC0xKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVSZW1vdmVGaWxlID0gKGluZGV4LCBlKSA9PiB7XHJcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xyXG4gICAgc2V0QXR0YWNobWVudHMoKHByZXYpID0+IHByZXYuZmlsdGVyKChfLCBpKSA9PiBpICE9PSBpbmRleCkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IFt1c2VyUHJvZmlsZSwgc2V0VXNlclByb2ZpbGVdID0gdXNlU3RhdGUoe1xyXG4gICAgbmFtZTogXCJcIixcclxuICAgIG1vYmlsZTogXCJcIlxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIG5hbWU6IFwiXCIsXHJcbiAgICBtb2JpbGU6IFwiXCIsXHJcbiAgICBzdWJqZWN0OiBcIlwiLFxyXG4gICAgZGVzaWduYXRpb246IFwiXCIsXHJcbiAgICBtZXNzYWdlOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzdWJtaXNzaW9ucywgc2V0U3VibWlzc2lvbnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc1N1Ym1pdHRpbmcsIHNldElzU3VibWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hVc2VyUHJvZmlsZSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCB1c2VyU3RyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpKSlcclxuXHJcbiAgICAgICAgaWYgKCF1c2VyU3RyKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZyhcIk5vIHVzZXIgZm91bmQgaW4gbG9jYWxTdG9yYWdlXCIpO1xyXG4gICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UodXNlclN0cik7XHJcbiAgICAgICAgY29uc3QgdXNlcklkID0gdXNlcj8uX2lkO1xyXG5cclxuICAgICAgICBpZiAoIXVzZXJJZCkge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJVc2VyIElEIG5vdCBmb3VuZFwiKTtcclxuICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IEFQSS5nZXQoYC9hZG1pbi9nZXQtYWRtaW4vJHt1c2VySWR9YCk7XHJcblxyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiVXNlciBwcm9maWxlOlwiLCByZXMuZGF0YSk7XHJcblxyXG4gICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgIG5hbWU6IHJlcy5kYXRhPy5uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgICBtb2JpbGU6IHJlcy5kYXRhPy5waG9uZU51bWJlciB8fCBcIlwiLFxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCB1c2VyIHByb2ZpbGU6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaFVzZXJQcm9maWxlKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVGaWxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IGZpbGVzID0gQXJyYXkuZnJvbShlLnRhcmdldC5maWxlcyk7XHJcbiAgICBpZiAoIWZpbGVzLmxlbmd0aCkgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGFsbG93ZWRUeXBlcyA9IFtcImFwcGxpY2F0aW9uL3BkZlwiLCBcImltYWdlL3BuZ1wiLCBcImltYWdlL2pwZWdcIiwgXCJpbWFnZS9qcGdcIl07XHJcbiAgICBjb25zdCB2YWxpZEZpbGVzID0gW107XHJcblxyXG4gICAgZm9yIChsZXQgZmlsZSBvZiBmaWxlcykge1xyXG4gICAgICBpZiAoIWFsbG93ZWRUeXBlcy5pbmNsdWRlcyhmaWxlLnR5cGUpKSB7XHJcbiAgICAgICAgbm90aWZ5KFwid2FybmluZ1wiLCBcIkludmFsaWQgRmlsZVwiLCBcIk9ubHkgUERGLCBQTkcsIEpQRyBhbGxvd2VkXCIpO1xyXG4gICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChmaWxlLnNpemUgPiA1ICogMTAyNCAqIDEwMjQpIHsgXHJcbiAgICAgICAgbm90aWZ5KFwid2FybmluZ1wiLCBcIkZpbGUgVG9vIExhcmdlXCIsIFwiTWF4IHNpemUgNU1CXCIpO1xyXG4gICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICB9XHJcbiAgICAgIHZhbGlkRmlsZXMucHVzaChmaWxlKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAodmFsaWRGaWxlcy5sZW5ndGgpIHtcclxuICAgICAgc2V0QXR0YWNobWVudHMoKHByZXYpID0+IFsuLi5wcmV2LCAuLi52YWxpZEZpbGVzXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgbm90aWZ5ID0gKHR5cGUsIHRpdGxlLCBkZXNjcmlwdGlvbikgPT4ge1xyXG4gICAgYXBpW3R5cGVdKHsgdGl0bGUsIGRlc2NyaXB0aW9uLCBwbGFjZW1lbnQ6IFwidG9wXCIsIGR1cmF0aW9uOiAyIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlRm9ybSA9IChleGlzdGluZ0RhdGEgPSBbXSkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcbiAgICBpZiAoIS9eW0EtWmEtelxcc18tXXsxLDE1fSQvLnRlc3QoZm9ybURhdGEubmFtZS50cmltKCkpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5uYW1lID0gXCJOYW1lIG11c3QgY29udGFpbiBvbmx5IGFscGhhYmV0cywgc3BhY2UsIC0gb3IgXyBhbmQgbWF4IDE1IGNoYXJhY3RlcnNcIjtcclxuICAgIH1cclxuICAgIGlmICghL15bNi05XVxcZHs5fSQvLnRlc3QoZm9ybURhdGEubW9iaWxlKSkge1xyXG4gICAgICBuZXdFcnJvcnMubW9iaWxlID0gXCJNb2JpbGUgbnVtYmVyIG11c3Qgc3RhcnQgd2l0aCA2LTkgYW5kIGJlIGV4YWN0bHkgMTAgZGlnaXRzXCI7XHJcbiAgICB9XHJcbiAgICBpZiAoZm9ybURhdGEuc3ViamVjdC50cmltKCkubGVuZ3RoIDwgMykge1xyXG4gICAgICBuZXdFcnJvcnMuc3ViamVjdCA9IFwiU3ViamVjdCBtdXN0IGJlIGF0IGxlYXN0IDMgY2hhcmFjdGVyc1wiO1xyXG4gICAgfVxyXG4gICAgaWYgKGZvcm1EYXRhLm1lc3NhZ2UudHJpbSgpLmxlbmd0aCA8IDUpIHtcclxuICAgICAgbmV3RXJyb3JzLm1lc3NhZ2UgPSBcIkRlc2NyaXB0aW9uIG11c3QgYmUgYXQgbGVhc3QgNSBjaGFyYWN0ZXJzXCI7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgaXNEdXBsaWNhdGUgPSBleGlzdGluZ0RhdGEuc29tZShcclxuICAgICAgKGl0ZW0pID0+XHJcbiAgICAgICAgaXRlbS5uYW1lID09PSBmb3JtRGF0YS5uYW1lICYmXHJcbiAgICAgICAgaXRlbS5tb2JpbGUgPT09IGZvcm1EYXRhLm1vYmlsZSAmJlxyXG4gICAgICAgIGl0ZW0uc3ViamVjdCA9PT0gZm9ybURhdGEuc3ViamVjdCAmJlxyXG4gICAgICAgIGl0ZW0ubWVzc2FnZSA9PT0gZm9ybURhdGEubWVzc2FnZVxyXG4gICAgKTtcclxuXHJcbiAgICBpZiAoaXNEdXBsaWNhdGUpIHtcclxuICAgICAgYWxlcnQoXCLinYwgRGF0YSBhbHJlYWR5IHN0b3JlZFwiKTtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHN1Ym1pdENvbXBsYWludCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgaWYgKGlzU3VibWl0dGluZykgcmV0dXJuO1xyXG5cclxuICAgIGlmICghdmFsaWRhdGVGb3JtKHN1Ym1pc3Npb25zKSkge1xyXG4gICAgICBub3RpZnkoXCJ3YXJuaW5nXCIsIFwiSW52YWxpZCBJbnB1dFwiLCBcIlBsZWFzZSBmaXggdGhlIGhpZ2hsaWdodGVkIGZpZWxkc1wiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIHNldElzU3VibWl0dGluZyh0cnVlKTtcclxuICAgICAgY29uc3QgZm9ybVBheWxvYWQgPSBuZXcgRm9ybURhdGEoKTtcclxuXHJcbiAgICAgIGNvbnN0IHVzZXJTdHIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICAgIGNvbnN0IHVzZXJJZCA9IHVzZXJTdHIgPyBKU09OLnBhcnNlKHVzZXJTdHIpLl9pZCA6IG51bGw7XHJcblxyXG4gICAgICBpZiAodXNlcklkKSB7XHJcbiAgICAgICAgZm9ybVBheWxvYWQuYXBwZW5kKFwidXNlcklkXCIsIHVzZXJJZCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGZvcm1QYXlsb2FkLmFwcGVuZChcIm5hbWVcIiwgZm9ybURhdGEubmFtZSk7XHJcbiAgICAgIGZvcm1QYXlsb2FkLmFwcGVuZChcIm1vYmlsZVwiLCBmb3JtRGF0YS5tb2JpbGUpO1xyXG4gICAgICBmb3JtUGF5bG9hZC5hcHBlbmQoXCJzdWJqZWN0XCIsIGZvcm1EYXRhLnN1YmplY3QpO1xyXG4gICAgICBmb3JtUGF5bG9hZC5hcHBlbmQoXCJkZXNpZ25hdGlvblwiLCBmb3JtRGF0YS5kZXNpZ25hdGlvbik7XHJcbiAgICAgIGZvcm1QYXlsb2FkLmFwcGVuZChcIm1lc3NhZ2VcIiwgZm9ybURhdGEubWVzc2FnZSk7XHJcblxyXG4gICAgIFxyXG4gICAgICBhdHRhY2htZW50cy5mb3JFYWNoKChmaWxlKSA9PiB7XHJcbiAgICAgICAgZm9ybVBheWxvYWQuYXBwZW5kKFwiY29tcGxhaW50X3VwbG9hZHNcIiwgZmlsZSk7IFxyXG4gICAgICB9KTtcclxuXHJcbiAgICBcclxuICAgICAgY29uc3QgY29uZmlnID0ge1xyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnbXVsdGlwYXJ0L2Zvcm0tZGF0YSdcclxuICAgICAgICB9XHJcbiAgICAgIH07XHJcblxyXG4gICAgICBhd2FpdCBBUEkucG9zdChcIi9jb21wbGFpbnRzL2NyZWF0ZVwiLCBmb3JtUGF5bG9hZCwgY29uZmlnKTtcclxuXHJcbiAgICAgIHNldFN1Ym1pc3Npb25zKChwcmV2KSA9PiBbLi4ucHJldiwgZm9ybURhdGFdKTtcclxuXHJcbiAgICAgIG5vdGlmeShcInN1Y2Nlc3NcIiwgXCJDb21wbGFpbnQgU3VibWl0dGVkXCIsIFwiT3VyIHN1cHBvcnQgdGVhbSB3aWxsIHJlcGx5IGFzIHNvb24gYXMgcG9zc2libGUuXCIpO1xyXG5cclxuICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgIG5hbWU6IHVzZXJQcm9maWxlLm5hbWUsXHJcbiAgICAgICAgbW9iaWxlOiB1c2VyUHJvZmlsZS5tb2JpbGUsXHJcbiAgICAgICAgc3ViamVjdDogXCJcIixcclxuICAgICAgICBkZXNpZ25hdGlvbjogXCJcIixcclxuICAgICAgICBtZXNzYWdlOiBcIlwiXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRBdHRhY2htZW50cyhbXSk7XHJcbiAgICAgIHNldEVycm9ycyh7fSk7XHJcblxyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IG5hdmlnYXRlKFwiL2hlbHAmc3VwcG9ydFwiKSwgMTUwMCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiU3VibWlzc2lvbiBFcnJvcjpcIiwgZXJyb3IpO1xyXG4gICAgICBub3RpZnkoXCJlcnJvclwiLCBcIlN1Ym1pc3Npb24gRmFpbGVkXCIsIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiU29tZXRoaW5nIHdlbnQgd3JvbmcuXCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAge2NvbnRleHRIb2xkZXJ9XHJcbiAgICAgIDxOYXZiYXIgLz5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHctc2NyZWVuIG10LTE0XCI+XHJcbiAgICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtY29sIHctZnVsbCBwLTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1jZW50ZXIgYmctZ3JheS0xMDAgcHgtNCBweS0yNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy14bCBiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy1tZCBib3JkZXIgcC04IHJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17aGFuZGxlQ2FuY2VsfSBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00IHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1yZWQtNTAwIHRyYW5zaXRpb25cIiB0aXRsZT1cIkNhbmNlbFwiPlxyXG4gICAgICAgICAgICAgICAgPFggc2l6ZT17MjR9IC8+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtzdWJtaXRDb21wbGFpbnR9IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmRpZ28tODAwIHRleHQtY2VudGVyIHByLThcIj5cclxuICAgICAgICAgICAgICAgICAgUmFpc2UgYSBTdXBwb3J0IFRpY2tldFxyXG4gICAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogTkFNRSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiPk5hbWU8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLWdyYXktMTAwIHB4LTQgcHktMiBjdXJzb3Itbm90LWFsbG93ZWQgb3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm5hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnMubmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogTU9CSUxFICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwXCI+TW9iaWxlPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm1vYmlsZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGJnLWdyYXktMTAwIHB4LTQgcHktMiBjdXJzb3Itbm90LWFsbG93ZWQgb3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm1vYmlsZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC1zbSBtdC0xXCI+e2Vycm9ycy5tb2JpbGV9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIFNVQkpFQ1QgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5TdWJqZWN0PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHlvdXIgU3ViamVjdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc3ViamVjdH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgc3ViamVjdDogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHB4LTQgcHktMiBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS0yMDAgb3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuc3ViamVjdCAmJiAoPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnMuc3ViamVjdH08L3A+KX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTQgaXRlbXMtc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgcHQtMlwiPkRlcGFydG1lbnQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5kZXNpZ25hdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBkZXNpZ25hdGlvbjogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcHgtNCBweS0yIGFwcGVhcmFuY2Utbm9uZSBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS0yMDAgb3V0bGluZS1ub25lIHByLTEwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBEZXBhcnRtZW50PC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNYW5hZ2VtZW50XCI+TWFuYWdlbWVudDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQWRtaW5pc3RyYXRpb25cIj5BZG1pbmlzdHJhdGlvbjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiU2FsZXMgJiBCdXNpbmVzc1wiPlNhbGVzICYgQnVzaW5lc3M8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkNvbGxlY3Rpb24gT3BlcmF0aW9uc1wiPkNvbGxlY3Rpb24gT3BlcmF0aW9uczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQWNjb3VudHMgJiBGaW5hbmNlXCI+QWNjb3VudHMgJiBGaW5hbmNlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJUZWNobmljYWwgLyBJVFwiPlRlY2huaWNhbCAmIElUPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJPdGhlcnNcIj5PdGhlcnM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBmbGV4IGl0ZW1zLWNlbnRlciBweC0yIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZ3JheS00MDBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xOSA5bC03IDctNy03XCI+PC9wYXRoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVzaWduYXRpb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnMuZGVzaWduYXRpb259PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIE1FU1NBR0UgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDBcIj5EZXNjcmlwdGlvbjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgICAgICAgcm93cz1cIjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJEZXNjcmliZSB5b3VyIGlzc3VlIGluIGRldGFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgbWVzc2FnZTogZS50YXJnZXQudmFsdWUgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHB4LTQgcHktMiBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS0yMDAgb3V0bGluZS1ub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubWVzc2FnZSAmJiAoPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQtc20gbXQtMVwiPntlcnJvcnMubWVzc2FnZX08L3A+KX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQVRUQUNIIERPQ1VNRU5UICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwXCI+QXR0YWNobWVudDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNvbXBsYWludF91cGxvYWRzXCIgLy8gQ2hhbmdlZCBpZCB0byBtYXRjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgaC0zMiBib3JkZXItMiBib3JkZXItZGFzaGVkIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXIgYmctZ3JheS01MCBob3ZlcjpiZy1ncmF5LTEwMCBvdmVyZmxvdy1oaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNvbXBsYWludF91cGxvYWRzXCIgLy8gQ2hhbmdlZCBpZCB0byBtYXRjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG11bHRpcGxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cIi5wZGYsLnBuZywuanBnLC5qcGVnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBSZXN0IG9mIHlvdXIgYXR0YWNobWVudCBVSSByZW1haW5zIHRoZSBzYW1lICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAge2F0dGFjaG1lbnRzLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LTEwIHBvaW50ZXItZXZlbnRzLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2xvdWRVcGxvYWQgc2l6ZT17NDB9IGNsYXNzTmFtZT1cInRleHQtZ3JheS00MDAgbWItMlwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+QXR0YWNoIERvY3VtZW50czwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5QREYsIFBORywgSlBHLCBKUEVHIChNYXggNU1CKTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTMgZ2FwLTIgdy1mdWxsIGgtZnVsbCBwLTIgb3ZlcmZsb3cteS1hdXRvIHotMTAgYmctd2hpdGUvNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YXR0YWNobWVudHMubWFwKChmaWxlLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJyZWxhdGl2ZSBncm91cCBoLTI0IHctZnVsbCByb3VuZGVkIGJvcmRlciBvdmVyZmxvdy1oaWRkZW4gYmctZ3JheS0xMDAgZmxleC1zaHJpbmstMCBmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIHJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ZpbGUudHlwZS5zdGFydHNXaXRoKCdpbWFnZS8nKSA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtVUkwuY3JlYXRlT2JqZWN0VVJMKGZpbGUpfSBhbHQ9XCJwcmV2aWV3XCIgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGgtZnVsbCB3LWZ1bGwgdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHQgc2l6ZT17Mjh9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRydW5jYXRlIHctZnVsbCB0ZXh0LWNlbnRlciBweC0xIG10LTFcIj5QREY8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGhhbmRsZVJlbW92ZUZpbGUoaW5kZXgsIGUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgLXRvcC0xIC1yaWdodC0xIGJnLXJlZC01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWZ1bGwgcC0wLjUgaG92ZXI6YmctcmVkLTYwMCBzaGFkb3ctc20gdHJhbnNpdGlvbiB0cmFuc2Zvcm0gc2NhbGUtOTAgaG92ZXI6c2NhbGUtMTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8WCBzaXplPXsxMn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwIHAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZ3JheS03MDAgdHJ1bmNhdGUgdGV4dC1jZW50ZXJcIiB0aXRsZT17ZmlsZS5uYW1lfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWxlLm5hbWUubGVuZ3RoID4gMTUgPyBmaWxlLm5hbWUuc3Vic3RyaW5nKDAsIDE1KSArICcuLi4nIDogZmlsZS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtMjQgdy1mdWxsIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMzAwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ibHVlLTUwMCBob3ZlcjpiZy1ncmF5LTUwIHRyYW5zaXRpb25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZFwiPis8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBtdC0xXCI+QWRkIE1vcmU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBTVUJNSVQgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtOCBweS0yIHJvdW5kZWQtbGcgZm9udC1tZWRpdW0gdHJhbnNpdGlvbiAke2lzU3VibWl0dGluZyA/IFwiYmctZ3JheS00MDAgY3Vyc29yLW5vdC1hbGxvd2VkXCIgOiBcImJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNzAwIHRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7aXNTdWJtaXR0aW5nID8gXCJTdWJtaXR0aW5nLi4uXCIgOiBcIlN1Ym1pdFwifVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb21wbGFpbnRGb3JtOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9Db21wbGFpbnRGb3JtLmpzeCJ9