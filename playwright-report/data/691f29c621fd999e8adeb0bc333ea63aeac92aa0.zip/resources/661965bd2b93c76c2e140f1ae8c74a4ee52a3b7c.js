import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UnApprovedCustomer.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Input, Select, Dropdown, Button, DatePicker } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import {
  MdGridView,
  MdViewList,
  MdOutlineTableRows,
  MdAssignmentInd
} from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import handleEnrollmentRequestPrint from "/src/components/printFormats/enrollmentRequestPrint.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
import __vite__cjsImport18_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport18_dayjs.__esModule ? __vite__cjsImport18_dayjs.default : __vite__cjsImport18_dayjs;
import { SearchOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const STATUS_OPTIONS = [
  "Contacted",
  "Interested",
  "Follow Up",
  "Converted",
  "Rejected"
];
const STATUS_SUMMARY_CONFIG = [
  {
    key: "Contacted",
    label: "Contacted",
    color: "from-indigo-500 to-indigo-600",
    bgLight: "bg-indigo-50",
    textColor: "text-indigo-700",
    iconColor: "text-indigo-500",
    ringColor: "ring-indigo-100",
    icon: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 47,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 46,
      columnNumber: 3
    }, this)
  },
  {
    key: "Interested",
    label: "Interested",
    color: "from-blue-500 to-blue-600",
    bgLight: "bg-blue-50",
    textColor: "text-blue-700",
    iconColor: "text-blue-500",
    ringColor: "ring-blue-100",
    icon: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 61,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 60,
      columnNumber: 3
    }, this)
  },
  {
    key: "Follow Up",
    label: "Follow Up",
    color: "from-purple-500 to-purple-600",
    bgLight: "bg-purple-50",
    textColor: "text-purple-700",
    iconColor: "text-purple-500",
    ringColor: "ring-purple-100",
    icon: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 75,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 74,
      columnNumber: 3
    }, this)
  },
  {
    key: "Converted",
    label: "Converted",
    color: "from-emerald-500 to-green-600",
    bgLight: "bg-emerald-50",
    textColor: "text-emerald-700",
    iconColor: "text-emerald-500",
    ringColor: "ring-emerald-100",
    icon: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 89,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 88,
      columnNumber: 3
    }, this)
  },
  {
    key: "Rejected",
    label: "Rejected",
    color: "from-red-500 to-red-600",
    bgLight: "bg-red-50",
    textColor: "text-red-700",
    iconColor: "text-red-500",
    ringColor: "ring-red-100",
    icon: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 103,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 102,
      columnNumber: 3
    }, this)
  }
];
const UnApprovedCustomer = ({ hideSidebar = false }) => {
  _s();
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentUpdateUser, setCurrentUpdateUser] = useState(null);
  const [selectedGroup, setSelectedGroup] = useState({});
  const [groups, setGroups] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [areas, setAreas] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [errors, setErrors] = useState({});
  const [updateFormData, setUpdateFormData] = useState({
    full_name: "",
    email: "",
    phone_number: "",
    password: "",
    address: "",
    pincode: "",
    adhaar_no: "",
    pan_no: "",
    title: "",
    gender: "",
    marital_status: "",
    dateofbirth: "",
    nationality: "",
    village: "",
    taluk: "",
    father_name: "",
    district: "",
    state: "",
    collection_area: "",
    alternate_number: "",
    referral_name: "",
    nominee_name: "",
    nominee_dateofbirth: "",
    nominee_phone_number: "",
    nominee_relationship: "",
    aadhar_frontphoto: "",
    aadhar_backphoto: "",
    pan_frontphoto: "",
    pan_backphoto: "",
    profilephoto: "",
    bank_name: "",
    bank_branch_name: "",
    bank_account_number: "",
    bank_IFSC_code: "",
    selected_plan: ""
  });
  const [selectedCustomers, setSelectedCustomers] = useState([]);
  const [lastCheckedId, setLastCheckedId] = useState(null);
  const [showContactModal, setShowContactModal] = useState(false);
  const [contactReason, setContactReason] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");
  const [activeTab, setActiveTab] = useState("pending");
  const [showActionModal, setShowActionModal] = useState(false);
  const [actionAssignments, setActionAssignments] = useState({});
  const [viewMode, setViewMode] = useState("grid");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(9);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredUsers.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredUsers.length / itemsPerPage);
  const [showStatusUpdateModal, setShowStatusUpdateModal] = useState(false);
  const [statusUpdateData, setStatusUpdateData] = useState({
    _id: "",
    status: "",
    remark: "",
    follow_up_date: ""
  });
  const [isStatusUpdating, setIsStatusUpdating] = useState(false);
  const getStatusCounts = () => {
    const contacted = filteredUsers.filter(
      (u) => u.status && u.status !== "Not Contacted"
    );
    return {
      total: contacted.length,
      Contacted: contacted.filter((u) => u.status === "Contacted").length,
      Interested: contacted.filter((u) => u.status === "Interested").length,
      "Follow Up": contacted.filter((u) => u.status === "Follow Up").length,
      Converted: contacted.filter((u) => u.status === "Converted").length,
      Rejected: contacted.filter((u) => u.status === "Rejected").length
    };
  };
  const getTabFilteredUsers = () => {
    if (activeTab === "pending") {
      return filteredUsers.filter(
        (user) => user.status === "Not Contacted" || !user.status
      );
    } else {
      return filteredUsers.filter(
        (user) => user.status && user.status !== "Not Contacted"
      );
    }
  };
  const getStatusColor = (status) => {
    switch (status) {
      case "Approved":
        return "bg-emerald-50 text-emerald-700 ring-1 ring-inset ring-emerald-600/20";
      case "Pending":
        return "bg-amber-50 text-amber-700 ring-1 ring-inset ring-amber-600/20";
      case "Interested":
        return "bg-blue-50 text-blue-700 ring-1 ring-inset ring-blue-600/20";
      case "Not Interested":
        return "bg-gray-50 text-gray-600 ring-1 ring-inset ring-gray-500/20";
      case "Contacted":
        return "bg-indigo-50 text-indigo-700 ring-1 ring-inset ring-indigo-600/20";
      case "Follow Up":
        return "bg-purple-50 text-purple-700 ring-1 ring-inset ring-purple-600/20";
      case "Converted":
        return "bg-green-50 text-green-700 ring-1 ring-inset ring-green-600/20";
      case "Rejected":
        return "bg-red-50 text-red-700 ring-1 ring-inset ring-red-600/20";
      default:
        return "bg-gray-50 text-gray-600 ring-1 ring-inset ring-gray-500/20";
    }
  };
  const getStatusIcon = (status) => {
    switch (status) {
      case "Contacted":
        return /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 259,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 258,
          columnNumber: 11
        }, this);
      case "Interested":
        return /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 265,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 264,
          columnNumber: 11
        }, this);
      case "Follow Up":
        return /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 271,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 270,
          columnNumber: 11
        }, this);
      case "Converted":
        return /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 277,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 276,
          columnNumber: 11
        }, this);
      case "Rejected":
        return /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 283,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 282,
          columnNumber: 11
        }, this);
      default:
        return null;
    }
  };
  const TableUsers = filteredUsers.map((user, index) => ({
    id: index + 1,
    _id: user._id,
    name: user.name,
    phone_number: user.phone_number,
    customer_id: user.customer_id,
    address: user.address,
    approval_status: /* @__PURE__ */ jsxDEV("span", { className: `px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(user.approval_status)}`, children: user.approval_status }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 300,
      columnNumber: 5
    }, this),
    status: /* @__PURE__ */ jsxDEV("span", { className: `px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(user.status || "Not Contacted")}`, children: user.status || "Not Contacted" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 305,
      columnNumber: 5
    }, this),
    statusRaw: user.status || "Not Contacted",
    remark: user.remark ? /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-600 max-w-[200px] truncate block", title: user.remark, children: user.remark }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 311,
      columnNumber: 5
    }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: "—" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 315,
      columnNumber: 5
    }, this),
    assigned_to: user.assigned_to ? /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-indigo-700 bg-indigo-50 px-2 py-1 rounded-full", children: user.assigned_to }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 318,
      columnNumber: 5
    }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: "—" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 322,
      columnNumber: 5
    }, this),
    follow_up_date: user.follow_up_date ? /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-purple-700 bg-purple-50 px-2 py-1 rounded-full", children: user.follow_up_date }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 325,
      columnNumber: 5
    }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: "—" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 329,
      columnNumber: 5
    }, this),
    createdAt: user.createdAt,
    collection_area: user.collection_area,
    action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center", children: /* @__PURE__ */ jsxDEV(
      Dropdown,
      {
        trigger: ["click"],
        menu: {
          items: [
            {
              key: "1",
              label: /* @__PURE__ */ jsxDEV("div", { className: "text-violet-600 font-medium cursor-pointer px-2 py-1", onClick: () => handleUpdateModalOpen(user._id), children: "Edit" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 342,
                columnNumber: 13
              }, this)
            },
            {
              key: "2",
              label: /* @__PURE__ */ jsxDEV("div", { className: "text-red-600 font-medium cursor-pointer px-2 py-1", onClick: () => handleDeleteModalOpen(user._id), children: "Delete" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 348,
                columnNumber: 13
              }, this)
            },
            {
              key: "3",
              label: /* @__PURE__ */ jsxDEV("div", { className: "text-gray-700 font-medium cursor-pointer px-2 py-1", onClick: () => handleEnrollmentRequestPrint(user._id), children: "Print" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 354,
                columnNumber: 13
              }, this)
            },
            {
              key: "4",
              label: /* @__PURE__ */ jsxDEV(
                "div",
                {
                  className: `font-medium cursor-pointer px-2 py-1 ${user.approval_status !== "Approved" ? "text-emerald-600" : "text-red-600"}`,
                  onClick: () => handleCustomerStatus(user._id, user.approval_status !== "Approved" ? "Approved" : "Pending"),
                  children: user.approval_status !== "Approved" ? "Approve" : "Unapprove"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 360,
                  columnNumber: 13
                },
                this
              )
            }
          ]
        },
        placement: "bottomRight",
        children: /* @__PURE__ */ jsxDEV("button", { className: "p-2 rounded-lg hover:bg-gray-100 transition-colors", children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-gray-500 text-lg" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 373,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 372,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 335,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 334,
      columnNumber: 5
    }, this)
  }));
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "unverfied_customer_code", header: "Code" },
    { key: "name", header: "Full Name" },
    { key: "phone_number", header: "Phone" },
    { key: "customer_id", header: "ID" },
    { key: "address", header: "Address" },
    { key: "collection_area", header: "Area" },
    { key: "approval_status", header: "Approval" },
    { key: "status", header: "Contact Status" },
    { key: "assigned_to", header: "Assigned To" },
    { key: "remark", header: "Remark" },
    { key: "follow_up_date", header: "Follow Up" },
    { key: "createdAt", header: "Joined" },
    { key: "action", header: "Actions" }
  ];
  const GlobalSearchChangeHandler = (e) => setSearchTerm(e.target.value);
  useEffect(() => {
    const fetchCollectionArea = async () => {
      try {
        setAreas((await api.get("/collection-area-request/get-collection-area-data")).data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchCollectionArea();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchDistricts = async () => {
      try {
        setDistricts((await api.get("/user/district")).data?.data?.districts);
      } catch (error) {
        console.error(error);
      }
    };
    fetchDistricts();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchAdmins = async () => {
      try {
        const response = await api.get("/admin/get-sub-admins");
        setAdmins(response.data || []);
      } catch (error) {
        console.error("Failed to fetch admins", error);
        setAdmins([]);
      }
    };
    fetchAdmins();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/user/approval-status/false");
        const formattedData = response.data.map((group, index) => ({
          _id: group._id,
          id: index + 1,
          unverfied_customer_code: group?.unverfied_customer_code,
          name: group.full_name,
          phone_number: group.phone_number,
          createdAt: group.createdAt?.split("T")[0],
          address: group.address,
          pincode: group.pincode,
          customer_id: group.customer_id,
          collection_area: group.collection_area?.route_name,
          approval_status: group.approval_status === "true" ? "Approved" : "Pending",
          status: group.status || "Not Contacted",
          remark: group.remark || "",
          follow_up_date: group.follow_up_date ? dayjs(group.follow_up_date).format("YYYY-MM-DD") : "",
          assigned_to: group.assigned_to?.full_name || group.assigned_to?.name || "",
          assigned_to_id: group.assigned_to?._id || "",
          status_updated_at: group.updatedAt ? dayjs(group.updatedAt).format("YYYY-MM-DD HH:mm") : ""
        }));
        setFilteredUsers(
          formattedData.filter(
            (user) => user.name.toLowerCase().includes(searchTerm.toLowerCase()) || user.phone_number.toString().includes(searchTerm)
          )
        );
        setCurrentPage(1);
      } catch (error) {
        console.error(error.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchUsers();
  }, [reloadTrigger, searchTerm]);
  useEffect(() => {
    const fetchGroupData = async () => {
      try {
        setGroups((await api.get("group/get-group-admin")).data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchGroupData();
  }, [reloadTrigger]);
  const handleSelectCustomer = (id) => {
    setSelectedCustomers((prev) => {
      if (prev.includes(id)) {
        const newArr = prev.filter((i) => i !== id);
        setLastCheckedId(newArr.length > 0 ? newArr[newArr.length - 1] : null);
        return newArr;
      }
      if (prev.length >= 10) {
        setAlertConfig({
          visibility: true,
          message: "You can select a maximum of 10 customers at a time.",
          type: "warning"
        });
        return prev;
      }
      setLastCheckedId(id);
      return [...prev, id];
    });
  };
  const handleAssignmentChange = (userId, field, value) => {
    setActionAssignments((prev) => {
      const current = prev[userId] || {};
      const updated = { ...current, [field]: value };
      if (field === "status" && value) {
        const prevStatus = current.status;
        const existingRemark = current.remark || "";
        let extraRemark = "";
        if (prevStatus && existingRemark.startsWith(prevStatus)) {
          extraRemark = existingRemark.slice(prevStatus.length).trim();
          extraRemark = extraRemark.replace(/^[-:–—]\s*/, "");
        }
        updated.remark = extraRemark ? `${value} - ${extraRemark}` : value;
      }
      if (field === "status" && value !== "Follow Up") {
        updated.followUpDate = void 0;
      }
      return { ...prev, [userId]: updated };
    });
  };
  const openStatusUpdateModal = (user) => {
    setStatusUpdateData({
      _id: user._id,
      status: user.status || "",
      remark: user.remark || "",
      follow_up_date: user.follow_up_date || ""
    });
    setShowStatusUpdateModal(true);
  };
  const handleStatusUpdateSubmit = async () => {
    const { _id, status, remark, follow_up_date } = statusUpdateData;
    if (!status) {
      setAlertConfig({ visibility: true, message: "Please select a status.", type: "warning" });
      return;
    }
    if (status === "Follow Up" && !follow_up_date) {
      setAlertConfig({ visibility: true, message: "Please select a follow-up date.", type: "warning" });
      return;
    }
    setIsStatusUpdating(true);
    try {
      const payload = {
        status,
        remark: remark || "",
        // keep existing assigned_to if any (optional)
        assigned_to: currentUpdateUser?.assigned_to_id || ""
      };
      if (status === "Follow Up" && follow_up_date) {
        payload.follow_up_date = follow_up_date;
      }
      await api.put(`/v1/admin/users/users-unverified/${_id}`, payload);
      setAlertConfig({ visibility: true, message: "Status updated successfully!", type: "success" });
      setShowStatusUpdateModal(false);
      setReloadTrigger((prev) => prev + 1);
    } catch (error) {
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to update status.",
        type: "error"
      });
    } finally {
      setIsStatusUpdating(false);
    }
  };
  const handleBulkActionSubmit = async () => {
    for (const id of selectedCustomers) {
      const assign = actionAssignments[id];
      if (!assign?.adminId) {
        return setAlertConfig({
          visibility: true,
          message: "Please assign an admin to all customers.",
          type: "warning"
        });
      }
      if (!assign?.status) {
        return setAlertConfig({
          visibility: true,
          message: "Please select a status for all customers.",
          type: "warning"
        });
      }
      if (assign.status === "Follow Up" && !assign.followUpDate) {
        return setAlertConfig({
          visibility: true,
          message: "Please select a follow-up date for customers with 'Follow Up' status.",
          type: "warning"
        });
      }
    }
    setIsSubmitting(true);
    try {
      const promises = selectedCustomers.map((id) => {
        const assign = actionAssignments[id];
        const payload = {
          status: assign.status,
          remark: assign.remark || "",
          assigned_to: assign.adminId
        };
        if (assign.status === "Follow Up" && assign.followUpDate) {
          payload.follow_up_date = assign.followUpDate;
        }
        return api.put(`/v1/admin/users/users-unverified/${id}`, payload);
      });
      await Promise.all(promises);
      setAlertConfig({
        visibility: true,
        message: "Customers assigned and updated successfully!",
        type: "success"
      });
      setShowActionModal(false);
      setActionAssignments({});
      setSelectedCustomers([]);
      setLastCheckedId(null);
      setReloadTrigger((prev) => prev + 1);
    } catch (error) {
      console.error(error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to update customers",
        type: "error"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((p) => ({ ...p, [field]: value }));
    setErrors((p) => ({ ...p, [field]: "" }));
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((p) => ({ ...p, [name]: value }));
    setErrors((p) => ({ ...p, [name]: "" }));
  };
  const handleDeleteModalOpen = async (id) => {
    setCurrentUser((await api.get(`/user/get-user-by-id/${id}`)).data);
    setShowModalDelete(true);
  };
  const handleUpdateModalOpen = async (id) => {
    const res = (await api.get(`/user/get-user-by-id/${id}`)).data;
    setCurrentUpdateUser(res);
    setUpdateFormData({
      full_name: res?.full_name,
      email: res?.email,
      phone_number: res?.phone_number,
      password: res?.password,
      pincode: res?.pincode,
      adhaar_no: res?.adhaar_no,
      pan_no: res?.pan_no,
      address: res?.address,
      selected_plan: res?.selected_plan?._id || "",
      title: res?.title,
      father_name: res?.father_name,
      gender: res?.gender,
      marital_status: res?.marital_status,
      dateofbirth: res?.dateofbirth?.split("T")[0],
      nationality: res?.nationality,
      village: res?.village,
      taluk: res?.taluk,
      district: res?.district,
      state: res?.state,
      collection_area: res?.collection_area?._id || "",
      alternate_number: res?.alternate_number,
      referral_name: res?.referral_name
    });
    setShowModalUpdate(true);
    setErrors({});
  };
  const handleDeleteUser = async () => {
    if (!currentUser) return;
    try {
      await api.delete(`/user/delete-user/${currentUser._id}`);
      setAlertConfig({ visibility: true, message: "Deleted successfully", type: "success" });
      setReloadTrigger((p) => p + 1);
      setShowModalDelete(false);
    } catch (e) {
      console.error(e);
    }
  };
  const handleCustomerStatus = async (id, status) => {
    try {
      if (id && (await api.put(`/user/update-user/${id}`, { approval_status: status })).status === 200) {
        setReloadTrigger((p) => p + 1);
        setAlertConfig({ visibility: true, message: `Status updated to ${status}`, type: "success" });
      }
    } catch (e) {
      console.error(e);
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const fmData = new FormData();
      Object.entries(updateFormData).forEach(([k, v]) => {
        if (v) fmData.append(k, v);
      });
      await api.put(`/user/update-user/${currentUpdateUser?._id}`, fmData, { headers: { "Content-Type": "multipart/form-data" } });
      setShowModalUpdate(false);
      setReloadTrigger((p) => p + 1);
      setAlertConfig({ visibility: true, message: "User Updated", type: "success" });
      setErrors({});
    } catch (error) {
      if (error.response?.data?.message?.toLowerCase().includes("phone"))
        setErrors((p) => ({ ...p, phone_number: "Phone exists" }));
      else
        setAlertConfig({ type: "error", message: error.response?.data?.message || "Error updating", visibility: true });
    }
  };
  const ActionDropdown = ({ user }) => /* @__PURE__ */ jsxDEV(
    Dropdown,
    {
      trigger: ["click"],
      menu: {
        items: [
          {
            key: "1",
            label: /* @__PURE__ */ jsxDEV("div", { className: "text-violet-600 font-medium cursor-pointer px-2 py-1", onClick: () => handleUpdateModalOpen(user._id), children: "Edit" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 750,
              columnNumber: 9
            }, this)
          },
          {
            key: "2",
            label: /* @__PURE__ */ jsxDEV("div", { className: "text-red-600 font-medium cursor-pointer px-2 py-1", onClick: () => handleDeleteModalOpen(user._id), children: "Delete" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 756,
              columnNumber: 9
            }, this)
          },
          {
            key: "3",
            label: /* @__PURE__ */ jsxDEV("div", { className: "text-gray-700 font-medium cursor-pointer px-2 py-1", onClick: () => handleEnrollmentRequestPrint(user._id), children: "Print" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 762,
              columnNumber: 9
            }, this)
          },
          {
            key: "4",
            label: /* @__PURE__ */ jsxDEV(
              "div",
              {
                className: `font-medium cursor-pointer px-2 py-1 ${user.approval_status !== "Approved" ? "text-emerald-600" : "text-red-600"}`,
                onClick: () => handleCustomerStatus(user._id, user.approval_status !== "Approved" ? "Approved" : "Pending"),
                children: user.approval_status !== "Approved" ? "Approve" : "Unapprove"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 768,
                columnNumber: 9
              },
              this
            )
          }
        ]
      },
      placement: "bottomRight",
      children: /* @__PURE__ */ jsxDEV("button", { className: "p-2 rounded-lg hover:bg-gray-100 transition-colors", children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-gray-500 text-lg" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 781,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 780,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 743,
      columnNumber: 3
    },
    this
  );
  const ContactSummaryDashboard = () => {
    const counts = getStatusCounts();
    const pendingCount = filteredUsers.filter((u) => u.status === "Not Contacted" || !u.status).length;
    const conversionRate = counts.total > 0 ? (counts.Converted / counts.total * 100).toFixed(1) : "0.0";
    const rejectionRate = counts.total > 0 ? (counts.Rejected / counts.total * 100).toFixed(1) : "0.0";
    return /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-sm border border-gray-100 p-5 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl text-white shadow-md shadow-blue-200", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 800,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 799,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 798,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-bold text-gray-900", children: "Contact Summary" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 804,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400", children: "Overview of employee follow-up work" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 805,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 803,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 797,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
          parseFloat(conversionRate) > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-emerald-50 border border-emerald-200 rounded-full px-3 py-1.5", children: [
            /* @__PURE__ */ jsxDEV("svg", { className: "w-3.5 h-3.5 text-emerald-600", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 814,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 813,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-emerald-700", children: [
              conversionRate,
              "% conversion"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 816,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 812,
            columnNumber: 13
          }, this),
          parseFloat(rejectionRate) > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-red-50 border border-red-200 rounded-full px-3 py-1.5", children: [
            /* @__PURE__ */ jsxDEV("svg", { className: "w-3.5 h-3.5 text-red-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M13 17h8m0 0V9m0 8l-8-8-4 4-6-6" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 822,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 821,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-red-600", children: [
              rejectionRate,
              "% rejection"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 824,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 820,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 810,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 796,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-5", children: STATUS_SUMMARY_CONFIG.map((cfg) => {
        const count = counts[cfg.key];
        const percentage = counts.total > 0 ? (count / counts.total * 100).toFixed(0) : 0;
        return /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `relative overflow-hidden rounded-xl border border-gray-100 p-4 hover:shadow-md hover:-translate-y-0.5 transition-all duration-300 group cursor-default ${count === 0 ? "opacity-50" : ""}`,
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: `absolute top-0 right-0 w-20 h-20 rounded-full bg-gradient-to-br ${cfg.color} opacity-[0.07] -translate-y-1/2 translate-x-1/2 group-hover:opacity-[0.12] transition-opacity` }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 841,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
                /* @__PURE__ */ jsxDEV("div", { className: `w-9 h-9 rounded-lg ${cfg.bgLight} ${cfg.iconColor} flex items-center justify-center mb-3 ring-1 ${cfg.ringColor}`, children: cfg.icon }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 844,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-extrabold text-gray-900 leading-none mb-1", children: count }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 847,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500 mb-2", children: cfg.label }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 850,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-full h-1.5 bg-gray-100 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: `h-full rounded-full bg-gradient-to-r ${cfg.color} transition-all duration-700 ease-out`,
                    style: { width: `${percentage}%` }
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 856,
                    columnNumber: 21
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 855,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-semibold text-gray-400 mt-1 text-right", children: [
                  percentage,
                  "%"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 861,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 843,
                columnNumber: 17
              }, this)
            ]
          },
          cfg.key,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 836,
            columnNumber: 15
          },
          this
        );
      }) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 831,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 pt-4 border-t border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 bg-slate-50 rounded-xl px-4 py-2.5 border border-slate-200/60", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-lg bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center text-white shadow-sm", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 11a3 3 0 11-6 0 3 3 0 016 0z" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 876,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 875,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 874,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-extrabold text-gray-900 leading-none", children: counts.total }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 880,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 font-medium", children: "Total Processed" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 881,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 879,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 873,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 bg-amber-50 rounded-xl px-4 py-2.5 border border-amber-200/60", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-orange-500 flex items-center justify-center text-white shadow-sm", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 889,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 888,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 887,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-extrabold text-amber-700 leading-none", children: pendingCount }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 893,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-amber-600 font-medium", children: "Still Pending" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 894,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 892,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 886,
          columnNumber: 11
        }, this),
        counts["Follow Up"] > 0 && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 bg-purple-50 rounded-xl px-4 py-2.5 border border-purple-200/60", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center text-white shadow-sm", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 903,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 902,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 901,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-extrabold text-purple-700 leading-none", children: counts["Follow Up"] }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 907,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-purple-600 font-medium", children: "Follow Ups Due" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 908,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 906,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 900,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5 ml-auto", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-extrabold text-gray-900 leading-none", children: [
              filteredUsers.length > 0 ? (counts.total / filteredUsers.length * 100).toFixed(1) : "0.0",
              "%"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 916,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 font-medium", children: "Process Rate" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 922,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 915,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative w-12 h-12", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-12 h-12 -rotate-90", viewBox: "0 0 36 36", children: [
            /* @__PURE__ */ jsxDEV(
              "path",
              {
                d: "M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831",
                fill: "none",
                stroke: "#f1f5f9",
                strokeWidth: "3"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 926,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "path",
              {
                d: "M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831",
                fill: "none",
                stroke: "url(#progressGradient)",
                strokeWidth: "3",
                strokeDasharray: `${filteredUsers.length > 0 ? counts.total / filteredUsers.length * 100 : 0}, 100`,
                strokeLinecap: "round"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 932,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("defs", { children: /* @__PURE__ */ jsxDEV("linearGradient", { id: "progressGradient", x1: "0%", y1: "0%", x2: "100%", y2: "0%", children: [
              /* @__PURE__ */ jsxDEV("stop", { offset: "0%", stopColor: "#6366f1" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 942,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("stop", { offset: "100%", stopColor: "#3b82f6" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 943,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 941,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 940,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 925,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 924,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 914,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 871,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 794,
      columnNumber: 7
    }, this);
  };
  const renderCustomerCard = (customer) => {
    const isPending = customer.status === "Not Contacted" || !customer.status;
    if (activeTab === "pending" && !isPending) return null;
    if (activeTab === "contacted" && isPending) return null;
    const isSelected = selectedCustomers.includes(customer._id);
    const isLastChecked = isSelected && lastCheckedId === customer._id;
    if (activeTab === "contacted") {
      return /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "group relative bg-white rounded-2xl border border-blue-200 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 left-0 w-full h-1.5 rounded-t-2xl bg-gradient-to-r from-blue-500 to-indigo-500 opacity-90" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 969,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "p-5 pt-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 min-w-0", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-sm flex-shrink-0", children: customer.name?.charAt(0)?.toUpperCase() }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 973,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "min-w-0", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-gray-900 truncate text-lg", children: customer.name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 977,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400", children: customer.customer_id }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 978,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 976,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 972,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => openStatusUpdateModal(customer),
                      className: "p-1.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-400 hover:text-blue-600",
                      title: "Update Status",
                      children: /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                        lineNumber: 989,
                        columnNumber: 21
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                        lineNumber: 988,
                        columnNumber: 19
                      }, this)
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 983,
                      columnNumber: 17
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(ActionDropdown, { user: customer }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 992,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 981,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 971,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3 mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2.5", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider", children: "Phone" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 998,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-0.5", children: customer.phone_number }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 999,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 997,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2.5", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider", children: "Joined" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1002,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-0.5", children: customer.createdAt }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1003,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1001,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 996,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-slate-50 to-blue-50/50 rounded-xl border border-slate-200/80 p-4 space-y-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-xs font-bold text-slate-500 uppercase tracking-wider", children: [
                  /* @__PURE__ */ jsxDEV("svg", { className: "w-3.5 h-3.5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1011,
                    columnNumber: 19
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1010,
                    columnNumber: 17
                  }, this),
                  "Work Status"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1009,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold ${getStatusColor(customer.status)}`, children: [
                    getStatusIcon(customer.status),
                    customer.status
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1017,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold ${getStatusColor(customer.approval_status)}`, children: customer.approval_status }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1021,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1016,
                  columnNumber: 15
                }, this),
                customer.remark && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg border border-slate-200 p-3", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1", children: "Remark" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1028,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-700 leading-relaxed", children: customer.remark }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1029,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1027,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
                  customer.assigned_to && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg border border-slate-200 p-2.5", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5", children: "Assigned To" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1036,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "w-5 h-5 rounded-full bg-indigo-100 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold text-indigo-600", children: customer.assigned_to?.charAt(0)?.toUpperCase() }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                        lineNumber: 1039,
                        columnNumber: 25
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                        lineNumber: 1038,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-indigo-700 truncate", children: customer.assigned_to }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                        lineNumber: 1041,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1037,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1035,
                    columnNumber: 17
                  }, this),
                  customer.follow_up_date && /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg border border-purple-200 p-2.5", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[10px] font-bold text-purple-400 uppercase tracking-wider mb-0.5", children: "Follow Up Date" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1047,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5", children: [
                      /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4 text-purple-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                        lineNumber: 1050,
                        columnNumber: 25
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                        lineNumber: 1049,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-purple-700", children: customer.follow_up_date }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                        lineNumber: 1052,
                        columnNumber: 23
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1048,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1046,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1033,
                  columnNumber: 15
                }, this),
                customer.status_updated_at && /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-slate-400 text-right", children: [
                  "Last updated: ",
                  customer.status_updated_at
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1059,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1008,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 970,
              columnNumber: 11
            }, this)
          ]
        },
        customer._id,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 965,
          columnNumber: 9
        },
        this
      );
    }
    return /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `group relative bg-white rounded-2xl border transition-all duration-300 hover:shadow-xl hover:-translate-y-1 ${isSelected ? "border-violet-400 ring-2 ring-violet-100 shadow-lg" : "border-gray-200 shadow-sm"}`,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 left-0 w-full h-1.5 rounded-t-2xl bg-gradient-to-r from-amber-400 to-orange-500 opacity-80" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1074,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "p-5 pt-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-start justify-between mb-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 min-w-0", children: [
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: isSelected,
                    onChange: () => handleSelectCustomer(customer._id),
                    className: "w-4 h-4 text-violet-600 border-gray-300 rounded focus:ring-violet-500 flex-shrink-0"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1078,
                    columnNumber: 15
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-gray-900 truncate text-lg", children: customer.name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1084,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1077,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(ActionDropdown, { user: customer }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1086,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1076,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3 mb-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2.5", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider", children: "Phone" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1091,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-0.5", children: customer.phone_number }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1092,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1090,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-2.5", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-semibold text-gray-400 uppercase tracking-wider", children: "ID" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1095,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-0.5 truncate", children: customer.customer_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1096,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1094,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1089,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between text-xs text-gray-500 border-t border-gray-100 pt-3 mt-1", children: [
              /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center px-2.5 py-1 rounded-full font-medium ${getStatusColor(customer.approval_status)}`, children: customer.approval_status }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1101,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV("svg", { className: "w-3.5 h-3.5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1106,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1105,
                  columnNumber: 15
                }, this),
                customer.createdAt
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1104,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1100,
              columnNumber: 11
            }, this),
            isLastChecked && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 pt-4 border-t border-gray-100", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowActionModal(true),
                className: "w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-sm font-semibold rounded-xl hover:from-blue-700 hover:to-indigo-700 shadow-md shadow-blue-200 transition-all active:scale-[0.98]",
                children: [
                  /* @__PURE__ */ jsxDEV(MdAssignmentInd, { className: "text-lg" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1118,
                    columnNumber: 17
                  }, this),
                  "View & Update (",
                  selectedCustomers.length,
                  ")"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1114,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1113,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1075,
            columnNumber: 9
          }, this)
        ]
      },
      customer._id,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1069,
        columnNumber: 7
      },
      this
    );
  };
  const UserRow = ({ user }) => {
    const isPending = user.status === "Not Contacted" || !user.status;
    if (activeTab === "pending" && !isPending) return null;
    if (activeTab === "contacted" && isPending) return null;
    const isSelected = selectedCustomers.includes(user._id);
    const isLastChecked = isSelected && lastCheckedId === user._id;
    if (activeTab === "contacted") {
      return /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "group bg-white rounded-xl border border-blue-200 shadow-sm hover:shadow-lg hover:border-blue-300 transition-all duration-300 overflow-hidden",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 w-full sm:w-auto", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-sm flex-shrink-0", children: user.name?.charAt(0)?.toUpperCase() }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1144,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1 flex-wrap", children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-900 truncate", children: user.name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1149,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold ${getStatusColor(user.status)}`, children: [
                      getStatusIcon(user.status),
                      user.status
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1150,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold ${getStatusColor(user.approval_status)}`, children: user.approval_status }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1154,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1148,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 truncate", children: user.address || "No address provided" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1158,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1147,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1143,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 ml-0 sm:ml-auto w-full sm:w-auto", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-50 px-3 py-1.5 rounded-lg text-center min-w-[100px]", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-violet-500 font-medium", children: "Phone" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1164,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-violet-900", children: user.phone_number }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1165,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1163,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV(ActionDropdown, { user }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1168,
                  columnNumber: 17
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1167,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1162,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1142,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-slate-50 to-blue-50/40 border-t border-slate-200 px-4 py-3", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 text-xs", children: [
              user.remark && /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2 flex-1 min-w-[200px]", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-slate-400 uppercase tracking-wider flex-shrink-0 mt-0.5", children: "Remark:" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1177,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 leading-relaxed", children: user.remark }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1178,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1176,
                columnNumber: 15
              }, this),
              user.assigned_to && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-white rounded-full px-3 py-1.5 border border-indigo-100", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-5 h-5 rounded-full bg-indigo-100 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold text-indigo-600", children: user.assigned_to?.charAt(0)?.toUpperCase() }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1184,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1183,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-indigo-700", children: user.assigned_to }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1186,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1182,
                columnNumber: 15
              }, this),
              user.follow_up_date && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-white rounded-full px-3 py-1.5 border border-purple-100", children: [
                /* @__PURE__ */ jsxDEV("svg", { className: "w-3.5 h-3.5 text-purple-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1192,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1191,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-purple-700", children: user.follow_up_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1194,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1190,
                columnNumber: 15
              }, this),
              user.status_updated_at && /* @__PURE__ */ jsxDEV("span", { className: "text-slate-400 ml-auto", children: [
                "Updated: ",
                user.status_updated_at
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1198,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1174,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1173,
              columnNumber: 11
            }, this)
          ]
        },
        user._id,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1138,
          columnNumber: 9
        },
        this
      );
    }
    return /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `group bg-white rounded-xl border flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 transition-all duration-300 hover:shadow-lg hover:border-gray-300 ${isSelected ? "border-violet-400 ring-2 ring-violet-100" : "border-gray-100 shadow-sm"}`,
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 w-full sm:w-auto", children: [
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "checkbox",
                checked: isSelected,
                onChange: () => handleSelectCustomer(user._id),
                className: "w-4 h-4 text-violet-600 border-gray-300 rounded focus:ring-violet-500 flex-shrink-0"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1213,
                columnNumber: 11
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { className: "min-w-0 flex-1", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-1", children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-900 truncate", children: user.name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1221,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: `inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold ${getStatusColor(user.approval_status)}`, children: user.approval_status }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1222,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1220,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 truncate", children: user.address || "No address provided" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1226,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1219,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1212,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 ml-8 sm:ml-0 w-full sm:w-auto", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-50 px-3 py-1.5 rounded-lg text-center min-w-[100px]", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-violet-500 font-medium", children: "Phone" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1232,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-violet-900", children: user.phone_number }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1233,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1231,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 px-3 py-1.5 rounded-lg text-center min-w-[90px] border border-gray-100", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 font-medium", children: "Joined" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1236,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-gray-700", children: user.createdAt }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1237,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1235,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0 ml-auto sm:ml-0", children: /* @__PURE__ */ jsxDEV(ActionDropdown, { user }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1240,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1239,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1230,
            columnNumber: 9
          }, this),
          isLastChecked && /* @__PURE__ */ jsxDEV("div", { className: "w-full mt-4 pt-4 border-t border-gray-100 flex justify-end", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setShowActionModal(true),
              className: "flex items-center justify-center gap-2 px-5 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-sm font-semibold rounded-xl hover:from-blue-700 hover:to-indigo-700 shadow-md shadow-blue-200 transition-all active:scale-[0.98]",
              children: [
                /* @__PURE__ */ jsxDEV(MdAssignmentInd, { className: "text-lg" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1250,
                  columnNumber: 15
                }, this),
                "Assign & Update (",
                selectedCustomers.length,
                ")"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1246,
              columnNumber: 13
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1245,
            columnNumber: 9
          }, this)
        ]
      },
      user._id,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1207,
        columnNumber: 7
      },
      this
    );
  };
  const renderUsers = () => {
    if (isLoading)
      return /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading, failure: false, data: "Customer Data" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1262,
        columnNumber: 12
      }, this);
    const tabFilteredUsers = getTabFilteredUsers();
    const tabIndexOfLastItem = currentPage * itemsPerPage;
    const tabIndexOfFirstItem = tabIndexOfLastItem - itemsPerPage;
    const tabCurrentItems = tabFilteredUsers.slice(tabIndexOfFirstItem, tabIndexOfLastItem);
    const tabTotalPages = Math.ceil(tabFilteredUsers.length / itemsPerPage);
    if (!tabFilteredUsers.length)
      return /* @__PURE__ */ jsxDEV("div", { className: "col-span-full py-20 bg-white rounded-2xl shadow-sm text-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-gray-300 mx-auto mb-4", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-16 h-16 mx-auto", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "1.5", d: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 11a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1275,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1274,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1273,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold text-gray-600", children: activeTab === "pending" ? "No pending customers found" : "No contacted customers found" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1278,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400 mt-1", children: activeTab === "pending" ? "All customers have been contacted" : "Try switching to the Pending tab or adjust your search" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1281,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1272,
        columnNumber: 7
      }, this);
    if (viewMode === "grid")
      return /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6", children: tabCurrentItems.map(renderCustomerCard) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1289,
        columnNumber: 7
      }, this);
    if (viewMode === "list")
      return /* @__PURE__ */ jsxDEV("div", { className: "space-y-3", children: tabCurrentItems.map(
        (u) => /* @__PURE__ */ jsxDEV(UserRow, { user: u }, u.id, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1297,
          columnNumber: 9
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1295,
        columnNumber: 7
      }, this);
    return /* @__PURE__ */ jsxDEV("div", { className: "w-full overflow-hidden rounded-2xl border border-gray-200 shadow-sm bg-white", children: /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        catcher: "_id",
        data: TableUsers.filter(
          (u) => activeTab === "contacted" ? u.statusRaw && u.statusRaw !== "Not Contacted" : !u.statusRaw || u.statusRaw === "Not Contacted"
        ),
        columns,
        exportedPdfName: "UnApproved",
        exportedFileName: "UnApproved.csv"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1303,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 1302,
      columnNumber: 7
    }, this);
  };
  const SimplePagination = ({ currentPage: currentPage2, totalPages: totalPages2, onPageChange }) => {
    if (totalPages2 <= 1) return null;
    const pages = [];
    const max = 5;
    pages.push(1);
    if (totalPages2 > max) {
      if (currentPage2 > 3) pages.push("...");
      for (let i = Math.max(2, currentPage2 - 1); i <= Math.min(totalPages2 - 1, currentPage2 + 1); i++) {
        if (i !== 1 && i !== totalPages2) pages.push(i);
      }
      if (currentPage2 < totalPages2 - 2) pages.push("...");
    } else {
      for (let i = 2; i <= totalPages2; i++) pages.push(i);
    }
    if (totalPages2 > 1) pages.push(totalPages2);
    return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-1.5 mt-8", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => onPageChange(currentPage2 - 1),
          disabled: currentPage2 === 1,
          className: "px-3.5 py-2 text-sm font-medium text-gray-600 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 hover:shadow-sm disabled:opacity-40 disabled:cursor-not-allowed transition-all",
          children: "Prev"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1335,
          columnNumber: 9
        },
        this
      ),
      pages.map(
        (page, i) => /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => typeof page === "number" && onPageChange(page),
            disabled: typeof page !== "number",
            className: `w-10 h-10 text-sm font-medium rounded-lg transition-all ${page === currentPage2 ? "bg-violet-600 text-white shadow-md shadow-violet-200" : typeof page === "number" ? "bg-white text-gray-700 border border-gray-200 hover:bg-gray-50 hover:shadow-sm" : "bg-white text-gray-400 border border-gray-200 cursor-default"}`,
            children: page
          },
          i,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1343,
            columnNumber: 9
          },
          this
        )
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => onPageChange(currentPage2 + 1),
          disabled: currentPage2 === totalPages2,
          className: "px-3.5 py-2 text-sm font-medium text-gray-600 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 hover:shadow-sm disabled:opacity-40 disabled:cursor-not-allowed transition-all",
          children: "Next"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1357,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 1334,
      columnNumber: 7
    }, this);
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: `flex overflow-x-hidden ${!hideSidebar ? "mt-20" : "mt-2"}`, children: [
      !hideSidebar && /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1371,
        columnNumber: 26
      }, this),
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: false }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1373,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((p) => ({ ...p, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1374,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0 p-4 lg:p-6 bg-slate-50 min-h-screen overflow-x-hidden", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1382,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-sm border border-gray-100 p-5 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-900 tracking-tight", children: "Unverified Customers" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1388,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Manage and follow up on pending enrollments" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1389,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1387,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-3 w-full lg:w-auto", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex bg-slate-100 rounded-xl p-1 gap-1", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setActiveTab("pending"),
                    className: `px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === "pending" ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-800"}`,
                    children: [
                      "Pending (",
                      filteredUsers.filter((u) => u.status === "Not Contacted" || !u.status).length,
                      ")"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1394,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setActiveTab("contacted"),
                    className: `px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === "contacted" ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-800"}`,
                    children: [
                      "Contacted (",
                      filteredUsers.filter((u) => u.status && u.status !== "Not Contacted").length,
                      ")"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1401,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1393,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 bg-slate-100 rounded-xl p-1", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setViewMode("grid"),
                    className: `p-2 rounded-lg transition-all ${viewMode === "grid" ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-800"}`,
                    children: /* @__PURE__ */ jsxDEV(MdGridView, { className: "text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1415,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1411,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setViewMode("list"),
                    className: `p-2 rounded-lg transition-all ${viewMode === "list" ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-800"}`,
                    children: /* @__PURE__ */ jsxDEV(MdViewList, { className: "text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1421,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1417,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setViewMode("table"),
                    className: `p-2 rounded-lg transition-all ${viewMode === "table" ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-800"}`,
                    children: /* @__PURE__ */ jsxDEV(MdOutlineTableRows, { className: "text-lg" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1427,
                      columnNumber: 21
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1423,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1410,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1392,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1386,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-5", children: [
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                placeholder: "Search by name or phone",
                value: searchQuery,
                allowClear: true,
                onChange: (e) => {
                  const val = e.target.value;
                  setSearchQuery(val);
                  if (val === "") {
                    setSearchTerm("");
                  }
                },
                onPressEnter: () => setSearchTerm(searchQuery),
                className: "h-10 w-80 rounded-lg border-gray-300 focus:border-violet-500 focus:ring-2 focus:ring-violet-200"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1433,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                icon: /* @__PURE__ */ jsxDEV(SearchOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1449,
                  columnNumber: 23
                }, this),
                onClick: () => setSearchTerm(searchQuery),
                className: "h-10 bg-violet-600 hover:bg-violet-700 border-violet-600 flex items-center justify-center",
                children: "Search"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1447,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1432,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1385,
          columnNumber: 11
        }, this),
        activeTab === "contacted" && !isLoading && /* @__PURE__ */ jsxDEV(ContactSummaryDashboard, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1460,
          columnNumber: 55
        }, this),
        renderUsers(),
        viewMode !== "table" && getTabFilteredUsers().length > itemsPerPage && /* @__PURE__ */ jsxDEV(
          SimplePagination,
          {
            currentPage,
            totalPages: Math.ceil(getTabFilteredUsers().length / itemsPerPage),
            onPageChange: handlePageChange
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1465,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1381,
        columnNumber: 10
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 1370,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showActionModal,
        onClose: () => {
          setShowActionModal(false);
          setActionAssignments({});
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-6 text-left max-h-[85vh] overflow-y-auto pr-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-2.5 bg-blue-100 rounded-xl text-blue-600", children: /* @__PURE__ */ jsxDEV(MdAssignmentInd, { className: "w-6 h-6" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1485,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1484,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: "Assign & Update Status" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1488,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: [
                "You are assigning",
                " ",
                /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-blue-600", children: selectedCustomers.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1491,
                  columnNumber: 17
                }, this),
                " customer(s). Select admin, status, and add remarks for each."
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1489,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1487,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1483,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-4 max-h-[55vh] overflow-y-auto pr-2 custom-scrollbar", children: selectedCustomers.map((id, index) => {
            const user = filteredUsers.find((u) => u._id === id);
            if (!user) return null;
            const currentAssign = actionAssignments[id] || {};
            const preFilledAdmin = currentAssign.adminId || user.assigned_to_id || void 0;
            return /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl border border-slate-200 p-4 hover:shadow-sm transition-shadow", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-100", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold text-sm", children: index + 1 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1507,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-900", children: user.name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1511,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500", children: user.phone_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1512,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1510,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1506,
                  columnNumber: 21
                }, this),
                user.assigned_to ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-indigo-50 px-3 py-1 rounded-lg self-start", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-4 h-4 rounded-full bg-indigo-200 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-[8px] font-bold text-indigo-700", children: user.assigned_to?.charAt(0)?.toUpperCase() }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1518,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1517,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-indigo-700", children: user.assigned_to }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1520,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1516,
                  columnNumber: 21
                }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-1.5 bg-red-50 px-3 py-1 rounded-lg self-start", children: [
                  /* @__PURE__ */ jsxDEV("svg", { className: "w-3.5 h-3.5 text-red-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1525,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1524,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-semibold text-red-600", children: "Unassigned" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1527,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1523,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1505,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider", children: [
                    "Admin ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1535,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1534,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      showSearch: true,
                      placeholder: "Select Admin",
                      value: preFilledAdmin || void 0,
                      onChange: (value) => handleAssignmentChange(id, "adminId", value),
                      className: "w-full h-11",
                      filterOption: (input, option) => (option?.label ?? "").toLowerCase().includes(input.toLowerCase()),
                      options: admins.map((admin) => ({ label: admin.full_name || admin.name, value: admin._id }))
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1537,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1533,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider", children: [
                    "Status ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1550,
                      columnNumber: 32
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1549,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      placeholder: "Select Status",
                      value: currentAssign.status || void 0,
                      onChange: (value) => handleAssignmentChange(id, "status", value),
                      className: "w-full h-11",
                      options: STATUS_OPTIONS.map((opt) => ({ label: opt, value: opt }))
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1552,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1548,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider", children: [
                    "Remark",
                    " ",
                    currentAssign.status && /* @__PURE__ */ jsxDEV("span", { className: "text-blue-500 font-normal normal-case tracking-normal ml-1", children: "(auto-filled with status)" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1565,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1562,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input.TextArea,
                    {
                      rows: 2,
                      placeholder: currentAssign.status ? `"${currentAssign.status}" — add extra details here...` : "Select a status first...",
                      value: currentAssign.remark || "",
                      onChange: (e) => handleAssignmentChange(id, "remark", e.target.value),
                      className: "w-full resize-none rounded-lg border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1568,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1561,
                  columnNumber: 21
                }, this),
                currentAssign.status === "Follow Up" && /* @__PURE__ */ jsxDEV("div", { className: "md:col-span-2", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-xs font-bold text-purple-600 uppercase tracking-wider", children: [
                    "Follow Up Date ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1580,
                      columnNumber: 42
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1579,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    DatePicker,
                    {
                      value: currentAssign.followUpDate ? dayjs(currentAssign.followUpDate) : null,
                      onChange: (_, dateString) => handleAssignmentChange(id, "followUpDate", dateString),
                      className: "w-full h-11 rounded-lg border-purple-300 hover:border-purple-400 focus:border-purple-500",
                      format: "YYYY-MM-DD",
                      placeholder: "Select follow-up date",
                      disabledDate: (current) => current && current < dayjs().startOf("day")
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                      lineNumber: 1582,
                      columnNumber: 25
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-purple-500 mt-1", children: "Select a future date for the follow-up" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                    lineNumber: 1590,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1578,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1532,
                columnNumber: 19
              }, this),
              !currentAssign.status && user.remark && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 pt-3 border-t border-dashed border-slate-200", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1", children: "Previous Remark" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1597,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-500 bg-slate-50 rounded-lg p-2", children: user.remark }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1598,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1596,
                columnNumber: 19
              }, this)
            ] }, id, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1504,
              columnNumber: 17
            }, this);
          }) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1496,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 mt-6 pt-4 border-t border-slate-200", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "default",
                onClick: () => {
                  setShowActionModal(false);
                  setActionAssignments({});
                },
                className: "h-11 px-6 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-xl font-medium",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1607,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                loading: isSubmitting,
                onClick: handleBulkActionSubmit,
                className: "h-11 px-6 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold rounded-xl shadow-md shadow-blue-200 transition-all",
                children: "Submit"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1617,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1606,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1482,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1475,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModalUpdate, onClose: () => setShowModalUpdate(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-6 text-left max-h-[85vh] overflow-y-auto pr-2", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900 mb-6", children: "Update Customer Details" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1632,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-5", onSubmit: handleUpdate, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-sm font-semibold text-gray-700", children: "Title" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1636,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { placeholder: "Select", value: updateFormData?.title || void 0, onChange: (v) => handleAntInputDSelect("title", v), className: "w-full h-11", children: ["Mr", "Ms", "Mrs", "M/S", "Dr"].map(
              (t) => /* @__PURE__ */ jsxDEV(Select.Option, { value: t, children: t }, t, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1639,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1637,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1635,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-sm font-semibold text-gray-700", children: [
              "Full Name ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1644,
                columnNumber: 95
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1644,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { name: "full_name", value: updateFormData?.full_name, onChange: handleInputChange, required: true, className: "h-11 rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1645,
              columnNumber: 17
            }, this),
            errors.full_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-500", children: errors.full_name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1646,
              columnNumber: 38
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1643,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-sm font-semibold text-gray-700", children: "Email" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1649,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { type: "email", name: "email", value: updateFormData?.email, onChange: handleInputChange, className: "h-11 rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1650,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1648,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-sm font-semibold text-gray-700", children: [
              "Phone ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1653,
                columnNumber: 91
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1653,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { type: "number", name: "phone_number", value: updateFormData?.phone_number, onChange: handleInputChange, required: true, className: "h-11 rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1654,
              columnNumber: 17
            }, this),
            errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-500", children: errors.phone_number }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1655,
              columnNumber: 41
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1652,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-sm font-semibold text-gray-700", children: [
              "Aadhar ",
              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1658,
                columnNumber: 92
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1658,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { name: "adhaar_no", value: updateFormData?.adhaar_no, onChange: handleInputChange, required: true, className: "h-11 rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1659,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1657,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-sm font-semibold text-gray-700", children: "PAN" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1662,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { name: "pan_no", value: updateFormData?.pan_no, onChange: handleInputChange, className: "h-11 rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1663,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1661,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1634,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-sm font-semibold text-gray-700", children: [
            "Address ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1667,
              columnNumber: 91
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1667,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Input, { name: "address", value: updateFormData?.address, onChange: handleInputChange, required: true, className: "h-11 rounded-lg" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1668,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1666,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-5", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-sm font-semibold text-gray-700", children: "Pincode" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1672,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { name: "pincode", value: updateFormData?.pincode, onChange: handleInputChange, className: "h-11 rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1673,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1671,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-sm font-semibold text-gray-700", children: "Father's Name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1676,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { name: "father_name", value: updateFormData?.father_name, onChange: handleInputChange, className: "h-11 rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1677,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1675,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-sm font-semibold text-gray-700", children: "Gender" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1680,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Select, { placeholder: "Select", value: updateFormData?.gender || void 0, onChange: (v) => handleAntInputDSelect("gender", v), className: "w-full h-11", children: ["Male", "Female"].map(
              (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g, children: g }, g, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1683,
                columnNumber: 19
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1681,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1679,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-sm font-semibold text-gray-700", children: "DOB" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1688,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Input, { type: "date", name: "dateofbirth", value: updateFormData?.dateofbirth, onChange: handleInputChange, className: "h-11 rounded-lg" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1689,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1687,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1670,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 pt-4 border-t border-gray-100 mt-6", children: [
          /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setShowModalUpdate(false), className: "px-5 py-2.5 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-xl text-sm font-medium transition-colors", children: "Cancel" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1693,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("button", { type: "submit", className: "px-5 py-2.5 text-white bg-violet-600 hover:bg-violet-700 rounded-xl text-sm font-medium shadow-sm shadow-violet-200 transition-all", children: "Update Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1694,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1692,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1633,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 1631,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 1630,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModalDelete, onClose: () => setShowModalDelete(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-6 text-left", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-red-100 rounded-xl text-red-600", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-6 h-6", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1706,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1705,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1704,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: "Delete Customer" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1709,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1703,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mb-6 pl-11", children: [
        "Are you sure you want to delete ",
        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-900", children: currentUser?.full_name }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1712,
          columnNumber: 45
        }, this),
        "? This action cannot be undone."
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1711,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 pl-11", children: [
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => setShowModalDelete(false), className: "px-5 py-2.5 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-xl text-sm font-medium transition-colors", children: "Cancel" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1715,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: handleDeleteUser, className: "px-5 py-2.5 text-white bg-red-600 hover:bg-red-700 rounded-xl text-sm font-medium shadow-sm shadow-red-200 transition-all", children: "Delete Forever" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1716,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1714,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 1702,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
      lineNumber: 1701,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showStatusUpdateModal,
        onClose: () => setShowStatusUpdateModal(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-6 text-left max-h-[85vh] overflow-y-auto pr-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-2.5 bg-blue-100 rounded-xl text-blue-600", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-6 h-6", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1730,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1729,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1728,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: "Update Status" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1734,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500", children: "Change the contact status and remark for this customer." }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1735,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1733,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1727,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider", children: [
                "Status ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1742,
                  columnNumber: 24
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1741,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  placeholder: "Select Status",
                  value: statusUpdateData.status || void 0,
                  onChange: (value) => setStatusUpdateData((prev) => ({ ...prev, status: value })),
                  className: "w-full h-11",
                  options: STATUS_OPTIONS.map((opt) => ({ label: opt, value: opt }))
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1744,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1740,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-xs font-bold text-slate-500 uppercase tracking-wider", children: "Remark" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1754,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input.TextArea,
                {
                  rows: 3,
                  placeholder: "Add a remark...",
                  value: statusUpdateData.remark,
                  onChange: (e) => setStatusUpdateData((prev) => ({ ...prev, remark: e.target.value })),
                  className: "w-full resize-none rounded-lg border-slate-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1757,
                  columnNumber: 15
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1753,
              columnNumber: 13
            }, this),
            statusUpdateData.status === "Follow Up" && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-1.5 text-xs font-bold text-purple-600 uppercase tracking-wider", children: [
                "Follow Up Date ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1769,
                  columnNumber: 34
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1768,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                DatePicker,
                {
                  value: statusUpdateData.follow_up_date ? dayjs(statusUpdateData.follow_up_date) : null,
                  onChange: (_, dateString) => setStatusUpdateData((prev) => ({ ...prev, follow_up_date: dateString })),
                  className: "w-full h-11 rounded-lg border-purple-300 hover:border-purple-400 focus:border-purple-500",
                  format: "YYYY-MM-DD",
                  placeholder: "Select follow-up date",
                  disabledDate: (current) => current && current < dayjs().startOf("day")
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                  lineNumber: 1771,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-purple-500 mt-1", children: "Select a future date for the follow-up" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1779,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
              lineNumber: 1767,
              columnNumber: 13
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1739,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3 mt-6 pt-4 border-t border-slate-200", children: [
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "default",
                onClick: () => setShowStatusUpdateModal(false),
                className: "h-11 px-6 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-xl font-medium",
                children: "Cancel"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1785,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                loading: isStatusUpdating,
                onClick: handleStatusUpdateSubmit,
                className: "h-11 px-6 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold rounded-xl shadow-md shadow-blue-200 transition-all",
                children: "Update Status"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
                lineNumber: 1792,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
            lineNumber: 1784,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
          lineNumber: 1726,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
        lineNumber: 1722,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx",
    lineNumber: 1369,
    columnNumber: 5
  }, this);
};
_s(UnApprovedCustomer, "O81QBzA0R9uB/60OmyEYoNBbjVc=");
_c = UnApprovedCustomer;
export default UnApprovedCustomer;
var _c;
$RefreshReg$(_c, "UnApprovedCustomer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnApprovedCustomer.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOENRLFNBMHlDSixVQTF5Q0k7MkJBOUNSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsT0FBT0MsUUFBUUMsVUFBVUMsUUFBUUMsa0JBQWtCO0FBQzVELFNBQVNDLGdCQUFnQjtBQUN6QjtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUCxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0Msa0NBQWtDO0FBQ3pDLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0Msc0JBQXNCO0FBRy9CLE1BQU1DLGlCQUFpQjtBQUFBLEVBQ3JCO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFVO0FBS1osTUFBTUMsd0JBQXdCO0FBQUEsRUFDNUI7QUFBQSxJQUNFQyxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsTUFDRSx1QkFBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsMk5BQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNFIsS0FEOVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFUCxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsTUFDRSx1QkFBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsNldBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOGEsS0FEaGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFUCxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsTUFDRSx1QkFBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsaURBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0gsS0FEcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFUCxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsTUFDRSx1QkFBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsbURBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0gsS0FEdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFBLEVBQ0E7QUFBQSxJQUNFUCxLQUFLO0FBQUEsSUFDTEMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYQyxXQUFXO0FBQUEsSUFDWEMsTUFDRSx1QkFBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsMEVBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkksS0FEN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFSjtBQUFDO0FBR0gsTUFBTUMscUJBQXFCQSxDQUFDLEVBQUVDLGNBQWMsTUFBTSxNQUFNO0FBQUFDLEtBQUE7QUFDdEQsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUl0QyxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDdUMsZUFBZUMsZ0JBQWdCLElBQUl4QyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDeUMsWUFBWUMsYUFBYSxJQUFJMUMsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzJDLFdBQVdDLFlBQVksSUFBSTVDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUM2QyxpQkFBaUJDLGtCQUFrQixJQUFJOUMsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQytDLGlCQUFpQkMsa0JBQWtCLElBQUloRCxTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDaUQsYUFBYUMsY0FBYyxJQUFJbEQsU0FBUyxJQUFJO0FBQ25ELFFBQU0sQ0FBQ21ELFdBQVdDLFlBQVksSUFBSXBELFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNxRCxjQUFjQyxlQUFlLElBQUl0RCxTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDdUQsbUJBQW1CQyxvQkFBb0IsSUFBSXhELFNBQVMsSUFBSTtBQUMvRCxRQUFNLENBQUN5RCxlQUFlQyxnQkFBZ0IsSUFBSTFELFNBQVMsQ0FBQyxDQUFDO0FBQ3JELFFBQU0sQ0FBQzJELFFBQVFDLFNBQVMsSUFBSTVELFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUM2RCxRQUFRQyxTQUFTLElBQUk5RCxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDK0QsT0FBT0MsUUFBUSxJQUFJaEUsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2lFLFdBQVdDLFlBQVksSUFBSWxFLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNtRSxlQUFlQyxnQkFBZ0IsSUFBSXBFLFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUNxRSxhQUFhQyxjQUFjLElBQUl0RSxTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDdUUsYUFBYUMsY0FBYyxJQUFJeEUsU0FBUztBQUFBLElBQzdDeUUsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUk3RSxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUM4RSxnQkFBZ0JDLGlCQUFpQixJQUFJL0UsU0FBUztBQUFBLElBQ25EZ0YsV0FBVztBQUFBLElBQ1hDLE9BQU87QUFBQSxJQUNQQyxjQUFjO0FBQUEsSUFDZEMsVUFBVTtBQUFBLElBQ1ZDLFNBQVM7QUFBQSxJQUNUQyxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLElBQ1hDLFFBQVE7QUFBQSxJQUNSQyxPQUFPO0FBQUEsSUFDUEMsUUFBUTtBQUFBLElBQ1JDLGdCQUFnQjtBQUFBLElBQ2hCQyxhQUFhO0FBQUEsSUFDYkMsYUFBYTtBQUFBLElBQ2JDLFNBQVM7QUFBQSxJQUNUQyxPQUFPO0FBQUEsSUFDUEMsYUFBYTtBQUFBLElBQ2JDLFVBQVU7QUFBQSxJQUNWQyxPQUFPO0FBQUEsSUFDUEMsaUJBQWlCO0FBQUEsSUFDakJDLGtCQUFrQjtBQUFBLElBQ2xCQyxlQUFlO0FBQUEsSUFDZkMsY0FBYztBQUFBLElBQ2RDLHFCQUFxQjtBQUFBLElBQ3JCQyxzQkFBc0I7QUFBQSxJQUN0QkMsc0JBQXNCO0FBQUEsSUFDdEJDLG1CQUFtQjtBQUFBLElBQ25CQyxrQkFBa0I7QUFBQSxJQUNsQkMsZ0JBQWdCO0FBQUEsSUFDaEJDLGVBQWU7QUFBQSxJQUNmQyxjQUFjO0FBQUEsSUFDZEMsV0FBVztBQUFBLElBQ1hDLGtCQUFrQjtBQUFBLElBQ2xCQyxxQkFBcUI7QUFBQSxJQUNyQkMsZ0JBQWdCO0FBQUEsSUFDaEJDLGVBQWU7QUFBQSxFQUNqQixDQUFDO0FBR0QsUUFBTSxDQUFDQyxtQkFBbUJDLG9CQUFvQixJQUFJcEgsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQ3FILGVBQWVDLGdCQUFnQixJQUFJdEgsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQ3VILGtCQUFrQkMsbUJBQW1CLElBQUl4SCxTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDeUgsZUFBZUMsZ0JBQWdCLElBQUkxSCxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDMkgsZ0JBQWdCQyxpQkFBaUIsSUFBSTVILFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUM2SCxXQUFXQyxZQUFZLElBQUk5SCxTQUFTLFNBQVM7QUFHcEQsUUFBTSxDQUFDK0gsaUJBQWlCQyxrQkFBa0IsSUFBSWhJLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNpSSxtQkFBbUJDLG9CQUFvQixJQUFJbEksU0FBUyxDQUFDLENBQUM7QUFHN0QsUUFBTSxDQUFDbUksVUFBVUMsV0FBVyxJQUFJcEksU0FBUyxNQUFNO0FBQy9DLFFBQU0sQ0FBQ3FJLGFBQWFDLGNBQWMsSUFBSXRJLFNBQVMsQ0FBQztBQUNoRCxRQUFNLENBQUN1SSxZQUFZLElBQUl2SSxTQUFTLENBQUM7QUFFakMsUUFBTXdJLGtCQUFrQkgsY0FBY0U7QUFDdEMsUUFBTUUsbUJBQW1CRCxrQkFBa0JEO0FBQzNDLFFBQU1HLGVBQWVuRyxjQUFjb0csTUFBTUYsa0JBQWtCRCxlQUFlO0FBQzFFLFFBQU1JLGFBQWFDLEtBQUtDLEtBQUt2RyxjQUFjd0csU0FBU1IsWUFBWTtBQUdoRSxRQUFNLENBQUNTLHVCQUF1QkMsd0JBQXdCLElBQUlqSixTQUFTLEtBQUs7QUFDeEUsUUFBTSxDQUFDa0osa0JBQWtCQyxtQkFBbUIsSUFBSW5KLFNBQVM7QUFBQSxJQUN2RG9KLEtBQUs7QUFBQSxJQUNMQyxRQUFRO0FBQUEsSUFDUkMsUUFBUTtBQUFBLElBQ1JDLGdCQUFnQjtBQUFBLEVBQ2xCLENBQUM7QUFDRCxRQUFNLENBQUNDLGtCQUFrQkMsbUJBQW1CLElBQUl6SixTQUFTLEtBQUs7QUFHOUQsUUFBTTBKLGtCQUFrQkEsTUFBTTtBQUM1QixVQUFNQyxZQUFZcEgsY0FBY3FIO0FBQUFBLE1BQzlCLENBQUNDLE1BQU1BLEVBQUVSLFVBQVVRLEVBQUVSLFdBQVc7QUFBQSxJQUNsQztBQUNBLFdBQU87QUFBQSxNQUNMUyxPQUFPSCxVQUFVWjtBQUFBQSxNQUNqQmdCLFdBQVdKLFVBQVVDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRVIsV0FBVyxXQUFXLEVBQUVOO0FBQUFBLE1BQzdEaUIsWUFBWUwsVUFBVUMsT0FBTyxDQUFDQyxNQUFNQSxFQUFFUixXQUFXLFlBQVksRUFBRU47QUFBQUEsTUFDL0QsYUFBYVksVUFBVUMsT0FBTyxDQUFDQyxNQUFNQSxFQUFFUixXQUFXLFdBQVcsRUFBRU47QUFBQUEsTUFDL0RrQixXQUFXTixVQUFVQyxPQUFPLENBQUNDLE1BQU1BLEVBQUVSLFdBQVcsV0FBVyxFQUFFTjtBQUFBQSxNQUM3RG1CLFVBQVVQLFVBQVVDLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRVIsV0FBVyxVQUFVLEVBQUVOO0FBQUFBLElBQzdEO0FBQUEsRUFDRjtBQUdBLFFBQU1vQixzQkFBc0JBLE1BQU07QUFDaEMsUUFBSXRDLGNBQWMsV0FBVztBQUMzQixhQUFPdEYsY0FBY3FIO0FBQUFBLFFBQ25CLENBQUNRLFNBQVNBLEtBQUtmLFdBQVcsbUJBQW1CLENBQUNlLEtBQUtmO0FBQUFBLE1BQ3JEO0FBQUEsSUFDRixPQUFPO0FBQ0wsYUFBTzlHLGNBQWNxSDtBQUFBQSxRQUNuQixDQUFDUSxTQUFTQSxLQUFLZixVQUFVZSxLQUFLZixXQUFXO0FBQUEsTUFDM0M7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU1nQixpQkFBaUJBLENBQUNoQixXQUFXO0FBQ2pDLFlBQVFBLFFBQU07QUFBQSxNQUNaLEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1QsS0FBSztBQUNILGVBQU87QUFBQSxNQUNULEtBQUs7QUFDSCxlQUFPO0FBQUEsTUFDVCxLQUFLO0FBQ0gsZUFBTztBQUFBLE1BQ1Q7QUFDRSxlQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ0Y7QUFFQSxRQUFNaUIsZ0JBQWdCQSxDQUFDakIsV0FBVztBQUNoQyxZQUFRQSxRQUFNO0FBQUEsTUFDWixLQUFLO0FBQ0gsZUFDRSx1QkFBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsMk5BQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNFIsS0FEOVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFFSixLQUFLO0FBQ0gsZUFDRSx1QkFBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsNldBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOGEsS0FEaGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFFSixLQUFLO0FBQ0gsZUFDRSx1QkFBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsaURBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0gsS0FEcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFFSixLQUFLO0FBQ0gsZUFDRSx1QkFBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsbURBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0gsS0FEdEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFFSixLQUFLO0FBQ0gsZUFDRSx1QkFBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsMEVBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkksS0FEN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFFSjtBQUNFLGVBQU87QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUdBLFFBQU1rQixhQUFhaEksY0FBY2lJLElBQUksQ0FBQ0osTUFBTUssV0FBVztBQUFBLElBQ3JEQyxJQUFJRCxRQUFRO0FBQUEsSUFDWnJCLEtBQUtnQixLQUFLaEI7QUFBQUEsSUFDVnVCLE1BQU1QLEtBQUtPO0FBQUFBLElBQ1h6RixjQUFja0YsS0FBS2xGO0FBQUFBLElBQ25CMEYsYUFBYVIsS0FBS1E7QUFBQUEsSUFDbEJ4RixTQUFTZ0YsS0FBS2hGO0FBQUFBLElBQ2R5RixpQkFDRSx1QkFBQyxVQUFLLFdBQVcsZ0RBQWdEUixlQUFlRCxLQUFLUyxlQUFlLENBQUMsSUFDbEdULGVBQUtTLG1CQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUZ4QixRQUNFLHVCQUFDLFVBQUssV0FBVyxnREFBZ0RnQixlQUFlRCxLQUFLZixVQUFVLGVBQWUsQ0FBQyxJQUM1R2UsZUFBS2YsVUFBVSxtQkFEbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFRnlCLFdBQVdWLEtBQUtmLFVBQVU7QUFBQSxJQUMxQkMsUUFBUWMsS0FBS2QsU0FDWCx1QkFBQyxVQUFLLFdBQVUsc0RBQXFELE9BQU9jLEtBQUtkLFFBQzlFYyxlQUFLZCxVQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsaUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUM7QUFBQSxJQUUzQ3lCLGFBQWFYLEtBQUtXLGNBQ2hCLHVCQUFDLFVBQUssV0FBVSwyRUFDYlgsZUFBS1csZUFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsSUFFQSx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLGlCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlDO0FBQUEsSUFFM0N4QixnQkFBZ0JhLEtBQUtiLGlCQUNuQix1QkFBQyxVQUFLLFdBQVUsMkVBQ2JhLGVBQUtiLGtCQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IsaUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUM7QUFBQSxJQUUzQ3lCLFdBQVdaLEtBQUtZO0FBQUFBLElBQ2hCOUUsaUJBQWlCa0UsS0FBS2xFO0FBQUFBLElBQ3RCK0UsUUFDRSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsUUFDakIsTUFBTTtBQUFBLFVBQ0pDLE9BQU87QUFBQSxZQUNMO0FBQUEsY0FDRXhKLEtBQUs7QUFBQSxjQUNMQyxPQUNFLHVCQUFDLFNBQUksV0FBVSx3REFBdUQsU0FBUyxNQUFNd0osc0JBQXNCZixLQUFLaEIsR0FBRyxHQUFHLG9CQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwSDtBQUFBLFlBRTlIO0FBQUEsWUFDQTtBQUFBLGNBQ0UxSCxLQUFLO0FBQUEsY0FDTEMsT0FDRSx1QkFBQyxTQUFJLFdBQVUscURBQW9ELFNBQVMsTUFBTXlKLHNCQUFzQmhCLEtBQUtoQixHQUFHLEdBQUcsc0JBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlIO0FBQUEsWUFFN0g7QUFBQSxZQUNBO0FBQUEsY0FDRTFILEtBQUs7QUFBQSxjQUNMQyxPQUNFLHVCQUFDLFNBQUksV0FBVSxzREFBcUQsU0FBUyxNQUFNVCw2QkFBNkJrSixLQUFLaEIsR0FBRyxHQUFHLHFCQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnSTtBQUFBLFlBRXBJO0FBQUEsWUFDQTtBQUFBLGNBQ0UxSCxLQUFLO0FBQUEsY0FDTEMsT0FDRTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHdDQUF3Q3lJLEtBQUtTLG9CQUFvQixhQUFhLHFCQUFxQixjQUFjO0FBQUEsa0JBQzVILFNBQVMsTUFBTVEscUJBQXFCakIsS0FBS2hCLEtBQUtnQixLQUFLUyxvQkFBb0IsYUFBYSxhQUFhLFNBQVM7QUFBQSxrQkFFekdULGVBQUtTLG9CQUFvQixhQUFhLFlBQVk7QUFBQTtBQUFBLGdCQUpyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLFlBRUo7QUFBQSxVQUFDO0FBQUEsUUFFTDtBQUFBLFFBQ0EsV0FBVTtBQUFBLFFBRVYsaUNBQUMsWUFBTyxXQUFVLHNEQUNoQixpQ0FBQyxZQUFTLFdBQVUsMkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUE7QUFBQSxNQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF3Q0EsS0F6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBDQTtBQUFBLEVBRUosRUFBRTtBQUVGLFFBQU1TLFVBQVU7QUFBQSxJQUNkLEVBQUU1SixLQUFLLE1BQU02SixRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFN0osS0FBSywyQkFBMkI2SixRQUFRLE9BQU87QUFBQSxJQUNqRCxFQUFFN0osS0FBSyxRQUFRNkosUUFBUSxZQUFZO0FBQUEsSUFDbkMsRUFBRTdKLEtBQUssZ0JBQWdCNkosUUFBUSxRQUFRO0FBQUEsSUFDdkMsRUFBRTdKLEtBQUssZUFBZTZKLFFBQVEsS0FBSztBQUFBLElBQ25DLEVBQUU3SixLQUFLLFdBQVc2SixRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFN0osS0FBSyxtQkFBbUI2SixRQUFRLE9BQU87QUFBQSxJQUN6QyxFQUFFN0osS0FBSyxtQkFBbUI2SixRQUFRLFdBQVc7QUFBQSxJQUM3QyxFQUFFN0osS0FBSyxVQUFVNkosUUFBUSxpQkFBaUI7QUFBQSxJQUMxQyxFQUFFN0osS0FBSyxlQUFlNkosUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRTdKLEtBQUssVUFBVTZKLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUU3SixLQUFLLGtCQUFrQjZKLFFBQVEsWUFBWTtBQUFBLElBQzdDLEVBQUU3SixLQUFLLGFBQWE2SixRQUFRLFNBQVM7QUFBQSxJQUNyQyxFQUFFN0osS0FBSyxVQUFVNkosUUFBUSxVQUFVO0FBQUEsRUFBQztBQUd0QyxRQUFNQyw0QkFBNEJBLENBQUNDLE1BQU0vSSxjQUFjK0ksRUFBRUMsT0FBT0MsS0FBSztBQUdyRTVMLFlBQVUsTUFBTTtBQUNkLFVBQU02TCxzQkFBc0IsWUFBWTtBQUN0QyxVQUFJO0FBQ0Y1SCxrQkFBVSxNQUFNN0QsSUFBSTBMLElBQUksbURBQW1ELEdBQUdDLElBQUk7QUFBQSxNQUNwRixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNQSxLQUFLO0FBQUEsTUFDckI7QUFBQSxJQUNGO0FBQ0FILHdCQUFvQjtBQUFBLEVBQ3RCLEdBQUcsQ0FBQ3pILGFBQWEsQ0FBQztBQUVsQnBFLFlBQVUsTUFBTTtBQUNkLFVBQU1rTSxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YvSCxzQkFBYyxNQUFNL0QsSUFBSTBMLElBQUksZ0JBQWdCLEdBQUdDLE1BQU1BLE1BQU03SCxTQUFTO0FBQUEsTUFDdEUsU0FBUzhILE9BQU87QUFDZEMsZ0JBQVFELE1BQU1BLEtBQUs7QUFBQSxNQUNyQjtBQUFBLElBQ0Y7QUFDQUUsbUJBQWU7QUFBQSxFQUNqQixHQUFHLENBQUM5SCxhQUFhLENBQUM7QUFFbEJwRSxZQUFVLE1BQU07QUFDZCxVQUFNbU0sY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU1oTSxJQUFJMEwsSUFBSSx1QkFBdUI7QUFDdEQvSCxrQkFBVXFJLFNBQVNMLFFBQVEsRUFBRTtBQUFBLE1BQy9CLFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sMEJBQTBCQSxLQUFLO0FBQzdDakksa0JBQVUsRUFBRTtBQUFBLE1BQ2Q7QUFBQSxJQUNGO0FBQ0FvSSxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxDQUFDL0gsYUFBYSxDQUFDO0FBRWxCcEUsWUFBVSxNQUFNO0FBQ2QsVUFBTXFNLGFBQWEsWUFBWTtBQUM3QixVQUFJO0FBQ0ZoSixxQkFBYSxJQUFJO0FBQ2pCLGNBQU0rSSxXQUFXLE1BQU1oTSxJQUFJMEwsSUFBSSw2QkFBNkI7QUFDNUQsY0FBTVEsZ0JBQWdCRixTQUFTTCxLQUFLdEIsSUFBSSxDQUFDOEIsT0FBTzdCLFdBQVc7QUFBQSxVQUN6RHJCLEtBQUtrRCxNQUFNbEQ7QUFBQUEsVUFDWHNCLElBQUlELFFBQVE7QUFBQSxVQUNaOEIseUJBQXlCRCxPQUFPQztBQUFBQSxVQUNoQzVCLE1BQU0yQixNQUFNdEg7QUFBQUEsVUFDWkUsY0FBY29ILE1BQU1wSDtBQUFBQSxVQUNwQjhGLFdBQVdzQixNQUFNdEIsV0FBV3dCLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxVQUN4Q3BILFNBQVNrSCxNQUFNbEg7QUFBQUEsVUFDZkMsU0FBU2lILE1BQU1qSDtBQUFBQSxVQUNmdUYsYUFBYTBCLE1BQU0xQjtBQUFBQSxVQUNuQjFFLGlCQUFpQm9HLE1BQU1wRyxpQkFBaUJ1RztBQUFBQSxVQUN4QzVCLGlCQUFpQnlCLE1BQU16QixvQkFBb0IsU0FBUyxhQUFhO0FBQUEsVUFDakV4QixRQUFRaUQsTUFBTWpELFVBQVU7QUFBQSxVQUN4QkMsUUFBUWdELE1BQU1oRCxVQUFVO0FBQUEsVUFDeEJDLGdCQUFnQitDLE1BQU0vQyxpQkFBaUJqSSxNQUFNZ0wsTUFBTS9DLGNBQWMsRUFBRW1ELE9BQU8sWUFBWSxJQUFJO0FBQUEsVUFDMUYzQixhQUFhdUIsTUFBTXZCLGFBQWEvRixhQUFhc0gsTUFBTXZCLGFBQWFKLFFBQVE7QUFBQSxVQUN4RWdDLGdCQUFnQkwsTUFBTXZCLGFBQWEzQixPQUFPO0FBQUEsVUFDMUN3RCxtQkFBbUJOLE1BQU1PLFlBQVl2TCxNQUFNZ0wsTUFBTU8sU0FBUyxFQUFFSCxPQUFPLGtCQUFrQixJQUFJO0FBQUEsUUFDM0YsRUFBRTtBQUNGbEs7QUFBQUEsVUFDRTZKLGNBQWN6QztBQUFBQSxZQUNaLENBQUNRLFNBQ0NBLEtBQUtPLEtBQUttQyxZQUFZLEVBQUVDLFNBQVN0SyxXQUFXcUssWUFBWSxDQUFDLEtBQ3pEMUMsS0FBS2xGLGFBQWE4SCxTQUFTLEVBQUVELFNBQVN0SyxVQUFVO0FBQUEsVUFDcEQ7QUFBQSxRQUNGO0FBQ0E2Rix1QkFBZSxDQUFDO0FBQUEsTUFDbEIsU0FBU3lELE9BQU87QUFDZEMsZ0JBQVFELE1BQU1BLE1BQU1ySCxPQUFPO0FBQUEsTUFDN0IsVUFBQztBQUNDdEIscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBZ0osZUFBVztBQUFBLEVBQ2IsR0FBRyxDQUFDakksZUFBZTFCLFVBQVUsQ0FBQztBQUU5QjFDLFlBQVUsTUFBTTtBQUNkLFVBQU1rTixpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0ZySixtQkFBVyxNQUFNekQsSUFBSTBMLElBQUksdUJBQXVCLEdBQUdDLElBQUk7QUFBQSxNQUN6RCxTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNQSxLQUFLO0FBQUEsTUFDckI7QUFBQSxJQUNGO0FBQ0FrQixtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsQ0FBQzlJLGFBQWEsQ0FBQztBQUdsQixRQUFNK0ksdUJBQXVCQSxDQUFDeEMsT0FBTztBQUNuQ3RELHlCQUFxQixDQUFDK0YsU0FBUztBQUM3QixVQUFJQSxLQUFLSixTQUFTckMsRUFBRSxHQUFHO0FBQ3JCLGNBQU0wQyxTQUFTRCxLQUFLdkQsT0FBTyxDQUFDeUQsTUFBTUEsTUFBTTNDLEVBQUU7QUFDMUNwRCx5QkFBaUI4RixPQUFPckUsU0FBUyxJQUFJcUUsT0FBT0EsT0FBT3JFLFNBQVMsQ0FBQyxJQUFJLElBQUk7QUFDckUsZUFBT3FFO0FBQUFBLE1BQ1Q7QUFDQSxVQUFJRCxLQUFLcEUsVUFBVSxJQUFJO0FBQ3JCdkUsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFDRCxlQUFPd0k7QUFBQUEsTUFDVDtBQUNBN0YsdUJBQWlCb0QsRUFBRTtBQUNuQixhQUFPLENBQUMsR0FBR3lDLE1BQU16QyxFQUFFO0FBQUEsSUFDckIsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNNEMseUJBQXlCQSxDQUFDQyxRQUFRQyxPQUFPN0IsVUFBVTtBQUN2RHpELHlCQUFxQixDQUFDaUYsU0FBUztBQUM3QixZQUFNTSxVQUFVTixLQUFLSSxNQUFNLEtBQUssQ0FBQztBQUNqQyxZQUFNRyxVQUFVLEVBQUUsR0FBR0QsU0FBUyxDQUFDRCxLQUFLLEdBQUc3QixNQUFNO0FBRTdDLFVBQUk2QixVQUFVLFlBQVk3QixPQUFPO0FBQy9CLGNBQU1nQyxhQUFhRixRQUFRcEU7QUFDM0IsY0FBTXVFLGlCQUFpQkgsUUFBUW5FLFVBQVU7QUFFekMsWUFBSXVFLGNBQWM7QUFDbEIsWUFBSUYsY0FBY0MsZUFBZUUsV0FBV0gsVUFBVSxHQUFHO0FBQ3ZERSx3QkFBY0QsZUFBZWpGLE1BQU1nRixXQUFXNUUsTUFBTSxFQUFFZ0YsS0FBSztBQUMzREYsd0JBQWNBLFlBQVlHLFFBQVEsY0FBYyxFQUFFO0FBQUEsUUFDcEQ7QUFFQU4sZ0JBQVFwRSxTQUFTdUUsY0FBYyxHQUFHbEMsS0FBSyxNQUFNa0MsV0FBVyxLQUFLbEM7QUFBQUEsTUFDL0Q7QUFFQSxVQUFJNkIsVUFBVSxZQUFZN0IsVUFBVSxhQUFhO0FBQy9DK0IsZ0JBQVFPLGVBQWVDO0FBQUFBLE1BQ3pCO0FBRUEsYUFBTyxFQUFFLEdBQUdmLE1BQU0sQ0FBQ0ksTUFBTSxHQUFHRyxRQUFRO0FBQUEsSUFDdEMsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNUyx3QkFBd0JBLENBQUMvRCxTQUFTO0FBQ3RDakIsd0JBQW9CO0FBQUEsTUFDbEJDLEtBQUtnQixLQUFLaEI7QUFBQUEsTUFDVkMsUUFBUWUsS0FBS2YsVUFBVTtBQUFBLE1BQ3ZCQyxRQUFRYyxLQUFLZCxVQUFVO0FBQUEsTUFDdkJDLGdCQUFnQmEsS0FBS2Isa0JBQWtCO0FBQUEsSUFDekMsQ0FBQztBQUNETiw2QkFBeUIsSUFBSTtBQUFBLEVBQy9CO0FBRUEsUUFBTW1GLDJCQUEyQixZQUFZO0FBQzNDLFVBQU0sRUFBRWhGLEtBQUtDLFFBQVFDLFFBQVFDLGVBQWUsSUFBSUw7QUFDaEQsUUFBSSxDQUFDRyxRQUFRO0FBQ1g3RSxxQkFBZSxFQUFFQyxZQUFZLE1BQU1DLFNBQVMsMkJBQTJCQyxNQUFNLFVBQVUsQ0FBQztBQUN4RjtBQUFBLElBQ0Y7QUFDQSxRQUFJMEUsV0FBVyxlQUFlLENBQUNFLGdCQUFnQjtBQUM3Qy9FLHFCQUFlLEVBQUVDLFlBQVksTUFBTUMsU0FBUyxtQ0FBbUNDLE1BQU0sVUFBVSxDQUFDO0FBQ2hHO0FBQUEsSUFDRjtBQUVBOEUsd0JBQW9CLElBQUk7QUFDeEIsUUFBSTtBQUNGLFlBQU00RSxVQUFVO0FBQUEsUUFDZGhGO0FBQUFBLFFBQ0FDLFFBQVFBLFVBQVU7QUFBQTtBQUFBLFFBRWxCeUIsYUFBYXhILG1CQUFtQm9KLGtCQUFrQjtBQUFBLE1BQ3BEO0FBQ0EsVUFBSXRELFdBQVcsZUFBZUUsZ0JBQWdCO0FBQzVDOEUsZ0JBQVE5RSxpQkFBaUJBO0FBQUFBLE1BQzNCO0FBQ0EsWUFBTXBKLElBQUltTyxJQUFJLG9DQUFvQ2xGLEdBQUcsSUFBSWlGLE9BQU87QUFDaEU3SixxQkFBZSxFQUFFQyxZQUFZLE1BQU1DLFNBQVMsZ0NBQWdDQyxNQUFNLFVBQVUsQ0FBQztBQUM3RnNFLCtCQUF5QixLQUFLO0FBQzlCN0UsdUJBQWlCLENBQUErSSxTQUFRQSxPQUFPLENBQUM7QUFBQSxJQUNuQyxTQUFTcEIsT0FBTztBQUNkdkgscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBU3FILE1BQU1JLFVBQVVMLE1BQU1wSCxXQUFXO0FBQUEsUUFDMUNDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQzhFLDBCQUFvQixLQUFLO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBRUEsUUFBTThFLHlCQUF5QixZQUFZO0FBQ3pDLGVBQVc3RCxNQUFNdkQsbUJBQW1CO0FBQ2xDLFlBQU1xSCxTQUFTdkcsa0JBQWtCeUMsRUFBRTtBQUNuQyxVQUFJLENBQUM4RCxRQUFRQyxTQUFTO0FBQ3BCLGVBQU9qSyxlQUFlO0FBQUEsVUFDcEJDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFDQSxVQUFJLENBQUM2SixRQUFRbkYsUUFBUTtBQUNuQixlQUFPN0UsZUFBZTtBQUFBLFVBQ3BCQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQ0EsVUFBSTZKLE9BQU9uRixXQUFXLGVBQWUsQ0FBQ21GLE9BQU9QLGNBQWM7QUFDekQsZUFBT3pKLGVBQWU7QUFBQSxVQUNwQkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFFQXJCLG9CQUFnQixJQUFJO0FBQ3BCLFFBQUk7QUFDRixZQUFNb0wsV0FBV3ZILGtCQUFrQnFELElBQUksQ0FBQ0UsT0FBTztBQUM3QyxjQUFNOEQsU0FBU3ZHLGtCQUFrQnlDLEVBQUU7QUFDbkMsY0FBTTJELFVBQVU7QUFBQSxVQUNkaEYsUUFBUW1GLE9BQU9uRjtBQUFBQSxVQUNmQyxRQUFRa0YsT0FBT2xGLFVBQVU7QUFBQSxVQUN6QnlCLGFBQWF5RCxPQUFPQztBQUFBQSxRQUN0QjtBQUVBLFlBQUlELE9BQU9uRixXQUFXLGVBQWVtRixPQUFPUCxjQUFjO0FBQ3hESSxrQkFBUTlFLGlCQUFpQmlGLE9BQU9QO0FBQUFBLFFBQ2xDO0FBRUEsZUFBTzlOLElBQUltTyxJQUFJLG9DQUFvQzVELEVBQUUsSUFBSTJELE9BQU87QUFBQSxNQUNsRSxDQUFDO0FBRUQsWUFBTU0sUUFBUUMsSUFBSUYsUUFBUTtBQUUxQmxLLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBRURxRCx5QkFBbUIsS0FBSztBQUN4QkUsMkJBQXFCLENBQUMsQ0FBQztBQUN2QmQsMkJBQXFCLEVBQUU7QUFDdkJFLHVCQUFpQixJQUFJO0FBQ3JCbEQsdUJBQWlCLENBQUMrSSxTQUFTQSxPQUFPLENBQUM7QUFBQSxJQUNyQyxTQUFTcEIsT0FBTztBQUNkQyxjQUFRRCxNQUFNQSxLQUFLO0FBQ25CdkgscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBU3FILE1BQU1JLFVBQVVMLE1BQU1wSCxXQUFXO0FBQUEsUUFDMUNDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQ3JCLHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsUUFBTXVMLG1CQUFtQkEsQ0FBQ0MsU0FBUztBQUNqQ3hHLG1CQUFld0csSUFBSTtBQUFBLEVBQ3JCO0FBRUEsUUFBTUMsd0JBQXdCQSxDQUFDdkIsT0FBTzdCLFVBQVU7QUFDOUM1RyxzQkFBa0IsQ0FBQ2lLLE9BQU8sRUFBRSxHQUFHQSxHQUFHLENBQUN4QixLQUFLLEdBQUc3QixNQUFNLEVBQUU7QUFDbkQ5RyxjQUFVLENBQUNtSyxPQUFPLEVBQUUsR0FBR0EsR0FBRyxDQUFDeEIsS0FBSyxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQzFDO0FBQ0EsUUFBTXlCLG9CQUFvQkEsQ0FBQ3hELE1BQU07QUFDL0IsVUFBTSxFQUFFZCxNQUFNZ0IsTUFBTSxJQUFJRixFQUFFQztBQUMxQjNHLHNCQUFrQixDQUFDaUssT0FBTyxFQUFFLEdBQUdBLEdBQUcsQ0FBQ3JFLElBQUksR0FBR2dCLE1BQU0sRUFBRTtBQUNsRDlHLGNBQVUsQ0FBQ21LLE9BQU8sRUFBRSxHQUFHQSxHQUFHLENBQUNyRSxJQUFJLEdBQUcsR0FBRyxFQUFFO0FBQUEsRUFDekM7QUFFQSxRQUFNUyx3QkFBd0IsT0FBT1YsT0FBTztBQUMxQ3hILG9CQUFnQixNQUFNL0MsSUFBSTBMLElBQUksd0JBQXdCbkIsRUFBRSxFQUFFLEdBQUdvQixJQUFJO0FBQ2pFaEosdUJBQW1CLElBQUk7QUFBQSxFQUN6QjtBQUVBLFFBQU1xSSx3QkFBd0IsT0FBT1QsT0FBTztBQUMxQyxVQUFNd0UsT0FBTyxNQUFNL08sSUFBSTBMLElBQUksd0JBQXdCbkIsRUFBRSxFQUFFLEdBQUdvQjtBQUMxRHRJLHlCQUFxQjBMLEdBQUc7QUFDeEJuSyxzQkFBa0I7QUFBQSxNQUNoQkMsV0FBV2tLLEtBQUtsSztBQUFBQSxNQUNoQkMsT0FBT2lLLEtBQUtqSztBQUFBQSxNQUNaQyxjQUFjZ0ssS0FBS2hLO0FBQUFBLE1BQ25CQyxVQUFVK0osS0FBSy9KO0FBQUFBLE1BQ2ZFLFNBQVM2SixLQUFLN0o7QUFBQUEsTUFDZEMsV0FBVzRKLEtBQUs1SjtBQUFBQSxNQUNoQkMsUUFBUTJKLEtBQUszSjtBQUFBQSxNQUNiSCxTQUFTOEosS0FBSzlKO0FBQUFBLE1BQ2Q4QixlQUFlZ0ksS0FBS2hJLGVBQWVrQyxPQUFPO0FBQUEsTUFDMUM1RCxPQUFPMEosS0FBSzFKO0FBQUFBLE1BQ1pPLGFBQWFtSixLQUFLbko7QUFBQUEsTUFDbEJOLFFBQVF5SixLQUFLeko7QUFBQUEsTUFDYkMsZ0JBQWdCd0osS0FBS3hKO0FBQUFBLE1BQ3JCQyxhQUFhdUosS0FBS3ZKLGFBQWE2RyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsTUFDM0M1RyxhQUFhc0osS0FBS3RKO0FBQUFBLE1BQ2xCQyxTQUFTcUosS0FBS3JKO0FBQUFBLE1BQ2RDLE9BQU9vSixLQUFLcEo7QUFBQUEsTUFDWkUsVUFBVWtKLEtBQUtsSjtBQUFBQSxNQUNmQyxPQUFPaUosS0FBS2pKO0FBQUFBLE1BQ1pDLGlCQUFpQmdKLEtBQUtoSixpQkFBaUJrRCxPQUFPO0FBQUEsTUFDOUNqRCxrQkFBa0IrSSxLQUFLL0k7QUFBQUEsTUFDdkJDLGVBQWU4SSxLQUFLOUk7QUFBQUEsSUFDdEIsQ0FBQztBQUNEcEQsdUJBQW1CLElBQUk7QUFDdkI2QixjQUFVLENBQUMsQ0FBQztBQUFBLEVBQ2Q7QUFFQSxRQUFNc0ssbUJBQW1CLFlBQVk7QUFDbkMsUUFBSSxDQUFDbE0sWUFBYTtBQUNsQixRQUFJO0FBQ0YsWUFBTTlDLElBQUlpUCxPQUFPLHFCQUFxQm5NLFlBQVltRyxHQUFHLEVBQUU7QUFDdkQ1RSxxQkFBZSxFQUFFQyxZQUFZLE1BQU1DLFNBQVMsd0JBQXdCQyxNQUFNLFVBQVUsQ0FBQztBQUNyRlAsdUJBQWlCLENBQUM0SyxNQUFNQSxJQUFJLENBQUM7QUFDN0JsTSx5QkFBbUIsS0FBSztBQUFBLElBQzFCLFNBQVMySSxHQUFHO0FBQ1ZPLGNBQVFELE1BQU1OLENBQUM7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNSix1QkFBdUIsT0FBT1gsSUFBSXJCLFdBQVc7QUFDakQsUUFBSTtBQUNGLFVBQUlxQixPQUFPLE1BQU12SyxJQUFJbU8sSUFBSSxxQkFBcUI1RCxFQUFFLElBQUksRUFBRUcsaUJBQWlCeEIsT0FBTyxDQUFDLEdBQUdBLFdBQVcsS0FBSztBQUNoR2pGLHlCQUFpQixDQUFDNEssTUFBTUEsSUFBSSxDQUFDO0FBQzdCeEssdUJBQWUsRUFBRUMsWUFBWSxNQUFNQyxTQUFTLHFCQUFxQjJFLE1BQU0sSUFBSTFFLE1BQU0sVUFBVSxDQUFDO0FBQUEsTUFDOUY7QUFBQSxJQUNGLFNBQVM4RyxHQUFHO0FBQ1ZPLGNBQVFELE1BQU1OLENBQUM7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNEQsZUFBZSxPQUFPNUQsTUFBTTtBQUNoQ0EsTUFBRTZELGVBQWU7QUFDakIsUUFBSTtBQUNGLFlBQU1DLFNBQVMsSUFBSUMsU0FBUztBQUM1QkMsYUFBT0MsUUFBUTVLLGNBQWMsRUFBRTZLLFFBQVEsQ0FBQyxDQUFDQyxHQUFHQyxDQUFDLE1BQU07QUFDakQsWUFBSUEsRUFBR04sUUFBT08sT0FBT0YsR0FBR0MsQ0FBQztBQUFBLE1BQzNCLENBQUM7QUFDRCxZQUFNMVAsSUFBSW1PLElBQUkscUJBQXFCL0ssbUJBQW1CNkYsR0FBRyxJQUFJbUcsUUFBUSxFQUFFUSxTQUFTLEVBQUUsZ0JBQWdCLHNCQUFzQixFQUFFLENBQUM7QUFDM0gvTSx5QkFBbUIsS0FBSztBQUN4Qm9CLHVCQUFpQixDQUFDNEssTUFBTUEsSUFBSSxDQUFDO0FBQzdCeEsscUJBQWUsRUFBRUMsWUFBWSxNQUFNQyxTQUFTLGdCQUFnQkMsTUFBTSxVQUFVLENBQUM7QUFDN0VFLGdCQUFVLENBQUMsQ0FBQztBQUFBLElBQ2QsU0FBU2tILE9BQU87QUFDZCxVQUFJQSxNQUFNSSxVQUFVTCxNQUFNcEgsU0FBU29JLFlBQVksRUFBRUMsU0FBUyxPQUFPO0FBQy9EbEksa0JBQVUsQ0FBQ21LLE9BQU8sRUFBRSxHQUFHQSxHQUFHOUosY0FBYyxlQUFlLEVBQUU7QUFBQTtBQUV6RFYsdUJBQWUsRUFBRUcsTUFBTSxTQUFTRCxTQUFTcUgsTUFBTUksVUFBVUwsTUFBTXBILFdBQVcsa0JBQWtCRCxZQUFZLEtBQUssQ0FBQztBQUFBLElBQ2xIO0FBQUEsRUFDRjtBQUVBLFFBQU11TCxpQkFBaUJBLENBQUMsRUFBRTVGLEtBQUssTUFDN0I7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsTUFDakIsTUFBTTtBQUFBLFFBQ0pjLE9BQU87QUFBQSxVQUNMO0FBQUEsWUFDRXhKLEtBQUs7QUFBQSxZQUNMQyxPQUNFLHVCQUFDLFNBQUksV0FBVSx3REFBdUQsU0FBUyxNQUFNd0osc0JBQXNCZixLQUFLaEIsR0FBRyxHQUFHLG9CQUF0SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwSDtBQUFBLFVBRTlIO0FBQUEsVUFDQTtBQUFBLFlBQ0UxSCxLQUFLO0FBQUEsWUFDTEMsT0FDRSx1QkFBQyxTQUFJLFdBQVUscURBQW9ELFNBQVMsTUFBTXlKLHNCQUFzQmhCLEtBQUtoQixHQUFHLEdBQUcsc0JBQW5IO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlIO0FBQUEsVUFFN0g7QUFBQSxVQUNBO0FBQUEsWUFDRTFILEtBQUs7QUFBQSxZQUNMQyxPQUNFLHVCQUFDLFNBQUksV0FBVSxzREFBcUQsU0FBUyxNQUFNVCw2QkFBNkJrSixLQUFLaEIsR0FBRyxHQUFHLHFCQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnSTtBQUFBLFVBRXBJO0FBQUEsVUFDQTtBQUFBLFlBQ0UxSCxLQUFLO0FBQUEsWUFDTEMsT0FDRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVcsd0NBQXdDeUksS0FBS1Msb0JBQW9CLGFBQWEscUJBQXFCLGNBQWM7QUFBQSxnQkFDNUgsU0FBUyxNQUFNUSxxQkFBcUJqQixLQUFLaEIsS0FBS2dCLEtBQUtTLG9CQUFvQixhQUFhLGFBQWEsU0FBUztBQUFBLGdCQUV6R1QsZUFBS1Msb0JBQW9CLGFBQWEsWUFBWTtBQUFBO0FBQUEsY0FKckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxVQUVKO0FBQUEsUUFBQztBQUFBLE1BRUw7QUFBQSxNQUNBLFdBQVU7QUFBQSxNQUVWLGlDQUFDLFlBQU8sV0FBVSxzREFDaEIsaUNBQUMsWUFBUyxXQUFVLDJCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJDLEtBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBO0FBQUEsSUF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBd0NBO0FBSUYsUUFBTW9GLDBCQUEwQkEsTUFBTTtBQUNwQyxVQUFNQyxTQUFTeEcsZ0JBQWdCO0FBQy9CLFVBQU15RyxlQUFlNU4sY0FBY3FILE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRVIsV0FBVyxtQkFBbUIsQ0FBQ1EsRUFBRVIsTUFBTSxFQUFFTjtBQUM1RixVQUFNcUgsaUJBQWlCRixPQUFPcEcsUUFBUSxLQUFNb0csT0FBT2pHLFlBQVlpRyxPQUFPcEcsUUFBUyxLQUFLdUcsUUFBUSxDQUFDLElBQUk7QUFDakcsVUFBTUMsZ0JBQWdCSixPQUFPcEcsUUFBUSxLQUFNb0csT0FBT2hHLFdBQVdnRyxPQUFPcEcsUUFBUyxLQUFLdUcsUUFBUSxDQUFDLElBQUk7QUFFL0YsV0FDRSx1QkFBQyxTQUFJLFdBQVUsa0VBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsb0ZBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUscUdBQ2IsaUNBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNqRSxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLDBNQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyUSxLQUQ3UTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFFBQUcsV0FBVSxxQ0FBb0MsK0JBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlFO0FBQUEsWUFDakUsdUJBQUMsT0FBRSxXQUFVLHlCQUF3QixtREFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0U7QUFBQSxlQUYxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdBLHVCQUFDLFNBQUksV0FBVSwyQkFDWkU7QUFBQUEscUJBQVdILGNBQWMsSUFBSSxLQUM1Qix1QkFBQyxTQUFJLFdBQVUsOEZBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsZ0NBQStCLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDdEYsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFZLEtBQUksR0FBRSxvQ0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUcsS0FEdkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsVUFBSyxXQUFVLHNDQUFzQ0E7QUFBQUE7QUFBQUEsY0FBZTtBQUFBLGlCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRjtBQUFBLGVBSm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxVQUVERyxXQUFXRCxhQUFhLElBQUksS0FDM0IsdUJBQUMsU0FBSSxXQUFVLHNGQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDRCQUEyQixNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2xGLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUscUNBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNHLEtBRHhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLFVBQUssV0FBVSxrQ0FBa0NBO0FBQUFBO0FBQUFBLGNBQWM7QUFBQSxpQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkU7QUFBQSxlQUo3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsYUFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUJBO0FBQUEsV0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdDQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLDZEQUNaN08sZ0NBQXNCK0ksSUFBSSxDQUFDZ0csUUFBUTtBQUNsQyxjQUFNQyxRQUFRUCxPQUFPTSxJQUFJOU8sR0FBRztBQUM1QixjQUFNZ1AsYUFBYVIsT0FBT3BHLFFBQVEsS0FBTTJHLFFBQVFQLE9BQU9wRyxRQUFTLEtBQUt1RyxRQUFRLENBQUMsSUFBSTtBQUNsRixlQUNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxXQUFXLDBKQUEwSkksVUFBVSxJQUFJLGVBQWUsRUFBRTtBQUFBLFlBR3BNO0FBQUEscUNBQUMsU0FBSSxXQUFXLG1FQUFtRUQsSUFBSTVPLEtBQUssb0dBQTVGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZMO0FBQUEsY0FFN0wsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVcsc0JBQXNCNE8sSUFBSTNPLE9BQU8sSUFBSTJPLElBQUl6TyxTQUFTLGlEQUFpRHlPLElBQUl4TyxTQUFTLElBQzdId08sY0FBSXZPLFFBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSwyREFDVndPLG1CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsMENBQ1ZELGNBQUk3TyxTQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUseURBQ2I7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVyx3Q0FBd0M2TyxJQUFJNU8sS0FBSztBQUFBLG9CQUM1RCxPQUFPLEVBQUUrTyxPQUFPLEdBQUdELFVBQVUsSUFBSTtBQUFBO0FBQUEsa0JBRm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFFcUMsS0FIdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSwyREFDVkE7QUFBQUE7QUFBQUEsa0JBQVc7QUFBQSxxQkFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUJBO0FBQUE7QUFBQTtBQUFBLFVBM0JLRixJQUFJOU87QUFBQUEsVUFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBNkJBO0FBQUEsTUFFSixDQUFDLEtBcENIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQ0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSxtRUFFYjtBQUFBLCtCQUFDLFNBQUksV0FBVSwyRkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwSEFDYixpQ0FBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsZ05BQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlSLEtBRG5SO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsT0FBRSxXQUFVLHFEQUFxRHdPLGlCQUFPcEcsU0FBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0U7QUFBQSxZQUMvRSx1QkFBQyxPQUFFLFdBQVUseUNBQXdDLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLGVBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDJGQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJIQUNiLGlDQUFDLFNBQUksV0FBVSxXQUFVLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDakUsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFZLEtBQUksR0FBRSxpREFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0gsS0FEcEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxPQUFFLFdBQVUsc0RBQXNEcUcsMEJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdGO0FBQUEsWUFDaEYsdUJBQUMsT0FBRSxXQUFVLDBDQUF5Qyw2QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUU7QUFBQSxlQUZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUE7QUFBQSxRQUdDRCxPQUFPLFdBQVcsSUFBSSxLQUNyQix1QkFBQyxTQUFJLFdBQVUsNkZBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNEhBQ2IsaUNBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNqRSxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLG1NQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvUSxLQUR0UTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLE9BQUUsV0FBVSx1REFBdURBLGlCQUFPLFdBQVcsS0FBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Y7QUFBQSxZQUN4Rix1QkFBQyxPQUFFLFdBQVUsMkNBQTBDLDhCQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRTtBQUFBLGVBRnZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQTtBQUFBLFFBSUYsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtQ0FBQyxPQUFFLFdBQVUscURBQ1YzTjtBQUFBQSw0QkFBY3dHLFNBQVMsS0FDbEJtSCxPQUFPcEcsUUFBUXZILGNBQWN3RyxTQUFVLEtBQUtzSCxRQUFRLENBQUMsSUFDdkQ7QUFBQSxjQUFNO0FBQUEsaUJBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLHlDQUF3Qyw0QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUU7QUFBQSxlQVBuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsc0JBQ2IsaUNBQUMsU0FBSSxXQUFVLHdCQUF1QixTQUFRLGFBQzVDO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxHQUFFO0FBQUEsZ0JBQ0YsTUFBSztBQUFBLGdCQUNMLFFBQU87QUFBQSxnQkFDUCxhQUFZO0FBQUE7QUFBQSxjQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlpQjtBQUFBLFlBRWpCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsR0FBRTtBQUFBLGdCQUNGLE1BQUs7QUFBQSxnQkFDTCxRQUFPO0FBQUEsZ0JBQ1AsYUFBWTtBQUFBLGdCQUNaLGlCQUFpQixHQUFHOU4sY0FBY3dHLFNBQVMsSUFBS21ILE9BQU9wRyxRQUFRdkgsY0FBY3dHLFNBQVUsTUFBTSxDQUFDO0FBQUEsZ0JBQzlGLGVBQWM7QUFBQTtBQUFBLGNBTmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU11QjtBQUFBLFlBRXZCLHVCQUFDLFVBQ0MsaUNBQUMsb0JBQWUsSUFBRyxvQkFBbUIsSUFBRyxNQUFLLElBQUcsTUFBSyxJQUFHLFFBQU8sSUFBRyxNQUNqRTtBQUFBLHFDQUFDLFVBQUssUUFBTyxNQUFLLFdBQVUsYUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUM7QUFBQSxjQUNyQyx1QkFBQyxVQUFLLFFBQU8sUUFBTyxXQUFVLGFBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVDO0FBQUEsaUJBRnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkEsS0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF1QkE7QUFBQSxhQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBa0NBO0FBQUEsV0E3RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThFQTtBQUFBLFNBM0pGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0SkE7QUFBQSxFQUVKO0FBR0EsUUFBTTZILHFCQUFxQkEsQ0FBQ0MsYUFBYTtBQUN2QyxVQUFNQyxZQUFZRCxTQUFTeEgsV0FBVyxtQkFBbUIsQ0FBQ3dILFNBQVN4SDtBQUNuRSxRQUFJeEIsY0FBYyxhQUFhLENBQUNpSixVQUFXLFFBQU87QUFDbEQsUUFBSWpKLGNBQWMsZUFBZWlKLFVBQVcsUUFBTztBQUNuRCxVQUFNQyxhQUFhNUosa0JBQWtCNEYsU0FBUzhELFNBQVN6SCxHQUFHO0FBQzFELFVBQU00SCxnQkFBZ0JELGNBQWMxSixrQkFBa0J3SixTQUFTekg7QUFHL0QsUUFBSXZCLGNBQWMsYUFBYTtBQUM3QixhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFNBQUksV0FBVSw4R0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF5SDtBQUFBLFlBQ3pILHVCQUFDLFNBQUksV0FBVSxZQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLHlIQUNaZ0osbUJBQVNsRyxNQUFNc0csT0FBTyxDQUFDLEdBQUdDLFlBQVksS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxXQUNiO0FBQUEsMkNBQUMsUUFBRyxXQUFVLDRDQUE0Q0wsbUJBQVNsRyxRQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3RTtBQUFBLG9CQUN4RSx1QkFBQyxPQUFFLFdBQVUseUJBQXlCa0csbUJBQVNqRyxlQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUEyRDtBQUFBLHVCQUY3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUdBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQkFFYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFNBQVMsTUFBTXVELHNCQUFzQjBDLFFBQVE7QUFBQSxzQkFDN0MsV0FBVTtBQUFBLHNCQUNWLE9BQU07QUFBQSxzQkFFTixpQ0FBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsNEhBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZMLEtBRC9MO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQTtBQUFBLG9CQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFRQTtBQUFBLGtCQUNBLHVCQUFDLGtCQUFlLE1BQU1BLFlBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStCO0FBQUEscUJBWGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBWUE7QUFBQSxtQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF1QkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSxvRUFBbUUscUJBQWhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFGO0FBQUEsa0JBQ3JGLHVCQUFDLE9BQUUsV0FBVSw4Q0FBOENBLG1CQUFTM0wsZ0JBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlGO0FBQUEscUJBRm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsb0VBQW1FLHNCQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRjtBQUFBLGtCQUN0Rix1QkFBQyxPQUFFLFdBQVUsOENBQThDMkwsbUJBQVM3RixhQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4RTtBQUFBLHFCQUZoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsbUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFTQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLHFHQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHFGQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLGVBQWMsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNyRSxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLG9JQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFxTSxLQUR2TTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQU07QUFBQSxxQkFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEseUNBQUMsVUFBSyxXQUFXLCtFQUErRVgsZUFBZXdHLFNBQVN4SCxNQUFNLENBQUMsSUFDNUhpQjtBQUFBQSxrQ0FBY3VHLFNBQVN4SCxNQUFNO0FBQUEsb0JBQzdCd0gsU0FBU3hIO0FBQUFBLHVCQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxrQkFDQSx1QkFBQyxVQUFLLFdBQVcsK0VBQStFZ0IsZUFBZXdHLFNBQVNoRyxlQUFlLENBQUMsSUFDcklnRyxtQkFBU2hHLG1CQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsZ0JBRUNnRyxTQUFTdkgsVUFDUix1QkFBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUsc0VBQXFFLHNCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RjtBQUFBLGtCQUN4Rix1QkFBQyxPQUFFLFdBQVUseUNBQXlDdUgsbUJBQVN2SCxVQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRTtBQUFBLHFCQUZ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBR0YsdUJBQUMsU0FBSSxXQUFVLDBCQUNadUg7QUFBQUEsMkJBQVM5RixlQUNSLHVCQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSx3RUFBdUUsMkJBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQStGO0FBQUEsb0JBQy9GLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLDZDQUFDLFNBQUksV0FBVSx1RUFDYixpQ0FBQyxVQUFLLFdBQVUseUNBQXlDOEYsbUJBQVM5RixhQUFha0csT0FBTyxDQUFDLEdBQUdDLFlBQVksS0FBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBd0csS0FEMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLE9BQUUsV0FBVSxrREFBa0RMLG1CQUFTOUYsZUFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0Y7QUFBQSx5QkFKdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLHVCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQSxrQkFFRDhGLFNBQVN0SCxrQkFDUix1QkFBQyxTQUFJLFdBQVUsc0RBQ2I7QUFBQSwyQ0FBQyxPQUFFLFdBQVUseUVBQXdFLDhCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtRztBQUFBLG9CQUNuRyx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsMkJBQTBCLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDakYsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFZLEtBQUksR0FBRSw0RkFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBNkosS0FEL0o7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBLHVCQUFDLE9BQUUsV0FBVSxxQ0FBcUNzSCxtQkFBU3RILGtCQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEwRTtBQUFBLHlCQUo1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBO0FBQUEsdUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFRQTtBQUFBLHFCQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVCQTtBQUFBLGdCQUVDc0gsU0FBU2pFLHFCQUNSLHVCQUFDLE9BQUUsV0FBVSx5Q0FBd0M7QUFBQTtBQUFBLGtCQUFlaUUsU0FBU2pFO0FBQUFBLHFCQUE3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErRjtBQUFBLG1CQW5Ebkc7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFxREE7QUFBQSxpQkEzRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0RkE7QUFBQTtBQUFBO0FBQUEsUUFoR0tpRSxTQUFTekg7QUFBQUEsUUFEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWtHQTtBQUFBLElBRUo7QUFHQSxXQUNFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFFQyxXQUFXLCtHQUErRzJILGFBQWEsdURBQXVELDJCQUEyQjtBQUFBLFFBR3pOO0FBQUEsaUNBQUMsU0FBSSxXQUFVLCtHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBIO0FBQUEsVUFDMUgsdUJBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU0E7QUFBQUEsb0JBQ1QsVUFBVSxNQUFNN0QscUJBQXFCMkQsU0FBU3pILEdBQUc7QUFBQSxvQkFDakQsV0FBVTtBQUFBO0FBQUEsa0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUlpRztBQUFBLGdCQUVqRyx1QkFBQyxRQUFHLFdBQVUsNENBQTRDeUgsbUJBQVNsRyxRQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RTtBQUFBLG1CQVAxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVFBO0FBQUEsY0FDQSx1QkFBQyxrQkFBZSxNQUFNa0csWUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQSxpQkFWakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLG9FQUFtRSxxQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUY7QUFBQSxnQkFDckYsdUJBQUMsT0FBRSxXQUFVLDhDQUE4Q0EsbUJBQVMzTCxnQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUY7QUFBQSxtQkFGbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLG9FQUFtRSxrQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0Y7QUFBQSxnQkFDbEYsdUJBQUMsT0FBRSxXQUFVLHVEQUF1RDJMLG1CQUFTakcsZUFBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBeUY7QUFBQSxtQkFGM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSw4RkFDYjtBQUFBLHFDQUFDLFVBQUssV0FBVyxpRUFBaUVQLGVBQWV3RyxTQUFTaEcsZUFBZSxDQUFDLElBQ3ZIZ0csbUJBQVNoRyxtQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxVQUFLLFdBQVUsMkJBQ2Q7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsZUFBYyxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ3JFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsNEZBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZKLEtBRC9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQ2dHLFNBQVM3RjtBQUFBQSxtQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFVQTtBQUFBLFlBRUNnRyxpQkFDQyx1QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLE1BQU1oSixtQkFBbUIsSUFBSTtBQUFBLGdCQUN0QyxXQUFVO0FBQUEsZ0JBRVY7QUFBQSx5Q0FBQyxtQkFBZ0IsV0FBVSxhQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQztBQUFBLGtCQUFHO0FBQUEsa0JBQ3ZCYixrQkFBa0I0QjtBQUFBQSxrQkFBTztBQUFBO0FBQUE7QUFBQSxjQUwzQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQTlDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdEQTtBQUFBO0FBQUE7QUFBQSxNQXJESzhILFNBQVN6SDtBQUFBQSxNQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBdURBO0FBQUEsRUFFSjtBQUdBLFFBQU0rSCxVQUFVQSxDQUFDLEVBQUUvRyxLQUFLLE1BQU07QUFDNUIsVUFBTTBHLFlBQVkxRyxLQUFLZixXQUFXLG1CQUFtQixDQUFDZSxLQUFLZjtBQUMzRCxRQUFJeEIsY0FBYyxhQUFhLENBQUNpSixVQUFXLFFBQU87QUFDbEQsUUFBSWpKLGNBQWMsZUFBZWlKLFVBQVcsUUFBTztBQUNuRCxVQUFNQyxhQUFhNUosa0JBQWtCNEYsU0FBUzNDLEtBQUtoQixHQUFHO0FBQ3RELFVBQU00SCxnQkFBZ0JELGNBQWMxSixrQkFBa0IrQyxLQUFLaEI7QUFFM0QsUUFBSXZCLGNBQWMsYUFBYTtBQUM3QixhQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFNBQUksV0FBVSxtRUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSx5SEFDWnVDLGVBQUtPLE1BQU1zRyxPQUFPLENBQUMsR0FBR0MsWUFBWSxLQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsMkNBQUMsUUFBRyxXQUFVLGtEQUFrRDlHLGVBQUtPLFFBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTBFO0FBQUEsb0JBQzFFLHVCQUFDLFVBQUssV0FBVyxxRkFBcUZOLGVBQWVELEtBQUtmLE1BQU0sQ0FBQyxJQUM5SGlCO0FBQUFBLG9DQUFjRixLQUFLZixNQUFNO0FBQUEsc0JBQ3pCZSxLQUFLZjtBQUFBQSx5QkFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsb0JBQ0EsdUJBQUMsVUFBSyxXQUFXLCtFQUErRWdCLGVBQWVELEtBQUtTLGVBQWUsQ0FBQyxJQUNqSVQsZUFBS1MsbUJBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBU0E7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsa0NBQWtDVCxlQUFLaEYsV0FBVyx5QkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcUY7QUFBQSxxQkFYdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFZQTtBQUFBLG1CQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHVDQUFzQyxxQkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0Q7QUFBQSxrQkFDeEQsdUJBQUMsT0FBRSxXQUFVLHFDQUFxQ2dGLGVBQUtsRixnQkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0U7QUFBQSxxQkFGdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFHQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxrQkFBZSxRQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEyQixLQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGlCQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLG9GQUNiLGlDQUFDLFNBQUksV0FBVSw2Q0FDWmtGO0FBQUFBLG1CQUFLZCxVQUNKLHVCQUFDLFNBQUksV0FBVSwrQ0FDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSwwRUFBeUUsdUJBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdHO0FBQUEsZ0JBQ2hHLHVCQUFDLFVBQUssV0FBVSxpQ0FBaUNjLGVBQUtkLFVBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZEO0FBQUEsbUJBRi9EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxjQUVEYyxLQUFLVyxlQUNKLHVCQUFDLFNBQUksV0FBVSx3RkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSx1RUFDYixpQ0FBQyxVQUFLLFdBQVUseUNBQXlDWCxlQUFLVyxhQUFha0csT0FBTyxDQUFDLEdBQUdDLFlBQVksS0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBb0csS0FEdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFVBQUssV0FBVSxpQ0FBaUM5RyxlQUFLVyxlQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRTtBQUFBLG1CQUpwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FFRFgsS0FBS2Isa0JBQ0osdUJBQUMsU0FBSSxXQUFVLHdGQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLCtCQUE4QixNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ3JGLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsNEZBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZKLEtBRC9KO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxVQUFLLFdBQVUsaUNBQWlDYSxlQUFLYixrQkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcUU7QUFBQSxtQkFKdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBRURhLEtBQUt3QyxxQkFDSix1QkFBQyxVQUFLLFdBQVUsMEJBQXlCO0FBQUE7QUFBQSxnQkFBVXhDLEtBQUt3QztBQUFBQSxtQkFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEU7QUFBQSxpQkF4QjlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBLEtBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUE7QUFBQTtBQUFBLFFBOURLeEMsS0FBS2hCO0FBQUFBLFFBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQWdFQTtBQUFBLElBRUo7QUFFQSxXQUNFO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFFQyxXQUFXLHNLQUFzSzJILGFBQWEsNkNBQTZDLDJCQUEyQjtBQUFBLFFBR3RRO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsU0FBU0E7QUFBQUEsZ0JBQ1QsVUFBVSxNQUFNN0QscUJBQXFCOUMsS0FBS2hCLEdBQUc7QUFBQSxnQkFDN0MsV0FBVTtBQUFBO0FBQUEsY0FKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJaUc7QUFBQSxZQUVqRyx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsa0RBQWtEZ0IsZUFBS08sUUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEU7QUFBQSxnQkFDMUUsdUJBQUMsVUFBSyxXQUFXLCtFQUErRU4sZUFBZUQsS0FBS1MsZUFBZSxDQUFDLElBQ2pJVCxlQUFLUyxtQkFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBQ0EsdUJBQUMsT0FBRSxXQUFVLGtDQUFrQ1QsZUFBS2hGLFdBQVcseUJBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFGO0FBQUEsaUJBUHZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUseURBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsaUVBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUsdUNBQXNDLHFCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3RDtBQUFBLGNBQ3hELHVCQUFDLE9BQUUsV0FBVSxxQ0FBcUNnRixlQUFLbEYsZ0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9FO0FBQUEsaUJBRnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxRkFDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSxxQ0FBb0Msc0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVEO0FBQUEsY0FDdkQsdUJBQUMsT0FBRSxXQUFVLG1DQUFtQ2tGLGVBQUtZLGFBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStEO0FBQUEsaUJBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxpQ0FDYixpQ0FBQyxrQkFBZSxRQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQixLQUQ3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFFQ2dHLGlCQUNDLHVCQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNaEosbUJBQW1CLElBQUk7QUFBQSxjQUN0QyxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLG1CQUFnQixXQUFVLGFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9DO0FBQUEsZ0JBQUc7QUFBQSxnQkFDckJiLGtCQUFrQjRCO0FBQUFBLGdCQUFPO0FBQUE7QUFBQTtBQUFBLFlBTDdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBO0FBQUE7QUFBQSxNQTdDR3FCLEtBQUtoQjtBQUFBQSxNQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFnREE7QUFBQSxFQUVKO0FBR0EsUUFBTWdJLGNBQWNBLE1BQU07QUFDeEIsUUFBSWpPO0FBQ0YsYUFBTyx1QkFBQyxrQkFBZSxXQUFzQixTQUFTLE9BQU8sTUFBSyxtQkFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEwRTtBQUVuRixVQUFNa08sbUJBQW1CbEgsb0JBQW9CO0FBQzdDLFVBQU1tSCxxQkFBcUJqSixjQUFjRTtBQUN6QyxVQUFNZ0osc0JBQXNCRCxxQkFBcUIvSTtBQUNqRCxVQUFNaUosa0JBQWtCSCxpQkFBaUIxSSxNQUFNNEkscUJBQXFCRCxrQkFBa0I7QUFDdEYsVUFBTUcsZ0JBQWdCNUksS0FBS0MsS0FBS3VJLGlCQUFpQnRJLFNBQVNSLFlBQVk7QUFFdEUsUUFBSSxDQUFDOEksaUJBQWlCdEk7QUFDcEIsYUFDRSx1QkFBQyxTQUFJLFdBQVUsa0VBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsOEJBQ2IsaUNBQUMsU0FBSSxXQUFVLHFCQUFvQixNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQzNFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxPQUFNLEdBQUUsZ1BBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbVQsS0FEclQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsdUNBQ1ZsQix3QkFBYyxZQUFZLCtCQUErQixrQ0FENUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQ1ZBLHdCQUFjLFlBQVksc0NBQXNDLDREQURuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUdKLFFBQUlNLGFBQWE7QUFDZixhQUNFLHVCQUFDLFNBQUksV0FBVSx3REFDWnFKLDBCQUFnQmhILElBQUlvRyxrQkFBa0IsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBRUosUUFBSXpJLGFBQWE7QUFDZixhQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNacUosMEJBQWdCaEg7QUFBQUEsUUFBSSxDQUFDWCxNQUNwQix1QkFBQyxXQUFtQixNQUFNQSxLQUFaQSxFQUFFYSxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsTUFDN0IsS0FISDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFFSixXQUNFLHVCQUFDLFNBQUksV0FBVSxnRkFDYjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUTtBQUFBLFFBQ1IsTUFBTUgsV0FBV1g7QUFBQUEsVUFBTyxDQUFDQyxNQUN2QmhDLGNBQWMsY0FBY2dDLEVBQUVpQixhQUFhakIsRUFBRWlCLGNBQWMsa0JBQWtCLENBQUNqQixFQUFFaUIsYUFBYWpCLEVBQUVpQixjQUFjO0FBQUEsUUFDL0c7QUFBQSxRQUNBO0FBQUEsUUFDQSxpQkFBZ0I7QUFBQSxRQUNoQixrQkFBaUI7QUFBQTtBQUFBLE1BUG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9tQyxLQVJyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxFQUVKO0FBR0EsUUFBTTRHLG1CQUFtQkEsQ0FBQyxFQUFFckosMkJBQWFPLHlCQUFZK0ksYUFBYSxNQUFNO0FBQ3RFLFFBQUkvSSxlQUFjLEVBQUcsUUFBTztBQUM1QixVQUFNZ0osUUFBUTtBQUNkLFVBQU1DLE1BQU07QUFDWkQsVUFBTUUsS0FBSyxDQUFDO0FBQ1osUUFBSWxKLGNBQWFpSixLQUFLO0FBQ3BCLFVBQUl4SixlQUFjLEVBQUd1SixPQUFNRSxLQUFLLEtBQUs7QUFDckMsZUFBU3pFLElBQUl4RSxLQUFLZ0osSUFBSSxHQUFHeEosZUFBYyxDQUFDLEdBQUdnRixLQUFLeEUsS0FBS2tKLElBQUluSixjQUFhLEdBQUdQLGVBQWMsQ0FBQyxHQUFHZ0YsS0FBSztBQUM5RixZQUFJQSxNQUFNLEtBQUtBLE1BQU16RSxZQUFZZ0osT0FBTUUsS0FBS3pFLENBQUM7QUFBQSxNQUMvQztBQUNBLFVBQUloRixlQUFjTyxjQUFhLEVBQUdnSixPQUFNRSxLQUFLLEtBQUs7QUFBQSxJQUNwRCxPQUFPO0FBQ0wsZUFBU3pFLElBQUksR0FBR0EsS0FBS3pFLGFBQVl5RSxJQUFLdUUsT0FBTUUsS0FBS3pFLENBQUM7QUFBQSxJQUNwRDtBQUNBLFFBQUl6RSxjQUFhLEVBQUdnSixPQUFNRSxLQUFLbEosV0FBVTtBQUV6QyxXQUNFLHVCQUFDLFNBQUksV0FBVSxpREFDYjtBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTLE1BQU0rSSxhQUFhdEosZUFBYyxDQUFDO0FBQUEsVUFDM0MsVUFBVUEsaUJBQWdCO0FBQUEsVUFDMUIsV0FBVTtBQUFBLFVBQTBMO0FBQUE7QUFBQSxRQUh0TTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLE1BQ0N1SixNQUFNcEg7QUFBQUEsUUFBSSxDQUFDc0UsTUFBTXpCLE1BQ2hCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFFQyxTQUFTLE1BQU0sT0FBT3lCLFNBQVMsWUFBWTZDLGFBQWE3QyxJQUFJO0FBQUEsWUFDNUQsVUFBVSxPQUFPQSxTQUFTO0FBQUEsWUFDMUIsV0FBVywyREFBMkRBLFNBQVN6RyxlQUMzRSx5REFDQSxPQUFPeUcsU0FBUyxXQUNkLG1GQUNBLDhEQUE4RDtBQUFBLFlBR25FQTtBQUFBQTtBQUFBQSxVQVZJekI7QUFBQUEsVUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUE7QUFBQSxNQUNEO0FBQUEsTUFDRDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNc0UsYUFBYXRKLGVBQWMsQ0FBQztBQUFBLFVBQzNDLFVBQVVBLGlCQUFnQk87QUFBQUEsVUFDMUIsV0FBVTtBQUFBLFVBQTBMO0FBQUE7QUFBQSxRQUh0TTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLFNBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxFQUVKO0FBRUEsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFNBQUksV0FBVywwQkFBMEIsQ0FBQ3pHLGNBQWMsVUFBVSxNQUFNLElBQ3RFO0FBQUEsT0FBQ0EsZUFBZSx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BRXpCLHVCQUFDLFVBQU8sWUFBWSxTQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBCO0FBQUEsTUFDMUI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1vQyxZQUFZSTtBQUFBQSxVQUNsQixXQUFXSixZQUFZRTtBQUFBQSxVQUN2QixTQUFTRixZQUFZRztBQUFBQSxVQUNyQixTQUFTLE1BQU1GLGVBQWUsQ0FBQ3dLLE9BQU8sRUFBRSxHQUFHQSxHQUFHdkssWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLFFBSnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUlzRTtBQUFBLE1BR3JFLHVCQUFDLFNBQUksV0FBVSx3RUFDZDtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBR1gsdUJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLCtFQUNiO0FBQUEsbUNBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSxtREFBa0Qsb0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW9GO0FBQUEsY0FDcEYsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QiwyREFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUY7QUFBQSxpQkFGdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLHNEQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNcUQsYUFBYSxTQUFTO0FBQUEsb0JBQ3JDLFdBQVcsMkRBQTJERCxjQUFjLFlBQVksdUNBQXVDLG1DQUFtQztBQUFBLG9CQUNySztBQUFBO0FBQUEsc0JBRUt0RixjQUFjcUgsT0FBTyxDQUFDQyxNQUFNQSxFQUFFUixXQUFXLG1CQUFtQixDQUFDUSxFQUFFUixNQUFNLEVBQUVOO0FBQUFBLHNCQUFPO0FBQUE7QUFBQTtBQUFBLGtCQUwxRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU1qQixhQUFhLFdBQVc7QUFBQSxvQkFDdkMsV0FBVywyREFBMkRELGNBQWMsY0FBYyx1Q0FBdUMsbUNBQW1DO0FBQUEsb0JBQ3ZLO0FBQUE7QUFBQSxzQkFFT3RGLGNBQWNxSCxPQUFPLENBQUNDLE1BQU1BLEVBQUVSLFVBQVVRLEVBQUVSLFdBQVcsZUFBZSxFQUFFTjtBQUFBQSxzQkFBTztBQUFBO0FBQUE7QUFBQSxrQkFMM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLHVEQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUyxNQUFNWCxZQUFZLE1BQU07QUFBQSxvQkFDakMsV0FBVyxpQ0FBaUNELGFBQWEsU0FBUyx1Q0FBdUMsbUNBQW1DO0FBQUEsb0JBRTVJLGlDQUFDLGNBQVcsV0FBVSxhQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQjtBQUFBO0FBQUEsa0JBSmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTUMsWUFBWSxNQUFNO0FBQUEsb0JBQ2pDLFdBQVcsaUNBQWlDRCxhQUFhLFNBQVMsdUNBQXVDLG1DQUFtQztBQUFBLG9CQUU1SSxpQ0FBQyxjQUFXLFdBQVUsYUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBK0I7QUFBQTtBQUFBLGtCQUpqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU1DLFlBQVksT0FBTztBQUFBLG9CQUNsQyxXQUFXLGlDQUFpQ0QsYUFBYSxVQUFVLHVDQUF1QyxtQ0FBbUM7QUFBQSxvQkFFN0ksaUNBQUMsc0JBQW1CLFdBQVUsYUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBdUM7QUFBQTtBQUFBLGtCQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxtQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkE7QUFBQSxpQkFyQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFzQ0E7QUFBQSxlQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZDQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFZO0FBQUEsZ0JBQ1osT0FBTzlEO0FBQUFBLGdCQUNQO0FBQUEsZ0JBQ0EsVUFBVSxDQUFDb0gsTUFBTTtBQUNmLHdCQUFNdUcsTUFBTXZHLEVBQUVDLE9BQU9DO0FBQ3JCckgsaUNBQWUwTixHQUFHO0FBQ2xCLHNCQUFJQSxRQUFRLElBQUk7QUFDZHRQLGtDQUFjLEVBQUU7QUFBQSxrQkFDbEI7QUFBQSxnQkFDRjtBQUFBLGdCQUNBLGNBQWMsTUFBTUEsY0FBYzJCLFdBQVc7QUFBQSxnQkFDN0MsV0FBVTtBQUFBO0FBQUEsY0FaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZNkc7QUFBQSxZQUU3RztBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFNLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWU7QUFBQSxnQkFDckIsU0FBUyxNQUFNM0IsY0FBYzJCLFdBQVc7QUFBQSxnQkFDeEMsV0FBVTtBQUFBLGdCQUEyRjtBQUFBO0FBQUEsY0FKdkc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxlQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdCQTtBQUFBLGFBdkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3RUE7QUFBQSxRQUdDd0QsY0FBYyxlQUFlLENBQUMxRSxhQUFhLHVCQUFDLDZCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0I7QUFBQSxRQUVuRWlPLFlBQVk7QUFBQSxRQUVaakosYUFBYSxXQUFXZ0Msb0JBQW9CLEVBQUVwQixTQUFTUixnQkFDdEQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxZQUFZTSxLQUFLQyxLQUFLcUIsb0JBQW9CLEVBQUVwQixTQUFTUixZQUFZO0FBQUEsWUFDakUsY0FBY3NHO0FBQUFBO0FBQUFBLFVBSGhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdpQztBQUFBLFdBdkZwQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEZEO0FBQUEsU0FyR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNHQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVc5RztBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkUsK0JBQXFCLENBQUMsQ0FBQztBQUFBLFFBQ3pCO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUseURBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsOENBQ2IsaUNBQUMsbUJBQWdCLFdBQVUsYUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBb0MsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSxtQ0FBa0Msc0NBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXNFO0FBQUEsY0FDdEUsdUJBQUMsT0FBRSxXQUFVLHlCQUF3QjtBQUFBO0FBQUEsZ0JBQ2pCO0FBQUEsZ0JBQ2xCLHVCQUFDLFVBQUssV0FBVSwyQkFBMkJmLDRCQUFrQjRCLFVBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9FO0FBQUEsZ0JBQU87QUFBQSxtQkFGN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGlCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxlQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBV0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxnRUFDWjVCLDRCQUFrQnFELElBQUksQ0FBQ0UsSUFBSUQsVUFBVTtBQUNwQyxrQkFBTUwsT0FBTzdILGNBQWMwUCxLQUFLLENBQUNwSSxNQUFNQSxFQUFFVCxRQUFRc0IsRUFBRTtBQUNuRCxnQkFBSSxDQUFDTixLQUFNLFFBQU87QUFDbEIsa0JBQU04SCxnQkFBZ0JqSyxrQkFBa0J5QyxFQUFFLEtBQUssQ0FBQztBQUNoRCxrQkFBTXlILGlCQUFpQkQsY0FBY3pELFdBQVdyRSxLQUFLdUMsa0JBQWtCdUI7QUFFdkUsbUJBQ0UsdUJBQUMsU0FBYSxXQUFVLHFGQUN0QjtBQUFBLHFDQUFDLFNBQUksV0FBVSx1R0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSx1R0FDWnpELGtCQUFRLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFNBQ0M7QUFBQSwyQ0FBQyxPQUFFLFdBQVUsdUNBQXVDTCxlQUFLTyxRQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4RDtBQUFBLG9CQUM5RCx1QkFBQyxPQUFFLFdBQVUsMEJBQTBCUCxlQUFLbEYsZ0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXlEO0FBQUEsdUJBRjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBR0E7QUFBQSxxQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsZ0JBQ0NrRixLQUFLVyxjQUNKLHVCQUFDLFNBQUksV0FBVSwwRUFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSx1RUFDYixpQ0FBQyxVQUFLLFdBQVUsd0NBQXdDWCxlQUFLVyxhQUFha0csT0FBTyxDQUFDLEdBQUdDLFlBQVksS0FBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUcsS0FEckc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSx5Q0FBeUM5RyxlQUFLVyxlQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF1RTtBQUFBLHFCQUp6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHVFQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLDRCQUEyQixNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2xGLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBWSxLQUFJLEdBQUUsdURBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdILEtBRDFIO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsc0NBQXFDLDBCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0RDtBQUFBLHFCQUo5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSx1Q0FBQyxTQUNDO0FBQUEseUNBQUMsV0FBTSxXQUFVLDBFQUF5RTtBQUFBO0FBQUEsb0JBQ2xGLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDO0FBQUEsc0JBQ0EsYUFBWTtBQUFBLHNCQUNaLE9BQU9vSCxrQkFBa0JqRTtBQUFBQSxzQkFDekIsVUFBVSxDQUFDdkMsVUFBVTJCLHVCQUF1QjVDLElBQUksV0FBV2lCLEtBQUs7QUFBQSxzQkFDaEUsV0FBVTtBQUFBLHNCQUNWLGNBQWMsQ0FBQ3lHLE9BQU9DLFlBQVlBLFFBQVExUSxTQUFTLElBQUltTCxZQUFZLEVBQUVDLFNBQVNxRixNQUFNdEYsWUFBWSxDQUFDO0FBQUEsc0JBQ2pHLFNBQVNqSixPQUFPMkcsSUFBSSxDQUFDOEgsV0FBVyxFQUFFM1EsT0FBTzJRLE1BQU10TixhQUFhc04sTUFBTTNILE1BQU1nQixPQUFPMkcsTUFBTWxKLElBQUksRUFBRTtBQUFBO0FBQUEsb0JBUDdGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPK0Y7QUFBQSxxQkFYakc7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLGdCQUVBLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsMEVBQXlFO0FBQUE7QUFBQSxvQkFDakYsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLHVCQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0E7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsYUFBWTtBQUFBLHNCQUNaLE9BQU84SSxjQUFjN0ksVUFBVTZFO0FBQUFBLHNCQUMvQixVQUFVLENBQUN2QyxVQUFVMkIsdUJBQXVCNUMsSUFBSSxVQUFVaUIsS0FBSztBQUFBLHNCQUMvRCxXQUFVO0FBQUEsc0JBQ1YsU0FBU25LLGVBQWVnSixJQUFJLENBQUMrSCxTQUFTLEVBQUU1USxPQUFPNFEsS0FBSzVHLE9BQU80RyxJQUFJLEVBQUU7QUFBQTtBQUFBLG9CQUxuRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBS3FFO0FBQUEscUJBVHZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBV0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsMEVBQXlFO0FBQUE7QUFBQSxvQkFDakY7QUFBQSxvQkFDTkwsY0FBYzdJLFVBQ2IsdUJBQUMsVUFBSyxXQUFVLDhEQUE2RCx5Q0FBN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBc0c7QUFBQSx1QkFIMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUMsTUFBTTtBQUFBLG9CQUFOO0FBQUEsc0JBQ0MsTUFBTTtBQUFBLHNCQUNOLGFBQWE2SSxjQUFjN0ksU0FBUyxJQUFJNkksY0FBYzdJLE1BQU0sa0NBQWtDO0FBQUEsc0JBQzlGLE9BQU82SSxjQUFjNUksVUFBVTtBQUFBLHNCQUMvQixVQUFVLENBQUNtQyxNQUFNNkIsdUJBQXVCNUMsSUFBSSxVQUFVZSxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsc0JBQ3BFLFdBQVU7QUFBQTtBQUFBLG9CQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLbUg7QUFBQSxxQkFackg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFjQTtBQUFBLGdCQUVDdUcsY0FBYzdJLFdBQVcsZUFDeEIsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLDJFQUEwRTtBQUFBO0FBQUEsb0JBQzFFLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE9BQU82SSxjQUFjakUsZUFBZTNNLE1BQU00USxjQUFjakUsWUFBWSxJQUFJO0FBQUEsc0JBQ3hFLFVBQVUsQ0FBQ3VFLEdBQUdDLGVBQWVuRix1QkFBdUI1QyxJQUFJLGdCQUFnQitILFVBQVU7QUFBQSxzQkFDbEYsV0FBVTtBQUFBLHNCQUNWLFFBQU87QUFBQSxzQkFDUCxhQUFZO0FBQUEsc0JBQ1osY0FBYyxDQUFDaEYsWUFBWUEsV0FBV0EsVUFBVW5NLE1BQU0sRUFBRW9SLFFBQVEsS0FBSztBQUFBO0FBQUEsb0JBTnZFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNeUU7QUFBQSxrQkFFekUsdUJBQUMsT0FBRSxXQUFVLG9DQUFtQyxzREFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0Y7QUFBQSxxQkFaeEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLG1CQTNESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTZEQTtBQUFBLGNBRUMsQ0FBQ1IsY0FBYzdJLFVBQVVlLEtBQUtkLFVBQzdCLHVCQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBLHVDQUFDLE9BQUUsV0FBVSxzRUFBcUUsK0JBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlHO0FBQUEsZ0JBQ2pHLHVCQUFDLE9BQUUsV0FBVSxxREFBcURjLGVBQUtkLFVBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQThFO0FBQUEsbUJBRmhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQSxpQkEvRk1vQixJQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUdBO0FBQUEsVUFFSixDQUFDLEtBM0dIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNEdBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsOERBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTLE1BQU07QUFDYjFDLHFDQUFtQixLQUFLO0FBQ3hCRSx1Q0FBcUIsQ0FBQyxDQUFDO0FBQUEsZ0JBQ3pCO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUEyRjtBQUFBO0FBQUEsY0FOdkc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBU0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVM3RTtBQUFBQSxnQkFDVCxTQUFTa0w7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUE2SztBQUFBO0FBQUEsY0FKekw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxlQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1CQTtBQUFBLGFBL0lGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnSkE7QUFBQTtBQUFBLE1BdkpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXdKQTtBQUFBLElBR0EsdUJBQUMsU0FBTSxXQUFXeEwsaUJBQWlCLFNBQVMsTUFBTUMsbUJBQW1CLEtBQUssR0FDeEUsaUNBQUMsU0FBSSxXQUFVLHlEQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHdDQUF1Qyx1Q0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RTtBQUFBLE1BQzVFLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVxTSxjQUFjLFlBQVUsTUFDNUQ7QUFBQSwrQkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG9EQUFtRCxxQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBeUU7QUFBQSxZQUN6RSx1QkFBQyxVQUFPLGFBQVksVUFBUyxPQUFPdkssZ0JBQWdCVSxTQUFTMEksUUFBVyxVQUFVLENBQUMyQixNQUFNZCxzQkFBc0IsU0FBU2MsQ0FBQyxHQUFHLFdBQVUsZUFDbkksV0FBQyxNQUFNLE1BQU0sT0FBTyxPQUFPLElBQUksRUFBRXJGO0FBQUFBLGNBQUksQ0FBQ21JLE1BQ3JDLHVCQUFDLE9BQU8sUUFBUCxFQUFzQixPQUFPQSxHQUFJQSxlQUFkQSxHQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBLFlBQ3JDLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxvREFBbUQ7QUFBQTtBQUFBLGNBQVUsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxSDtBQUFBLFlBQ3JILHVCQUFDLFNBQU0sTUFBSyxhQUFZLE9BQU83TixnQkFBZ0JFLFdBQVcsVUFBVWlLLG1CQUFtQixVQUFRLE1BQUMsV0FBVSxxQkFBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkg7QUFBQSxZQUMxSHJLLE9BQU9JLGFBQWEsdUJBQUMsT0FBRSxXQUFVLDZCQUE2QkosaUJBQU9JLGFBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJEO0FBQUEsZUFIbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxvREFBbUQscUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlFO0FBQUEsWUFDekUsdUJBQUMsU0FBTSxNQUFLLFNBQVEsTUFBSyxTQUFRLE9BQU9GLGdCQUFnQkcsT0FBTyxVQUFVZ0ssbUJBQW1CLFdBQVUscUJBQXRHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVIO0FBQUEsZUFGekg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxvREFBbUQ7QUFBQTtBQUFBLGNBQU0sdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFnQztBQUFBLGlCQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpSDtBQUFBLFlBQ2pILHVCQUFDLFNBQU0sTUFBSyxVQUFTLE1BQUssZ0JBQWUsT0FBT25LLGdCQUFnQkksY0FBYyxVQUFVK0osbUJBQW1CLFVBQVEsTUFBQyxXQUFVLHFCQUE5SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErSTtBQUFBLFlBQzlJckssT0FBT00sZ0JBQWdCLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJOLGlCQUFPTSxnQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBOEQ7QUFBQSxlQUh4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUlBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG9EQUFtRDtBQUFBO0FBQUEsY0FBTyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWdDO0FBQUEsaUJBQTNHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtIO0FBQUEsWUFDbEgsdUJBQUMsU0FBTSxNQUFLLGFBQVksT0FBT0osZ0JBQWdCUSxXQUFXLFVBQVUySixtQkFBbUIsVUFBUSxNQUFDLFdBQVUscUJBQTFHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJIO0FBQUEsZUFGN0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxvREFBbUQsbUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUEsWUFDdkUsdUJBQUMsU0FBTSxNQUFLLFVBQVMsT0FBT25LLGdCQUFnQlMsUUFBUSxVQUFVMEosbUJBQW1CLFdBQVUscUJBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTRHO0FBQUEsZUFGOUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUErQkE7QUFBQSxRQUNBLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsb0RBQW1EO0FBQUE7QUFBQSxZQUFRLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxlQUE1RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtSDtBQUFBLFVBQ25ILHVCQUFDLFNBQU0sTUFBSyxXQUFVLE9BQU9uSyxnQkFBZ0JNLFNBQVMsVUFBVTZKLG1CQUFtQixVQUFRLE1BQUMsV0FBVSxxQkFBdEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUg7QUFBQSxhQUZ6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLGlDQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsb0RBQW1ELHVCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyRTtBQUFBLFlBQzNFLHVCQUFDLFNBQU0sTUFBSyxXQUFVLE9BQU9uSyxnQkFBZ0JPLFNBQVMsVUFBVTRKLG1CQUFtQixXQUFVLHFCQUE3RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RztBQUFBLGVBRmhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxVQUNBLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsb0RBQW1ELDZCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFzRjtBQUFBLFlBQ3RGLHVCQUFDLFNBQU0sTUFBSyxlQUFjLE9BQU9uSyxnQkFBZ0JpQixhQUFhLFVBQVVrSixtQkFBbUIsV0FBVSxxQkFBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0g7QUFBQSxlQUZ4SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsVUFDQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLG9EQUFtRCxzQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEU7QUFBQSxZQUMxRSx1QkFBQyxVQUFPLGFBQVksVUFBUyxPQUFPbkssZ0JBQWdCVyxVQUFVeUksUUFBVyxVQUFVLENBQUMyQixNQUFNZCxzQkFBc0IsVUFBVWMsQ0FBQyxHQUFHLFdBQVUsZUFDckksV0FBQyxRQUFRLFFBQVEsRUFBRXJGO0FBQUFBLGNBQUksQ0FBQ29JLE1BQ3ZCLHVCQUFDLE9BQU8sUUFBUCxFQUFzQixPQUFPQSxHQUFJQSxlQUFkQSxHQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBLFlBQ3JDLEtBSEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLFVBQ0EsdUJBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxvREFBbUQsbUJBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVFO0FBQUEsWUFDdkUsdUJBQUMsU0FBTSxNQUFLLFFBQU8sTUFBSyxlQUFjLE9BQU85TixnQkFBZ0JhLGFBQWEsVUFBVXNKLG1CQUFtQixXQUFVLHFCQUFqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrSTtBQUFBLGVBRnBJO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBR0E7QUFBQSxhQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsNkRBQ2I7QUFBQSxpQ0FBQyxZQUFPLE1BQUssVUFBUyxTQUFTLE1BQU1qTSxtQkFBbUIsS0FBSyxHQUFHLFdBQVUsNEdBQTJHLHNCQUFyTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyTDtBQUFBLFVBQzNMLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFdBQVUsc0lBQXFJLCtCQUFySztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvTDtBQUFBLGFBRnRMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErREE7QUFBQSxTQWpFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0VBLEtBbkVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvRUE7QUFBQSxJQUdBLHVCQUFDLFNBQU0sV0FBV0gsaUJBQWlCLFNBQVMsTUFBTUMsbUJBQW1CLEtBQUssR0FDeEUsaUNBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFNBQUksV0FBVSxXQUFVLE1BQUssUUFBTyxRQUFPLGdCQUFlLFNBQVEsYUFDakUsaUNBQUMsVUFBSyxlQUFjLFNBQVEsZ0JBQWUsU0FBUSxhQUFZLEtBQUksR0FBRSxrSUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtTSxLQURyTTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSxtQ0FBa0MsK0JBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxXQU5qRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSw0QkFBMkI7QUFBQTtBQUFBLFFBQ04sdUJBQUMsVUFBSyxXQUFVLCtCQUErQkcsdUJBQWErQixhQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNFO0FBQUEsUUFBTztBQUFBLFdBRC9HO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsK0JBQUMsWUFBTyxNQUFLLFVBQVMsU0FBUyxNQUFNbEMsbUJBQW1CLEtBQUssR0FBRyxXQUFVLDRHQUEyRyxzQkFBckw7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyTDtBQUFBLFFBQzNMLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVNxTSxrQkFBa0IsV0FBVSw2SEFBNEgsOEJBQXZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcU07QUFBQSxXQUZ2TTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQkEsS0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtCQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVduRztBQUFBQSxRQUNYLFNBQVMsTUFBTUMseUJBQXlCLEtBQUs7QUFBQSxRQUU3QyxpQ0FBQyxTQUFJLFdBQVUseURBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsOENBQ2IsaUNBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNqRSxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLDRIQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2TCxLQUQvTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFFBQUcsV0FBVSxtQ0FBa0MsNkJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZEO0FBQUEsY0FDN0QsdUJBQUMsT0FBRSxXQUFVLHlCQUF3Qix1RUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEY7QUFBQSxpQkFGOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLDBFQUF5RTtBQUFBO0FBQUEsZ0JBQ2pGLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsYUFBWTtBQUFBLGtCQUNaLE9BQU9DLGlCQUFpQkcsVUFBVTZFO0FBQUFBLGtCQUNsQyxVQUFVLENBQUN2QyxVQUFVeEMsb0JBQW9CLENBQUFnRSxVQUFTLEVBQUUsR0FBR0EsTUFBTTlELFFBQVFzQyxNQUFNLEVBQUU7QUFBQSxrQkFDN0UsV0FBVTtBQUFBLGtCQUNWLFNBQVNuSyxlQUFlZ0osSUFBSSxDQUFBK0gsU0FBUSxFQUFFNVEsT0FBTzRRLEtBQUs1RyxPQUFPNEcsSUFBSSxFQUFFO0FBQUE7QUFBQSxnQkFMakU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS21FO0FBQUEsaUJBVHJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxZQUVBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsMEVBQXlFLHNCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDLE1BQU07QUFBQSxnQkFBTjtBQUFBLGtCQUNDLE1BQU07QUFBQSxrQkFDTixhQUFZO0FBQUEsa0JBQ1osT0FBT3JKLGlCQUFpQkk7QUFBQUEsa0JBQ3hCLFVBQVUsQ0FBQ21DLE1BQU10QyxvQkFBb0IsQ0FBQWdFLFVBQVMsRUFBRSxHQUFHQSxNQUFNN0QsUUFBUW1DLEVBQUVDLE9BQU9DLE1BQU0sRUFBRTtBQUFBLGtCQUNsRixXQUFVO0FBQUE7QUFBQSxnQkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLbUg7QUFBQSxpQkFUckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFXQTtBQUFBLFlBRUN6QyxpQkFBaUJHLFdBQVcsZUFDM0IsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSwyRUFBMEU7QUFBQTtBQUFBLGdCQUMxRSx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU9ILGlCQUFpQkssaUJBQWlCakksTUFBTTRILGlCQUFpQkssY0FBYyxJQUFJO0FBQUEsa0JBQ2xGLFVBQVUsQ0FBQ2lKLEdBQUdDLGVBQWV0SixvQkFBb0IsQ0FBQWdFLFVBQVMsRUFBRSxHQUFHQSxNQUFNNUQsZ0JBQWdCa0osV0FBVyxFQUFFO0FBQUEsa0JBQ2xHLFdBQVU7QUFBQSxrQkFDVixRQUFPO0FBQUEsa0JBQ1AsYUFBWTtBQUFBLGtCQUNaLGNBQWMsQ0FBQ2hGLFlBQVlBLFdBQVdBLFVBQVVuTSxNQUFNLEVBQUVvUixRQUFRLEtBQUs7QUFBQTtBQUFBLGdCQU52RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNeUU7QUFBQSxjQUV6RSx1QkFBQyxPQUFFLFdBQVUsb0NBQW1DLHNEQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRjtBQUFBLGlCQVp4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUEsZUF6Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEyQ0E7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSw4REFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFNBQVMsTUFBTXpKLHlCQUF5QixLQUFLO0FBQUEsZ0JBQzdDLFdBQVU7QUFBQSxnQkFBMkY7QUFBQTtBQUFBLGNBSHZHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxTQUFTTztBQUFBQSxnQkFDVCxTQUFTNEU7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUE2SztBQUFBO0FBQUEsY0FKekw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBT0E7QUFBQSxlQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ0JBO0FBQUEsYUExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTJFQTtBQUFBO0FBQUEsTUEvRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0ZBO0FBQUEsT0FqYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtiQTtBQUVKO0FBQUVoTSxHQWhxRElGLG9CQUFrQjtBQUFBMlEsS0FBbEIzUTtBQWtxRE4sZUFBZUE7QUFBbUIsSUFBQTJRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJNb2RhbCIsImFwaSIsIkRhdGFUYWJsZSIsIklucHV0IiwiU2VsZWN0IiwiRHJvcGRvd24iLCJCdXR0b24iLCJEYXRlUGlja2VyIiwiSW9NZE1vcmUiLCJNZEdyaWRWaWV3IiwiTWRWaWV3TGlzdCIsIk1kT3V0bGluZVRhYmxlUm93cyIsIk1kQXNzaWdubWVudEluZCIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIkNpcmN1bGFyTG9hZGVyIiwiaGFuZGxlRW5yb2xsbWVudFJlcXVlc3RQcmludCIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiZmllbGRTaXplIiwiQnJlYWRjcnVtYiIsImRheWpzIiwiU2VhcmNoT3V0bGluZWQiLCJTVEFUVVNfT1BUSU9OUyIsIlNUQVRVU19TVU1NQVJZX0NPTkZJRyIsImtleSIsImxhYmVsIiwiY29sb3IiLCJiZ0xpZ2h0IiwidGV4dENvbG9yIiwiaWNvbkNvbG9yIiwicmluZ0NvbG9yIiwiaWNvbiIsIlVuQXBwcm92ZWRDdXN0b21lciIsImhpZGVTaWRlYmFyIiwiX3MiLCJ1c2VycyIsInNldFVzZXJzIiwiZmlsdGVyZWRVc2VycyIsInNldEZpbHRlcmVkVXNlcnMiLCJzZWFyY2hUZXJtIiwic2V0U2VhcmNoVGVybSIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInNob3dNb2RhbERlbGV0ZSIsInNldFNob3dNb2RhbERlbGV0ZSIsInNob3dNb2RhbFVwZGF0ZSIsInNldFNob3dNb2RhbFVwZGF0ZSIsImN1cnJlbnRVc2VyIiwic2V0Q3VycmVudFVzZXIiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJpc1N1Ym1pdHRpbmciLCJzZXRJc1N1Ym1pdHRpbmciLCJjdXJyZW50VXBkYXRlVXNlciIsInNldEN1cnJlbnRVcGRhdGVVc2VyIiwic2VsZWN0ZWRHcm91cCIsInNldFNlbGVjdGVkR3JvdXAiLCJncm91cHMiLCJzZXRHcm91cHMiLCJhZG1pbnMiLCJzZXRBZG1pbnMiLCJhcmVhcyIsInNldEFyZWFzIiwiZGlzdHJpY3RzIiwic2V0RGlzdHJpY3RzIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJzZWFyY2hRdWVyeSIsInNldFNlYXJjaFF1ZXJ5IiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsImVycm9ycyIsInNldEVycm9ycyIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJmdWxsX25hbWUiLCJlbWFpbCIsInBob25lX251bWJlciIsInBhc3N3b3JkIiwiYWRkcmVzcyIsInBpbmNvZGUiLCJhZGhhYXJfbm8iLCJwYW5fbm8iLCJ0aXRsZSIsImdlbmRlciIsIm1hcml0YWxfc3RhdHVzIiwiZGF0ZW9mYmlydGgiLCJuYXRpb25hbGl0eSIsInZpbGxhZ2UiLCJ0YWx1ayIsImZhdGhlcl9uYW1lIiwiZGlzdHJpY3QiLCJzdGF0ZSIsImNvbGxlY3Rpb25fYXJlYSIsImFsdGVybmF0ZV9udW1iZXIiLCJyZWZlcnJhbF9uYW1lIiwibm9taW5lZV9uYW1lIiwibm9taW5lZV9kYXRlb2ZiaXJ0aCIsIm5vbWluZWVfcGhvbmVfbnVtYmVyIiwibm9taW5lZV9yZWxhdGlvbnNoaXAiLCJhYWRoYXJfZnJvbnRwaG90byIsImFhZGhhcl9iYWNrcGhvdG8iLCJwYW5fZnJvbnRwaG90byIsInBhbl9iYWNrcGhvdG8iLCJwcm9maWxlcGhvdG8iLCJiYW5rX25hbWUiLCJiYW5rX2JyYW5jaF9uYW1lIiwiYmFua19hY2NvdW50X251bWJlciIsImJhbmtfSUZTQ19jb2RlIiwic2VsZWN0ZWRfcGxhbiIsInNlbGVjdGVkQ3VzdG9tZXJzIiwic2V0U2VsZWN0ZWRDdXN0b21lcnMiLCJsYXN0Q2hlY2tlZElkIiwic2V0TGFzdENoZWNrZWRJZCIsInNob3dDb250YWN0TW9kYWwiLCJzZXRTaG93Q29udGFjdE1vZGFsIiwiY29udGFjdFJlYXNvbiIsInNldENvbnRhY3RSZWFzb24iLCJzZWxlY3RlZFN0YXR1cyIsInNldFNlbGVjdGVkU3RhdHVzIiwiYWN0aXZlVGFiIiwic2V0QWN0aXZlVGFiIiwic2hvd0FjdGlvbk1vZGFsIiwic2V0U2hvd0FjdGlvbk1vZGFsIiwiYWN0aW9uQXNzaWdubWVudHMiLCJzZXRBY3Rpb25Bc3NpZ25tZW50cyIsInZpZXdNb2RlIiwic2V0Vmlld01vZGUiLCJjdXJyZW50UGFnZSIsInNldEN1cnJlbnRQYWdlIiwiaXRlbXNQZXJQYWdlIiwiaW5kZXhPZkxhc3RJdGVtIiwiaW5kZXhPZkZpcnN0SXRlbSIsImN1cnJlbnRJdGVtcyIsInNsaWNlIiwidG90YWxQYWdlcyIsIk1hdGgiLCJjZWlsIiwibGVuZ3RoIiwic2hvd1N0YXR1c1VwZGF0ZU1vZGFsIiwic2V0U2hvd1N0YXR1c1VwZGF0ZU1vZGFsIiwic3RhdHVzVXBkYXRlRGF0YSIsInNldFN0YXR1c1VwZGF0ZURhdGEiLCJfaWQiLCJzdGF0dXMiLCJyZW1hcmsiLCJmb2xsb3dfdXBfZGF0ZSIsImlzU3RhdHVzVXBkYXRpbmciLCJzZXRJc1N0YXR1c1VwZGF0aW5nIiwiZ2V0U3RhdHVzQ291bnRzIiwiY29udGFjdGVkIiwiZmlsdGVyIiwidSIsInRvdGFsIiwiQ29udGFjdGVkIiwiSW50ZXJlc3RlZCIsIkNvbnZlcnRlZCIsIlJlamVjdGVkIiwiZ2V0VGFiRmlsdGVyZWRVc2VycyIsInVzZXIiLCJnZXRTdGF0dXNDb2xvciIsImdldFN0YXR1c0ljb24iLCJUYWJsZVVzZXJzIiwibWFwIiwiaW5kZXgiLCJpZCIsIm5hbWUiLCJjdXN0b21lcl9pZCIsImFwcHJvdmFsX3N0YXR1cyIsInN0YXR1c1JhdyIsImFzc2lnbmVkX3RvIiwiY3JlYXRlZEF0IiwiYWN0aW9uIiwiaXRlbXMiLCJoYW5kbGVVcGRhdGVNb2RhbE9wZW4iLCJoYW5kbGVEZWxldGVNb2RhbE9wZW4iLCJoYW5kbGVDdXN0b21lclN0YXR1cyIsImNvbHVtbnMiLCJoZWFkZXIiLCJHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInRhcmdldCIsInZhbHVlIiwiZmV0Y2hDb2xsZWN0aW9uQXJlYSIsImdldCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaERpc3RyaWN0cyIsImZldGNoQWRtaW5zIiwicmVzcG9uc2UiLCJmZXRjaFVzZXJzIiwiZm9ybWF0dGVkRGF0YSIsImdyb3VwIiwidW52ZXJmaWVkX2N1c3RvbWVyX2NvZGUiLCJzcGxpdCIsInJvdXRlX25hbWUiLCJmb3JtYXQiLCJhc3NpZ25lZF90b19pZCIsInN0YXR1c191cGRhdGVkX2F0IiwidXBkYXRlZEF0IiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInRvU3RyaW5nIiwiZmV0Y2hHcm91cERhdGEiLCJoYW5kbGVTZWxlY3RDdXN0b21lciIsInByZXYiLCJuZXdBcnIiLCJpIiwiaGFuZGxlQXNzaWdubWVudENoYW5nZSIsInVzZXJJZCIsImZpZWxkIiwiY3VycmVudCIsInVwZGF0ZWQiLCJwcmV2U3RhdHVzIiwiZXhpc3RpbmdSZW1hcmsiLCJleHRyYVJlbWFyayIsInN0YXJ0c1dpdGgiLCJ0cmltIiwicmVwbGFjZSIsImZvbGxvd1VwRGF0ZSIsInVuZGVmaW5lZCIsIm9wZW5TdGF0dXNVcGRhdGVNb2RhbCIsImhhbmRsZVN0YXR1c1VwZGF0ZVN1Ym1pdCIsInBheWxvYWQiLCJwdXQiLCJoYW5kbGVCdWxrQWN0aW9uU3VibWl0IiwiYXNzaWduIiwiYWRtaW5JZCIsInByb21pc2VzIiwiUHJvbWlzZSIsImFsbCIsImhhbmRsZVBhZ2VDaGFuZ2UiLCJwYWdlIiwiaGFuZGxlQW50SW5wdXREU2VsZWN0IiwicCIsImhhbmRsZUlucHV0Q2hhbmdlIiwicmVzIiwiaGFuZGxlRGVsZXRlVXNlciIsImRlbGV0ZSIsImhhbmRsZVVwZGF0ZSIsInByZXZlbnREZWZhdWx0IiwiZm1EYXRhIiwiRm9ybURhdGEiLCJPYmplY3QiLCJlbnRyaWVzIiwiZm9yRWFjaCIsImsiLCJ2IiwiYXBwZW5kIiwiaGVhZGVycyIsIkFjdGlvbkRyb3Bkb3duIiwiQ29udGFjdFN1bW1hcnlEYXNoYm9hcmQiLCJjb3VudHMiLCJwZW5kaW5nQ291bnQiLCJjb252ZXJzaW9uUmF0ZSIsInRvRml4ZWQiLCJyZWplY3Rpb25SYXRlIiwicGFyc2VGbG9hdCIsImNmZyIsImNvdW50IiwicGVyY2VudGFnZSIsIndpZHRoIiwicmVuZGVyQ3VzdG9tZXJDYXJkIiwiY3VzdG9tZXIiLCJpc1BlbmRpbmciLCJpc1NlbGVjdGVkIiwiaXNMYXN0Q2hlY2tlZCIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwiVXNlclJvdyIsInJlbmRlclVzZXJzIiwidGFiRmlsdGVyZWRVc2VycyIsInRhYkluZGV4T2ZMYXN0SXRlbSIsInRhYkluZGV4T2ZGaXJzdEl0ZW0iLCJ0YWJDdXJyZW50SXRlbXMiLCJ0YWJUb3RhbFBhZ2VzIiwiU2ltcGxlUGFnaW5hdGlvbiIsIm9uUGFnZUNoYW5nZSIsInBhZ2VzIiwibWF4IiwicHVzaCIsIm1pbiIsInZhbCIsImZpbmQiLCJjdXJyZW50QXNzaWduIiwicHJlRmlsbGVkQWRtaW4iLCJpbnB1dCIsIm9wdGlvbiIsImFkbWluIiwib3B0IiwiXyIsImRhdGVTdHJpbmciLCJzdGFydE9mIiwidCIsImciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJVbkFwcHJvdmVkQ3VzdG9tZXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCB7IElucHV0LCBTZWxlY3QsIERyb3Bkb3duLCBCdXR0b24sIERhdGVQaWNrZXIgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQge1xyXG4gIE1kR3JpZFZpZXcsXHJcbiAgTWRWaWV3TGlzdCxcclxuICBNZE91dGxpbmVUYWJsZVJvd3MsXHJcbiAgTWRBc3NpZ25tZW50SW5kLFxyXG59IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBoYW5kbGVFbnJvbGxtZW50UmVxdWVzdFByaW50IGZyb20gXCIuLi9jb21wb25lbnRzL3ByaW50Rm9ybWF0cy9lbnJvbGxtZW50UmVxdWVzdFByaW50XCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5pbXBvcnQgeyBTZWFyY2hPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5cclxuLy8gU3RhdHVzIG9wdGlvbnMgZnJvbSBiYWNrZW5kIGVudW1cclxuY29uc3QgU1RBVFVTX09QVElPTlMgPSBbXHJcbiAgXCJDb250YWN0ZWRcIixcclxuICBcIkludGVyZXN0ZWRcIixcclxuICBcIkZvbGxvdyBVcFwiLFxyXG4gIFwiQ29udmVydGVkXCIsXHJcbiAgXCJSZWplY3RlZFwiLFxyXG5dO1xyXG5cclxuXHJcbi8vIFN1bW1hcnkgY2FyZCBjb25maWcg4oCUIGljb25zLCBjb2xvcnMsIGxhYmVsc1xyXG5jb25zdCBTVEFUVVNfU1VNTUFSWV9DT05GSUcgPSBbXHJcbiAge1xyXG4gICAga2V5OiBcIkNvbnRhY3RlZFwiLFxyXG4gICAgbGFiZWw6IFwiQ29udGFjdGVkXCIsXHJcbiAgICBjb2xvcjogXCJmcm9tLWluZGlnby01MDAgdG8taW5kaWdvLTYwMFwiLFxyXG4gICAgYmdMaWdodDogXCJiZy1pbmRpZ28tNTBcIixcclxuICAgIHRleHRDb2xvcjogXCJ0ZXh0LWluZGlnby03MDBcIixcclxuICAgIGljb25Db2xvcjogXCJ0ZXh0LWluZGlnby01MDBcIixcclxuICAgIHJpbmdDb2xvcjogXCJyaW5nLWluZGlnby0xMDBcIixcclxuICAgIGljb246IChcclxuICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMyA1YTIgMiAwIDAxMi0yaDMuMjhhMSAxIDAgMDEuOTQ4LjY4NGwxLjQ5OCA0LjQ5M2ExIDEgMCAwMS0uNTAyIDEuMjFsLTIuMjU3IDEuMTNhMTEuMDQyIDExLjA0MiAwIDAwNS41MTYgNS41MTZsMS4xMy0yLjI1N2ExIDEgMCAwMTEuMjEtLjUwMmw0LjQ5MyAxLjQ5OGExIDEgMCAwMS42ODQuOTQ5VjE5YTIgMiAwIDAxLTIgMmgtMUM5LjcxNiAyMSAzIDE0LjI4NCAzIDZWNXpcIiAvPlxyXG4gICAgICA8L3N2Zz5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFwiSW50ZXJlc3RlZFwiLFxyXG4gICAgbGFiZWw6IFwiSW50ZXJlc3RlZFwiLFxyXG4gICAgY29sb3I6IFwiZnJvbS1ibHVlLTUwMCB0by1ibHVlLTYwMFwiLFxyXG4gICAgYmdMaWdodDogXCJiZy1ibHVlLTUwXCIsXHJcbiAgICB0ZXh0Q29sb3I6IFwidGV4dC1ibHVlLTcwMFwiLFxyXG4gICAgaWNvbkNvbG9yOiBcInRleHQtYmx1ZS01MDBcIixcclxuICAgIHJpbmdDb2xvcjogXCJyaW5nLWJsdWUtMTAwXCIsXHJcbiAgICBpY29uOiAoXHJcbiAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTExLjA0OSAyLjkyN2MuMy0uOTIxIDEuNjAzLS45MjEgMS45MDIgMGwxLjUxOSA0LjY3NGExIDEgMCAwMC45NS42OWg0LjkxNWMuOTY5IDAgMS4zNzEgMS4yNC41ODggMS44MWwtMy45NzYgMi44ODhhMSAxIDAgMDAtLjM2MyAxLjExOGwxLjUxOCA0LjY3NGMuMy45MjItLjc1NSAxLjY4OC0xLjUzOCAxLjExOGwtMy45NzYtMi44ODhhMSAxIDAgMDAtMS4xNzYgMGwtMy45NzYgMi44ODhjLS43ODMuNTctMS44MzgtLjE5Ny0xLjUzOC0xLjExOGwxLjUxOC00LjY3NGExIDEgMCAwMC0uMzYzLTEuMTE4bC0zLjk3Ni0yLjg4OGMtLjc4NC0uNTctLjM4LTEuODEuNTg4LTEuODFoNC45MTRhMSAxIDAgMDAuOTUxLS42OWwxLjUxOS00LjY3NHpcIiAvPlxyXG4gICAgICA8L3N2Zz5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFwiRm9sbG93IFVwXCIsXHJcbiAgICBsYWJlbDogXCJGb2xsb3cgVXBcIixcclxuICAgIGNvbG9yOiBcImZyb20tcHVycGxlLTUwMCB0by1wdXJwbGUtNjAwXCIsXHJcbiAgICBiZ0xpZ2h0OiBcImJnLXB1cnBsZS01MFwiLFxyXG4gICAgdGV4dENvbG9yOiBcInRleHQtcHVycGxlLTcwMFwiLFxyXG4gICAgaWNvbkNvbG9yOiBcInRleHQtcHVycGxlLTUwMFwiLFxyXG4gICAgcmluZ0NvbG9yOiBcInJpbmctcHVycGxlLTEwMFwiLFxyXG4gICAgaWNvbjogKFxyXG4gICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNSBoLTVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xMiA4djRsMyAzbTYtM2E5IDkgMCAxMS0xOCAwIDkgOSAwIDAxMTggMHpcIiAvPlxyXG4gICAgICA8L3N2Zz5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFwiQ29udmVydGVkXCIsXHJcbiAgICBsYWJlbDogXCJDb252ZXJ0ZWRcIixcclxuICAgIGNvbG9yOiBcImZyb20tZW1lcmFsZC01MDAgdG8tZ3JlZW4tNjAwXCIsXHJcbiAgICBiZ0xpZ2h0OiBcImJnLWVtZXJhbGQtNTBcIixcclxuICAgIHRleHRDb2xvcjogXCJ0ZXh0LWVtZXJhbGQtNzAwXCIsXHJcbiAgICBpY29uQ29sb3I6IFwidGV4dC1lbWVyYWxkLTUwMFwiLFxyXG4gICAgcmluZ0NvbG9yOiBcInJpbmctZW1lcmFsZC0xMDBcIixcclxuICAgIGljb246IChcclxuICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNOSAxMmwyIDIgNC00bTYgMmE5IDkgMCAxMS0xOCAwIDkgOSAwIDAxMTggMHpcIiAvPlxyXG4gICAgICA8L3N2Zz5cclxuICAgICksXHJcbiAgfSxcclxuICB7XHJcbiAgICBrZXk6IFwiUmVqZWN0ZWRcIixcclxuICAgIGxhYmVsOiBcIlJlamVjdGVkXCIsXHJcbiAgICBjb2xvcjogXCJmcm9tLXJlZC01MDAgdG8tcmVkLTYwMFwiLFxyXG4gICAgYmdMaWdodDogXCJiZy1yZWQtNTBcIixcclxuICAgIHRleHRDb2xvcjogXCJ0ZXh0LXJlZC03MDBcIixcclxuICAgIGljb25Db2xvcjogXCJ0ZXh0LXJlZC01MDBcIixcclxuICAgIHJpbmdDb2xvcjogXCJyaW5nLXJlZC0xMDBcIixcclxuICAgIGljb246IChcclxuICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTAgMTRsMi0ybTAgMGwyLTJtLTIgMmwtMi0ybTIgMmwyIDJtNy0yYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiIC8+XHJcbiAgICAgIDwvc3ZnPlxyXG4gICAgKSxcclxuICB9LFxyXG5dO1xyXG5cclxuY29uc3QgVW5BcHByb3ZlZEN1c3RvbWVyID0gKHsgaGlkZVNpZGViYXIgPSBmYWxzZSB9KSA9PiB7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkVXNlcnMsIHNldEZpbHRlcmVkVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXNlciwgc2V0Q3VycmVudFVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlVXNlciwgc2V0Q3VycmVudFVwZGF0ZVVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXAsIHNldFNlbGVjdGVkR3JvdXBdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FkbWlucywgc2V0QWRtaW5zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYXJlYXMsIHNldEFyZWFzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZGlzdHJpY3RzLCBzZXREaXN0cmljdHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtyZWxvYWRUcmlnZ2VyLCBzZXRSZWxvYWRUcmlnZ2VyXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2Vycm9ycywgc2V0RXJyb3JzXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGZ1bGxfbmFtZTogXCJcIixcclxuICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgcGhvbmVfbnVtYmVyOiBcIlwiLFxyXG4gICAgcGFzc3dvcmQ6IFwiXCIsXHJcbiAgICBhZGRyZXNzOiBcIlwiLFxyXG4gICAgcGluY29kZTogXCJcIixcclxuICAgIGFkaGFhcl9ubzogXCJcIixcclxuICAgIHBhbl9ubzogXCJcIixcclxuICAgIHRpdGxlOiBcIlwiLFxyXG4gICAgZ2VuZGVyOiBcIlwiLFxyXG4gICAgbWFyaXRhbF9zdGF0dXM6IFwiXCIsXHJcbiAgICBkYXRlb2ZiaXJ0aDogXCJcIixcclxuICAgIG5hdGlvbmFsaXR5OiBcIlwiLFxyXG4gICAgdmlsbGFnZTogXCJcIixcclxuICAgIHRhbHVrOiBcIlwiLFxyXG4gICAgZmF0aGVyX25hbWU6IFwiXCIsXHJcbiAgICBkaXN0cmljdDogXCJcIixcclxuICAgIHN0YXRlOiBcIlwiLFxyXG4gICAgY29sbGVjdGlvbl9hcmVhOiBcIlwiLFxyXG4gICAgYWx0ZXJuYXRlX251bWJlcjogXCJcIixcclxuICAgIHJlZmVycmFsX25hbWU6IFwiXCIsXHJcbiAgICBub21pbmVlX25hbWU6IFwiXCIsXHJcbiAgICBub21pbmVlX2RhdGVvZmJpcnRoOiBcIlwiLFxyXG4gICAgbm9taW5lZV9waG9uZV9udW1iZXI6IFwiXCIsXHJcbiAgICBub21pbmVlX3JlbGF0aW9uc2hpcDogXCJcIixcclxuICAgIGFhZGhhcl9mcm9udHBob3RvOiBcIlwiLFxyXG4gICAgYWFkaGFyX2JhY2twaG90bzogXCJcIixcclxuICAgIHBhbl9mcm9udHBob3RvOiBcIlwiLFxyXG4gICAgcGFuX2JhY2twaG90bzogXCJcIixcclxuICAgIHByb2ZpbGVwaG90bzogXCJcIixcclxuICAgIGJhbmtfbmFtZTogXCJcIixcclxuICAgIGJhbmtfYnJhbmNoX25hbWU6IFwiXCIsXHJcbiAgICBiYW5rX2FjY291bnRfbnVtYmVyOiBcIlwiLFxyXG4gICAgYmFua19JRlNDX2NvZGU6IFwiXCIsXHJcbiAgICBzZWxlY3RlZF9wbGFuOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICAvLyBTRUxFQ1RJT04gJiBUQUIgU1RBVEVTXHJcbiAgY29uc3QgW3NlbGVjdGVkQ3VzdG9tZXJzLCBzZXRTZWxlY3RlZEN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2xhc3RDaGVja2VkSWQsIHNldExhc3RDaGVja2VkSWRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dDb250YWN0TW9kYWwsIHNldFNob3dDb250YWN0TW9kYWxdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjb250YWN0UmVhc29uLCBzZXRDb250YWN0UmVhc29uXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZFN0YXR1cywgc2V0U2VsZWN0ZWRTdGF0dXNdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKFwicGVuZGluZ1wiKTtcclxuXHJcbiAgLy8gQWN0aW9uIE1vZGFsIFN0YXRlc1xyXG4gIGNvbnN0IFtzaG93QWN0aW9uTW9kYWwsIHNldFNob3dBY3Rpb25Nb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FjdGlvbkFzc2lnbm1lbnRzLCBzZXRBY3Rpb25Bc3NpZ25tZW50c10gPSB1c2VTdGF0ZSh7fSk7XHJcblxyXG4gIC8vIFZpZXcgJiBQYWdpbmF0aW9uIFN0YXRlc1xyXG4gIGNvbnN0IFt2aWV3TW9kZSwgc2V0Vmlld01vZGVdID0gdXNlU3RhdGUoXCJncmlkXCIpO1xyXG4gIGNvbnN0IFtjdXJyZW50UGFnZSwgc2V0Q3VycmVudFBhZ2VdID0gdXNlU3RhdGUoMSk7XHJcbiAgY29uc3QgW2l0ZW1zUGVyUGFnZV0gPSB1c2VTdGF0ZSg5KTtcclxuXHJcbiAgY29uc3QgaW5kZXhPZkxhc3RJdGVtID0gY3VycmVudFBhZ2UgKiBpdGVtc1BlclBhZ2U7XHJcbiAgY29uc3QgaW5kZXhPZkZpcnN0SXRlbSA9IGluZGV4T2ZMYXN0SXRlbSAtIGl0ZW1zUGVyUGFnZTtcclxuICBjb25zdCBjdXJyZW50SXRlbXMgPSBmaWx0ZXJlZFVzZXJzLnNsaWNlKGluZGV4T2ZGaXJzdEl0ZW0sIGluZGV4T2ZMYXN0SXRlbSk7XHJcbiAgY29uc3QgdG90YWxQYWdlcyA9IE1hdGguY2VpbChmaWx0ZXJlZFVzZXJzLmxlbmd0aCAvIGl0ZW1zUGVyUGFnZSk7XHJcblxyXG4gIC8vIEZvciBzdGF0dXMgdXBkYXRlIG1vZGFsXHJcbiAgY29uc3QgW3Nob3dTdGF0dXNVcGRhdGVNb2RhbCwgc2V0U2hvd1N0YXR1c1VwZGF0ZU1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc3RhdHVzVXBkYXRlRGF0YSwgc2V0U3RhdHVzVXBkYXRlRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBfaWQ6ICcnLFxyXG4gICAgc3RhdHVzOiAnJyxcclxuICAgIHJlbWFyazogJycsXHJcbiAgICBmb2xsb3dfdXBfZGF0ZTogJycsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2lzU3RhdHVzVXBkYXRpbmcsIHNldElzU3RhdHVzVXBkYXRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyDilIDilIDilIAgU1RBVFVTIENPVU5UUyBGT1IgU1VNTUFSWSDilIDilIDilIBcclxuICBjb25zdCBnZXRTdGF0dXNDb3VudHMgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBjb250YWN0ZWQgPSBmaWx0ZXJlZFVzZXJzLmZpbHRlcihcclxuICAgICAgKHUpID0+IHUuc3RhdHVzICYmIHUuc3RhdHVzICE9PSBcIk5vdCBDb250YWN0ZWRcIlxyXG4gICAgKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHRvdGFsOiBjb250YWN0ZWQubGVuZ3RoLFxyXG4gICAgICBDb250YWN0ZWQ6IGNvbnRhY3RlZC5maWx0ZXIoKHUpID0+IHUuc3RhdHVzID09PSBcIkNvbnRhY3RlZFwiKS5sZW5ndGgsXHJcbiAgICAgIEludGVyZXN0ZWQ6IGNvbnRhY3RlZC5maWx0ZXIoKHUpID0+IHUuc3RhdHVzID09PSBcIkludGVyZXN0ZWRcIikubGVuZ3RoLFxyXG4gICAgICBcIkZvbGxvdyBVcFwiOiBjb250YWN0ZWQuZmlsdGVyKCh1KSA9PiB1LnN0YXR1cyA9PT0gXCJGb2xsb3cgVXBcIikubGVuZ3RoLFxyXG4gICAgICBDb252ZXJ0ZWQ6IGNvbnRhY3RlZC5maWx0ZXIoKHUpID0+IHUuc3RhdHVzID09PSBcIkNvbnZlcnRlZFwiKS5sZW5ndGgsXHJcbiAgICAgIFJlamVjdGVkOiBjb250YWN0ZWQuZmlsdGVyKCh1KSA9PiB1LnN0YXR1cyA9PT0gXCJSZWplY3RlZFwiKS5sZW5ndGgsXHJcbiAgICB9O1xyXG4gIH07XHJcblxyXG4gIC8vIEZpbHRlciB1c2VycyBiYXNlZCBvbiBhY3RpdmUgdGFiIChzdGF0dXMpXHJcbiAgY29uc3QgZ2V0VGFiRmlsdGVyZWRVc2VycyA9ICgpID0+IHtcclxuICAgIGlmIChhY3RpdmVUYWIgPT09IFwicGVuZGluZ1wiKSB7XHJcbiAgICAgIHJldHVybiBmaWx0ZXJlZFVzZXJzLmZpbHRlcihcclxuICAgICAgICAodXNlcikgPT4gdXNlci5zdGF0dXMgPT09IFwiTm90IENvbnRhY3RlZFwiIHx8ICF1c2VyLnN0YXR1c1xyXG4gICAgICApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmV0dXJuIGZpbHRlcmVkVXNlcnMuZmlsdGVyKFxyXG4gICAgICAgICh1c2VyKSA9PiB1c2VyLnN0YXR1cyAmJiB1c2VyLnN0YXR1cyAhPT0gXCJOb3QgQ29udGFjdGVkXCJcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRTdGF0dXNDb2xvciA9IChzdGF0dXMpID0+IHtcclxuICAgIHN3aXRjaCAoc3RhdHVzKSB7XHJcbiAgICAgIGNhc2UgXCJBcHByb3ZlZFwiOlxyXG4gICAgICAgIHJldHVybiBcImJnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTcwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLWVtZXJhbGQtNjAwLzIwXCI7XHJcbiAgICAgIGNhc2UgXCJQZW5kaW5nXCI6XHJcbiAgICAgICAgcmV0dXJuIFwiYmctYW1iZXItNTAgdGV4dC1hbWJlci03MDAgcmluZy0xIHJpbmctaW5zZXQgcmluZy1hbWJlci02MDAvMjBcIjtcclxuICAgICAgY2FzZSBcIkludGVyZXN0ZWRcIjpcclxuICAgICAgICByZXR1cm4gXCJiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDAgcmluZy0xIHJpbmctaW5zZXQgcmluZy1ibHVlLTYwMC8yMFwiO1xyXG4gICAgICBjYXNlIFwiTm90IEludGVyZXN0ZWRcIjpcclxuICAgICAgICByZXR1cm4gXCJiZy1ncmF5LTUwIHRleHQtZ3JheS02MDAgcmluZy0xIHJpbmctaW5zZXQgcmluZy1ncmF5LTUwMC8yMFwiO1xyXG4gICAgICBjYXNlIFwiQ29udGFjdGVkXCI6XHJcbiAgICAgICAgcmV0dXJuIFwiYmctaW5kaWdvLTUwIHRleHQtaW5kaWdvLTcwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLWluZGlnby02MDAvMjBcIjtcclxuICAgICAgY2FzZSBcIkZvbGxvdyBVcFwiOlxyXG4gICAgICAgIHJldHVybiBcImJnLXB1cnBsZS01MCB0ZXh0LXB1cnBsZS03MDAgcmluZy0xIHJpbmctaW5zZXQgcmluZy1wdXJwbGUtNjAwLzIwXCI7XHJcbiAgICAgIGNhc2UgXCJDb252ZXJ0ZWRcIjpcclxuICAgICAgICByZXR1cm4gXCJiZy1ncmVlbi01MCB0ZXh0LWdyZWVuLTcwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLWdyZWVuLTYwMC8yMFwiO1xyXG4gICAgICBjYXNlIFwiUmVqZWN0ZWRcIjpcclxuICAgICAgICByZXR1cm4gXCJiZy1yZWQtNTAgdGV4dC1yZWQtNzAwIHJpbmctMSByaW5nLWluc2V0IHJpbmctcmVkLTYwMC8yMFwiO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHJldHVybiBcImJnLWdyYXktNTAgdGV4dC1ncmF5LTYwMCByaW5nLTEgcmluZy1pbnNldCByaW5nLWdyYXktNTAwLzIwXCI7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0U3RhdHVzSWNvbiA9IChzdGF0dXMpID0+IHtcclxuICAgIHN3aXRjaCAoc3RhdHVzKSB7XHJcbiAgICAgIGNhc2UgXCJDb250YWN0ZWRcIjpcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTMgNWEyIDIgMCAwMTItMmgzLjI4YTEgMSAwIDAxLjk0OC42ODRsMS40OTggNC40OTNhMSAxIDAgMDEtLjUwMiAxLjIxbC0yLjI1NyAxLjEzYTExLjA0MiAxMS4wNDIgMCAwMDUuNTE2IDUuNTE2bDEuMTMtMi4yNTdhMSAxIDAgMDExLjIxLS41MDJsNC40OTMgMS40OThhMSAxIDAgMDEuNjg0Ljk0OVYxOWEyIDIgMCAwMS0yIDJoLTFDOS43MTYgMjEgMyAxNC4yODQgMyA2VjV6XCIgLz5cclxuICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICk7XHJcbiAgICAgIGNhc2UgXCJJbnRlcmVzdGVkXCI6XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xMS4wNDkgMi45MjdjLjMtLjkyMSAxLjYwMy0uOTIxIDEuOTAyIDBsMS41MTkgNC42NzRhMSAxIDAgMDAuOTUuNjloNC45MTVjLjk2OSAwIDEuMzcxIDEuMjQuNTg4IDEuODFsLTMuOTc2IDIuODg4YTEgMSAwIDAwLS4zNjMgMS4xMThsMS41MTggNC42NzRjLjMuOTIyLS43NTUgMS42ODgtMS41MzggMS4xMThsLTMuOTc2LTIuODg4YTEgMSAwIDAwLTEuMTc2IDBsLTMuOTc2IDIuODg4Yy0uNzgzLjU3LTEuODM4LS4xOTctMS41MzgtMS4xMThsMS41MTgtNC42NzRhMSAxIDAgMDAtLjM2My0xLjExOGwtMy45NzYtMi44ODhjLS43ODQtLjU3LS4zOC0xLjgxLjU4OC0xLjgxaDQuOTE0YTEgMSAwIDAwLjk1MS0uNjlsMS41MTktNC42NzR6XCIgLz5cclxuICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICk7XHJcbiAgICAgIGNhc2UgXCJGb2xsb3cgVXBcIjpcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTEyIDh2NGwzIDNtNi0zYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiIC8+XHJcbiAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICApO1xyXG4gICAgICBjYXNlIFwiQ29udmVydGVkXCI6XHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk05IDEybDIgMiA0LTRtNiAyYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiIC8+XHJcbiAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICApO1xyXG4gICAgICBjYXNlIFwiUmVqZWN0ZWRcIjpcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTEwIDE0bDItMm0wIDBsMi0ybS0yIDJsLTItMm0yIDJsMiAybTctMmE5IDkgMCAxMS0xOCAwIDkgOSAwIDAxMTggMHpcIiAvPlxyXG4gICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgKTtcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBUYWJsZSBkYXRhIG1hcHBpbmcgd2l0aCBuZXcgZmllbGRzXHJcbiAgY29uc3QgVGFibGVVc2VycyA9IGZpbHRlcmVkVXNlcnMubWFwKCh1c2VyLCBpbmRleCkgPT4gKHtcclxuICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICBfaWQ6IHVzZXIuX2lkLFxyXG4gICAgbmFtZTogdXNlci5uYW1lLFxyXG4gICAgcGhvbmVfbnVtYmVyOiB1c2VyLnBob25lX251bWJlcixcclxuICAgIGN1c3RvbWVyX2lkOiB1c2VyLmN1c3RvbWVyX2lkLFxyXG4gICAgYWRkcmVzczogdXNlci5hZGRyZXNzLFxyXG4gICAgYXBwcm92YWxfc3RhdHVzOiAoXHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LXNlbWlib2xkICR7Z2V0U3RhdHVzQ29sb3IodXNlci5hcHByb3ZhbF9zdGF0dXMpfWB9PlxyXG4gICAgICAgIHt1c2VyLmFwcHJvdmFsX3N0YXR1c31cclxuICAgICAgPC9zcGFuPlxyXG4gICAgKSxcclxuICAgIHN0YXR1czogKFxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0zIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZCAke2dldFN0YXR1c0NvbG9yKHVzZXIuc3RhdHVzIHx8IFwiTm90IENvbnRhY3RlZFwiKX1gfT5cclxuICAgICAgICB7dXNlci5zdGF0dXMgfHwgXCJOb3QgQ29udGFjdGVkXCJ9XHJcbiAgICAgIDwvc3Bhbj5cclxuICAgICksXHJcbiAgICBzdGF0dXNSYXc6IHVzZXIuc3RhdHVzIHx8IFwiTm90IENvbnRhY3RlZFwiLFxyXG4gICAgcmVtYXJrOiB1c2VyLnJlbWFyayA/IChcclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNjAwIG1heC13LVsyMDBweF0gdHJ1bmNhdGUgYmxvY2tcIiB0aXRsZT17dXNlci5yZW1hcmt9PlxyXG4gICAgICAgIHt1c2VyLnJlbWFya31cclxuICAgICAgPC9zcGFuPlxyXG4gICAgKSA6IChcclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+4oCUPC9zcGFuPlxyXG4gICAgKSxcclxuICAgIGFzc2lnbmVkX3RvOiB1c2VyLmFzc2lnbmVkX3RvID8gKFxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtaW5kaWdvLTcwMCBiZy1pbmRpZ28tNTAgcHgtMiBweS0xIHJvdW5kZWQtZnVsbFwiPlxyXG4gICAgICAgIHt1c2VyLmFzc2lnbmVkX3RvfVxyXG4gICAgICA8L3NwYW4+XHJcbiAgICApIDogKFxyXG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS00MDBcIj7igJQ8L3NwYW4+XHJcbiAgICApLFxyXG4gICAgZm9sbG93X3VwX2RhdGU6IHVzZXIuZm9sbG93X3VwX2RhdGUgPyAoXHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1wdXJwbGUtNzAwIGJnLXB1cnBsZS01MCBweC0yIHB5LTEgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAge3VzZXIuZm9sbG93X3VwX2RhdGV9XHJcbiAgICAgIDwvc3Bhbj5cclxuICAgICkgOiAoXHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMFwiPuKAlDwvc3Bhbj5cclxuICAgICksXHJcbiAgICBjcmVhdGVkQXQ6IHVzZXIuY3JlYXRlZEF0LFxyXG4gICAgY29sbGVjdGlvbl9hcmVhOiB1c2VyLmNvbGxlY3Rpb25fYXJlYSxcclxuICAgIGFjdGlvbjogKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCBmb250LW1lZGl1bSBjdXJzb3ItcG9pbnRlciBweC0yIHB5LTFcIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4odXNlci5faWQpfT5FZGl0PC9kaXY+XHJcbiAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIGZvbnQtbWVkaXVtIGN1cnNvci1wb2ludGVyIHB4LTIgcHktMVwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3Blbih1c2VyLl9pZCl9PkRlbGV0ZTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS03MDAgZm9udC1tZWRpdW0gY3Vyc29yLXBvaW50ZXIgcHgtMiBweS0xXCIgb25DbGljaz17KCkgPT4gaGFuZGxlRW5yb2xsbWVudFJlcXVlc3RQcmludCh1c2VyLl9pZCl9PlByaW50PC9kaXY+XHJcbiAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAga2V5OiBcIjRcIixcclxuICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Bmb250LW1lZGl1bSBjdXJzb3ItcG9pbnRlciBweC0yIHB5LTEgJHt1c2VyLmFwcHJvdmFsX3N0YXR1cyAhPT0gXCJBcHByb3ZlZFwiID8gXCJ0ZXh0LWVtZXJhbGQtNjAwXCIgOiBcInRleHQtcmVkLTYwMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ3VzdG9tZXJTdGF0dXModXNlci5faWQsIHVzZXIuYXBwcm92YWxfc3RhdHVzICE9PSBcIkFwcHJvdmVkXCIgPyBcIkFwcHJvdmVkXCIgOiBcIlBlbmRpbmdcIil9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7dXNlci5hcHByb3ZhbF9zdGF0dXMgIT09IFwiQXBwcm92ZWRcIiA/IFwiQXBwcm92ZVwiIDogXCJVbmFwcHJvdmVcIn1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tUmlnaHRcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtbGcgaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICksXHJcbiAgfSkpO1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJ1bnZlcmZpZWRfY3VzdG9tZXJfY29kZVwiLCBoZWFkZXI6IFwiQ29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJGdWxsIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZVwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9pZFwiLCBoZWFkZXI6IFwiSURcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWRkcmVzc1wiLCBoZWFkZXI6IFwiQWRkcmVzc1wiIH0sXHJcbiAgICB7IGtleTogXCJjb2xsZWN0aW9uX2FyZWFcIiwgaGVhZGVyOiBcIkFyZWFcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXBwcm92YWxfc3RhdHVzXCIsIGhlYWRlcjogXCJBcHByb3ZhbFwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIkNvbnRhY3QgU3RhdHVzXCIgfSxcclxuICAgIHsga2V5OiBcImFzc2lnbmVkX3RvXCIsIGhlYWRlcjogXCJBc3NpZ25lZCBUb1wiIH0sXHJcbiAgICB7IGtleTogXCJyZW1hcmtcIiwgaGVhZGVyOiBcIlJlbWFya1wiIH0sXHJcbiAgICB7IGtleTogXCJmb2xsb3dfdXBfZGF0ZVwiLCBoZWFkZXI6IFwiRm9sbG93IFVwXCIgfSxcclxuICAgIHsga2V5OiBcImNyZWF0ZWRBdFwiLCBoZWFkZXI6IFwiSm9pbmVkXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uc1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiBzZXRTZWFyY2hUZXJtKGUudGFyZ2V0LnZhbHVlKTtcclxuXHJcbiAgLy8gLS0tIERBVEEgRkVUQ0hJTkcgLS0tXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQ29sbGVjdGlvbkFyZWEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0QXJlYXMoKGF3YWl0IGFwaS5nZXQoXCIvY29sbGVjdGlvbi1hcmVhLXJlcXVlc3QvZ2V0LWNvbGxlY3Rpb24tYXJlYS1kYXRhXCIpKS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQ29sbGVjdGlvbkFyZWEoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hEaXN0cmljdHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0RGlzdHJpY3RzKChhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZGlzdHJpY3RcIikpLmRhdGE/LmRhdGE/LmRpc3RyaWN0cyk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaERpc3RyaWN0cygpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEFkbWlucyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWRtaW4vZ2V0LXN1Yi1hZG1pbnNcIik7XHJcbiAgICAgICAgc2V0QWRtaW5zKHJlc3BvbnNlLmRhdGEgfHwgW10pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggYWRtaW5zXCIsIGVycm9yKTtcclxuICAgICAgICBzZXRBZG1pbnMoW10pO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBZG1pbnMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvYXBwcm92YWwtc3RhdHVzL2ZhbHNlXCIpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgdW52ZXJmaWVkX2N1c3RvbWVyX2NvZGU6IGdyb3VwPy51bnZlcmZpZWRfY3VzdG9tZXJfY29kZSxcclxuICAgICAgICAgIG5hbWU6IGdyb3VwLmZ1bGxfbmFtZSxcclxuICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXAucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgY3JlYXRlZEF0OiBncm91cC5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgIGFkZHJlc3M6IGdyb3VwLmFkZHJlc3MsXHJcbiAgICAgICAgICBwaW5jb2RlOiBncm91cC5waW5jb2RlLFxyXG4gICAgICAgICAgY3VzdG9tZXJfaWQ6IGdyb3VwLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgY29sbGVjdGlvbl9hcmVhOiBncm91cC5jb2xsZWN0aW9uX2FyZWE/LnJvdXRlX25hbWUsXHJcbiAgICAgICAgICBhcHByb3ZhbF9zdGF0dXM6IGdyb3VwLmFwcHJvdmFsX3N0YXR1cyA9PT0gXCJ0cnVlXCIgPyBcIkFwcHJvdmVkXCIgOiBcIlBlbmRpbmdcIixcclxuICAgICAgICAgIHN0YXR1czogZ3JvdXAuc3RhdHVzIHx8IFwiTm90IENvbnRhY3RlZFwiLFxyXG4gICAgICAgICAgcmVtYXJrOiBncm91cC5yZW1hcmsgfHwgXCJcIixcclxuICAgICAgICAgIGZvbGxvd191cF9kYXRlOiBncm91cC5mb2xsb3dfdXBfZGF0ZSA/IGRheWpzKGdyb3VwLmZvbGxvd191cF9kYXRlKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpIDogXCJcIixcclxuICAgICAgICAgIGFzc2lnbmVkX3RvOiBncm91cC5hc3NpZ25lZF90bz8uZnVsbF9uYW1lIHx8IGdyb3VwLmFzc2lnbmVkX3RvPy5uYW1lIHx8IFwiXCIsXHJcbiAgICAgICAgICBhc3NpZ25lZF90b19pZDogZ3JvdXAuYXNzaWduZWRfdG8/Ll9pZCB8fCBcIlwiLFxyXG4gICAgICAgICAgc3RhdHVzX3VwZGF0ZWRfYXQ6IGdyb3VwLnVwZGF0ZWRBdCA/IGRheWpzKGdyb3VwLnVwZGF0ZWRBdCkuZm9ybWF0KFwiWVlZWS1NTS1ERCBISDptbVwiKSA6IFwiXCIsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkVXNlcnMoXHJcbiAgICAgICAgICBmb3JtYXR0ZWREYXRhLmZpbHRlcihcclxuICAgICAgICAgICAgKHVzZXIpID0+XHJcbiAgICAgICAgICAgICAgdXNlci5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKSB8fFxyXG4gICAgICAgICAgICAgIHVzZXIucGhvbmVfbnVtYmVyLnRvU3RyaW5nKCkuaW5jbHVkZXMoc2VhcmNoVGVybSlcclxuICAgICAgICAgIClcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldEN1cnJlbnRQYWdlKDEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IubWVzc2FnZSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoVXNlcnMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlciwgc2VhcmNoVGVybV0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0R3JvdXBzKChhd2FpdCBhcGkuZ2V0KFwiZ3JvdXAvZ2V0LWdyb3VwLWFkbWluXCIpKS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoR3JvdXBEYXRhKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgLy8gLS0tIEhBTkRMRVJTIC0tLVxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdEN1c3RvbWVyID0gKGlkKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEN1c3RvbWVycygocHJldikgPT4ge1xyXG4gICAgICBpZiAocHJldi5pbmNsdWRlcyhpZCkpIHtcclxuICAgICAgICBjb25zdCBuZXdBcnIgPSBwcmV2LmZpbHRlcigoaSkgPT4gaSAhPT0gaWQpO1xyXG4gICAgICAgIHNldExhc3RDaGVja2VkSWQobmV3QXJyLmxlbmd0aCA+IDAgPyBuZXdBcnJbbmV3QXJyLmxlbmd0aCAtIDFdIDogbnVsbCk7XHJcbiAgICAgICAgcmV0dXJuIG5ld0FycjtcclxuICAgICAgfVxyXG4gICAgICBpZiAocHJldi5sZW5ndGggPj0gMTApIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJZb3UgY2FuIHNlbGVjdCBhIG1heGltdW0gb2YgMTAgY3VzdG9tZXJzIGF0IGEgdGltZS5cIixcclxuICAgICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiBwcmV2O1xyXG4gICAgICB9XHJcbiAgICAgIHNldExhc3RDaGVja2VkSWQoaWQpO1xyXG4gICAgICByZXR1cm4gWy4uLnByZXYsIGlkXTtcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFzc2lnbm1lbnRDaGFuZ2UgPSAodXNlcklkLCBmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIHNldEFjdGlvbkFzc2lnbm1lbnRzKChwcmV2KSA9PiB7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnQgPSBwcmV2W3VzZXJJZF0gfHwge307XHJcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSB7IC4uLmN1cnJlbnQsIFtmaWVsZF06IHZhbHVlIH07XHJcblxyXG4gICAgICBpZiAoZmllbGQgPT09IFwic3RhdHVzXCIgJiYgdmFsdWUpIHtcclxuICAgICAgICBjb25zdCBwcmV2U3RhdHVzID0gY3VycmVudC5zdGF0dXM7XHJcbiAgICAgICAgY29uc3QgZXhpc3RpbmdSZW1hcmsgPSBjdXJyZW50LnJlbWFyayB8fCBcIlwiO1xyXG5cclxuICAgICAgICBsZXQgZXh0cmFSZW1hcmsgPSBcIlwiO1xyXG4gICAgICAgIGlmIChwcmV2U3RhdHVzICYmIGV4aXN0aW5nUmVtYXJrLnN0YXJ0c1dpdGgocHJldlN0YXR1cykpIHtcclxuICAgICAgICAgIGV4dHJhUmVtYXJrID0gZXhpc3RpbmdSZW1hcmsuc2xpY2UocHJldlN0YXR1cy5sZW5ndGgpLnRyaW0oKTtcclxuICAgICAgICAgIGV4dHJhUmVtYXJrID0gZXh0cmFSZW1hcmsucmVwbGFjZSgvXlstOuKAk+KAlF1cXHMqLywgXCJcIik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB1cGRhdGVkLnJlbWFyayA9IGV4dHJhUmVtYXJrID8gYCR7dmFsdWV9IC0gJHtleHRyYVJlbWFya31gIDogdmFsdWU7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChmaWVsZCA9PT0gXCJzdGF0dXNcIiAmJiB2YWx1ZSAhPT0gXCJGb2xsb3cgVXBcIikge1xyXG4gICAgICAgIHVwZGF0ZWQuZm9sbG93VXBEYXRlID0gdW5kZWZpbmVkO1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4geyAuLi5wcmV2LCBbdXNlcklkXTogdXBkYXRlZCB9O1xyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb3BlblN0YXR1c1VwZGF0ZU1vZGFsID0gKHVzZXIpID0+IHtcclxuICAgIHNldFN0YXR1c1VwZGF0ZURhdGEoe1xyXG4gICAgICBfaWQ6IHVzZXIuX2lkLFxyXG4gICAgICBzdGF0dXM6IHVzZXIuc3RhdHVzIHx8ICcnLFxyXG4gICAgICByZW1hcms6IHVzZXIucmVtYXJrIHx8ICcnLFxyXG4gICAgICBmb2xsb3dfdXBfZGF0ZTogdXNlci5mb2xsb3dfdXBfZGF0ZSB8fCAnJyxcclxuICAgIH0pO1xyXG4gICAgc2V0U2hvd1N0YXR1c1VwZGF0ZU1vZGFsKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN0YXR1c1VwZGF0ZVN1Ym1pdCA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHsgX2lkLCBzdGF0dXMsIHJlbWFyaywgZm9sbG93X3VwX2RhdGUgfSA9IHN0YXR1c1VwZGF0ZURhdGE7XHJcbiAgICBpZiAoIXN0YXR1cykge1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7IHZpc2liaWxpdHk6IHRydWUsIG1lc3NhZ2U6ICdQbGVhc2Ugc2VsZWN0IGEgc3RhdHVzLicsIHR5cGU6ICd3YXJuaW5nJyB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgaWYgKHN0YXR1cyA9PT0gJ0ZvbGxvdyBVcCcgJiYgIWZvbGxvd191cF9kYXRlKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHsgdmlzaWJpbGl0eTogdHJ1ZSwgbWVzc2FnZTogJ1BsZWFzZSBzZWxlY3QgYSBmb2xsb3ctdXAgZGF0ZS4nLCB0eXBlOiAnd2FybmluZycgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRJc1N0YXR1c1VwZGF0aW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICBzdGF0dXMsXHJcbiAgICAgICAgcmVtYXJrOiByZW1hcmsgfHwgJycsXHJcbiAgICAgICAgLy8ga2VlcCBleGlzdGluZyBhc3NpZ25lZF90byBpZiBhbnkgKG9wdGlvbmFsKVxyXG4gICAgICAgIGFzc2lnbmVkX3RvOiBjdXJyZW50VXBkYXRlVXNlcj8uYXNzaWduZWRfdG9faWQgfHwgJycsXHJcbiAgICAgIH07XHJcbiAgICAgIGlmIChzdGF0dXMgPT09ICdGb2xsb3cgVXAnICYmIGZvbGxvd191cF9kYXRlKSB7XHJcbiAgICAgICAgcGF5bG9hZC5mb2xsb3dfdXBfZGF0ZSA9IGZvbGxvd191cF9kYXRlO1xyXG4gICAgICB9XHJcbiAgICAgIGF3YWl0IGFwaS5wdXQoYC92MS9hZG1pbi91c2Vycy91c2Vycy11bnZlcmlmaWVkLyR7X2lkfWAsIHBheWxvYWQpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7IHZpc2liaWxpdHk6IHRydWUsIG1lc3NhZ2U6ICdTdGF0dXMgdXBkYXRlZCBzdWNjZXNzZnVsbHkhJywgdHlwZTogJ3N1Y2Nlc3MnIH0pO1xyXG4gICAgICBzZXRTaG93U3RhdHVzVXBkYXRlTW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKHByZXYgPT4gcHJldiArIDEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byB1cGRhdGUgc3RhdHVzLicsXHJcbiAgICAgICAgdHlwZTogJ2Vycm9yJyxcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1N0YXR1c1VwZGF0aW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVCdWxrQWN0aW9uU3VibWl0ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgZm9yIChjb25zdCBpZCBvZiBzZWxlY3RlZEN1c3RvbWVycykge1xyXG4gICAgICBjb25zdCBhc3NpZ24gPSBhY3Rpb25Bc3NpZ25tZW50c1tpZF07XHJcbiAgICAgIGlmICghYXNzaWduPy5hZG1pbklkKSB7XHJcbiAgICAgICAgcmV0dXJuIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBhc3NpZ24gYW4gYWRtaW4gdG8gYWxsIGN1c3RvbWVycy5cIixcclxuICAgICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIGlmICghYXNzaWduPy5zdGF0dXMpIHtcclxuICAgICAgICByZXR1cm4gc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBhIHN0YXR1cyBmb3IgYWxsIGN1c3RvbWVycy5cIixcclxuICAgICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChhc3NpZ24uc3RhdHVzID09PSBcIkZvbGxvdyBVcFwiICYmICFhc3NpZ24uZm9sbG93VXBEYXRlKSB7XHJcbiAgICAgICAgcmV0dXJuIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgYSBmb2xsb3ctdXAgZGF0ZSBmb3IgY3VzdG9tZXJzIHdpdGggJ0ZvbGxvdyBVcCcgc3RhdHVzLlwiLFxyXG4gICAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBzZXRJc1N1Ym1pdHRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwcm9taXNlcyA9IHNlbGVjdGVkQ3VzdG9tZXJzLm1hcCgoaWQpID0+IHtcclxuICAgICAgICBjb25zdCBhc3NpZ24gPSBhY3Rpb25Bc3NpZ25tZW50c1tpZF07XHJcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIHN0YXR1czogYXNzaWduLnN0YXR1cyxcclxuICAgICAgICAgIHJlbWFyazogYXNzaWduLnJlbWFyayB8fCBcIlwiLFxyXG4gICAgICAgICAgYXNzaWduZWRfdG86IGFzc2lnbi5hZG1pbklkLFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGlmIChhc3NpZ24uc3RhdHVzID09PSBcIkZvbGxvdyBVcFwiICYmIGFzc2lnbi5mb2xsb3dVcERhdGUpIHtcclxuICAgICAgICAgIHBheWxvYWQuZm9sbG93X3VwX2RhdGUgPSBhc3NpZ24uZm9sbG93VXBEYXRlO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIGFwaS5wdXQoYC92MS9hZG1pbi91c2Vycy91c2Vycy11bnZlcmlmaWVkLyR7aWR9YCwgcGF5bG9hZCk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgYXdhaXQgUHJvbWlzZS5hbGwocHJvbWlzZXMpO1xyXG5cclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJDdXN0b21lcnMgYXNzaWduZWQgYW5kIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFNob3dBY3Rpb25Nb2RhbChmYWxzZSk7XHJcbiAgICAgIHNldEFjdGlvbkFzc2lnbm1lbnRzKHt9KTtcclxuICAgICAgc2V0U2VsZWN0ZWRDdXN0b21lcnMoW10pO1xyXG4gICAgICBzZXRMYXN0Q2hlY2tlZElkKG51bGwpO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gdXBkYXRlIGN1c3RvbWVyc1wiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBhZ2VDaGFuZ2UgPSAocGFnZSkgPT4ge1xyXG4gICAgc2V0Q3VycmVudFBhZ2UocGFnZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50SW5wdXREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHApID0+ICh7IC4uLnAsIFtmaWVsZF06IHZhbHVlIH0pKTtcclxuICAgIHNldEVycm9ycygocCkgPT4gKHsgLi4ucCwgW2ZpZWxkXTogXCJcIiB9KSk7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwKSA9PiAoeyAuLi5wLCBbbmFtZV06IHZhbHVlIH0pKTtcclxuICAgIHNldEVycm9ycygocCkgPT4gKHsgLi4ucCwgW25hbWVdOiBcIlwiIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAoaWQpID0+IHtcclxuICAgIHNldEN1cnJlbnRVc2VyKChhd2FpdCBhcGkuZ2V0KGAvdXNlci9nZXQtdXNlci1ieS1pZC8ke2lkfWApKS5kYXRhKTtcclxuICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAoaWQpID0+IHtcclxuICAgIGNvbnN0IHJlcyA9IChhd2FpdCBhcGkuZ2V0KGAvdXNlci9nZXQtdXNlci1ieS1pZC8ke2lkfWApKS5kYXRhO1xyXG4gICAgc2V0Q3VycmVudFVwZGF0ZVVzZXIocmVzKTtcclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgZnVsbF9uYW1lOiByZXM/LmZ1bGxfbmFtZSxcclxuICAgICAgZW1haWw6IHJlcz8uZW1haWwsXHJcbiAgICAgIHBob25lX251bWJlcjogcmVzPy5waG9uZV9udW1iZXIsXHJcbiAgICAgIHBhc3N3b3JkOiByZXM/LnBhc3N3b3JkLFxyXG4gICAgICBwaW5jb2RlOiByZXM/LnBpbmNvZGUsXHJcbiAgICAgIGFkaGFhcl9ubzogcmVzPy5hZGhhYXJfbm8sXHJcbiAgICAgIHBhbl9ubzogcmVzPy5wYW5fbm8sXHJcbiAgICAgIGFkZHJlc3M6IHJlcz8uYWRkcmVzcyxcclxuICAgICAgc2VsZWN0ZWRfcGxhbjogcmVzPy5zZWxlY3RlZF9wbGFuPy5faWQgfHwgXCJcIixcclxuICAgICAgdGl0bGU6IHJlcz8udGl0bGUsXHJcbiAgICAgIGZhdGhlcl9uYW1lOiByZXM/LmZhdGhlcl9uYW1lLFxyXG4gICAgICBnZW5kZXI6IHJlcz8uZ2VuZGVyLFxyXG4gICAgICBtYXJpdGFsX3N0YXR1czogcmVzPy5tYXJpdGFsX3N0YXR1cyxcclxuICAgICAgZGF0ZW9mYmlydGg6IHJlcz8uZGF0ZW9mYmlydGg/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgbmF0aW9uYWxpdHk6IHJlcz8ubmF0aW9uYWxpdHksXHJcbiAgICAgIHZpbGxhZ2U6IHJlcz8udmlsbGFnZSxcclxuICAgICAgdGFsdWs6IHJlcz8udGFsdWssXHJcbiAgICAgIGRpc3RyaWN0OiByZXM/LmRpc3RyaWN0LFxyXG4gICAgICBzdGF0ZTogcmVzPy5zdGF0ZSxcclxuICAgICAgY29sbGVjdGlvbl9hcmVhOiByZXM/LmNvbGxlY3Rpb25fYXJlYT8uX2lkIHx8IFwiXCIsXHJcbiAgICAgIGFsdGVybmF0ZV9udW1iZXI6IHJlcz8uYWx0ZXJuYXRlX251bWJlcixcclxuICAgICAgcmVmZXJyYWxfbmFtZTogcmVzPy5yZWZlcnJhbF9uYW1lLFxyXG4gICAgfSk7XHJcbiAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbiAgICBzZXRFcnJvcnMoe30pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZVVzZXIgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIWN1cnJlbnRVc2VyKSByZXR1cm47XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvdXNlci9kZWxldGUtdXNlci8ke2N1cnJlbnRVc2VyLl9pZH1gKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoeyB2aXNpYmlsaXR5OiB0cnVlLCBtZXNzYWdlOiBcIkRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIsIHR5cGU6IFwic3VjY2Vzc1wiIH0pO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwKSA9PiBwICsgMSk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ3VzdG9tZXJTdGF0dXMgPSBhc3luYyAoaWQsIHN0YXR1cykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKGlkICYmIChhd2FpdCBhcGkucHV0KGAvdXNlci91cGRhdGUtdXNlci8ke2lkfWAsIHsgYXBwcm92YWxfc3RhdHVzOiBzdGF0dXMgfSkpLnN0YXR1cyA9PT0gMjAwKSB7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocCkgPT4gcCArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHsgdmlzaWJpbGl0eTogdHJ1ZSwgbWVzc2FnZTogYFN0YXR1cyB1cGRhdGVkIHRvICR7c3RhdHVzfWAsIHR5cGU6IFwic3VjY2Vzc1wiIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGZtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG4gICAgICBPYmplY3QuZW50cmllcyh1cGRhdGVGb3JtRGF0YSkuZm9yRWFjaCgoW2ssIHZdKSA9PiB7XHJcbiAgICAgICAgaWYgKHYpIGZtRGF0YS5hcHBlbmQoaywgdik7XHJcbiAgICAgIH0pO1xyXG4gICAgICBhd2FpdCBhcGkucHV0KGAvdXNlci91cGRhdGUtdXNlci8ke2N1cnJlbnRVcGRhdGVVc2VyPy5faWR9YCwgZm1EYXRhLCB7IGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIgfSB9KTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocCkgPT4gcCArIDEpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7IHZpc2liaWxpdHk6IHRydWUsIG1lc3NhZ2U6IFwiVXNlciBVcGRhdGVkXCIsIHR5cGU6IFwic3VjY2Vzc1wiIH0pO1xyXG4gICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgaWYgKGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwicGhvbmVcIikpXHJcbiAgICAgICAgc2V0RXJyb3JzKChwKSA9PiAoeyAuLi5wLCBwaG9uZV9udW1iZXI6IFwiUGhvbmUgZXhpc3RzXCIgfSkpO1xyXG4gICAgICBlbHNlXHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoeyB0eXBlOiBcImVycm9yXCIsIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRXJyb3IgdXBkYXRpbmdcIiwgdmlzaWJpbGl0eTogdHJ1ZSB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBBY3Rpb25Ecm9wZG93biA9ICh7IHVzZXIgfSkgPT4gKFxyXG4gICAgPERyb3Bkb3duXHJcbiAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICBtZW51PXt7XHJcbiAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTYwMCBmb250LW1lZGl1bSBjdXJzb3ItcG9pbnRlciBweC0yIHB5LTFcIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4odXNlci5faWQpfT5FZGl0PC9kaXY+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIGZvbnQtbWVkaXVtIGN1cnNvci1wb2ludGVyIHB4LTIgcHktMVwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3Blbih1c2VyLl9pZCl9PkRlbGV0ZTwvZGl2PlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAga2V5OiBcIjNcIixcclxuICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS03MDAgZm9udC1tZWRpdW0gY3Vyc29yLXBvaW50ZXIgcHgtMiBweS0xXCIgb25DbGljaz17KCkgPT4gaGFuZGxlRW5yb2xsbWVudFJlcXVlc3RQcmludCh1c2VyLl9pZCl9PlByaW50PC9kaXY+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBrZXk6IFwiNFwiLFxyXG4gICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZvbnQtbWVkaXVtIGN1cnNvci1wb2ludGVyIHB4LTIgcHktMSAke3VzZXIuYXBwcm92YWxfc3RhdHVzICE9PSBcIkFwcHJvdmVkXCIgPyBcInRleHQtZW1lcmFsZC02MDBcIiA6IFwidGV4dC1yZWQtNjAwXCJ9YH1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUN1c3RvbWVyU3RhdHVzKHVzZXIuX2lkLCB1c2VyLmFwcHJvdmFsX3N0YXR1cyAhPT0gXCJBcHByb3ZlZFwiID8gXCJBcHByb3ZlZFwiIDogXCJQZW5kaW5nXCIpfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHt1c2VyLmFwcHJvdmFsX3N0YXR1cyAhPT0gXCJBcHByb3ZlZFwiID8gXCJBcHByb3ZlXCIgOiBcIlVuYXBwcm92ZVwifVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICBdLFxyXG4gICAgICB9fVxyXG4gICAgICBwbGFjZW1lbnQ9XCJib3R0b21SaWdodFwiXHJcbiAgICA+XHJcbiAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtbGcgaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cclxuICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCB0ZXh0LWxnXCIgLz5cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L0Ryb3Bkb3duPlxyXG4gICk7XHJcblxyXG4gIC8vIOKUgOKUgOKUgCBDT05UQUNUIFNVTU1BUlkgREFTSEJPQVJEIOKUgOKUgOKUgFxyXG4gIGNvbnN0IENvbnRhY3RTdW1tYXJ5RGFzaGJvYXJkID0gKCkgPT4ge1xyXG4gICAgY29uc3QgY291bnRzID0gZ2V0U3RhdHVzQ291bnRzKCk7XHJcbiAgICBjb25zdCBwZW5kaW5nQ291bnQgPSBmaWx0ZXJlZFVzZXJzLmZpbHRlcigodSkgPT4gdS5zdGF0dXMgPT09IFwiTm90IENvbnRhY3RlZFwiIHx8ICF1LnN0YXR1cykubGVuZ3RoO1xyXG4gICAgY29uc3QgY29udmVyc2lvblJhdGUgPSBjb3VudHMudG90YWwgPiAwID8gKChjb3VudHMuQ29udmVydGVkIC8gY291bnRzLnRvdGFsKSAqIDEwMCkudG9GaXhlZCgxKSA6IFwiMC4wXCI7XHJcbiAgICBjb25zdCByZWplY3Rpb25SYXRlID0gY291bnRzLnRvdGFsID4gMCA/ICgoY291bnRzLlJlamVjdGVkIC8gY291bnRzLnRvdGFsKSAqIDEwMCkudG9GaXhlZCgxKSA6IFwiMC4wXCI7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTEwMCBwLTUgbWItNlwiPlxyXG4gICAgICAgIHsvKiBTdW1tYXJ5IEhlYWRlciAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBnYXAtMyBtYi01XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MDAgdG8taW5kaWdvLTYwMCByb3VuZGVkLXhsIHRleHQtd2hpdGUgc2hhZG93LW1kIHNoYWRvdy1ibHVlLTIwMFwiPlxyXG4gICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNOSAxOXYtNmEyIDIgMCAwMC0yLTJINWEyIDIgMCAwMC0yIDJ2NmEyIDIgMCAwMDIgMmgyYTIgMiAwIDAwMi0yem0wIDBWOWEyIDIgMCAwMTItMmgyYTIgMiAwIDAxMiAydjEwbS02IDBhMiAyIDAgMDAyIDJoMmEyIDIgMCAwMDItMm0wIDBWNWEyIDIgMCAwMTItMmgyYTIgMiAwIDAxMiAydjE0YTIgMiAwIDAxLTIgMmgtMmEyIDIgMCAwMS0yLTJ6XCIgLz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPkNvbnRhY3QgU3VtbWFyeTwvaDM+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+T3ZlcnZpZXcgb2YgZW1wbG95ZWUgZm9sbG93LXVwIHdvcms8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIENvbnZlcnNpb24gUmF0ZSBCYWRnZSAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAge3BhcnNlRmxvYXQoY29udmVyc2lvblJhdGUpID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWVtZXJhbGQtNTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMCByb3VuZGVkLWZ1bGwgcHgtMyBweS0xLjVcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTYwMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xMyA3aDhtMCAwdjhtMC04bC04IDgtNC00LTYgNlwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZW1lcmFsZC03MDBcIj57Y29udmVyc2lvblJhdGV9JSBjb252ZXJzaW9uPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICB7cGFyc2VGbG9hdChyZWplY3Rpb25SYXRlKSA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1yZWQtNTAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIHJvdW5kZWQtZnVsbCBweC0zIHB5LTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXJlZC01MDBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTMgMTdoOG0wIDBWOW0wIDhsLTgtOC00IDQtNi02XCIgLz5cclxuICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1yZWQtNjAwXCI+e3JlamVjdGlvblJhdGV9JSByZWplY3Rpb248L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFN0YXR1cyBDYXJkcyBSb3cgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy0zIGxnOmdyaWQtY29scy01IGdhcC0zIG1iLTVcIj5cclxuICAgICAgICAgIHtTVEFUVVNfU1VNTUFSWV9DT05GSUcubWFwKChjZmcpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgY291bnQgPSBjb3VudHNbY2ZnLmtleV07XHJcbiAgICAgICAgICAgIGNvbnN0IHBlcmNlbnRhZ2UgPSBjb3VudHMudG90YWwgPiAwID8gKChjb3VudCAvIGNvdW50cy50b3RhbCkgKiAxMDApLnRvRml4ZWQoMCkgOiAwO1xyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgIGtleT17Y2ZnLmtleX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0xMDAgcC00IGhvdmVyOnNoYWRvdy1tZCBob3ZlcjotdHJhbnNsYXRlLXktMC41IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBncm91cCBjdXJzb3ItZGVmYXVsdCAke2NvdW50ID09PSAwID8gXCJvcGFjaXR5LTUwXCIgOiBcIlwifWB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgey8qIEJhY2tncm91bmQgZ3JhZGllbnQgYWNjZW50ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BhYnNvbHV0ZSB0b3AtMCByaWdodC0wIHctMjAgaC0yMCByb3VuZGVkLWZ1bGwgYmctZ3JhZGllbnQtdG8tYnIgJHtjZmcuY29sb3J9IG9wYWNpdHktWzAuMDddIC10cmFuc2xhdGUteS0xLzIgdHJhbnNsYXRlLXgtMS8yIGdyb3VwLWhvdmVyOm9wYWNpdHktWzAuMTJdIHRyYW5zaXRpb24tb3BhY2l0eWB9IC8+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHctOSBoLTkgcm91bmRlZC1sZyAke2NmZy5iZ0xpZ2h0fSAke2NmZy5pY29uQ29sb3J9IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG1iLTMgcmluZy0xICR7Y2ZnLnJpbmdDb2xvcn1gfT5cclxuICAgICAgICAgICAgICAgICAgICB7Y2ZnLmljb259XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWV4dHJhYm9sZCB0ZXh0LWdyYXktOTAwIGxlYWRpbmctbm9uZSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2NvdW50fVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2NmZy5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFByb2dyZXNzIGJhciAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xLjUgYmctZ3JheS0xMDAgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGgtZnVsbCByb3VuZGVkLWZ1bGwgYmctZ3JhZGllbnQtdG8tciAke2NmZy5jb2xvcn0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNzAwIGVhc2Utb3V0YH1cclxuICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtwZXJjZW50YWdlfSVgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCBtdC0xIHRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICB7cGVyY2VudGFnZX0lXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgfSl9XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBCb3R0b20gU3RhdHMgQmFyICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICB7LyogVG90YWwgUHJvY2Vzc2VkICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IGJnLXNsYXRlLTUwIHJvdW5kZWQteGwgcHgtNCBweS0yLjUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAvNjBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtbGcgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1zbGF0ZS02MDAgdG8tc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtd2hpdGUgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xNyAyMGg1di0yYTMgMyAwIDAwLTUuMzU2LTEuODU3TTE3IDIwSDdtMTAgMHYtMmMwLS42NTYtLjEyNi0xLjI4My0uMzU2LTEuODU3TTcgMjBIMnYtMmEzIDMgMCAwMTUuMzU2LTEuODU3TTcgMjB2LTJjMC0uNjU2LjEyNi0xLjI4My4zNTYtMS44NTdtMCAwYTUuMDAyIDUuMDAyIDAgMDE5LjI4OCAwTTE1IDExYTMgMyAwIDExLTYgMCAzIDMgMCAwMTYgMHpcIiAvPlxyXG4gICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtZXh0cmFib2xkIHRleHQtZ3JheS05MDAgbGVhZGluZy1ub25lXCI+e2NvdW50cy50b3RhbH08L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlRvdGFsIFByb2Nlc3NlZDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogU3RpbGwgUGVuZGluZyAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBiZy1hbWJlci01MCByb3VuZGVkLXhsIHB4LTQgcHktMi41IGJvcmRlciBib3JkZXItYW1iZXItMjAwLzYwXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYW1iZXItNTAwIHRvLW9yYW5nZS01MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTEyIDh2NGwzIDNtNi0zYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiIC8+XHJcbiAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1leHRyYWJvbGQgdGV4dC1hbWJlci03MDAgbGVhZGluZy1ub25lXCI+e3BlbmRpbmdDb3VudH08L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1hbWJlci02MDAgZm9udC1tZWRpdW1cIj5TdGlsbCBQZW5kaW5nPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIHsvKiBGb2xsb3cgVXBzIER1ZSAqL31cclxuICAgICAgICAgIHtjb3VudHNbXCJGb2xsb3cgVXBcIl0gPiAwICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IGJnLXB1cnBsZS01MCByb3VuZGVkLXhsIHB4LTQgcHktMi41IGJvcmRlciBib3JkZXItcHVycGxlLTIwMC82MFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWxnIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwMCB0by1wdXJwbGUtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtd2hpdGUgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTUgMTdoNWwtMS40MDUtMS40MDVBMi4wMzIgMi4wMzIgMCAwMTE4IDE0LjE1OFYxMWE2LjAwMiA2LjAwMiAwIDAwLTQtNS42NTlWNWEyIDIgMCAxMC00IDB2LjM0MUM3LjY3IDYuMTY1IDYgOC4zODggNiAxMXYzLjE1OWMwIC41MzgtLjIxNCAxLjA1NS0uNTk1IDEuNDM2TDQgMTdoNW02IDB2MWEzIDMgMCAxMS02IDB2LTFtNiAwSDlcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1leHRyYWJvbGQgdGV4dC1wdXJwbGUtNzAwIGxlYWRpbmctbm9uZVwiPntjb3VudHNbXCJGb2xsb3cgVXBcIl19PC9wPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1wdXJwbGUtNjAwIGZvbnQtbWVkaXVtXCI+Rm9sbG93IFVwcyBEdWU8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7LyogUHJvY2VzcyBSYXRlICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41IG1sLWF1dG9cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0ZXh0LWdyYXktOTAwIGxlYWRpbmctbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAge2ZpbHRlcmVkVXNlcnMubGVuZ3RoID4gMFxyXG4gICAgICAgICAgICAgICAgICA/ICgoY291bnRzLnRvdGFsIC8gZmlsdGVyZWRVc2Vycy5sZW5ndGgpICogMTAwKS50b0ZpeGVkKDEpXHJcbiAgICAgICAgICAgICAgICAgIDogXCIwLjBcIn1cclxuICAgICAgICAgICAgICAgICVcclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPlByb2Nlc3MgUmF0ZTwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy0xMiBoLTEyXCI+XHJcbiAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgLXJvdGF0ZS05MFwiIHZpZXdCb3g9XCIwIDAgMzYgMzZcIj5cclxuICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgIGQ9XCJNMTggMi4wODQ1IGEgMTUuOTE1NSAxNS45MTU1IDAgMCAxIDAgMzEuODMxIGEgMTUuOTE1NSAxNS45MTU1IDAgMCAxIDAgLTMxLjgzMVwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiI2YxZjVmOVwiXHJcbiAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiM1wiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgZD1cIk0xOCAyLjA4NDUgYSAxNS45MTU1IDE1LjkxNTUgMCAwIDEgMCAzMS44MzEgYSAxNS45MTU1IDE1LjkxNTUgMCAwIDEgMCAtMzEuODMxXCJcclxuICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2U9XCJ1cmwoI3Byb2dyZXNzR3JhZGllbnQpXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIzXCJcclxuICAgICAgICAgICAgICAgICAgc3Ryb2tlRGFzaGFycmF5PXtgJHtmaWx0ZXJlZFVzZXJzLmxlbmd0aCA+IDAgPyAoY291bnRzLnRvdGFsIC8gZmlsdGVyZWRVc2Vycy5sZW5ndGgpICogMTAwIDogMH0sIDEwMGB9XHJcbiAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPGRlZnM+XHJcbiAgICAgICAgICAgICAgICAgIDxsaW5lYXJHcmFkaWVudCBpZD1cInByb2dyZXNzR3JhZGllbnRcIiB4MT1cIjAlXCIgeTE9XCIwJVwiIHgyPVwiMTAwJVwiIHkyPVwiMCVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3RvcCBvZmZzZXQ9XCIwJVwiIHN0b3BDb2xvcj1cIiM2MzY2ZjFcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdG9wIG9mZnNldD1cIjEwMCVcIiBzdG9wQ29sb3I9XCIjM2I4MmY2XCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9saW5lYXJHcmFkaWVudD5cclxuICAgICAgICAgICAgICAgIDwvZGVmcz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIC8vIC0tLSBQRU5ESU5HIFRBQjogQ3VzdG9tZXIgQ2FyZCAtLS1cclxuICBjb25zdCByZW5kZXJDdXN0b21lckNhcmQgPSAoY3VzdG9tZXIpID0+IHtcclxuICAgIGNvbnN0IGlzUGVuZGluZyA9IGN1c3RvbWVyLnN0YXR1cyA9PT0gXCJOb3QgQ29udGFjdGVkXCIgfHwgIWN1c3RvbWVyLnN0YXR1cztcclxuICAgIGlmIChhY3RpdmVUYWIgPT09IFwicGVuZGluZ1wiICYmICFpc1BlbmRpbmcpIHJldHVybiBudWxsO1xyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJjb250YWN0ZWRcIiAmJiBpc1BlbmRpbmcpIHJldHVybiBudWxsO1xyXG4gICAgY29uc3QgaXNTZWxlY3RlZCA9IHNlbGVjdGVkQ3VzdG9tZXJzLmluY2x1ZGVzKGN1c3RvbWVyLl9pZCk7XHJcbiAgICBjb25zdCBpc0xhc3RDaGVja2VkID0gaXNTZWxlY3RlZCAmJiBsYXN0Q2hlY2tlZElkID09PSBjdXN0b21lci5faWQ7XHJcblxyXG4gICAgLy8gQ09OVEFDVEVEIFRBQiDigJQgUmljaCB3b3JrLXN0YXR1cyBjYXJkIGZvciBNRCByZXZpZXdcclxuICAgIGlmIChhY3RpdmVUYWIgPT09IFwiY29udGFjdGVkXCIpIHtcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2XHJcbiAgICAgICAgICBrZXk9e2N1c3RvbWVyLl9pZH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlIGJnLXdoaXRlIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1sZyBob3ZlcjotdHJhbnNsYXRlLXktMSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgbGVmdC0wIHctZnVsbCBoLTEuNSByb3VuZGVkLXQtMnhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTUwMCB0by1pbmRpZ28tNTAwIG9wYWNpdHktOTBcIiAvPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcHQtNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1pbi13LTBcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBiZy1pbmRpZ28tMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtaW5kaWdvLTcwMCBmb250LWJvbGQgdGV4dC1zbSBmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtjdXN0b21lci5uYW1lPy5jaGFyQXQoMCk/LnRvVXBwZXJDYXNlKCl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZ3JheS05MDAgdHJ1bmNhdGUgdGV4dC1sZ1wiPntjdXN0b21lci5uYW1lfTwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMFwiPntjdXN0b21lci5jdXN0b21lcl9pZH08L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICB7LyogTmV3IHBlbmNpbCBpY29uIGZvciBzdGF0dXMgdXBkYXRlICovfVxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuU3RhdHVzVXBkYXRlTW9kYWwoY3VzdG9tZXIpfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGhvdmVyOmJnLWdyYXktMTAwIHRyYW5zaXRpb24tY29sb3JzIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVXBkYXRlIFN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTExIDVINmEyIDIgMCAwMC0yIDJ2MTFhMiAyIDAgMDAyIDJoMTFhMiAyIDAgMDAyLTJ2LTVtLTEuNDE0LTkuNDE0YTIgMiAwIDExMi44MjggMi44MjhMMTEuODI4IDE1SDl2LTIuODI4bDguNTg2LTguNTg2elwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QWN0aW9uRHJvcGRvd24gdXNlcj17Y3VzdG9tZXJ9IC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zIG1iLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC1sZyBwLTIuNVwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlBob25lPC9wPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbXQtMC41XCI+e2N1c3RvbWVyLnBob25lX251bWJlcn08L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0yLjVcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5Kb2luZWQ8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtdC0wLjVcIj57Y3VzdG9tZXIuY3JlYXRlZEF0fTwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogV09SSyBTVEFUVVMgU0VDVElPTiAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTUwIHRvLWJsdWUtNTAvNTAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC84MCBwLTQgc3BhY2UteS0zXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNOSA1SDdhMiAyIDAgMDAtMiAydjEwYTIgMiAwIDAwMiAyaDhhMiAyIDAgMDAyLTJWN2EyIDIgMCAwMC0yLTJoLTJNOSA1YTIgMiAwIDAwMiAyaDJhMiAyIDAgMDAyLTJNOSA1YTIgMiAwIDAxMi0yaDJhMiAyIDAgMDEyIDJcIiAvPlxyXG4gICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICBXb3JrIFN0YXR1c1xyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLWZ1bGwgdGV4dC14cyBmb250LWJvbGQgJHtnZXRTdGF0dXNDb2xvcihjdXN0b21lci5zdGF0dXMpfWB9PlxyXG4gICAgICAgICAgICAgICAgICB7Z2V0U3RhdHVzSWNvbihjdXN0b21lci5zdGF0dXMpfVxyXG4gICAgICAgICAgICAgICAgICB7Y3VzdG9tZXIuc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkICR7Z2V0U3RhdHVzQ29sb3IoY3VzdG9tZXIuYXBwcm92YWxfc3RhdHVzKX1gfT5cclxuICAgICAgICAgICAgICAgICAge2N1c3RvbWVyLmFwcHJvdmFsX3N0YXR1c31cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAge2N1c3RvbWVyLnJlbWFyayAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMVwiPlJlbWFyazwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwIGxlYWRpbmctcmVsYXhlZFwiPntjdXN0b21lci5yZW1hcmt9PC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICB7Y3VzdG9tZXIuYXNzaWduZWRfdG8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcC0yLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTAuNVwiPkFzc2lnbmVkIFRvPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTUgaC01IHJvdW5kZWQtZnVsbCBiZy1pbmRpZ28tMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LWluZGlnby02MDBcIj57Y3VzdG9tZXIuYXNzaWduZWRfdG8/LmNoYXJBdCgwKT8udG9VcHBlckNhc2UoKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWluZGlnby03MDAgdHJ1bmNhdGVcIj57Y3VzdG9tZXIuYXNzaWduZWRfdG99PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7Y3VzdG9tZXIuZm9sbG93X3VwX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwIHAtMi41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtcHVycGxlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMC41XCI+Rm9sbG93IFVwIERhdGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1wdXJwbGUtNTAwXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTggN1YzbTggNFYzbS05IDhoMTBNNSAyMWgxNGEyIDIgMCAwMDItMlY3YTIgMiAwIDAwLTItMkg1YTIgMiAwIDAwLTIgMnYxMmEyIDIgMCAwMDIgMnpcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS03MDBcIj57Y3VzdG9tZXIuZm9sbG93X3VwX2RhdGV9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHtjdXN0b21lci5zdGF0dXNfdXBkYXRlZF9hdCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCB0ZXh0LXJpZ2h0XCI+TGFzdCB1cGRhdGVkOiB7Y3VzdG9tZXIuc3RhdHVzX3VwZGF0ZWRfYXR9PC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gUEVORElORyBUQUJcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxkaXZcclxuICAgICAgICBrZXk9e2N1c3RvbWVyLl9pZH1cclxuICAgICAgICBjbGFzc05hbWU9e2Bncm91cCByZWxhdGl2ZSBiZy13aGl0ZSByb3VuZGVkLTJ4bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIGhvdmVyOnNoYWRvdy14bCBob3ZlcjotdHJhbnNsYXRlLXktMSAke2lzU2VsZWN0ZWQgPyBcImJvcmRlci12aW9sZXQtNDAwIHJpbmctMiByaW5nLXZpb2xldC0xMDAgc2hhZG93LWxnXCIgOiBcImJvcmRlci1ncmF5LTIwMCBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgfWB9XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIGxlZnQtMCB3LWZ1bGwgaC0xLjUgcm91bmRlZC10LTJ4bCBiZy1ncmFkaWVudC10by1yIGZyb20tYW1iZXItNDAwIHRvLW9yYW5nZS01MDAgb3BhY2l0eS04MFwiIC8+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcHQtNlwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWluLXctMFwiPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2lzU2VsZWN0ZWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT4gaGFuZGxlU2VsZWN0Q3VzdG9tZXIoY3VzdG9tZXIuX2lkKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC12aW9sZXQtNjAwIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmbGV4LXNocmluay0wXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ncmF5LTkwMCB0cnVuY2F0ZSB0ZXh0LWxnXCI+e2N1c3RvbWVyLm5hbWV9PC9oMz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxBY3Rpb25Ecm9wZG93biB1c2VyPXtjdXN0b21lcn0gLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMyBtYi00XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLWxnIHAtMi41XCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlBob25lPC9wPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG10LTAuNVwiPntjdXN0b21lci5waG9uZV9udW1iZXJ9PC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0yLjVcIj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtZ3JheS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+SUQ8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbXQtMC41IHRydW5jYXRlXCI+e2N1c3RvbWVyLmN1c3RvbWVyX2lkfTwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtZ3JheS01MDAgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwIHB0LTMgbXQtMVwiPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMi41IHB5LTEgcm91bmRlZC1mdWxsIGZvbnQtbWVkaXVtICR7Z2V0U3RhdHVzQ29sb3IoY3VzdG9tZXIuYXBwcm92YWxfc3RhdHVzKX1gfT5cclxuICAgICAgICAgICAgICB7Y3VzdG9tZXIuYXBwcm92YWxfc3RhdHVzfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNOCA3VjNtOCA0VjNtLTkgOGgxME01IDIxaDE0YTIgMiAwIDAwMi0yVjdhMiAyIDAgMDAtMi0ySDVhMiAyIDAgMDAtMiAydjEyYTIgMiAwIDAwMiAyelwiIC8+XHJcbiAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAge2N1c3RvbWVyLmNyZWF0ZWRBdH1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAge2lzTGFzdENoZWNrZWQgJiYgKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDBcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWN0aW9uTW9kYWwodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHgtNCBweS0zIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwIHRleHQtd2hpdGUgdGV4dC1zbSBmb250LXNlbWlib2xkIHJvdW5kZWQteGwgaG92ZXI6ZnJvbS1ibHVlLTcwMCBob3Zlcjp0by1pbmRpZ28tNzAwIHNoYWRvdy1tZCBzaGFkb3ctYmx1ZS0yMDAgdHJhbnNpdGlvbi1hbGwgYWN0aXZlOnNjYWxlLVswLjk4XVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPE1kQXNzaWdubWVudEluZCBjbGFzc05hbWU9XCJ0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgIFZpZXcgJiBVcGRhdGUgKHtzZWxlY3RlZEN1c3RvbWVycy5sZW5ndGh9KVxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICAvLyAtLS0gTElTVCBWSUVXIFJPVyAtLS1cclxuICBjb25zdCBVc2VyUm93ID0gKHsgdXNlciB9KSA9PiB7XHJcbiAgICBjb25zdCBpc1BlbmRpbmcgPSB1c2VyLnN0YXR1cyA9PT0gXCJOb3QgQ29udGFjdGVkXCIgfHwgIXVzZXIuc3RhdHVzO1xyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJwZW5kaW5nXCIgJiYgIWlzUGVuZGluZykgcmV0dXJuIG51bGw7XHJcbiAgICBpZiAoYWN0aXZlVGFiID09PSBcImNvbnRhY3RlZFwiICYmIGlzUGVuZGluZykgcmV0dXJuIG51bGw7XHJcbiAgICBjb25zdCBpc1NlbGVjdGVkID0gc2VsZWN0ZWRDdXN0b21lcnMuaW5jbHVkZXModXNlci5faWQpO1xyXG4gICAgY29uc3QgaXNMYXN0Q2hlY2tlZCA9IGlzU2VsZWN0ZWQgJiYgbGFzdENoZWNrZWRJZCA9PT0gdXNlci5faWQ7XHJcblxyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gXCJjb250YWN0ZWRcIikge1xyXG4gICAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXZcclxuICAgICAgICAgIGtleT17dXNlci5faWR9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJncm91cCBiZy13aGl0ZSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItYmx1ZS0yMDAgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1sZyBob3Zlcjpib3JkZXItYmx1ZS0zMDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIG92ZXJmbG93LWhpZGRlblwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBnYXAtNCBwLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCB3LWZ1bGwgc206dy1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLWluZGlnby0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1pbmRpZ28tNzAwIGZvbnQtYm9sZCB0ZXh0LXNtIGZsZXgtc2hyaW5rLTBcIj5cclxuICAgICAgICAgICAgICAgIHt1c2VyLm5hbWU/LmNoYXJBdCgwKT8udG9VcHBlckNhc2UoKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTAgZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG1iLTEgZmxleC13cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIHRydW5jYXRlXCI+e3VzZXIubmFtZX08L2gzPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgJHtnZXRTdGF0dXNDb2xvcih1c2VyLnN0YXR1cyl9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAge2dldFN0YXR1c0ljb24odXNlci5zdGF0dXMpfVxyXG4gICAgICAgICAgICAgICAgICAgIHt1c2VyLnN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGQgJHtnZXRTdGF0dXNDb2xvcih1c2VyLmFwcHJvdmFsX3N0YXR1cyl9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAge3VzZXIuYXBwcm92YWxfc3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB0cnVuY2F0ZVwiPnt1c2VyLmFkZHJlc3MgfHwgXCJObyBhZGRyZXNzIHByb3ZpZGVkXCJ9PC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWwtMCBzbTptbC1hdXRvIHctZnVsbCBzbTp3LWF1dG9cIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC01MCBweC0zIHB5LTEuNSByb3VuZGVkLWxnIHRleHQtY2VudGVyIG1pbi13LVsxMDBweF1cIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC12aW9sZXQtNTAwIGZvbnQtbWVkaXVtXCI+UGhvbmU8L3A+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC05MDBcIj57dXNlci5waG9uZV9udW1iZXJ9PC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgPEFjdGlvbkRyb3Bkb3duIHVzZXI9e3VzZXJ9IC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tc2xhdGUtNTAgdG8tYmx1ZS01MC80MCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwIHB4LTQgcHktM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtNCB0ZXh0LXhzXCI+XHJcbiAgICAgICAgICAgICAge3VzZXIucmVtYXJrICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMiBmbGV4LTEgbWluLXctWzIwMHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXgtc2hyaW5rLTAgbXQtMC41XCI+UmVtYXJrOjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTcwMCBsZWFkaW5nLXJlbGF4ZWRcIj57dXNlci5yZW1hcmt9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7dXNlci5hc3NpZ25lZF90byAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctd2hpdGUgcm91bmRlZC1mdWxsIHB4LTMgcHktMS41IGJvcmRlciBib3JkZXItaW5kaWdvLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNSBoLTUgcm91bmRlZC1mdWxsIGJnLWluZGlnby0xMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1pbmRpZ28tNjAwXCI+e3VzZXIuYXNzaWduZWRfdG8/LmNoYXJBdCgwKT8udG9VcHBlckNhc2UoKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtaW5kaWdvLTcwMFwiPnt1c2VyLmFzc2lnbmVkX3RvfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAge3VzZXIuZm9sbG93X3VwX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLXdoaXRlIHJvdW5kZWQtZnVsbCBweC0zIHB5LTEuNSBib3JkZXIgYm9yZGVyLXB1cnBsZS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXB1cnBsZS01MDBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk04IDdWM204IDRWM20tOSA4aDEwTTUgMjFoMTRhMiAyIDAgMDAyLTJWN2EyIDIgMCAwMC0yLTJINWEyIDIgMCAwMC0yIDJ2MTJhMiAyIDAgMDAyIDJ6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1wdXJwbGUtNzAwXCI+e3VzZXIuZm9sbG93X3VwX2RhdGV9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7dXNlci5zdGF0dXNfdXBkYXRlZF9hdCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBtbC1hdXRvXCI+VXBkYXRlZDoge3VzZXIuc3RhdHVzX3VwZGF0ZWRfYXR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdlxyXG4gICAgICAgIGtleT17dXNlci5faWR9XHJcbiAgICAgICAgY2xhc3NOYW1lPXtgZ3JvdXAgYmctd2hpdGUgcm91bmRlZC14bCBib3JkZXIgZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1zdGFydCBzbTppdGVtcy1jZW50ZXIgZ2FwLTQgcC00IHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBob3ZlcjpzaGFkb3ctbGcgaG92ZXI6Ym9yZGVyLWdyYXktMzAwICR7aXNTZWxlY3RlZCA/IFwiYm9yZGVyLXZpb2xldC00MDAgcmluZy0yIHJpbmctdmlvbGV0LTEwMFwiIDogXCJib3JkZXItZ3JheS0xMDAgc2hhZG93LXNtXCJcclxuICAgICAgICAgIH1gfVxyXG4gICAgICA+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCB3LWZ1bGwgc206dy1hdXRvXCI+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgY2hlY2tlZD17aXNTZWxlY3RlZH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eygpID0+IGhhbmRsZVNlbGVjdEN1c3RvbWVyKHVzZXIuX2lkKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXZpb2xldC02MDAgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZsZXgtc2hyaW5rLTBcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgdHJ1bmNhdGVcIj57dXNlci5uYW1lfTwvaDM+XHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkICR7Z2V0U3RhdHVzQ29sb3IodXNlci5hcHByb3ZhbF9zdGF0dXMpfWB9PlxyXG4gICAgICAgICAgICAgICAge3VzZXIuYXBwcm92YWxfc3RhdHVzfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB0cnVuY2F0ZVwiPnt1c2VyLmFkZHJlc3MgfHwgXCJObyBhZGRyZXNzIHByb3ZpZGVkXCJ9PC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWwtOCBzbTptbC0wIHctZnVsbCBzbTp3LWF1dG9cIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTUwIHB4LTMgcHktMS41IHJvdW5kZWQtbGcgdGV4dC1jZW50ZXIgbWluLXctWzEwMHB4XVwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtdmlvbGV0LTUwMCBmb250LW1lZGl1bVwiPlBob25lPC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC05MDBcIj57dXNlci5waG9uZV9udW1iZXJ9PC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcHgtMyBweS0xLjUgcm91bmRlZC1sZyB0ZXh0LWNlbnRlciBtaW4tdy1bOTBweF0gYm9yZGVyIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5Kb2luZWQ8L3A+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS03MDBcIj57dXNlci5jcmVhdGVkQXR9PC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTAgbWwtYXV0byBzbTptbC0wXCI+XHJcbiAgICAgICAgICAgIDxBY3Rpb25Ecm9wZG93biB1c2VyPXt1c2VyfSAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHtpc0xhc3RDaGVja2VkICYmIChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG10LTQgcHQtNCBib3JkZXItdCBib3JkZXItZ3JheS0xMDAgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FjdGlvbk1vZGFsKHRydWUpfVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB4LTUgcHktMi41IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwIHRleHQtd2hpdGUgdGV4dC1zbSBmb250LXNlbWlib2xkIHJvdW5kZWQteGwgaG92ZXI6ZnJvbS1ibHVlLTcwMCBob3Zlcjp0by1pbmRpZ28tNzAwIHNoYWRvdy1tZCBzaGFkb3ctYmx1ZS0yMDAgdHJhbnNpdGlvbi1hbGwgYWN0aXZlOnNjYWxlLVswLjk4XVwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8TWRBc3NpZ25tZW50SW5kIGNsYXNzTmFtZT1cInRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgIEFzc2lnbiAmIFVwZGF0ZSAoe3NlbGVjdGVkQ3VzdG9tZXJzLmxlbmd0aH0pXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG4gIH07XHJcblxyXG4gIC8vIC0tLSBSRU5ERVIgVVNFUlMgLS0tXHJcbiAgY29uc3QgcmVuZGVyVXNlcnMgPSAoKSA9PiB7XHJcbiAgICBpZiAoaXNMb2FkaW5nKVxyXG4gICAgICByZXR1cm4gPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17aXNMb2FkaW5nfSBmYWlsdXJlPXtmYWxzZX0gZGF0YT1cIkN1c3RvbWVyIERhdGFcIiAvPjtcclxuXHJcbiAgICBjb25zdCB0YWJGaWx0ZXJlZFVzZXJzID0gZ2V0VGFiRmlsdGVyZWRVc2VycygpO1xyXG4gICAgY29uc3QgdGFiSW5kZXhPZkxhc3RJdGVtID0gY3VycmVudFBhZ2UgKiBpdGVtc1BlclBhZ2U7XHJcbiAgICBjb25zdCB0YWJJbmRleE9mRmlyc3RJdGVtID0gdGFiSW5kZXhPZkxhc3RJdGVtIC0gaXRlbXNQZXJQYWdlO1xyXG4gICAgY29uc3QgdGFiQ3VycmVudEl0ZW1zID0gdGFiRmlsdGVyZWRVc2Vycy5zbGljZSh0YWJJbmRleE9mRmlyc3RJdGVtLCB0YWJJbmRleE9mTGFzdEl0ZW0pO1xyXG4gICAgY29uc3QgdGFiVG90YWxQYWdlcyA9IE1hdGguY2VpbCh0YWJGaWx0ZXJlZFVzZXJzLmxlbmd0aCAvIGl0ZW1zUGVyUGFnZSk7XHJcblxyXG4gICAgaWYgKCF0YWJGaWx0ZXJlZFVzZXJzLmxlbmd0aClcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLWZ1bGwgcHktMjAgYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LXNtIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS0zMDAgbXgtYXV0byBtYi00XCI+XHJcbiAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy0xNiBoLTE2IG14LWF1dG9cIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIxLjVcIiBkPVwiTTE3IDIwaDV2LTJhMyAzIDAgMDAtNS4zNTYtMS44NTdNMTcgMjBIN20xMCAwdi0yYzAtLjY1Ni0uMTI2LTEuMjgzLS4zNTYtMS44NTdNNyAyMEgydi0yYTMgMyAwIDAxNS4zNTYtMS44NTdNNyAyMHYtMmMwLS42NTYuMTI2LTEuMjgzLjM1Ni0xLjg1N20wIDBhNS4wMDIgNS4wMDIgMCAwMTkuMjg4IDBNMTUgMTFhMyAzIDAgMTEtNiAwIDMgMyAwIDAxNiAwem02IDJhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCIgLz5cclxuICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwicGVuZGluZ1wiID8gXCJObyBwZW5kaW5nIGN1c3RvbWVycyBmb3VuZFwiIDogXCJObyBjb250YWN0ZWQgY3VzdG9tZXJzIGZvdW5kXCJ9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS00MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICB7YWN0aXZlVGFiID09PSBcInBlbmRpbmdcIiA/IFwiQWxsIGN1c3RvbWVycyBoYXZlIGJlZW4gY29udGFjdGVkXCIgOiBcIlRyeSBzd2l0Y2hpbmcgdG8gdGhlIFBlbmRpbmcgdGFiIG9yIGFkanVzdCB5b3VyIHNlYXJjaFwifVxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApO1xyXG5cclxuICAgIGlmICh2aWV3TW9kZSA9PT0gXCJncmlkXCIpXHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIHhsOmdyaWQtY29scy0zIGdhcC02XCI+XHJcbiAgICAgICAgICB7dGFiQ3VycmVudEl0ZW1zLm1hcChyZW5kZXJDdXN0b21lckNhcmQpfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApO1xyXG4gICAgaWYgKHZpZXdNb2RlID09PSBcImxpc3RcIilcclxuICAgICAgcmV0dXJuIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxyXG4gICAgICAgICAge3RhYkN1cnJlbnRJdGVtcy5tYXAoKHUpID0+IChcclxuICAgICAgICAgICAgPFVzZXJSb3cga2V5PXt1LmlkfSB1c2VyPXt1fSAvPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICk7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBzaGFkb3ctc20gYmctd2hpdGVcIj5cclxuICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgIGRhdGE9e1RhYmxlVXNlcnMuZmlsdGVyKCh1KSA9PlxyXG4gICAgICAgICAgICBhY3RpdmVUYWIgPT09IFwiY29udGFjdGVkXCIgPyB1LnN0YXR1c1JhdyAmJiB1LnN0YXR1c1JhdyAhPT0gXCJOb3QgQ29udGFjdGVkXCIgOiAhdS5zdGF0dXNSYXcgfHwgdS5zdGF0dXNSYXcgPT09IFwiTm90IENvbnRhY3RlZFwiXHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIlVuQXBwcm92ZWRcIlxyXG4gICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIlVuQXBwcm92ZWQuY3N2XCJcclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgLy8gLS0tIFBBR0lOQVRJT04gLS0tXHJcbiAgY29uc3QgU2ltcGxlUGFnaW5hdGlvbiA9ICh7IGN1cnJlbnRQYWdlLCB0b3RhbFBhZ2VzLCBvblBhZ2VDaGFuZ2UgfSkgPT4ge1xyXG4gICAgaWYgKHRvdGFsUGFnZXMgPD0gMSkgcmV0dXJuIG51bGw7XHJcbiAgICBjb25zdCBwYWdlcyA9IFtdO1xyXG4gICAgY29uc3QgbWF4ID0gNTtcclxuICAgIHBhZ2VzLnB1c2goMSk7XHJcbiAgICBpZiAodG90YWxQYWdlcyA+IG1heCkge1xyXG4gICAgICBpZiAoY3VycmVudFBhZ2UgPiAzKSBwYWdlcy5wdXNoKFwiLi4uXCIpO1xyXG4gICAgICBmb3IgKGxldCBpID0gTWF0aC5tYXgoMiwgY3VycmVudFBhZ2UgLSAxKTsgaSA8PSBNYXRoLm1pbih0b3RhbFBhZ2VzIC0gMSwgY3VycmVudFBhZ2UgKyAxKTsgaSsrKSB7XHJcbiAgICAgICAgaWYgKGkgIT09IDEgJiYgaSAhPT0gdG90YWxQYWdlcykgcGFnZXMucHVzaChpKTtcclxuICAgICAgfVxyXG4gICAgICBpZiAoY3VycmVudFBhZ2UgPCB0b3RhbFBhZ2VzIC0gMikgcGFnZXMucHVzaChcIi4uLlwiKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGZvciAobGV0IGkgPSAyOyBpIDw9IHRvdGFsUGFnZXM7IGkrKykgcGFnZXMucHVzaChpKTtcclxuICAgIH1cclxuICAgIGlmICh0b3RhbFBhZ2VzID4gMSkgcGFnZXMucHVzaCh0b3RhbFBhZ2VzKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgbXQtOFwiPlxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUGFnZUNoYW5nZShjdXJyZW50UGFnZSAtIDEpfVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e2N1cnJlbnRQYWdlID09PSAxfVxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwicHgtMy41IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmF5LTUwIGhvdmVyOnNoYWRvdy1zbSBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgUHJldlxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIHtwYWdlcy5tYXAoKHBhZ2UsIGkpID0+IChcclxuICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAga2V5PXtpfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0eXBlb2YgcGFnZSA9PT0gXCJudW1iZXJcIiAmJiBvblBhZ2VDaGFuZ2UocGFnZSl9XHJcbiAgICAgICAgICAgIGRpc2FibGVkPXt0eXBlb2YgcGFnZSAhPT0gXCJudW1iZXJcIn1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy0xMCBoLTEwIHRleHQtc20gZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke3BhZ2UgPT09IGN1cnJlbnRQYWdlXHJcbiAgICAgICAgICAgICAgPyBcImJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LXZpb2xldC0yMDBcIlxyXG4gICAgICAgICAgICAgIDogdHlwZW9mIHBhZ2UgPT09IFwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgID8gXCJiZy13aGl0ZSB0ZXh0LWdyYXktNzAwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgaG92ZXI6YmctZ3JheS01MCBob3ZlcjpzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIHRleHQtZ3JheS00MDAgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBjdXJzb3ItZGVmYXVsdFwiXHJcbiAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtwYWdlfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25QYWdlQ2hhbmdlKGN1cnJlbnRQYWdlICsgMSl9XHJcbiAgICAgICAgICBkaXNhYmxlZD17Y3VycmVudFBhZ2UgPT09IHRvdGFsUGFnZXN9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIGhvdmVyOmJnLWdyYXktNTAgaG92ZXI6c2hhZG93LXNtIGRpc2FibGVkOm9wYWNpdHktNDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRyYW5zaXRpb24tYWxsXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICBOZXh0XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9e2BmbGV4IG92ZXJmbG93LXgtaGlkZGVuICR7IWhpZGVTaWRlYmFyID8gXCJtdC0yMFwiIDogXCJtdC0yXCJ9YH0+XHJcbiAgICAgICAgeyFoaWRlU2lkZWJhciAmJiA8U2lkZWJhciAvPn1cclxuICAgICAgICB7LyogPE5hdmJhciBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e0dsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9IHZpc2liaWxpdHk9e3RydWV9IC8+ICovfVxyXG4gICAgICAgIDxOYXZiYXIgdmlzaWJpbGl0eT17ZmFsc2V9IC8+XHJcbiAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFsZXJ0Q29uZmlnKChwKSA9PiAoeyAuLi5wLCB2aXNpYmlsaXR5OiBmYWxzZSB9KSl9XHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LTAgcC00IGxnOnAtNiBiZy1zbGF0ZS01MCBtaW4taC1zY3JlZW4gb3ZlcmZsb3cteC1oaWRkZW5cIj5cclxuICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcblxyXG4gICAgICAgICAgey8qIEhlYWRlciBCYXIgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHAtNSBtYi02XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBsZzpmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgbGc6aXRlbXMtY2VudGVyIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCB0cmFja2luZy10aWdodFwiPlVudmVyaWZpZWQgQ3VzdG9tZXJzPC9oMT5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0xXCI+TWFuYWdlIGFuZCBmb2xsb3cgdXAgb24gcGVuZGluZyBlbnJvbGxtZW50czwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTMgdy1mdWxsIGxnOnctYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGJnLXNsYXRlLTEwMCByb3VuZGVkLXhsIHAtMSBnYXAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwicGVuZGluZ1wiKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgcm91bmRlZC1sZyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsICR7YWN0aXZlVGFiID09PSBcInBlbmRpbmdcIiA/IFwiYmctd2hpdGUgdGV4dC12aW9sZXQtNzAwIHNoYWRvdy1zbVwiIDogXCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS04MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQZW5kaW5nICh7ZmlsdGVyZWRVc2Vycy5maWx0ZXIoKHUpID0+IHUuc3RhdHVzID09PSBcIk5vdCBDb250YWN0ZWRcIiB8fCAhdS5zdGF0dXMpLmxlbmd0aH0pXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKFwiY29udGFjdGVkXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMiByb3VuZGVkLWxnIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgJHthY3RpdmVUYWIgPT09IFwiY29udGFjdGVkXCIgPyBcImJnLXdoaXRlIHRleHQtdmlvbGV0LTcwMCBzaGFkb3ctc21cIiA6IFwidGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktODAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ29udGFjdGVkICh7ZmlsdGVyZWRVc2Vycy5maWx0ZXIoKHUpID0+IHUuc3RhdHVzICYmIHUuc3RhdHVzICE9PSBcIk5vdCBDb250YWN0ZWRcIikubGVuZ3RofSlcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLXNsYXRlLTEwMCByb3VuZGVkLXhsIHAtMVwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld01vZGUoXCJncmlkXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLWxnIHRyYW5zaXRpb24tYWxsICR7dmlld01vZGUgPT09IFwiZ3JpZFwiID8gXCJiZy13aGl0ZSB0ZXh0LXZpb2xldC03MDAgc2hhZG93LXNtXCIgOiBcInRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTgwMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8TWRHcmlkVmlldyBjbGFzc05hbWU9XCJ0ZXh0LWxnXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3TW9kZShcImxpc3RcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHt2aWV3TW9kZSA9PT0gXCJsaXN0XCIgPyBcImJnLXdoaXRlIHRleHQtdmlvbGV0LTcwMCBzaGFkb3ctc21cIiA6IFwidGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktODAwXCJ9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxNZFZpZXdMaXN0IGNsYXNzTmFtZT1cInRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdNb2RlKFwidGFibGVcIil9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHt2aWV3TW9kZSA9PT0gXCJ0YWJsZVwiID8gXCJiZy13aGl0ZSB0ZXh0LXZpb2xldC03MDAgc2hhZG93LXNtXCIgOiBcInRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTgwMFwifWB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8TWRPdXRsaW5lVGFibGVSb3dzIGNsYXNzTmFtZT1cInRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC01XCI+XHJcbiAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBieSBuYW1lIG9yIHBob25lXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cclxuICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCB2YWwgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgICAgICAgICAgICAgICAgc2V0U2VhcmNoUXVlcnkodmFsKTtcclxuICAgICAgICAgICAgICAgICAgaWYgKHZhbCA9PT0gJycpIHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTZWFyY2hUZXJtKCcnKTsgICAvLyDwn5SlIHJlc2V0IGZpbHRlciB3aGVuIGlucHV0IGlzIGNsZWFyZWRcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIG9uUHJlc3NFbnRlcj17KCkgPT4gc2V0U2VhcmNoVGVybShzZWFyY2hRdWVyeSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTEwIHctODAgcm91bmRlZC1sZyBib3JkZXItZ3JheS0zMDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTIwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBpY29uPXs8U2VhcmNoT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWFyY2hUZXJtKHNlYXJjaFF1ZXJ5KX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTAgYmctdmlvbGV0LTYwMCBob3ZlcjpiZy12aW9sZXQtNzAwIGJvcmRlci12aW9sZXQtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBTZWFyY2hcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIOKYhSBDT05UQUNUIFNVTU1BUlkg4oCUIG9ubHkgaW4gQ29udGFjdGVkIHRhYiAqL31cclxuICAgICAgICAgIHthY3RpdmVUYWIgPT09IFwiY29udGFjdGVkXCIgJiYgIWlzTG9hZGluZyAmJiA8Q29udGFjdFN1bW1hcnlEYXNoYm9hcmQgLz59XHJcblxyXG4gICAgICAgICAge3JlbmRlclVzZXJzKCl9XHJcblxyXG4gICAgICAgICAge3ZpZXdNb2RlICE9PSBcInRhYmxlXCIgJiYgZ2V0VGFiRmlsdGVyZWRVc2VycygpLmxlbmd0aCA+IGl0ZW1zUGVyUGFnZSAmJiAoXHJcbiAgICAgICAgICAgIDxTaW1wbGVQYWdpbmF0aW9uXHJcbiAgICAgICAgICAgICAgY3VycmVudFBhZ2U9e2N1cnJlbnRQYWdlfVxyXG4gICAgICAgICAgICAgIHRvdGFsUGFnZXM9e01hdGguY2VpbChnZXRUYWJGaWx0ZXJlZFVzZXJzKCkubGVuZ3RoIC8gaXRlbXNQZXJQYWdlKX1cclxuICAgICAgICAgICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2VDaGFuZ2V9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiA9PT09PT09PT09IEFTU0lHTiAmIFVQREFURSBNT0RBTCA9PT09PT09PT09ICovfVxyXG4gICAgICA8TW9kYWxcclxuICAgICAgICBpc1Zpc2libGU9e3Nob3dBY3Rpb25Nb2RhbH1cclxuICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICBzZXRTaG93QWN0aW9uTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgc2V0QWN0aW9uQXNzaWdubWVudHMoe30pO1xyXG4gICAgICAgIH19XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNiB0ZXh0LWxlZnQgbWF4LWgtWzg1dmhdIG92ZXJmbG93LXktYXV0byBwci0yXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSBiZy1ibHVlLTEwMCByb3VuZGVkLXhsIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICA8TWRBc3NpZ25tZW50SW5kIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPkFzc2lnbiAmIFVwZGF0ZSBTdGF0dXM8L2gzPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgWW91IGFyZSBhc3NpZ25pbmd7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ibHVlLTYwMFwiPntzZWxlY3RlZEN1c3RvbWVycy5sZW5ndGh9PC9zcGFuPiBjdXN0b21lcihzKS4gU2VsZWN0IGFkbWluLCBzdGF0dXMsIGFuZCBhZGQgcmVtYXJrcyBmb3IgZWFjaC5cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgbWF4LWgtWzU1dmhdIG92ZXJmbG93LXktYXV0byBwci0yIGN1c3RvbS1zY3JvbGxiYXJcIj5cclxuICAgICAgICAgICAge3NlbGVjdGVkQ3VzdG9tZXJzLm1hcCgoaWQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgdXNlciA9IGZpbHRlcmVkVXNlcnMuZmluZCgodSkgPT4gdS5faWQgPT09IGlkKTtcclxuICAgICAgICAgICAgICBpZiAoIXVzZXIpIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRBc3NpZ24gPSBhY3Rpb25Bc3NpZ25tZW50c1tpZF0gfHwge307XHJcbiAgICAgICAgICAgICAgY29uc3QgcHJlRmlsbGVkQWRtaW4gPSBjdXJyZW50QXNzaWduLmFkbWluSWQgfHwgdXNlci5hc3NpZ25lZF90b19pZCB8fCB1bmRlZmluZWQ7XHJcblxyXG4gICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR9IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcC00IGhvdmVyOnNoYWRvdy1zbSB0cmFuc2l0aW9uLXNoYWRvd1wiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBtYi00IHBiLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLWZ1bGwgYmctc2xhdGUtMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtNjAwIGZvbnQtYm9sZCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtpbmRleCArIDF9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+e3VzZXIubmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj57dXNlci5waG9uZV9udW1iZXJ9PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAge3VzZXIuYXNzaWduZWRfdG8gPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctaW5kaWdvLTUwIHB4LTMgcHktMSByb3VuZGVkLWxnIHNlbGYtc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTQgaC00IHJvdW5kZWQtZnVsbCBiZy1pbmRpZ28tMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOHB4XSBmb250LWJvbGQgdGV4dC1pbmRpZ28tNzAwXCI+e3VzZXIuYXNzaWduZWRfdG8/LmNoYXJBdCgwKT8udG9VcHBlckNhc2UoKX08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1pbmRpZ28tNzAwXCI+e3VzZXIuYXNzaWduZWRfdG99PC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1yZWQtNTAgcHgtMyBweS0xIHJvdW5kZWQtbGcgc2VsZi1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtcmVkLTUwMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTEyIDh2NG0wIDRoLjAxTTIxIDEyYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtNjAwXCI+VW5hc3NpZ25lZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFkbWluIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEFkbWluXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3ByZUZpbGxlZEFkbWluIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQXNzaWdubWVudENoYW5nZShpZCwgXCJhZG1pbklkXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiAob3B0aW9uPy5sYWJlbCA/PyBcIlwiKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXthZG1pbnMubWFwKChhZG1pbikgPT4gKHsgbGFiZWw6IGFkbWluLmZ1bGxfbmFtZSB8fCBhZG1pbi5uYW1lLCB2YWx1ZTogYWRtaW4uX2lkIH0pKX1cclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMS41IHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTdGF0dXMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50QXNzaWduLnN0YXR1cyB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFzc2lnbm1lbnRDaGFuZ2UoaWQsIFwic3RhdHVzXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtTVEFUVVNfT1BUSU9OUy5tYXAoKG9wdCkgPT4gKHsgbGFiZWw6IG9wdCwgdmFsdWU6IG9wdCB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFJlbWFya3tcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRBc3NpZ24uc3RhdHVzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwIGZvbnQtbm9ybWFsIG5vcm1hbC1jYXNlIHRyYWNraW5nLW5vcm1hbCBtbC0xXCI+KGF1dG8tZmlsbGVkIHdpdGggc3RhdHVzKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8SW5wdXQuVGV4dEFyZWFcclxuICAgICAgICAgICAgICAgICAgICAgICAgcm93cz17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9e2N1cnJlbnRBc3NpZ24uc3RhdHVzID8gYFwiJHtjdXJyZW50QXNzaWduLnN0YXR1c31cIiDigJQgYWRkIGV4dHJhIGRldGFpbHMgaGVyZS4uLmAgOiBcIlNlbGVjdCBhIHN0YXR1cyBmaXJzdC4uLlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudEFzc2lnbi5yZW1hcmsgfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVBc3NpZ25tZW50Q2hhbmdlKGlkLCBcInJlbWFya1wiLCBlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCByZXNpemUtbm9uZSByb3VuZGVkLWxnIGJvcmRlci1zbGF0ZS0zMDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtjdXJyZW50QXNzaWduLnN0YXR1cyA9PT0gXCJGb2xsb3cgVXBcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1kOmNvbC1zcGFuLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS02MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRm9sbG93IFVwIERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudEFzc2lnbi5mb2xsb3dVcERhdGUgPyBkYXlqcyhjdXJyZW50QXNzaWduLmZvbGxvd1VwRGF0ZSkgOiBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoXywgZGF0ZVN0cmluZykgPT4gaGFuZGxlQXNzaWdubWVudENoYW5nZShpZCwgXCJmb2xsb3dVcERhdGVcIiwgZGF0ZVN0cmluZyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTEgcm91bmRlZC1sZyBib3JkZXItcHVycGxlLTMwMCBob3Zlcjpib3JkZXItcHVycGxlLTQwMCBmb2N1czpib3JkZXItcHVycGxlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybWF0PVwiWVlZWS1NTS1ERFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgZm9sbG93LXVwIGRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkRGF0ZT17KGN1cnJlbnQpID0+IGN1cnJlbnQgJiYgY3VycmVudCA8IGRheWpzKCkuc3RhcnRPZihcImRheVwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1wdXJwbGUtNTAwIG10LTFcIj5TZWxlY3QgYSBmdXR1cmUgZGF0ZSBmb3IgdGhlIGZvbGxvdy11cDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgeyFjdXJyZW50QXNzaWduLnN0YXR1cyAmJiB1c2VyLnJlbWFyayAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHB0LTMgYm9yZGVyLXQgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTFcIj5QcmV2aW91cyBSZW1hcms8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGJnLXNsYXRlLTUwIHJvdW5kZWQtbGcgcC0yXCI+e3VzZXIucmVtYXJrfTwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zIG10LTYgcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwiZGVmYXVsdFwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0U2hvd0FjdGlvbk1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgIHNldEFjdGlvbkFzc2lnbm1lbnRzKHt9KTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTEgcHgtNiBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCB0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS01MCByb3VuZGVkLXhsIGZvbnQtbWVkaXVtXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICBsb2FkaW5nPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQnVsa0FjdGlvblN1Ym1pdH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTExIHB4LTYgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWluZGlnby02MDAgaG92ZXI6ZnJvbS1ibHVlLTcwMCBob3Zlcjp0by1pbmRpZ28tNzAwIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCByb3VuZGVkLXhsIHNoYWRvdy1tZCBzaGFkb3ctYmx1ZS0yMDAgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgU3VibWl0XHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICB7LyogPT09PT09PT09PSBVUERBVEUgTU9EQUwgPT09PT09PT09PSAqL31cclxuICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd01vZGFsVXBkYXRlfSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpfT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNiB0ZXh0LWxlZnQgbWF4LWgtWzg1dmhdIG92ZXJmbG93LXktYXV0byBwci0yXCI+XHJcbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBtYi02XCI+VXBkYXRlIEN1c3RvbWVyIERldGFpbHM8L2gzPlxyXG4gICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS01XCIgb25TdWJtaXQ9e2hhbmRsZVVwZGF0ZX0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC01XCI+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xLjUgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5UaXRsZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0IHBsYWNlaG9sZGVyPVwiU2VsZWN0XCIgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy50aXRsZSB8fCB1bmRlZmluZWR9IG9uQ2hhbmdlPXsodikgPT4gaGFuZGxlQW50SW5wdXREU2VsZWN0KFwidGl0bGVcIiwgdil9IGNsYXNzTmFtZT1cInctZnVsbCBoLTExXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtbXCJNclwiLCBcIk1zXCIsIFwiTXJzXCIsIFwiTS9TXCIsIFwiRHJcIl0ubWFwKCh0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt0fSB2YWx1ZT17dH0+e3R9PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMS41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+RnVsbCBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dCBuYW1lPVwiZnVsbF9uYW1lXCIgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5mdWxsX25hbWV9IG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX0gcmVxdWlyZWQgY2xhc3NOYW1lPVwiaC0xMSByb3VuZGVkLWxnXCIgLz5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuZnVsbF9uYW1lICYmIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC01MDBcIj57ZXJyb3JzLmZ1bGxfbmFtZX08L3A+fVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMS41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+RW1haWw8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0IHR5cGU9XCJlbWFpbFwiIG5hbWU9XCJlbWFpbFwiIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uZW1haWx9IG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX0gY2xhc3NOYW1lPVwiaC0xMSByb3VuZGVkLWxnXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEuNSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlBob25lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dCB0eXBlPVwibnVtYmVyXCIgbmFtZT1cInBob25lX251bWJlclwiIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucGhvbmVfbnVtYmVyfSBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9IHJlcXVpcmVkIGNsYXNzTmFtZT1cImgtMTEgcm91bmRlZC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lX251bWJlciAmJiA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQteHMgdGV4dC1yZWQtNTAwXCI+e2Vycm9ycy5waG9uZV9udW1iZXJ9PC9wPn1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEuNSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPkFhZGhhciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXQgbmFtZT1cImFkaGFhcl9ub1wiIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uYWRoYWFyX25vfSBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9IHJlcXVpcmVkIGNsYXNzTmFtZT1cImgtMTEgcm91bmRlZC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xLjUgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5QQU48L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0IG5hbWU9XCJwYW5fbm9cIiB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnBhbl9ub30gb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfSBjbGFzc05hbWU9XCJoLTExIHJvdW5kZWQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMS41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+QWRkcmVzcyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPElucHV0IG5hbWU9XCJhZGRyZXNzXCIgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5hZGRyZXNzfSBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9IHJlcXVpcmVkIGNsYXNzTmFtZT1cImgtMTEgcm91bmRlZC1sZ1wiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTVcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEuNSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlBpbmNvZGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0IG5hbWU9XCJwaW5jb2RlXCIgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5waW5jb2RlfSBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9IGNsYXNzTmFtZT1cImgtMTEgcm91bmRlZC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xLjUgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5GYXRoZXImYXBvcztzIE5hbWU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPElucHV0IG5hbWU9XCJmYXRoZXJfbmFtZVwiIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uZmF0aGVyX25hbWV9IG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX0gY2xhc3NOYW1lPVwiaC0xMSByb3VuZGVkLWxnXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEuNSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPkdlbmRlcjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0IHBsYWNlaG9sZGVyPVwiU2VsZWN0XCIgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5nZW5kZXIgfHwgdW5kZWZpbmVkfSBvbkNoYW5nZT17KHYpID0+IGhhbmRsZUFudElucHV0RFNlbGVjdChcImdlbmRlclwiLCB2KX0gY2xhc3NOYW1lPVwidy1mdWxsIGgtMTFcIj5cclxuICAgICAgICAgICAgICAgICAge1tcIk1hbGVcIiwgXCJGZW1hbGVcIl0ubWFwKChnKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtnfSB2YWx1ZT17Z30+e2d9PC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMS41IHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+RE9CPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dCB0eXBlPVwiZGF0ZVwiIG5hbWU9XCJkYXRlb2ZiaXJ0aFwiIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uZGF0ZW9mYmlydGh9IG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX0gY2xhc3NOYW1lPVwiaC0xMSByb3VuZGVkLWxnXCIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBwdC00IGJvcmRlci10IGJvcmRlci1ncmF5LTEwMCBtdC02XCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKX0gY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgdGV4dC1ncmF5LTcwMCBiZy1ncmF5LTEwMCBob3ZlcjpiZy1ncmF5LTIwMCByb3VuZGVkLXhsIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnNcIj5DYW5jZWw8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJweC01IHB5LTIuNSB0ZXh0LXdoaXRlIGJnLXZpb2xldC02MDAgaG92ZXI6YmctdmlvbGV0LTcwMCByb3VuZGVkLXhsIHRleHQtc20gZm9udC1tZWRpdW0gc2hhZG93LXNtIHNoYWRvdy12aW9sZXQtMjAwIHRyYW5zaXRpb24tYWxsXCI+VXBkYXRlIEN1c3RvbWVyPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgey8qID09PT09PT09PT0gREVMRVRFIE1PREFMID09PT09PT09PT0gKi99XHJcbiAgICAgIDxNb2RhbCBpc1Zpc2libGU9e3Nob3dNb2RhbERlbGV0ZX0gb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKX0+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTYgdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTRcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgYmctcmVkLTEwMCByb3VuZGVkLXhsIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy02IGgtNlwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTkgN2wtLjg2NyAxMi4xNDJBMiAyIDAgMDExNi4xMzggMjFINy44NjJhMiAyIDAgMDEtMS45OTUtMS44NThMNSA3bTUgNHY2bTQtNnY2bTEtMTBWNGExIDEgMCAwMC0xLTFoLTRhMSAxIDAgMDAtMSAxdjNNNCA3aDE2XCIgLz5cclxuICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+RGVsZXRlIEN1c3RvbWVyPC9oMz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCBtYi02IHBsLTExXCI+XHJcbiAgICAgICAgICAgIEFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+e2N1cnJlbnRVc2VyPy5mdWxsX25hbWV9PC9zcGFuPj8gVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS5cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBwbC0xMVwiPlxyXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpfSBjbGFzc05hbWU9XCJweC01IHB5LTIuNSB0ZXh0LWdyYXktNzAwIGJnLWdyYXktMTAwIGhvdmVyOmJnLWdyYXktMjAwIHJvdW5kZWQteGwgdGV4dC1zbSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWNvbG9yc1wiPkNhbmNlbDwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXtoYW5kbGVEZWxldGVVc2VyfSBjbGFzc05hbWU9XCJweC01IHB5LTIuNSB0ZXh0LXdoaXRlIGJnLXJlZC02MDAgaG92ZXI6YmctcmVkLTcwMCByb3VuZGVkLXhsIHRleHQtc20gZm9udC1tZWRpdW0gc2hhZG93LXNtIHNoYWRvdy1yZWQtMjAwIHRyYW5zaXRpb24tYWxsXCI+RGVsZXRlIEZvcmV2ZXI8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgey8qID09PT09PT09PT0gU1RBVFVTIFVQREFURSBNT0RBTCAoZm9yIGNvbnRhY3RlZCBjdXN0b21lcnMpID09PT09PT09PT0gKi99XHJcbiAgICAgIDxNb2RhbFxyXG4gICAgICAgIGlzVmlzaWJsZT17c2hvd1N0YXR1c1VwZGF0ZU1vZGFsfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dTdGF0dXNVcGRhdGVNb2RhbChmYWxzZSl9XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNiB0ZXh0LWxlZnQgbWF4LWgtWzg1dmhdIG92ZXJmbG93LXktYXV0byBwci0yXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIG1iLTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSBiZy1ibHVlLTEwMCByb3VuZGVkLXhsIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNiBoLTZcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTExIDVINmEyIDIgMCAwMC0yIDJ2MTFhMiAyIDAgMDAyIDJoMTFhMiAyIDAgMDAyLTJ2LTVtLTEuNDE0LTkuNDE0YTIgMiAwIDExMi44MjggMi44MjhMMTEuODI4IDE1SDl2LTIuODI4bDguNTg2LTguNTg2elwiIC8+XHJcbiAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+VXBkYXRlIFN0YXR1czwvaDM+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+Q2hhbmdlIHRoZSBjb250YWN0IHN0YXR1cyBhbmQgcmVtYXJrIGZvciB0aGlzIGN1c3RvbWVyLjwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xLjUgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICBTdGF0dXMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17c3RhdHVzVXBkYXRlRGF0YS5zdGF0dXMgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gc2V0U3RhdHVzVXBkYXRlRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIHN0YXR1czogdmFsdWUgfSkpfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTFcIlxyXG4gICAgICAgICAgICAgICAgb3B0aW9ucz17U1RBVFVTX09QVElPTlMubWFwKG9wdCA9PiAoeyBsYWJlbDogb3B0LCB2YWx1ZTogb3B0IH0pKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgIFJlbWFya1xyXG4gICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPElucHV0LlRleHRBcmVhXHJcbiAgICAgICAgICAgICAgICByb3dzPXszfVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBZGQgYSByZW1hcmsuLi5cIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3N0YXR1c1VwZGF0ZURhdGEucmVtYXJrfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdGF0dXNVcGRhdGVEYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgcmVtYXJrOiBlLnRhcmdldC52YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcmVzaXplLW5vbmUgcm91bmRlZC1sZyBib3JkZXItc2xhdGUtMzAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTIwMFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7c3RhdHVzVXBkYXRlRGF0YS5zdGF0dXMgPT09ICdGb2xsb3cgVXAnICYmIChcclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS02MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIEZvbGxvdyBVcCBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPERhdGVQaWNrZXJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3N0YXR1c1VwZGF0ZURhdGEuZm9sbG93X3VwX2RhdGUgPyBkYXlqcyhzdGF0dXNVcGRhdGVEYXRhLmZvbGxvd191cF9kYXRlKSA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoXywgZGF0ZVN0cmluZykgPT4gc2V0U3RhdHVzVXBkYXRlRGF0YShwcmV2ID0+ICh7IC4uLnByZXYsIGZvbGxvd191cF9kYXRlOiBkYXRlU3RyaW5nIH0pKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTEgcm91bmRlZC1sZyBib3JkZXItcHVycGxlLTMwMCBob3Zlcjpib3JkZXItcHVycGxlLTQwMCBmb2N1czpib3JkZXItcHVycGxlLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGZvcm1hdD1cIllZWVktTU0tRERcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBmb2xsb3ctdXAgZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkRGF0ZT17KGN1cnJlbnQpID0+IGN1cnJlbnQgJiYgY3VycmVudCA8IGRheWpzKCkuc3RhcnRPZignZGF5Jyl9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1wdXJwbGUtNTAwIG10LTFcIj5TZWxlY3QgYSBmdXR1cmUgZGF0ZSBmb3IgdGhlIGZvbGxvdy11cDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMyBtdC02IHB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImRlZmF1bHRcIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dTdGF0dXNVcGRhdGVNb2RhbChmYWxzZSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMSBweC02IGJvcmRlciBib3JkZXItc2xhdGUtMzAwIHRleHQtc2xhdGUtNzAwIGhvdmVyOmJnLXNsYXRlLTUwIHJvdW5kZWQteGwgZm9udC1tZWRpdW1cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgIGxvYWRpbmc9e2lzU3RhdHVzVXBkYXRpbmd9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlU3RhdHVzVXBkYXRlU3VibWl0fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTEgcHgtNiBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8taW5kaWdvLTYwMCBob3Zlcjpmcm9tLWJsdWUtNzAwIGhvdmVyOnRvLWluZGlnby03MDAgdGV4dC13aGl0ZSBmb250LXNlbWlib2xkIHJvdW5kZWQteGwgc2hhZG93LW1kIHNoYWRvdy1ibHVlLTIwMCB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBVcGRhdGUgU3RhdHVzXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvTW9kYWw+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVW5BcHByb3ZlZEN1c3RvbWVyOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9VbkFwcHJvdmVkQ3VzdG9tZXIuanN4In0=