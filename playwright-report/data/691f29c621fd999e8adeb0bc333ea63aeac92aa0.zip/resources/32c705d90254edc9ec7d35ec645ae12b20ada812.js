import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AllUserReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select, message } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import {
  Users,
  UserCheck,
  Layers3,
  Wallet,
  TrendingUp,
  IndianRupee,
  BadgeIndianRupee,
  Trophy,
  Shield
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
const AllUserReport = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [screenLoading, setScreenLoading] = useState(true);
  const [error, setError] = useState(null);
  const [usersData, setUsersData] = useState([]);
  const [filters, setFilters] = useState({
    groupFilter: "All",
    referredByFilter: "All",
    relationshipManagerFilter: "All",
    fromDate: "",
    toDate: "",
    customerStatusFilter: "All"
  });
  const StatsCard = ({
    title,
    value,
    icon: Icon,
    gradient,
    iconBg = "bg-white/20"
  }) => /* @__PURE__ */ jsxDEV(
    "div",
    {
      className: `relative rounded-2xl ${gradient} text-white shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 p-4 lg:p-5`,
      children: [
        /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: `absolute top-4 right-4 ${iconBg} p-2 rounded-lg flex items-center justify-center`,
            children: /* @__PURE__ */ jsxDEV(Icon, { className: "w-4 h-4 lg:w-5 lg:h-5", strokeWidth: 2 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
              lineNumber: 48,
              columnNumber: 9
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 45,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-xs sm:text-sm font-medium text-white/80", children: title }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 52,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "mt-4 text-[clamp(14px,1.2vw,22px)] font-bold whitespace-nowrap", children: value }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 54,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 51,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
      lineNumber: 42,
      columnNumber: 3
    },
    this
  );
  const transformUserData = (userInfo, index) => {
    return {
      sl_no: index + 1,
      _id: userInfo._id,
      userId: userInfo?.user_id?._id || null,
      customerId: userInfo?.user_id?.customer_id || "N/A",
      userName: userInfo?.user_id?.full_name || "N/A",
      userPhone: userInfo?.user_id?.phone_number || "N/A",
      collectionArea: userInfo?.user_id?.collection_area?.route_name || "N/A",
      collectionExecutive: userInfo?.user_id?.collection_area?.agent_id?.length ? userInfo.user_id.collection_area.agent_id.map((agent) => agent.name).join(" | ") : "N/A",
      groupName: userInfo?.group_id?.group_name || "N/A",
      groupValue: Number(userInfo?.group_id?.group_value) || 0,
      firstInstallment: Number(userInfo?.group_id?.monthly_installment) || 0,
      paymentsTicket: userInfo?.tickets || 0,
      relationshipManager: userInfo?.group_id?.relationship_manager?.name || "N/A",
      referred_type: userInfo?.referred_type || "N/A",
      reffered_by: userInfo?.referred_agent?.name || userInfo?.referred_customer?.full_name || userInfo?.referred_lead?.full_name || "N/A",
      payment_type: userInfo?.payment_type || "N/A",
      customer_status: userInfo?.customer_status || "N/A",
      chit_asking_month: userInfo?.chit_asking_month || "N/A",
      enrollmentDate: userInfo?.createdAt ? userInfo.createdAt.split("T")[0] : "",
      amountPaid: Number(userInfo?.total_investment) || 0,
      profit: Number(userInfo?.total_profit) || 0,
      totalLateFee: Number(userInfo?.total_late_fee) || 0,
      totalPenalty: Number(userInfo?.total_penalty) || 0,
      toBePaidAmount: Number(userInfo?.total_payable) || 0,
      balance: Number(userInfo?.total_balance) || 0,
      firstInstallmentStatus: Number(userInfo?.total_investment) >= Number(userInfo?.group_id?.monthly_installment) ? "Paid" : "Not Paid",
      status: userInfo?.is_prized ? "Prized" : "Un Prized",
      isPrized: userInfo?.is_prized || false,
      statusDiv: userInfo?.is_prized ? /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center gap-2 bg-emerald-50 text-emerald-700 px-3 py-1.5 rounded-lg shadow-sm border border-emerald-200", children: [
        /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsxDEV(
          "path",
          {
            fillRule: "evenodd",
            d: "M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z",
            clipRule: "evenodd"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 130,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 129,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-sm", children: "Prized" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 137,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
        lineNumber: 128,
        columnNumber: 7
      }, this) : /* @__PURE__ */ jsxDEV("div", { className: "inline-flex items-center gap-2 bg-amber-50 text-amber-700 px-3 py-1.5 rounded-lg shadow-sm border border-amber-200", children: [
        /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsxDEV(
          "path",
          {
            fillRule: "evenodd",
            d: "M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z",
            clipRule: "evenodd"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 142,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 141,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-sm", children: "Un Prized" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 149,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
        lineNumber: 140,
        columnNumber: 7
      }, this)
    };
  };
  const groupOptions = useMemo(
    () => [...new Set(usersData.map((u) => u.groupName))],
    [usersData]
  );
  const customerStatusOptions = useMemo(
    () => [...new Set(usersData.map((u) => u.customer_status))].filter(Boolean),
    [usersData]
  );
  const referredByOptions = useMemo(
    () => [...new Set(usersData.map((u) => u.reffered_by))].filter(Boolean),
    [usersData]
  );
  const relationshipManagerOptions = useMemo(
    () => [...new Set(usersData.map((u) => u.relationshipManager))].filter(Boolean),
    [usersData]
  );
  const filteredUsers = useMemo(() => {
    return filterOption(
      usersData.filter((u) => {
        const matchGroup = filters.groupFilter === "All" || !filters.groupFilter ? true : u.groupName === filters.groupFilter;
        const matchReferredBy = filters.referredByFilter === "All" || !filters.referredByFilter ? true : u.reffered_by === filters.referredByFilter;
        const enrollmentDate = new Date(u.enrollmentDate);
        const matchFromDate = filters.fromDate ? enrollmentDate >= new Date(filters.fromDate) : true;
        const matchToDate = filters.toDate ? enrollmentDate <= new Date(filters.toDate) : true;
        const matchRelationshipManager = filters.relationshipManagerFilter === "All" || !filters.relationshipManagerFilter ? true : u.relationshipManager === filters.relationshipManagerFilter;
        const matchCustomerStatus = filters.customerStatusFilter === "All" || !filters.customerStatusFilter ? true : u.customer_status === filters.customerStatusFilter;
        return matchGroup && matchReferredBy && matchRelationshipManager && matchCustomerStatus && matchFromDate && matchToDate;
      }),
      searchText
    );
  }, [usersData, filters, searchText]);
  const totals = useMemo(() => {
    const totalEnrollments = filteredUsers.length;
    const groupSet = new Set(filteredUsers.map((user) => user.groupName));
    const totalGroups = filters.groupFilter === "All" ? groupSet.size : filters.groupFilter ? 1 : groupSet.size;
    const customerSet = new Set(
      filteredUsers.map((u) => u.userId).filter(Boolean)
    );
    const totalCustomers = customerSet.size;
    const prizedCount = filteredUsers.filter((u) => u.isPrized === true).length;
    const unprizedCount = filteredUsers.filter(
      (u) => u.isPrized === false
    ).length;
    const totalToBePaid = filteredUsers.reduce(
      (sum, u) => sum + (Number(u.toBePaidAmount) || 0),
      0
    );
    const totalProfit = filteredUsers.reduce(
      (sum, u) => sum + (u.profit || 0),
      0
    );
    const totalPaid = filteredUsers.reduce(
      (sum, u) => sum + (u.amountPaid || 0),
      0
    );
    const totalBalance = filteredUsers.reduce(
      (sum, u) => sum + (u.balance || 0),
      0
    );
    return {
      totalEnrollments,
      totalGroups,
      totalCustomers,
      prizedCount,
      unprizedCount,
      totalToBePaid,
      totalProfit,
      totalPaid,
      totalBalance
    };
  }, [filteredUsers, filters.groupFilter]);
  const handleFilterChange = useCallback((key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  }, []);
  useEffect(() => {
    const fetchData = async () => {
      try {
        setScreenLoading(true);
        setError(null);
        const reportResponse = await api.get("/v1/admin/users");
        const reportData = reportResponse.data.data.map(transformUserData);
        setUsersData(reportData);
      } catch (error2) {
        console.error("Error fetching data:", error2);
        setError("Failed to load data. Please try again later.");
        message.error("Failed to load data. Please try again later.");
      } finally {
        setScreenLoading(false);
      }
    };
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "customerId", header: "Customer Id" },
    { key: "customer_status", header: "Customer Status" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    { key: "groupName", header: "Group Name" },
    { key: "groupValue", header: "Group Value" },
    { key: "paymentsTicket", header: "Ticket" },
    { key: "enrollmentDate", header: "Enrollment Date" },
    { key: "referred_type", header: "Referred Type" },
    { key: "reffered_by", header: "Referred By" },
    { key: "chit_asking_month", header: "Chit Asking Month" },
    { key: "relationshipManager", header: "Relationship Manager" },
    { key: "payment_type", header: "Payment Type" },
    { key: "firstInstallment", header: "First Installment" },
    { key: "firstInstallmentStatus", header: "First Installment Status" },
    { key: "amountPaid", header: "Amount Paid" },
    { key: "totalLateFee", header: "Late Fee" },
    { key: "totalPenalty", header: "Penalty" },
    { key: "toBePaidAmount", header: "Payable Amount" },
    { key: "balance", header: "Balance" },
    { key: "collectionArea", header: "Collection Area" },
    { key: "collectionExecutive", header: "Collection Executive" },
    { key: "statusDiv", header: "Status" }
  ];
  const ExcelColumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "customerId", header: "Customer Id" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    { key: "groupName", header: "Group Name" },
    { key: "groupValue", header: "Group Value" },
    { key: "paymentsTicket", header: "Ticket" },
    { key: "enrollmentDate", header: "Enrollment Date" },
    { key: "referred_type", header: "Referred Type" },
    { key: "reffered_by", header: "Referred By" },
    { key: "relationshipManager", header: "Relationship Manager" },
    { key: "payment_type", header: "Payment Type" },
    { key: "firstInstallment", header: "First Installment" },
    { key: "toBePaidAmount", header: "Payable Amount" },
    { key: "amountPaid", header: "Amount Paid" },
    { key: "totalLateFee", header: "Late Fee" },
    { key: "totalPenalty", header: "Penalty" },
    { key: "balance", header: "Balance" },
    { key: "collectionArea", header: "Collection Area" },
    { key: "collectionExecutive", header: "Collection Executive" },
    { key: "status", header: "Status" }
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1 p-1", children: /* @__PURE__ */ jsxDEV("div", { className: " ", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
        lineNumber: 356,
        columnNumber: 9
      },
      this
    ),
    screenLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full flex flex-col justify-center items-center min-h-screen", children: [
      /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-indigo-600" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
        lineNumber: 362,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "mt-6 text-lg text-gray-600 font-medium", children: "Loading user data..." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
        lineNumber: 363,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
      lineNumber: 361,
      columnNumber: 9
    }, this) : error ? /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-center items-center p-8 min-h-screen", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white border-l-4 border-red-500 text-red-700 px-6 py-5 rounded-lg shadow-lg max-w-md", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start", children: [
      /* @__PURE__ */ jsxDEV(
        "svg",
        {
          className: "w-6 h-6 mr-3 flex-shrink-0",
          fill: "currentColor",
          viewBox: "0 0 20 20",
          children: /* @__PURE__ */ jsxDEV(
            "path",
            {
              fillRule: "evenodd",
              d: "M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z",
              clipRule: "evenodd"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
              lineNumber: 376,
              columnNumber: 19
            },
            this
          )
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 371,
          columnNumber: 17
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "font-semibold text-lg mb-1", children: "Error Loading Data" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 383,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: error }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 386,
          columnNumber: 19
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            className: "mt-4 bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200 shadow-md hover:shadow-lg",
            onClick: () => window.location.reload(),
            children: "Retry Loading"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 387,
            columnNumber: 19
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
        lineNumber: 382,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
      lineNumber: 370,
      columnNumber: 15
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
      lineNumber: 369,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
      lineNumber: 368,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex-grow max-w-screen p-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-8 mb-8 border border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center gap-3 mb-2", children: [
          /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-8 h-8 text-indigo-600",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                  lineNumber: 407,
                  columnNumber: 19
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
              lineNumber: 401,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold bg-gradient-to-r from-indigo-600 to-blue-600 bg-clip-text text-transparent", children: "All Customer Reports" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 414,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 400,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-center text-gray-500 text-sm", children: "Comprehensive overview of customer data and analytics" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 418,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
        lineNumber: 399,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-6 mb-8 border border-gray-100", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-5", children: [
          /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "w-5 h-5 text-indigo-600",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                  lineNumber: 431,
                  columnNumber: 19
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
              lineNumber: 425,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800", children: "Filters" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 438,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 424,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[200px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Group Filter" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
              lineNumber: 443,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                style: { width: "100%" },
                size: "large",
                showSearch: true,
                allowClear: false,
                placeholder: "Select Group",
                optionFilterProp: "children",
                filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
                value: filters.groupFilter,
                onChange: (value) => handleFilterChange("groupFilter", value),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "All", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                    lineNumber: 463,
                    columnNumber: 21
                  }, this),
                  groupOptions.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                      lineNumber: 466,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                lineNumber: 446,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 442,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[200px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Customer Status" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
              lineNumber: 473,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                style: { width: "100%" },
                size: "large",
                showSearch: true,
                allowClear: false,
                placeholder: "Select Customer Status",
                optionFilterProp: "children",
                filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
                value: filters.customerStatusFilter,
                onChange: (value) => handleFilterChange("customerStatusFilter", value),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "All", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                    lineNumber: 493,
                    columnNumber: 21
                  }, this),
                  customerStatusOptions.map(
                    (status) => /* @__PURE__ */ jsxDEV(Select.Option, { value: status, children: status }, status, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                      lineNumber: 496,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                lineNumber: 476,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 472,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[200px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Referred By" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
              lineNumber: 503,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                style: { width: "100%" },
                size: "large",
                showSearch: true,
                allowClear: false,
                placeholder: "Select Referred By",
                optionFilterProp: "children",
                filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
                value: filters.referredByFilter,
                onChange: (value) => handleFilterChange("referredByFilter", value),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "All", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                    lineNumber: 523,
                    columnNumber: 21
                  }, this),
                  referredByOptions.map(
                    (referrer) => /* @__PURE__ */ jsxDEV(Select.Option, { value: referrer, children: referrer }, referrer, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                      lineNumber: 526,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                lineNumber: 506,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 502,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[200px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "Relationship Manager" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
              lineNumber: 533,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                style: { width: "100%" },
                size: "large",
                showSearch: true,
                allowClear: false,
                placeholder: "Select Relationship Manager",
                optionFilterProp: "children",
                filterOption: (input, option) => (option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
                value: filters.relationshipManagerFilter,
                onChange: (value) => handleFilterChange("relationshipManagerFilter", value),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "All", children: "All" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                    lineNumber: 553,
                    columnNumber: 21
                  }, this),
                  relationshipManagerOptions.map(
                    (rm) => /* @__PURE__ */ jsxDEV(Select.Option, { value: rm, children: rm }, rm, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                      lineNumber: 556,
                      columnNumber: 19
                    }, this)
                  )
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                lineNumber: 536,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 532,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[180px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "From Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
              lineNumber: 564,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: filters.fromDate,
                onChange: (e) => handleFilterChange("fromDate", e.target.value),
                className: "w-full border-2 border-gray-200 rounded-lg px-4 py-2.5 focus:outline-none focus:border-indigo-500 transition-colors duration-200"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                lineNumber: 567,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 563,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "min-w-[180px]", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-gray-700 mb-2", children: "To Date" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
              lineNumber: 578,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "date",
                value: filters.toDate,
                onChange: (e) => handleFilterChange("toDate", e.target.value),
                className: "w-full border-2 border-gray-200 rounded-lg px-4 py-2.5 focus:outline-none focus:border-indigo-500 transition-colors duration-200"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
                lineNumber: 581,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 577,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 441,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
        lineNumber: 423,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-5 mb-8", children: [
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Customers",
            value: totals.totalCustomers,
            icon: Users,
            gradient: "bg-gradient-to-br from-pink-500 to-rose-500"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 595,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Enrollments",
            value: totals.totalEnrollments,
            icon: UserCheck,
            gradient: "bg-gradient-to-br from-blue-500 to-indigo-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 602,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Groups",
            value: totals.totalGroups,
            icon: Layers3,
            gradient: "bg-gradient-to-br from-emerald-500 to-green-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 609,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Prized",
            value: totals.prizedCount,
            icon: Trophy,
            gradient: "bg-gradient-to-br from-yellow-500 to-amber-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 616,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Unprized",
            value: totals.unprizedCount,
            icon: Shield,
            gradient: "bg-gradient-to-br from-gray-500 to-gray-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 623,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Payable",
            value: `₹${totals.totalToBePaid.toLocaleString("en-IN")}`,
            icon: Wallet,
            gradient: "bg-gradient-to-br from-purple-500 to-fuchsia-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 630,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Profit",
            value: `₹${totals.totalProfit.toLocaleString("en-IN")}`,
            icon: TrendingUp,
            gradient: "bg-gradient-to-br from-teal-500 to-cyan-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 637,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Paid",
            value: `₹${totals.totalPaid.toLocaleString("en-IN")}`,
            icon: IndianRupee,
            gradient: "bg-gradient-to-br from-indigo-500 to-violet-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 644,
            columnNumber: 15
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          StatsCard,
          {
            title: "Total Balance",
            value: `₹${totals.totalBalance.toLocaleString("en-IN")}`,
            icon: BadgeIndianRupee,
            gradient: "bg-gradient-to-br from-rose-500 to-red-600"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
            lineNumber: 651,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
        lineNumber: 594,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: filteredUsers,
          columns: Auctioncolumns,
          exportCols: ExcelColumns,
          exportedPdfName: `All Customer Report`,
          printHeaderKeys: [
            "From Date",
            "Group Name",
            "Referred By",
            "Customer Status",
            "Relationship Manager",
            "To Date",
            "Total Customers",
            "Total Groups",
            "Prized",
            "Unprized",
            "Amount Payable",
            "Total Profit",
            "Total Amount Paid",
            "Total Balance"
          ],
          printHeaderValues: [
            filters.fromDate ? new Date(filters.fromDate).toLocaleDateString("en-GB") : "—",
            filters.groupFilter || "All Groups",
            filters.referredByFilter || "All",
            filters.customerStatusFilter || "All",
            filters.relationshipManagerFilter || "All",
            filters.toDate ? new Date(filters.toDate).toLocaleDateString("en-GB") : "—",
            totals.totalCustomers,
            totals.totalGroups,
            totals.prizedCount,
            totals.unprizedCount,
            `₹${totals.totalToBePaid.toLocaleString("en-IN")}`,
            `₹${totals.totalProfit.toLocaleString("en-IN")}`,
            `₹${totals.totalPaid.toLocaleString("en-IN")}`,
            `₹${totals.totalBalance.toLocaleString("en-IN")}`
          ],
          exportedFileName: `CustomerReport.csv`
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
          lineNumber: 661,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
        lineNumber: 660,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
      lineNumber: 398,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
    lineNumber: 355,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx",
    lineNumber: 354,
    columnNumber: 5
  }, this);
};
_s(AllUserReport, "I9Pj1VGgKk4xOYvp9Gu9IICZPR8=");
_c = AllUserReport;
export default AllUserReport;
var _c;
$RefreshReg$(_c, "AllUserReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AllUserReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NROzJCQS9DUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLFVBQVVDLFNBQVNDLG1CQUFtQjtBQUMxRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLFFBQVFDLGVBQWU7QUFDaEMsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBRVAsTUFBTUMsZ0JBQWdCQSxNQUFNO0FBQUFDLEtBQUE7QUFDMUIsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUl0QixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDdUIsZUFBZUMsZ0JBQWdCLElBQUl4QixTQUFTLElBQUk7QUFDdkQsUUFBTSxDQUFDeUIsT0FBT0MsUUFBUSxJQUFJMUIsU0FBUyxJQUFJO0FBQ3ZDLFFBQU0sQ0FBQzJCLFdBQVdDLFlBQVksSUFBSTVCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM2QixTQUFTQyxVQUFVLElBQUk5QixTQUFTO0FBQUEsSUFDckMrQixhQUFhO0FBQUEsSUFDYkMsa0JBQWtCO0FBQUEsSUFDbEJDLDJCQUEyQjtBQUFBLElBQzNCQyxVQUFVO0FBQUEsSUFDVkMsUUFBUTtBQUFBLElBQ1JDLHNCQUFzQjtBQUFBLEVBQ3hCLENBQUM7QUFFRCxRQUFNQyxZQUFZQSxDQUFDO0FBQUEsSUFDakJDO0FBQUFBLElBQ0FDO0FBQUFBLElBQ0FDLE1BQU1DO0FBQUFBLElBQ05DO0FBQUFBLElBQ0FDLFNBQVM7QUFBQSxFQUNYLE1BQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLFdBQVcsd0JBQXdCRCxRQUFRO0FBQUEsTUFFM0M7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVywwQkFBMEJDLE1BQU07QUFBQSxZQUUzQyxpQ0FBQyxRQUFLLFdBQVUseUJBQXdCLGFBQWEsS0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQTtBQUFBLFVBSHpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsT0FBRSxXQUFVLGdEQUFnREwsbUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW1FO0FBQUEsVUFFbkUsdUJBQUMsUUFBRyxXQUFVLGtFQUNYQyxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQTtBQUFBO0FBQUEsSUFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnQkE7QUFHRixRQUFNSyxvQkFBb0JBLENBQUNDLFVBQVVDLFVBQVU7QUFDN0MsV0FBTztBQUFBLE1BQ0xDLE9BQU9ELFFBQVE7QUFBQSxNQUNmRSxLQUFLSCxTQUFTRztBQUFBQSxNQUVkQyxRQUFRSixVQUFVSyxTQUFTRixPQUFPO0FBQUEsTUFDbENHLFlBQVlOLFVBQVVLLFNBQVNFLGVBQWU7QUFBQSxNQUM5Q0MsVUFBVVIsVUFBVUssU0FBU0ksYUFBYTtBQUFBLE1BQzFDQyxXQUFXVixVQUFVSyxTQUFTTSxnQkFBZ0I7QUFBQSxNQUU5Q0MsZ0JBQWdCWixVQUFVSyxTQUFTUSxpQkFBaUJDLGNBQWM7QUFBQSxNQUVsRUMscUJBQXFCZixVQUFVSyxTQUFTUSxpQkFBaUJHLFVBQVVDLFNBQy9EakIsU0FBU0ssUUFBUVEsZ0JBQWdCRyxTQUM5QkUsSUFBSSxDQUFDQyxVQUFVQSxNQUFNQyxJQUFJLEVBQ3pCQyxLQUFLLEtBQUssSUFDYjtBQUFBLE1BRUpDLFdBQVd0QixVQUFVdUIsVUFBVUMsY0FBYztBQUFBLE1BQzdDQyxZQUFZQyxPQUFPMUIsVUFBVXVCLFVBQVVJLFdBQVcsS0FBSztBQUFBLE1BQ3ZEQyxrQkFBa0JGLE9BQU8xQixVQUFVdUIsVUFBVU0sbUJBQW1CLEtBQUs7QUFBQSxNQUVyRUMsZ0JBQWdCOUIsVUFBVStCLFdBQVc7QUFBQSxNQUVyQ0MscUJBQ0VoQyxVQUFVdUIsVUFBVVUsc0JBQXNCYixRQUFRO0FBQUEsTUFFcERjLGVBQWVsQyxVQUFVa0MsaUJBQWlCO0FBQUEsTUFFMUNDLGFBQ0VuQyxVQUFVb0MsZ0JBQWdCaEIsUUFDMUJwQixVQUFVcUMsbUJBQW1CNUIsYUFDN0JULFVBQVVzQyxlQUFlN0IsYUFDekI7QUFBQSxNQUVGOEIsY0FBY3ZDLFVBQVV1QyxnQkFBZ0I7QUFBQSxNQUV4Q0MsaUJBQWlCeEMsVUFBVXdDLG1CQUFtQjtBQUFBLE1BRTlDQyxtQkFBbUJ6QyxVQUFVeUMscUJBQXFCO0FBQUEsTUFFbERDLGdCQUFnQjFDLFVBQVUyQyxZQUN0QjNDLFNBQVMyQyxVQUFVQyxNQUFNLEdBQUcsRUFBRSxDQUFDLElBQy9CO0FBQUEsTUFFSkMsWUFBWW5CLE9BQU8xQixVQUFVOEMsZ0JBQWdCLEtBQUs7QUFBQSxNQUVsREMsUUFBUXJCLE9BQU8xQixVQUFVZ0QsWUFBWSxLQUFLO0FBQUEsTUFFMUNDLGNBQWN2QixPQUFPMUIsVUFBVWtELGNBQWMsS0FBSztBQUFBLE1BRWxEQyxjQUFjekIsT0FBTzFCLFVBQVVvRCxhQUFhLEtBQUs7QUFBQSxNQUVqREMsZ0JBQWdCM0IsT0FBTzFCLFVBQVVzRCxhQUFhLEtBQUs7QUFBQSxNQUVuREMsU0FBUzdCLE9BQU8xQixVQUFVd0QsYUFBYSxLQUFLO0FBQUEsTUFFNUNDLHdCQUNFL0IsT0FBTzFCLFVBQVU4QyxnQkFBZ0IsS0FDakNwQixPQUFPMUIsVUFBVXVCLFVBQVVNLG1CQUFtQixJQUMxQyxTQUNBO0FBQUEsTUFFTjZCLFFBQVExRCxVQUFVMkQsWUFBWSxXQUFXO0FBQUEsTUFDekNDLFVBQVU1RCxVQUFVMkQsYUFBYTtBQUFBLE1BRWpDRSxXQUFXN0QsVUFBVTJELFlBQ25CLHVCQUFDLFNBQUksV0FBVSw0SEFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxXQUFVLE1BQUssZ0JBQWUsU0FBUSxhQUNuRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsVUFBUztBQUFBLFlBQ1QsR0FBRTtBQUFBLFlBQ0YsVUFBUztBQUFBO0FBQUEsVUFIWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHb0IsS0FKdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFFQSx1QkFBQyxVQUFLLFdBQVUseUJBQXdCLHNCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQThDO0FBQUEsV0FUaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHNIQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxnQkFBZSxTQUFRLGFBQ25EO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxVQUFTO0FBQUEsWUFDVCxHQUFFO0FBQUEsWUFDRixVQUFTO0FBQUE7QUFBQSxVQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUdvQixLQUp0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUE7QUFBQSxRQUVBLHVCQUFDLFVBQUssV0FBVSx5QkFBd0IseUJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxXQVRuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxJQUVKO0FBQUEsRUFDRjtBQUdBLFFBQU1HLGVBQWUxRztBQUFBQSxJQUNuQixNQUFNLENBQUMsR0FBRyxJQUFJMkcsSUFBSWpGLFVBQVVvQyxJQUFJLENBQUM4QyxNQUFNQSxFQUFFMUMsU0FBUyxDQUFDLENBQUM7QUFBQSxJQUNwRCxDQUFDeEMsU0FBUztBQUFBLEVBQ1o7QUFDQSxRQUFNbUYsd0JBQXdCN0c7QUFBQUEsSUFDNUIsTUFBTSxDQUFDLEdBQUcsSUFBSTJHLElBQUlqRixVQUFVb0MsSUFBSSxDQUFDOEMsTUFBTUEsRUFBRXhCLGVBQWUsQ0FBQyxDQUFDLEVBQUUwQixPQUFPQyxPQUFPO0FBQUEsSUFDMUUsQ0FBQ3JGLFNBQVM7QUFBQSxFQUNaO0FBR0EsUUFBTXNGLG9CQUFvQmhIO0FBQUFBLElBQ3hCLE1BQU0sQ0FBQyxHQUFHLElBQUkyRyxJQUFJakYsVUFBVW9DLElBQUksQ0FBQzhDLE1BQU1BLEVBQUU3QixXQUFXLENBQUMsQ0FBQyxFQUFFK0IsT0FBT0MsT0FBTztBQUFBLElBQ3RFLENBQUNyRixTQUFTO0FBQUEsRUFDWjtBQUNBLFFBQU11Riw2QkFBNkJqSDtBQUFBQSxJQUNqQyxNQUNFLENBQUMsR0FBRyxJQUFJMkcsSUFBSWpGLFVBQVVvQyxJQUFJLENBQUM4QyxNQUFNQSxFQUFFaEMsbUJBQW1CLENBQUMsQ0FBQyxFQUFFa0MsT0FBT0MsT0FBTztBQUFBLElBQzFFLENBQUNyRixTQUFTO0FBQUEsRUFDWjtBQUVBLFFBQU13RixnQkFBZ0JsSCxRQUFRLE1BQU07QUFDbEMsV0FBT1E7QUFBQUEsTUFDTGtCLFVBQVVvRixPQUFPLENBQUNGLE1BQU07QUFFdEIsY0FBTU8sYUFDSnZGLFFBQVFFLGdCQUFnQixTQUFTLENBQUNGLFFBQVFFLGNBQ3RDLE9BQ0E4RSxFQUFFMUMsY0FBY3RDLFFBQVFFO0FBRzlCLGNBQU1zRixrQkFDSnhGLFFBQVFHLHFCQUFxQixTQUFTLENBQUNILFFBQVFHLG1CQUMzQyxPQUNBNkUsRUFBRTdCLGdCQUFnQm5ELFFBQVFHO0FBR2hDLGNBQU11RCxpQkFBaUIsSUFBSStCLEtBQUtULEVBQUV0QixjQUFjO0FBQ2hELGNBQU1nQyxnQkFBZ0IxRixRQUFRSyxXQUMxQnFELGtCQUFrQixJQUFJK0IsS0FBS3pGLFFBQVFLLFFBQVEsSUFDM0M7QUFDSixjQUFNc0YsY0FBYzNGLFFBQVFNLFNBQ3hCb0Qsa0JBQWtCLElBQUkrQixLQUFLekYsUUFBUU0sTUFBTSxJQUN6QztBQUVKLGNBQU1zRiwyQkFDSjVGLFFBQVFJLDhCQUE4QixTQUN0QyxDQUFDSixRQUFRSSw0QkFDTCxPQUNBNEUsRUFBRWhDLHdCQUF3QmhELFFBQVFJO0FBRXhDLGNBQU15RixzQkFDSjdGLFFBQVFPLHlCQUF5QixTQUNqQyxDQUFDUCxRQUFRTyx1QkFDTCxPQUNBeUUsRUFBRXhCLG9CQUFvQnhELFFBQVFPO0FBRXBDLGVBQ0VnRixjQUNBQyxtQkFDQUksNEJBQ0FDLHVCQUNBSCxpQkFDQUM7QUFBQUEsTUFFSixDQUFDO0FBQUEsTUFDRG5HO0FBQUFBLElBQ0Y7QUFBQSxFQUNGLEdBQUcsQ0FBQ00sV0FBV0UsU0FBU1IsVUFBVSxDQUFDO0FBRW5DLFFBQU1zRyxTQUFTMUgsUUFBUSxNQUFNO0FBQzNCLFVBQU0ySCxtQkFBbUJULGNBQWNyRDtBQUV2QyxVQUFNK0QsV0FBVyxJQUFJakIsSUFBSU8sY0FBY3BELElBQUksQ0FBQytELFNBQVNBLEtBQUszRCxTQUFTLENBQUM7QUFDcEUsVUFBTTRELGNBQ0psRyxRQUFRRSxnQkFBZ0IsUUFDcEI4RixTQUFTRyxPQUNUbkcsUUFBUUUsY0FDTixJQUNBOEYsU0FBU0c7QUFFakIsVUFBTUMsY0FBYyxJQUFJckI7QUFBQUEsTUFDdEJPLGNBQWNwRCxJQUFJLENBQUM4QyxNQUFNQSxFQUFFNUQsTUFBTSxFQUFFOEQsT0FBT0MsT0FBTztBQUFBLElBQ25EO0FBQ0EsVUFBTWtCLGlCQUFpQkQsWUFBWUQ7QUFHbkMsVUFBTUcsY0FBY2hCLGNBQWNKLE9BQU8sQ0FBQ0YsTUFBTUEsRUFBRUosYUFBYSxJQUFJLEVBQUUzQztBQUNyRSxVQUFNc0UsZ0JBQWdCakIsY0FBY0o7QUFBQUEsTUFDbEMsQ0FBQ0YsTUFBTUEsRUFBRUosYUFBYTtBQUFBLElBQ3hCLEVBQUUzQztBQUVGLFVBQU11RSxnQkFBZ0JsQixjQUFjbUI7QUFBQUEsTUFDbEMsQ0FBQ0MsS0FBSzFCLE1BQU0wQixPQUFPaEUsT0FBT3NDLEVBQUVYLGNBQWMsS0FBSztBQUFBLE1BQy9DO0FBQUEsSUFDRjtBQUNBLFVBQU1zQyxjQUFjckIsY0FBY21CO0FBQUFBLE1BQ2hDLENBQUNDLEtBQUsxQixNQUFNMEIsT0FBTzFCLEVBQUVqQixVQUFVO0FBQUEsTUFDL0I7QUFBQSxJQUNGO0FBQ0EsVUFBTTZDLFlBQVl0QixjQUFjbUI7QUFBQUEsTUFDOUIsQ0FBQ0MsS0FBSzFCLE1BQU0wQixPQUFPMUIsRUFBRW5CLGNBQWM7QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFDQSxVQUFNZ0QsZUFBZXZCLGNBQWNtQjtBQUFBQSxNQUNqQyxDQUFDQyxLQUFLMUIsTUFBTTBCLE9BQU8xQixFQUFFVCxXQUFXO0FBQUEsTUFDaEM7QUFBQSxJQUNGO0FBRUEsV0FBTztBQUFBLE1BQ0x3QjtBQUFBQSxNQUNBRztBQUFBQSxNQUNBRztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxNQUNBRztBQUFBQSxNQUNBQztBQUFBQSxNQUNBQztBQUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUN2QixlQUFldEYsUUFBUUUsV0FBVyxDQUFDO0FBRXZDLFFBQU00RyxxQkFBcUJ6SSxZQUFZLENBQUMwSSxLQUFLckcsVUFBVTtBQUNyRFQsZUFBVyxDQUFDK0csVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ0QsR0FBRyxHQUFHckcsTUFBTSxFQUFFO0FBQUEsRUFDbEQsR0FBRyxFQUFFO0FBRUx4QyxZQUFVLE1BQU07QUFDZCxVQUFNK0ksWUFBWSxZQUFZO0FBQzVCLFVBQUk7QUFDRnRILHlCQUFpQixJQUFJO0FBQ3JCRSxpQkFBUyxJQUFJO0FBRWIsY0FBTXFILGlCQUFpQixNQUFNNUksSUFBSTZJLElBQUksaUJBQWlCO0FBQ3RELGNBQU1DLGFBQWFGLGVBQWVHLEtBQUtBLEtBQUtuRixJQUFJbkIsaUJBQWlCO0FBQ2pFaEIscUJBQWFxSCxVQUFVO0FBQUEsTUFDekIsU0FBU3hILFFBQU87QUFDZDBILGdCQUFRMUgsTUFBTSx3QkFBd0JBLE1BQUs7QUFDM0NDLGlCQUFTLDhDQUE4QztBQUN2RG5CLGdCQUFRa0IsTUFBTSw4Q0FBOEM7QUFBQSxNQUM5RCxVQUFDO0FBQ0NELHlCQUFpQixLQUFLO0FBQUEsTUFDeEI7QUFBQSxJQUNGO0FBRUFzSCxjQUFVO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFFTCxRQUFNTSxpQkFBaUI7QUFBQSxJQUNyQixFQUFFUixLQUFLLFNBQVNTLFFBQVEsU0FBUztBQUFBLElBQ2pDLEVBQUVULEtBQUssY0FBY1MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRVQsS0FBSyxtQkFBbUJTLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRVQsS0FBSyxZQUFZUyxRQUFRLGdCQUFnQjtBQUFBLElBQzNDLEVBQUVULEtBQUssYUFBYVMsUUFBUSxlQUFlO0FBQUEsSUFDM0MsRUFBRVQsS0FBSyxhQUFhUyxRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFFVCxLQUFLLGNBQWNTLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVULEtBQUssa0JBQWtCUyxRQUFRLFNBQVM7QUFBQSxJQUMxQyxFQUFFVCxLQUFLLGtCQUFrQlMsUUFBUSxrQkFBa0I7QUFBQSxJQUNuRCxFQUFFVCxLQUFLLGlCQUFpQlMsUUFBUSxnQkFBZ0I7QUFBQSxJQUNoRCxFQUFFVCxLQUFLLGVBQWVTLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVULEtBQUsscUJBQXFCUyxRQUFRLG9CQUFvQjtBQUFBLElBQ3hELEVBQUVULEtBQUssdUJBQXVCUyxRQUFRLHVCQUF1QjtBQUFBLElBQzdELEVBQUVULEtBQUssZ0JBQWdCUyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFVCxLQUFLLG9CQUFvQlMsUUFBUSxvQkFBb0I7QUFBQSxJQUN2RCxFQUFFVCxLQUFLLDBCQUEwQlMsUUFBUSwyQkFBMkI7QUFBQSxJQUNwRSxFQUFFVCxLQUFLLGNBQWNTLFFBQVEsY0FBYztBQUFBLElBQzNDLEVBQUVULEtBQUssZ0JBQWdCUyxRQUFRLFdBQVc7QUFBQSxJQUMxQyxFQUFFVCxLQUFLLGdCQUFnQlMsUUFBUSxVQUFVO0FBQUEsSUFDekMsRUFBRVQsS0FBSyxrQkFBa0JTLFFBQVEsaUJBQWlCO0FBQUEsSUFDbEQsRUFBRVQsS0FBSyxXQUFXUyxRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFVCxLQUFLLGtCQUFrQlMsUUFBUSxrQkFBa0I7QUFBQSxJQUNuRCxFQUFFVCxLQUFLLHVCQUF1QlMsUUFBUSx1QkFBdUI7QUFBQSxJQUM3RCxFQUFFVCxLQUFLLGFBQWFTLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHeEMsUUFBTUMsZUFBZTtBQUFBLElBQ25CLEVBQUVWLEtBQUssU0FBU1MsUUFBUSxTQUFTO0FBQUEsSUFDakMsRUFBRVQsS0FBSyxjQUFjUyxRQUFRLGNBQWM7QUFBQSxJQUMzQyxFQUFFVCxLQUFLLFlBQVlTLFFBQVEsZ0JBQWdCO0FBQUEsSUFDM0MsRUFBRVQsS0FBSyxhQUFhUyxRQUFRLGVBQWU7QUFBQSxJQUMzQyxFQUFFVCxLQUFLLGFBQWFTLFFBQVEsYUFBYTtBQUFBLElBQ3pDLEVBQUVULEtBQUssY0FBY1MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRVQsS0FBSyxrQkFBa0JTLFFBQVEsU0FBUztBQUFBLElBQzFDLEVBQUVULEtBQUssa0JBQWtCUyxRQUFRLGtCQUFrQjtBQUFBLElBQ25ELEVBQUVULEtBQUssaUJBQWlCUyxRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUVULEtBQUssZUFBZVMsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRVQsS0FBSyx1QkFBdUJTLFFBQVEsdUJBQXVCO0FBQUEsSUFDN0QsRUFBRVQsS0FBSyxnQkFBZ0JTLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVULEtBQUssb0JBQW9CUyxRQUFRLG9CQUFvQjtBQUFBLElBQ3ZELEVBQUVULEtBQUssa0JBQWtCUyxRQUFRLGlCQUFpQjtBQUFBLElBQ2xELEVBQUVULEtBQUssY0FBY1MsUUFBUSxjQUFjO0FBQUEsSUFDM0MsRUFBRVQsS0FBSyxnQkFBZ0JTLFFBQVEsV0FBVztBQUFBLElBQzFDLEVBQUVULEtBQUssZ0JBQWdCUyxRQUFRLFVBQVU7QUFBQSxJQUN6QyxFQUFFVCxLQUFLLFdBQVdTLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUVULEtBQUssa0JBQWtCUyxRQUFRLGtCQUFrQjtBQUFBLElBQ25ELEVBQUVULEtBQUssdUJBQXVCUyxRQUFRLHVCQUF1QjtBQUFBLElBQzdELEVBQUVULEtBQUssVUFBVVMsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiLGlDQUFDLFNBQUksV0FBVSxLQUNiO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLDZCQUE2QixDQUFDRSxNQUFNakksY0FBY2lJLEVBQUVDLE9BQU9qSCxLQUFLO0FBQUEsUUFDaEUsWUFBWTtBQUFBO0FBQUEsTUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFbUI7QUFBQSxJQUVsQmhCLGdCQUNDLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLDZCQUFDLGtCQUFlLE9BQU0scUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUM7QUFBQSxNQUN2Qyx1QkFBQyxPQUFFLFdBQVUsMENBQXlDLG9DQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQSxJQUNFRSxRQUNGLHVCQUFDLFNBQUksV0FBVSw0REFDYixpQ0FBQyxTQUFJLFdBQVUsMkZBQ2IsaUNBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFdBQVU7QUFBQSxVQUNWLE1BQUs7QUFBQSxVQUNMLFNBQVE7QUFBQSxVQUVSO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFTO0FBQUEsY0FDVCxHQUFFO0FBQUEsY0FDRixVQUFTO0FBQUE7QUFBQSxZQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUdvQjtBQUFBO0FBQUEsUUFSdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BVUE7QUFBQSxNQUNBLHVCQUFDLFNBQ0M7QUFBQSwrQkFBQyxRQUFHLFdBQVUsOEJBQTZCLGtDQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSxXQUFXQSxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFFBQzlCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFVO0FBQUEsWUFDVixTQUFTLE1BQU1nSSxPQUFPQyxTQUFTQyxPQUFPO0FBQUEsWUFBRTtBQUFBO0FBQUEsVUFGMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxXQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLFNBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3QkEsS0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTBCQSxLQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLCtDQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE1BQUs7QUFBQSxjQUNMLFFBQU87QUFBQSxjQUNQLFNBQVE7QUFBQSxjQUVSO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGVBQWM7QUFBQSxrQkFDZCxnQkFBZTtBQUFBLGtCQUNmLGFBQWE7QUFBQSxrQkFDYixHQUFFO0FBQUE7QUFBQSxnQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJbUk7QUFBQTtBQUFBLFlBVnJJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVlBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsaUdBQWdHLG9DQUE5RztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlCQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQyxxRUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNCQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGtFQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE1BQUs7QUFBQSxjQUNMLFFBQU87QUFBQSxjQUNQLFNBQVE7QUFBQSxjQUVSO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGVBQWM7QUFBQSxrQkFDZCxnQkFBZTtBQUFBLGtCQUNmLGFBQWE7QUFBQSxrQkFDYixHQUFFO0FBQUE7QUFBQSxnQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJNko7QUFBQTtBQUFBLFlBVi9KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVlBO0FBQUEsVUFDQSx1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLHVCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBLGFBZDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCw0QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPLEVBQUVDLE9BQU8sT0FBTztBQUFBLGdCQUN2QixNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxZQUFZO0FBQUEsZ0JBQ1osYUFBWTtBQUFBLGdCQUNaLGtCQUFpQjtBQUFBLGdCQUNqQixjQUFjLENBQUNDLE9BQU9DLFlBQ25CQSxRQUFRQyxZQUFZLElBQ2xCQyxZQUFZLEVBQ1pDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxPQUFPbkksUUFBUUU7QUFBQUEsZ0JBQ2YsVUFBVSxDQUFDUSxVQUNUb0csbUJBQW1CLGVBQWVwRyxLQUFLO0FBQUEsZ0JBR3pDO0FBQUEseUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxPQUFNLG1CQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4QjtBQUFBLGtCQUU3Qm9FLGFBQWE1QztBQUFBQSxvQkFBSSxDQUFDbUcsVUFDakIsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLE9BQy9CQSxtQkFEaUJBLE9BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF3QkE7QUFBQSxlQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCwrQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPLEVBQUVOLE9BQU8sT0FBTztBQUFBLGdCQUN2QixNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxZQUFZO0FBQUEsZ0JBQ1osYUFBWTtBQUFBLGdCQUNaLGtCQUFpQjtBQUFBLGdCQUNqQixjQUFjLENBQUNDLE9BQU9DLFlBQ25CQSxRQUFRQyxZQUFZLElBQ2xCQyxZQUFZLEVBQ1pDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxPQUFPbkksUUFBUU87QUFBQUEsZ0JBQ2YsVUFBVSxDQUFDRyxVQUNUb0csbUJBQW1CLHdCQUF3QnBHLEtBQUs7QUFBQSxnQkFHbEQ7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLE9BQU0sbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThCO0FBQUEsa0JBRTdCdUUsc0JBQXNCL0M7QUFBQUEsb0JBQUksQ0FBQ3dDLFdBQzFCLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPQSxRQUNoQ0Esb0JBRGlCQSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0F2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBd0JBO0FBQUEsZUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQsMkJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsT0FBTyxFQUFFcUQsT0FBTyxPQUFPO0FBQUEsZ0JBQ3ZCLE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLFlBQVk7QUFBQSxnQkFDWixhQUFZO0FBQUEsZ0JBQ1osa0JBQWlCO0FBQUEsZ0JBQ2pCLGNBQWMsQ0FBQ0MsT0FBT0MsWUFDbkJBLFFBQVFDLFlBQVksSUFDbEJDLFlBQVksRUFDWkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLE9BQU9uSSxRQUFRRztBQUFBQSxnQkFDZixVQUFVLENBQUNPLFVBQ1RvRyxtQkFBbUIsb0JBQW9CcEcsS0FBSztBQUFBLGdCQUc5QztBQUFBLHlDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sT0FBTSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEI7QUFBQSxrQkFFN0IwRSxrQkFBa0JsRDtBQUFBQSxvQkFBSSxDQUFDb0csYUFDdEIsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLFVBQ2xDQSxzQkFEaUJBLFVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUE7QUFBQSxjQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF3QkE7QUFBQSxlQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGtEQUFpRCxvQ0FBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPLEVBQUVQLE9BQU8sT0FBTztBQUFBLGdCQUN2QixNQUFLO0FBQUEsZ0JBQ0w7QUFBQSxnQkFDQSxZQUFZO0FBQUEsZ0JBQ1osYUFBWTtBQUFBLGdCQUNaLGtCQUFpQjtBQUFBLGdCQUNqQixjQUFjLENBQUNDLE9BQU9DLFlBQ25CQSxRQUFRQyxZQUFZLElBQ2xCQyxZQUFZLEVBQ1pDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGdCQUVqQyxPQUFPbkksUUFBUUk7QUFBQUEsZ0JBQ2YsVUFBVSxDQUFDTSxVQUNUb0csbUJBQW1CLDZCQUE2QnBHLEtBQUs7QUFBQSxnQkFHdkQ7QUFBQSx5Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLE9BQU0sbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQThCO0FBQUEsa0JBRTdCMkUsMkJBQTJCbkQ7QUFBQUEsb0JBQUksQ0FBQ3FHLE9BQy9CLHVCQUFDLE9BQU8sUUFBUCxFQUF1QixPQUFPQSxJQUM1QkEsZ0JBRGlCQSxJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBO0FBQUEsY0F2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBd0JBO0FBQUEsZUE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2QkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSxrREFBaUQseUJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU92SSxRQUFRSztBQUFBQSxnQkFDZixVQUFVLENBQUNxSCxNQUNUWixtQkFBbUIsWUFBWVksRUFBRUMsT0FBT2pILEtBQUs7QUFBQSxnQkFFL0MsV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNOEk7QUFBQSxlQVZoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsa0RBQWlELHVCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFPVixRQUFRTTtBQUFBQSxnQkFDZixVQUFVLENBQUNvSCxNQUNUWixtQkFBbUIsVUFBVVksRUFBRUMsT0FBT2pILEtBQUs7QUFBQSxnQkFFN0MsV0FBVTtBQUFBO0FBQUEsY0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNOEk7QUFBQSxlQVZoSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUEsYUFwSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFKQTtBQUFBLFdBdktGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3S0E7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSw0RUFDYjtBQUFBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPb0YsT0FBT087QUFBQUEsWUFDZCxNQUFNeEg7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl3RDtBQUFBLFFBR3hEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPaUgsT0FBT0M7QUFBQUEsWUFDZCxNQUFNakg7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUkwRDtBQUFBLFFBRzFEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPZ0gsT0FBT0k7QUFBQUEsWUFDZCxNQUFNbkg7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk0RDtBQUFBLFFBRzVEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPK0csT0FBT1E7QUFBQUEsWUFDZCxNQUFNbEg7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUkyRDtBQUFBLFFBRzNEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPMEcsT0FBT1M7QUFBQUEsWUFDZCxNQUFNbEg7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl3RDtBQUFBLFFBR3hEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPLElBQUl5RyxPQUFPVSxjQUFjZ0MsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUN2RCxNQUFNeEo7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk2RDtBQUFBLFFBRzdEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPLElBQUk4RyxPQUFPYSxZQUFZNkIsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUNyRCxNQUFNdko7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl3RDtBQUFBLFFBR3hEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPLElBQUk2RyxPQUFPYyxVQUFVNEIsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUNuRCxNQUFNdEo7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUk0RDtBQUFBLFFBRzVEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFNO0FBQUEsWUFDTixPQUFPLElBQUk0RyxPQUFPZSxhQUFhMkIsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUN0RCxNQUFNcko7QUFBQUEsWUFDTixVQUFTO0FBQUE7QUFBQSxVQUpYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUl1RDtBQUFBLFdBN0R6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0RBO0FBQUEsTUFHQSx1QkFBQyxTQUNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNbUc7QUFBQUEsVUFDTixTQUFTaUM7QUFBQUEsVUFDVCxZQUFZRTtBQUFBQSxVQUNaLGlCQUFpQjtBQUFBLFVBQ2pCLGlCQUFpQjtBQUFBLFlBQ2Y7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0M7QUFBQSxZQUNEO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUVBO0FBQUEsVUFBZTtBQUFBLFVBRWpCLG1CQUFtQjtBQUFBLFlBQ2pCekgsUUFBUUssV0FDSixJQUFJb0YsS0FBS3pGLFFBQVFLLFFBQVEsRUFBRW9JLG1CQUFtQixPQUFPLElBQ3JEO0FBQUEsWUFDSnpJLFFBQVFFLGVBQWU7QUFBQSxZQUN2QkYsUUFBUUcsb0JBQW9CO0FBQUEsWUFDNUJILFFBQVFPLHdCQUF3QjtBQUFBLFlBQ2hDUCxRQUFRSSw2QkFBNkI7QUFBQSxZQUNyQ0osUUFBUU0sU0FDSixJQUFJbUYsS0FBS3pGLFFBQVFNLE1BQU0sRUFBRW1JLG1CQUFtQixPQUFPLElBQ25EO0FBQUEsWUFDSjNDLE9BQU9PO0FBQUFBLFlBQ1BQLE9BQU9JO0FBQUFBLFlBQ1BKLE9BQU9RO0FBQUFBLFlBQ1BSLE9BQU9TO0FBQUFBLFlBQ1AsSUFBSVQsT0FBT1UsY0FBY2dDLGVBQWUsT0FBTyxDQUFDO0FBQUEsWUFDaEQsSUFBSTFDLE9BQU9hLFlBQVk2QixlQUFlLE9BQU8sQ0FBQztBQUFBLFlBQzlDLElBQUkxQyxPQUFPYyxVQUFVNEIsZUFBZSxPQUFPLENBQUM7QUFBQSxZQUM1QyxJQUFJMUMsT0FBT2UsYUFBYTJCLGVBQWUsT0FBTyxDQUFDO0FBQUEsVUFBRTtBQUFBLFVBRW5ELGtCQUFrQjtBQUFBO0FBQUEsUUExQ3BCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTBDeUMsS0EzQzNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE2Q0E7QUFBQSxTQW5URjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb1RBO0FBQUEsT0EvVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlXQSxLQWxXRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbVdBO0FBRUo7QUFBRWpKLEdBbHJCSUQsZUFBYTtBQUFBb0osS0FBYnBKO0FBb3JCTixlQUFlQTtBQUFjLElBQUFvSjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VNZW1vIiwidXNlQ2FsbGJhY2siLCJhcGkiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIlNlbGVjdCIsIm1lc3NhZ2UiLCJOYXZiYXIiLCJmaWx0ZXJPcHRpb24iLCJVc2VycyIsIlVzZXJDaGVjayIsIkxheWVyczMiLCJXYWxsZXQiLCJUcmVuZGluZ1VwIiwiSW5kaWFuUnVwZWUiLCJCYWRnZUluZGlhblJ1cGVlIiwiVHJvcGh5IiwiU2hpZWxkIiwiQWxsVXNlclJlcG9ydCIsIl9zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJzY3JlZW5Mb2FkaW5nIiwic2V0U2NyZWVuTG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJ1c2Vyc0RhdGEiLCJzZXRVc2Vyc0RhdGEiLCJmaWx0ZXJzIiwic2V0RmlsdGVycyIsImdyb3VwRmlsdGVyIiwicmVmZXJyZWRCeUZpbHRlciIsInJlbGF0aW9uc2hpcE1hbmFnZXJGaWx0ZXIiLCJmcm9tRGF0ZSIsInRvRGF0ZSIsImN1c3RvbWVyU3RhdHVzRmlsdGVyIiwiU3RhdHNDYXJkIiwidGl0bGUiLCJ2YWx1ZSIsImljb24iLCJJY29uIiwiZ3JhZGllbnQiLCJpY29uQmciLCJ0cmFuc2Zvcm1Vc2VyRGF0YSIsInVzZXJJbmZvIiwiaW5kZXgiLCJzbF9ubyIsIl9pZCIsInVzZXJJZCIsInVzZXJfaWQiLCJjdXN0b21lcklkIiwiY3VzdG9tZXJfaWQiLCJ1c2VyTmFtZSIsImZ1bGxfbmFtZSIsInVzZXJQaG9uZSIsInBob25lX251bWJlciIsImNvbGxlY3Rpb25BcmVhIiwiY29sbGVjdGlvbl9hcmVhIiwicm91dGVfbmFtZSIsImNvbGxlY3Rpb25FeGVjdXRpdmUiLCJhZ2VudF9pZCIsImxlbmd0aCIsIm1hcCIsImFnZW50IiwibmFtZSIsImpvaW4iLCJncm91cE5hbWUiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJncm91cFZhbHVlIiwiTnVtYmVyIiwiZ3JvdXBfdmFsdWUiLCJmaXJzdEluc3RhbGxtZW50IiwibW9udGhseV9pbnN0YWxsbWVudCIsInBheW1lbnRzVGlja2V0IiwidGlja2V0cyIsInJlbGF0aW9uc2hpcE1hbmFnZXIiLCJyZWxhdGlvbnNoaXBfbWFuYWdlciIsInJlZmVycmVkX3R5cGUiLCJyZWZmZXJlZF9ieSIsInJlZmVycmVkX2FnZW50IiwicmVmZXJyZWRfY3VzdG9tZXIiLCJyZWZlcnJlZF9sZWFkIiwicGF5bWVudF90eXBlIiwiY3VzdG9tZXJfc3RhdHVzIiwiY2hpdF9hc2tpbmdfbW9udGgiLCJlbnJvbGxtZW50RGF0ZSIsImNyZWF0ZWRBdCIsInNwbGl0IiwiYW1vdW50UGFpZCIsInRvdGFsX2ludmVzdG1lbnQiLCJwcm9maXQiLCJ0b3RhbF9wcm9maXQiLCJ0b3RhbExhdGVGZWUiLCJ0b3RhbF9sYXRlX2ZlZSIsInRvdGFsUGVuYWx0eSIsInRvdGFsX3BlbmFsdHkiLCJ0b0JlUGFpZEFtb3VudCIsInRvdGFsX3BheWFibGUiLCJiYWxhbmNlIiwidG90YWxfYmFsYW5jZSIsImZpcnN0SW5zdGFsbG1lbnRTdGF0dXMiLCJzdGF0dXMiLCJpc19wcml6ZWQiLCJpc1ByaXplZCIsInN0YXR1c0RpdiIsImdyb3VwT3B0aW9ucyIsIlNldCIsInUiLCJjdXN0b21lclN0YXR1c09wdGlvbnMiLCJmaWx0ZXIiLCJCb29sZWFuIiwicmVmZXJyZWRCeU9wdGlvbnMiLCJyZWxhdGlvbnNoaXBNYW5hZ2VyT3B0aW9ucyIsImZpbHRlcmVkVXNlcnMiLCJtYXRjaEdyb3VwIiwibWF0Y2hSZWZlcnJlZEJ5IiwiRGF0ZSIsIm1hdGNoRnJvbURhdGUiLCJtYXRjaFRvRGF0ZSIsIm1hdGNoUmVsYXRpb25zaGlwTWFuYWdlciIsIm1hdGNoQ3VzdG9tZXJTdGF0dXMiLCJ0b3RhbHMiLCJ0b3RhbEVucm9sbG1lbnRzIiwiZ3JvdXBTZXQiLCJ1c2VyIiwidG90YWxHcm91cHMiLCJzaXplIiwiY3VzdG9tZXJTZXQiLCJ0b3RhbEN1c3RvbWVycyIsInByaXplZENvdW50IiwidW5wcml6ZWRDb3VudCIsInRvdGFsVG9CZVBhaWQiLCJyZWR1Y2UiLCJzdW0iLCJ0b3RhbFByb2ZpdCIsInRvdGFsUGFpZCIsInRvdGFsQmFsYW5jZSIsImhhbmRsZUZpbHRlckNoYW5nZSIsImtleSIsInByZXYiLCJmZXRjaERhdGEiLCJyZXBvcnRSZXNwb25zZSIsImdldCIsInJlcG9ydERhdGEiLCJkYXRhIiwiY29uc29sZSIsIkF1Y3Rpb25jb2x1bW5zIiwiaGVhZGVyIiwiRXhjZWxDb2x1bW5zIiwiZSIsInRhcmdldCIsIndpbmRvdyIsImxvY2F0aW9uIiwicmVsb2FkIiwid2lkdGgiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsImdyb3VwIiwicmVmZXJyZXIiLCJybSIsInRvTG9jYWxlU3RyaW5nIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQWxsVXNlclJlcG9ydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlTWVtbywgdXNlQ2FsbGJhY2sgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgbWVzc2FnZSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IHtcclxuICBVc2VycyxcclxuICBVc2VyQ2hlY2ssXHJcbiAgTGF5ZXJzMyxcclxuICBXYWxsZXQsXHJcbiAgVHJlbmRpbmdVcCxcclxuICBJbmRpYW5SdXBlZSxcclxuICBCYWRnZUluZGlhblJ1cGVlLFxyXG4gIFRyb3BoeSxcclxuICBTaGllbGQsXHJcbn0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiO1xyXG5cclxuY29uc3QgQWxsVXNlclJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2NyZWVuTG9hZGluZywgc2V0U2NyZWVuTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt1c2Vyc0RhdGEsIHNldFVzZXJzRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcnMsIHNldEZpbHRlcnNdID0gdXNlU3RhdGUoe1xyXG4gICAgZ3JvdXBGaWx0ZXI6IFwiQWxsXCIsXHJcbiAgICByZWZlcnJlZEJ5RmlsdGVyOiBcIkFsbFwiLFxyXG4gICAgcmVsYXRpb25zaGlwTWFuYWdlckZpbHRlcjogXCJBbGxcIixcclxuICAgIGZyb21EYXRlOiBcIlwiLFxyXG4gICAgdG9EYXRlOiBcIlwiLFxyXG4gICAgY3VzdG9tZXJTdGF0dXNGaWx0ZXI6IFwiQWxsXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFN0YXRzQ2FyZCA9ICh7XHJcbiAgICB0aXRsZSxcclxuICAgIHZhbHVlLFxyXG4gICAgaWNvbjogSWNvbixcclxuICAgIGdyYWRpZW50LFxyXG4gICAgaWNvbkJnID0gXCJiZy13aGl0ZS8yMFwiLFxyXG4gIH0pID0+IChcclxuICAgIDxkaXZcclxuICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgcm91bmRlZC0yeGwgJHtncmFkaWVudH0gdGV4dC13aGl0ZSBzaGFkb3ctbGcgaG92ZXI6c2hhZG93LXhsIGhvdmVyOi10cmFuc2xhdGUteS0xIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBwLTQgbGc6cC01YH1cclxuICAgID5cclxuICAgICAgPGRpdlxyXG4gICAgICAgIGNsYXNzTmFtZT17YGFic29sdXRlIHRvcC00IHJpZ2h0LTQgJHtpY29uQmd9IHAtMiByb3VuZGVkLWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyYH1cclxuICAgICAgPlxyXG4gICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctNCBoLTQgbGc6dy01IGxnOmgtNVwiIHN0cm9rZVdpZHRoPXsyfSAvPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBzbTp0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUvODBcIj57dGl0bGV9PC9wPlxyXG5cclxuICAgICAgICA8aDIgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LVtjbGFtcCgxNHB4LDEuMnZ3LDIycHgpXSBmb250LWJvbGQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgIHt2YWx1ZX1cclxuICAgICAgICA8L2gyPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcblxyXG4gIGNvbnN0IHRyYW5zZm9ybVVzZXJEYXRhID0gKHVzZXJJbmZvLCBpbmRleCkgPT4ge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAgICAgX2lkOiB1c2VySW5mby5faWQsXHJcblxyXG4gICAgICB1c2VySWQ6IHVzZXJJbmZvPy51c2VyX2lkPy5faWQgfHwgbnVsbCxcclxuICAgICAgY3VzdG9tZXJJZDogdXNlckluZm8/LnVzZXJfaWQ/LmN1c3RvbWVyX2lkIHx8IFwiTi9BXCIsXHJcbiAgICAgIHVzZXJOYW1lOiB1c2VySW5mbz8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgIHVzZXJQaG9uZTogdXNlckluZm8/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG5cclxuICAgICAgY29sbGVjdGlvbkFyZWE6IHVzZXJJbmZvPy51c2VyX2lkPy5jb2xsZWN0aW9uX2FyZWE/LnJvdXRlX25hbWUgfHwgXCJOL0FcIixcclxuXHJcbiAgICAgIGNvbGxlY3Rpb25FeGVjdXRpdmU6IHVzZXJJbmZvPy51c2VyX2lkPy5jb2xsZWN0aW9uX2FyZWE/LmFnZW50X2lkPy5sZW5ndGhcclxuICAgICAgICA/IHVzZXJJbmZvLnVzZXJfaWQuY29sbGVjdGlvbl9hcmVhLmFnZW50X2lkXHJcbiAgICAgICAgICAgIC5tYXAoKGFnZW50KSA9PiBhZ2VudC5uYW1lKVxyXG4gICAgICAgICAgICAuam9pbihcIiB8IFwiKVxyXG4gICAgICAgIDogXCJOL0FcIixcclxuXHJcbiAgICAgIGdyb3VwTmFtZTogdXNlckluZm8/Lmdyb3VwX2lkPy5ncm91cF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgIGdyb3VwVmFsdWU6IE51bWJlcih1c2VySW5mbz8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlKSB8fCAwLFxyXG4gICAgICBmaXJzdEluc3RhbGxtZW50OiBOdW1iZXIodXNlckluZm8/Lmdyb3VwX2lkPy5tb250aGx5X2luc3RhbGxtZW50KSB8fCAwLFxyXG5cclxuICAgICAgcGF5bWVudHNUaWNrZXQ6IHVzZXJJbmZvPy50aWNrZXRzIHx8IDAsXHJcblxyXG4gICAgICByZWxhdGlvbnNoaXBNYW5hZ2VyOlxyXG4gICAgICAgIHVzZXJJbmZvPy5ncm91cF9pZD8ucmVsYXRpb25zaGlwX21hbmFnZXI/Lm5hbWUgfHwgXCJOL0FcIixcclxuXHJcbiAgICAgIHJlZmVycmVkX3R5cGU6IHVzZXJJbmZvPy5yZWZlcnJlZF90eXBlIHx8IFwiTi9BXCIsXHJcblxyXG4gICAgICByZWZmZXJlZF9ieTpcclxuICAgICAgICB1c2VySW5mbz8ucmVmZXJyZWRfYWdlbnQ/Lm5hbWUgfHxcclxuICAgICAgICB1c2VySW5mbz8ucmVmZXJyZWRfY3VzdG9tZXI/LmZ1bGxfbmFtZSB8fFxyXG4gICAgICAgIHVzZXJJbmZvPy5yZWZlcnJlZF9sZWFkPy5mdWxsX25hbWUgfHxcclxuICAgICAgICBcIk4vQVwiLFxyXG5cclxuICAgICAgcGF5bWVudF90eXBlOiB1c2VySW5mbz8ucGF5bWVudF90eXBlIHx8IFwiTi9BXCIsXHJcblxyXG4gICAgICBjdXN0b21lcl9zdGF0dXM6IHVzZXJJbmZvPy5jdXN0b21lcl9zdGF0dXMgfHwgXCJOL0FcIixcclxuXHJcbiAgICAgIGNoaXRfYXNraW5nX21vbnRoOiB1c2VySW5mbz8uY2hpdF9hc2tpbmdfbW9udGggfHwgXCJOL0FcIixcclxuXHJcbiAgICAgIGVucm9sbG1lbnREYXRlOiB1c2VySW5mbz8uY3JlYXRlZEF0XHJcbiAgICAgICAgPyB1c2VySW5mby5jcmVhdGVkQXQuc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgOiBcIlwiLFxyXG5cclxuICAgICAgYW1vdW50UGFpZDogTnVtYmVyKHVzZXJJbmZvPy50b3RhbF9pbnZlc3RtZW50KSB8fCAwLFxyXG5cclxuICAgICAgcHJvZml0OiBOdW1iZXIodXNlckluZm8/LnRvdGFsX3Byb2ZpdCkgfHwgMCxcclxuXHJcbiAgICAgIHRvdGFsTGF0ZUZlZTogTnVtYmVyKHVzZXJJbmZvPy50b3RhbF9sYXRlX2ZlZSkgfHwgMCxcclxuXHJcbiAgICAgIHRvdGFsUGVuYWx0eTogTnVtYmVyKHVzZXJJbmZvPy50b3RhbF9wZW5hbHR5KSB8fCAwLFxyXG5cclxuICAgICAgdG9CZVBhaWRBbW91bnQ6IE51bWJlcih1c2VySW5mbz8udG90YWxfcGF5YWJsZSkgfHwgMCxcclxuXHJcbiAgICAgIGJhbGFuY2U6IE51bWJlcih1c2VySW5mbz8udG90YWxfYmFsYW5jZSkgfHwgMCxcclxuXHJcbiAgICAgIGZpcnN0SW5zdGFsbG1lbnRTdGF0dXM6XHJcbiAgICAgICAgTnVtYmVyKHVzZXJJbmZvPy50b3RhbF9pbnZlc3RtZW50KSA+PVxyXG4gICAgICAgIE51bWJlcih1c2VySW5mbz8uZ3JvdXBfaWQ/Lm1vbnRobHlfaW5zdGFsbG1lbnQpXHJcbiAgICAgICAgICA/IFwiUGFpZFwiXHJcbiAgICAgICAgICA6IFwiTm90IFBhaWRcIixcclxuXHJcbiAgICAgIHN0YXR1czogdXNlckluZm8/LmlzX3ByaXplZCA/IFwiUHJpemVkXCIgOiBcIlVuIFByaXplZFwiLFxyXG4gICAgICBpc1ByaXplZDogdXNlckluZm8/LmlzX3ByaXplZCB8fCBmYWxzZSxcclxuXHJcbiAgICAgIHN0YXR1c0RpdjogdXNlckluZm8/LmlzX3ByaXplZCA/IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1lbWVyYWxkLTUwIHRleHQtZW1lcmFsZC03MDAgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMFwiPlxyXG4gICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjAgMjBcIj5cclxuICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICBmaWxsUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAgIGQ9XCJNMTAgMThhOCA4IDAgMTAwLTE2IDggOCAwIDAwMCAxNnptMy43MDctOS4yOTNhMSAxIDAgMDAtMS40MTQtMS40MTRMOSAxMC41ODYgNy43MDcgOS4yOTNhMSAxIDAgMDAtMS40MTQgMS40MTRsMiAyYTEgMSAwIDAwMS40MTQgMGw0LTR6XCJcclxuICAgICAgICAgICAgICBjbGlwUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9zdmc+XHJcblxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNtXCI+UHJpemVkPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLWFtYmVyLTUwIHRleHQtYW1iZXItNzAwIHB4LTMgcHktMS41IHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItYW1iZXItMjAwXCI+XHJcbiAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTRcIiBmaWxsPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyMCAyMFwiPlxyXG4gICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgIGZpbGxSdWxlPVwiZXZlbm9kZFwiXHJcbiAgICAgICAgICAgICAgZD1cIk0xMCAxOGE4IDggMCAxMDAtMTYgOCA4IDAgMDAwIDE2ek04LjcwNyA3LjI5M2ExIDEgMCAwMC0xLjQxNCAxLjQxNEw4LjU4NiAxMGwtMS4yOTMgMS4yOTNhMSAxIDAgMTAxLjQxNCAxLjQxNEwxMCAxMS40MTRsMS4yOTMgMS4yOTNhMSAxIDAgMDAxLjQxNC0xLjQxNEwxMS40MTQgMTBsMS4yOTMtMS4yOTNhMSAxIDAgMDAtMS40MTQtMS40MTRMMTAgOC41ODYgOC43MDcgNy4yOTN6XCJcclxuICAgICAgICAgICAgICBjbGlwUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9zdmc+XHJcblxyXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNtXCI+VW4gUHJpemVkPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApLFxyXG4gICAgfTtcclxuICB9O1xyXG5cclxuICAvLyBHZXQgdW5pcXVlIGdyb3VwIG9wdGlvbnNcclxuICBjb25zdCBncm91cE9wdGlvbnMgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT4gWy4uLm5ldyBTZXQodXNlcnNEYXRhLm1hcCgodSkgPT4gdS5ncm91cE5hbWUpKV0sXHJcbiAgICBbdXNlcnNEYXRhXSxcclxuICApO1xyXG4gIGNvbnN0IGN1c3RvbWVyU3RhdHVzT3B0aW9ucyA9IHVzZU1lbW8oXHJcbiAgICAoKSA9PiBbLi4ubmV3IFNldCh1c2Vyc0RhdGEubWFwKCh1KSA9PiB1LmN1c3RvbWVyX3N0YXR1cykpXS5maWx0ZXIoQm9vbGVhbiksXHJcbiAgICBbdXNlcnNEYXRhXSxcclxuICApO1xyXG5cclxuICAvLyBHZXQgdW5pcXVlIHJlZmVycmVkIGJ5IG9wdGlvbnNcclxuICBjb25zdCByZWZlcnJlZEJ5T3B0aW9ucyA9IHVzZU1lbW8oXHJcbiAgICAoKSA9PiBbLi4ubmV3IFNldCh1c2Vyc0RhdGEubWFwKCh1KSA9PiB1LnJlZmZlcmVkX2J5KSldLmZpbHRlcihCb29sZWFuKSxcclxuICAgIFt1c2Vyc0RhdGFdLFxyXG4gICk7XHJcbiAgY29uc3QgcmVsYXRpb25zaGlwTWFuYWdlck9wdGlvbnMgPSB1c2VNZW1vKFxyXG4gICAgKCkgPT5cclxuICAgICAgWy4uLm5ldyBTZXQodXNlcnNEYXRhLm1hcCgodSkgPT4gdS5yZWxhdGlvbnNoaXBNYW5hZ2VyKSldLmZpbHRlcihCb29sZWFuKSxcclxuICAgIFt1c2Vyc0RhdGFdLFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkVXNlcnMgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIHJldHVybiBmaWx0ZXJPcHRpb24oXHJcbiAgICAgIHVzZXJzRGF0YS5maWx0ZXIoKHUpID0+IHtcclxuICAgICAgICAvLyBHcm91cCBmaWx0ZXJcclxuICAgICAgICBjb25zdCBtYXRjaEdyb3VwID1cclxuICAgICAgICAgIGZpbHRlcnMuZ3JvdXBGaWx0ZXIgPT09IFwiQWxsXCIgfHwgIWZpbHRlcnMuZ3JvdXBGaWx0ZXJcclxuICAgICAgICAgICAgPyB0cnVlXHJcbiAgICAgICAgICAgIDogdS5ncm91cE5hbWUgPT09IGZpbHRlcnMuZ3JvdXBGaWx0ZXI7XHJcblxyXG4gICAgICAgIC8vIFJlZmVycmVkIEJ5IGZpbHRlclxyXG4gICAgICAgIGNvbnN0IG1hdGNoUmVmZXJyZWRCeSA9XHJcbiAgICAgICAgICBmaWx0ZXJzLnJlZmVycmVkQnlGaWx0ZXIgPT09IFwiQWxsXCIgfHwgIWZpbHRlcnMucmVmZXJyZWRCeUZpbHRlclxyXG4gICAgICAgICAgICA/IHRydWVcclxuICAgICAgICAgICAgOiB1LnJlZmZlcmVkX2J5ID09PSBmaWx0ZXJzLnJlZmVycmVkQnlGaWx0ZXI7XHJcblxyXG4gICAgICAgIC8vIERhdGUgZmlsdGVyc1xyXG4gICAgICAgIGNvbnN0IGVucm9sbG1lbnREYXRlID0gbmV3IERhdGUodS5lbnJvbGxtZW50RGF0ZSk7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hGcm9tRGF0ZSA9IGZpbHRlcnMuZnJvbURhdGVcclxuICAgICAgICAgID8gZW5yb2xsbWVudERhdGUgPj0gbmV3IERhdGUoZmlsdGVycy5mcm9tRGF0ZSlcclxuICAgICAgICAgIDogdHJ1ZTtcclxuICAgICAgICBjb25zdCBtYXRjaFRvRGF0ZSA9IGZpbHRlcnMudG9EYXRlXHJcbiAgICAgICAgICA/IGVucm9sbG1lbnREYXRlIDw9IG5ldyBEYXRlKGZpbHRlcnMudG9EYXRlKVxyXG4gICAgICAgICAgOiB0cnVlO1xyXG5cclxuICAgICAgICBjb25zdCBtYXRjaFJlbGF0aW9uc2hpcE1hbmFnZXIgPVxyXG4gICAgICAgICAgZmlsdGVycy5yZWxhdGlvbnNoaXBNYW5hZ2VyRmlsdGVyID09PSBcIkFsbFwiIHx8XHJcbiAgICAgICAgICAhZmlsdGVycy5yZWxhdGlvbnNoaXBNYW5hZ2VyRmlsdGVyXHJcbiAgICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgICA6IHUucmVsYXRpb25zaGlwTWFuYWdlciA9PT0gZmlsdGVycy5yZWxhdGlvbnNoaXBNYW5hZ2VyRmlsdGVyO1xyXG5cclxuICAgICAgICBjb25zdCBtYXRjaEN1c3RvbWVyU3RhdHVzID1cclxuICAgICAgICAgIGZpbHRlcnMuY3VzdG9tZXJTdGF0dXNGaWx0ZXIgPT09IFwiQWxsXCIgfHxcclxuICAgICAgICAgICFmaWx0ZXJzLmN1c3RvbWVyU3RhdHVzRmlsdGVyXHJcbiAgICAgICAgICAgID8gdHJ1ZVxyXG4gICAgICAgICAgICA6IHUuY3VzdG9tZXJfc3RhdHVzID09PSBmaWx0ZXJzLmN1c3RvbWVyU3RhdHVzRmlsdGVyO1xyXG5cclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgbWF0Y2hHcm91cCAmJlxyXG4gICAgICAgICAgbWF0Y2hSZWZlcnJlZEJ5ICYmXHJcbiAgICAgICAgICBtYXRjaFJlbGF0aW9uc2hpcE1hbmFnZXIgJiZcclxuICAgICAgICAgIG1hdGNoQ3VzdG9tZXJTdGF0dXMgJiZcclxuICAgICAgICAgIG1hdGNoRnJvbURhdGUgJiZcclxuICAgICAgICAgIG1hdGNoVG9EYXRlXHJcbiAgICAgICAgKTtcclxuICAgICAgfSksXHJcbiAgICAgIHNlYXJjaFRleHQsXHJcbiAgICApO1xyXG4gIH0sIFt1c2Vyc0RhdGEsIGZpbHRlcnMsIHNlYXJjaFRleHRdKTtcclxuXHJcbiAgY29uc3QgdG90YWxzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCB0b3RhbEVucm9sbG1lbnRzID0gZmlsdGVyZWRVc2Vycy5sZW5ndGg7XHJcblxyXG4gICAgY29uc3QgZ3JvdXBTZXQgPSBuZXcgU2V0KGZpbHRlcmVkVXNlcnMubWFwKCh1c2VyKSA9PiB1c2VyLmdyb3VwTmFtZSkpO1xyXG4gICAgY29uc3QgdG90YWxHcm91cHMgPVxyXG4gICAgICBmaWx0ZXJzLmdyb3VwRmlsdGVyID09PSBcIkFsbFwiXHJcbiAgICAgICAgPyBncm91cFNldC5zaXplXHJcbiAgICAgICAgOiBmaWx0ZXJzLmdyb3VwRmlsdGVyXHJcbiAgICAgICAgICA/IDFcclxuICAgICAgICAgIDogZ3JvdXBTZXQuc2l6ZTtcclxuXHJcbiAgICBjb25zdCBjdXN0b21lclNldCA9IG5ldyBTZXQoXHJcbiAgICAgIGZpbHRlcmVkVXNlcnMubWFwKCh1KSA9PiB1LnVzZXJJZCkuZmlsdGVyKEJvb2xlYW4pLFxyXG4gICAgKTtcclxuICAgIGNvbnN0IHRvdGFsQ3VzdG9tZXJzID0gY3VzdG9tZXJTZXQuc2l6ZTtcclxuXHJcbiAgICAvLyBDYWxjdWxhdGUgcHJpemVkIGFuZCB1bnByaXplZCBjb3VudHNcclxuICAgIGNvbnN0IHByaXplZENvdW50ID0gZmlsdGVyZWRVc2Vycy5maWx0ZXIoKHUpID0+IHUuaXNQcml6ZWQgPT09IHRydWUpLmxlbmd0aDtcclxuICAgIGNvbnN0IHVucHJpemVkQ291bnQgPSBmaWx0ZXJlZFVzZXJzLmZpbHRlcihcclxuICAgICAgKHUpID0+IHUuaXNQcml6ZWQgPT09IGZhbHNlLFxyXG4gICAgKS5sZW5ndGg7XHJcblxyXG4gICAgY29uc3QgdG90YWxUb0JlUGFpZCA9IGZpbHRlcmVkVXNlcnMucmVkdWNlKFxyXG4gICAgICAoc3VtLCB1KSA9PiBzdW0gKyAoTnVtYmVyKHUudG9CZVBhaWRBbW91bnQpIHx8IDApLFxyXG4gICAgICAwLFxyXG4gICAgKTtcclxuICAgIGNvbnN0IHRvdGFsUHJvZml0ID0gZmlsdGVyZWRVc2Vycy5yZWR1Y2UoXHJcbiAgICAgIChzdW0sIHUpID0+IHN1bSArICh1LnByb2ZpdCB8fCAwKSxcclxuICAgICAgMCxcclxuICAgICk7XHJcbiAgICBjb25zdCB0b3RhbFBhaWQgPSBmaWx0ZXJlZFVzZXJzLnJlZHVjZShcclxuICAgICAgKHN1bSwgdSkgPT4gc3VtICsgKHUuYW1vdW50UGFpZCB8fCAwKSxcclxuICAgICAgMCxcclxuICAgICk7XHJcbiAgICBjb25zdCB0b3RhbEJhbGFuY2UgPSBmaWx0ZXJlZFVzZXJzLnJlZHVjZShcclxuICAgICAgKHN1bSwgdSkgPT4gc3VtICsgKHUuYmFsYW5jZSB8fCAwKSxcclxuICAgICAgMCxcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgdG90YWxFbnJvbGxtZW50cyxcclxuICAgICAgdG90YWxHcm91cHMsXHJcbiAgICAgIHRvdGFsQ3VzdG9tZXJzLFxyXG4gICAgICBwcml6ZWRDb3VudCxcclxuICAgICAgdW5wcml6ZWRDb3VudCxcclxuICAgICAgdG90YWxUb0JlUGFpZCxcclxuICAgICAgdG90YWxQcm9maXQsXHJcbiAgICAgIHRvdGFsUGFpZCxcclxuICAgICAgdG90YWxCYWxhbmNlLFxyXG4gICAgfTtcclxuICB9LCBbZmlsdGVyZWRVc2VycywgZmlsdGVycy5ncm91cEZpbHRlcl0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVGaWx0ZXJDaGFuZ2UgPSB1c2VDYWxsYmFjaygoa2V5LCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0RmlsdGVycygocHJldikgPT4gKHsgLi4ucHJldiwgW2tleV06IHZhbHVlIH0pKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0U2NyZWVuTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBzZXRFcnJvcihudWxsKTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVwb3J0UmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3YxL2FkbWluL3VzZXJzXCIpO1xyXG4gICAgICAgIGNvbnN0IHJlcG9ydERhdGEgPSByZXBvcnRSZXNwb25zZS5kYXRhLmRhdGEubWFwKHRyYW5zZm9ybVVzZXJEYXRhKTtcclxuICAgICAgICBzZXRVc2Vyc0RhdGEocmVwb3J0RGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRFcnJvcihcIkZhaWxlZCB0byBsb2FkIGRhdGEuIFBsZWFzZSB0cnkgYWdhaW4gbGF0ZXIuXCIpO1xyXG4gICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBkYXRhLiBQbGVhc2UgdHJ5IGFnYWluIGxhdGVyLlwiKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRTY3JlZW5Mb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaERhdGEoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IEF1Y3Rpb25jb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcklkXCIsIGhlYWRlcjogXCJDdXN0b21lciBJZFwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9zdGF0dXNcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyTmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyUGhvbmVcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBWYWx1ZVwiLCBoZWFkZXI6IFwiR3JvdXAgVmFsdWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5bWVudHNUaWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJlbnJvbGxtZW50RGF0ZVwiLCBoZWFkZXI6IFwiRW5yb2xsbWVudCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmVycmVkX3R5cGVcIiwgaGVhZGVyOiBcIlJlZmVycmVkIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZmVyZWRfYnlcIiwgaGVhZGVyOiBcIlJlZmVycmVkIEJ5XCIgfSxcclxuICAgIHsga2V5OiBcImNoaXRfYXNraW5nX21vbnRoXCIsIGhlYWRlcjogXCJDaGl0IEFza2luZyBNb250aFwiIH0sXHJcbiAgICB7IGtleTogXCJyZWxhdGlvbnNoaXBNYW5hZ2VyXCIsIGhlYWRlcjogXCJSZWxhdGlvbnNoaXAgTWFuYWdlclwiIH0sXHJcbiAgICB7IGtleTogXCJwYXltZW50X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJmaXJzdEluc3RhbGxtZW50XCIsIGhlYWRlcjogXCJGaXJzdCBJbnN0YWxsbWVudFwiIH0sXHJcbiAgICB7IGtleTogXCJmaXJzdEluc3RhbGxtZW50U3RhdHVzXCIsIGhlYWRlcjogXCJGaXJzdCBJbnN0YWxsbWVudCBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYW1vdW50UGFpZFwiLCBoZWFkZXI6IFwiQW1vdW50IFBhaWRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxMYXRlRmVlXCIsIGhlYWRlcjogXCJMYXRlIEZlZVwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbFBlbmFsdHlcIiwgaGVhZGVyOiBcIlBlbmFsdHlcIiB9LFxyXG4gICAgeyBrZXk6IFwidG9CZVBhaWRBbW91bnRcIiwgaGVhZGVyOiBcIlBheWFibGUgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2VcIiwgaGVhZGVyOiBcIkJhbGFuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29sbGVjdGlvbkFyZWFcIiwgaGVhZGVyOiBcIkNvbGxlY3Rpb24gQXJlYVwiIH0sXHJcbiAgICB7IGtleTogXCJjb2xsZWN0aW9uRXhlY3V0aXZlXCIsIGhlYWRlcjogXCJDb2xsZWN0aW9uIEV4ZWN1dGl2ZVwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNEaXZcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgRXhjZWxDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwic2xfbm9cIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcklkXCIsIGhlYWRlcjogXCJDdXN0b21lciBJZFwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyTmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyUGhvbmVcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cE5hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBWYWx1ZVwiLCBoZWFkZXI6IFwiR3JvdXAgVmFsdWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGF5bWVudHNUaWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJlbnJvbGxtZW50RGF0ZVwiLCBoZWFkZXI6IFwiRW5yb2xsbWVudCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcInJlZmVycmVkX3R5cGVcIiwgaGVhZGVyOiBcIlJlZmVycmVkIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZmVyZWRfYnlcIiwgaGVhZGVyOiBcIlJlZmVycmVkIEJ5XCIgfSxcclxuICAgIHsga2V5OiBcInJlbGF0aW9uc2hpcE1hbmFnZXJcIiwgaGVhZGVyOiBcIlJlbGF0aW9uc2hpcCBNYW5hZ2VyXCIgfSxcclxuICAgIHsga2V5OiBcInBheW1lbnRfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcImZpcnN0SW5zdGFsbG1lbnRcIiwgaGVhZGVyOiBcIkZpcnN0IEluc3RhbGxtZW50XCIgfSxcclxuICAgIHsga2V5OiBcInRvQmVQYWlkQW1vdW50XCIsIGhlYWRlcjogXCJQYXlhYmxlIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRQYWlkXCIsIGhlYWRlcjogXCJBbW91bnQgUGFpZFwiIH0sXHJcbiAgICB7IGtleTogXCJ0b3RhbExhdGVGZWVcIiwgaGVhZGVyOiBcIkxhdGUgRmVlXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsUGVuYWx0eVwiLCBoZWFkZXI6IFwiUGVuYWx0eVwiIH0sXHJcbiAgICB7IGtleTogXCJiYWxhbmNlXCIsIGhlYWRlcjogXCJCYWxhbmNlXCIgfSxcclxuICAgIHsga2V5OiBcImNvbGxlY3Rpb25BcmVhXCIsIGhlYWRlcjogXCJDb2xsZWN0aW9uIEFyZWFcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29sbGVjdGlvbkV4ZWN1dGl2ZVwiLCBoZWFkZXI6IFwiQ29sbGVjdGlvbiBFeGVjdXRpdmVcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBwLTFcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCIgXCI+XHJcbiAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXsoZSkgPT4gc2V0U2VhcmNoVGV4dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgIC8+XHJcbiAgICAgICAge3NjcmVlbkxvYWRpbmcgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBtaW4taC1zY3JlZW5cIj5cclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGNvbG9yPVwidGV4dC1pbmRpZ28tNjAwXCIgLz5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtNiB0ZXh0LWxnIHRleHQtZ3JheS02MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICBMb2FkaW5nIHVzZXIgZGF0YS4uLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogZXJyb3IgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBwLTggbWluLWgtc2NyZWVuXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyLWwtNCBib3JkZXItcmVkLTUwMCB0ZXh0LXJlZC03MDAgcHgtNiBweS01IHJvdW5kZWQtbGcgc2hhZG93LWxnIG1heC13LW1kXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0XCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNiBoLTYgbXItMyBmbGV4LXNocmluay0wXCJcclxuICAgICAgICAgICAgICAgICAgZmlsbD1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjAgMjBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGxSdWxlPVwiZXZlbm9kZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZD1cIk0xMCAxOGE4IDggMCAxMDAtMTYgOCA4IDAgMDAwIDE2ek04LjcwNyA3LjI5M2ExIDEgMCAwMC0xLjQxNCAxLjQxNEw4LjU4NiAxMGwtMS4yOTMgMS4yOTNhMSAxIDAgMTAxLjQxNCAxLjQxNEwxMCAxMS40MTRsMS4yOTMgMS4yOTNhMSAxIDAgMDAxLjQxNC0xLjQxNEwxMS40MTQgMTBsMS4yOTMtMS4yOTNhMSAxIDAgMDAtMS40MTQtMS40MTRMMTAgOC41ODYgOC43MDcgNy4yOTN6XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGlwUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWxnIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICBFcnJvciBMb2FkaW5nIERhdGFcclxuICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbVwiPntlcnJvcn08L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC00IGJnLXJlZC01MDAgaG92ZXI6YmctcmVkLTYwMCB0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgcHktMiBweC00IHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMjAwIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFJldHJ5IExvYWRpbmdcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApIDogKFxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgbWF4LXctc2NyZWVuIHAtNFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBwLTggbWItOCBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMyBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOCBoLTggdGV4dC1pbmRpZ28tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgIGQ9XCJNOSAxN3YtMm0zIDJ2LTRtMyA0di02bTIgMTBIN2EyIDIgMCAwMS0yLTJWNWEyIDIgMCAwMTItMmg1LjU4NmExIDEgMCAwMS43MDcuMjkzbDUuNDE0IDUuNDE0YTEgMSAwIDAxLjI5My43MDdWMTlhMiAyIDAgMDEtMiAyelwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgYmctZ3JhZGllbnQtdG8tciBmcm9tLWluZGlnby02MDAgdG8tYmx1ZS02MDAgYmctY2xpcC10ZXh0IHRleHQtdHJhbnNwYXJlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgQWxsIEN1c3RvbWVyIFJlcG9ydHNcclxuICAgICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1ncmF5LTUwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICBDb21wcmVoZW5zaXZlIG92ZXJ2aWV3IG9mIGN1c3RvbWVyIGRhdGEgYW5kIGFuYWx5dGljc1xyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBwLTYgbWItOCBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi01XCI+XHJcbiAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1pbmRpZ28tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgIGQ9XCJNMyA0YTEgMSAwIDAxMS0xaDE2YTEgMSAwIDAxMSAxdjIuNTg2YTEgMSAwIDAxLS4yOTMuNzA3bC02LjQxNCA2LjQxNGExIDEgMCAwMC0uMjkzLjcwN1YxN2wtNCA0di02LjU4NmExIDEgMCAwMC0uMjkzLS43MDdMMy4yOTMgNy4yOTNBMSAxIDAgMDEzIDYuNTg2VjR6XCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+RmlsdGVyczwvaDI+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1bMjAwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXAgRmlsdGVyXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHcm91cFwiXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKG9wdGlvbj8uY2hpbGRyZW4gPz8gXCJcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLmdyb3VwRmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVGaWx0ZXJDaGFuZ2UoXCJncm91cEZpbHRlclwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkFsbFwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2dyb3VwT3B0aW9ucy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwfSB2YWx1ZT17Z3JvdXB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LVsyMDBweF1cIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBTdGF0dXNcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXI9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEN1c3RvbWVyIFN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKG9wdGlvbj8uY2hpbGRyZW4gPz8gXCJcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLmN1c3RvbWVyU3RhdHVzRmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVGaWx0ZXJDaGFuZ2UoXCJjdXN0b21lclN0YXR1c0ZpbHRlclwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkFsbFwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2N1c3RvbWVyU3RhdHVzT3B0aW9ucy5tYXAoKHN0YXR1cykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtzdGF0dXN9IHZhbHVlPXtzdGF0dXN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1bMjAwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVmZXJyZWQgQnlcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXI9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIEJ5XCJcclxuICAgICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAob3B0aW9uPy5jaGlsZHJlbiA/PyBcIlwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnMucmVmZXJyZWRCeUZpbHRlcn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRmlsdGVyQ2hhbmdlKFwicmVmZXJyZWRCeUZpbHRlclwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIkFsbFwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge3JlZmVycmVkQnlPcHRpb25zLm1hcCgocmVmZXJyZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17cmVmZXJyZXJ9IHZhbHVlPXtyZWZlcnJlcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtyZWZlcnJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLXctWzIwMHB4XVwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlbGF0aW9uc2hpcCBNYW5hZ2VyXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBSZWxhdGlvbnNoaXAgTWFuYWdlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKG9wdGlvbj8uY2hpbGRyZW4gPz8gXCJcIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmaWx0ZXJzLnJlbGF0aW9uc2hpcE1hbmFnZXJGaWx0ZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUZpbHRlckNoYW5nZShcInJlbGF0aW9uc2hpcE1hbmFnZXJGaWx0ZXJcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJBbGxcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtyZWxhdGlvbnNoaXBNYW5hZ2VyT3B0aW9ucy5tYXAoKHJtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3JtfSB2YWx1ZT17cm19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cm19XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1bMTgwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRnJvbSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZmlsdGVycy5mcm9tRGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVGaWx0ZXJDaGFuZ2UoXCJmcm9tRGF0ZVwiLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlci0yIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItaW5kaWdvLTUwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1bMTgwcHhdXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVG8gRGF0ZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2ZpbHRlcnMudG9EYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUZpbHRlckNoYW5nZShcInRvRGF0ZVwiLCBlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlci0yIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHB4LTQgcHktMi41IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItaW5kaWdvLTUwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFN0YXRpc3RpY3MgQ2FyZHMgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyB4bDpncmlkLWNvbHMtNSBnYXAtNSBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPFN0YXRzQ2FyZFxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJUb3RhbCBDdXN0b21lcnNcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3RvdGFscy50b3RhbEN1c3RvbWVyc31cclxuICAgICAgICAgICAgICAgIGljb249e1VzZXJzfVxyXG4gICAgICAgICAgICAgICAgZ3JhZGllbnQ9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXBpbmstNTAwIHRvLXJvc2UtNTAwXCJcclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICA8U3RhdHNDYXJkXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlRvdGFsIEVucm9sbG1lbnRzXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXt0b3RhbHMudG90YWxFbnJvbGxtZW50c31cclxuICAgICAgICAgICAgICAgIGljb249e1VzZXJDaGVja31cclxuICAgICAgICAgICAgICAgIGdyYWRpZW50PVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwMCB0by1pbmRpZ28tNjAwXCJcclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICA8U3RhdHNDYXJkXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlRvdGFsIEdyb3Vwc1wiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17dG90YWxzLnRvdGFsR3JvdXBzfVxyXG4gICAgICAgICAgICAgICAgaWNvbj17TGF5ZXJzM31cclxuICAgICAgICAgICAgICAgIGdyYWRpZW50PVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1lbWVyYWxkLTUwMCB0by1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxTdGF0c0NhcmRcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiUHJpemVkXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXt0b3RhbHMucHJpemVkQ291bnR9XHJcbiAgICAgICAgICAgICAgICBpY29uPXtUcm9waHl9XHJcbiAgICAgICAgICAgICAgICBncmFkaWVudD1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20teWVsbG93LTUwMCB0by1hbWJlci02MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxTdGF0c0NhcmRcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiVW5wcml6ZWRcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3RvdGFscy51bnByaXplZENvdW50fVxyXG4gICAgICAgICAgICAgICAgaWNvbj17U2hpZWxkfVxyXG4gICAgICAgICAgICAgICAgZ3JhZGllbnQ9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWdyYXktNTAwIHRvLWdyYXktNjAwXCJcclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICA8U3RhdHNDYXJkXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlRvdGFsIFBheWFibGVcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Digrkke3RvdGFscy50b3RhbFRvQmVQYWlkLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YH1cclxuICAgICAgICAgICAgICAgIGljb249e1dhbGxldH1cclxuICAgICAgICAgICAgICAgIGdyYWRpZW50PVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1wdXJwbGUtNTAwIHRvLWZ1Y2hzaWEtNjAwXCJcclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICA8U3RhdHNDYXJkXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlRvdGFsIFByb2ZpdFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSR7dG90YWxzLnRvdGFsUHJvZml0LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YH1cclxuICAgICAgICAgICAgICAgIGljb249e1RyZW5kaW5nVXB9XHJcbiAgICAgICAgICAgICAgICBncmFkaWVudD1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tdGVhbC01MDAgdG8tY3lhbi02MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxTdGF0c0NhcmRcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiVG90YWwgUGFpZFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSR7dG90YWxzLnRvdGFsUGFpZC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWB9XHJcbiAgICAgICAgICAgICAgICBpY29uPXtJbmRpYW5SdXBlZX1cclxuICAgICAgICAgICAgICAgIGdyYWRpZW50PVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1pbmRpZ28tNTAwIHRvLXZpb2xldC02MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxTdGF0c0NhcmRcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiVG90YWwgQmFsYW5jZVwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17YOKCuSR7dG90YWxzLnRvdGFsQmFsYW5jZS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWB9XHJcbiAgICAgICAgICAgICAgICBpY29uPXtCYWRnZUluZGlhblJ1cGVlfVxyXG4gICAgICAgICAgICAgICAgZ3JhZGllbnQ9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXJvc2UtNTAwIHRvLXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIERhdGEgVGFibGUgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZFVzZXJzfVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17QXVjdGlvbmNvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRDb2xzPXtFeGNlbENvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9e2BBbGwgQ3VzdG9tZXIgUmVwb3J0YH1cclxuICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICBcIkZyb20gRGF0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICBcIkdyb3VwIE5hbWVcIixcclxuICAgICAgICAgICAgICAgICAgXCJSZWZlcnJlZCBCeVwiLFxyXG4gICAgICAgICAgICAgICAgICAgXCJDdXN0b21lciBTdGF0dXNcIixcclxuICAgICAgICAgICAgICAgICAgXCJSZWxhdGlvbnNoaXAgTWFuYWdlclwiLFxyXG4gICAgICAgICAgICAgICAgICBcIlRvIERhdGVcIixcclxuICAgICAgICAgICAgICAgICAgXCJUb3RhbCBDdXN0b21lcnNcIixcclxuICAgICAgICAgICAgICAgICAgXCJUb3RhbCBHcm91cHNcIixcclxuICAgICAgICAgICAgICAgICAgXCJQcml6ZWRcIixcclxuICAgICAgICAgICAgICAgICAgXCJVbnByaXplZFwiLFxyXG4gICAgICAgICAgICAgICAgICBcIkFtb3VudCBQYXlhYmxlXCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgUHJvZml0XCIsXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgQW1vdW50IFBhaWRcIixcclxuXHJcbiAgICAgICAgICAgICAgICAgIFwiVG90YWwgQmFsYW5jZVwiLFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlcnMuZnJvbURhdGVcclxuICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGZpbHRlcnMuZnJvbURhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUdCXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIuKAlFwiLFxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJzLmdyb3VwRmlsdGVyIHx8IFwiQWxsIEdyb3Vwc1wiLFxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJzLnJlZmVycmVkQnlGaWx0ZXIgfHwgXCJBbGxcIixcclxuICAgICAgICAgICAgICAgICAgZmlsdGVycy5jdXN0b21lclN0YXR1c0ZpbHRlciB8fCBcIkFsbFwiLFxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJzLnJlbGF0aW9uc2hpcE1hbmFnZXJGaWx0ZXIgfHwgXCJBbGxcIixcclxuICAgICAgICAgICAgICAgICAgZmlsdGVycy50b0RhdGVcclxuICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGZpbHRlcnMudG9EYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1HQlwiKVxyXG4gICAgICAgICAgICAgICAgICAgIDogXCLigJRcIixcclxuICAgICAgICAgICAgICAgICAgdG90YWxzLnRvdGFsQ3VzdG9tZXJzLFxyXG4gICAgICAgICAgICAgICAgICB0b3RhbHMudG90YWxHcm91cHMsXHJcbiAgICAgICAgICAgICAgICAgIHRvdGFscy5wcml6ZWRDb3VudCxcclxuICAgICAgICAgICAgICAgICAgdG90YWxzLnVucHJpemVkQ291bnQsXHJcbiAgICAgICAgICAgICAgICAgIGDigrkke3RvdGFscy50b3RhbFRvQmVQYWlkLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgICAgICAgYOKCuSR7dG90YWxzLnRvdGFsUHJvZml0LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9YCxcclxuICAgICAgICAgICAgICAgICAgYOKCuSR7dG90YWxzLnRvdGFsUGFpZC50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsXHJcbiAgICAgICAgICAgICAgICAgIGDigrkke3RvdGFscy50b3RhbEJhbGFuY2UudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1gLFxyXG4gICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BDdXN0b21lclJlcG9ydC5jc3ZgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWxsVXNlclJlcG9ydDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0FsbFVzZXJSZXBvcnQuanN4In0=