import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/NonConvertedLead.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Select, Spin } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
const groupOptions = [
  { value: "Today", label: "Today" },
  { value: "Yesterday", label: "Yesterday" },
  { value: "ThisMonth", label: "This Month" },
  { value: "LastMonth", label: "Last Month" },
  { value: "ThisYear", label: "This Year" },
  { value: "Custom", label: "Custom" }
];
const NonConvertedLead = () => {
  _s();
  const [loadingPage, setLoadingPage] = useState(true);
  const [selectedLabel, setSelectedLabel] = useState("ThisMonth");
  const [selectedFromDate, setSelectedFromDate] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [users, setUsers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [customerReferredBy, setCustomerReferredBy] = useState("");
  const [employeeReferredBy, setEmployeeReferredBy] = useState("");
  const [leadTableData, setLeadTableData] = useState([]);
  const [fetchingLeads, setFetchingLeads] = useState(false);
  const formatDateEnCA = (date) => {
    if (!date) return "";
    const d = new Date(date);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  };
  const getIdFromValue = (val) => {
    if (!val) return "";
    return val.split("_")[1] || "";
  };
  const handleSelectFilter = (value) => {
    setSelectedLabel(value);
    const today = /* @__PURE__ */ new Date();
    if (value === "Today") {
      const f = formatDateEnCA(today);
      setSelectedFromDate(f);
      setSelectedDate(f);
    } else if (value === "Yesterday") {
      const y = new Date(today);
      y.setDate(y.getDate() - 1);
      const f = formatDateEnCA(y);
      setSelectedFromDate(f);
      setSelectedDate(f);
    } else if (value === "ThisMonth") {
      const start = new Date(today.getFullYear(), today.getMonth(), 1);
      const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      setSelectedFromDate(formatDateEnCA(start));
      setSelectedDate(formatDateEnCA(end));
    } else if (value === "LastMonth") {
      const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const end = new Date(today.getFullYear(), today.getMonth(), 0);
      setSelectedFromDate(formatDateEnCA(start));
      setSelectedDate(formatDateEnCA(end));
    } else if (value === "ThisYear") {
      const start = new Date(today.getFullYear(), 0, 1);
      const end = new Date(today.getFullYear(), 11, 31);
      setSelectedFromDate(formatDateEnCA(start));
      setSelectedDate(formatDateEnCA(end));
    } else if (value === "Custom") {
      setSelectedFromDate("");
      setSelectedDate("");
    }
  };
  useEffect(() => {
    const p1 = api.get("/user/get-user").catch(() => ({ data: [] }));
    const p2 = api.get("/agent/get").catch(() => ({ data: { agent: [] } }));
    const p3 = api.get("/employee").catch(() => ({ data: { employee: [] } }));
    const p4 = api.get("/user/get-user").catch(() => ({ data: { customer: [] } }));
    Promise.all([p1, p2, p3, p4]).then(([u, a, e, c]) => {
      setUsers(u?.data || []);
      setAgents(a?.data?.agent || []);
      setEmployees(e?.data?.employee || []);
      setCustomers(c?.data?.customer || []);
    }).finally(() => setLoadingPage(false));
  }, []);
  useEffect(() => {
    if (selectedFromDate && selectedDate) {
      fetchFilteredLeads();
    } else {
      setLeadTableData([]);
    }
  }, [selectedFromDate, selectedDate, customerReferredBy, employeeReferredBy]);
  useEffect(() => {
    if (!loadingPage) {
      handleSelectFilter("ThisMonth");
    }
  }, [loadingPage]);
  const fetchFilteredLeads = async () => {
    setFetchingLeads(true);
    try {
      const params = new URLSearchParams();
      params.append("from_date", selectedFromDate);
      params.append("to_date", selectedDate);
      if (customerReferredBy) {
        params.append("customer_id", getIdFromValue(customerReferredBy));
      }
      if (employeeReferredBy) {
        params.append("agent_id", getIdFromValue(employeeReferredBy));
      }
      const res = await api.get(`/lead/not-converted-customer?${params.toString()}`);
      const data = res?.data?.response || [];
      const formatted = data.map((lead, index) => ({
        id: lead?._id,
        SlNo: index + 1,
        LeadName: lead?.lead_name || "",
        leadPhone: lead?.lead_phone || "",
        leadProfession: lead?.lead_profession || "",
        groupName: lead?.group_id?.group_name || "",
        leadType: lead?.lead_type || "",
        schemeType: lead?.scheme_type || "",
        referredBy: lead?.lead_agent?.name ? `${lead?.lead_agent?.name} | ${lead?.lead_agent?.phone_number}` : lead?.lead_customer?.full_name ? `${lead?.lead_customer?.full_name} | ${lead?.lead_customer?.phone_number}` : "N/A"
      }));
      setLeadTableData(formatted);
    } catch (error) {
      console.error("Fetch error:", error);
      setLeadTableData([]);
    } finally {
      setFetchingLeads(false);
    }
  };
  const leadColumns = [
    { header: "Sl No", key: "SlNo" },
    { header: "Name", key: "LeadName" },
    { header: "Phone", key: "leadPhone" },
    { header: "Profession", key: "leadProfession" },
    { header: "Group", key: "groupName" },
    { header: "Lead Type", key: "leadType" },
    { header: "Scheme Type", key: "schemeType" },
    { header: "Referred By", key: "referredBy" }
  ];
  const isCustomMode = selectedLabel === "Custom";
  return /* @__PURE__ */ jsxDEV("div", { className: "p-5 w-full", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "text-xl font-semibold text-gray-800", children: "Report – Non-Converted Leads" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
        lineNumber: 552,
        columnNumber: 9
      }, this),
      loadingPage && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-sm text-gray-600", children: [
        /* @__PURE__ */ jsxDEV(Spin, { size: "small" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 557,
          columnNumber: 13
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("span", { children: "Loading lookups..." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 557,
          columnNumber: 35
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
        lineNumber: 556,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
      lineNumber: 551,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 mb-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium", children: "Date Filter" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 567,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            value: selectedLabel,
            onChange: handleSelectFilter,
            className: "w-full h-11",
            children: groupOptions.map(
              (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g.value, children: g.label }, g.value, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
                lineNumber: 574,
                columnNumber: 13
              }, this)
            )
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 568,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
        lineNumber: 566,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium", children: "From Date" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 583,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: selectedFromDate,
            onChange: (e) => {
              setSelectedFromDate(e.target.value);
              setSelectedLabel("Custom");
            },
            disabled: !isCustomMode,
            className: `w-full h-11 border rounded-lg px-3 ${!isCustomMode ? "bg-gray-100" : "border-gray-300"}`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 584,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
        lineNumber: 582,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium", children: "To Date" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 600,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "date",
            value: selectedDate,
            onChange: (e) => {
              setSelectedDate(e.target.value);
              setSelectedLabel("Custom");
            },
            disabled: !isCustomMode,
            className: `w-full h-11 border rounded-lg px-3 ${!isCustomMode ? "bg-gray-100" : "border-gray-300"}`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 601,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
        lineNumber: 599,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium", children: "Customer Referred By" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 617,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Select,
          {
            allowClear: true,
            value: customerReferredBy,
            onChange: (v) => setCustomerReferredBy(v || ""),
            className: "w-full h-11",
            children: [
              /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
                lineNumber: 624,
                columnNumber: 13
              }, this),
              customers.map(
                (c) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `CUS_${c._id}`, children: [
                  c.full_name,
                  " | ",
                  c.phone_number
                ] }, c._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
                  lineNumber: 626,
                  columnNumber: 13
                }, this)
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 618,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
        lineNumber: 616,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
      lineNumber: 563,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 mb-4", children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
      /* @__PURE__ */ jsxDEV("label", { className: "text-sm font-medium", children: "Employee Referred By" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
        lineNumber: 638,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Select,
        {
          allowClear: true,
          value: employeeReferredBy,
          onChange: (v) => setEmployeeReferredBy(v || ""),
          className: "w-full h-11",
          children: [
            /* @__PURE__ */ jsxDEV(Select.Option, { value: "", children: "All" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
              lineNumber: 645,
              columnNumber: 13
            }, this),
            employees.map(
              (e) => /* @__PURE__ */ jsxDEV(Select.Option, { value: `EMP_${e._id}`, children: [
                e.full_name || e.name,
                " | ",
                e.phone_number
              ] }, e._id, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
                lineNumber: 647,
                columnNumber: 13
              }, this)
            )
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 639,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
      lineNumber: 637,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
      lineNumber: 635,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-50 border border-violet-200 rounded-lg p-4 mb-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 mb-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Non-Converted Leads" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 661,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-violet-700", children: leadTableData.length }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 662,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 660,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Referred by Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 666,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-green-700", children: leadTableData.filter(
            (l) => customers.some(
              (c) => `${c.full_name} | ${c.phone_number}` === l.referredBy
            )
          ).length }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 667,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 665,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Referred by Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 679,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-purple-700", children: leadTableData.filter(
            (l) => employees.some(
              (e) => `${e.full_name || e.name} | ${e.phone_number}` === l.referredBy
            )
          ).length }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 680,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 678,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Referred by Agent" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 693,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-xl font-bold text-orange-700", children: leadTableData.filter(
            (l) => agents.some(
              (a) => `${a.name} | ${a.phone_number}` === l.referredBy
            )
          ).length }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 694,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 692,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
        lineNumber: 659,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-4 rounded-lg border", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "font-semibold text-gray-700 mb-2", children: "Referrer Breakdown" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 708,
          columnNumber: 11
        }, this),
        leadTableData.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 text-sm", children: "No leads available." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 711,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV("ul", { className: "space-y-1", children: [...new Set(leadTableData.map((l) => l.referredBy))].map((ref) => {
          if (!ref || ref === "N/A") return null;
          const count = leadTableData.filter((l) => l.referredBy === ref).length;
          return /* @__PURE__ */ jsxDEV("li", { className: "flex justify-between border-b py-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-800", children: ref }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
              lineNumber: 721,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-violet-700", children: count }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
              lineNumber: 722,
              columnNumber: 21
            }, this)
          ] }, ref, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
            lineNumber: 720,
            columnNumber: 17
          }, this);
        }) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
          lineNumber: 713,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
        lineNumber: 707,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
      lineNumber: 656,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white shadow rounded-lg p-3 min-h-[200px]", children: fetchingLeads ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center py-16", children: /* @__PURE__ */ jsxDEV(Spin, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
      lineNumber: 735,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
      lineNumber: 734,
      columnNumber: 9
    }, this) : /* @__PURE__ */ jsxDEV(DataTable, { columns: leadColumns, data: leadTableData, exportedFileName: "Non Converted Lead.csv", exportedPdfName: "Non Converted Lead" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
      lineNumber: 738,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
      lineNumber: 732,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx",
    lineNumber: 550,
    columnNumber: 5
  }, this);
};
_s(NonConvertedLead, "7OKE7vjuBXQq5XqmFaF/NB7hKuo=");
_c = NonConvertedLead;
export default NonConvertedLead;
var _c;
$RefreshReg$(_c, "NonConvertedLead");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/NonConvertedLead.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdWlCUTsyQkF2aUJSO0FBQWdCQSxNQUFVQyxjQUFTLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbEQsU0FBU0MsUUFBUUMsWUFBWTtBQUM3QixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFFdEIsTUFBTUMsZUFBZTtBQUFBLEVBQ25CLEVBQUVDLE9BQU8sU0FBU0MsT0FBTyxRQUFRO0FBQUEsRUFDakMsRUFBRUQsT0FBTyxhQUFhQyxPQUFPLFlBQVk7QUFBQSxFQUN6QyxFQUFFRCxPQUFPLGFBQWFDLE9BQU8sYUFBYTtBQUFBLEVBQzFDLEVBQUVELE9BQU8sYUFBYUMsT0FBTyxhQUFhO0FBQUEsRUFDMUMsRUFBRUQsT0FBTyxZQUFZQyxPQUFPLFlBQVk7QUFBQSxFQUN4QyxFQUFFRCxPQUFPLFVBQVVDLE9BQU8sU0FBUztBQUFDO0FBMFh0QyxNQUFNQyxtQkFBbUJBLE1BQU07QUFBQUMsS0FBQTtBQUM3QixRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSVosU0FBUyxJQUFJO0FBRW5ELFFBQU0sQ0FBQ2EsZUFBZUMsZ0JBQWdCLElBQUlkLFNBQVMsV0FBVztBQUM5RCxRQUFNLENBQUNlLGtCQUFrQkMsbUJBQW1CLElBQUloQixTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDaUIsY0FBY0MsZUFBZSxJQUFJbEIsU0FBUyxFQUFFO0FBRW5ELFFBQU0sQ0FBQ21CLE9BQU9DLFFBQVEsSUFBSXBCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNxQixRQUFRQyxTQUFTLElBQUl0QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDdUIsV0FBV0MsWUFBWSxJQUFJeEIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3lCLFdBQVdDLFlBQVksSUFBSTFCLFNBQVMsRUFBRTtBQUU3QyxRQUFNLENBQUMyQixvQkFBb0JDLHFCQUFxQixJQUFJNUIsU0FBUyxFQUFFO0FBQy9ELFFBQU0sQ0FBQzZCLG9CQUFvQkMscUJBQXFCLElBQUk5QixTQUFTLEVBQUU7QUFFL0QsUUFBTSxDQUFDK0IsZUFBZUMsZ0JBQWdCLElBQUloQyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDaUMsZUFBZUMsZ0JBQWdCLElBQUlsQyxTQUFTLEtBQUs7QUFHeEQsUUFBTW1DLGlCQUFpQkEsQ0FBQ0MsU0FBUztBQUMvQixRQUFJLENBQUNBLEtBQU0sUUFBTztBQUNsQixVQUFNQyxJQUFJLElBQUlDLEtBQUtGLElBQUk7QUFDdkIsVUFBTUcsT0FBT0YsRUFBRUcsWUFBWTtBQUMzQixVQUFNQyxLQUFLQyxPQUFPTCxFQUFFTSxTQUFTLElBQUksQ0FBQyxFQUFFQyxTQUFTLEdBQUcsR0FBRztBQUNuRCxVQUFNQyxLQUFLSCxPQUFPTCxFQUFFUyxRQUFRLENBQUMsRUFBRUYsU0FBUyxHQUFHLEdBQUc7QUFDOUMsV0FBTyxHQUFHTCxJQUFJLElBQUlFLEVBQUUsSUFBSUksRUFBRTtBQUFBLEVBQzVCO0FBRUEsUUFBTUUsaUJBQWlCQSxDQUFDQyxRQUFRO0FBQzlCLFFBQUksQ0FBQ0EsSUFBSyxRQUFPO0FBQ2pCLFdBQU9BLElBQUlDLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLEVBQzlCO0FBR0EsUUFBTUMscUJBQXFCQSxDQUFDM0MsVUFBVTtBQUNwQ08scUJBQWlCUCxLQUFLO0FBQ3RCLFVBQU00QyxRQUFRLG9CQUFJYixLQUFLO0FBRXZCLFFBQUkvQixVQUFVLFNBQVM7QUFDckIsWUFBTTZDLElBQUlqQixlQUFlZ0IsS0FBSztBQUM5Qm5DLDBCQUFvQm9DLENBQUM7QUFDckJsQyxzQkFBZ0JrQyxDQUFDO0FBQUEsSUFDbkIsV0FBVzdDLFVBQVUsYUFBYTtBQUNoQyxZQUFNOEMsSUFBSSxJQUFJZixLQUFLYSxLQUFLO0FBQ3hCRSxRQUFFQyxRQUFRRCxFQUFFUCxRQUFRLElBQUksQ0FBQztBQUN6QixZQUFNTSxJQUFJakIsZUFBZWtCLENBQUM7QUFDMUJyQywwQkFBb0JvQyxDQUFDO0FBQ3JCbEMsc0JBQWdCa0MsQ0FBQztBQUFBLElBQ25CLFdBQVc3QyxVQUFVLGFBQWE7QUFDaEMsWUFBTWdELFFBQVEsSUFBSWpCLEtBQUthLE1BQU1YLFlBQVksR0FBR1csTUFBTVIsU0FBUyxHQUFHLENBQUM7QUFDL0QsWUFBTWEsTUFBTSxJQUFJbEIsS0FBS2EsTUFBTVgsWUFBWSxHQUFHVyxNQUFNUixTQUFTLElBQUksR0FBRyxDQUFDO0FBQ2pFM0IsMEJBQW9CbUIsZUFBZW9CLEtBQUssQ0FBQztBQUN6Q3JDLHNCQUFnQmlCLGVBQWVxQixHQUFHLENBQUM7QUFBQSxJQUNyQyxXQUFXakQsVUFBVSxhQUFhO0FBQ2hDLFlBQU1nRCxRQUFRLElBQUlqQixLQUFLYSxNQUFNWCxZQUFZLEdBQUdXLE1BQU1SLFNBQVMsSUFBSSxHQUFHLENBQUM7QUFDbkUsWUFBTWEsTUFBTSxJQUFJbEIsS0FBS2EsTUFBTVgsWUFBWSxHQUFHVyxNQUFNUixTQUFTLEdBQUcsQ0FBQztBQUM3RDNCLDBCQUFvQm1CLGVBQWVvQixLQUFLLENBQUM7QUFDekNyQyxzQkFBZ0JpQixlQUFlcUIsR0FBRyxDQUFDO0FBQUEsSUFDckMsV0FBV2pELFVBQVUsWUFBWTtBQUMvQixZQUFNZ0QsUUFBUSxJQUFJakIsS0FBS2EsTUFBTVgsWUFBWSxHQUFHLEdBQUcsQ0FBQztBQUNoRCxZQUFNZ0IsTUFBTSxJQUFJbEIsS0FBS2EsTUFBTVgsWUFBWSxHQUFHLElBQUksRUFBRTtBQUNoRHhCLDBCQUFvQm1CLGVBQWVvQixLQUFLLENBQUM7QUFDekNyQyxzQkFBZ0JpQixlQUFlcUIsR0FBRyxDQUFDO0FBQUEsSUFDckMsV0FBV2pELFVBQVUsVUFBVTtBQUM3QlMsMEJBQW9CLEVBQUU7QUFDdEJFLHNCQUFnQixFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBR0FqQixZQUFVLE1BQU07QUFDZCxVQUFNd0QsS0FBS3JELElBQUlzRCxJQUFJLGdCQUFnQixFQUFFQyxNQUFNLE9BQU8sRUFBRUMsTUFBTSxHQUFHLEVBQUU7QUFDL0QsVUFBTUMsS0FBS3pELElBQUlzRCxJQUFJLFlBQVksRUFBRUMsTUFBTSxPQUFPLEVBQUVDLE1BQU0sRUFBRUUsT0FBTyxHQUFHLEVBQUUsRUFBRTtBQUN0RSxVQUFNQyxLQUFLM0QsSUFBSXNELElBQUksV0FBVyxFQUFFQyxNQUFNLE9BQU8sRUFBRUMsTUFBTSxFQUFFSSxVQUFVLEdBQUcsRUFBRSxFQUFFO0FBQ3hFLFVBQU1DLEtBQUs3RCxJQUFJc0QsSUFBSSxnQkFBZ0IsRUFBRUMsTUFBTSxPQUFPLEVBQUVDLE1BQU0sRUFBRU0sVUFBVSxHQUFHLEVBQUUsRUFBRTtBQUU3RUMsWUFBUUMsSUFBSSxDQUFDWCxJQUFJSSxJQUFJRSxJQUFJRSxFQUFFLENBQUMsRUFDekJJLEtBQUssQ0FBQyxDQUFDQyxHQUFHQyxHQUFHQyxHQUFHQyxDQUFDLE1BQU07QUFDdEJyRCxlQUFTa0QsR0FBR1YsUUFBUSxFQUFFO0FBQ3RCdEMsZ0JBQVVpRCxHQUFHWCxNQUFNRSxTQUFTLEVBQUU7QUFDOUJ0QyxtQkFBYWdELEdBQUdaLE1BQU1JLFlBQVksRUFBRTtBQUNwQ3RDLG1CQUFhK0MsR0FBR2IsTUFBTU0sWUFBWSxFQUFFO0FBQUEsSUFDdEMsQ0FBQyxFQUNBUSxRQUFRLE1BQU05RCxlQUFlLEtBQUssQ0FBQztBQUFBLEVBQ3hDLEdBQUcsRUFBRTtBQUdMWCxZQUFVLE1BQU07QUFDZCxRQUFJYyxvQkFBb0JFLGNBQWM7QUFDcEMwRCx5QkFBbUI7QUFBQSxJQUNyQixPQUFPO0FBQ0wzQyx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCO0FBQUEsRUFDRixHQUFHLENBQUNqQixrQkFBa0JFLGNBQWNVLG9CQUFvQkUsa0JBQWtCLENBQUM7QUFHM0U1QixZQUFVLE1BQU07QUFDZCxRQUFJLENBQUNVLGFBQWE7QUFDaEJ1Qyx5QkFBbUIsV0FBVztBQUFBLElBQ2hDO0FBQUEsRUFDRixHQUFHLENBQUN2QyxXQUFXLENBQUM7QUFFaEIsUUFBTWdFLHFCQUFxQixZQUFZO0FBQ3JDekMscUJBQWlCLElBQUk7QUFDckIsUUFBSTtBQUNGLFlBQU0wQyxTQUFTLElBQUlDLGdCQUFnQjtBQUNuQ0QsYUFBT0UsT0FBTyxhQUFhL0QsZ0JBQWdCO0FBQzNDNkQsYUFBT0UsT0FBTyxXQUFXN0QsWUFBWTtBQUVyQyxVQUFJVSxvQkFBb0I7QUFDdEJpRCxlQUFPRSxPQUFPLGVBQWUvQixlQUFlcEIsa0JBQWtCLENBQUM7QUFBQSxNQUNqRTtBQUNBLFVBQUlFLG9CQUFvQjtBQUN0QitDLGVBQU9FLE9BQU8sWUFBWS9CLGVBQWVsQixrQkFBa0IsQ0FBQztBQUFBLE1BQzlEO0FBRUEsWUFBTWtELE1BQU0sTUFBTTNFLElBQUlzRCxJQUFJLGdDQUFnQ2tCLE9BQU9JLFNBQVMsQ0FBQyxFQUFFO0FBQzdFLFlBQU1wQixPQUFPbUIsS0FBS25CLE1BQU1xQixZQUFZO0FBRXBDLFlBQU1DLFlBQVl0QixLQUFLdUIsSUFBSSxDQUFDQyxNQUFNQyxXQUFXO0FBQUEsUUFDM0NDLElBQUlGLE1BQU1HO0FBQUFBLFFBQ1ZDLE1BQU1ILFFBQVE7QUFBQSxRQUNkSSxVQUFVTCxNQUFNTSxhQUFhO0FBQUEsUUFDN0JDLFdBQVdQLE1BQU1RLGNBQWM7QUFBQSxRQUMvQkMsZ0JBQWdCVCxNQUFNVSxtQkFBbUI7QUFBQSxRQUN6Q0MsV0FBV1gsTUFBTVksVUFBVUMsY0FBYztBQUFBLFFBQ3pDQyxVQUFVZCxNQUFNZSxhQUFhO0FBQUEsUUFDN0JDLFlBQVloQixNQUFNaUIsZUFBZTtBQUFBLFFBQ2pDQyxZQUNFbEIsTUFBTW1CLFlBQVlDLE9BQ2QsR0FBR3BCLE1BQU1tQixZQUFZQyxJQUFJLE1BQU1wQixNQUFNbUIsWUFBWUUsWUFBWSxLQUM3RHJCLE1BQU1zQixlQUFlQyxZQUNyQixHQUFHdkIsTUFBTXNCLGVBQWVDLFNBQVMsTUFBTXZCLE1BQU1zQixlQUFlRCxZQUFZLEtBQ3hFO0FBQUEsTUFDUixFQUFFO0FBRUZ6RSx1QkFBaUJrRCxTQUFTO0FBQUEsSUFDNUIsU0FBUzBCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxnQkFBZ0JBLEtBQUs7QUFDbkM1RSx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCLFVBQUM7QUFDQ0UsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFHQSxRQUFNNEUsY0FBYztBQUFBLElBQ2xCLEVBQUVDLFFBQVEsU0FBU0MsS0FBSyxPQUFPO0FBQUEsSUFDL0IsRUFBRUQsUUFBUSxRQUFRQyxLQUFLLFdBQVc7QUFBQSxJQUNsQyxFQUFFRCxRQUFRLFNBQVNDLEtBQUssWUFBWTtBQUFBLElBQ3BDLEVBQUVELFFBQVEsY0FBY0MsS0FBSyxpQkFBaUI7QUFBQSxJQUM5QyxFQUFFRCxRQUFRLFNBQVNDLEtBQUssWUFBWTtBQUFBLElBQ3BDLEVBQUVELFFBQVEsYUFBYUMsS0FBSyxXQUFXO0FBQUEsSUFDdkMsRUFBRUQsUUFBUSxlQUFlQyxLQUFLLGFBQWE7QUFBQSxJQUMzQyxFQUFFRCxRQUFRLGVBQWVDLEtBQUssYUFBYTtBQUFBLEVBQUM7QUFHOUMsUUFBTUMsZUFBZXBHLGtCQUFrQjtBQUV2QyxTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHVDQUFzQyw0Q0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQ0YsZUFDQyx1QkFBQyxTQUFJLFdBQVUsaURBQ2I7QUFBQSwrQkFBQyxRQUFLLE1BQUssV0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtCO0FBQUEsUUFBRztBQUFBLFFBQUMsdUJBQUMsVUFBSyxrQ0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdCO0FBQUEsV0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSw4Q0FHYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLHVCQUFzQiwyQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRDtBQUFBLFFBQ2xEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxPQUFPRTtBQUFBQSxZQUNQLFVBQVVxQztBQUFBQSxZQUNWLFdBQVU7QUFBQSxZQUVUNUMsdUJBQWE2RTtBQUFBQSxjQUFJLENBQUMrQixNQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsRUFBRTNHLE9BQ25DMkcsWUFBRTFHLFNBRGUwRyxFQUFFM0csT0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLFlBQ0Q7QUFBQTtBQUFBLFVBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVUE7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwrQkFBQyxXQUFNLFdBQVUsdUJBQXNCLHlCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdEO0FBQUEsUUFDaEQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU9RO0FBQUFBLFlBQ1AsVUFBVSxDQUFDeUQsTUFBTTtBQUNmeEQsa0NBQW9Cd0QsRUFBRTJDLE9BQU81RyxLQUFLO0FBQ2xDTywrQkFBaUIsUUFBUTtBQUFBLFlBQzNCO0FBQUEsWUFDQSxVQUFVLENBQUNtRztBQUFBQSxZQUNYLFdBQVcsc0NBQ1QsQ0FBQ0EsZUFBZSxnQkFBZ0IsaUJBQWlCO0FBQUE7QUFBQSxVQVRyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVSztBQUFBLFdBWlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSx1QkFBc0IsdUJBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsT0FBT2hHO0FBQUFBLFlBQ1AsVUFBVSxDQUFDdUQsTUFBTTtBQUNmdEQsOEJBQWdCc0QsRUFBRTJDLE9BQU81RyxLQUFLO0FBQzlCTywrQkFBaUIsUUFBUTtBQUFBLFlBQzNCO0FBQUEsWUFDQSxVQUFVLENBQUNtRztBQUFBQSxZQUNYLFdBQVcsc0NBQ1QsQ0FBQ0EsZUFBZSxnQkFBZ0IsaUJBQWlCO0FBQUE7QUFBQSxVQVRyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFVSztBQUFBLFdBWlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWNBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLCtCQUFDLFdBQU0sV0FBVSx1QkFBc0Isb0NBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxRQUMzRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLE9BQU90RjtBQUFBQSxZQUNQLFVBQVUsQ0FBQ3lGLE1BQU14RixzQkFBc0J3RixLQUFLLEVBQUU7QUFBQSxZQUM5QyxXQUFVO0FBQUEsWUFFVjtBQUFBLHFDQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkI7QUFBQSxjQUMxQjNGLFVBQVUwRDtBQUFBQSxnQkFBSSxDQUFDVixNQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPLE9BQU9BLEVBQUVjLEdBQUcsSUFDM0NkO0FBQUFBLG9CQUFFa0M7QUFBQUEsa0JBQVU7QUFBQSxrQkFBSWxDLEVBQUVnQztBQUFBQSxxQkFERGhDLEVBQUVjLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUE7QUFBQTtBQUFBLFVBWEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWUE7QUFBQSxXQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFlQTtBQUFBLFNBcEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxRUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSw4Q0FFYixpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDZCQUFDLFdBQU0sV0FBVSx1QkFBc0Isb0NBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMkQ7QUFBQSxNQUMzRDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLE9BQU8xRDtBQUFBQSxVQUNQLFVBQVUsQ0FBQ3VGLE1BQU10RixzQkFBc0JzRixLQUFLLEVBQUU7QUFBQSxVQUM5QyxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLE9BQU8sUUFBUCxFQUFjLE9BQU0sSUFBRyxtQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkI7QUFBQSxZQUMxQjdGLFVBQVU0RDtBQUFBQSxjQUFJLENBQUNYLE1BQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU8sT0FBT0EsRUFBRWUsR0FBRyxJQUMzQ2Y7QUFBQUEsa0JBQUVtQyxhQUFhbkMsRUFBRWdDO0FBQUFBLGdCQUFLO0FBQUEsZ0JBQUloQyxFQUFFaUM7QUFBQUEsbUJBRFhqQyxFQUFFZSxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsWUFDRDtBQUFBO0FBQUE7QUFBQSxRQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVlBO0FBQUEsU0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZUEsS0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDZEQUdiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSxpQ0FBQyxPQUFFLFdBQVUseUJBQXdCLHlDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE4RDtBQUFBLFVBQzlELHVCQUFDLE9BQUUsV0FBVSxxQ0FBcUN4RCx3QkFBY3NGLFVBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXVFO0FBQUEsYUFGekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSx5QkFBd0Isb0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsVUFDekQsdUJBQUMsT0FBRSxXQUFVLG9DQUVUdEYsd0JBQWN1RjtBQUFBQSxZQUFPLENBQUNDLE1BQ3BCOUYsVUFBVStGO0FBQUFBLGNBQ1IsQ0FBQy9DLE1BQU0sR0FBR0EsRUFBRWtDLFNBQVMsTUFBTWxDLEVBQUVnQyxZQUFZLE9BQU9jLEVBQUVqQjtBQUFBQSxZQUNwRDtBQUFBLFVBQ0YsRUFBRWUsVUFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsaUNBQUMsT0FBRSxXQUFVLHlCQUF3QixvQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBeUQ7QUFBQSxVQUN6RCx1QkFBQyxPQUFFLFdBQVUscUNBRVR0Rix3QkFBY3VGO0FBQUFBLFlBQU8sQ0FBQ0MsTUFDcEJoRyxVQUFVaUc7QUFBQUEsY0FDUixDQUFDaEQsTUFDQyxHQUFHQSxFQUFFbUMsYUFBYW5DLEVBQUVnQyxJQUFJLE1BQU1oQyxFQUFFaUMsWUFBWSxPQUFPYyxFQUFFakI7QUFBQUEsWUFDekQ7QUFBQSxVQUNGLEVBQUVlLFVBUE47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSx5QkFBd0IsaUNBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXNEO0FBQUEsVUFDdEQsdUJBQUMsT0FBRSxXQUFVLHFDQUVUdEYsd0JBQWN1RjtBQUFBQSxZQUFPLENBQUNDLE1BQ3BCbEcsT0FBT21HO0FBQUFBLGNBQ0wsQ0FBQ2pELE1BQU0sR0FBR0EsRUFBRWlDLElBQUksTUFBTWpDLEVBQUVrQyxZQUFZLE9BQU9jLEVBQUVqQjtBQUFBQSxZQUMvQztBQUFBLFVBQ0YsRUFBRWUsVUFOTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVFBO0FBQUEsYUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV0E7QUFBQSxXQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkNBO0FBQUEsTUFHQSx1QkFBQyxTQUFJLFdBQVUsa0NBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsb0NBQW1DLGtDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1FO0FBQUEsUUFFbEV0RixjQUFjc0YsV0FBVyxJQUN4Qix1QkFBQyxPQUFFLFdBQVUseUJBQXdCLG1DQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdELElBRXhELHVCQUFDLFFBQUcsV0FBVSxhQUNYLFdBQUMsR0FBRyxJQUFJSSxJQUFJMUYsY0FBY29ELElBQUksQ0FBQ29DLE1BQU1BLEVBQUVqQixVQUFVLENBQUMsQ0FBQyxFQUFFbkIsSUFBSSxDQUFDdUMsUUFBUTtBQUNqRSxjQUFJLENBQUNBLE9BQU9BLFFBQVEsTUFBTyxRQUFPO0FBRWxDLGdCQUFNQyxRQUFRNUYsY0FBY3VGLE9BQU8sQ0FBQ0MsTUFBTUEsRUFBRWpCLGVBQWVvQixHQUFHLEVBQUVMO0FBRWhFLGlCQUNFLHVCQUFDLFFBQWEsV0FBVSxzQ0FDdEI7QUFBQSxtQ0FBQyxVQUFLLFdBQVUsNkJBQTZCSyxpQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBaUQ7QUFBQSxZQUNqRCx1QkFBQyxVQUFLLFdBQVUsNkJBQTZCQyxtQkFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBbUQ7QUFBQSxlQUY1Q0QsS0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsUUFFSixDQUFDLEtBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsV0FuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFCQTtBQUFBLFNBeEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5RUE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDWnpGLDBCQUNDLHVCQUFDLFNBQUksV0FBVSw2QkFDYixpQ0FBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSyxLQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVRLHVCQUFDLGFBQVUsU0FBUzZFLGFBQWEsTUFBTS9FLGVBQWUsa0JBQWlCLDBCQUF5QixpQkFBZ0Isd0JBQWhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0ksS0FOaEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsT0EvTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdNQTtBQUVKO0FBQUVyQixHQWxXSUQsa0JBQWdCO0FBQUFtSCxLQUFoQm5IO0FBcVdOLGVBQWVBO0FBQWlCLElBQUFtSDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJTZWxlY3QiLCJTcGluIiwiYXBpIiwiRGF0YVRhYmxlIiwiZ3JvdXBPcHRpb25zIiwidmFsdWUiLCJsYWJlbCIsIk5vbkNvbnZlcnRlZExlYWQiLCJfcyIsImxvYWRpbmdQYWdlIiwic2V0TG9hZGluZ1BhZ2UiLCJzZWxlY3RlZExhYmVsIiwic2V0U2VsZWN0ZWRMYWJlbCIsInNlbGVjdGVkRnJvbURhdGUiLCJzZXRTZWxlY3RlZEZyb21EYXRlIiwic2VsZWN0ZWREYXRlIiwic2V0U2VsZWN0ZWREYXRlIiwidXNlcnMiLCJzZXRVc2VycyIsImFnZW50cyIsInNldEFnZW50cyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsImN1c3RvbWVycyIsInNldEN1c3RvbWVycyIsImN1c3RvbWVyUmVmZXJyZWRCeSIsInNldEN1c3RvbWVyUmVmZXJyZWRCeSIsImVtcGxveWVlUmVmZXJyZWRCeSIsInNldEVtcGxveWVlUmVmZXJyZWRCeSIsImxlYWRUYWJsZURhdGEiLCJzZXRMZWFkVGFibGVEYXRhIiwiZmV0Y2hpbmdMZWFkcyIsInNldEZldGNoaW5nTGVhZHMiLCJmb3JtYXREYXRlRW5DQSIsImRhdGUiLCJkIiwiRGF0ZSIsInl5eXkiLCJnZXRGdWxsWWVhciIsIm1tIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsImRkIiwiZ2V0RGF0ZSIsImdldElkRnJvbVZhbHVlIiwidmFsIiwic3BsaXQiLCJoYW5kbGVTZWxlY3RGaWx0ZXIiLCJ0b2RheSIsImYiLCJ5Iiwic2V0RGF0ZSIsInN0YXJ0IiwiZW5kIiwicDEiLCJnZXQiLCJjYXRjaCIsImRhdGEiLCJwMiIsImFnZW50IiwicDMiLCJlbXBsb3llZSIsInA0IiwiY3VzdG9tZXIiLCJQcm9taXNlIiwiYWxsIiwidGhlbiIsInUiLCJhIiwiZSIsImMiLCJmaW5hbGx5IiwiZmV0Y2hGaWx0ZXJlZExlYWRzIiwicGFyYW1zIiwiVVJMU2VhcmNoUGFyYW1zIiwiYXBwZW5kIiwicmVzIiwidG9TdHJpbmciLCJyZXNwb25zZSIsImZvcm1hdHRlZCIsIm1hcCIsImxlYWQiLCJpbmRleCIsImlkIiwiX2lkIiwiU2xObyIsIkxlYWROYW1lIiwibGVhZF9uYW1lIiwibGVhZFBob25lIiwibGVhZF9waG9uZSIsImxlYWRQcm9mZXNzaW9uIiwibGVhZF9wcm9mZXNzaW9uIiwiZ3JvdXBOYW1lIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwibGVhZFR5cGUiLCJsZWFkX3R5cGUiLCJzY2hlbWVUeXBlIiwic2NoZW1lX3R5cGUiLCJyZWZlcnJlZEJ5IiwibGVhZF9hZ2VudCIsIm5hbWUiLCJwaG9uZV9udW1iZXIiLCJsZWFkX2N1c3RvbWVyIiwiZnVsbF9uYW1lIiwiZXJyb3IiLCJjb25zb2xlIiwibGVhZENvbHVtbnMiLCJoZWFkZXIiLCJrZXkiLCJpc0N1c3RvbU1vZGUiLCJnIiwidGFyZ2V0IiwidiIsImxlbmd0aCIsImZpbHRlciIsImwiLCJzb21lIiwiU2V0IiwicmVmIiwiY291bnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJOb25Db252ZXJ0ZWRMZWFkLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIFNwaW4gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuXHJcbmNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICB7IHZhbHVlOiBcIlRvZGF5XCIsIGxhYmVsOiBcIlRvZGF5XCIgfSxcclxuICB7IHZhbHVlOiBcIlllc3RlcmRheVwiLCBsYWJlbDogXCJZZXN0ZXJkYXlcIiB9LFxyXG4gIHsgdmFsdWU6IFwiVGhpc01vbnRoXCIsIGxhYmVsOiBcIlRoaXMgTW9udGhcIiB9LFxyXG4gIHsgdmFsdWU6IFwiTGFzdE1vbnRoXCIsIGxhYmVsOiBcIkxhc3QgTW9udGhcIiB9LFxyXG4gIHsgdmFsdWU6IFwiVGhpc1llYXJcIiwgbGFiZWw6IFwiVGhpcyBZZWFyXCIgfSxcclxuICB7IHZhbHVlOiBcIkN1c3RvbVwiLCBsYWJlbDogXCJDdXN0b21cIiB9LFxyXG5dO1xyXG5cclxuLy8gY29uc3QgTm9uQ29udmVydGVkTGVhZCA9ICgpID0+IHtcclxuLy8gICBjb25zdCBbbG9hZGluZ1BhZ2UsIHNldExvYWRpbmdQYWdlXSA9IHVzZVN0YXRlKHRydWUpO1xyXG5cclxuLy8gICBjb25zdCBbc2VsZWN0ZWRMYWJlbCwgc2V0U2VsZWN0ZWRMYWJlbF0gPSB1c2VTdGF0ZShcIlRoaXNNb250aFwiKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2V0U2VsZWN0ZWRGcm9tRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWREYXRlLCBzZXRTZWxlY3RlZERhdGVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4vLyAgIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4vLyAgIGNvbnN0IFthZ2VudHMsIHNldEFnZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbY3VzdG9tZXJzLCBzZXRDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuLy8gICBjb25zdCBbY3VzdG9tZXJSZWZlcnJlZEJ5LCBzZXRDdXN0b21lclJlZmVycmVkQnldID0gdXNlU3RhdGUoXCJcIik7XHJcbi8vICAgY29uc3QgW2VtcGxveWVlUmVmZXJyZWRCeSwgc2V0RW1wbG95ZWVSZWZlcnJlZEJ5XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuLy8gICBjb25zdCBbbGVhZFRhYmxlRGF0YSwgc2V0TGVhZFRhYmxlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2ZldGNoaW5nTGVhZHMsIHNldEZldGNoaW5nTGVhZHNdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuLy8gICAvLyBGb3JtYXQgZGF0ZSBhcyB5eXl5LW1tLWRkXHJcbi8vICAgY29uc3QgZm9ybWF0RGF0ZUVuQ0EgPSAoZGF0ZSkgPT4ge1xyXG4vLyAgICAgaWYgKCFkYXRlKSByZXR1cm4gXCJcIjtcclxuLy8gICAgIGNvbnN0IGQgPSBuZXcgRGF0ZShkYXRlKTtcclxuLy8gICAgIGNvbnN0IHl5eXkgPSBkLmdldEZ1bGxZZWFyKCk7XHJcbi8vICAgICBjb25zdCBtbSA9IFN0cmluZyhkLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbi8vICAgICBjb25zdCBkZCA9IFN0cmluZyhkLmdldERhdGUoKSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4vLyAgICAgcmV0dXJuIGAke3l5eXl9LSR7bW19LSR7ZGR9YDtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBnZXRJZEZyb21WYWx1ZSA9ICh2YWwpID0+IHtcclxuLy8gICAgIGlmICghdmFsKSByZXR1cm4gXCJcIjtcclxuLy8gICAgIHJldHVybiB2YWwuc3BsaXQoXCJfXCIpWzFdIHx8IFwiXCI7XHJcbi8vICAgfTtcclxuXHJcbi8vICAgY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbi8vICAgICBzZXRTZWxlY3RlZExhYmVsKHZhbHVlKTtcclxuXHJcbi8vICAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcblxyXG4vLyAgICAgaWYgKHZhbHVlID09PSBcIlRvZGF5XCIpIHtcclxuLy8gICAgICAgY29uc3QgZiA9IGZvcm1hdERhdGVFbkNBKHRvZGF5KTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWREYXRlKGYpO1xyXG4vLyAgICAgfSBlbHNlIGlmICh2YWx1ZSA9PT0gXCJZZXN0ZXJkYXlcIikge1xyXG4vLyAgICAgICBjb25zdCB5ID0gbmV3IERhdGUodG9kYXkpO1xyXG4vLyAgICAgICB5LnNldERhdGUoeS5nZXREYXRlKCkgLSAxKTtcclxuLy8gICAgICAgY29uc3QgZiA9IGZvcm1hdERhdGVFbkNBKHkpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGYpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZik7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNNb250aFwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSwgMSk7XHJcbi8vICAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCkgKyAxLCAwKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlRW5DQShzdGFydCkpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZUVuQ0EoZW5kKSk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkxhc3RNb250aFwiKSB7XHJcbi8vICAgICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSAtIDEsIDEpO1xyXG4vLyAgICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAwKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlRW5DQShzdGFydCkpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZUVuQ0EoZW5kKSk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlRoaXNZZWFyXCIpIHtcclxuLy8gICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAwLCAxKTtcclxuLy8gICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgMTEsIDMxKTtcclxuLy8gICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShmb3JtYXREYXRlRW5DQShzdGFydCkpO1xyXG4vLyAgICAgICBzZXRTZWxlY3RlZERhdGUoZm9ybWF0RGF0ZUVuQ0EoZW5kKSk7XHJcbi8vICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbVwiKSB7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoXCJcIik7XHJcbi8vICAgICAgIHNldFNlbGVjdGVkRGF0ZShcIlwiKTtcclxuLy8gICAgIH1cclxuLy8gICB9O1xyXG5cclxuLy8gICAvLyBMb2FkIGRyb3Bkb3duc1xyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICBjb25zdCBwMSA9IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKS5jYXRjaCgoKSA9PiAoeyBkYXRhOiBbXSB9KSk7XHJcbi8vICAgICBjb25zdCBwMiA9IGFwaS5nZXQoXCIvYWdlbnQvZ2V0XCIpLmNhdGNoKCgpID0+ICh7IGRhdGE6IHsgYWdlbnQ6IFtdIH0gfSkpO1xyXG4vLyAgICAgY29uc3QgcDMgPSBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpLmNhdGNoKCgpID0+ICh7IGRhdGE6IHsgZW1wbG95ZWU6IFtdIH0gfSkpO1xyXG4vLyAgICAgY29uc3QgcDQgPSBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIikuY2F0Y2goKCkgPT4gKHsgZGF0YTogeyBjdXN0b21lcjogW10gfSB9KSk7XHJcblxyXG4vLyAgICAgUHJvbWlzZS5hbGwoW3AxLCBwMiwgcDMsIHA0XSlcclxuLy8gICAgICAgLnRoZW4oKFt1LCBhLCBlLCBjXSkgPT4ge1xyXG4vLyAgICAgICAgIHNldFVzZXJzKHU/LmRhdGEgfHwgW10pO1xyXG4vLyAgICAgICAgIHNldEFnZW50cyhhPy5kYXRhPy5hZ2VudCB8fCBbXSk7XHJcbi8vICAgICAgICAgc2V0RW1wbG95ZWVzKGU/LmRhdGE/LmVtcGxveWVlIHx8IFtdKTtcclxuLy8gICAgICAgICBzZXRDdXN0b21lcnMoYz8uZGF0YT8uY3VzdG9tZXIgfHwgW10pO1xyXG4vLyAgICAgICB9KVxyXG4vLyAgICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nUGFnZShmYWxzZSkpO1xyXG4vLyAgIH0sIFtdKTtcclxuXHJcbi8vICAgLy8gRkVUQ0ggTEVBRFMgd2hlbiBmaWx0ZXJzIGNoYW5nZVxyXG4vLyAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbi8vICAgICAvLyBPbmx5IGZldGNoIGlmIGJvdGggZGF0ZXMgYXJlIHByZXNlbnQgKGV2ZW4gZm9yIHByZXNldHMpXHJcbi8vICAgICBpZiAoc2VsZWN0ZWRGcm9tRGF0ZSAmJiBzZWxlY3RlZERhdGUpIHtcclxuLy8gICAgICAgZmV0Y2hGaWx0ZXJlZExlYWRzKCk7XHJcbi8vICAgICB9IGVsc2Uge1xyXG4vLyAgICAgICAvLyBJZiBkYXRlcyBhcmUgbWlzc2luZyAoZS5nLiwgQ3VzdG9tIHdpdGggbm8gaW5wdXQpLCBjbGVhciB0YWJsZVxyXG4vLyAgICAgICBzZXRMZWFkVGFibGVEYXRhKFtdKTtcclxuLy8gICAgIH1cclxuLy8gICB9LCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2VsZWN0ZWREYXRlLCBjdXN0b21lclJlZmVycmVkQnksIGVtcGxveWVlUmVmZXJyZWRCeV0pO1xyXG5cclxuLy8gICAvLyBJTklUSUFMSVpFIERFRkFVTFQgRklMVEVSIEFGVEVSIERST1BET1dOUyBBUkUgTE9BREVEIChvcHRpb25hbCBidXQgc2FmZSlcclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgaWYgKCFsb2FkaW5nUGFnZSkge1xyXG4vLyAgICAgICBoYW5kbGVTZWxlY3RGaWx0ZXIoXCJUaGlzTW9udGhcIik7XHJcbi8vICAgICB9XHJcbi8vICAgfSwgW2xvYWRpbmdQYWdlXSk7XHJcblxyXG4vLyAgIGNvbnN0IGZldGNoRmlsdGVyZWRMZWFkcyA9IGFzeW5jICgpID0+IHtcclxuLy8gICAgIHNldEZldGNoaW5nTGVhZHModHJ1ZSk7XHJcbi8vICAgICB0cnkge1xyXG4vLyAgICAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKCk7XHJcbi8vICAgICAgIHBhcmFtcy5hcHBlbmQoXCJmcm9tX2RhdGVcIiwgc2VsZWN0ZWRGcm9tRGF0ZSk7XHJcbi8vICAgICAgIHBhcmFtcy5hcHBlbmQoXCJ0b19kYXRlXCIsIHNlbGVjdGVkRGF0ZSk7XHJcblxyXG4vLyAgICAgICBpZiAoY3VzdG9tZXJSZWZlcnJlZEJ5KSB7XHJcbi8vICAgICAgICAgcGFyYW1zLmFwcGVuZChcImN1c3RvbWVyX2lkXCIsIGdldElkRnJvbVZhbHVlKGN1c3RvbWVyUmVmZXJyZWRCeSkpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICAgIGlmIChlbXBsb3llZVJlZmVycmVkQnkpIHtcclxuLy8gICAgICAgICBwYXJhbXMuYXBwZW5kKFwiYWdlbnRfaWRcIiwgZ2V0SWRGcm9tVmFsdWUoZW1wbG95ZWVSZWZlcnJlZEJ5KSk7XHJcbi8vICAgICAgIH1cclxuXHJcbi8vICAgICAgIGNvbnN0IHVybCA9IGAvbGVhZC9ub3QtY29udmVydGVkLWN1c3RvbWVyPyR7cGFyYW1zLnRvU3RyaW5nKCl9YDtcclxuLy8gICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldCh1cmwpO1xyXG4vLyAgICAgICBjb25zdCBkYXRhID0gcmVzPy5kYXRhPy5yZXNwb25zZSB8fCBbXTtcclxuXHJcbi8vICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGRhdGEubWFwKChsZWFkLCBpbmRleCkgPT4gKHtcclxuLy8gICAgICAgICBpZDogbGVhZD8uX2lkLFxyXG4vLyAgICAgICAgIFNsTm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICBMZWFkTmFtZTogbGVhZD8ubGVhZF9uYW1lIHx8IFwiXCIsXHJcbi8vICAgICAgICAgbGVhZFBob25lOiBsZWFkPy5sZWFkX3Bob25lIHx8IFwiXCIsXHJcbi8vICAgICAgICAgbGVhZFByb2Zlc3Npb246IGxlYWQ/LmxlYWRfcHJvZmVzc2lvbiB8fCBcIlwiLFxyXG4vLyAgICAgICAgIGdyb3VwTmFtZTogbGVhZD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJcIixcclxuLy8gICAgICAgICBsZWFkVHlwZTogbGVhZD8ubGVhZF90eXBlIHx8IFwiXCIsXHJcbi8vICAgICAgICAgc2NoZW1lVHlwZTogbGVhZD8uc2NoZW1lX3R5cGUgfHwgXCJcIixcclxuLy8gICAgICAgICByZWZlcnJlZEJ5OlxyXG4vLyAgICAgICAgICAgKGxlYWQ/LmxlYWRfYWdlbnQ/Lm5hbWUgJiYgbGVhZD8ubGVhZF9hZ2VudD8ucGhvbmVfbnVtYmVyKVxyXG4vLyAgICAgICAgICAgICA/IGAke2xlYWQ/LmxlYWRfYWdlbnQ/Lm5hbWV9IHwgJHtsZWFkPy5sZWFkX2FnZW50Py5waG9uZV9udW1iZXJ9YFxyXG4vLyAgICAgICAgICAgICA6IChsZWFkPy5sZWFkX2N1c3RvbWVyPy5mdWxsX25hbWUgJiYgbGVhZD8ubGVhZF9jdXN0b21lcj8ucGhvbmVfbnVtYmVyKVxyXG4vLyAgICAgICAgICAgICA/IGAke2xlYWQ/LmxlYWRfY3VzdG9tZXI/LmZ1bGxfbmFtZX0gfCAke2xlYWQ/LmxlYWRfY3VzdG9tZXI/LnBob25lX251bWJlcn1gXHJcbi8vICAgICAgICAgICAgIDogXCJOL0FcIixcclxuLy8gICAgICAgfSkpO1xyXG5cclxuLy8gICAgICAgc2V0TGVhZFRhYmxlRGF0YShmb3JtYXR0ZWQpO1xyXG4vLyAgICAgfSBjYXRjaCAoZSkge1xyXG4vLyAgICAgICBjb25zb2xlLmVycm9yKFwiRmV0Y2ggRXJyb3I6XCIsIGUpO1xyXG4vLyAgICAgICBzZXRMZWFkVGFibGVEYXRhKFtdKTtcclxuLy8gICAgIH0gZmluYWxseSB7XHJcbi8vICAgICAgIHNldEZldGNoaW5nTGVhZHMoZmFsc2UpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH07XHJcblxyXG4vLyAgIGNvbnN0IGxlYWRDb2x1bW5zID0gW1xyXG4vLyAgICAgeyBoZWFkZXI6IFwiU2wgTm9cIiwga2V5OiBcIlNsTm9cIiB9LFxyXG4vLyAgICAgeyBoZWFkZXI6IFwiTmFtZVwiLCBrZXk6IFwiTGVhZE5hbWVcIiB9LFxyXG4vLyAgICAgeyBoZWFkZXI6IFwiUGhvbmVcIiwga2V5OiBcImxlYWRQaG9uZVwiIH0sXHJcbi8vICAgICB7IGhlYWRlcjogXCJQcm9mZXNzaW9uXCIsIGtleTogXCJsZWFkUHJvZmVzc2lvblwiIH0sXHJcbi8vICAgICB7IGhlYWRlcjogXCJHcm91cFwiLCBrZXk6IFwiZ3JvdXBOYW1lXCIgfSxcclxuLy8gICAgIHsgaGVhZGVyOiBcIkxlYWQgVHlwZVwiLCBrZXk6IFwibGVhZFR5cGVcIiB9LFxyXG4vLyAgICAgeyBoZWFkZXI6IFwiU2NoZW1lIFR5cGVcIiwga2V5OiBcInNjaGVtZVR5cGVcIiB9LFxyXG4vLyAgICAgeyBoZWFkZXI6IFwiUmVmZXJyZWQgQnlcIiwga2V5OiBcInJlZmVycmVkQnlcIiB9LFxyXG4vLyAgIF07XHJcblxyXG4vLyAgIC8vIERpc2FibGUgbWFudWFsIGRhdGUgaW5wdXRzIHVubGVzcyBcIkN1c3RvbVwiIGlzIHNlbGVjdGVkXHJcbi8vICAgY29uc3QgaXNDdXN0b21Nb2RlID0gc2VsZWN0ZWRMYWJlbCA9PT0gXCJDdXN0b21cIjtcclxuXHJcbi8vICAgcmV0dXJuIChcclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHctZnVsbFwiPlxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbi8vICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbi8vICAgICAgICAgICBSZXBvcnQg4oCTIE5vbi1Db252ZXJ0ZWQgTGVhZHNcclxuLy8gICAgICAgICA8L2gxPlxyXG4vLyAgICAgICAgIHtsb2FkaW5nUGFnZSAmJiAoXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4vLyAgICAgICAgICAgICA8U3BpbiBzaXplPVwic21hbGxcIiAvPiA8c3Bhbj5Mb2FkaW5nIGxvb2t1cHMuLi48L3NwYW4+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICApfVxyXG4vLyAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgIHsvKiBGSUxURVJTIFJPVyAxICovfVxyXG4vLyAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItNFwiPlxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbi8vICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPkRhdGUgRmlsdGVyPC9sYWJlbD5cclxuLy8gICAgICAgICAgIDxTZWxlY3RcclxuLy8gICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4vLyAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRMYWJlbH1cclxuLy8gICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVNlbGVjdEZpbHRlcn1cclxuLy8gICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTFcIlxyXG4vLyAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4vLyAgICAgICAgICAgPlxyXG4vLyAgICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgoZykgPT4gKFxyXG4vLyAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Zy52YWx1ZX0gdmFsdWU9e2cudmFsdWV9PlxyXG4vLyAgICAgICAgICAgICAgICAge2cubGFiZWx9XHJcbi8vICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgIDwvU2VsZWN0PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4vLyAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5Gcm9tIERhdGU8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgPGlucHV0XHJcbi8vICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuLy8gICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRnJvbURhdGV9XHJcbi8vICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4vLyAgICAgICAgICAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZS50YXJnZXQudmFsdWUpO1xyXG4vLyAgICAgICAgICAgICAgIHNldFNlbGVjdGVkTGFiZWwoXCJDdXN0b21cIik7XHJcbi8vICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgIGRpc2FibGVkPXshaXNDdXN0b21Nb2RlfSAvLyDihpDihpDihpAgS0VZIEZJWFxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgaC0xMSBib3JkZXIgcm91bmRlZC1sZyBweC0zICR7XHJcbi8vICAgICAgICAgICAgICAgIWlzQ3VzdG9tTW9kZSA/IFwiYmctZ3JheS0xMDAgY3Vyc29yLW5vdC1hbGxvd2VkXCIgOiBcImJvcmRlci1ncmF5LTMwMFwiXHJcbi8vICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuLy8gICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+VG8gRGF0ZTwvbGFiZWw+XHJcbi8vICAgICAgICAgICA8aW5wdXRcclxuLy8gICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4vLyAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWREYXRlfVxyXG4vLyAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuLy8gICAgICAgICAgICAgICBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQudmFsdWUpO1xyXG4vLyAgICAgICAgICAgICAgIHNldFNlbGVjdGVkTGFiZWwoXCJDdXN0b21cIik7XHJcbi8vICAgICAgICAgICAgIH19XHJcbi8vICAgICAgICAgICAgIGRpc2FibGVkPXshaXNDdXN0b21Nb2RlfSAvLyDihpDihpDihpAgS0VZIEZJWFxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgaC0xMSBib3JkZXIgcm91bmRlZC1sZyBweC0zICR7XHJcbi8vICAgICAgICAgICAgICAgIWlzQ3VzdG9tTW9kZSA/IFwiYmctZ3JheS0xMDAgY3Vyc29yLW5vdC1hbGxvd2VkXCIgOiBcImJvcmRlci1ncmF5LTMwMFwiXHJcbi8vICAgICAgICAgICAgIH1gfVxyXG4vLyAgICAgICAgICAgLz5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuLy8gICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+Q3VzdG9tZXIgUmVmZXJyZWQgQnk8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgPFNlbGVjdFxyXG4vLyAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbi8vICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuLy8gICAgICAgICAgICAgdmFsdWU9e2N1c3RvbWVyUmVmZXJyZWRCeX1cclxuLy8gICAgICAgICAgICAgb25DaGFuZ2U9eyh2KSA9PiBzZXRDdXN0b21lclJlZmVycmVkQnkodiB8fCBcIlwiKX1cclxuLy8gICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQ3VzdG9tZXIgUmVmZXJyZXJcIlxyXG4vLyAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMVwiXHJcbi8vICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbi8vICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICA8U2VsZWN0Lk9wdEdyb3VwIGxhYmVsPVwiVXNlcnNcIj5cclxuLy8gICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1KSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3UuX2lkfSB2YWx1ZT17YFVTRVJfJHt1Ll9pZH1gfT5cclxuLy8gICAgICAgICAgICAgICAgICAge3UuZnVsbF9uYW1lfSB8IHt1LnBob25lX251bWJlcn1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgPC9TZWxlY3QuT3B0R3JvdXA+XHJcbi8vICAgICAgICAgICAgIDxTZWxlY3QuT3B0R3JvdXAgbGFiZWw9XCJBZ2VudHNcIj5cclxuLy8gICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYSkgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXthLl9pZH0gdmFsdWU9e2BBR0VOVF8ke2EuX2lkfWB9PlxyXG4vLyAgICAgICAgICAgICAgICAgICB7YS5uYW1lfSB8IHthLnBob25lX251bWJlcn1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgPC9TZWxlY3QuT3B0R3JvdXA+XHJcbi8vICAgICAgICAgICAgIDxTZWxlY3QuT3B0R3JvdXAgbGFiZWw9XCJDdXN0b21lcnNcIj5cclxuLy8gICAgICAgICAgICAgICB7Y3VzdG9tZXJzLm1hcCgoYykgPT4gKFxyXG4vLyAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtjLl9pZH0gdmFsdWU9e2BDVVNfJHtjLl9pZH1gfT5cclxuLy8gICAgICAgICAgICAgICAgICAge2MuZnVsbF9uYW1lfSB8IHtjLnBob25lX251bWJlcn1cclxuLy8gICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgICApKX1cclxuLy8gICAgICAgICAgICAgPC9TZWxlY3QuT3B0R3JvdXA+XHJcbi8vICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICB7LyogRklMVEVSUyBST1cgMiAqL31cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC00IG1iLTRcIj5cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4vLyAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5FbXBsb3llZSBSZWZlcnJlZCBCeTwvbGFiZWw+XHJcbi8vICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuLy8gICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4vLyAgICAgICAgICAgICB2YWx1ZT17ZW1wbG95ZWVSZWZlcnJlZEJ5fVxyXG4vLyAgICAgICAgICAgICBvbkNoYW5nZT17KHYpID0+IHNldEVtcGxveWVlUmVmZXJyZWRCeSh2IHx8IFwiXCIpfVxyXG4vLyAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZSBSZWZlcnJlclwiXHJcbi8vICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTExXCJcclxuLy8gICAgICAgICAgID5cclxuLy8gICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIj5BbGw8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlLl9pZH0gdmFsdWU9e2BFTVBfJHtlLl9pZH1gfT5cclxuLy8gICAgICAgICAgICAgICAgIHtlLmZ1bGxfbmFtZSB8fCBlLm5hbWV9IHwge2UucGhvbmVfbnVtYmVyfVxyXG4vLyAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuLy8gICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICA8L1NlbGVjdD5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICB7LyogU1VNTUFSWSBCT1ggKi99XHJcbi8vIDxkaXYgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTUwIGJvcmRlciBib3JkZXItdmlvbGV0LTIwMCByb3VuZGVkLWxnIHAtNCBtYi00XCI+XHJcblxyXG4vLyAgIHsvKiBUT1AgU1VNTUFSWSA0LUJPWCBHUklEICovfVxyXG4vLyAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtNCBnYXAtNCBtYi00XCI+XHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XHJcbi8vICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgdGV4dC1zbVwiPlRvdGFsIE5vbi1Db252ZXJ0ZWQgTGVhZHM8L3A+XHJcbi8vICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtdmlvbGV0LTcwMFwiPntsZWFkVGFibGVEYXRhLmxlbmd0aH08L3A+XHJcbi8vICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XHJcbi8vICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgdGV4dC1zbVwiPlJlZmVycmVkIGJ5IEN1c3RvbWVyPC9wPlxyXG4vLyAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4vLyAgICAgICAgIHtcclxuLy8gICAgICAgICAgIGxlYWRUYWJsZURhdGEuZmlsdGVyKGwgPT5cclxuLy8gICAgICAgICAgICAgY3VzdG9tZXJzLnNvbWUoYyA9PlxyXG4vLyAgICAgICAgICAgICAgIGAke2MuZnVsbF9uYW1lfSB8ICR7Yy5waG9uZV9udW1iZXJ9YCA9PT0gbC5yZWZlcnJlZEJ5XHJcbi8vICAgICAgICAgICAgIClcclxuLy8gICAgICAgICAgICkubGVuZ3RoXHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICA8L3A+XHJcbi8vICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XHJcbi8vICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgdGV4dC1zbVwiPlJlZmVycmVkIGJ5IEVtcGxveWVlPC9wPlxyXG4vLyAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS03MDBcIj5cclxuLy8gICAgICAgICB7XHJcbi8vICAgICAgICAgICBsZWFkVGFibGVEYXRhLmZpbHRlcihsID0+XHJcbi8vICAgICAgICAgICAgIGVtcGxveWVlcy5zb21lKGUgPT5cclxuLy8gICAgICAgICAgICAgICBgJHtlLmZ1bGxfbmFtZSB8fCBlLm5hbWV9IHwgJHtlLnBob25lX251bWJlcn1gID09PSBsLnJlZmVycmVkQnlcclxuLy8gICAgICAgICAgICAgKVxyXG4vLyAgICAgICAgICAgKS5sZW5ndGhcclxuLy8gICAgICAgICB9XHJcbi8vICAgICAgIDwvcD5cclxuLy8gICAgIDwvZGl2PlxyXG5cclxuLy8gICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cclxuLy8gICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMCB0ZXh0LXNtXCI+UmVmZXJyZWQgYnkgQWdlbnQ8L3A+XHJcbi8vICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtb3JhbmdlLTcwMFwiPlxyXG4vLyAgICAgICAgIHtcclxuLy8gICAgICAgICAgIGxlYWRUYWJsZURhdGEuZmlsdGVyKGwgPT5cclxuLy8gICAgICAgICAgICAgYWdlbnRzLnNvbWUoYSA9PlxyXG4vLyAgICAgICAgICAgICAgIGAke2EubmFtZX0gfCAke2EucGhvbmVfbnVtYmVyfWAgPT09IGwucmVmZXJyZWRCeVxyXG4vLyAgICAgICAgICAgICApXHJcbi8vICAgICAgICAgICApLmxlbmd0aFxyXG4vLyAgICAgICAgIH1cclxuLy8gICAgICAgPC9wPlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgPC9kaXY+XHJcblxyXG4vLyAgIHsvKiBERVRBSUxFRCBSRUZFUlJFUiBOQU1FIFdJVEggQ09VTlQgKi99XHJcbi8vICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTQgcm91bmRlZC1sZyBib3JkZXJcIj5cclxuLy8gICAgIDxoMiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlJlZmVycmVyIEJyZWFrZG93bjwvaDI+XHJcblxyXG4vLyAgICAge2xlYWRUYWJsZURhdGEubGVuZ3RoID09PSAwID8gKFxyXG4vLyAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtc21cIj5ObyBsZWFkcyBhdmFpbGFibGUuPC9wPlxyXG4vLyAgICAgKSA6IChcclxuLy8gICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4vLyAgICAgICAgIHtbLi4ubmV3IFNldChsZWFkVGFibGVEYXRhLm1hcChsID0+IGwucmVmZXJyZWRCeSkpXS5tYXAocmVmID0+IHtcclxuLy8gICAgICAgICAgIGlmICghcmVmIHx8IHJlZiA9PT0gXCJOL0FcIikgcmV0dXJuIG51bGw7XHJcblxyXG4vLyAgICAgICAgICAgY29uc3QgY291bnQgPSBsZWFkVGFibGVEYXRhLmZpbHRlcihsID0+IGwucmVmZXJyZWRCeSA9PT0gcmVmKS5sZW5ndGg7XHJcblxyXG4vLyAgICAgICAgICAgcmV0dXJuIChcclxuLy8gICAgICAgICAgICAgPGxpIGtleT17cmVmfSBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBweS0xXCI+XHJcbi8vICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPntyZWZ9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXZpb2xldC03MDBcIj57Y291bnR9PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICA8L2xpPlxyXG4vLyAgICAgICAgICAgKTtcclxuLy8gICAgICAgICB9KX1cclxuLy8gICAgICAgPC91bD5cclxuLy8gICAgICl9XHJcbi8vICAgPC9kaXY+XHJcbi8vIDwvZGl2PlxyXG5cclxuXHJcbi8vICAgICAgIHsvKiBUQUJMRSAqL31cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBzaGFkb3cgcm91bmRlZC1sZyBwLTMgbWluLWgtWzIwMHB4XVwiPlxyXG4vLyAgICAgICAgIHtmZXRjaGluZ0xlYWRzID8gKFxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIHB5LTE2XCI+XHJcbi8vICAgICAgICAgICAgIDxTcGluIC8+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICApIDogKFxyXG4vLyAgICAgICAgICAgPERhdGFUYWJsZSBjb2x1bW5zPXtsZWFkQ29sdW1uc30gZGF0YT17bGVhZFRhYmxlRGF0YX0gLz5cclxuLy8gICAgICAgICApfVxyXG4vLyAgICAgICA8L2Rpdj5cclxuLy8gICAgIDwvZGl2PlxyXG4vLyAgICk7XHJcbi8vIH07XHJcblxyXG5jb25zdCBOb25Db252ZXJ0ZWRMZWFkID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtsb2FkaW5nUGFnZSwgc2V0TG9hZGluZ1BhZ2VdID0gdXNlU3RhdGUodHJ1ZSk7XHJcblxyXG4gIGNvbnN0IFtzZWxlY3RlZExhYmVsLCBzZXRTZWxlY3RlZExhYmVsXSA9IHVzZVN0YXRlKFwiVGhpc01vbnRoXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEZyb21EYXRlLCBzZXRTZWxlY3RlZEZyb21EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZERhdGUsIHNldFNlbGVjdGVkRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjdXN0b21lcnMsIHNldEN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIGNvbnN0IFtjdXN0b21lclJlZmVycmVkQnksIHNldEN1c3RvbWVyUmVmZXJyZWRCeV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZW1wbG95ZWVSZWZlcnJlZEJ5LCBzZXRFbXBsb3llZVJlZmVycmVkQnldID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IFtsZWFkVGFibGVEYXRhLCBzZXRMZWFkVGFibGVEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZmV0Y2hpbmdMZWFkcywgc2V0RmV0Y2hpbmdMZWFkc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIEZPUk1BVCBEQVRFIFlZWVktTU0tRERcclxuICBjb25zdCBmb3JtYXREYXRlRW5DQSA9IChkYXRlKSA9PiB7XHJcbiAgICBpZiAoIWRhdGUpIHJldHVybiBcIlwiO1xyXG4gICAgY29uc3QgZCA9IG5ldyBEYXRlKGRhdGUpO1xyXG4gICAgY29uc3QgeXl5eSA9IGQuZ2V0RnVsbFllYXIoKTtcclxuICAgIGNvbnN0IG1tID0gU3RyaW5nKGQuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICAgIGNvbnN0IGRkID0gU3RyaW5nKGQuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCBcIjBcIik7XHJcbiAgICByZXR1cm4gYCR7eXl5eX0tJHttbX0tJHtkZH1gO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGdldElkRnJvbVZhbHVlID0gKHZhbCkgPT4ge1xyXG4gICAgaWYgKCF2YWwpIHJldHVybiBcIlwiO1xyXG4gICAgcmV0dXJuIHZhbC5zcGxpdChcIl9cIilbMV0gfHwgXCJcIjtcclxuICB9O1xyXG5cclxuICAvLyBIQU5ETEUgRFJPUERPV04gUFJFU0VUIERBVEUgU0VMRUNUSU9OXHJcbiAgY29uc3QgaGFuZGxlU2VsZWN0RmlsdGVyID0gKHZhbHVlKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZExhYmVsKHZhbHVlKTtcclxuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcclxuXHJcbiAgICBpZiAodmFsdWUgPT09IFwiVG9kYXlcIikge1xyXG4gICAgICBjb25zdCBmID0gZm9ybWF0RGF0ZUVuQ0EodG9kYXkpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGYpO1xyXG4gICAgICBzZXRTZWxlY3RlZERhdGUoZik7XHJcbiAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIlllc3RlcmRheVwiKSB7XHJcbiAgICAgIGNvbnN0IHkgPSBuZXcgRGF0ZSh0b2RheSk7XHJcbiAgICAgIHkuc2V0RGF0ZSh5LmdldERhdGUoKSAtIDEpO1xyXG4gICAgICBjb25zdCBmID0gZm9ybWF0RGF0ZUVuQ0EoeSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRnJvbURhdGUoZik7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc01vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpLCAxKTtcclxuICAgICAgY29uc3QgZW5kID0gbmV3IERhdGUodG9kYXkuZ2V0RnVsbFllYXIoKSwgdG9kYXkuZ2V0TW9udGgoKSArIDEsIDApO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGVFbkNBKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlRW5DQShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiTGFzdE1vbnRoXCIpIHtcclxuICAgICAgY29uc3Qgc3RhcnQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCB0b2RheS5nZXRNb250aCgpIC0gMSwgMSk7XHJcbiAgICAgIGNvbnN0IGVuZCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIHRvZGF5LmdldE1vbnRoKCksIDApO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGVFbkNBKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlRW5DQShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiVGhpc1llYXJcIikge1xyXG4gICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHRvZGF5LmdldEZ1bGxZZWFyKCksIDAsIDEpO1xyXG4gICAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZSh0b2RheS5nZXRGdWxsWWVhcigpLCAxMSwgMzEpO1xyXG4gICAgICBzZXRTZWxlY3RlZEZyb21EYXRlKGZvcm1hdERhdGVFbkNBKHN0YXJ0KSk7XHJcbiAgICAgIHNldFNlbGVjdGVkRGF0ZShmb3JtYXREYXRlRW5DQShlbmQpKTtcclxuICAgIH0gZWxzZSBpZiAodmFsdWUgPT09IFwiQ3VzdG9tXCIpIHtcclxuICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShcIlwiKTtcclxuICAgICAgc2V0U2VsZWN0ZWREYXRlKFwiXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIExPQUQgRFJPUERPV04gREFUQVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBwMSA9IGFwaS5nZXQoXCIvdXNlci9nZXQtdXNlclwiKS5jYXRjaCgoKSA9PiAoeyBkYXRhOiBbXSB9KSk7XHJcbiAgICBjb25zdCBwMiA9IGFwaS5nZXQoXCIvYWdlbnQvZ2V0XCIpLmNhdGNoKCgpID0+ICh7IGRhdGE6IHsgYWdlbnQ6IFtdIH0gfSkpO1xyXG4gICAgY29uc3QgcDMgPSBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpLmNhdGNoKCgpID0+ICh7IGRhdGE6IHsgZW1wbG95ZWU6IFtdIH0gfSkpO1xyXG4gICAgY29uc3QgcDQgPSBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIikuY2F0Y2goKCkgPT4gKHsgZGF0YTogeyBjdXN0b21lcjogW10gfSB9KSk7XHJcblxyXG4gICAgUHJvbWlzZS5hbGwoW3AxLCBwMiwgcDMsIHA0XSlcclxuICAgICAgLnRoZW4oKFt1LCBhLCBlLCBjXSkgPT4ge1xyXG4gICAgICAgIHNldFVzZXJzKHU/LmRhdGEgfHwgW10pO1xyXG4gICAgICAgIHNldEFnZW50cyhhPy5kYXRhPy5hZ2VudCB8fCBbXSk7XHJcbiAgICAgICAgc2V0RW1wbG95ZWVzKGU/LmRhdGE/LmVtcGxveWVlIHx8IFtdKTtcclxuICAgICAgICBzZXRDdXN0b21lcnMoYz8uZGF0YT8uY3VzdG9tZXIgfHwgW10pO1xyXG4gICAgICB9KVxyXG4gICAgICAuZmluYWxseSgoKSA9PiBzZXRMb2FkaW5nUGFnZShmYWxzZSkpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gRkVUQ0ggTEVBRFMgV0hFTiBGSUxURVIgQ0hBTkdFU1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoc2VsZWN0ZWRGcm9tRGF0ZSAmJiBzZWxlY3RlZERhdGUpIHtcclxuICAgICAgZmV0Y2hGaWx0ZXJlZExlYWRzKCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRMZWFkVGFibGVEYXRhKFtdKTtcclxuICAgIH1cclxuICB9LCBbc2VsZWN0ZWRGcm9tRGF0ZSwgc2VsZWN0ZWREYXRlLCBjdXN0b21lclJlZmVycmVkQnksIGVtcGxveWVlUmVmZXJyZWRCeV0pO1xyXG5cclxuICAvLyBERUZBVUxUIExPQUQgPSBUSElTIE1PTlRIXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghbG9hZGluZ1BhZ2UpIHtcclxuICAgICAgaGFuZGxlU2VsZWN0RmlsdGVyKFwiVGhpc01vbnRoXCIpO1xyXG4gICAgfVxyXG4gIH0sIFtsb2FkaW5nUGFnZV0pO1xyXG5cclxuICBjb25zdCBmZXRjaEZpbHRlcmVkTGVhZHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBzZXRGZXRjaGluZ0xlYWRzKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcygpO1xyXG4gICAgICBwYXJhbXMuYXBwZW5kKFwiZnJvbV9kYXRlXCIsIHNlbGVjdGVkRnJvbURhdGUpO1xyXG4gICAgICBwYXJhbXMuYXBwZW5kKFwidG9fZGF0ZVwiLCBzZWxlY3RlZERhdGUpO1xyXG5cclxuICAgICAgaWYgKGN1c3RvbWVyUmVmZXJyZWRCeSkge1xyXG4gICAgICAgIHBhcmFtcy5hcHBlbmQoXCJjdXN0b21lcl9pZFwiLCBnZXRJZEZyb21WYWx1ZShjdXN0b21lclJlZmVycmVkQnkpKTtcclxuICAgICAgfVxyXG4gICAgICBpZiAoZW1wbG95ZWVSZWZlcnJlZEJ5KSB7XHJcbiAgICAgICAgcGFyYW1zLmFwcGVuZChcImFnZW50X2lkXCIsIGdldElkRnJvbVZhbHVlKGVtcGxveWVlUmVmZXJyZWRCeSkpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KGAvbGVhZC9ub3QtY29udmVydGVkLWN1c3RvbWVyPyR7cGFyYW1zLnRvU3RyaW5nKCl9YCk7XHJcbiAgICAgIGNvbnN0IGRhdGEgPSByZXM/LmRhdGE/LnJlc3BvbnNlIHx8IFtdO1xyXG5cclxuICAgICAgY29uc3QgZm9ybWF0dGVkID0gZGF0YS5tYXAoKGxlYWQsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIGlkOiBsZWFkPy5faWQsXHJcbiAgICAgICAgU2xObzogaW5kZXggKyAxLFxyXG4gICAgICAgIExlYWROYW1lOiBsZWFkPy5sZWFkX25hbWUgfHwgXCJcIixcclxuICAgICAgICBsZWFkUGhvbmU6IGxlYWQ/LmxlYWRfcGhvbmUgfHwgXCJcIixcclxuICAgICAgICBsZWFkUHJvZmVzc2lvbjogbGVhZD8ubGVhZF9wcm9mZXNzaW9uIHx8IFwiXCIsXHJcbiAgICAgICAgZ3JvdXBOYW1lOiBsZWFkPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgIGxlYWRUeXBlOiBsZWFkPy5sZWFkX3R5cGUgfHwgXCJcIixcclxuICAgICAgICBzY2hlbWVUeXBlOiBsZWFkPy5zY2hlbWVfdHlwZSB8fCBcIlwiLFxyXG4gICAgICAgIHJlZmVycmVkQnk6XHJcbiAgICAgICAgICBsZWFkPy5sZWFkX2FnZW50Py5uYW1lXHJcbiAgICAgICAgICAgID8gYCR7bGVhZD8ubGVhZF9hZ2VudD8ubmFtZX0gfCAke2xlYWQ/LmxlYWRfYWdlbnQ/LnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgIDogbGVhZD8ubGVhZF9jdXN0b21lcj8uZnVsbF9uYW1lXHJcbiAgICAgICAgICAgID8gYCR7bGVhZD8ubGVhZF9jdXN0b21lcj8uZnVsbF9uYW1lfSB8ICR7bGVhZD8ubGVhZF9jdXN0b21lcj8ucGhvbmVfbnVtYmVyfWBcclxuICAgICAgICAgICAgOiBcIk4vQVwiLFxyXG4gICAgICB9KSk7XHJcblxyXG4gICAgICBzZXRMZWFkVGFibGVEYXRhKGZvcm1hdHRlZCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRmV0Y2ggZXJyb3I6XCIsIGVycm9yKTtcclxuICAgICAgc2V0TGVhZFRhYmxlRGF0YShbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRGZXRjaGluZ0xlYWRzKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBUQUJMRSBDT0xVTU5TXHJcbiAgY29uc3QgbGVhZENvbHVtbnMgPSBbXHJcbiAgICB7IGhlYWRlcjogXCJTbCBOb1wiLCBrZXk6IFwiU2xOb1wiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJOYW1lXCIsIGtleTogXCJMZWFkTmFtZVwiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJQaG9uZVwiLCBrZXk6IFwibGVhZFBob25lXCIgfSxcclxuICAgIHsgaGVhZGVyOiBcIlByb2Zlc3Npb25cIiwga2V5OiBcImxlYWRQcm9mZXNzaW9uXCIgfSxcclxuICAgIHsgaGVhZGVyOiBcIkdyb3VwXCIsIGtleTogXCJncm91cE5hbWVcIiB9LFxyXG4gICAgeyBoZWFkZXI6IFwiTGVhZCBUeXBlXCIsIGtleTogXCJsZWFkVHlwZVwiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJTY2hlbWUgVHlwZVwiLCBrZXk6IFwic2NoZW1lVHlwZVwiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJSZWZlcnJlZCBCeVwiLCBrZXk6IFwicmVmZXJyZWRCeVwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgaXNDdXN0b21Nb2RlID0gc2VsZWN0ZWRMYWJlbCA9PT0gXCJDdXN0b21cIjtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHctZnVsbFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi00XCI+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICBSZXBvcnQg4oCTIE5vbi1Db252ZXJ0ZWQgTGVhZHNcclxuICAgICAgICA8L2gxPlxyXG4gICAgICAgIHtsb2FkaW5nUGFnZSAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICA8U3BpbiBzaXplPVwic21hbGxcIiAvPiA8c3Bhbj5Mb2FkaW5nIGxvb2t1cHMuLi48L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBGSUxURVJTICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItNFwiPlxyXG5cclxuICAgICAgICB7LyogREFURSBGSUxURVIgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cclxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+RGF0ZSBGaWx0ZXI8L2xhYmVsPlxyXG4gICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRMYWJlbH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVNlbGVjdEZpbHRlcn1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTFcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgoZykgPT4gKFxyXG4gICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Zy52YWx1ZX0gdmFsdWU9e2cudmFsdWV9PlxyXG4gICAgICAgICAgICAgICAge2cubGFiZWx9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRlJPTSBEQVRFICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPkZyb20gRGF0ZTwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRGcm9tRGF0ZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRGcm9tRGF0ZShlLnRhcmdldC52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRMYWJlbChcIkN1c3RvbVwiKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9eyFpc0N1c3RvbU1vZGV9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBoLTExIGJvcmRlciByb3VuZGVkLWxnIHB4LTMgJHtcclxuICAgICAgICAgICAgICAhaXNDdXN0b21Nb2RlID8gXCJiZy1ncmF5LTEwMFwiIDogXCJib3JkZXItZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICB9YH1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBUTyBEQVRFICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPlRvIERhdGU8L2xhYmVsPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgICAgICBzZXRTZWxlY3RlZExhYmVsKFwiQ3VzdG9tXCIpO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17IWlzQ3VzdG9tTW9kZX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGgtMTEgYm9yZGVyIHJvdW5kZWQtbGcgcHgtMyAke1xyXG4gICAgICAgICAgICAgICFpc0N1c3RvbU1vZGUgPyBcImJnLWdyYXktMTAwXCIgOiBcImJvcmRlci1ncmF5LTMwMFwiXHJcbiAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIENVU1RPTUVSIFJFRkVSUkVEIEJZICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPkN1c3RvbWVyIFJlZmVycmVkIEJ5PC9sYWJlbD5cclxuICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICB2YWx1ZT17Y3VzdG9tZXJSZWZlcnJlZEJ5fVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KHYpID0+IHNldEN1c3RvbWVyUmVmZXJyZWRCeSh2IHx8IFwiXCIpfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMVwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIHZhbHVlPVwiXCI+QWxsPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICB7Y3VzdG9tZXJzLm1hcCgoYykgPT4gKFxyXG4gICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Yy5faWR9IHZhbHVlPXtgQ1VTXyR7Yy5faWR9YH0+XHJcbiAgICAgICAgICAgICAgICB7Yy5mdWxsX25hbWV9IHwge2MucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogU0VDT05EIFJPVyBGSUxURVJTICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTQgZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgIHsvKiBFTVBMT1lFRSBSRUZFUlJFRCBCWSAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW1cIj5FbXBsb3llZSBSZWZlcnJlZCBCeTwvbGFiZWw+XHJcbiAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgdmFsdWU9e2VtcGxveWVlUmVmZXJyZWRCeX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyh2KSA9PiBzZXRFbXBsb3llZVJlZmVycmVkQnkodiB8fCBcIlwiKX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTFcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIlwiPkFsbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGUpID0+IChcclxuICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2UuX2lkfSB2YWx1ZT17YEVNUF8ke2UuX2lkfWB9PlxyXG4gICAgICAgICAgICAgICAge2UuZnVsbF9uYW1lIHx8IGUubmFtZX0gfCB7ZS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBTVU1NQVJZICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXZpb2xldC01MCBib3JkZXIgYm9yZGVyLXZpb2xldC0yMDAgcm91bmRlZC1sZyBwLTQgbWItNFwiPlxyXG5cclxuICAgICAgICB7LyogVE9QIFNVTU1BUlkgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC00IG1iLTRcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+VG90YWwgTm9uLUNvbnZlcnRlZCBMZWFkczwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC12aW9sZXQtNzAwXCI+e2xlYWRUYWJsZURhdGEubGVuZ3RofTwvcD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+UmVmZXJyZWQgYnkgQ3VzdG9tZXI8L3A+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JlZW4tNzAwXCI+XHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgbGVhZFRhYmxlRGF0YS5maWx0ZXIoKGwpID0+XHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVycy5zb21lKFxyXG4gICAgICAgICAgICAgICAgICAgIChjKSA9PiBgJHtjLmZ1bGxfbmFtZX0gfCAke2MucGhvbmVfbnVtYmVyfWAgPT09IGwucmVmZXJyZWRCeVxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICApLmxlbmd0aFxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5SZWZlcnJlZCBieSBFbXBsb3llZTwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1wdXJwbGUtNzAwXCI+XHJcbiAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgbGVhZFRhYmxlRGF0YS5maWx0ZXIoKGwpID0+XHJcbiAgICAgICAgICAgICAgICAgIGVtcGxveWVlcy5zb21lKFxyXG4gICAgICAgICAgICAgICAgICAgIChlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgYCR7ZS5mdWxsX25hbWUgfHwgZS5uYW1lfSB8ICR7ZS5waG9uZV9udW1iZXJ9YCA9PT0gbC5yZWZlcnJlZEJ5XHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICkubGVuZ3RoXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlJlZmVycmVkIGJ5IEFnZW50PC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS03MDBcIj5cclxuICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBsZWFkVGFibGVEYXRhLmZpbHRlcigobCkgPT5cclxuICAgICAgICAgICAgICAgICAgYWdlbnRzLnNvbWUoXHJcbiAgICAgICAgICAgICAgICAgICAgKGEpID0+IGAke2EubmFtZX0gfCAke2EucGhvbmVfbnVtYmVyfWAgPT09IGwucmVmZXJyZWRCeVxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICApLmxlbmd0aFxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBERVRBSUxFRCBCUkVBS0RPV04gKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTQgcm91bmRlZC1sZyBib3JkZXJcIj5cclxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMlwiPlJlZmVycmVyIEJyZWFrZG93bjwvaDI+XHJcblxyXG4gICAgICAgICAge2xlYWRUYWJsZURhdGEubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIHRleHQtc21cIj5ObyBsZWFkcyBhdmFpbGFibGUuPC9wPlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxyXG4gICAgICAgICAgICAgIHtbLi4ubmV3IFNldChsZWFkVGFibGVEYXRhLm1hcCgobCkgPT4gbC5yZWZlcnJlZEJ5KSldLm1hcCgocmVmKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXJlZiB8fCByZWYgPT09IFwiTi9BXCIpIHJldHVybiBudWxsO1xyXG5cclxuICAgICAgICAgICAgICAgIGNvbnN0IGNvdW50ID0gbGVhZFRhYmxlRGF0YS5maWx0ZXIoKGwpID0+IGwucmVmZXJyZWRCeSA9PT0gcmVmKS5sZW5ndGg7XHJcblxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgPGxpIGtleT17cmVmfSBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBweS0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPntyZWZ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXZpb2xldC03MDBcIj57Y291bnR9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgPC91bD5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIFRBQkxFICovfVxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHNoYWRvdyByb3VuZGVkLWxnIHAtMyBtaW4taC1bMjAwcHhdXCI+XHJcbiAgICAgICAge2ZldGNoaW5nTGVhZHMgPyAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgcHktMTZcIj5cclxuICAgICAgICAgICAgPFNwaW4gLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGUgY29sdW1ucz17bGVhZENvbHVtbnN9IGRhdGE9e2xlYWRUYWJsZURhdGF9IGV4cG9ydGVkRmlsZU5hbWU9XCJOb24gQ29udmVydGVkIExlYWQuY3N2XCIgZXhwb3J0ZWRQZGZOYW1lPVwiTm9uIENvbnZlcnRlZCBMZWFkXCIvPlxyXG5cclxuICAgICAgICApfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTm9uQ29udmVydGVkTGVhZDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL05vbkNvbnZlcnRlZExlYWQuanN4In0=