import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CustomerVisitTrackerReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import {
  FaSearch,
  FaFilter,
  FaDownload,
  FaEye,
  FaCheckCircle,
  FaClock,
  FaTimesCircle,
  FaUserCheck,
  FaUserClock,
  FaUserTimes,
  FaUser,
  FaMapMarkerAlt,
  FaPhone,
  FaCalendarAlt,
  FaFileAlt,
  FaUserTie,
  FaTasks,
  FaClipboardCheck,
  FaSpinner
} from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { message, DatePicker, Select, Tag, Modal, Spin } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import __vite__cjsImport8_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport8_dayjs.__esModule ? __vite__cjsImport8_dayjs.default : __vite__cjsImport8_dayjs;
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=819e0a34";
const { RangePicker } = DatePicker;
const { Option } = Select;
function CustomerVisitTrackerReport() {
  _s();
  const [loading, setLoading] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [filteredTasks, setFilteredTasks] = useState([]);
  const [agents, setAgents] = useState([]);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [dateRange, setDateRange] = useState(null);
  const [statusFilter, setStatusFilter] = useState("All");
  const [summary, setSummary] = useState({
    total: 0,
    pending: 0,
    inProgress: 0,
    completed: 0,
    visited: 0,
    notAvailable: 0,
    rejected: 0
  });
  const [selectedTask, setSelectedTask] = useState(null);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const fetchAgents = useCallback(async () => {
    try {
      const response = await api.get("/agent/get-agent");
      const agentData = response?.data?.data || response?.data || [];
      const verifiedAgents = Array.isArray(agentData) ? agentData.filter((agent) => agent?.isVerified === true) : [];
      setAgents(verifiedAgents);
    } catch (error) {
      console.error("Error fetching agents:", error);
      message.error("Failed to fetch agents");
      setAgents([]);
    }
  }, []);
  const fetchTasks = useCallback(async () => {
    setLoading(true);
    try {
      let url = "/v1/mobile/feildvisittracker/assigned-customer";
      if (selectedAgent) {
        url = `/v1/mobile/feildvisittracker/assigned-customer/${selectedAgent}`;
      }
      const response = await api.get(url);
      let taskData = response?.data?.data || [];
      if (dateRange && dateRange[0] && dateRange[1]) {
        const startDate = dayjs(dateRange[0]).startOf("day");
        const endDate = dayjs(dateRange[1]).endOf("day");
        taskData = taskData.filter((task) => {
          const createdAt = dayjs(task.createdAt);
          return createdAt.isBetween(startDate, endDate, null, "[]");
        });
      }
      if (statusFilter !== "All") {
        taskData = taskData.filter((task) => {
          if (statusFilter === "Visited") {
            return task.status === "Completed" && task.approval_status === "Approved";
          }
          if (statusFilter === "Not Available") {
            return task.status === "Rejected" || task.agent_response === "Rejected";
          }
          if (statusFilter === "Accepted") {
            return task.agent_response === "Accepted";
          }
          return task.status === statusFilter || task.agent_response === statusFilter;
        });
      }
      setTasks(taskData);
      setFilteredTasks(taskData);
      calculateSummary(taskData);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      message.error("Failed to fetch tasks");
      setTasks([]);
      setFilteredTasks([]);
    } finally {
      setLoading(false);
    }
  }, [selectedAgent, dateRange, statusFilter]);
  const calculateSummary = (data) => {
    const summaryData = {
      total: data.length,
      // Pending: tasks with no response or explicitly pending, and not in progress/completed/rejected
      pending: data.filter((t) => {
        const status = t.status;
        const response = t.agent_response;
        if (status === "In Progress" || status === "Completed" || status === "Rejected") {
          return false;
        }
        return !response || response === "Pending";
      }).length,
      inProgress: data.filter((t) => t.status === "In Progress").length,
      completed: data.filter((t) => t.status === "Completed").length,
      visited: data.filter((t) => t.status === "Completed" && t.approval_status === "Approved").length,
      notAvailable: data.filter((t) => t.status === "Rejected" || t.agent_response === "Rejected").length,
      rejected: data.filter((t) => t.agent_response === "Rejected").length
    };
    setSummary(summaryData);
  };
  useEffect(() => {
    fetchAgents();
  }, [fetchAgents]);
  useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);
  const viewTaskDetails = (task) => {
    setSelectedTask(task);
    setIsModalVisible(true);
  };
  const getStatusColor = (status, agentResponse) => {
    if (status === "Completed" && agentResponse === "Accepted") return "green";
    if (status === "Completed") return "green";
    if (status === "In Progress") return "blue";
    if (status === "Rejected" || agentResponse === "Rejected") return "red";
    if (status === "Pending" || !agentResponse) return "orange";
    if (agentResponse === "Accepted") return "cyan";
    return "default";
  };
  const getStatusText = (task) => {
    if (task.status === "Completed" && task.approval_status === "Approved") return "Visited";
    if (task.status === "Completed") return "Completed";
    if (task.status === "In Progress") return "In Progress";
    if (task.status === "Rejected") return "Not Available";
    if (task.agent_response === "Accepted") return "Accepted";
    if (task.agent_response === "Rejected") return "Rejected";
    return "Pending";
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "task_code", header: "Task Code" },
    { key: "customer_name", header: "Customer" },
    { key: "phone_number", header: "Phone" },
    { key: "assigned_to", header: "Assigned To" },
    { key: "status", header: "Status" },
    { key: "createdAt", header: "Created Date" },
    { key: "actions", header: "Actions" }
  ];
  const tableData = filteredTasks.map((task, index) => {
    const status = getStatusText(task);
    return {
      id: index + 1,
      task_code: task.task_code || "-",
      customer_name: task.customer?.full_name || "-",
      phone_number: task.customer?.phone_number || "-",
      assigned_to: task.assignedTo?.name || "-",
      status: /* @__PURE__ */ jsxDEV(
        Tag,
        {
          color: getStatusColor(task.status, task.agent_response),
          className: "px-3 py-1 font-medium",
          children: status
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
          lineNumber: 204,
          columnNumber: 7
        },
        this
      ),
      createdAt: task.createdAt ? dayjs(task.createdAt).format("DD/MM/YYYY HH:mm") : "-",
      actions: /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: () => viewTaskDetails(task),
          className: "text-blue-600 hover:text-blue-800 transition-all duration-200 hover:scale-110",
          children: /* @__PURE__ */ jsxDEV(FaEye, { size: 18 }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
            lineNumber: 219,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
          lineNumber: 215,
          columnNumber: 7
        },
        this
      ),
      _raw: task
    };
  });
  const StatusCard = ({ title, count, icon: Icon, borderColor, bgColor, subtext }) => /* @__PURE__ */ jsxDEV(
    motion.div,
    {
      whileHover: { scale: 1.02 },
      transition: { duration: 0.2 },
      className: `${bgColor} rounded-xl shadow-sm p-4 border-l-4 ${borderColor} hover:shadow-md transition-all duration-300`,
      children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { className: `${borderColor.replace("border-", "bg-").replace("-500", "-100")} p-3 rounded-full`, children: /* @__PURE__ */ jsxDEV(Icon, { className: `w-5 h-5 ${borderColor.replace("border-", "text-")}` }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
          lineNumber: 235,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
          lineNumber: 234,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-600", children: title }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
            lineNumber: 238,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-baseline gap-2", children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: count }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
              lineNumber: 240,
              columnNumber: 13
            }, this),
            subtext && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-400", children: subtext }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
              lineNumber: 242,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
            lineNumber: 239,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
          lineNumber: 237,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
        lineNumber: 233,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
      lineNumber: 228,
      columnNumber: 3
    },
    this
  );
  return /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen bg-gradient-to-br from-gray-50 to-gray-100", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1 flex flex-col", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
        lineNumber: 254,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "flex-1 overflow-auto p-4", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-8xl mx-auto", children: [
        /* @__PURE__ */ jsxDEV(
          motion.div,
          {
            initial: { opacity: 0, y: -20 },
            animate: { opacity: 1, y: 0 },
            transition: { duration: 0.5 },
            className: "flex flex-col md:flex-row justify-between items-start md:items-center mb-4 bg-white rounded-xl p-4 shadow-sm",
            children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-gray-800 flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(FaClipboardCheck, { className: "text-blue-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 266,
                    columnNumber: 19
                  }, this),
                  "Customer Visit Tracker Report"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 265,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Track and manage customer visit tasks efficiently" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 269,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 264,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mt-4 md:mt-0", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => {
                    setSelectedAgent(null);
                    setDateRange(null);
                    setStatusFilter("All");
                  },
                  className: "px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-all duration-200 flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxDEV(FaFilter, { size: 14 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 282,
                      columnNumber: 19
                    }, this),
                    "Clear Filters"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 274,
                  columnNumber: 17
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 273,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
            lineNumber: 258,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          motion.div,
          {
            initial: { opacity: 0, y: -10 },
            animate: { opacity: 1, y: 0 },
            transition: { duration: 0.4, delay: 0.1 },
            className: "bg-white rounded-xl shadow-sm p-4 mb-4 border border-gray-100",
            children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1.5", children: [
                  /* @__PURE__ */ jsxDEV(FaUserTie, { className: "inline mr-1.5 text-blue-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 298,
                    columnNumber: 21
                  }, this),
                  " Agent"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 297,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    placeholder: "Select Agent",
                    className: "w-full",
                    allowClear: true,
                    value: selectedAgent,
                    onChange: setSelectedAgent,
                    showSearch: true,
                    optionFilterProp: "label",
                    size: "middle",
                    children: agents.map(
                      (agent) => /* @__PURE__ */ jsxDEV(
                        Option,
                        {
                          value: agent._id,
                          label: `${agent.name} ${agent.phone_number}`,
                          children: [
                            agent.name,
                            " (",
                            agent.phone_number,
                            ")"
                          ]
                        },
                        agent._id,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                          lineNumber: 311,
                          columnNumber: 21
                        },
                        this
                      )
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 300,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 296,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1.5", children: [
                  /* @__PURE__ */ jsxDEV(FaCalendarAlt, { className: "inline mr-1.5 text-purple-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 324,
                    columnNumber: 21
                  }, this),
                  " Date Range"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 323,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  RangePicker,
                  {
                    className: "w-full",
                    value: dateRange,
                    onChange: setDateRange,
                    format: "DD/MM/YYYY",
                    placeholder: ["Start Date", "End Date"],
                    size: "middle"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 326,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 322,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1.5", children: [
                  /* @__PURE__ */ jsxDEV(FaFilter, { className: "inline mr-1.5 text-orange-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 338,
                    columnNumber: 21
                  }, this),
                  " Status"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 337,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    placeholder: "Filter by Status",
                    className: "w-full",
                    value: statusFilter,
                    onChange: setStatusFilter,
                    size: "middle",
                    children: [
                      /* @__PURE__ */ jsxDEV(Option, { value: "All", children: "All Status" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 347,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Option, { value: "Pending", children: "Pending" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 348,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Option, { value: "Accepted", children: "Accepted" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 349,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Option, { value: "In Progress", children: "In Progress" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 350,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Option, { value: "Completed", children: "Completed" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 351,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Option, { value: "Visited", children: "Visited" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 352,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Option, { value: "Not Available", children: "Not Available" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 353,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV(Option, { value: "Rejected", children: "Rejected" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 354,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 340,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 336,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-end", children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: fetchTasks,
                  className: "w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all duration-200 flex items-center justify-center gap-2 shadow-md hover:shadow-lg",
                  children: [
                    /* @__PURE__ */ jsxDEV(FaSearch, { size: 14 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 363,
                      columnNumber: 21
                    }, this),
                    "Apply Filters"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 359,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 358,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
              lineNumber: 295,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
            lineNumber: 289,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          motion.div,
          {
            initial: { opacity: 0 },
            animate: { opacity: 1 },
            transition: { duration: 0.4, delay: 0.2 },
            className: "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-3 mb-4",
            children: [
              /* @__PURE__ */ jsxDEV(
                StatusCard,
                {
                  title: "Total Tasks",
                  count: summary.total,
                  icon: FaTasks,
                  borderColor: "border-gray-500",
                  bgColor: "bg-white",
                  subtext: "All tasks"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 377,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                StatusCard,
                {
                  title: "Pending",
                  count: summary.pending,
                  icon: FaClock,
                  borderColor: "border-orange-500",
                  bgColor: "bg-white",
                  subtext: "Awaiting action"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 385,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                StatusCard,
                {
                  title: "In Progress",
                  count: summary.inProgress,
                  icon: FaSpinner,
                  borderColor: "border-blue-500",
                  bgColor: "bg-white",
                  subtext: "Being worked on"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 393,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                StatusCard,
                {
                  title: "Completed",
                  count: summary.completed,
                  icon: FaCheckCircle,
                  borderColor: "border-green-500",
                  bgColor: "bg-white",
                  subtext: "Finished tasks"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 401,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                StatusCard,
                {
                  title: "Visited",
                  count: summary.visited,
                  icon: FaUserCheck,
                  borderColor: "border-teal-500",
                  bgColor: "bg-white",
                  subtext: "Approved visits"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 409,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                StatusCard,
                {
                  title: "Not Available",
                  count: summary.notAvailable,
                  icon: FaUserTimes,
                  borderColor: "border-red-500",
                  bgColor: "bg-white",
                  subtext: "Unavailable"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 417,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                StatusCard,
                {
                  title: "Rejected",
                  count: summary.rejected,
                  icon: FaTimesCircle,
                  borderColor: "border-rose-500",
                  bgColor: "bg-white",
                  subtext: "Rejected tasks"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 425,
                  columnNumber: 15
                },
                this
              )
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
            lineNumber: 371,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          motion.div,
          {
            initial: { opacity: 0, y: 20 },
            animate: { opacity: 1, y: 0 },
            transition: { duration: 0.4, delay: 0.3 },
            className: "bg-white rounded-xl shadow-sm p-4 border border-gray-100",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-semibold text-gray-800 flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(FaTasks, { className: "text-blue-500" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 444,
                    columnNumber: 19
                  }, this),
                  "Task Details"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 443,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 text-blue-600 px-3 py-1 rounded-full text-sm font-medium", children: [
                  filteredTasks.length,
                  " Tasks"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 448,
                  columnNumber: 19
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 447,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 442,
                columnNumber: 15
              }, this),
              loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col justify-center items-center py-12", children: [
                /* @__PURE__ */ jsxDEV(Spin, { size: "large" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 456,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "mt-4 text-gray-500", children: "Loading tasks..." }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 457,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 455,
                columnNumber: 15
              }, this) : filteredTasks.length > 0 ? /* @__PURE__ */ jsxDEV(
                DataTable,
                {
                  data: tableData,
                  columns,
                  exportedFileName: "Customer_Visit_Tracker_Report.csv",
                  exportedPdfName: "Customer_Visit_Tracker_Report.pdf"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 460,
                  columnNumber: 15
                },
                this
              ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
                /* @__PURE__ */ jsxDEV(FaFileAlt, { className: "text-4xl text-gray-300 mx-auto mb-3" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 468,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500 font-medium", children: "No tasks found" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 469,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400", children: "Try adjusting your filters to see more results" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 470,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 467,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
            lineNumber: 436,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
        lineNumber: 256,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
        lineNumber: 255,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
      lineNumber: 253,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 text-lg font-semibold", children: [
          /* @__PURE__ */ jsxDEV(FaClipboardCheck, { className: "text-blue-600" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
            lineNumber: 484,
            columnNumber: 13
          }, this),
          "Task Details"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
          lineNumber: 483,
          columnNumber: 9
        }, this),
        open: isModalVisible,
        onCancel: () => setIsModalVisible(false),
        footer: null,
        width: 900,
        className: "task-details-modal",
        bodyStyle: { padding: "24px" },
        children: selectedTask && /* @__PURE__ */ jsxDEV(
          motion.div,
          {
            initial: { opacity: 0 },
            animate: { opacity: 1 },
            transition: { duration: 0.3 },
            className: "space-y-6",
            children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start border-b pb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-800", children: selectedTask.taskTitle || "Customer Visit Task" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 505,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Task Code:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 509,
                      columnNumber: 19
                    }, this),
                    " ",
                    selectedTask.task_code || "-"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 508,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 504,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Tag,
                  {
                    color: getStatusColor(
                      selectedTask.status,
                      selectedTask.agent_response
                    ),
                    className: "text-sm px-3 py-1 font-medium",
                    children: getStatusText(selectedTask)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 512,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 503,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200", children: [
                  /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-700 mb-3 flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV(FaUser, { className: "text-blue-600" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 527,
                      columnNumber: 19
                    }, this),
                    " Customer Details"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 526,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-600", children: "Name:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 531,
                        columnNumber: 21
                      }, this),
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: selectedTask.customer?.full_name || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 532,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 530,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-600", children: "Phone:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 535,
                        columnNumber: 21
                      }, this),
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: selectedTask.customer?.phone_number || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 536,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 534,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-600", children: "Email:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 539,
                        columnNumber: 21
                      }, this),
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: selectedTask.customer?.email || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 540,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 538,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-600", children: "Address:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 543,
                        columnNumber: 21
                      }, this),
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: selectedTask.customer?.address || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 544,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 542,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 529,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 525,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4 border border-green-200", children: [
                  /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-700 mb-3 flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV(FaUserTie, { className: "text-green-600" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 551,
                      columnNumber: 19
                    }, this),
                    " Agent Details"
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 550,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-600", children: "Assigned To:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 555,
                        columnNumber: 21
                      }, this),
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: selectedTask.assignedTo?.name || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 556,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 554,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-600", children: "Phone:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 559,
                        columnNumber: 21
                      }, this),
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: selectedTask.assignedTo?.phone_number || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 560,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 558,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-600", children: "Email:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 563,
                        columnNumber: 21
                      }, this),
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: selectedTask.assignedTo?.email || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 564,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 562,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-600", children: "Assigned By:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 567,
                        columnNumber: 21
                      }, this),
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: selectedTask.assignedBy?.name || "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 568,
                        columnNumber: 21
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 566,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 553,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 549,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 524,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-4 border border-gray-200", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-700 mb-3 flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(FaFileAlt, { className: "text-purple-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 577,
                    columnNumber: 17
                  }, this),
                  " Task Information"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 576,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-3", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded p-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Status" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 581,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Tag, { color: getStatusColor(selectedTask.status, selectedTask.agent_response), className: "mt-1", children: getStatusText(selectedTask) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 582,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 580,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded p-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Approval Status" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 587,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV(Tag, { color: selectedTask.approval_status === "Approved" ? "green" : "orange", className: "mt-1", children: selectedTask.approval_status || "Pending" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 588,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 586,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded p-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Created" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 593,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-800", children: selectedTask.createdAt ? dayjs(selectedTask.createdAt).format("DD/MM/YYYY HH:mm") : "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 594,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 592,
                    columnNumber: 17
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded p-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Completed" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 601,
                      columnNumber: 19
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-800", children: selectedTask.completed_at ? dayjs(selectedTask.completed_at).format("DD/MM/YYYY HH:mm") : "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 602,
                      columnNumber: 19
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 600,
                    columnNumber: 17
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 579,
                  columnNumber: 15
                }, this),
                selectedTask.taskDescription && /* @__PURE__ */ jsxDEV("div", { className: "mt-3 bg-white rounded p-3", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mb-1", children: "Description" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 611,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-700", children: selectedTask.taskDescription }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 612,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 610,
                  columnNumber: 13
                }, this),
                selectedTask.agent_response_note && /* @__PURE__ */ jsxDEV("div", { className: "mt-2 bg-white rounded p-3", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mb-1", children: "Agent Note" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 617,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-700", children: selectedTask.agent_response_note }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 618,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 616,
                  columnNumber: 13
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 575,
                columnNumber: 13
              }, this),
              selectedTask.completion_details?.gps_location && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4 border border-purple-200", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-700 mb-3 flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(FaMapMarkerAlt, { className: "text-purple-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 627,
                    columnNumber: 19
                  }, this),
                  " Location Details"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 626,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded p-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Latitude" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 631,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-800", children: selectedTask.completion_details.gps_location.latitude || "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 632,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 630,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded p-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Longitude" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 637,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-800", children: selectedTask.completion_details.gps_location.longitude || "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 638,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 636,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded p-2 col-span-2", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Address" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 643,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-800", children: selectedTask.completion_details.gps_location.address || "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 644,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 642,
                    columnNumber: 19
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 629,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 625,
                columnNumber: 11
              }, this),
              selectedTask.history && selectedTask.history.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-4 border border-gray-200", children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "font-semibold text-gray-700 mb-3 flex items-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV(FaClock, { className: "text-blue-600" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 656,
                    columnNumber: 19
                  }, this),
                  " Activity History"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 655,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 max-h-48 overflow-y-auto pr-2", children: selectedTask.history.map(
                  (entry, index) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3 text-sm bg-white rounded p-3 border border-gray-100", children: [
                    /* @__PURE__ */ jsxDEV(Tag, { color: "blue", className: "mt-0.5", children: entry.status }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 661,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-gray-700", children: entry.note }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 663,
                        columnNumber: 25
                      }, this),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-400 mt-1", children: entry.changedAt ? dayjs(entry.changedAt).format("DD/MM/YYYY HH:mm") : "-" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                        lineNumber: 664,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                      lineNumber: 662,
                      columnNumber: 23
                    }, this)
                  ] }, index, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                    lineNumber: 660,
                    columnNumber: 15
                  }, this)
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                  lineNumber: 658,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
                lineNumber: 654,
                columnNumber: 11
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
            lineNumber: 496,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
        lineNumber: 481,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx",
    lineNumber: 251,
    columnNumber: 5
  }, this);
}
_s(CustomerVisitTrackerReport, "v+TOx4Rsxs9BFgmz6USwAZuYNS0=");
_c = CustomerVisitTrackerReport;
export default CustomerVisitTrackerReport;
var _c;
$RefreshReg$(_c, "CustomerVisitTrackerReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerVisitTrackerReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMk1ROzJCQTNNUjtBQUFnQkEsTUFBVUMsY0FBV0MsT0FBVyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMvRCxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGFBQWE7QUFDcEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsU0FBU0MsWUFBWUMsUUFBUUMsS0FBS0MsT0FBT0MsWUFBWTtBQUM5RCxPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxjQUFjO0FBRXZCLE1BQU0sRUFBRUMsWUFBWSxJQUFJVDtBQUN4QixNQUFNLEVBQUVVLE9BQU8sSUFBSVQ7QUFFbkIsU0FBU1UsNkJBQTZCO0FBQUFDLEtBQUE7QUFDcEMsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUl2QyxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDd0MsT0FBT0MsUUFBUSxJQUFJekMsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzBDLGVBQWVDLGdCQUFnQixJQUFJM0MsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQzRDLFFBQVFDLFNBQVMsSUFBSTdDLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUM4QyxlQUFlQyxnQkFBZ0IsSUFBSS9DLFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUNnRCxXQUFXQyxZQUFZLElBQUlqRCxTQUFTLElBQUk7QUFDL0MsUUFBTSxDQUFDa0QsY0FBY0MsZUFBZSxJQUFJbkQsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ29ELFNBQVNDLFVBQVUsSUFBSXJELFNBQVM7QUFBQSxJQUNyQ3NELE9BQU87QUFBQSxJQUNQQyxTQUFTO0FBQUEsSUFDVEMsWUFBWTtBQUFBLElBQ1pDLFdBQVc7QUFBQSxJQUNYQyxTQUFTO0FBQUEsSUFDVEMsY0FBYztBQUFBLElBQ2RDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCxRQUFNLENBQUNDLGNBQWNDLGVBQWUsSUFBSTlELFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUMrRCxnQkFBZ0JDLGlCQUFpQixJQUFJaEUsU0FBUyxLQUFLO0FBRzFELFFBQU1pRSxjQUFjL0QsWUFBWSxZQUFZO0FBQzFDLFFBQUk7QUFDRixZQUFNZ0UsV0FBVyxNQUFNbkMsSUFBSW9DLElBQUksa0JBQWtCO0FBRWpELFlBQU1DLFlBQVlGLFVBQVVHLE1BQU1BLFFBQVFILFVBQVVHLFFBQVE7QUFDNUQsWUFBTUMsaUJBQWlCQyxNQUFNQyxRQUFRSixTQUFTLElBQzFDQSxVQUFVSyxPQUFPLENBQUNDLFVBQVVBLE9BQU9DLGVBQWUsSUFBSSxJQUN0RDtBQUNKOUIsZ0JBQVV5QixjQUFjO0FBQUEsSUFDMUIsU0FBU00sT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUM3Q3BELGNBQVFvRCxNQUFNLHdCQUF3QjtBQUN0Qy9CLGdCQUFVLEVBQUU7QUFBQSxJQUNkO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFHTCxRQUFNaUMsYUFBYTVFLFlBQVksWUFBWTtBQUN6Q3FDLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixVQUFJd0MsTUFBTTtBQUVWLFVBQUlqQyxlQUFlO0FBQ2pCaUMsY0FBTSxrREFBa0RqQyxhQUFhO0FBQUEsTUFDdkU7QUFFQSxZQUFNb0IsV0FBVyxNQUFNbkMsSUFBSW9DLElBQUlZLEdBQUc7QUFDbEMsVUFBSUMsV0FBV2QsVUFBVUcsTUFBTUEsUUFBUTtBQUd2QyxVQUFJckIsYUFBYUEsVUFBVSxDQUFDLEtBQUtBLFVBQVUsQ0FBQyxHQUFHO0FBQzdDLGNBQU1pQyxZQUFZbkQsTUFBTWtCLFVBQVUsQ0FBQyxDQUFDLEVBQUVrQyxRQUFRLEtBQUs7QUFDbkQsY0FBTUMsVUFBVXJELE1BQU1rQixVQUFVLENBQUMsQ0FBQyxFQUFFb0MsTUFBTSxLQUFLO0FBQy9DSixtQkFBV0EsU0FBU1AsT0FBTyxDQUFBWSxTQUFRO0FBQ2pDLGdCQUFNQyxZQUFZeEQsTUFBTXVELEtBQUtDLFNBQVM7QUFDdEMsaUJBQU9BLFVBQVVDLFVBQVVOLFdBQVdFLFNBQVMsTUFBTSxJQUFJO0FBQUEsUUFDM0QsQ0FBQztBQUFBLE1BQ0g7QUFHQSxVQUFJakMsaUJBQWlCLE9BQU87QUFDMUI4QixtQkFBV0EsU0FBU1AsT0FBTyxDQUFBWSxTQUFRO0FBQ2pDLGNBQUluQyxpQkFBaUIsV0FBVztBQUM5QixtQkFBT21DLEtBQUtHLFdBQVcsZUFBZUgsS0FBS0ksb0JBQW9CO0FBQUEsVUFDakU7QUFDQSxjQUFJdkMsaUJBQWlCLGlCQUFpQjtBQUNwQyxtQkFBT21DLEtBQUtHLFdBQVcsY0FBY0gsS0FBS0ssbUJBQW1CO0FBQUEsVUFDL0Q7QUFDQSxjQUFJeEMsaUJBQWlCLFlBQVk7QUFDL0IsbUJBQU9tQyxLQUFLSyxtQkFBbUI7QUFBQSxVQUNqQztBQUNBLGlCQUFPTCxLQUFLRyxXQUFXdEMsZ0JBQWdCbUMsS0FBS0ssbUJBQW1CeEM7QUFBQUEsUUFDakUsQ0FBQztBQUFBLE1BQ0g7QUFFQVQsZUFBU3VDLFFBQVE7QUFDakJyQyx1QkFBaUJxQyxRQUFRO0FBQ3pCVyx1QkFBaUJYLFFBQVE7QUFBQSxJQUMzQixTQUFTSixPQUFPO0FBQ2RDLGNBQVFELE1BQU0seUJBQXlCQSxLQUFLO0FBQzVDcEQsY0FBUW9ELE1BQU0sdUJBQXVCO0FBQ3JDbkMsZUFBUyxFQUFFO0FBQ1hFLHVCQUFpQixFQUFFO0FBQUEsSUFDckIsVUFBQztBQUNDSixpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGLEdBQUcsQ0FBQ08sZUFBZUUsV0FBV0UsWUFBWSxDQUFDO0FBRzNDLFFBQU15QyxtQkFBbUJBLENBQUN0QixTQUFTO0FBQ2pDLFVBQU11QixjQUFjO0FBQUEsTUFDbEJ0QyxPQUFPZSxLQUFLd0I7QUFBQUE7QUFBQUEsTUFFWnRDLFNBQVNjLEtBQUtJLE9BQU8sQ0FBQXFCLE1BQUs7QUFDeEIsY0FBTU4sU0FBU00sRUFBRU47QUFDakIsY0FBTXRCLFdBQVc0QixFQUFFSjtBQUVuQixZQUFJRixXQUFXLGlCQUFpQkEsV0FBVyxlQUFlQSxXQUFXLFlBQVk7QUFDL0UsaUJBQU87QUFBQSxRQUNUO0FBRUEsZUFBTyxDQUFDdEIsWUFBWUEsYUFBYTtBQUFBLE1BQ25DLENBQUMsRUFBRTJCO0FBQUFBLE1BQ0hyQyxZQUFZYSxLQUFLSSxPQUFPLENBQUFxQixNQUFLQSxFQUFFTixXQUFXLGFBQWEsRUFBRUs7QUFBQUEsTUFDekRwQyxXQUFXWSxLQUFLSSxPQUFPLENBQUFxQixNQUFLQSxFQUFFTixXQUFXLFdBQVcsRUFBRUs7QUFBQUEsTUFDdERuQyxTQUFTVyxLQUFLSSxPQUFPLENBQUFxQixNQUFLQSxFQUFFTixXQUFXLGVBQWVNLEVBQUVMLG9CQUFvQixVQUFVLEVBQUVJO0FBQUFBLE1BQ3hGbEMsY0FBY1UsS0FBS0ksT0FBTyxDQUFBcUIsTUFBS0EsRUFBRU4sV0FBVyxjQUFjTSxFQUFFSixtQkFBbUIsVUFBVSxFQUFFRztBQUFBQSxNQUMzRmpDLFVBQVVTLEtBQUtJLE9BQU8sQ0FBQXFCLE1BQUtBLEVBQUVKLG1CQUFtQixVQUFVLEVBQUVHO0FBQUFBLElBQzlEO0FBQ0F4QyxlQUFXdUMsV0FBVztBQUFBLEVBQ3hCO0FBRUEzRixZQUFVLE1BQU07QUFDZGdFLGdCQUFZO0FBQUEsRUFDZCxHQUFHLENBQUNBLFdBQVcsQ0FBQztBQUVoQmhFLFlBQVUsTUFBTTtBQUNkNkUsZUFBVztBQUFBLEVBQ2IsR0FBRyxDQUFDQSxVQUFVLENBQUM7QUFHZixRQUFNaUIsa0JBQWtCQSxDQUFDVixTQUFTO0FBQ2hDdkIsb0JBQWdCdUIsSUFBSTtBQUNwQnJCLHNCQUFrQixJQUFJO0FBQUEsRUFDeEI7QUFHQSxRQUFNZ0MsaUJBQWlCQSxDQUFDUixRQUFRUyxrQkFBa0I7QUFDaEQsUUFBSVQsV0FBVyxlQUFlUyxrQkFBa0IsV0FBWSxRQUFPO0FBQ25FLFFBQUlULFdBQVcsWUFBYSxRQUFPO0FBQ25DLFFBQUlBLFdBQVcsY0FBZSxRQUFPO0FBQ3JDLFFBQUlBLFdBQVcsY0FBY1Msa0JBQWtCLFdBQVksUUFBTztBQUNsRSxRQUFJVCxXQUFXLGFBQWEsQ0FBQ1MsY0FBZSxRQUFPO0FBQ25ELFFBQUlBLGtCQUFrQixXQUFZLFFBQU87QUFDekMsV0FBTztBQUFBLEVBQ1Q7QUFFQSxRQUFNQyxnQkFBZ0JBLENBQUNiLFNBQVM7QUFDOUIsUUFBSUEsS0FBS0csV0FBVyxlQUFlSCxLQUFLSSxvQkFBb0IsV0FBWSxRQUFPO0FBQy9FLFFBQUlKLEtBQUtHLFdBQVcsWUFBYSxRQUFPO0FBQ3hDLFFBQUlILEtBQUtHLFdBQVcsY0FBZSxRQUFPO0FBQzFDLFFBQUlILEtBQUtHLFdBQVcsV0FBWSxRQUFPO0FBQ3ZDLFFBQUlILEtBQUtLLG1CQUFtQixXQUFZLFFBQU87QUFDL0MsUUFBSUwsS0FBS0ssbUJBQW1CLFdBQVksUUFBTztBQUMvQyxXQUFPO0FBQUEsRUFDVDtBQUdBLFFBQU1TLFVBQVU7QUFBQSxJQUNkLEVBQUVDLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLFlBQVk7QUFBQSxJQUN4QyxFQUFFRCxLQUFLLGlCQUFpQkMsUUFBUSxXQUFXO0FBQUEsSUFDM0MsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsUUFBUTtBQUFBLElBQ3ZDLEVBQUVELEtBQUssZUFBZUMsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsZUFBZTtBQUFBLElBQzNDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsRUFBQztBQUl2QyxRQUFNQyxZQUFZNUQsY0FBYzZELElBQUksQ0FBQ2xCLE1BQU1tQixVQUFVO0FBQ25ELFVBQU1oQixTQUFTVSxjQUFjYixJQUFJO0FBQ2pDLFdBQU87QUFBQSxNQUNMb0IsSUFBSUQsUUFBUTtBQUFBLE1BQ1pFLFdBQVdyQixLQUFLcUIsYUFBYTtBQUFBLE1BQzdCQyxlQUFldEIsS0FBS3VCLFVBQVVDLGFBQWE7QUFBQSxNQUMzQ0MsY0FBY3pCLEtBQUt1QixVQUFVRSxnQkFBZ0I7QUFBQSxNQUM3Q0MsYUFBYTFCLEtBQUsyQixZQUFZQyxRQUFRO0FBQUEsTUFDdEN6QixRQUNFO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPUSxlQUFlWCxLQUFLRyxRQUFRSCxLQUFLSyxjQUFjO0FBQUEsVUFDdEQsV0FBVTtBQUFBLFVBRVRGO0FBQUFBO0FBQUFBLFFBSkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxNQUVGRixXQUFXRCxLQUFLQyxZQUNaeEQsTUFBTXVELEtBQUtDLFNBQVMsRUFBRTRCLE9BQU8sa0JBQWtCLElBQy9DO0FBQUEsTUFDSkMsU0FDRTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBUyxNQUFNcEIsZ0JBQWdCVixJQUFJO0FBQUEsVUFDbkMsV0FBVTtBQUFBLFVBRVYsaUNBQUMsU0FBTSxNQUFNLE1BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0I7QUFBQTtBQUFBLFFBSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsTUFFRitCLE1BQU0vQjtBQUFBQSxJQUNSO0FBQUEsRUFDRixDQUFDO0FBR0QsUUFBTWdDLGFBQWFBLENBQUMsRUFBRUMsT0FBT0MsT0FBT0MsTUFBTUMsTUFBTUMsYUFBYUMsU0FBU0MsUUFBUSxNQUM1RTtBQUFBLElBQUMsT0FBTztBQUFBLElBQVA7QUFBQSxNQUNDLFlBQVksRUFBRUMsT0FBTyxLQUFLO0FBQUEsTUFDMUIsWUFBWSxFQUFFQyxVQUFVLElBQUk7QUFBQSxNQUM1QixXQUFXLEdBQUdILE9BQU8sd0NBQXdDRCxXQUFXO0FBQUEsTUFFeEUsaUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFXLEdBQUdBLFlBQVlLLFFBQVEsV0FBVyxLQUFLLEVBQUVBLFFBQVEsUUFBUSxNQUFNLENBQUMscUJBQzlFLGlDQUFDLFFBQUssV0FBVyxXQUFXTCxZQUFZSyxRQUFRLFdBQVcsT0FBTyxDQUFDLE1BQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0UsS0FEeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLGlDQUFDLE9BQUUsV0FBVSxxQ0FBcUNULG1CQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF3RDtBQUFBLFVBQ3hELHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLG1DQUFDLE9BQUUsV0FBVSxvQ0FBb0NDLG1CQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1RDtBQUFBLFlBQ3RESyxXQUNDLHVCQUFDLFVBQUssV0FBVSx5QkFBeUJBLHFCQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRDtBQUFBLGVBSHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFdBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUE7QUFBQSxJQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFtQkE7QUFHRixTQUNFLHVCQUFDLFNBQUksV0FBVSxnRUFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDZCQUFDLFVBQU8sWUFBWSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsVUFBSyxXQUFVLDRCQUNkLGlDQUFDLFNBQUksV0FBVSxxQkFFYjtBQUFBO0FBQUEsVUFBQyxPQUFPO0FBQUEsVUFBUDtBQUFBLFlBQ0MsU0FBUyxFQUFFSSxTQUFTLEdBQUdDLEdBQUcsSUFBSTtBQUFBLFlBQzlCLFNBQVMsRUFBRUQsU0FBUyxHQUFHQyxHQUFHLEVBQUU7QUFBQSxZQUM1QixZQUFZLEVBQUVILFVBQVUsSUFBSTtBQUFBLFlBQzVCLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsU0FDQztBQUFBLHVDQUFDLFFBQUcsV0FBVSw0REFDWjtBQUFBLHlDQUFDLG9CQUFpQixXQUFVLG1CQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyQztBQUFBLGtCQUFHO0FBQUEscUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLGlFQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFRQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdDQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTTtBQUNiL0UscUNBQWlCLElBQUk7QUFDckJFLGlDQUFhLElBQUk7QUFDakJFLG9DQUFnQixLQUFLO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsWUFBUyxNQUFNLE1BQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1CO0FBQUEsb0JBQUc7QUFBQTtBQUFBO0FBQUEsZ0JBUnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBO0FBQUE7QUFBQSxVQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUE0QkE7QUFBQSxRQUdBO0FBQUEsVUFBQyxPQUFPO0FBQUEsVUFBUDtBQUFBLFlBQ0MsU0FBUyxFQUFFNkUsU0FBUyxHQUFHQyxHQUFHLElBQUk7QUFBQSxZQUM5QixTQUFTLEVBQUVELFNBQVMsR0FBR0MsR0FBRyxFQUFFO0FBQUEsWUFDNUIsWUFBWSxFQUFFSCxVQUFVLEtBQUtJLE9BQU8sSUFBSTtBQUFBLFlBQ3hDLFdBQVU7QUFBQSxZQUVWLGlDQUFDLFNBQUksV0FBVSx3REFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsa0RBQ2Y7QUFBQSx5Q0FBQyxhQUFVLFdBQVUsaUNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtEO0FBQUEsa0JBQUc7QUFBQSxxQkFEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLGFBQVk7QUFBQSxvQkFDWixXQUFVO0FBQUEsb0JBQ1Y7QUFBQSxvQkFDQSxPQUFPcEY7QUFBQUEsb0JBQ1AsVUFBVUM7QUFBQUEsb0JBQ1Y7QUFBQSxvQkFDQSxrQkFBaUI7QUFBQSxvQkFDakIsTUFBSztBQUFBLG9CQUVKSCxpQkFBTzJEO0FBQUFBLHNCQUFJLENBQUM3QixVQUNYO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUVDLE9BQU9BLE1BQU15RDtBQUFBQSwwQkFDYixPQUFPLEdBQUd6RCxNQUFNdUMsSUFBSSxJQUFJdkMsTUFBTW9DLFlBQVk7QUFBQSwwQkFFekNwQztBQUFBQSxrQ0FBTXVDO0FBQUFBLDRCQUFLO0FBQUEsNEJBQUd2QyxNQUFNb0M7QUFBQUEsNEJBQWE7QUFBQTtBQUFBO0FBQUEsd0JBSjdCcEMsTUFBTXlEO0FBQUFBLHdCQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTUE7QUFBQSxvQkFDRDtBQUFBO0FBQUEsa0JBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFtQkE7QUFBQSxtQkF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF3QkE7QUFBQSxjQUVBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsa0RBQ2Y7QUFBQSx5Q0FBQyxpQkFBYyxXQUFVLG1DQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF3RDtBQUFBLGtCQUFHO0FBQUEscUJBRDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBT25GO0FBQUFBLG9CQUNQLFVBQVVDO0FBQUFBLG9CQUNWLFFBQU87QUFBQSxvQkFDUCxhQUFhLENBQUMsY0FBYyxVQUFVO0FBQUEsb0JBQ3RDLE1BQUs7QUFBQTtBQUFBLGtCQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNZTtBQUFBLG1CQVZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVlBO0FBQUEsY0FFQSx1QkFBQyxTQUNDO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGtEQUNmO0FBQUEseUNBQUMsWUFBUyxXQUFVLG1DQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRDtBQUFBLGtCQUFHO0FBQUEscUJBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxhQUFZO0FBQUEsb0JBQ1osV0FBVTtBQUFBLG9CQUNWLE9BQU9DO0FBQUFBLG9CQUNQLFVBQVVDO0FBQUFBLG9CQUNWLE1BQUs7QUFBQSxvQkFFTDtBQUFBLDZDQUFDLFVBQU8sT0FBTSxPQUFNLDBCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUE4QjtBQUFBLHNCQUM5Qix1QkFBQyxVQUFPLE9BQU0sV0FBVSx1QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBK0I7QUFBQSxzQkFDL0IsdUJBQUMsVUFBTyxPQUFNLFlBQVcsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUEsc0JBQ2pDLHVCQUFDLFVBQU8sT0FBTSxlQUFjLDJCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF1QztBQUFBLHNCQUN2Qyx1QkFBQyxVQUFPLE9BQU0sYUFBWSx5QkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBbUM7QUFBQSxzQkFDbkMsdUJBQUMsVUFBTyxPQUFNLFdBQVUsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQStCO0FBQUEsc0JBQy9CLHVCQUFDLFVBQU8sT0FBTSxpQkFBZ0IsNkJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTJDO0FBQUEsc0JBQzNDLHVCQUFDLFVBQU8sT0FBTSxZQUFXLHdCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFkbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQWVBO0FBQUEsbUJBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0JBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUzJCO0FBQUFBLGtCQUNULFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFlBQVMsTUFBTSxNQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFtQjtBQUFBLG9CQUFHO0FBQUE7QUFBQTtBQUFBLGdCQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxpQkF2RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3RUE7QUFBQTtBQUFBLFVBOUVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQStFQTtBQUFBLFFBR0E7QUFBQSxVQUFDLE9BQU87QUFBQSxVQUFQO0FBQUEsWUFDQyxTQUFTLEVBQUVrRCxTQUFTLEVBQUU7QUFBQSxZQUN0QixTQUFTLEVBQUVBLFNBQVMsRUFBRTtBQUFBLFlBQ3RCLFlBQVksRUFBRUYsVUFBVSxLQUFLSSxPQUFPLElBQUk7QUFBQSxZQUN4QyxXQUFVO0FBQUEsWUFFVjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU07QUFBQSxrQkFDTixPQUFPOUUsUUFBUUU7QUFBQUEsa0JBQ2YsTUFBTWpDO0FBQUFBLGtCQUNOLGFBQVk7QUFBQSxrQkFDWixTQUFRO0FBQUEsa0JBQ1IsU0FBUTtBQUFBO0FBQUEsZ0JBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTXFCO0FBQUEsY0FFckI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTTtBQUFBLGtCQUNOLE9BQU8rQixRQUFRRztBQUFBQSxrQkFDZixNQUFNN0M7QUFBQUEsa0JBQ04sYUFBWTtBQUFBLGtCQUNaLFNBQVE7QUFBQSxrQkFDUixTQUFRO0FBQUE7QUFBQSxnQkFOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNMkI7QUFBQSxjQUUzQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFNO0FBQUEsa0JBQ04sT0FBTzBDLFFBQVFJO0FBQUFBLGtCQUNmLE1BQU1qQztBQUFBQSxrQkFDTixhQUFZO0FBQUEsa0JBQ1osU0FBUTtBQUFBLGtCQUNSLFNBQVE7QUFBQTtBQUFBLGdCQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU0yQjtBQUFBLGNBRTNCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU07QUFBQSxrQkFDTixPQUFPNkIsUUFBUUs7QUFBQUEsa0JBQ2YsTUFBTWhEO0FBQUFBLGtCQUNOLGFBQVk7QUFBQSxrQkFDWixTQUFRO0FBQUEsa0JBQ1IsU0FBUTtBQUFBO0FBQUEsZ0JBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTTBCO0FBQUEsY0FFMUI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTTtBQUFBLGtCQUNOLE9BQU8yQyxRQUFRTTtBQUFBQSxrQkFDZixNQUFNOUM7QUFBQUEsa0JBQ04sYUFBWTtBQUFBLGtCQUNaLFNBQVE7QUFBQSxrQkFDUixTQUFRO0FBQUE7QUFBQSxnQkFOVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNMkI7QUFBQSxjQUUzQjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFNO0FBQUEsa0JBQ04sT0FBT3dDLFFBQVFPO0FBQUFBLGtCQUNmLE1BQU03QztBQUFBQSxrQkFDTixhQUFZO0FBQUEsa0JBQ1osU0FBUTtBQUFBLGtCQUNSLFNBQVE7QUFBQTtBQUFBLGdCQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU11QjtBQUFBLGNBRXZCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU07QUFBQSxrQkFDTixPQUFPc0MsUUFBUVE7QUFBQUEsa0JBQ2YsTUFBTWpEO0FBQUFBLGtCQUNOLGFBQVk7QUFBQSxrQkFDWixTQUFRO0FBQUEsa0JBQ1IsU0FBUTtBQUFBO0FBQUEsZ0JBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTTBCO0FBQUE7QUFBQTtBQUFBLFVBNUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUE4REE7QUFBQSxRQUdBO0FBQUEsVUFBQyxPQUFPO0FBQUEsVUFBUDtBQUFBLFlBQ0MsU0FBUyxFQUFFcUgsU0FBUyxHQUFHQyxHQUFHLEdBQUc7QUFBQSxZQUM3QixTQUFTLEVBQUVELFNBQVMsR0FBR0MsR0FBRyxFQUFFO0FBQUEsWUFDNUIsWUFBWSxFQUFFSCxVQUFVLEtBQUtJLE9BQU8sSUFBSTtBQUFBLFlBQ3hDLFdBQVU7QUFBQSxZQUVWO0FBQUEscUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLCtEQUNaO0FBQUEseUNBQUMsV0FBUSxXQUFVLG1CQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrQztBQUFBLGtCQUFHO0FBQUEscUJBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2IsaUNBQUMsU0FBSSxXQUFVLHVFQUNaeEY7QUFBQUEsZ0NBQWNtRDtBQUFBQSxrQkFBTztBQUFBLHFCQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFJQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxjQUVDdkQsVUFDQyx1QkFBQyxTQUFJLFdBQVUsbURBQ2I7QUFBQSx1Q0FBQyxRQUFLLE1BQUssV0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrQjtBQUFBLGdCQUNsQix1QkFBQyxPQUFFLFdBQVUsc0JBQXFCLGdDQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRDtBQUFBLG1CQUZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBLElBQ0VJLGNBQWNtRCxTQUFTLElBQ3pCO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU1TO0FBQUFBLGtCQUNOO0FBQUEsa0JBQ0Esa0JBQWlCO0FBQUEsa0JBQ2pCLGlCQUFnQjtBQUFBO0FBQUEsZ0JBSmxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUlxRCxJQUdyRCx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSx1Q0FBQyxhQUFVLFdBQVUseUNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTBEO0FBQUEsZ0JBQzFELHVCQUFDLE9BQUUsV0FBVSw2QkFBNEIsOEJBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVEO0FBQUEsZ0JBQ3ZELHVCQUFDLE9BQUUsV0FBVSx5QkFBd0IsOERBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUE7QUFBQTtBQUFBLFVBckNKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXVDQTtBQUFBLFdBM05GO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0TkEsS0E3TkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThOQTtBQUFBLFNBaE9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpT0E7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUNFLHVCQUFDLFNBQUksV0FBVSxpREFDYjtBQUFBLGlDQUFDLG9CQUFpQixXQUFVLG1CQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyQztBQUFBLFVBQUc7QUFBQSxhQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVGLE1BQU12QztBQUFBQSxRQUNOLFVBQVUsTUFBTUMsa0JBQWtCLEtBQUs7QUFBQSxRQUN2QyxRQUFRO0FBQUEsUUFDUixPQUFPO0FBQUEsUUFDUCxXQUFVO0FBQUEsUUFDVixXQUFXLEVBQUVvRSxTQUFTLE9BQU87QUFBQSxRQUU1QnZFLDBCQUNDO0FBQUEsVUFBQyxPQUFPO0FBQUEsVUFBUDtBQUFBLFlBQ0MsU0FBUyxFQUFFbUUsU0FBUyxFQUFFO0FBQUEsWUFDdEIsU0FBUyxFQUFFQSxTQUFTLEVBQUU7QUFBQSxZQUN0QixZQUFZLEVBQUVGLFVBQVUsSUFBSTtBQUFBLFlBQzVCLFdBQVU7QUFBQSxZQUdWO0FBQUEscUNBQUMsU0FBSSxXQUFVLGtEQUNiO0FBQUEsdUNBQUMsU0FDQztBQUFBLHlDQUFDLFFBQUcsV0FBVSx1Q0FDWGpFLHVCQUFhd0UsYUFBYSx5QkFEN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFDWDtBQUFBLDJDQUFDLFVBQUssV0FBVSxlQUFjLDBCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUF3QztBQUFBLG9CQUFPO0FBQUEsb0JBQUV4RSxhQUFhNkMsYUFBYTtBQUFBLHVCQUQ3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFPQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE9BQU9WO0FBQUFBLHNCQUNMbkMsYUFBYTJCO0FBQUFBLHNCQUNiM0IsYUFBYTZCO0FBQUFBLG9CQUNmO0FBQUEsb0JBQ0EsV0FBVTtBQUFBLG9CQUVUUSx3QkFBY3JDLFlBQVk7QUFBQTtBQUFBLGtCQVA3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUE7QUFBQSxtQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQkE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxvRkFDYjtBQUFBLHlDQUFDLFFBQUcsV0FBVSw0REFDWjtBQUFBLDJDQUFDLFVBQU8sV0FBVSxtQkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQSxvQkFBRztBQUFBLHVCQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwyQ0FBQyxPQUFFLFdBQVUsV0FDWDtBQUFBLDZDQUFDLFVBQUssV0FBVSw2QkFBNEIscUJBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlEO0FBQUEsc0JBQVE7QUFBQSxzQkFDekQsdUJBQUMsVUFBSyxXQUFVLGlCQUFpQkEsdUJBQWErQyxVQUFVQyxhQUFhLE9BQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlFO0FBQUEseUJBRjNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUsV0FDWDtBQUFBLDZDQUFDLFVBQUssV0FBVSw2QkFBNEIsc0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtEO0FBQUEsc0JBQVE7QUFBQSxzQkFDMUQsdUJBQUMsVUFBSyxXQUFVLGlCQUFpQmhELHVCQUFhK0MsVUFBVUUsZ0JBQWdCLE9BQXhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTRFO0FBQUEseUJBRjlFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUsV0FDWDtBQUFBLDZDQUFDLFVBQUssV0FBVSw2QkFBNEIsc0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtEO0FBQUEsc0JBQVE7QUFBQSxzQkFDMUQsdUJBQUMsVUFBSyxXQUFVLGlCQUFpQmpELHVCQUFhK0MsVUFBVTBCLFNBQVMsT0FBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBcUU7QUFBQSx5QkFGdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSxXQUNYO0FBQUEsNkNBQUMsVUFBSyxXQUFVLDZCQUE0Qix3QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBb0Q7QUFBQSxzQkFBUTtBQUFBLHNCQUM1RCx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCekUsdUJBQWErQyxVQUFVMkIsV0FBVyxPQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF1RTtBQUFBLHlCQUZ6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsdUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUJBO0FBQUEscUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBc0JBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLHVGQUNiO0FBQUEseUNBQUMsUUFBRyxXQUFVLDREQUNaO0FBQUEsMkNBQUMsYUFBVSxXQUFVLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFxQztBQUFBLG9CQUFHO0FBQUEsdUJBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSxXQUNYO0FBQUEsNkNBQUMsVUFBSyxXQUFVLDZCQUE0Qiw0QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBd0Q7QUFBQSxzQkFBUTtBQUFBLHNCQUNoRSx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCMUUsdUJBQWFtRCxZQUFZQyxRQUFRLE9BQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXNFO0FBQUEseUJBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUsV0FDWDtBQUFBLDZDQUFDLFVBQUssV0FBVSw2QkFBNEIsc0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtEO0FBQUEsc0JBQVE7QUFBQSxzQkFDMUQsdUJBQUMsVUFBSyxXQUFVLGlCQUFpQnBELHVCQUFhbUQsWUFBWUYsZ0JBQWdCLE9BQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQThFO0FBQUEseUJBRmhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxvQkFDQSx1QkFBQyxPQUFFLFdBQVUsV0FDWDtBQUFBLDZDQUFDLFVBQUssV0FBVSw2QkFBNEIsc0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWtEO0FBQUEsc0JBQVE7QUFBQSxzQkFDMUQsdUJBQUMsVUFBSyxXQUFVLGlCQUFpQmpELHVCQUFhbUQsWUFBWXNCLFNBQVMsT0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBdUU7QUFBQSx5QkFGekU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUNBLHVCQUFDLE9BQUUsV0FBVSxXQUNYO0FBQUEsNkNBQUMsVUFBSyxXQUFVLDZCQUE0Qiw0QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBd0Q7QUFBQSxzQkFBUTtBQUFBLHNCQUNoRSx1QkFBQyxVQUFLLFdBQVUsaUJBQWlCekUsdUJBQWEyRSxZQUFZdkIsUUFBUSxPQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFzRTtBQUFBLHlCQUZ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsdUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUJBO0FBQUEscUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBc0JBO0FBQUEsbUJBL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0RBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsb0ZBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsNERBQ1o7QUFBQSx5Q0FBQyxhQUFVLFdBQVUscUJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXNDO0FBQUEsa0JBQUc7QUFBQSxxQkFEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSx5QkFBd0Isc0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJDO0FBQUEsb0JBQzNDLHVCQUFDLE9BQUksT0FBT2pCLGVBQWVuQyxhQUFhMkIsUUFBUTNCLGFBQWE2QixjQUFjLEdBQUcsV0FBVSxRQUNyRlEsd0JBQWNyQyxZQUFZLEtBRDdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHlCQUF3QiwrQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBb0Q7QUFBQSxvQkFDcEQsdUJBQUMsT0FBSSxPQUFPQSxhQUFhNEIsb0JBQW9CLGFBQWEsVUFBVSxVQUFVLFdBQVUsUUFDckY1Qix1QkFBYTRCLG1CQUFtQixhQURuQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSx5QkFBd0IsdUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRDO0FBQUEsb0JBQzVDLHVCQUFDLE9BQUUsV0FBVSxxQ0FDVjVCLHVCQUFheUIsWUFDVnhELE1BQU0rQixhQUFheUIsU0FBUyxFQUFFNEIsT0FBTyxrQkFBa0IsSUFDdkQsT0FITjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUlBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSx5QkFBd0IseUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQThDO0FBQUEsb0JBQzlDLHVCQUFDLE9BQUUsV0FBVSxxQ0FDVnJELHVCQUFhNEUsZUFDVjNHLE1BQU0rQixhQUFhNEUsWUFBWSxFQUFFdkIsT0FBTyxrQkFBa0IsSUFDMUQsT0FITjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUlBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFPQTtBQUFBLHFCQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTZCQTtBQUFBLGdCQUNDckQsYUFBYTZFLG1CQUNaLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSw4QkFBNkIsMkJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFEO0FBQUEsa0JBQ3JELHVCQUFDLE9BQUUsV0FBVSx5QkFBeUI3RSx1QkFBYTZFLG1CQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRTtBQUFBLHFCQUZyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBRUQ3RSxhQUFhOEUsdUJBQ1osdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLDhCQUE2QiwwQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBb0Q7QUFBQSxrQkFDcEQsdUJBQUMsT0FBRSxXQUFVLHlCQUF5QjlFLHVCQUFhOEUsdUJBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXVFO0FBQUEscUJBRnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkE1Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE4Q0E7QUFBQSxjQUdDOUUsYUFBYStFLG9CQUFvQkMsZ0JBQ2hDLHVCQUFDLFNBQUksV0FBVSwwRkFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSw0REFDWjtBQUFBLHlDQUFDLGtCQUFlLFdBQVUscUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTJDO0FBQUEsa0JBQUc7QUFBQSxxQkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLDJDQUFDLE9BQUUsV0FBVSx5QkFBd0Isd0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTZDO0FBQUEsb0JBQzdDLHVCQUFDLE9BQUUsV0FBVSxxQ0FDVmhGLHVCQUFhK0UsbUJBQW1CQyxhQUFhQyxZQUFZLE9BRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsMkNBQUMsT0FBRSxXQUFVLHlCQUF3Qix5QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEM7QUFBQSxvQkFDOUMsdUJBQUMsT0FBRSxXQUFVLHFDQUNWakYsdUJBQWErRSxtQkFBbUJDLGFBQWFFLGFBQWEsT0FEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsbUNBQ2I7QUFBQSwyQ0FBQyxPQUFFLFdBQVUseUJBQXdCLHVCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE0QztBQUFBLG9CQUM1Qyx1QkFBQyxPQUFFLFdBQVUscUNBQ1ZsRix1QkFBYStFLG1CQUFtQkMsYUFBYU4sV0FBVyxPQUQzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQTtBQUFBLHFCQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQTtBQUFBLG1CQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXdCQTtBQUFBLGNBSUQxRSxhQUFhbUYsV0FBV25GLGFBQWFtRixRQUFRbkQsU0FBUyxLQUNyRCx1QkFBQyxTQUFJLFdBQVUsb0ZBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsNERBQ1o7QUFBQSx5Q0FBQyxXQUFRLFdBQVUsbUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtDO0FBQUEsa0JBQUc7QUFBQSxxQkFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDWmhDLHVCQUFhbUYsUUFBUXpDO0FBQUFBLGtCQUFJLENBQUMwQyxPQUFPekMsVUFDaEMsdUJBQUMsU0FBZ0IsV0FBVSw4RUFDekI7QUFBQSwyQ0FBQyxPQUFJLE9BQU0sUUFBTyxXQUFVLFVBQVV5QyxnQkFBTXpELFVBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1EO0FBQUEsb0JBQ25ELHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkNBQUMsT0FBRSxXQUFVLGlCQUFpQnlELGdCQUFNQyxRQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5QztBQUFBLHNCQUN6Qyx1QkFBQyxPQUFFLFdBQVUsOEJBQ1ZELGdCQUFNRSxZQUNIckgsTUFBTW1ILE1BQU1FLFNBQVMsRUFBRWpDLE9BQU8sa0JBQWtCLElBQ2hELE9BSE47QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFJQTtBQUFBLHlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQSx1QkFUUVYsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVVBO0FBQUEsZ0JBQ0QsS0FiSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWNBO0FBQUEsbUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbUJBO0FBQUE7QUFBQTtBQUFBLFVBakxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW1MQTtBQUFBO0FBQUEsTUFsTUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBb01BO0FBQUEsT0ExYUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJhQTtBQUVKO0FBQUNuRSxHQXRvQlFELDRCQUEwQjtBQUFBZ0gsS0FBMUJoSDtBQXdvQlQsZUFBZUE7QUFBMkIsSUFBQWdIO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUNhbGxiYWNrIiwiTmF2YmFyIiwiU2lkZWJhciIsIkZhU2VhcmNoIiwiRmFGaWx0ZXIiLCJGYURvd25sb2FkIiwiRmFFeWUiLCJGYUNoZWNrQ2lyY2xlIiwiRmFDbG9jayIsIkZhVGltZXNDaXJjbGUiLCJGYVVzZXJDaGVjayIsIkZhVXNlckNsb2NrIiwiRmFVc2VyVGltZXMiLCJGYVVzZXIiLCJGYU1hcE1hcmtlckFsdCIsIkZhUGhvbmUiLCJGYUNhbGVuZGFyQWx0IiwiRmFGaWxlQWx0IiwiRmFVc2VyVGllIiwiRmFUYXNrcyIsIkZhQ2xpcGJvYXJkQ2hlY2siLCJGYVNwaW5uZXIiLCJtZXNzYWdlIiwiRGF0ZVBpY2tlciIsIlNlbGVjdCIsIlRhZyIsIk1vZGFsIiwiU3BpbiIsImRheWpzIiwiYXBpIiwiRGF0YVRhYmxlIiwibW90aW9uIiwiUmFuZ2VQaWNrZXIiLCJPcHRpb24iLCJDdXN0b21lclZpc2l0VHJhY2tlclJlcG9ydCIsIl9zIiwibG9hZGluZyIsInNldExvYWRpbmciLCJ0YXNrcyIsInNldFRhc2tzIiwiZmlsdGVyZWRUYXNrcyIsInNldEZpbHRlcmVkVGFza3MiLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJzZWxlY3RlZEFnZW50Iiwic2V0U2VsZWN0ZWRBZ2VudCIsImRhdGVSYW5nZSIsInNldERhdGVSYW5nZSIsInN0YXR1c0ZpbHRlciIsInNldFN0YXR1c0ZpbHRlciIsInN1bW1hcnkiLCJzZXRTdW1tYXJ5IiwidG90YWwiLCJwZW5kaW5nIiwiaW5Qcm9ncmVzcyIsImNvbXBsZXRlZCIsInZpc2l0ZWQiLCJub3RBdmFpbGFibGUiLCJyZWplY3RlZCIsInNlbGVjdGVkVGFzayIsInNldFNlbGVjdGVkVGFzayIsImlzTW9kYWxWaXNpYmxlIiwic2V0SXNNb2RhbFZpc2libGUiLCJmZXRjaEFnZW50cyIsInJlc3BvbnNlIiwiZ2V0IiwiYWdlbnREYXRhIiwiZGF0YSIsInZlcmlmaWVkQWdlbnRzIiwiQXJyYXkiLCJpc0FycmF5IiwiZmlsdGVyIiwiYWdlbnQiLCJpc1ZlcmlmaWVkIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hUYXNrcyIsInVybCIsInRhc2tEYXRhIiwic3RhcnREYXRlIiwic3RhcnRPZiIsImVuZERhdGUiLCJlbmRPZiIsInRhc2siLCJjcmVhdGVkQXQiLCJpc0JldHdlZW4iLCJzdGF0dXMiLCJhcHByb3ZhbF9zdGF0dXMiLCJhZ2VudF9yZXNwb25zZSIsImNhbGN1bGF0ZVN1bW1hcnkiLCJzdW1tYXJ5RGF0YSIsImxlbmd0aCIsInQiLCJ2aWV3VGFza0RldGFpbHMiLCJnZXRTdGF0dXNDb2xvciIsImFnZW50UmVzcG9uc2UiLCJnZXRTdGF0dXNUZXh0IiwiY29sdW1ucyIsImtleSIsImhlYWRlciIsInRhYmxlRGF0YSIsIm1hcCIsImluZGV4IiwiaWQiLCJ0YXNrX2NvZGUiLCJjdXN0b21lcl9uYW1lIiwiY3VzdG9tZXIiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJhc3NpZ25lZF90byIsImFzc2lnbmVkVG8iLCJuYW1lIiwiZm9ybWF0IiwiYWN0aW9ucyIsIl9yYXciLCJTdGF0dXNDYXJkIiwidGl0bGUiLCJjb3VudCIsImljb24iLCJJY29uIiwiYm9yZGVyQ29sb3IiLCJiZ0NvbG9yIiwic3VidGV4dCIsInNjYWxlIiwiZHVyYXRpb24iLCJyZXBsYWNlIiwib3BhY2l0eSIsInkiLCJkZWxheSIsIl9pZCIsInBhZGRpbmciLCJ0YXNrVGl0bGUiLCJlbWFpbCIsImFkZHJlc3MiLCJhc3NpZ25lZEJ5IiwiY29tcGxldGVkX2F0IiwidGFza0Rlc2NyaXB0aW9uIiwiYWdlbnRfcmVzcG9uc2Vfbm90ZSIsImNvbXBsZXRpb25fZGV0YWlscyIsImdwc19sb2NhdGlvbiIsImxhdGl0dWRlIiwibG9uZ2l0dWRlIiwiaGlzdG9yeSIsImVudHJ5Iiwibm90ZSIsImNoYW5nZWRBdCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkN1c3RvbWVyVmlzaXRUcmFja2VyUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlQ2FsbGJhY2sgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IHtcclxuICBGYVNlYXJjaCxcclxuICBGYUZpbHRlcixcclxuICBGYURvd25sb2FkLFxyXG4gIEZhRXllLFxyXG4gIEZhQ2hlY2tDaXJjbGUsXHJcbiAgRmFDbG9jayxcclxuICBGYVRpbWVzQ2lyY2xlLFxyXG4gIEZhVXNlckNoZWNrLFxyXG4gIEZhVXNlckNsb2NrLFxyXG4gIEZhVXNlclRpbWVzLFxyXG4gIEZhVXNlcixcclxuICBGYU1hcE1hcmtlckFsdCxcclxuICBGYVBob25lLFxyXG4gIEZhQ2FsZW5kYXJBbHQsXHJcbiAgRmFGaWxlQWx0LFxyXG4gIEZhVXNlclRpZSxcclxuICBGYVRhc2tzLFxyXG4gIEZhQ2xpcGJvYXJkQ2hlY2ssXHJcbiAgRmFTcGlubmVyLFxyXG59IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBtZXNzYWdlLCBEYXRlUGlja2VyLCBTZWxlY3QsIFRhZywgTW9kYWwsIFNwaW4gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgZGF5anMgZnJvbSBcImRheWpzXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tIFwiZnJhbWVyLW1vdGlvblwiO1xyXG5cclxuY29uc3QgeyBSYW5nZVBpY2tlciB9ID0gRGF0ZVBpY2tlcjtcclxuY29uc3QgeyBPcHRpb24gfSA9IFNlbGVjdDtcclxuXHJcbmZ1bmN0aW9uIEN1c3RvbWVyVmlzaXRUcmFja2VyUmVwb3J0KCkge1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdGFza3MsIHNldFRhc2tzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZmlsdGVyZWRUYXNrcywgc2V0RmlsdGVyZWRUYXNrc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBZ2VudCwgc2V0U2VsZWN0ZWRBZ2VudF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZGF0ZVJhbmdlLCBzZXREYXRlUmFuZ2VdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3N0YXR1c0ZpbHRlciwgc2V0U3RhdHVzRmlsdGVyXSA9IHVzZVN0YXRlKFwiQWxsXCIpO1xyXG4gIGNvbnN0IFtzdW1tYXJ5LCBzZXRTdW1tYXJ5XSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsOiAwLFxyXG4gICAgcGVuZGluZzogMCxcclxuICAgIGluUHJvZ3Jlc3M6IDAsXHJcbiAgICBjb21wbGV0ZWQ6IDAsXHJcbiAgICB2aXNpdGVkOiAwLFxyXG4gICAgbm90QXZhaWxhYmxlOiAwLFxyXG4gICAgcmVqZWN0ZWQ6IDAsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVGFzaywgc2V0U2VsZWN0ZWRUYXNrXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtpc01vZGFsVmlzaWJsZSwgc2V0SXNNb2RhbFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyBGZXRjaCBhZ2VudHMgLSB1c2luZyAvYWdlbnQvZ2V0LWFnZW50XHJcbiAgY29uc3QgZmV0Y2hBZ2VudHMgPSB1c2VDYWxsYmFjayhhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWFnZW50XCIpO1xyXG4gICAgICAvLyBUaGUgcmVzcG9uc2Ugc3RydWN0dXJlIG1pZ2h0IGJlIGRpZmZlcmVudCwgaGFuZGxlIGJvdGggY2FzZXNcclxuICAgICAgY29uc3QgYWdlbnREYXRhID0gcmVzcG9uc2U/LmRhdGE/LmRhdGEgfHwgcmVzcG9uc2U/LmRhdGEgfHwgW107XHJcbiAgICAgIGNvbnN0IHZlcmlmaWVkQWdlbnRzID0gQXJyYXkuaXNBcnJheShhZ2VudERhdGEpIFxyXG4gICAgICAgID8gYWdlbnREYXRhLmZpbHRlcigoYWdlbnQpID0+IGFnZW50Py5pc1ZlcmlmaWVkID09PSB0cnVlKVxyXG4gICAgICAgIDogW107XHJcbiAgICAgIHNldEFnZW50cyh2ZXJpZmllZEFnZW50cyk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWdlbnRzOlwiLCBlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggYWdlbnRzXCIpO1xyXG4gICAgICBzZXRBZ2VudHMoW10pO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gRmV0Y2ggdGFza3NcclxuICBjb25zdCBmZXRjaFRhc2tzID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCB1cmwgPSBcIi92MS9tb2JpbGUvZmVpbGR2aXNpdHRyYWNrZXIvYXNzaWduZWQtY3VzdG9tZXJcIjtcclxuICAgICAgXHJcbiAgICAgIGlmIChzZWxlY3RlZEFnZW50KSB7XHJcbiAgICAgICAgdXJsID0gYC92MS9tb2JpbGUvZmVpbGR2aXNpdHRyYWNrZXIvYXNzaWduZWQtY3VzdG9tZXIvJHtzZWxlY3RlZEFnZW50fWA7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldCh1cmwpO1xyXG4gICAgICBsZXQgdGFza0RhdGEgPSByZXNwb25zZT8uZGF0YT8uZGF0YSB8fCBbXTtcclxuXHJcbiAgICAgIC8vIEFwcGx5IGRhdGUgZmlsdGVyXHJcbiAgICAgIGlmIChkYXRlUmFuZ2UgJiYgZGF0ZVJhbmdlWzBdICYmIGRhdGVSYW5nZVsxXSkge1xyXG4gICAgICAgIGNvbnN0IHN0YXJ0RGF0ZSA9IGRheWpzKGRhdGVSYW5nZVswXSkuc3RhcnRPZignZGF5Jyk7XHJcbiAgICAgICAgY29uc3QgZW5kRGF0ZSA9IGRheWpzKGRhdGVSYW5nZVsxXSkuZW5kT2YoJ2RheScpO1xyXG4gICAgICAgIHRhc2tEYXRhID0gdGFza0RhdGEuZmlsdGVyKHRhc2sgPT4ge1xyXG4gICAgICAgICAgY29uc3QgY3JlYXRlZEF0ID0gZGF5anModGFzay5jcmVhdGVkQXQpO1xyXG4gICAgICAgICAgcmV0dXJuIGNyZWF0ZWRBdC5pc0JldHdlZW4oc3RhcnREYXRlLCBlbmREYXRlLCBudWxsLCAnW10nKTtcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gQXBwbHkgc3RhdHVzIGZpbHRlclxyXG4gICAgICBpZiAoc3RhdHVzRmlsdGVyICE9PSBcIkFsbFwiKSB7XHJcbiAgICAgICAgdGFza0RhdGEgPSB0YXNrRGF0YS5maWx0ZXIodGFzayA9PiB7XHJcbiAgICAgICAgICBpZiAoc3RhdHVzRmlsdGVyID09PSBcIlZpc2l0ZWRcIikge1xyXG4gICAgICAgICAgICByZXR1cm4gdGFzay5zdGF0dXMgPT09IFwiQ29tcGxldGVkXCIgJiYgdGFzay5hcHByb3ZhbF9zdGF0dXMgPT09IFwiQXBwcm92ZWRcIjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlmIChzdGF0dXNGaWx0ZXIgPT09IFwiTm90IEF2YWlsYWJsZVwiKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0YXNrLnN0YXR1cyA9PT0gXCJSZWplY3RlZFwiIHx8IHRhc2suYWdlbnRfcmVzcG9uc2UgPT09IFwiUmVqZWN0ZWRcIjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlmIChzdGF0dXNGaWx0ZXIgPT09IFwiQWNjZXB0ZWRcIikge1xyXG4gICAgICAgICAgICByZXR1cm4gdGFzay5hZ2VudF9yZXNwb25zZSA9PT0gXCJBY2NlcHRlZFwiO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgcmV0dXJuIHRhc2suc3RhdHVzID09PSBzdGF0dXNGaWx0ZXIgfHwgdGFzay5hZ2VudF9yZXNwb25zZSA9PT0gc3RhdHVzRmlsdGVyO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRUYXNrcyh0YXNrRGF0YSk7XHJcbiAgICAgIHNldEZpbHRlcmVkVGFza3ModGFza0RhdGEpO1xyXG4gICAgICBjYWxjdWxhdGVTdW1tYXJ5KHRhc2tEYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YXNrczpcIiwgZXJyb3IpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHRhc2tzXCIpO1xyXG4gICAgICBzZXRUYXNrcyhbXSk7XHJcbiAgICAgIHNldEZpbHRlcmVkVGFza3MoW10pO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfSwgW3NlbGVjdGVkQWdlbnQsIGRhdGVSYW5nZSwgc3RhdHVzRmlsdGVyXSk7XHJcblxyXG4gIC8vIENhbGN1bGF0ZSBzdW1tYXJ5IC0gRml4ZWQgcGVuZGluZyBjYWxjdWxhdGlvblxyXG4gIGNvbnN0IGNhbGN1bGF0ZVN1bW1hcnkgPSAoZGF0YSkgPT4ge1xyXG4gICAgY29uc3Qgc3VtbWFyeURhdGEgPSB7XHJcbiAgICAgIHRvdGFsOiBkYXRhLmxlbmd0aCxcclxuICAgICAgLy8gUGVuZGluZzogdGFza3Mgd2l0aCBubyByZXNwb25zZSBvciBleHBsaWNpdGx5IHBlbmRpbmcsIGFuZCBub3QgaW4gcHJvZ3Jlc3MvY29tcGxldGVkL3JlamVjdGVkXHJcbiAgICAgIHBlbmRpbmc6IGRhdGEuZmlsdGVyKHQgPT4ge1xyXG4gICAgICAgIGNvbnN0IHN0YXR1cyA9IHQuc3RhdHVzO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gdC5hZ2VudF9yZXNwb25zZTtcclxuICAgICAgICAvLyBOb3QgcGVuZGluZyBpZiBpbiBwcm9ncmVzcywgY29tcGxldGVkLCBvciByZWplY3RlZFxyXG4gICAgICAgIGlmIChzdGF0dXMgPT09IFwiSW4gUHJvZ3Jlc3NcIiB8fCBzdGF0dXMgPT09IFwiQ29tcGxldGVkXCIgfHwgc3RhdHVzID09PSBcIlJlamVjdGVkXCIpIHtcclxuICAgICAgICAgIHJldHVybiBmYWxzZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gUGVuZGluZyBpZiBubyByZXNwb25zZSBvciByZXNwb25zZSBpcyBQZW5kaW5nXHJcbiAgICAgICAgcmV0dXJuICFyZXNwb25zZSB8fCByZXNwb25zZSA9PT0gXCJQZW5kaW5nXCI7XHJcbiAgICAgIH0pLmxlbmd0aCxcclxuICAgICAgaW5Qcm9ncmVzczogZGF0YS5maWx0ZXIodCA9PiB0LnN0YXR1cyA9PT0gXCJJbiBQcm9ncmVzc1wiKS5sZW5ndGgsXHJcbiAgICAgIGNvbXBsZXRlZDogZGF0YS5maWx0ZXIodCA9PiB0LnN0YXR1cyA9PT0gXCJDb21wbGV0ZWRcIikubGVuZ3RoLFxyXG4gICAgICB2aXNpdGVkOiBkYXRhLmZpbHRlcih0ID0+IHQuc3RhdHVzID09PSBcIkNvbXBsZXRlZFwiICYmIHQuYXBwcm92YWxfc3RhdHVzID09PSBcIkFwcHJvdmVkXCIpLmxlbmd0aCxcclxuICAgICAgbm90QXZhaWxhYmxlOiBkYXRhLmZpbHRlcih0ID0+IHQuc3RhdHVzID09PSBcIlJlamVjdGVkXCIgfHwgdC5hZ2VudF9yZXNwb25zZSA9PT0gXCJSZWplY3RlZFwiKS5sZW5ndGgsXHJcbiAgICAgIHJlamVjdGVkOiBkYXRhLmZpbHRlcih0ID0+IHQuYWdlbnRfcmVzcG9uc2UgPT09IFwiUmVqZWN0ZWRcIikubGVuZ3RoLFxyXG4gICAgfTtcclxuICAgIHNldFN1bW1hcnkoc3VtbWFyeURhdGEpO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEFnZW50cygpO1xyXG4gIH0sIFtmZXRjaEFnZW50c10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hUYXNrcygpO1xyXG4gIH0sIFtmZXRjaFRhc2tzXSk7XHJcblxyXG4gIC8vIEhhbmRsZSB2aWV3IHRhc2sgZGV0YWlsc1xyXG4gIGNvbnN0IHZpZXdUYXNrRGV0YWlscyA9ICh0YXNrKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFRhc2sodGFzayk7XHJcbiAgICBzZXRJc01vZGFsVmlzaWJsZSh0cnVlKTtcclxuICB9O1xyXG5cclxuICAvLyBTdGF0dXMgY29sb3IgbWFwcGluZ1xyXG4gIGNvbnN0IGdldFN0YXR1c0NvbG9yID0gKHN0YXR1cywgYWdlbnRSZXNwb25zZSkgPT4ge1xyXG4gICAgaWYgKHN0YXR1cyA9PT0gXCJDb21wbGV0ZWRcIiAmJiBhZ2VudFJlc3BvbnNlID09PSBcIkFjY2VwdGVkXCIpIHJldHVybiBcImdyZWVuXCI7XHJcbiAgICBpZiAoc3RhdHVzID09PSBcIkNvbXBsZXRlZFwiKSByZXR1cm4gXCJncmVlblwiO1xyXG4gICAgaWYgKHN0YXR1cyA9PT0gXCJJbiBQcm9ncmVzc1wiKSByZXR1cm4gXCJibHVlXCI7XHJcbiAgICBpZiAoc3RhdHVzID09PSBcIlJlamVjdGVkXCIgfHwgYWdlbnRSZXNwb25zZSA9PT0gXCJSZWplY3RlZFwiKSByZXR1cm4gXCJyZWRcIjtcclxuICAgIGlmIChzdGF0dXMgPT09IFwiUGVuZGluZ1wiIHx8ICFhZ2VudFJlc3BvbnNlKSByZXR1cm4gXCJvcmFuZ2VcIjtcclxuICAgIGlmIChhZ2VudFJlc3BvbnNlID09PSBcIkFjY2VwdGVkXCIpIHJldHVybiBcImN5YW5cIjtcclxuICAgIHJldHVybiBcImRlZmF1bHRcIjtcclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRTdGF0dXNUZXh0ID0gKHRhc2spID0+IHtcclxuICAgIGlmICh0YXNrLnN0YXR1cyA9PT0gXCJDb21wbGV0ZWRcIiAmJiB0YXNrLmFwcHJvdmFsX3N0YXR1cyA9PT0gXCJBcHByb3ZlZFwiKSByZXR1cm4gXCJWaXNpdGVkXCI7XHJcbiAgICBpZiAodGFzay5zdGF0dXMgPT09IFwiQ29tcGxldGVkXCIpIHJldHVybiBcIkNvbXBsZXRlZFwiO1xyXG4gICAgaWYgKHRhc2suc3RhdHVzID09PSBcIkluIFByb2dyZXNzXCIpIHJldHVybiBcIkluIFByb2dyZXNzXCI7XHJcbiAgICBpZiAodGFzay5zdGF0dXMgPT09IFwiUmVqZWN0ZWRcIikgcmV0dXJuIFwiTm90IEF2YWlsYWJsZVwiO1xyXG4gICAgaWYgKHRhc2suYWdlbnRfcmVzcG9uc2UgPT09IFwiQWNjZXB0ZWRcIikgcmV0dXJuIFwiQWNjZXB0ZWRcIjtcclxuICAgIGlmICh0YXNrLmFnZW50X3Jlc3BvbnNlID09PSBcIlJlamVjdGVkXCIpIHJldHVybiBcIlJlamVjdGVkXCI7XHJcbiAgICByZXR1cm4gXCJQZW5kaW5nXCI7XHJcbiAgfTtcclxuXHJcbiAgLy8gQ29sdW1ucyBmb3IgRGF0YVRhYmxlXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwidGFza19jb2RlXCIsIGhlYWRlcjogXCJUYXNrIENvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZVwiIH0sXHJcbiAgICB7IGtleTogXCJhc3NpZ25lZF90b1wiLCBoZWFkZXI6IFwiQXNzaWduZWQgVG9cIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3JlYXRlZEF0XCIsIGhlYWRlcjogXCJDcmVhdGVkIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uc1wiLCBoZWFkZXI6IFwiQWN0aW9uc1wiIH0sXHJcbiAgXTtcclxuXHJcbiAgLy8gUHJlcGFyZSB0YWJsZSBkYXRhXHJcbiAgY29uc3QgdGFibGVEYXRhID0gZmlsdGVyZWRUYXNrcy5tYXAoKHRhc2ssIGluZGV4KSA9PiB7XHJcbiAgICBjb25zdCBzdGF0dXMgPSBnZXRTdGF0dXNUZXh0KHRhc2spO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgdGFza19jb2RlOiB0YXNrLnRhc2tfY29kZSB8fCBcIi1cIixcclxuICAgICAgY3VzdG9tZXJfbmFtZTogdGFzay5jdXN0b21lcj8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICBwaG9uZV9udW1iZXI6IHRhc2suY3VzdG9tZXI/LnBob25lX251bWJlciB8fCBcIi1cIixcclxuICAgICAgYXNzaWduZWRfdG86IHRhc2suYXNzaWduZWRUbz8ubmFtZSB8fCBcIi1cIixcclxuICAgICAgc3RhdHVzOiAoXHJcbiAgICAgICAgPFRhZyBcclxuICAgICAgICAgIGNvbG9yPXtnZXRTdGF0dXNDb2xvcih0YXNrLnN0YXR1cywgdGFzay5hZ2VudF9yZXNwb25zZSl9XHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEgZm9udC1tZWRpdW1cIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtzdGF0dXN9XHJcbiAgICAgICAgPC9UYWc+XHJcbiAgICAgICksXHJcbiAgICAgIGNyZWF0ZWRBdDogdGFzay5jcmVhdGVkQXRcclxuICAgICAgICA/IGRheWpzKHRhc2suY3JlYXRlZEF0KS5mb3JtYXQoXCJERC9NTS9ZWVlZIEhIOm1tXCIpXHJcbiAgICAgICAgOiBcIi1cIixcclxuICAgICAgYWN0aW9uczogKFxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZpZXdUYXNrRGV0YWlscyh0YXNrKX1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgaG92ZXI6dGV4dC1ibHVlLTgwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgaG92ZXI6c2NhbGUtMTEwXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8RmFFeWUgc2l6ZT17MTh9IC8+XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICksXHJcbiAgICAgIF9yYXc6IHRhc2ssXHJcbiAgICB9O1xyXG4gIH0pO1xyXG5cclxuICAvLyBTdGF0dXMgQ2FyZHMgd2l0aCBib3JkZXIgY29sb3JzXHJcbiAgY29uc3QgU3RhdHVzQ2FyZCA9ICh7IHRpdGxlLCBjb3VudCwgaWNvbjogSWNvbiwgYm9yZGVyQ29sb3IsIGJnQ29sb3IsIHN1YnRleHQgfSkgPT4gKFxyXG4gICAgPG1vdGlvbi5kaXZcclxuICAgICAgd2hpbGVIb3Zlcj17eyBzY2FsZTogMS4wMiB9fVxyXG4gICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjIgfX1cclxuICAgICAgY2xhc3NOYW1lPXtgJHtiZ0NvbG9yfSByb3VuZGVkLXhsIHNoYWRvdy1zbSBwLTQgYm9yZGVyLWwtNCAke2JvcmRlckNvbG9yfSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwYH1cclxuICAgID5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtib3JkZXJDb2xvci5yZXBsYWNlKCdib3JkZXItJywgJ2JnLScpLnJlcGxhY2UoJy01MDAnLCAnLTEwMCcpfSBwLTMgcm91bmRlZC1mdWxsYH0+XHJcbiAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9e2B3LTUgaC01ICR7Ym9yZGVyQ29sb3IucmVwbGFjZSgnYm9yZGVyLScsICd0ZXh0LScpfWB9IC8+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPnt0aXRsZX08L3A+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTJcIj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj57Y291bnR9PC9wPlxyXG4gICAgICAgICAgICB7c3VidGV4dCAmJiAoXHJcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNDAwXCI+e3N1YnRleHR9PC9zcGFuPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9tb3Rpb24uZGl2PlxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JheS01MCB0by1ncmF5LTEwMFwiPlxyXG4gICAgICB7LyogUmVtb3ZlZCBTaWRlYmFyIC0ga2VlcGluZyBvbmx5IHRoZSBtYWluIGNvbnRlbnQgKi99XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LWF1dG8gcC00XCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTh4bCBteC1hdXRvXCI+XHJcbiAgICAgICAgICAgIHsvKiBIZWFkZXIgKi99XHJcbiAgICAgICAgICAgIDxtb3Rpb24uZGl2XHJcbiAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAtMjAgfX1cclxuICAgICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cclxuICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjUgfX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBtZDppdGVtcy1jZW50ZXIgbWItNCBiZy13aGl0ZSByb3VuZGVkLXhsIHAtNCBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RmFDbGlwYm9hcmRDaGVjayBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgVmlzaXQgVHJhY2tlciBSZXBvcnRcclxuICAgICAgICAgICAgICAgIDwvaDE+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICBUcmFjayBhbmQgbWFuYWdlIGN1c3RvbWVyIHZpc2l0IHRhc2tzIGVmZmljaWVudGx5XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtdC00IG1kOm10LTBcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkQWdlbnQobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RGF0ZVJhbmdlKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFN0YXR1c0ZpbHRlcihcIkFsbFwiKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWdyYXktMTAwIHRleHQtZ3JheS03MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmF5LTIwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8RmFGaWx0ZXIgc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICAgICAgICAgIENsZWFyIEZpbHRlcnNcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L21vdGlvbi5kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRmlsdGVycyAqL31cclxuICAgICAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IC0xMCB9fVxyXG4gICAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxyXG4gICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuNCwgZGVsYXk6IDAuMSB9fVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LXNtIHAtNCBtYi00IGJvcmRlciBib3JkZXItZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGYVVzZXJUaWUgY2xhc3NOYW1lPVwiaW5saW5lIG1yLTEuNSB0ZXh0LWJsdWUtNTAwXCIgLz4gQWdlbnRcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEFnZW50XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIGFsbG93Q2xlYXJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRBZ2VudH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRBZ2VudH1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibWlkZGxlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChhZ2VudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPE9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2FnZW50Ll9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2FnZW50Ll9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9e2Ake2FnZW50Lm5hbWV9ICR7YWdlbnQucGhvbmVfbnVtYmVyfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfSAoe2FnZW50LnBob25lX251bWJlcn0pXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGYUNhbGVuZGFyQWx0IGNsYXNzTmFtZT1cImlubGluZSBtci0xLjUgdGV4dC1wdXJwbGUtNTAwXCIgLz4gRGF0ZSBSYW5nZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8UmFuZ2VQaWNrZXJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRlUmFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldERhdGVSYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBmb3JtYXQ9XCJERC9NTS9ZWVlZXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj17W1wiU3RhcnQgRGF0ZVwiLCBcIkVuZCBEYXRlXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJtaWRkbGVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xLjVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8RmFGaWx0ZXIgY2xhc3NOYW1lPVwiaW5saW5lIG1yLTEuNSB0ZXh0LW9yYW5nZS01MDBcIiAvPiBTdGF0dXNcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRmlsdGVyIGJ5IFN0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3RhdHVzRmlsdGVyfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtzZXRTdGF0dXNGaWx0ZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cIm1pZGRsZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiQWxsXCI+QWxsIFN0YXR1czwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJQZW5kaW5nXCI+UGVuZGluZzwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJBY2NlcHRlZFwiPkFjY2VwdGVkPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIkluIFByb2dyZXNzXCI+SW4gUHJvZ3Jlc3M8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiQ29tcGxldGVkXCI+Q29tcGxldGVkPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIlZpc2l0ZWRcIj5WaXNpdGVkPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIk5vdCBBdmFpbGFibGVcIj5Ob3QgQXZhaWxhYmxlPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIlJlamVjdGVkXCI+UmVqZWN0ZWQ8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtZW5kXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtmZXRjaFRhc2tzfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIgYmctYmx1ZS02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIGhvdmVyOmJnLWJsdWUtNzAwIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBzaGFkb3ctbWQgaG92ZXI6c2hhZG93LWxnXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGYVNlYXJjaCBzaXplPXsxNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICBBcHBseSBGaWx0ZXJzXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBTdW1tYXJ5IENhcmRzIHdpdGggQm9yZGVyIENvbG9ycyAqL31cclxuICAgICAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAgfX1cclxuICAgICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEgfX1cclxuICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjQsIGRlbGF5OiAwLjIgfX1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIG1kOmdyaWQtY29scy0zIGxnOmdyaWQtY29scy03IGdhcC0zIG1iLTRcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPFN0YXR1c0NhcmRcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiVG90YWwgVGFza3NcIlxyXG4gICAgICAgICAgICAgICAgY291bnQ9e3N1bW1hcnkudG90YWx9XHJcbiAgICAgICAgICAgICAgICBpY29uPXtGYVRhc2tzfVxyXG4gICAgICAgICAgICAgICAgYm9yZGVyQ29sb3I9XCJib3JkZXItZ3JheS01MDBcIlxyXG4gICAgICAgICAgICAgICAgYmdDb2xvcj1cImJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgIHN1YnRleHQ9XCJBbGwgdGFza3NcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPFN0YXR1c0NhcmRcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiUGVuZGluZ1wiXHJcbiAgICAgICAgICAgICAgICBjb3VudD17c3VtbWFyeS5wZW5kaW5nfVxyXG4gICAgICAgICAgICAgICAgaWNvbj17RmFDbG9ja31cclxuICAgICAgICAgICAgICAgIGJvcmRlckNvbG9yPVwiYm9yZGVyLW9yYW5nZS01MDBcIlxyXG4gICAgICAgICAgICAgICAgYmdDb2xvcj1cImJnLXdoaXRlXCJcclxuICAgICAgICAgICAgICAgIHN1YnRleHQ9XCJBd2FpdGluZyBhY3Rpb25cIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPFN0YXR1c0NhcmRcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiSW4gUHJvZ3Jlc3NcIlxyXG4gICAgICAgICAgICAgICAgY291bnQ9e3N1bW1hcnkuaW5Qcm9ncmVzc31cclxuICAgICAgICAgICAgICAgIGljb249e0ZhU3Bpbm5lcn1cclxuICAgICAgICAgICAgICAgIGJvcmRlckNvbG9yPVwiYm9yZGVyLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgIGJnQ29sb3I9XCJiZy13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICBzdWJ0ZXh0PVwiQmVpbmcgd29ya2VkIG9uXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxTdGF0dXNDYXJkXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkNvbXBsZXRlZFwiXHJcbiAgICAgICAgICAgICAgICBjb3VudD17c3VtbWFyeS5jb21wbGV0ZWR9XHJcbiAgICAgICAgICAgICAgICBpY29uPXtGYUNoZWNrQ2lyY2xlfVxyXG4gICAgICAgICAgICAgICAgYm9yZGVyQ29sb3I9XCJib3JkZXItZ3JlZW4tNTAwXCJcclxuICAgICAgICAgICAgICAgIGJnQ29sb3I9XCJiZy13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICBzdWJ0ZXh0PVwiRmluaXNoZWQgdGFza3NcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPFN0YXR1c0NhcmRcclxuICAgICAgICAgICAgICAgIHRpdGxlPVwiVmlzaXRlZFwiXHJcbiAgICAgICAgICAgICAgICBjb3VudD17c3VtbWFyeS52aXNpdGVkfVxyXG4gICAgICAgICAgICAgICAgaWNvbj17RmFVc2VyQ2hlY2t9XHJcbiAgICAgICAgICAgICAgICBib3JkZXJDb2xvcj1cImJvcmRlci10ZWFsLTUwMFwiXHJcbiAgICAgICAgICAgICAgICBiZ0NvbG9yPVwiYmctd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgc3VidGV4dD1cIkFwcHJvdmVkIHZpc2l0c1wiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8U3RhdHVzQ2FyZFxyXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJOb3QgQXZhaWxhYmxlXCJcclxuICAgICAgICAgICAgICAgIGNvdW50PXtzdW1tYXJ5Lm5vdEF2YWlsYWJsZX1cclxuICAgICAgICAgICAgICAgIGljb249e0ZhVXNlclRpbWVzfVxyXG4gICAgICAgICAgICAgICAgYm9yZGVyQ29sb3I9XCJib3JkZXItcmVkLTUwMFwiXHJcbiAgICAgICAgICAgICAgICBiZ0NvbG9yPVwiYmctd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgc3VidGV4dD1cIlVuYXZhaWxhYmxlXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxTdGF0dXNDYXJkXHJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlJlamVjdGVkXCJcclxuICAgICAgICAgICAgICAgIGNvdW50PXtzdW1tYXJ5LnJlamVjdGVkfVxyXG4gICAgICAgICAgICAgICAgaWNvbj17RmFUaW1lc0NpcmNsZX1cclxuICAgICAgICAgICAgICAgIGJvcmRlckNvbG9yPVwiYm9yZGVyLXJvc2UtNTAwXCJcclxuICAgICAgICAgICAgICAgIGJnQ29sb3I9XCJiZy13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICBzdWJ0ZXh0PVwiUmVqZWN0ZWQgdGFza3NcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBUYXNrcyBUYWJsZSAqL31cclxuICAgICAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19XHJcbiAgICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XHJcbiAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC40LCBkZWxheTogMC4zIH19XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC14bCBzaGFkb3ctc20gcC00IGJvcmRlciBib3JkZXItZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxGYVRhc2tzIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICBUYXNrIERldGFpbHNcclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCB0ZXh0LWJsdWUtNjAwIHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFRhc2tzLmxlbmd0aH0gVGFza3NcclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHB5LTEyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxTcGluIHNpemU9XCJsYXJnZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTQgdGV4dC1ncmF5LTUwMFwiPkxvYWRpbmcgdGFza3MuLi48L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogZmlsdGVyZWRUYXNrcy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICBkYXRhPXt0YWJsZURhdGF9XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJDdXN0b21lcl9WaXNpdF9UcmFja2VyX1JlcG9ydC5jc3ZcIlxyXG4gICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDdXN0b21lcl9WaXNpdF9UcmFja2VyX1JlcG9ydC5wZGZcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RmFGaWxlQWx0IGNsYXNzTmFtZT1cInRleHQtNHhsIHRleHQtZ3JheS0zMDAgbXgtYXV0byBtYi0zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBmb250LW1lZGl1bVwiPk5vIHRhc2tzIGZvdW5kPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBUcnkgYWRqdXN0aW5nIHlvdXIgZmlsdGVycyB0byBzZWUgbW9yZSByZXN1bHRzXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvbWFpbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7LyogVGFzayBEZXRhaWxzIE1vZGFsICovfVxyXG4gICAgICA8TW9kYWxcclxuICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtbGcgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICA8RmFDbGlwYm9hcmRDaGVjayBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz5cclxuICAgICAgICAgICAgVGFzayBEZXRhaWxzXHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICB9XHJcbiAgICAgICAgb3Blbj17aXNNb2RhbFZpc2libGV9XHJcbiAgICAgICAgb25DYW5jZWw9eygpID0+IHNldElzTW9kYWxWaXNpYmxlKGZhbHNlKX1cclxuICAgICAgICBmb290ZXI9e251bGx9XHJcbiAgICAgICAgd2lkdGg9ezkwMH1cclxuICAgICAgICBjbGFzc05hbWU9XCJ0YXNrLWRldGFpbHMtbW9kYWxcIlxyXG4gICAgICAgIGJvZHlTdHlsZT17eyBwYWRkaW5nOiAnMjRweCcgfX1cclxuICAgICAgPlxyXG4gICAgICAgIHtzZWxlY3RlZFRhc2sgJiYgKFxyXG4gICAgICAgICAgPG1vdGlvbi5kaXZcclxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwIH19XHJcbiAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSB9fVxyXG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjMgfX1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS02XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgey8qIFRhc2sgSGVhZGVyICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLXN0YXJ0IGJvcmRlci1iIHBiLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFRhc2sudGFza1RpdGxlIHx8IFwiQ3VzdG9tZXIgVmlzaXQgVGFza1wifVxyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+VGFzayBDb2RlOjwvc3Bhbj4ge3NlbGVjdGVkVGFzay50YXNrX2NvZGUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPFRhZ1xyXG4gICAgICAgICAgICAgICAgY29sb3I9e2dldFN0YXR1c0NvbG9yKFxyXG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZFRhc2suc3RhdHVzLFxyXG4gICAgICAgICAgICAgICAgICBzZWxlY3RlZFRhc2suYWdlbnRfcmVzcG9uc2VcclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNtIHB4LTMgcHktMSBmb250LW1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2dldFN0YXR1c1RleHQoc2VsZWN0ZWRUYXNrKX1cclxuICAgICAgICAgICAgICA8L1RhZz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogQ3VzdG9tZXIgJiBBZ2VudCBJbmZvICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MCB0by1ibHVlLTEwMCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPEZhVXNlciBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz4gQ3VzdG9tZXIgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+TmFtZTo8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDBcIj57c2VsZWN0ZWRUYXNrLmN1c3RvbWVyPy5mdWxsX25hbWUgfHwgXCItXCJ9PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+UGhvbmU6PC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwXCI+e3NlbGVjdGVkVGFzay5jdXN0b21lcj8ucGhvbmVfbnVtYmVyIHx8IFwiLVwifTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPkVtYWlsOjwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMFwiPntzZWxlY3RlZFRhc2suY3VzdG9tZXI/LmVtYWlsIHx8IFwiLVwifTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPkFkZHJlc3M6PC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwXCI+e3NlbGVjdGVkVGFzay5jdXN0b21lcj8uYWRkcmVzcyB8fCBcIi1cIn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JlZW4tNTAgdG8tZ3JlZW4tMTAwIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItZ3JlZW4tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPEZhVXNlclRpZSBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiIC8+IEFnZW50IERldGFpbHNcclxuICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPkFzc2lnbmVkIFRvOjwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMFwiPntzZWxlY3RlZFRhc2suYXNzaWduZWRUbz8ubmFtZSB8fCBcIi1cIn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5QaG9uZTo8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDBcIj57c2VsZWN0ZWRUYXNrLmFzc2lnbmVkVG8/LnBob25lX251bWJlciB8fCBcIi1cIn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZ3JheS02MDBcIj5FbWFpbDo8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDBcIj57c2VsZWN0ZWRUYXNrLmFzc2lnbmVkVG8/LmVtYWlsIHx8IFwiLVwifTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTYwMFwiPkFzc2lnbmVkIEJ5Ojwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMFwiPntzZWxlY3RlZFRhc2suYXNzaWduZWRCeT8ubmFtZSB8fCBcIi1cIn08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBUYXNrIEluZm9ybWF0aW9uICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JheS01MCB0by1ncmF5LTEwMCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8RmFGaWxlQWx0IGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMFwiIC8+IFRhc2sgSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkIHAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5TdGF0dXM8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxUYWcgY29sb3I9e2dldFN0YXR1c0NvbG9yKHNlbGVjdGVkVGFzay5zdGF0dXMsIHNlbGVjdGVkVGFzay5hZ2VudF9yZXNwb25zZSl9IGNsYXNzTmFtZT1cIm10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Z2V0U3RhdHVzVGV4dChzZWxlY3RlZFRhc2spfVxyXG4gICAgICAgICAgICAgICAgICA8L1RhZz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkIHAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5BcHByb3ZhbCBTdGF0dXM8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxUYWcgY29sb3I9e3NlbGVjdGVkVGFzay5hcHByb3ZhbF9zdGF0dXMgPT09IFwiQXBwcm92ZWRcIiA/IFwiZ3JlZW5cIiA6IFwib3JhbmdlXCJ9IGNsYXNzTmFtZT1cIm10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRUYXNrLmFwcHJvdmFsX3N0YXR1cyB8fCBcIlBlbmRpbmdcIn1cclxuICAgICAgICAgICAgICAgICAgPC9UYWc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZCBwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+Q3JlYXRlZDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkVGFzay5jcmVhdGVkQXRcclxuICAgICAgICAgICAgICAgICAgICAgID8gZGF5anMoc2VsZWN0ZWRUYXNrLmNyZWF0ZWRBdCkuZm9ybWF0KFwiREQvTU0vWVlZWSBISDptbVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQgcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPkNvbXBsZXRlZDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkVGFzay5jb21wbGV0ZWRfYXRcclxuICAgICAgICAgICAgICAgICAgICAgID8gZGF5anMoc2VsZWN0ZWRUYXNrLmNvbXBsZXRlZF9hdCkuZm9ybWF0KFwiREQvTU0vWVlZWSBISDptbVwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgOiBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAge3NlbGVjdGVkVGFzay50YXNrRGVzY3JpcHRpb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGJnLXdoaXRlIHJvdW5kZWQgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtYi0xXCI+RGVzY3JpcHRpb248L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTcwMFwiPntzZWxlY3RlZFRhc2sudGFza0Rlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAge3NlbGVjdGVkVGFzay5hZ2VudF9yZXNwb25zZV9ub3RlICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiBiZy13aGl0ZSByb3VuZGVkIHAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbWItMVwiPkFnZW50IE5vdGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTcwMFwiPntzZWxlY3RlZFRhc2suYWdlbnRfcmVzcG9uc2Vfbm90ZX08L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBMb2NhdGlvbiBJbmZvICovfVxyXG4gICAgICAgICAgICB7c2VsZWN0ZWRUYXNrLmNvbXBsZXRpb25fZGV0YWlscz8uZ3BzX2xvY2F0aW9uICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcHVycGxlLTUwIHRvLXB1cnBsZS0xMDAgcm91bmRlZC1sZyBwLTQgYm9yZGVyIGJvcmRlci1wdXJwbGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwIG1iLTMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPEZhTWFwTWFya2VyQWx0IGNsYXNzTmFtZT1cInRleHQtcHVycGxlLTYwMFwiIC8+IExvY2F0aW9uIERldGFpbHNcclxuICAgICAgICAgICAgICAgIDwvaDQ+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkIHAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPkxhdGl0dWRlPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkVGFzay5jb21wbGV0aW9uX2RldGFpbHMuZ3BzX2xvY2F0aW9uLmxhdGl0dWRlIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZCBwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5Mb25naXR1ZGU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRUYXNrLmNvbXBsZXRpb25fZGV0YWlscy5ncHNfbG9jYXRpb24ubG9uZ2l0dWRlIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZCBwLTIgY29sLXNwYW4tMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPkFkZHJlc3M8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRUYXNrLmNvbXBsZXRpb25fZGV0YWlscy5ncHNfbG9jYXRpb24uYWRkcmVzcyB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7LyogSGlzdG9yeSAqL31cclxuICAgICAgICAgICAge3NlbGVjdGVkVGFzay5oaXN0b3J5ICYmIHNlbGVjdGVkVGFzay5oaXN0b3J5Lmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ncmF5LTUwIHRvLWdyYXktMTAwIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RmFDbG9jayBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwXCIgLz4gQWN0aXZpdHkgSGlzdG9yeVxyXG4gICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIG1heC1oLTQ4IG92ZXJmbG93LXktYXV0byBwci0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZFRhc2suaGlzdG9yeS5tYXAoKGVudHJ5LCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpbmRleH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMyB0ZXh0LXNtIGJnLXdoaXRlIHJvdW5kZWQgcC0zIGJvcmRlciBib3JkZXItZ3JheS0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxUYWcgY29sb3I9XCJibHVlXCIgY2xhc3NOYW1lPVwibXQtMC41XCI+e2VudHJ5LnN0YXR1c308L1RhZz5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS03MDBcIj57ZW50cnkubm90ZX08L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTQwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2VudHJ5LmNoYW5nZWRBdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBkYXlqcyhlbnRyeS5jaGFuZ2VkQXQpLmZvcm1hdChcIkREL01NL1lZWVkgSEg6bW1cIilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvTW9kYWw+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDdXN0b21lclZpc2l0VHJhY2tlclJlcG9ydDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQ3VzdG9tZXJWaXNpdFRyYWNrZXJSZXBvcnQuanN4In0=