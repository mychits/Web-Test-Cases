import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Target.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"];
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Dropdown, Drawer } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore, IoMdAdd, IoMdClose } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Loader from "/src/components/loaders/CircularLoader.jsx";
import { Collapse } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { FileTextOutlined, DollarOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import { FaMoneyBill } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { MdPayments } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const today = /* @__PURE__ */ new Date();
const currentYear = today.getFullYear();
const currentMonth = String(today.getMonth() + 1).padStart(2, "0");
const currentYearMonth = `${currentYear}-${currentMonth}`;
function formatDate(date) {
  const year = date.getFullYear();
  const month = `0${date.getMonth() + 1}`.slice(-2);
  const day = `0${date.getDate()}`.slice(-2);
  return `${year}-${month}-${day}`;
}
const monthNames = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
];
const GlobalSearchChangeHandler = (e) => {
  const { value } = e.target;
  setSearchText(value);
};
_c = GlobalSearchChangeHandler;
const Target = () => {
  _s();
  const [selectedType, setSelectedType] = useState("agents");
  const [selectedId, setSelectedId] = useState("all");
  const [agents, setAgents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [drawerVisible, setDrawerVisible] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: ""
  });
  const [initialDataLoading, setInitialDataLoading] = useState(true);
  const [dataLoading, setDataLoading] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [isBulkMode, setIsBulkMode] = useState(false);
  const [editTargetId, setEditTargetId] = useState(null);
  const [selectedDate, setSelectedDate] = useState(currentYearMonth);
  const [selectedPerson, setSelectedPerson] = useState(null);
  const [reload, setReload] = useState(0);
  const [targetData, setTargetData] = useState([]);
  const [monthValues, setMonthValues] = useState({
    January: 0,
    February: 0,
    March: 0,
    April: 0,
    May: 0,
    June: 0,
    July: 0,
    August: 0,
    September: 0,
    October: 0,
    November: 0,
    December: 0
  });
  const [targetExists, setTargetExists] = useState(false);
  const [fetchedTargetData, setFetchedTargetData] = useState(null);
  const alertShownRef = useRef({
    agents: false,
    targets: false
  });
  const parseDate = (dateString) => {
    const [year, month] = dateString.split("-");
    return {
      year,
      month: String(parseInt(month)).padStart(2, "0"),
      monthName: monthNames[parseInt(month) - 1]
    };
  };
  const formatToYearMonth = (year, month) => {
    return `${year}-${String(month).padStart(2, "0")}`;
  };
  const getMonthDateRange = (dateString) => {
    const { year, month } = parseDate(dateString);
    const startDate = new Date(year, parseInt(month) - 1, 1);
    const endDate = new Date(year, parseInt(month), 0);
    return {
      from_date: formatDate(startDate),
      to_date: formatDate(endDate)
    };
  };
  useEffect(() => {
    const fetchData = async () => {
      setInitialDataLoading(true);
      try {
        const [agentRes, employeeRes] = await Promise.all(
          [
            api.get("/agent/get-agent"),
            api.get("/employee")
          ]
        );
        const allAgents = agentRes.data || [];
        setAgents(
          allAgents.filter(
            (a) => a.agent_type === "agent" || a.agent_type === "both"
          )
        );
        setEmployees(employeeRes.data?.employee || []);
        alertShownRef.current.agents = false;
      } catch (err) {
        console.error("Error fetching agents/employees:", err);
        if (!alertShownRef.current.agents) {
          setAlertConfig({
            visibility: true,
            message: "Failed to load agents and employees",
            type: "error"
          });
          alertShownRef.current.agents = true;
          setTimeout(() => {
            alertShownRef.current.agents = false;
          }, 3e3);
        }
      } finally {
        setInitialDataLoading(false);
      }
    };
    fetchData();
  }, [reload]);
  useEffect(() => {
    const abortController = new AbortController();
    setDataLoading(true);
    const fetchTargets = async () => {
      try {
        const { from_date, to_date } = getMonthDateRange(selectedDate);
        let res;
        if (selectedType === "agents") {
          res = await api.get("/target/agents", {
            params: {
              from_date,
              to_date
            },
            signal: abortController.signal
          });
        } else {
          res = await api.get("/target/employee", {
            params: {
              from_date,
              to_date
            },
            signal: abortController.signal
          });
        }
        if (res.data.success && res.data.summaries) {
          setTargetData(res.data.summaries);
          alertShownRef.current.targets = false;
        } else {
          setTargetData([]);
        }
      } catch (err) {
        if (err.name !== "AbortError") {
          console.error("Error fetching targets:", err);
          if (!alertShownRef.current.targets) {
            alertShownRef.current.targets = true;
            setTimeout(() => {
              alertShownRef.current.targets = false;
            }, 3e3);
          }
          setTargetData([]);
        }
      } finally {
        if (!abortController.signal.aborted) {
          setDataLoading(false);
        }
      }
    };
    if (!initialDataLoading) {
      fetchTargets();
    }
    return () => {
      abortController.abort();
    };
  }, [selectedType, selectedDate, initialDataLoading, reload]);
  useEffect(() => {
    if (targetData.length > 0) {
      let filteredData = targetData;
      if (selectedId !== "all") {
        filteredData = targetData.filter(
          (item) => item.agent.id === selectedId
        );
      }
      const anyTargetExists = filteredData.some(
        (item) => item.agent.target.value !== "Not Set"
      );
      setTargetExists(anyTargetExists);
      const formattedData = filteredData.map((item) => {
        const hasTarget = item.agent.target.value !== "Not Set";
        const dropdownItems = [{ key: "update", label: "Edit Target" }];
        if (!hasTarget) {
          dropdownItems.unshift({ key: "set", label: "Set Target" });
        }
        const actionDropdown = /* @__PURE__ */ jsxDEV(
          Dropdown,
          {
            trigger: ["click"],
            menu: {
              items: dropdownItems,
              onClick: ({ key }) => {
                if (key === "set") {
                  setIsBulkMode(false);
                  setIsEditMode(false);
                  openSetDrawer(item);
                }
                if (key === "update") {
                  setIsBulkMode(false);
                  setIsEditMode(true);
                  openEditDrawer(item);
                }
              }
            },
            children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 258,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
            lineNumber: 240,
            columnNumber: 9
          },
          this
        );
        return {
          target_code: item?.target_code,
          name: item.agent.name,
          phone_number: item.agent.phone,
          actual_business: item?.metrics?.actual_business,
          target_difference: item?.metrics?.target_difference,
          target_remaining_digits: item?.metrics?.target_remaining_digits,
          target: item.agent?.target?.value,
          action: actionDropdown,
          _item: item
        };
      });
      setTableData(formattedData);
    } else {
      setTableData([]);
    }
  }, [selectedId, targetData]);
  const fetchTargetDetails = async (item) => {
    try {
      const { year } = parseDate(selectedDate);
      const res = await api.get(`/target/agent/${item.agent.id}`, {
        params: { year }
      });
      let monthData = null;
      if (res.data && res.data.length > 0) {
        const target = res.data[0];
        monthData = target.monthData || null;
      }
      setFetchedTargetData(monthData);
      return monthData;
    } catch (err) {
      console.error("Error fetching target details:", err);
      setFetchedTargetData(null);
      return null;
    }
  };
  const openSetDrawer = async (item) => {
    setSelectedPerson(item);
    setIsEditMode(false);
    setIsBulkMode(false);
    setEditTargetId(item.agent.id);
    const monthData = await fetchTargetDetails(item);
    const monthValues2 = {
      January: 0,
      February: 0,
      March: 0,
      April: 0,
      May: 0,
      June: 0,
      July: 0,
      August: 0,
      September: 0,
      October: 0,
      November: 0,
      December: 0
    };
    if (monthData) {
      Object.keys(monthValues2).forEach((month) => {
        monthValues2[month] = monthData[month] || 0;
      });
    }
    setMonthValues(monthValues2);
    setDrawerVisible(true);
  };
  const openEditDrawer = async (item) => {
    setSelectedPerson(item);
    setIsEditMode(true);
    setIsBulkMode(false);
    setEditTargetId(item.agent.id);
    const monthData = await fetchTargetDetails(item);
    const monthValues2 = {
      January: 0,
      February: 0,
      March: 0,
      April: 0,
      May: 0,
      June: 0,
      July: 0,
      August: 0,
      September: 0,
      October: 0,
      November: 0,
      December: 0
    };
    if (monthData) {
      Object.keys(monthValues2).forEach((month) => {
        monthValues2[month] = monthData[month] || 0;
      });
    }
    setMonthValues(monthValues2);
    setDrawerVisible(true);
  };
  const openBulkDrawer = () => {
    setIsBulkMode(true);
    setIsEditMode(false);
    setDrawerVisible(true);
    setMonthValues({
      January: 0,
      February: 0,
      March: 0,
      April: 0,
      May: 0,
      June: 0,
      July: 0,
      August: 0,
      September: 0,
      October: 0,
      November: 0,
      December: 0
    });
  };
  const handleMonthChange = (month, value) => {
    setMonthValues((prev) => ({
      ...prev,
      [month]: value === "" ? "" : Number(value)
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const { year } = parseDate(selectedDate);
      if (isBulkMode) {
        const agentIds = selectedType === "agents" ? agents.map((a) => a._id) : employees.map((e2) => e2._id);
        await api.patch(`/target/bulk`, {
          agentIds,
          year,
          monthValues
        });
      } else {
        await api.patch(
          `/target/agent/${editTargetId}?year=${year}`,
          monthValues
        );
      }
      setAlertConfig({
        visibility: true,
        message: isBulkMode ? "Bulk targets updated successfully" : isEditMode ? "Target updated successfully" : "Target set successfully",
        type: "success"
      });
      setDrawerVisible(false);
      setReload((prev) => prev + 1);
    } catch (err) {
      console.error("Submit failed", err);
      setAlertConfig({
        visibility: true,
        message: isBulkMode ? "Bulk update failed" : isEditMode ? "Update failed" : "Add failed",
        type: "error"
      });
    }
  };
  const getColumns = () => {
    return [
      { key: "target_code", header: "Target Code" },
      { key: "name", header: "Name" },
      { key: "phone_number", header: "Phone Number" },
      { key: "target", header: "Target" },
      { key: "actual_business", header: "Actual Business" },
      { key: "target_difference", header: "Target Difference" },
      { key: "target_remaining_digits", header: "Target Remaining Digits" },
      { key: "action", header: "Action" }
    ];
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
        lineNumber: 465,
        columnNumber: 10
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
          lineNumber: 466,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
          lineNumber: 470,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-6", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
          lineNumber: 480,
          columnNumber: 14
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Targets Management" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
            lineNumber: 482,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: openBulkDrawer,
              className: "flex items-center bg-violet-600 text-white px-4 py-2 rounded hover:bg-violet-700",
              children: [
                /* @__PURE__ */ jsxDEV(IoMdAdd, { className: "mr-2" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                  lineNumber: 487,
                  columnNumber: 15
                }, this),
                " Bulk Update Targets"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 483,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
          lineNumber: 481,
          columnNumber: 11
        }, this),
        initialDataLoading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center h-64", children: /* @__PURE__ */ jsxDEV(Loader, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
          lineNumber: 493,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
          lineNumber: 492,
          columnNumber: 11
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "my-6", children: /* @__PURE__ */ jsxDEV(
            Collapse,
            {
              items: [
                {
                  key: "1",
                  label: /* @__PURE__ */ jsxDEV("span", { className: "font-semibold text-gray-800 text-base", children: "Shortcut Keys" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                    lineNumber: 503,
                    columnNumber: 19
                  }, this),
                  children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-5 gap-4", children: [
                    /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: "/reports/target-commission",
                        className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-violet-500 hover:text-violet-600 transition-colors",
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            DollarOutlined,
                            {
                              className: "text-violet-500",
                              size: 30
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                              lineNumber: 513,
                              columnNumber: 29
                            },
                            this
                          ),
                          "Commission Report"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                        lineNumber: 509,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: "/reports/target-incentive",
                        className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-violet-500 hover:text-violet-600 transition-colors",
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            FileTextOutlined,
                            {
                              className: "text-violet-500",
                              size: 30
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                              lineNumber: 524,
                              columnNumber: 29
                            },
                            this
                          ),
                          "Incentive Report"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                        lineNumber: 520,
                        columnNumber: 27
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: "/payment-menu/payment-in-out-menu/pay-out-menu/salary-payment",
                        className: "flex text-base items-center gap-2 border  border-gray-200 rounded-lg px-4 py-2 text-gray-700 hover:border-violet-500 hover:text-violet-600 transition-colors",
                        children: [
                          /* @__PURE__ */ jsxDEV(FaMoneyBill, { className: "text-violet-500", size: 30 }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                            lineNumber: 543,
                            columnNumber: 29
                          }, this),
                          "Salary Payout"
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                        lineNumber: 539,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                    lineNumber: 508,
                    columnNumber: 19
                  }, this)
                }
              ],
              defaultActiveKey: ["1"],
              className: "rounded-lg border border-gray-200 bg-white shadow-sm"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 498,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
            lineNumber: 497,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 flex-wrap mb-6 items-end", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Type" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                lineNumber: 556,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  className: "p-2 border rounded w-full min-w-[150px]",
                  value: selectedType,
                  onChange: (e) => {
                    setSelectedType(e.target.value);
                    setSelectedId("all");
                  },
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "agents", children: "Agents" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                      lineNumber: 567,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "employees", children: "Employees" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                      lineNumber: 568,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                  lineNumber: 559,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 555,
              columnNumber: 17
            }, this),
            selectedType === "agents" && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Agent" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                lineNumber: 574,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  className: "p-2 border rounded w-full min-w-[200px]",
                  value: selectedId,
                  onChange: (e) => setSelectedId(e.target.value),
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "all", children: "All Agents" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                      lineNumber: 582,
                      columnNumber: 23
                    }, this),
                    agents.map(
                      (agent) => /* @__PURE__ */ jsxDEV("option", { value: agent._id, children: agent.name || "Unknown Agent" }, agent._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                        lineNumber: 584,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                  lineNumber: 577,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 573,
              columnNumber: 15
            }, this),
            selectedType === "employees" && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Employee" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                lineNumber: 594,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  className: "p-2 border rounded w-full min-w-[200px]",
                  value: selectedId,
                  onChange: (e) => setSelectedId(e.target.value),
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "all", children: "All Employees" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                      lineNumber: 602,
                      columnNumber: 23
                    }, this),
                    employees.map(
                      (employee) => /* @__PURE__ */ jsxDEV("option", { value: employee._id, children: employee.name || "Unknown Employee" }, employee._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                        lineNumber: 604,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                  lineNumber: 597,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 593,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Target Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                lineNumber: 613,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "month",
                  className: "p-2 border rounded w-full min-w-[150px]",
                  value: selectedDate,
                  onChange: (e) => setSelectedDate(e.target.value),
                  max: formatToYearMonth(currentYear, currentMonth)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                  lineNumber: 616,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 612,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
            lineNumber: 554,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "relative min-h-[200px]", children: [
            dataLoading && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-white bg-opacity-70 flex items-center justify-center z-10", children: /* @__PURE__ */ jsxDEV("div", { className: "animate-spin rounded-full h-10 w-10 border-4 border-violet-600 border-t-transparent" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 629,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 628,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                data: tableData,
                columns: getColumns(),
                exportedPdfName: "Target-Report",
                exportedFileName: "Target-Report.csv"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                lineNumber: 632,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
            lineNumber: 626,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
          lineNumber: 496,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
        lineNumber: 479,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
      lineNumber: 464,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("span", { children: isBulkMode ? "Bulk Update Targets" : isEditMode ? "Edit Target" : "Set Target" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
            lineNumber: 648,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setDrawerVisible(false),
              className: "text-gray-500 hover:text-gray-700",
              children: /* @__PURE__ */ jsxDEV(IoMdClose, { size: 20 }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                lineNumber: 659,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 655,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
          lineNumber: 647,
          columnNumber: 9
        }, this),
        placement: "right",
        closable: false,
        onClose: () => setDrawerVisible(false),
        open: drawerVisible,
        width: 500,
        className: "target-drawer",
        styles: {
          body: {
            padding: 0,
            overflow: "hidden"
          },
          header: {
            borderBottom: "1px solid #f0f0f0",
            padding: "16px 24px"
          }
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-4", children: [
          !isBulkMode && selectedPerson && /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block font-medium mb-1", children: "Target For" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 684,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full p-2 border rounded bg-gray-50", children: selectedPerson.agent.name }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 685,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
            lineNumber: 683,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 mb-4", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block font-medium mb-1", children: "Year" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                lineNumber: 693,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full p-2 border rounded bg-gray-50", children: parseDate(selectedDate).year }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                lineNumber: 694,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 692,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block font-medium mb-1", children: "Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                lineNumber: 699,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full p-2 border rounded bg-gray-50", children: parseDate(selectedDate).monthName }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                lineNumber: 700,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 698,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
            lineNumber: 691,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: monthNames.map(
            (month) => /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block font-medium mb-1", children: month }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                lineNumber: 709,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "mr-2", children: "₹" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                  lineNumber: 711,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    value: monthValues[month],
                    onChange: (e) => handleMonthChange(month, e.target.value),
                    className: "w-full p-2 border rounded",
                    min: "0",
                    placeholder: `Enter ${month} target`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                    lineNumber: 712,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
                lineNumber: 710,
                columnNumber: 19
              }, this)
            ] }, month, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 708,
              columnNumber: 15
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
            lineNumber: 706,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              type: "submit",
              className: "w-full bg-violet-600 text-white p-2 rounded hover:bg-violet-700 mt-6",
              children: isBulkMode ? "Update All Targets" : isEditMode ? "Update Target" : "Save Target"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
              lineNumber: 725,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
          lineNumber: 681,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
          lineNumber: 680,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
        lineNumber: 645,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx",
    lineNumber: 463,
    columnNumber: 5
  }, this);
};
_s(Target, "5eyfSwC1DVqRhzVMhVtM7EOpgAE=");
_c2 = Target;
export default Target;
var _c, _c2;
$RefreshReg$(_c, "GlobalSearchChangeHandler");
$RefreshReg$(_c2, "Target");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Target.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaVFZLFNBOE9BLFVBOU9BOzJCQWpRWjtBQUFvQkEsb0JBQWdCLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbkQsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxVQUFVQyxjQUFjO0FBQ2pDLFNBQVNDLFVBQVVDLFNBQVNDLGlCQUFpQjtBQUM3QyxPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxrQkFBa0JDLHNCQUFzQjtBQUNqRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msa0JBQWtCO0FBQzNCLE9BQU9DLGdCQUFnQjtBQUN2QixNQUFNQyxRQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLE1BQU1DLGNBQWNGLE1BQU1HLFlBQVk7QUFDdEMsTUFBTUMsZUFBZUMsT0FBT0wsTUFBTU0sU0FBUyxJQUFJLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDakUsTUFBTUMsbUJBQW1CLEdBQUdOLFdBQVcsSUFBSUUsWUFBWTtBQUN2RCxTQUFTSyxXQUFXQyxNQUFNO0FBQ3hCLFFBQU1DLE9BQU9ELEtBQUtQLFlBQVk7QUFDOUIsUUFBTVMsUUFBUSxJQUFJRixLQUFLSixTQUFTLElBQUksQ0FBQyxHQUFHTyxNQUFNLEVBQUU7QUFDaEQsUUFBTUMsTUFBTSxJQUFJSixLQUFLSyxRQUFRLENBQUMsR0FBR0YsTUFBTSxFQUFFO0FBQ3pDLFNBQU8sR0FBR0YsSUFBSSxJQUFJQyxLQUFLLElBQUlFLEdBQUc7QUFDaEM7QUFFQSxNQUFNRSxhQUFhO0FBQUEsRUFDakI7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFVO0FBRVYsTUFBTUMsNEJBQTRCQSxDQUFDQyxNQUFNO0FBQ3ZDLFFBQU0sRUFBRUMsTUFBTSxJQUFJRCxFQUFFRTtBQUNwQkMsZ0JBQWNGLEtBQUs7QUFDckI7QUFBRUcsS0FISUw7QUFJUixNQUFNTSxTQUFTQSxNQUFNO0FBQUFDLEtBQUE7QUFDbkIsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUk3QyxTQUFTLFFBQVE7QUFDekQsUUFBTSxDQUFDOEMsWUFBWUMsYUFBYSxJQUFJL0MsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ2dELFFBQVFDLFNBQVMsSUFBSWpELFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNrRCxXQUFXQyxZQUFZLElBQUluRCxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDb0QsV0FBV0MsWUFBWSxJQUFJckQsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ3NELGVBQWVDLGdCQUFnQixJQUFJdkQsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ3dELGFBQWFDLGNBQWMsSUFBSXpELFNBQVM7QUFBQSxJQUM3QzBELFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0Msb0JBQW9CQyxxQkFBcUIsSUFBSTlELFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUMrRCxhQUFhQyxjQUFjLElBQUloRSxTQUFTLEtBQUs7QUFDcEQsUUFBTSxDQUFDaUUsWUFBWUMsYUFBYSxJQUFJbEUsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ21FLFlBQVlDLGFBQWEsSUFBSXBFLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUNxRSxjQUFjQyxlQUFlLElBQUl0RSxTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDdUUsY0FBY0MsZUFBZSxJQUFJeEUsU0FBUzJCLGdCQUFnQjtBQUNqRSxRQUFNLENBQUM4QyxnQkFBZ0JDLGlCQUFpQixJQUFJMUUsU0FBUyxJQUFJO0FBQ3pELFFBQU0sQ0FBQzJFLFFBQVFDLFNBQVMsSUFBSTVFLFNBQVMsQ0FBQztBQUN0QyxRQUFNLENBQUM2RSxZQUFZQyxhQUFhLElBQUk5RSxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDK0UsYUFBYUMsY0FBYyxJQUFJaEYsU0FBUztBQUFBLElBQzdDaUYsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxJQUNWQyxPQUFPO0FBQUEsSUFDUEMsT0FBTztBQUFBLElBQ1BDLEtBQUs7QUFBQSxJQUNMQyxNQUFNO0FBQUEsSUFDTkMsTUFBTTtBQUFBLElBQ05DLFFBQVE7QUFBQSxJQUNSQyxXQUFXO0FBQUEsSUFDWEMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxJQUNWQyxVQUFVO0FBQUEsRUFDWixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUk5RixTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDK0YsbUJBQW1CQyxvQkFBb0IsSUFBSWhHLFNBQVMsSUFBSTtBQUUvRCxRQUFNaUcsZ0JBQWdCQyxPQUFPO0FBQUEsSUFDM0JsRCxRQUFRO0FBQUEsSUFDUm1ELFNBQVM7QUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNQyxZQUFZQSxDQUFDQyxlQUFlO0FBQ2hDLFVBQU0sQ0FBQ3ZFLE1BQU1DLEtBQUssSUFBSXNFLFdBQVdDLE1BQU0sR0FBRztBQUMxQyxXQUFPO0FBQUEsTUFDTHhFO0FBQUFBLE1BQ0FDLE9BQU9QLE9BQU8rRSxTQUFTeEUsS0FBSyxDQUFDLEVBQUVMLFNBQVMsR0FBRyxHQUFHO0FBQUEsTUFDOUM4RSxXQUFXckUsV0FBV29FLFNBQVN4RSxLQUFLLElBQUksQ0FBQztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUVBLFFBQU0wRSxvQkFBb0JBLENBQUMzRSxNQUFNQyxVQUFVO0FBQ3pDLFdBQU8sR0FBR0QsSUFBSSxJQUFJTixPQUFPTyxLQUFLLEVBQUVMLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFBQSxFQUNsRDtBQUVBLFFBQU1nRixvQkFBb0JBLENBQUNMLGVBQWU7QUFDeEMsVUFBTSxFQUFFdkUsTUFBTUMsTUFBTSxJQUFJcUUsVUFBVUMsVUFBVTtBQUM1QyxVQUFNTSxZQUFZLElBQUl2RixLQUFLVSxNQUFNeUUsU0FBU3hFLEtBQUssSUFBSSxHQUFHLENBQUM7QUFDdkQsVUFBTTZFLFVBQVUsSUFBSXhGLEtBQUtVLE1BQU15RSxTQUFTeEUsS0FBSyxHQUFHLENBQUM7QUFFakQsV0FBTztBQUFBLE1BQ0w4RSxXQUFXakYsV0FBVytFLFNBQVM7QUFBQSxNQUMvQkcsU0FBU2xGLFdBQVdnRixPQUFPO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBRUFHLFlBQVUsTUFBTTtBQUNkLFVBQU1DLFlBQVksWUFBWTtBQUM1QmxELDRCQUFzQixJQUFJO0FBQzFCLFVBQUk7QUFDRixjQUFNLENBQUNtRCxVQUFVQyxXQUFXLElBQUksTUFBTUMsUUFBUUM7QUFBQUEsVUFBSTtBQUFBLFlBQ2hEakgsSUFBSWtILElBQUksa0JBQWtCO0FBQUEsWUFDMUJsSCxJQUFJa0gsSUFBSSxXQUFXO0FBQUEsVUFBQztBQUFBLFFBQ3JCO0FBRUQsY0FBTUMsWUFBWUwsU0FBU00sUUFBUTtBQUNuQ3RFO0FBQUFBLFVBQ0VxRSxVQUFVRTtBQUFBQSxZQUNSLENBQUNDLE1BQU1BLEVBQUVDLGVBQWUsV0FBV0QsRUFBRUMsZUFBZTtBQUFBLFVBQ3REO0FBQUEsUUFDRjtBQUVBdkUscUJBQWErRCxZQUFZSyxNQUFNSSxZQUFZLEVBQUU7QUFFN0MxQixzQkFBYzJCLFFBQVE1RSxTQUFTO0FBQUEsTUFDakMsU0FBUzZFLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU0sb0NBQW9DRixHQUFHO0FBRXJELFlBQUksQ0FBQzVCLGNBQWMyQixRQUFRNUUsUUFBUTtBQUNqQ1MseUJBQWU7QUFBQSxZQUNiQyxZQUFZO0FBQUEsWUFDWkMsU0FBUztBQUFBLFlBQ1RDLE1BQU07QUFBQSxVQUNSLENBQUM7QUFDRHFDLHdCQUFjMkIsUUFBUTVFLFNBQVM7QUFFL0JnRixxQkFBVyxNQUFNO0FBQ2YvQiwwQkFBYzJCLFFBQVE1RSxTQUFTO0FBQUEsVUFDakMsR0FBRyxHQUFJO0FBQUEsUUFDVDtBQUFBLE1BQ0YsVUFBQztBQUNDYyw4QkFBc0IsS0FBSztBQUFBLE1BQzdCO0FBQUEsSUFDRjtBQUVBa0QsY0FBVTtBQUFBLEVBQ1osR0FBRyxDQUFDckMsTUFBTSxDQUFDO0FBRVhvQyxZQUFVLE1BQU07QUFDZCxVQUFNa0Isa0JBQWtCLElBQUlDLGdCQUFnQjtBQUU1Q2xFLG1CQUFlLElBQUk7QUFFbkIsVUFBTW1FLGVBQWUsWUFBWTtBQUMvQixVQUFJO0FBQ0YsY0FBTSxFQUFFdEIsV0FBV0MsUUFBUSxJQUFJSixrQkFBa0JuQyxZQUFZO0FBRTdELFlBQUk2RDtBQUNKLFlBQUl4RixpQkFBaUIsVUFBVTtBQUM3QndGLGdCQUFNLE1BQU1qSSxJQUFJa0gsSUFBSSxrQkFBa0I7QUFBQSxZQUNwQ2dCLFFBQVE7QUFBQSxjQUNOeEI7QUFBQUEsY0FDQUM7QUFBQUEsWUFDRjtBQUFBLFlBQ0F3QixRQUFRTCxnQkFBZ0JLO0FBQUFBLFVBQzFCLENBQUM7QUFBQSxRQUNILE9BQU87QUFDTEYsZ0JBQU0sTUFBTWpJLElBQUlrSCxJQUFJLG9CQUFvQjtBQUFBLFlBQ3RDZ0IsUUFBUTtBQUFBLGNBQ054QjtBQUFBQSxjQUNBQztBQUFBQSxZQUNGO0FBQUEsWUFDQXdCLFFBQVFMLGdCQUFnQks7QUFBQUEsVUFDMUIsQ0FBQztBQUFBLFFBQ0g7QUFFQSxZQUFJRixJQUFJYixLQUFLZ0IsV0FBV0gsSUFBSWIsS0FBS2lCLFdBQVc7QUFDMUMxRCx3QkFBY3NELElBQUliLEtBQUtpQixTQUFTO0FBQ2hDdkMsd0JBQWMyQixRQUFRekIsVUFBVTtBQUFBLFFBQ2xDLE9BQU87QUFDTHJCLHdCQUFjLEVBQUU7QUFBQSxRQUNsQjtBQUFBLE1BQ0YsU0FBUytDLEtBQUs7QUFDWixZQUFJQSxJQUFJWSxTQUFTLGNBQWM7QUFDN0JYLGtCQUFRQyxNQUFNLDJCQUEyQkYsR0FBRztBQUM1QyxjQUFJLENBQUM1QixjQUFjMkIsUUFBUXpCLFNBQVM7QUFDbENGLDBCQUFjMkIsUUFBUXpCLFVBQVU7QUFFaEM2Qix1QkFBVyxNQUFNO0FBQ2YvQiw0QkFBYzJCLFFBQVF6QixVQUFVO0FBQUEsWUFDbEMsR0FBRyxHQUFJO0FBQUEsVUFDVDtBQUNBckIsd0JBQWMsRUFBRTtBQUFBLFFBQ2xCO0FBQUEsTUFDRixVQUFDO0FBQ0MsWUFBSSxDQUFDbUQsZ0JBQWdCSyxPQUFPSSxTQUFTO0FBQ25DMUUseUJBQWUsS0FBSztBQUFBLFFBQ3RCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxRQUFJLENBQUNILG9CQUFvQjtBQUN2QnNFLG1CQUFhO0FBQUEsSUFDZjtBQUVBLFdBQU8sTUFBTTtBQUNYRixzQkFBZ0JVLE1BQU07QUFBQSxJQUN4QjtBQUFBLEVBQ0YsR0FBRyxDQUFDL0YsY0FBYzJCLGNBQWNWLG9CQUFvQmMsTUFBTSxDQUFDO0FBRTNEb0MsWUFBVSxNQUFNO0FBQ2QsUUFBSWxDLFdBQVcrRCxTQUFTLEdBQUc7QUFDekIsVUFBSUMsZUFBZWhFO0FBRW5CLFVBQUkvQixlQUFlLE9BQU87QUFDeEIrRix1QkFBZWhFLFdBQVcyQztBQUFBQSxVQUN4QixDQUFDc0IsU0FBU0EsS0FBS0MsTUFBTUMsT0FBT2xHO0FBQUFBLFFBQzlCO0FBQUEsTUFDRjtBQUVBLFlBQU1tRyxrQkFBa0JKLGFBQWFLO0FBQUFBLFFBQ25DLENBQUNKLFNBQVNBLEtBQUtDLE1BQU14RyxPQUFPRCxVQUFVO0FBQUEsTUFDeEM7QUFDQXdELHNCQUFnQm1ELGVBQWU7QUFFL0IsWUFBTUUsZ0JBQWdCTixhQUFhTyxJQUFJLENBQUNOLFNBQVM7QUFDL0MsY0FBTU8sWUFBWVAsS0FBS0MsTUFBTXhHLE9BQU9ELFVBQVU7QUFDOUMsY0FBTWdILGdCQUFnQixDQUFDLEVBQUVDLEtBQUssVUFBVUMsT0FBTyxjQUFjLENBQUM7QUFFOUQsWUFBSSxDQUFDSCxXQUFXO0FBQ2RDLHdCQUFjRyxRQUFRLEVBQUVGLEtBQUssT0FBT0MsT0FBTyxhQUFhLENBQUM7QUFBQSxRQUMzRDtBQUVBLGNBQU1FLGlCQUNKO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLENBQUMsT0FBTztBQUFBLFlBQ2pCLE1BQU07QUFBQSxjQUNKQyxPQUFPTDtBQUFBQSxjQUNQTSxTQUFTQSxDQUFDLEVBQUVMLElBQUksTUFBTTtBQUNwQixvQkFBSUEsUUFBUSxPQUFPO0FBQ2pCbkYsZ0NBQWMsS0FBSztBQUNuQkYsZ0NBQWMsS0FBSztBQUNuQjJGLGdDQUFjZixJQUFJO0FBQUEsZ0JBQ3BCO0FBQ0Esb0JBQUlTLFFBQVEsVUFBVTtBQUNwQm5GLGdDQUFjLEtBQUs7QUFDbkJGLGdDQUFjLElBQUk7QUFDbEI0RixpQ0FBZWhCLElBQUk7QUFBQSxnQkFDckI7QUFBQSxjQUNGO0FBQUEsWUFDRjtBQUFBLFlBRUEsaUNBQUMsWUFBUyxXQUFVLG9CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQztBQUFBO0FBQUEsVUFsQnRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW1CQTtBQUdGLGVBQU87QUFBQSxVQUNIaUIsYUFBYWpCLE1BQU1pQjtBQUFBQSxVQUNyQnRCLE1BQU1LLEtBQUtDLE1BQU1OO0FBQUFBLFVBQ2pCdUIsY0FBY2xCLEtBQUtDLE1BQU1rQjtBQUFBQSxVQUN6QkMsaUJBQWlCcEIsTUFBTXFCLFNBQVNEO0FBQUFBLFVBQ2hDRSxtQkFBbUJ0QixNQUFNcUIsU0FBU0M7QUFBQUEsVUFDbENDLHlCQUF5QnZCLE1BQU1xQixTQUFTRTtBQUFBQSxVQUN4QzlILFFBQVF1RyxLQUFLQyxPQUFPeEcsUUFBUUQ7QUFBQUEsVUFDNUJnSSxRQUFRWjtBQUFBQSxVQUNSYSxPQUFPekI7QUFBQUEsUUFDVDtBQUFBLE1BQ0YsQ0FBQztBQUVEekYsbUJBQWE4RixhQUFhO0FBQUEsSUFDNUIsT0FBTztBQUNMOUYsbUJBQWEsRUFBRTtBQUFBLElBQ2pCO0FBQUEsRUFDRixHQUFHLENBQUNQLFlBQVkrQixVQUFVLENBQUM7QUFFM0IsUUFBTTJGLHFCQUFxQixPQUFPMUIsU0FBUztBQUN6QyxRQUFJO0FBQ0YsWUFBTSxFQUFFaEgsS0FBSyxJQUFJc0UsVUFBVTdCLFlBQVk7QUFFdkMsWUFBTTZELE1BQU0sTUFBTWpJLElBQUlrSCxJQUFJLGlCQUFpQnlCLEtBQUtDLE1BQU1DLEVBQUUsSUFBSTtBQUFBLFFBQzFEWCxRQUFRLEVBQUV2RyxLQUFLO0FBQUEsTUFDakIsQ0FBQztBQUVELFVBQUkySSxZQUFZO0FBRWhCLFVBQUlyQyxJQUFJYixRQUFRYSxJQUFJYixLQUFLcUIsU0FBUyxHQUFHO0FBQ25DLGNBQU1yRyxTQUFTNkYsSUFBSWIsS0FBSyxDQUFDO0FBQ3pCa0Qsb0JBQVlsSSxPQUFPa0ksYUFBYTtBQUFBLE1BQ2xDO0FBRUF6RSwyQkFBcUJ5RSxTQUFTO0FBQzlCLGFBQU9BO0FBQUFBLElBQ1QsU0FBUzVDLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSxrQ0FBa0NGLEdBQUc7QUFDbkQ3QiwyQkFBcUIsSUFBSTtBQUN6QixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxRQUFNNkQsZ0JBQWdCLE9BQU9mLFNBQVM7QUFDcENwRSxzQkFBa0JvRSxJQUFJO0FBQ3RCNUUsa0JBQWMsS0FBSztBQUNuQkUsa0JBQWMsS0FBSztBQUNuQkUsb0JBQWdCd0UsS0FBS0MsTUFBTUMsRUFBRTtBQUU3QixVQUFNeUIsWUFBWSxNQUFNRCxtQkFBbUIxQixJQUFJO0FBRS9DLFVBQU0vRCxlQUFjO0FBQUEsTUFDbEJFLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsT0FBTztBQUFBLE1BQ1BDLE9BQU87QUFBQSxNQUNQQyxLQUFLO0FBQUEsTUFDTEMsTUFBTTtBQUFBLE1BQ05DLE1BQU07QUFBQSxNQUNOQyxRQUFRO0FBQUEsTUFDUkMsV0FBVztBQUFBLE1BQ1hDLFNBQVM7QUFBQSxNQUNUQyxVQUFVO0FBQUEsTUFDVkMsVUFBVTtBQUFBLElBQ1o7QUFFQSxRQUFJNkUsV0FBVztBQUNiQyxhQUFPQyxLQUFLNUYsWUFBVyxFQUFFNkYsUUFBUSxDQUFDN0ksVUFBVTtBQUMxQ2dELHFCQUFZaEQsS0FBSyxJQUFJMEksVUFBVTFJLEtBQUssS0FBSztBQUFBLE1BQzNDLENBQUM7QUFBQSxJQUNIO0FBRUFpRCxtQkFBZUQsWUFBVztBQUMxQnhCLHFCQUFpQixJQUFJO0FBQUEsRUFDdkI7QUFFQSxRQUFNdUcsaUJBQWlCLE9BQU9oQixTQUFTO0FBQ3JDcEUsc0JBQWtCb0UsSUFBSTtBQUN0QjVFLGtCQUFjLElBQUk7QUFDbEJFLGtCQUFjLEtBQUs7QUFDbkJFLG9CQUFnQndFLEtBQUtDLE1BQU1DLEVBQUU7QUFFN0IsVUFBTXlCLFlBQVksTUFBTUQsbUJBQW1CMUIsSUFBSTtBQUUvQyxVQUFNL0QsZUFBYztBQUFBLE1BQ2xCRSxTQUFTO0FBQUEsTUFDVEMsVUFBVTtBQUFBLE1BQ1ZDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsTUFDUEMsS0FBSztBQUFBLE1BQ0xDLE1BQU07QUFBQSxNQUNOQyxNQUFNO0FBQUEsTUFDTkMsUUFBUTtBQUFBLE1BQ1JDLFdBQVc7QUFBQSxNQUNYQyxTQUFTO0FBQUEsTUFDVEMsVUFBVTtBQUFBLE1BQ1ZDLFVBQVU7QUFBQSxJQUNaO0FBRUEsUUFBSTZFLFdBQVc7QUFDYkMsYUFBT0MsS0FBSzVGLFlBQVcsRUFBRTZGLFFBQVEsQ0FBQzdJLFVBQVU7QUFDMUNnRCxxQkFBWWhELEtBQUssSUFBSTBJLFVBQVUxSSxLQUFLLEtBQUs7QUFBQSxNQUMzQyxDQUFDO0FBQUEsSUFDSDtBQUVBaUQsbUJBQWVELFlBQVc7QUFDMUJ4QixxQkFBaUIsSUFBSTtBQUFBLEVBQ3ZCO0FBRUEsUUFBTXNILGlCQUFpQkEsTUFBTTtBQUMzQnpHLGtCQUFjLElBQUk7QUFDbEJGLGtCQUFjLEtBQUs7QUFDbkJYLHFCQUFpQixJQUFJO0FBRXJCeUIsbUJBQWU7QUFBQSxNQUNiQyxTQUFTO0FBQUEsTUFDVEMsVUFBVTtBQUFBLE1BQ1ZDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsTUFDUEMsS0FBSztBQUFBLE1BQ0xDLE1BQU07QUFBQSxNQUNOQyxNQUFNO0FBQUEsTUFDTkMsUUFBUTtBQUFBLE1BQ1JDLFdBQVc7QUFBQSxNQUNYQyxTQUFTO0FBQUEsTUFDVEMsVUFBVTtBQUFBLE1BQ1ZDLFVBQVU7QUFBQSxJQUNaLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTWtGLG9CQUFvQkEsQ0FBQy9JLE9BQU9PLFVBQVU7QUFDMUMwQyxtQkFBZSxDQUFDK0YsVUFBVTtBQUFBLE1BQ3hCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2hKLEtBQUssR0FBR08sVUFBVSxLQUFLLEtBQUswSSxPQUFPMUksS0FBSztBQUFBLElBQzNDLEVBQUU7QUFBQSxFQUNKO0FBR0EsUUFBTTJJLGVBQWUsT0FBTzVJLE1BQU07QUFDaENBLE1BQUU2SSxlQUFlO0FBRWpCLFFBQUk7QUFDRixZQUFNLEVBQUVwSixLQUFLLElBQUlzRSxVQUFVN0IsWUFBWTtBQUV2QyxVQUFJSixZQUFZO0FBQ2QsY0FBTWdILFdBQ0p2SSxpQkFBaUIsV0FDYkksT0FBT29HLElBQUksQ0FBQzNCLE1BQU1BLEVBQUUyRCxHQUFHLElBQ3ZCbEksVUFBVWtHLElBQUksQ0FBQy9HLE9BQU1BLEdBQUUrSSxHQUFHO0FBRWhDLGNBQU1qTCxJQUFJa0wsTUFBTSxnQkFBZ0I7QUFBQSxVQUM5QkY7QUFBQUEsVUFDQXJKO0FBQUFBLFVBQ0FpRDtBQUFBQSxRQUNGLENBQUM7QUFBQSxNQUNILE9BQU87QUFDTCxjQUFNNUUsSUFBSWtMO0FBQUFBLFVBQ1IsaUJBQWlCaEgsWUFBWSxTQUFTdkMsSUFBSTtBQUFBLFVBQzFDaUQ7QUFBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQXRCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVNRLGFBQ0wsc0NBQ0FGLGFBQ0EsZ0NBQ0E7QUFBQSxRQUNKTCxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0RMLHVCQUFpQixLQUFLO0FBQ3RCcUIsZ0JBQVUsQ0FBQ21HLFNBQVNBLE9BQU8sQ0FBQztBQUFBLElBQzlCLFNBQVNsRCxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0saUJBQWlCRixHQUFHO0FBQ2xDcEUscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBU1EsYUFDTCx1QkFDQUYsYUFDQSxrQkFDQTtBQUFBLFFBQ0pMLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU0wSCxhQUFhQSxNQUFNO0FBQ3ZCLFdBQU87QUFBQSxNQUNILEVBQUMvQixLQUFLLGVBQWVnQyxRQUFRLGNBQWE7QUFBQSxNQUM1QyxFQUFFaEMsS0FBSyxRQUFRZ0MsUUFBUSxPQUFPO0FBQUEsTUFDOUIsRUFBRWhDLEtBQUssZ0JBQWdCZ0MsUUFBUSxlQUFlO0FBQUEsTUFDOUMsRUFBRWhDLEtBQUssVUFBVWdDLFFBQVEsU0FBUztBQUFBLE1BQ2xDLEVBQUVoQyxLQUFLLG1CQUFtQmdDLFFBQVEsa0JBQWtCO0FBQUEsTUFDcEQsRUFBRWhDLEtBQUsscUJBQXFCZ0MsUUFBUSxvQkFBb0I7QUFBQSxNQUN4RCxFQUFFaEMsS0FBSywyQkFBMkJnQyxRQUFRLDBCQUEwQjtBQUFBLE1BQ3BFLEVBQUVoQyxLQUFLLFVBQVVnQyxRQUFRLFNBQVM7QUFBQSxJQUFDO0FBQUEsRUFFdkM7QUFFQSxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ1o7QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ1A7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLDZCQUE2Qm5KO0FBQUFBLFVBQzdCLFlBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1CO0FBQUEsTUFFbkI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1vQixZQUFZSTtBQUFBQSxVQUNsQixXQUFXSixZQUFZRTtBQUFBQSxVQUN2QixTQUFTRixZQUFZRztBQUFBQSxVQUNyQixTQUFTLE1BQ1BGLGVBQWUsQ0FBQ3NILFVBQVUsRUFBRSxHQUFHQSxNQUFNckgsWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLFFBTDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1HO0FBQUEsTUFHTCx1QkFBQyxTQUFJLFdBQVUsaUJBQ1Y7QUFBQSwrQkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVc7QUFBQSxRQUNkLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSwwQkFBeUIsa0NBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsVUFDekQ7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVNtSDtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUVWO0FBQUEsdUNBQUMsV0FBUSxXQUFVLFVBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlCO0FBQUEsZ0JBQUc7QUFBQTtBQUFBO0FBQUEsWUFKOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBRUNoSCxxQkFDQyx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQU8sS0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsSUFFQSxtQ0FDRTtBQUFBLGlDQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPO0FBQUEsZ0JBQ0w7QUFBQSxrQkFDRTBGLEtBQUs7QUFBQSxrQkFDTEMsT0FDRSx1QkFBQyxVQUFLLFdBQVUseUNBQXdDLDZCQUF4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUZnQyxVQUNFLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLElBQUc7QUFBQSx3QkFDSCxXQUFVO0FBQUEsd0JBRVY7QUFBQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxXQUFVO0FBQUEsOEJBQ1YsTUFBTTtBQUFBO0FBQUEsNEJBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUVXO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVNBO0FBQUEsb0JBRUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsSUFBRztBQUFBLHdCQUNILFdBQVU7QUFBQSx3QkFFVjtBQUFBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFdBQVU7QUFBQSw4QkFDVixNQUFNO0FBQUE7QUFBQSw0QkFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBRVc7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFOYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBU0E7QUFBQSxvQkFVQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxJQUFHO0FBQUEsd0JBQ0gsV0FBVTtBQUFBLHdCQUVWO0FBQUEsaURBQUMsZUFBWSxXQUFVLG1CQUFrQixNQUFNLE1BQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWtEO0FBQUEsMEJBQUc7QUFBQTtBQUFBO0FBQUEsc0JBSnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNQTtBQUFBLHVCQXJDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXNDQTtBQUFBLGdCQUVKO0FBQUEsY0FBQztBQUFBLGNBRUgsa0JBQWtCLENBQUMsR0FBRztBQUFBLGNBQ3RCLFdBQVU7QUFBQTtBQUFBLFlBckRaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXFEa0UsS0F0RHBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0RBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyxvQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE9BQU81STtBQUFBQSxrQkFDUCxVQUFVLENBQUNQLE1BQU07QUFDZlEsb0NBQWdCUixFQUFFRSxPQUFPRCxLQUFLO0FBQzlCUyxrQ0FBYyxLQUFLO0FBQUEsa0JBQ3JCO0FBQUEsa0JBRUE7QUFBQSwyQ0FBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkI7QUFBQSxvQkFDN0IsdUJBQUMsWUFBTyxPQUFNLGFBQVkseUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW1DO0FBQUE7QUFBQTtBQUFBLGdCQVRyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FVQTtBQUFBLGlCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZUE7QUFBQSxZQUVDSCxpQkFBaUIsWUFDaEIsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MscUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixPQUFPRTtBQUFBQSxrQkFDUCxVQUFVLENBQUNULE1BQU1VLGNBQWNWLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxrQkFFN0M7QUFBQSwyQ0FBQyxZQUFPLE9BQU0sT0FBTSwwQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOEI7QUFBQSxvQkFDN0JVLE9BQU9vRztBQUFBQSxzQkFBSSxDQUFDTCxVQUNYLHVCQUFDLFlBQXVCLE9BQU9BLE1BQU1xQyxLQUNsQ3JDLGdCQUFNTixRQUFRLG1CQURKTSxNQUFNcUMsS0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQTtBQUFBLGdCQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdBO0FBQUEsaUJBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUdEeEksaUJBQWlCLGVBQ2hCLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHdCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsT0FBT0U7QUFBQUEsa0JBQ1AsVUFBVSxDQUFDVCxNQUFNVSxjQUFjVixFQUFFRSxPQUFPRCxLQUFLO0FBQUEsa0JBRTdDO0FBQUEsMkNBQUMsWUFBTyxPQUFNLE9BQU0sNkJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUEsb0JBQ2hDWSxVQUFVa0c7QUFBQUEsc0JBQUksQ0FBQ3pCLGFBQ2QsdUJBQUMsWUFBMEIsT0FBT0EsU0FBU3lELEtBQ3hDekQsbUJBQVNjLFFBQVEsc0JBRFBkLFNBQVN5RCxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBO0FBQUEsZ0JBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBV0E7QUFBQSxpQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFlBR0YsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBTzdHO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ2xDLE1BQU1tQyxnQkFBZ0JuQyxFQUFFRSxPQUFPRCxLQUFLO0FBQUEsa0JBQy9DLEtBQUttRSxrQkFBa0JwRixhQUFhRSxZQUFZO0FBQUE7QUFBQSxnQkFMbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS29EO0FBQUEsaUJBVHREO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQSxlQXJFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNFQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUNad0M7QUFBQUEsMkJBQ0MsdUJBQUMsU0FBSSxXQUFVLGlGQUNiLGlDQUFDLFNBQUksV0FBVSx5RkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRyxLQUR2RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFRjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQU1YO0FBQUFBLGdCQUNOLFNBQVNrSSxXQUFXO0FBQUEsZ0JBQ3BCLGlCQUFnQjtBQUFBLGdCQUNoQixrQkFBaUI7QUFBQTtBQUFBLGNBSm5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlzQztBQUFBLGVBVnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQTlJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0lBO0FBQUEsV0FoS0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtLQTtBQUFBLFNBakxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrTEE7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUNFLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLGlDQUFDLFVBQ0VuSCx1QkFDRyx3QkFDQUYsYUFDQSxnQkFDQSxnQkFMTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNVixpQkFBaUIsS0FBSztBQUFBLGNBQ3JDLFdBQVU7QUFBQSxjQUVWLGlDQUFDLGFBQVUsTUFBTSxNQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQjtBQUFBO0FBQUEsWUFKdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxhQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQTtBQUFBLFFBRUYsV0FBVTtBQUFBLFFBQ1YsVUFBVTtBQUFBLFFBQ1YsU0FBUyxNQUFNQSxpQkFBaUIsS0FBSztBQUFBLFFBQ3JDLE1BQU1EO0FBQUFBLFFBQ04sT0FBTztBQUFBLFFBQ1AsV0FBVTtBQUFBLFFBQ1YsUUFBUTtBQUFBLFVBQ05tSSxNQUFNO0FBQUEsWUFDSkMsU0FBUztBQUFBLFlBQ1RDLFVBQVU7QUFBQSxVQUNaO0FBQUEsVUFDQUosUUFBUTtBQUFBLFlBQ05LLGNBQWM7QUFBQSxZQUNkRixTQUFTO0FBQUEsVUFDWDtBQUFBLFFBQ0Y7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSxPQUNiLGlDQUFDLFVBQUssVUFBVVQsY0FBYyxXQUFVLGFBQ3JDO0FBQUEsV0FBQzlHLGNBQWNNLGtCQUNkLHVCQUFDLFNBQ0M7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsMEJBQXlCLDBCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRDtBQUFBLFlBQ3BELHVCQUFDLFNBQUksV0FBVSx3Q0FDWkEseUJBQWVzRSxNQUFNTixRQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUtBO0FBQUEsVUFHRix1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLDBCQUF5QixvQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEM7QUFBQSxjQUM5Qyx1QkFBQyxTQUFJLFdBQVUsd0NBQ1pyQyxvQkFBVTdCLFlBQVksRUFBRXpDLFFBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLDBCQUF5QixxQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0M7QUFBQSxjQUMvQyx1QkFBQyxTQUFJLFdBQVUsd0NBQ1pzRSxvQkFBVTdCLFlBQVksRUFBRWlDLGFBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ1pyRSxxQkFBV2lIO0FBQUFBLFlBQUksQ0FBQ3JILFVBQ2YsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSwwQkFBMEJBLG1CQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpRDtBQUFBLGNBQ2pELHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHVDQUFDLFVBQUssV0FBVSxRQUFPLGlCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QjtBQUFBLGdCQUN4QjtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBT2dELFlBQVloRCxLQUFLO0FBQUEsb0JBQ3hCLFVBQVUsQ0FBQ00sTUFBTXlJLGtCQUFrQi9JLE9BQU9NLEVBQUVFLE9BQU9ELEtBQUs7QUFBQSxvQkFDeEQsV0FBVTtBQUFBLG9CQUNWLEtBQUk7QUFBQSxvQkFDSixhQUFhLFNBQVNQLEtBQUs7QUFBQTtBQUFBLGtCQU43QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTXVDO0FBQUEsbUJBUnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxpQkFaUUEsT0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUEsVUFDRCxLQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUVUb0MsdUJBQ0csdUJBQ0FGLGFBQ0Esa0JBQ0E7QUFBQTtBQUFBLFlBUk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxhQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBc0RBLEtBdkRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF3REE7QUFBQTtBQUFBLE1BM0ZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTRGQTtBQUFBLE9BbFJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtUkE7QUFFSjtBQUFFdEIsR0F2ckJJRCxRQUFNO0FBQUFtSixNQUFObko7QUF5ckJOLGVBQWVBO0FBQU8sSUFBQUQsSUFBQW9KO0FBQUFDLGFBQUFySixJQUFBO0FBQUFxSixhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJOYXZiYXIiLCJTaWRlYmFyIiwiYXBpIiwiRGF0YVRhYmxlIiwiRHJvcGRvd24iLCJEcmF3ZXIiLCJJb01kTW9yZSIsIklvTWRBZGQiLCJJb01kQ2xvc2UiLCJDdXN0b21BbGVydERpYWxvZyIsIkxvYWRlciIsIkNvbGxhcHNlIiwiTGluayIsIkZpbGVUZXh0T3V0bGluZWQiLCJEb2xsYXJPdXRsaW5lZCIsIkZhTW9uZXlCaWxsIiwiTWRQYXltZW50cyIsIkJyZWFkY3J1bWIiLCJ0b2RheSIsIkRhdGUiLCJjdXJyZW50WWVhciIsImdldEZ1bGxZZWFyIiwiY3VycmVudE1vbnRoIiwiU3RyaW5nIiwiZ2V0TW9udGgiLCJwYWRTdGFydCIsImN1cnJlbnRZZWFyTW9udGgiLCJmb3JtYXREYXRlIiwiZGF0ZSIsInllYXIiLCJtb250aCIsInNsaWNlIiwiZGF5IiwiZ2V0RGF0ZSIsIm1vbnRoTmFtZXMiLCJHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyIiwiZSIsInZhbHVlIiwidGFyZ2V0Iiwic2V0U2VhcmNoVGV4dCIsIl9jIiwiVGFyZ2V0IiwiX3MiLCJzZWxlY3RlZFR5cGUiLCJzZXRTZWxlY3RlZFR5cGUiLCJzZWxlY3RlZElkIiwic2V0U2VsZWN0ZWRJZCIsImFnZW50cyIsInNldEFnZW50cyIsImVtcGxveWVlcyIsInNldEVtcGxveWVlcyIsInRhYmxlRGF0YSIsInNldFRhYmxlRGF0YSIsImRyYXdlclZpc2libGUiLCJzZXREcmF3ZXJWaXNpYmxlIiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsImluaXRpYWxEYXRhTG9hZGluZyIsInNldEluaXRpYWxEYXRhTG9hZGluZyIsImRhdGFMb2FkaW5nIiwic2V0RGF0YUxvYWRpbmciLCJpc0VkaXRNb2RlIiwic2V0SXNFZGl0TW9kZSIsImlzQnVsa01vZGUiLCJzZXRJc0J1bGtNb2RlIiwiZWRpdFRhcmdldElkIiwic2V0RWRpdFRhcmdldElkIiwic2VsZWN0ZWREYXRlIiwic2V0U2VsZWN0ZWREYXRlIiwic2VsZWN0ZWRQZXJzb24iLCJzZXRTZWxlY3RlZFBlcnNvbiIsInJlbG9hZCIsInNldFJlbG9hZCIsInRhcmdldERhdGEiLCJzZXRUYXJnZXREYXRhIiwibW9udGhWYWx1ZXMiLCJzZXRNb250aFZhbHVlcyIsIkphbnVhcnkiLCJGZWJydWFyeSIsIk1hcmNoIiwiQXByaWwiLCJNYXkiLCJKdW5lIiwiSnVseSIsIkF1Z3VzdCIsIlNlcHRlbWJlciIsIk9jdG9iZXIiLCJOb3ZlbWJlciIsIkRlY2VtYmVyIiwidGFyZ2V0RXhpc3RzIiwic2V0VGFyZ2V0RXhpc3RzIiwiZmV0Y2hlZFRhcmdldERhdGEiLCJzZXRGZXRjaGVkVGFyZ2V0RGF0YSIsImFsZXJ0U2hvd25SZWYiLCJ1c2VSZWYiLCJ0YXJnZXRzIiwicGFyc2VEYXRlIiwiZGF0ZVN0cmluZyIsInNwbGl0IiwicGFyc2VJbnQiLCJtb250aE5hbWUiLCJmb3JtYXRUb1llYXJNb250aCIsImdldE1vbnRoRGF0ZVJhbmdlIiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJ1c2VFZmZlY3QiLCJmZXRjaERhdGEiLCJhZ2VudFJlcyIsImVtcGxveWVlUmVzIiwiUHJvbWlzZSIsImFsbCIsImdldCIsImFsbEFnZW50cyIsImRhdGEiLCJmaWx0ZXIiLCJhIiwiYWdlbnRfdHlwZSIsImVtcGxveWVlIiwiY3VycmVudCIsImVyciIsImNvbnNvbGUiLCJlcnJvciIsInNldFRpbWVvdXQiLCJhYm9ydENvbnRyb2xsZXIiLCJBYm9ydENvbnRyb2xsZXIiLCJmZXRjaFRhcmdldHMiLCJyZXMiLCJwYXJhbXMiLCJzaWduYWwiLCJzdWNjZXNzIiwic3VtbWFyaWVzIiwibmFtZSIsImFib3J0ZWQiLCJhYm9ydCIsImxlbmd0aCIsImZpbHRlcmVkRGF0YSIsIml0ZW0iLCJhZ2VudCIsImlkIiwiYW55VGFyZ2V0RXhpc3RzIiwic29tZSIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJoYXNUYXJnZXQiLCJkcm9wZG93bkl0ZW1zIiwia2V5IiwibGFiZWwiLCJ1bnNoaWZ0IiwiYWN0aW9uRHJvcGRvd24iLCJpdGVtcyIsIm9uQ2xpY2siLCJvcGVuU2V0RHJhd2VyIiwib3BlbkVkaXREcmF3ZXIiLCJ0YXJnZXRfY29kZSIsInBob25lX251bWJlciIsInBob25lIiwiYWN0dWFsX2J1c2luZXNzIiwibWV0cmljcyIsInRhcmdldF9kaWZmZXJlbmNlIiwidGFyZ2V0X3JlbWFpbmluZ19kaWdpdHMiLCJhY3Rpb24iLCJfaXRlbSIsImZldGNoVGFyZ2V0RGV0YWlscyIsIm1vbnRoRGF0YSIsIk9iamVjdCIsImtleXMiLCJmb3JFYWNoIiwib3BlbkJ1bGtEcmF3ZXIiLCJoYW5kbGVNb250aENoYW5nZSIsInByZXYiLCJOdW1iZXIiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImFnZW50SWRzIiwiX2lkIiwicGF0Y2giLCJnZXRDb2x1bW5zIiwiaGVhZGVyIiwiY2hpbGRyZW4iLCJib2R5IiwicGFkZGluZyIsIm92ZXJmbG93IiwiYm9yZGVyQm90dG9tIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlRhcmdldC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdXNlUmVmIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBEcm9wZG93biwgRHJhd2VyIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUsIElvTWRBZGQsIElvTWRDbG9zZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCBMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBDb2xsYXBzZSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBGaWxlVGV4dE91dGxpbmVkLCBEb2xsYXJPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgeyBGYU1vbmV5QmlsbCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBNZFBheW1lbnRzIH0gZnJvbSBcInJlYWN0LWljb25zL21kXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG5jb25zdCBjdXJyZW50WWVhciA9IHRvZGF5LmdldEZ1bGxZZWFyKCk7XHJcbmNvbnN0IGN1cnJlbnRNb250aCA9IFN0cmluZyh0b2RheS5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG5jb25zdCBjdXJyZW50WWVhck1vbnRoID0gYCR7Y3VycmVudFllYXJ9LSR7Y3VycmVudE1vbnRofWA7XHJcbmZ1bmN0aW9uIGZvcm1hdERhdGUoZGF0ZSkge1xyXG4gIGNvbnN0IHllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XHJcbiAgY29uc3QgbW9udGggPSBgMCR7ZGF0ZS5nZXRNb250aCgpICsgMX1gLnNsaWNlKC0yKTtcclxuICBjb25zdCBkYXkgPSBgMCR7ZGF0ZS5nZXREYXRlKCl9YC5zbGljZSgtMik7XHJcbiAgcmV0dXJuIGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fWA7XHJcbn1cclxuXHJcbmNvbnN0IG1vbnRoTmFtZXMgPSBbXHJcbiAgXCJKYW51YXJ5XCIsXHJcbiAgXCJGZWJydWFyeVwiLFxyXG4gIFwiTWFyY2hcIixcclxuICBcIkFwcmlsXCIsXHJcbiAgXCJNYXlcIixcclxuICBcIkp1bmVcIixcclxuICBcIkp1bHlcIixcclxuICBcIkF1Z3VzdFwiLFxyXG4gIFwiU2VwdGVtYmVyXCIsXHJcbiAgXCJPY3RvYmVyXCIsXHJcbiAgXCJOb3ZlbWJlclwiLFxyXG4gIFwiRGVjZW1iZXJcIixcclxuXTtcclxuICBjb25zdCBHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbiAgfTtcclxuY29uc3QgVGFyZ2V0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtzZWxlY3RlZFR5cGUsIHNldFNlbGVjdGVkVHlwZV0gPSB1c2VTdGF0ZShcImFnZW50c1wiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRJZCwgc2V0U2VsZWN0ZWRJZF0gPSB1c2VTdGF0ZShcImFsbFwiKTtcclxuICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3RhYmxlRGF0YSwgc2V0VGFibGVEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZHJhd2VyVmlzaWJsZSwgc2V0RHJhd2VyVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiXCIsXHJcbiAgICB0eXBlOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtpbml0aWFsRGF0YUxvYWRpbmcsIHNldEluaXRpYWxEYXRhTG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbZGF0YUxvYWRpbmcsIHNldERhdGFMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNFZGl0TW9kZSwgc2V0SXNFZGl0TW9kZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzQnVsa01vZGUsIHNldElzQnVsa01vZGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlZGl0VGFyZ2V0SWQsIHNldEVkaXRUYXJnZXRJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWREYXRlLCBzZXRTZWxlY3RlZERhdGVdID0gdXNlU3RhdGUoY3VycmVudFllYXJNb250aCk7XHJcbiAgY29uc3QgW3NlbGVjdGVkUGVyc29uLCBzZXRTZWxlY3RlZFBlcnNvbl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbcmVsb2FkLCBzZXRSZWxvYWRdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW3RhcmdldERhdGEsIHNldFRhcmdldERhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFttb250aFZhbHVlcywgc2V0TW9udGhWYWx1ZXNdID0gdXNlU3RhdGUoe1xyXG4gICAgSmFudWFyeTogMCxcclxuICAgIEZlYnJ1YXJ5OiAwLFxyXG4gICAgTWFyY2g6IDAsXHJcbiAgICBBcHJpbDogMCxcclxuICAgIE1heTogMCxcclxuICAgIEp1bmU6IDAsXHJcbiAgICBKdWx5OiAwLFxyXG4gICAgQXVndXN0OiAwLFxyXG4gICAgU2VwdGVtYmVyOiAwLFxyXG4gICAgT2N0b2JlcjogMCxcclxuICAgIE5vdmVtYmVyOiAwLFxyXG4gICAgRGVjZW1iZXI6IDAsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3RhcmdldEV4aXN0cywgc2V0VGFyZ2V0RXhpc3RzXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZmV0Y2hlZFRhcmdldERhdGEsIHNldEZldGNoZWRUYXJnZXREYXRhXSA9IHVzZVN0YXRlKG51bGwpO1xyXG5cclxuICBjb25zdCBhbGVydFNob3duUmVmID0gdXNlUmVmKHtcclxuICAgIGFnZW50czogZmFsc2UsXHJcbiAgICB0YXJnZXRzOiBmYWxzZSxcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcGFyc2VEYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIGNvbnN0IFt5ZWFyLCBtb250aF0gPSBkYXRlU3RyaW5nLnNwbGl0KFwiLVwiKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHllYXIsXHJcbiAgICAgIG1vbnRoOiBTdHJpbmcocGFyc2VJbnQobW9udGgpKS5wYWRTdGFydCgyLCBcIjBcIiksXHJcbiAgICAgIG1vbnRoTmFtZTogbW9udGhOYW1lc1twYXJzZUludChtb250aCkgLSAxXSxcclxuICAgIH07XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0VG9ZZWFyTW9udGggPSAoeWVhciwgbW9udGgpID0+IHtcclxuICAgIHJldHVybiBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0TW9udGhEYXRlUmFuZ2UgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgeyB5ZWFyLCBtb250aCB9ID0gcGFyc2VEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgY29uc3Qgc3RhcnREYXRlID0gbmV3IERhdGUoeWVhciwgcGFyc2VJbnQobW9udGgpIC0gMSwgMSk7XHJcbiAgICBjb25zdCBlbmREYXRlID0gbmV3IERhdGUoeWVhciwgcGFyc2VJbnQobW9udGgpLCAwKTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBmcm9tX2RhdGU6IGZvcm1hdERhdGUoc3RhcnREYXRlKSxcclxuICAgICAgdG9fZGF0ZTogZm9ybWF0RGF0ZShlbmREYXRlKSxcclxuICAgIH07XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgc2V0SW5pdGlhbERhdGFMb2FkaW5nKHRydWUpO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IFthZ2VudFJlcywgZW1wbG95ZWVSZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgYXBpLmdldChcIi9hZ2VudC9nZXQtYWdlbnRcIiksXHJcbiAgICAgICAgICBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpLFxyXG4gICAgICAgIF0pO1xyXG5cclxuICAgICAgICBjb25zdCBhbGxBZ2VudHMgPSBhZ2VudFJlcy5kYXRhIHx8IFtdO1xyXG4gICAgICAgIHNldEFnZW50cyhcclxuICAgICAgICAgIGFsbEFnZW50cy5maWx0ZXIoXHJcbiAgICAgICAgICAgIChhKSA9PiBhLmFnZW50X3R5cGUgPT09IFwiYWdlbnRcIiB8fCBhLmFnZW50X3R5cGUgPT09IFwiYm90aFwiXHJcbiAgICAgICAgICApXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgc2V0RW1wbG95ZWVzKGVtcGxveWVlUmVzLmRhdGE/LmVtcGxveWVlIHx8IFtdKTtcclxuXHJcbiAgICAgICAgYWxlcnRTaG93blJlZi5jdXJyZW50LmFnZW50cyA9IGZhbHNlO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWdlbnRzL2VtcGxveWVlczpcIiwgZXJyKTtcclxuXHJcbiAgICAgICAgaWYgKCFhbGVydFNob3duUmVmLmN1cnJlbnQuYWdlbnRzKSB7XHJcbiAgICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGxvYWQgYWdlbnRzIGFuZCBlbXBsb3llZXNcIixcclxuICAgICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBhbGVydFNob3duUmVmLmN1cnJlbnQuYWdlbnRzID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgYWxlcnRTaG93blJlZi5jdXJyZW50LmFnZW50cyA9IGZhbHNlO1xyXG4gICAgICAgICAgfSwgMzAwMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldEluaXRpYWxEYXRhTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hEYXRhKCk7XHJcbiAgfSwgW3JlbG9hZF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xyXG5cclxuICAgIHNldERhdGFMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgIGNvbnN0IGZldGNoVGFyZ2V0cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCB7IGZyb21fZGF0ZSwgdG9fZGF0ZSB9ID0gZ2V0TW9udGhEYXRlUmFuZ2Uoc2VsZWN0ZWREYXRlKTtcclxuXHJcbiAgICAgICAgbGV0IHJlcztcclxuICAgICAgICBpZiAoc2VsZWN0ZWRUeXBlID09PSBcImFnZW50c1wiKSB7XHJcbiAgICAgICAgICByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL3RhcmdldC9hZ2VudHNcIiwge1xyXG4gICAgICAgICAgICBwYXJhbXM6IHtcclxuICAgICAgICAgICAgICBmcm9tX2RhdGUsXHJcbiAgICAgICAgICAgICAgdG9fZGF0ZSxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2lnbmFsOiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvdGFyZ2V0L2VtcGxveWVlXCIsIHtcclxuICAgICAgICAgICAgcGFyYW1zOiB7XHJcbiAgICAgICAgICAgICAgZnJvbV9kYXRlLFxyXG4gICAgICAgICAgICAgIHRvX2RhdGUsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNpZ25hbDogYWJvcnRDb250cm9sbGVyLnNpZ25hbCxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaWYgKHJlcy5kYXRhLnN1Y2Nlc3MgJiYgcmVzLmRhdGEuc3VtbWFyaWVzKSB7XHJcbiAgICAgICAgICBzZXRUYXJnZXREYXRhKHJlcy5kYXRhLnN1bW1hcmllcyk7XHJcbiAgICAgICAgICBhbGVydFNob3duUmVmLmN1cnJlbnQudGFyZ2V0cyA9IGZhbHNlO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRUYXJnZXREYXRhKFtdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGlmIChlcnIubmFtZSAhPT0gXCJBYm9ydEVycm9yXCIpIHtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB0YXJnZXRzOlwiLCBlcnIpO1xyXG4gICAgICAgICAgaWYgKCFhbGVydFNob3duUmVmLmN1cnJlbnQudGFyZ2V0cykge1xyXG4gICAgICAgICAgICBhbGVydFNob3duUmVmLmN1cnJlbnQudGFyZ2V0cyA9IHRydWU7XHJcblxyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICBhbGVydFNob3duUmVmLmN1cnJlbnQudGFyZ2V0cyA9IGZhbHNlO1xyXG4gICAgICAgICAgICB9LCAzMDAwKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHNldFRhcmdldERhdGEoW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBpZiAoIWFib3J0Q29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xyXG4gICAgICAgICAgc2V0RGF0YUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBpZiAoIWluaXRpYWxEYXRhTG9hZGluZykge1xyXG4gICAgICBmZXRjaFRhcmdldHMoKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICBhYm9ydENvbnRyb2xsZXIuYWJvcnQoKTtcclxuICAgIH07XHJcbiAgfSwgW3NlbGVjdGVkVHlwZSwgc2VsZWN0ZWREYXRlLCBpbml0aWFsRGF0YUxvYWRpbmcsIHJlbG9hZF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHRhcmdldERhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICBsZXQgZmlsdGVyZWREYXRhID0gdGFyZ2V0RGF0YTtcclxuXHJcbiAgICAgIGlmIChzZWxlY3RlZElkICE9PSBcImFsbFwiKSB7XHJcbiAgICAgICAgZmlsdGVyZWREYXRhID0gdGFyZ2V0RGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAoaXRlbSkgPT4gaXRlbS5hZ2VudC5pZCA9PT0gc2VsZWN0ZWRJZFxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IGFueVRhcmdldEV4aXN0cyA9IGZpbHRlcmVkRGF0YS5zb21lKFxyXG4gICAgICAgIChpdGVtKSA9PiBpdGVtLmFnZW50LnRhcmdldC52YWx1ZSAhPT0gXCJOb3QgU2V0XCJcclxuICAgICAgKTtcclxuICAgICAgc2V0VGFyZ2V0RXhpc3RzKGFueVRhcmdldEV4aXN0cyk7XHJcblxyXG4gICAgICBjb25zdCBmb3JtYXR0ZWREYXRhID0gZmlsdGVyZWREYXRhLm1hcCgoaXRlbSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGhhc1RhcmdldCA9IGl0ZW0uYWdlbnQudGFyZ2V0LnZhbHVlICE9PSBcIk5vdCBTZXRcIjtcclxuICAgICAgICBjb25zdCBkcm9wZG93bkl0ZW1zID0gW3sga2V5OiBcInVwZGF0ZVwiLCBsYWJlbDogXCJFZGl0IFRhcmdldFwiIH1dO1xyXG5cclxuICAgICAgICBpZiAoIWhhc1RhcmdldCkge1xyXG4gICAgICAgICAgZHJvcGRvd25JdGVtcy51bnNoaWZ0KHsga2V5OiBcInNldFwiLCBsYWJlbDogXCJTZXQgVGFyZ2V0XCIgfSk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBhY3Rpb25Ecm9wZG93biA9IChcclxuICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgIGl0ZW1zOiBkcm9wZG93bkl0ZW1zLFxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s6ICh7IGtleSB9KSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoa2V5ID09PSBcInNldFwiKSB7XHJcbiAgICAgICAgICAgICAgICAgIHNldElzQnVsa01vZGUoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICBzZXRJc0VkaXRNb2RlKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgb3BlblNldERyYXdlcihpdGVtKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlmIChrZXkgPT09IFwidXBkYXRlXCIpIHtcclxuICAgICAgICAgICAgICAgICAgc2V0SXNCdWxrTW9kZShmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgIHNldElzRWRpdE1vZGUodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIG9wZW5FZGl0RHJhd2VyKGl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlclwiIC8+XHJcbiAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHRhcmdldF9jb2RlOiBpdGVtPy50YXJnZXRfY29kZSxcclxuICAgICAgICAgIG5hbWU6IGl0ZW0uYWdlbnQubmFtZSxcclxuICAgICAgICAgIHBob25lX251bWJlcjogaXRlbS5hZ2VudC5waG9uZSxcclxuICAgICAgICAgIGFjdHVhbF9idXNpbmVzczogaXRlbT8ubWV0cmljcz8uYWN0dWFsX2J1c2luZXNzLFxyXG4gICAgICAgICAgdGFyZ2V0X2RpZmZlcmVuY2U6IGl0ZW0/Lm1ldHJpY3M/LnRhcmdldF9kaWZmZXJlbmNlLFxyXG4gICAgICAgICAgdGFyZ2V0X3JlbWFpbmluZ19kaWdpdHM6IGl0ZW0/Lm1ldHJpY3M/LnRhcmdldF9yZW1haW5pbmdfZGlnaXRzLFxyXG4gICAgICAgICAgdGFyZ2V0OiBpdGVtLmFnZW50Py50YXJnZXQ/LnZhbHVlLFxyXG4gICAgICAgICAgYWN0aW9uOiBhY3Rpb25Ecm9wZG93bixcclxuICAgICAgICAgIF9pdGVtOiBpdGVtLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0VGFibGVEYXRhKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0VGFibGVEYXRhKFtdKTtcclxuICAgIH1cclxuICB9LCBbc2VsZWN0ZWRJZCwgdGFyZ2V0RGF0YV0pO1xyXG5cclxuICBjb25zdCBmZXRjaFRhcmdldERldGFpbHMgPSBhc3luYyAoaXRlbSkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgeyB5ZWFyIH0gPSBwYXJzZURhdGUoc2VsZWN0ZWREYXRlKTtcclxuXHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoYC90YXJnZXQvYWdlbnQvJHtpdGVtLmFnZW50LmlkfWAsIHtcclxuICAgICAgICBwYXJhbXM6IHsgeWVhciB9LFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGxldCBtb250aERhdGEgPSBudWxsO1xyXG5cclxuICAgICAgaWYgKHJlcy5kYXRhICYmIHJlcy5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBjb25zdCB0YXJnZXQgPSByZXMuZGF0YVswXTtcclxuICAgICAgICBtb250aERhdGEgPSB0YXJnZXQubW9udGhEYXRhIHx8IG51bGw7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHNldEZldGNoZWRUYXJnZXREYXRhKG1vbnRoRGF0YSk7XHJcbiAgICAgIHJldHVybiBtb250aERhdGE7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHRhcmdldCBkZXRhaWxzOlwiLCBlcnIpO1xyXG4gICAgICBzZXRGZXRjaGVkVGFyZ2V0RGF0YShudWxsKTtcclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb3BlblNldERyYXdlciA9IGFzeW5jIChpdGVtKSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZFBlcnNvbihpdGVtKTtcclxuICAgIHNldElzRWRpdE1vZGUoZmFsc2UpO1xyXG4gICAgc2V0SXNCdWxrTW9kZShmYWxzZSk7XHJcbiAgICBzZXRFZGl0VGFyZ2V0SWQoaXRlbS5hZ2VudC5pZCk7XHJcblxyXG4gICAgY29uc3QgbW9udGhEYXRhID0gYXdhaXQgZmV0Y2hUYXJnZXREZXRhaWxzKGl0ZW0pO1xyXG5cclxuICAgIGNvbnN0IG1vbnRoVmFsdWVzID0ge1xyXG4gICAgICBKYW51YXJ5OiAwLFxyXG4gICAgICBGZWJydWFyeTogMCxcclxuICAgICAgTWFyY2g6IDAsXHJcbiAgICAgIEFwcmlsOiAwLFxyXG4gICAgICBNYXk6IDAsXHJcbiAgICAgIEp1bmU6IDAsXHJcbiAgICAgIEp1bHk6IDAsXHJcbiAgICAgIEF1Z3VzdDogMCxcclxuICAgICAgU2VwdGVtYmVyOiAwLFxyXG4gICAgICBPY3RvYmVyOiAwLFxyXG4gICAgICBOb3ZlbWJlcjogMCxcclxuICAgICAgRGVjZW1iZXI6IDAsXHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChtb250aERhdGEpIHtcclxuICAgICAgT2JqZWN0LmtleXMobW9udGhWYWx1ZXMpLmZvckVhY2goKG1vbnRoKSA9PiB7XHJcbiAgICAgICAgbW9udGhWYWx1ZXNbbW9udGhdID0gbW9udGhEYXRhW21vbnRoXSB8fCAwO1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICBzZXRNb250aFZhbHVlcyhtb250aFZhbHVlcyk7XHJcbiAgICBzZXREcmF3ZXJWaXNpYmxlKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9wZW5FZGl0RHJhd2VyID0gYXN5bmMgKGl0ZW0pID0+IHtcclxuICAgIHNldFNlbGVjdGVkUGVyc29uKGl0ZW0pO1xyXG4gICAgc2V0SXNFZGl0TW9kZSh0cnVlKTtcclxuICAgIHNldElzQnVsa01vZGUoZmFsc2UpO1xyXG4gICAgc2V0RWRpdFRhcmdldElkKGl0ZW0uYWdlbnQuaWQpO1xyXG5cclxuICAgIGNvbnN0IG1vbnRoRGF0YSA9IGF3YWl0IGZldGNoVGFyZ2V0RGV0YWlscyhpdGVtKTtcclxuXHJcbiAgICBjb25zdCBtb250aFZhbHVlcyA9IHtcclxuICAgICAgSmFudWFyeTogMCxcclxuICAgICAgRmVicnVhcnk6IDAsXHJcbiAgICAgIE1hcmNoOiAwLFxyXG4gICAgICBBcHJpbDogMCxcclxuICAgICAgTWF5OiAwLFxyXG4gICAgICBKdW5lOiAwLFxyXG4gICAgICBKdWx5OiAwLFxyXG4gICAgICBBdWd1c3Q6IDAsXHJcbiAgICAgIFNlcHRlbWJlcjogMCxcclxuICAgICAgT2N0b2JlcjogMCxcclxuICAgICAgTm92ZW1iZXI6IDAsXHJcbiAgICAgIERlY2VtYmVyOiAwLFxyXG4gICAgfTtcclxuXHJcbiAgICBpZiAobW9udGhEYXRhKSB7XHJcbiAgICAgIE9iamVjdC5rZXlzKG1vbnRoVmFsdWVzKS5mb3JFYWNoKChtb250aCkgPT4ge1xyXG4gICAgICAgIG1vbnRoVmFsdWVzW21vbnRoXSA9IG1vbnRoRGF0YVttb250aF0gfHwgMDtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0TW9udGhWYWx1ZXMobW9udGhWYWx1ZXMpO1xyXG4gICAgc2V0RHJhd2VyVmlzaWJsZSh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBvcGVuQnVsa0RyYXdlciA9ICgpID0+IHtcclxuICAgIHNldElzQnVsa01vZGUodHJ1ZSk7XHJcbiAgICBzZXRJc0VkaXRNb2RlKGZhbHNlKTtcclxuICAgIHNldERyYXdlclZpc2libGUodHJ1ZSk7XHJcblxyXG4gICAgc2V0TW9udGhWYWx1ZXMoe1xyXG4gICAgICBKYW51YXJ5OiAwLFxyXG4gICAgICBGZWJydWFyeTogMCxcclxuICAgICAgTWFyY2g6IDAsXHJcbiAgICAgIEFwcmlsOiAwLFxyXG4gICAgICBNYXk6IDAsXHJcbiAgICAgIEp1bmU6IDAsXHJcbiAgICAgIEp1bHk6IDAsXHJcbiAgICAgIEF1Z3VzdDogMCxcclxuICAgICAgU2VwdGVtYmVyOiAwLFxyXG4gICAgICBPY3RvYmVyOiAwLFxyXG4gICAgICBOb3ZlbWJlcjogMCxcclxuICAgICAgRGVjZW1iZXI6IDAsXHJcbiAgICB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVNb250aENoYW5nZSA9IChtb250aCwgdmFsdWUpID0+IHtcclxuICAgIHNldE1vbnRoVmFsdWVzKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBbbW9udGhdOiB2YWx1ZSA9PT0gXCJcIiA/IFwiXCIgOiBOdW1iZXIodmFsdWUpLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHsgeWVhciB9ID0gcGFyc2VEYXRlKHNlbGVjdGVkRGF0ZSk7XHJcblxyXG4gICAgICBpZiAoaXNCdWxrTW9kZSkge1xyXG4gICAgICAgIGNvbnN0IGFnZW50SWRzID1cclxuICAgICAgICAgIHNlbGVjdGVkVHlwZSA9PT0gXCJhZ2VudHNcIlxyXG4gICAgICAgICAgICA/IGFnZW50cy5tYXAoKGEpID0+IGEuX2lkKVxyXG4gICAgICAgICAgICA6IGVtcGxveWVlcy5tYXAoKGUpID0+IGUuX2lkKTtcclxuXHJcbiAgICAgICAgYXdhaXQgYXBpLnBhdGNoKGAvdGFyZ2V0L2J1bGtgLCB7XHJcbiAgICAgICAgICBhZ2VudElkcyxcclxuICAgICAgICAgIHllYXIsXHJcbiAgICAgICAgICBtb250aFZhbHVlcyxcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBhd2FpdCBhcGkucGF0Y2goXHJcbiAgICAgICAgICBgL3RhcmdldC9hZ2VudC8ke2VkaXRUYXJnZXRJZH0/eWVhcj0ke3llYXJ9YCxcclxuICAgICAgICAgIG1vbnRoVmFsdWVzXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogaXNCdWxrTW9kZVxyXG4gICAgICAgICAgPyBcIkJ1bGsgdGFyZ2V0cyB1cGRhdGVkIHN1Y2Nlc3NmdWxseVwiXHJcbiAgICAgICAgICA6IGlzRWRpdE1vZGVcclxuICAgICAgICAgID8gXCJUYXJnZXQgdXBkYXRlZCBzdWNjZXNzZnVsbHlcIlxyXG4gICAgICAgICAgOiBcIlRhcmdldCBzZXQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXREcmF3ZXJWaXNpYmxlKGZhbHNlKTtcclxuICAgICAgc2V0UmVsb2FkKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIlN1Ym1pdCBmYWlsZWRcIiwgZXJyKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogaXNCdWxrTW9kZVxyXG4gICAgICAgICAgPyBcIkJ1bGsgdXBkYXRlIGZhaWxlZFwiXHJcbiAgICAgICAgICA6IGlzRWRpdE1vZGVcclxuICAgICAgICAgID8gXCJVcGRhdGUgZmFpbGVkXCJcclxuICAgICAgICAgIDogXCJBZGQgZmFpbGVkXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBnZXRDb2x1bW5zID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIFtcclxuICAgICAgICB7a2V5OiBcInRhcmdldF9jb2RlXCIsIGhlYWRlcjogXCJUYXJnZXQgQ29kZVwifSxcclxuICAgICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiTmFtZVwiIH0sXHJcbiAgICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgICAgeyBrZXk6IFwidGFyZ2V0XCIsIGhlYWRlcjogXCJUYXJnZXRcIiB9LFxyXG4gICAgICB7IGtleTogXCJhY3R1YWxfYnVzaW5lc3NcIiwgaGVhZGVyOiBcIkFjdHVhbCBCdXNpbmVzc1wiIH0sXHJcbiAgICAgIHsga2V5OiBcInRhcmdldF9kaWZmZXJlbmNlXCIsIGhlYWRlcjogXCJUYXJnZXQgRGlmZmVyZW5jZVwiIH0sXHJcbiAgICAgIHsga2V5OiBcInRhcmdldF9yZW1haW5pbmdfZGlnaXRzXCIsIGhlYWRlcjogXCJUYXJnZXQgUmVtYWluaW5nIERpZ2l0c1wiIH0sXHJcbiAgICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICAgIF07XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e0dsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtNlwiPlxyXG4gICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5UYXJnZXRzIE1hbmFnZW1lbnQ8L2gxPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17b3BlbkJ1bGtEcmF3ZXJ9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgYmctdmlvbGV0LTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIGhvdmVyOmJnLXZpb2xldC03MDBcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPElvTWRBZGQgY2xhc3NOYW1lPVwibXItMlwiIC8+IEJ1bGsgVXBkYXRlIFRhcmdldHNcclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7aW5pdGlhbERhdGFMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGgtNjRcIj5cclxuICAgICAgICAgICAgICA8TG9hZGVyIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTZcIj5cclxuICAgICAgICAgICAgICAgIDxDb2xsYXBzZVxyXG4gICAgICAgICAgICAgICAgICBpdGVtcz17W1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1iYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgU2hvcnRjdXQgS2V5c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2hpbGRyZW46IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIG1kOmdyaWQtY29scy01IGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3JlcG9ydHMvdGFyZ2V0LWNvbW1pc3Npb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCB0ZXh0LWJhc2UgaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlciAgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIHRleHQtZ3JheS03MDAgaG92ZXI6Ym9yZGVyLXZpb2xldC01MDAgaG92ZXI6dGV4dC12aW9sZXQtNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RG9sbGFyT3V0bGluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT17MzB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29tbWlzc2lvbiBSZXBvcnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9yZXBvcnRzL3RhcmdldC1pbmNlbnRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCB0ZXh0LWJhc2UgaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlciAgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgcHgtNCBweS0yIHRleHQtZ3JheS03MDAgaG92ZXI6Ym9yZGVyLXZpb2xldC01MDAgaG92ZXI6dGV4dC12aW9sZXQtNjAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHRPdXRsaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXszMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBJbmNlbnRpdmUgUmVwb3J0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3RhcmdldC1jb21taXNzaW9uLWluY2VudGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHRleHQtYmFzZSBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyICBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItdmlvbGV0LTUwMCBob3Zlcjp0ZXh0LXZpb2xldC02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZFBheW1lbnRzIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTUwMFwiIHNpemU9ezMwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29tbWlzc2lvbiBvciBJbmNlbnRpdmUgUGF5b3V0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPiAqL31cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3BheW1lbnQtbWVudS9wYXltZW50LWluLW91dC1tZW51L3BheS1vdXQtbWVudS9zYWxhcnktcGF5bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHRleHQtYmFzZSBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyICBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBweC00IHB5LTIgdGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItdmlvbGV0LTUwMCBob3Zlcjp0ZXh0LXZpb2xldC02MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGYU1vbmV5QmlsbCBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC01MDBcIiBzaXplPXszMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNhbGFyeSBQYXlvdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBdfVxyXG4gICAgICAgICAgICAgICAgICBkZWZhdWx0QWN0aXZlS2V5PXtbXCIxXCJdfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZ3JheS0yMDAgYmctd2hpdGUgc2hhZG93LXNtXCJcclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IGZsZXgtd3JhcCBtYi02IGl0ZW1zLWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVHlwZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJvcmRlciByb3VuZGVkIHctZnVsbCBtaW4tdy1bMTUwcHhdXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRUeXBlKGUudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkSWQoXCJhbGxcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJhZ2VudHNcIj5BZ2VudHM8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiZW1wbG95ZWVzXCI+RW1wbG95ZWVzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkVHlwZSA9PT0gXCJhZ2VudHNcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBZ2VudFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJvcmRlciByb3VuZGVkIHctZnVsbCBtaW4tdy1bMjAwcHhdXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZElkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZElkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWxsXCI+QWxsIEFnZW50czwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2FnZW50cy5tYXAoKGFnZW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lIHx8IFwiVW5rbm93biBBZ2VudFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAge3NlbGVjdGVkVHlwZSA9PT0gXCJlbXBsb3llZXNcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBFbXBsb3llZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJvcmRlciByb3VuZGVkIHctZnVsbCBtaW4tdy1bMjAwcHhdXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZElkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZElkKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYWxsXCI+QWxsIEVtcGxveWVlczwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcGxveWVlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtlbXBsb3llZS5faWR9IHZhbHVlPXtlbXBsb3llZS5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZS5uYW1lIHx8IFwiVW5rbm93biBFbXBsb3llZVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMCBtYi0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVGFyZ2V0IE1vbnRoXHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJtb250aFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIGJvcmRlciByb3VuZGVkIHctZnVsbCBtaW4tdy1bMTUwcHhdXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWREYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICBtYXg9e2Zvcm1hdFRvWWVhck1vbnRoKGN1cnJlbnRZZWFyLCBjdXJyZW50TW9udGgpfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWluLWgtWzIwMHB4XVwiPlxyXG4gICAgICAgICAgICAgICAge2RhdGFMb2FkaW5nICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLXdoaXRlIGJnLW9wYWNpdHktNzAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYW5pbWF0ZS1zcGluIHJvdW5kZWQtZnVsbCBoLTEwIHctMTAgYm9yZGVyLTQgYm9yZGVyLXZpb2xldC02MDAgYm9yZGVyLXQtdHJhbnNwYXJlbnRcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICBkYXRhPXt0YWJsZURhdGF9XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e2dldENvbHVtbnMoKX1cclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiVGFyZ2V0LVJlcG9ydFwiXHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJUYXJnZXQtUmVwb3J0LmNzdlwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIFRhcmdldCBEcmF3ZXIgKi99XHJcbiAgICAgIDxEcmF3ZXJcclxuICAgICAgICB0aXRsZT17XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICA8c3Bhbj5cclxuICAgICAgICAgICAgICB7aXNCdWxrTW9kZVxyXG4gICAgICAgICAgICAgICAgPyBcIkJ1bGsgVXBkYXRlIFRhcmdldHNcIlxyXG4gICAgICAgICAgICAgICAgOiBpc0VkaXRNb2RlXHJcbiAgICAgICAgICAgICAgICA/IFwiRWRpdCBUYXJnZXRcIlxyXG4gICAgICAgICAgICAgICAgOiBcIlNldCBUYXJnZXRcIn1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RHJhd2VyVmlzaWJsZShmYWxzZSl9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktNzAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJb01kQ2xvc2Ugc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHBsYWNlbWVudD1cInJpZ2h0XCJcclxuICAgICAgICBjbG9zYWJsZT17ZmFsc2V9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0RHJhd2VyVmlzaWJsZShmYWxzZSl9XHJcbiAgICAgICAgb3Blbj17ZHJhd2VyVmlzaWJsZX1cclxuICAgICAgICB3aWR0aD17NTAwfVxyXG4gICAgICAgIGNsYXNzTmFtZT1cInRhcmdldC1kcmF3ZXJcIlxyXG4gICAgICAgIHN0eWxlcz17e1xyXG4gICAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwLFxyXG4gICAgICAgICAgICBvdmVyZmxvdzogXCJoaWRkZW5cIixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBoZWFkZXI6IHtcclxuICAgICAgICAgICAgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCAjZjBmMGYwXCIsXHJcbiAgICAgICAgICAgIHBhZGRpbmc6IFwiMTZweCAyNHB4XCIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH19XHJcbiAgICAgID5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgIHshaXNCdWxrTW9kZSAmJiBzZWxlY3RlZFBlcnNvbiAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bSBtYi0xXCI+VGFyZ2V0IEZvcjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWQgYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRQZXJzb24uYWdlbnQubmFtZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00IG1iLTRcIj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIGZvbnQtbWVkaXVtIG1iLTFcIj5ZZWFyPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZCBiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgIHtwYXJzZURhdGUoc2VsZWN0ZWREYXRlKS55ZWFyfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bSBtYi0xXCI+TW9udGg8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0yIGJvcmRlciByb3VuZGVkIGJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAge3BhcnNlRGF0ZShzZWxlY3RlZERhdGUpLm1vbnRoTmFtZX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIHttb250aE5hbWVzLm1hcCgobW9udGgpID0+IChcclxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXttb250aH0+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBmb250LW1lZGl1bSBtYi0xXCI+e21vbnRofTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtci0yXCI+4oK5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bW9udGhWYWx1ZXNbbW9udGhdfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVNb250aENoYW5nZShtb250aCwgZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMiBib3JkZXIgcm91bmRlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtgRW50ZXIgJHttb250aH0gdGFyZ2V0YH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdmlvbGV0LTYwMCB0ZXh0LXdoaXRlIHAtMiByb3VuZGVkIGhvdmVyOmJnLXZpb2xldC03MDAgbXQtNlwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7aXNCdWxrTW9kZVxyXG4gICAgICAgICAgICAgICAgPyBcIlVwZGF0ZSBBbGwgVGFyZ2V0c1wiXHJcbiAgICAgICAgICAgICAgICA6IGlzRWRpdE1vZGVcclxuICAgICAgICAgICAgICAgID8gXCJVcGRhdGUgVGFyZ2V0XCJcclxuICAgICAgICAgICAgICAgIDogXCJTYXZlIFRhcmdldFwifVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9EcmF3ZXI+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVGFyZ2V0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvVGFyZ2V0LmpzeCJ9