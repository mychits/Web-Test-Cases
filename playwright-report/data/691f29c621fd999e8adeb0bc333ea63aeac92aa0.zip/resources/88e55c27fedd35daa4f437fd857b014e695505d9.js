import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/HoldedCustomerReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Flex, Spin, Select, Typography } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { LoadingOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const { Title } = Typography;
const HoldedCustomerReport = () => {
  _s();
  const [holdedCustomers, setHoldedCustomers] = useState([]);
  const referrals = ["All", "Agent", "Employee"];
  const [selectedRefferal, setSelectedRefferal] = useState("All");
  const [agents, setAgents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedAgentOrEmployee, setSelectedAgentOrEmployee] = useState("");
  useEffect(() => {
    (async () => {
      if (selectedRefferal === "All") {
        try {
          setIsLoading(true);
          const response = await api.get("/enroll/holdedcustomers");
          if (Array.isArray(response.data)) {
            setHoldedCustomers(
              response.data.map((c, i) => ({
                _id: c._id,
                si_no: i + 1,
                user_name: c?.user_id?.full_name,
                user_phone: c?.user_id?.phone_number,
                customer_id: c?.user_id?.customer_id,
                ticket_no: c?.tickets,
                group_name: c?.group_id?.group_name,
                agent_name: c?.agent?.name,
                agent_code: c?.agent?.employeeCode,
                agent_phone_number: c?.agent?.phone_number
              }))
            );
          }
        } catch (err) {
          setHoldedCustomers([]);
          console.log("failed to get all customers", err);
        } finally {
          setIsLoading(false);
        }
      }
    })();
  }, [selectedRefferal]);
  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/agent/get");
        if (Array.isArray(res.data?.agent)) {
          setAgents(
            res.data.agent.map((ag) => ({
              _id: ag._id,
              agent_name: ag.name,
              agent_phone_number: ag.phone_number,
              agent_id: ag.employeeCode
            }))
          );
        }
      } catch (err) {
        setAgents([]);
        console.log("Error fetching agent data", err);
      }
    })();
  }, []);
  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/employee");
        if (Array.isArray(res.data?.employee)) {
          setEmployees(
            res.data.employee.map((e) => ({
              _id: e._id,
              employee_name: e.name,
              employee_phone_number: e.phone_number,
              employee_id: e.employeeCode
            }))
          );
        }
      } catch (err) {
        console.log("Error fetching Employee data", err);
      }
    })();
  }, []);
  useEffect(() => {
    if (!selectedAgentOrEmployee) return;
    (async () => {
      try {
        setIsLoading(true);
        const res = await api.get(
          `/enroll/holded?agent=${selectedAgentOrEmployee}`
        );
        if (Array.isArray(res.data)) {
          setHoldedCustomers(
            res.data.map((c, i) => ({
              _id: c._id,
              si_no: i + 1,
              user_name: c?.user_id?.full_name,
              user_phone: c?.user_id?.phone_number,
              customer_id: c?.user_id?.customer_id,
              ticket_no: c?.tickets,
              group_name: c?.group_id?.group_name,
              agent_name: c?.agent?.name,
              agent_code: c?.agent?.employeeCode,
              agent_phone_number: c?.agent?.phone_number
            }))
          );
        }
      } catch (err) {
        setHoldedCustomers([]);
        console.error("Error Fetching Holded Customer", err);
      } finally {
        setIsLoading(false);
      }
    })();
  }, [selectedAgentOrEmployee]);
  const columns = [
    { key: "si_no", header: "SL. NO" },
    { key: "user_name", header: "Customer Name" },
    { key: "user_phone", header: "Phone Number" },
    { key: "customer_id", header: "Customer Id" },
    { key: "ticket_no", header: "Ticket No" },
    { key: "group_name", header: "Group Name" }
  ];
  if (selectedRefferal === "All") {
    columns.push(
      { key: "agent_name", header: "Agent Name" },
      { key: "agent_code", header: "Agent Id" },
      { key: "agent_phone_number", header: "Agent Phone Number" }
    );
  }
  return /* @__PURE__ */ jsxDEV("div", { style: { padding: 24 }, children: [
    /* @__PURE__ */ jsxDEV(Title, { level: 3, style: { textAlign: "center", marginBottom: 24 }, children: "Holded Customer Report" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx",
      lineNumber: 144,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Flex, { gap: "large", style: { marginBottom: 24 }, children: [
      /* @__PURE__ */ jsxDEV(
        Select,
        {
          size: "large",
          showSearch: true,
          placeholder: "Select Referral Type",
          style: { width: 300, height: 55 },
          onChange: (v) => {
            setSelectedRefferal(v);
            setSelectedAgentOrEmployee("");
          },
          options: referrals.map((r) => ({ label: r, value: r }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx",
          lineNumber: 149,
          columnNumber: 9
        },
        this
      ),
      selectedRefferal === "Employee" && /* @__PURE__ */ jsxDEV(
        Select,
        {
          size: "large",
          showSearch: true,
          placeholder: "Select Employee",
          style: { width: 500, height: 55 },
          onChange: (v) => setSelectedAgentOrEmployee(v),
          options: employees.map((e) => ({
            label: `${e.employee_name} | ${e.employee_phone_number} | ${e.employee_id}`,
            value: e._id
          }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx",
          lineNumber: 162,
          columnNumber: 9
        },
        this
      ),
      selectedRefferal === "Agent" && /* @__PURE__ */ jsxDEV(
        Select,
        {
          size: "large",
          showSearch: true,
          placeholder: "Select Agent",
          style: { width: 500, height: 55 },
          onChange: (v) => setSelectedAgentOrEmployee(v),
          options: agents.map((a) => ({
            label: `${a.agent_name} | ${a.agent_phone_number} | ${a.agent_id}`,
            value: a._id
          }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx",
          lineNumber: 176,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx",
      lineNumber: 148,
      columnNumber: 7
    }, this),
    isLoading ? /* @__PURE__ */ jsxDEV(
      Flex,
      {
        style: { height: "60vh" },
        align: "center",
        justify: "center",
        vertical: true,
        children: /* @__PURE__ */ jsxDEV(
          Spin,
          {
            indicator: /* @__PURE__ */ jsxDEV(LoadingOutlined, { style: { fontSize: 64 }, spin: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx",
              lineNumber: 198,
              columnNumber: 22
            }, this),
            tip: "Loading data..."
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx",
            lineNumber: 197,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx",
        lineNumber: 191,
        columnNumber: 7
      },
      this
    ) : holdedCustomers.length <= 0 ? /* @__PURE__ */ jsxDEV(
      Flex,
      {
        style: { height: "40vh" },
        align: "center",
        justify: "center",
        vertical: true,
        children: "No data found"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx",
        lineNumber: 203,
        columnNumber: 7
      },
      this
    ) : /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        catcher: "_id",
        data: holdedCustomers,
        columns,
        exportedPdfName: "HoldedCustomer",
        exportedFileName: `HoldedCustomer.csv`
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx",
        lineNumber: 212,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx",
    lineNumber: 143,
    columnNumber: 5
  }, this);
};
_s(HoldedCustomerReport, "1AZ5g7avrTIeumBmJiPjDc4FTH0=");
_c = HoldedCustomerReport;
export default HoldedCustomerReport;
var _c;
$RefreshReg$(_c, "HoldedCustomerReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/HoldedCustomerReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0lNOzJCQS9JTjtBQUFnQkEsTUFBV0MsY0FBUSxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxNQUFNQyxNQUFNQyxRQUFRQyxrQkFBa0I7QUFDL0MsU0FBU0MsdUJBQXVCO0FBRWhDLE1BQU0sRUFBRUMsTUFBTSxJQUFJRjtBQUVsQixNQUFNRyx1QkFBdUJBLE1BQU07QUFBQUMsS0FBQTtBQUNqQyxRQUFNLENBQUNDLGlCQUFpQkMsa0JBQWtCLElBQUlaLFNBQVMsRUFBRTtBQUN6RCxRQUFNYSxZQUFZLENBQUMsT0FBTSxTQUFTLFVBQVU7QUFDNUMsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJZixTQUFTLEtBQUs7QUFDOUQsUUFBTSxDQUFDZ0IsUUFBUUMsU0FBUyxJQUFJakIsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ2tCLFdBQVdDLFlBQVksSUFBSW5CLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNvQixXQUFXQyxZQUFZLElBQUlyQixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDc0IseUJBQXlCQywwQkFBMEIsSUFBSXZCLFNBQVMsRUFBRTtBQUV6RUQsWUFBVSxNQUFNO0FBQ2QsS0FBQyxZQUFZO0FBQ1gsVUFBR2UscUJBQXFCLE9BQU07QUFDOUIsWUFBSTtBQUNGTyx1QkFBYSxJQUFJO0FBQ2pCLGdCQUFNRyxXQUFXLE1BQU12QixJQUFJd0IsSUFBSSx5QkFBeUI7QUFDeEQsY0FBSUMsTUFBTUMsUUFBUUgsU0FBU0ksSUFBSSxHQUFHO0FBQ2hDaEI7QUFBQUEsY0FDRVksU0FBU0ksS0FBS0MsSUFBSSxDQUFDQyxHQUFHQyxPQUFPO0FBQUEsZ0JBQzNCQyxLQUFLRixFQUFFRTtBQUFBQSxnQkFDUEMsT0FBT0YsSUFBSTtBQUFBLGdCQUNYRyxXQUFXSixHQUFHSyxTQUFTQztBQUFBQSxnQkFDdkJDLFlBQVlQLEdBQUdLLFNBQVNHO0FBQUFBLGdCQUN4QkMsYUFBYVQsR0FBR0ssU0FBU0k7QUFBQUEsZ0JBQ3pCQyxXQUFXVixHQUFHVztBQUFBQSxnQkFDZEMsWUFBWVosR0FBR2EsVUFBVUQ7QUFBQUEsZ0JBQ3pCRSxZQUFZZCxHQUFHZSxPQUFPQztBQUFBQSxnQkFDdEJDLFlBQVlqQixHQUFHZSxPQUFPRztBQUFBQSxnQkFDdEJDLG9CQUFvQm5CLEdBQUdlLE9BQU9QO0FBQUFBLGNBQ2hDLEVBQUU7QUFBQSxZQUNKO0FBQUEsVUFDRjtBQUFBLFFBQ0YsU0FBU1ksS0FBSztBQUNadEMsNkJBQW1CLEVBQUU7QUFDckJ1QyxrQkFBUUMsSUFBSSwrQkFBK0JGLEdBQUc7QUFBQSxRQUNoRCxVQUFDO0FBQ0M3Qix1QkFBYSxLQUFLO0FBQUEsUUFDcEI7QUFBQSxNQUNGO0FBQUEsSUFDQSxHQUFHO0FBQUEsRUFDTCxHQUFHLENBQUNQLGdCQUFnQixDQUFDO0FBR3JCZixZQUFVLE1BQU07QUFDZCxLQUFDLFlBQVk7QUFDWCxVQUFJO0FBQ0YsY0FBTXNELE1BQU0sTUFBTXBELElBQUl3QixJQUFJLFlBQVk7QUFDdEMsWUFBSUMsTUFBTUMsUUFBUTBCLElBQUl6QixNQUFNaUIsS0FBSyxHQUFHO0FBQ2xDNUI7QUFBQUEsWUFDRW9DLElBQUl6QixLQUFLaUIsTUFBTWhCLElBQUksQ0FBQ3lCLFFBQVE7QUFBQSxjQUMxQnRCLEtBQUtzQixHQUFHdEI7QUFBQUEsY0FDUlksWUFBWVUsR0FBR1I7QUFBQUEsY0FDZkcsb0JBQW9CSyxHQUFHaEI7QUFBQUEsY0FDdkJpQixVQUFVRCxHQUFHTjtBQUFBQSxZQUNmLEVBQUU7QUFBQSxVQUNKO0FBQUEsUUFDRjtBQUFBLE1BQ0YsU0FBU0UsS0FBSztBQUNaakMsa0JBQVUsRUFBRTtBQUNaa0MsZ0JBQVFDLElBQUksNkJBQTZCRixHQUFHO0FBQUEsTUFDOUM7QUFBQSxJQUNGLEdBQUc7QUFBQSxFQUNMLEdBQUcsRUFBRTtBQUdMbkQsWUFBVSxNQUFNO0FBQ2QsS0FBQyxZQUFZO0FBQ1gsVUFBSTtBQUNGLGNBQU1zRCxNQUFNLE1BQU1wRCxJQUFJd0IsSUFBSSxXQUFXO0FBQ3JDLFlBQUlDLE1BQU1DLFFBQVEwQixJQUFJekIsTUFBTTRCLFFBQVEsR0FBRztBQUNyQ3JDO0FBQUFBLFlBQ0VrQyxJQUFJekIsS0FBSzRCLFNBQVMzQixJQUFJLENBQUM0QixPQUFPO0FBQUEsY0FDNUJ6QixLQUFLeUIsRUFBRXpCO0FBQUFBLGNBQ1AwQixlQUFlRCxFQUFFWDtBQUFBQSxjQUNqQmEsdUJBQXVCRixFQUFFbkI7QUFBQUEsY0FDekJzQixhQUFhSCxFQUFFVDtBQUFBQSxZQUNqQixFQUFFO0FBQUEsVUFDSjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFNBQVNFLEtBQUs7QUFDWkMsZ0JBQVFDLElBQUksZ0NBQWdDRixHQUFHO0FBQUEsTUFDakQ7QUFBQSxJQUNGLEdBQUc7QUFBQSxFQUNMLEdBQUcsRUFBRTtBQUVMbkQsWUFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFDdUIsd0JBQXlCO0FBQzlCLEtBQUMsWUFBWTtBQUNYLFVBQUk7QUFDRkQscUJBQWEsSUFBSTtBQUNqQixjQUFNZ0MsTUFBTSxNQUFNcEQsSUFBSXdCO0FBQUFBLFVBQ3BCLHdCQUF3QkgsdUJBQXVCO0FBQUEsUUFDakQ7QUFDQSxZQUFJSSxNQUFNQyxRQUFRMEIsSUFBSXpCLElBQUksR0FBRztBQUMzQmhCO0FBQUFBLFlBQ0V5QyxJQUFJekIsS0FBS0MsSUFBSSxDQUFDQyxHQUFHQyxPQUFPO0FBQUEsY0FDdEJDLEtBQUtGLEVBQUVFO0FBQUFBLGNBQ1BDLE9BQU9GLElBQUk7QUFBQSxjQUNYRyxXQUFXSixHQUFHSyxTQUFTQztBQUFBQSxjQUN2QkMsWUFBWVAsR0FBR0ssU0FBU0c7QUFBQUEsY0FDeEJDLGFBQWFULEdBQUdLLFNBQVNJO0FBQUFBLGNBQ3pCQyxXQUFXVixHQUFHVztBQUFBQSxjQUNkQyxZQUFZWixHQUFHYSxVQUFVRDtBQUFBQSxjQUN6QkUsWUFBWWQsR0FBR2UsT0FBT0M7QUFBQUEsY0FDdEJDLFlBQVlqQixHQUFHZSxPQUFPRztBQUFBQSxjQUN0QkMsb0JBQW9CbkIsR0FBR2UsT0FBT1A7QUFBQUEsWUFDaEMsRUFBRTtBQUFBLFVBQ0o7QUFBQSxRQUNGO0FBQUEsTUFDRixTQUFTWSxLQUFLO0FBQ1p0QywyQkFBbUIsRUFBRTtBQUNyQnVDLGdCQUFRVSxNQUFNLGtDQUFrQ1gsR0FBRztBQUFBLE1BQ3JELFVBQUM7QUFDQzdCLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0YsR0FBRztBQUFBLEVBQ0wsR0FBRyxDQUFDQyx1QkFBdUIsQ0FBQztBQUU1QixRQUFNd0MsVUFBVTtBQUFBLElBQ2QsRUFBRUMsS0FBSyxTQUFTQyxRQUFRLFNBQVM7QUFBQSxJQUNqQyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDNUMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGVBQWU7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLGVBQWVDLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUVELEtBQUssYUFBYUMsUUFBUSxZQUFZO0FBQUEsSUFDeEMsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxFQUFDO0FBRTdDLE1BQUlsRCxxQkFBbUIsT0FBTztBQUM1QmdELFlBQVFHO0FBQUFBLE1BQ04sRUFBRUYsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxNQUMxQyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsV0FBVztBQUFBLE1BQ3hDLEVBQUVELEtBQUssc0JBQXNCQyxRQUFRLHFCQUFxQjtBQUFBLElBQzVEO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUVFLFNBQVMsR0FBRyxHQUN4QjtBQUFBLDJCQUFDLFNBQU0sT0FBTyxHQUFHLE9BQU8sRUFBRUMsV0FBVyxVQUFVQyxjQUFjLEdBQUcsR0FBRyxzQ0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxRQUFLLEtBQUksU0FBUSxPQUFPLEVBQUVBLGNBQWMsR0FBRyxHQUMxQztBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTDtBQUFBLFVBQ0EsYUFBWTtBQUFBLFVBQ1osT0FBTyxFQUFFQyxPQUFPLEtBQUtDLFFBQVEsR0FBRztBQUFBLFVBQ2hDLFVBQVUsQ0FBQ0MsTUFBTTtBQUNmeEQsZ0NBQW9Cd0QsQ0FBQztBQUNyQmhELHVDQUEyQixFQUFFO0FBQUEsVUFDL0I7QUFBQSxVQUNBLFNBQVNWLFVBQVVnQixJQUFJLENBQUMyQyxPQUFPLEVBQUVDLE9BQU9ELEdBQUdFLE9BQU9GLEVBQUUsRUFBRTtBQUFBO0FBQUEsUUFUeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUzBEO0FBQUEsTUFHekQxRCxxQkFBcUIsY0FDcEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMO0FBQUEsVUFDQSxhQUFZO0FBQUEsVUFDWixPQUFPLEVBQUV1RCxPQUFPLEtBQUtDLFFBQVEsR0FBRztBQUFBLFVBQ2hDLFVBQVUsQ0FBQ0MsTUFBTWhELDJCQUEyQmdELENBQUM7QUFBQSxVQUM3QyxTQUFTckQsVUFBVVcsSUFBSSxDQUFDNEIsT0FBTztBQUFBLFlBQzdCZ0IsT0FBTyxHQUFHaEIsRUFBRUMsYUFBYSxNQUFNRCxFQUFFRSxxQkFBcUIsTUFBTUYsRUFBRUcsV0FBVztBQUFBLFlBQ3pFYyxPQUFPakIsRUFBRXpCO0FBQUFBLFVBQ1gsRUFBRTtBQUFBO0FBQUEsUUFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTTTtBQUFBLE1BSVBsQixxQkFBcUIsV0FDcEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMO0FBQUEsVUFDQSxhQUFZO0FBQUEsVUFDWixPQUFPLEVBQUV1RCxPQUFPLEtBQUtDLFFBQVEsR0FBRztBQUFBLFVBQ2hDLFVBQVUsQ0FBQ0MsTUFBTWhELDJCQUEyQmdELENBQUM7QUFBQSxVQUM3QyxTQUFTdkQsT0FBT2EsSUFBSSxDQUFDOEMsT0FBTztBQUFBLFlBQzFCRixPQUFPLEdBQUdFLEVBQUUvQixVQUFVLE1BQU0rQixFQUFFMUIsa0JBQWtCLE1BQU0wQixFQUFFcEIsUUFBUTtBQUFBLFlBQ2hFbUIsT0FBT0MsRUFBRTNDO0FBQUFBLFVBQ1gsRUFBRTtBQUFBO0FBQUEsUUFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFTTTtBQUFBLFNBckNWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F3Q0E7QUFBQSxJQUVDWixZQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFPLEVBQUVrRCxRQUFRLE9BQU87QUFBQSxRQUN4QixPQUFNO0FBQUEsUUFDTixTQUFRO0FBQUEsUUFDUixVQUFRO0FBQUEsUUFFUjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVyx1QkFBQyxtQkFBZ0IsT0FBTyxFQUFFTSxVQUFVLEdBQUcsR0FBRyxNQUFJLFFBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThDO0FBQUEsWUFDekQsS0FBSTtBQUFBO0FBQUEsVUFGTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFdUI7QUFBQTtBQUFBLE1BUnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVVBLElBQ0VqRSxnQkFBZ0JrRSxVQUFVLElBQzVCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFPLEVBQUVQLFFBQVEsT0FBTztBQUFBLFFBQ3hCLE9BQU07QUFBQSxRQUNOLFNBQVE7QUFBQSxRQUNSLFVBQVE7QUFBQTtBQUFBO0FBQUEsTUFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFRO0FBQUEsUUFDUixNQUFNM0Q7QUFBQUEsUUFDTjtBQUFBLFFBQ0EsaUJBQWdCO0FBQUEsUUFDaEIsa0JBQWtCO0FBQUE7QUFBQSxNQUxwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLeUM7QUFBQSxPQTFFN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTZFQTtBQUVKO0FBQUVELEdBck5JRCxzQkFBb0I7QUFBQXFFLEtBQXBCckU7QUF1Tk4sZUFBZUE7QUFBcUIsSUFBQXFFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsImFwaSIsIkRhdGFUYWJsZSIsIkZsZXgiLCJTcGluIiwiU2VsZWN0IiwiVHlwb2dyYXBoeSIsIkxvYWRpbmdPdXRsaW5lZCIsIlRpdGxlIiwiSG9sZGVkQ3VzdG9tZXJSZXBvcnQiLCJfcyIsImhvbGRlZEN1c3RvbWVycyIsInNldEhvbGRlZEN1c3RvbWVycyIsInJlZmVycmFscyIsInNlbGVjdGVkUmVmZmVyYWwiLCJzZXRTZWxlY3RlZFJlZmZlcmFsIiwiYWdlbnRzIiwic2V0QWdlbnRzIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2VsZWN0ZWRBZ2VudE9yRW1wbG95ZWUiLCJzZXRTZWxlY3RlZEFnZW50T3JFbXBsb3llZSIsInJlc3BvbnNlIiwiZ2V0IiwiQXJyYXkiLCJpc0FycmF5IiwiZGF0YSIsIm1hcCIsImMiLCJpIiwiX2lkIiwic2lfbm8iLCJ1c2VyX25hbWUiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwidXNlcl9waG9uZSIsInBob25lX251bWJlciIsImN1c3RvbWVyX2lkIiwidGlja2V0X25vIiwidGlja2V0cyIsImdyb3VwX25hbWUiLCJncm91cF9pZCIsImFnZW50X25hbWUiLCJhZ2VudCIsIm5hbWUiLCJhZ2VudF9jb2RlIiwiZW1wbG95ZWVDb2RlIiwiYWdlbnRfcGhvbmVfbnVtYmVyIiwiZXJyIiwiY29uc29sZSIsImxvZyIsInJlcyIsImFnIiwiYWdlbnRfaWQiLCJlbXBsb3llZSIsImUiLCJlbXBsb3llZV9uYW1lIiwiZW1wbG95ZWVfcGhvbmVfbnVtYmVyIiwiZW1wbG95ZWVfaWQiLCJlcnJvciIsImNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJwdXNoIiwicGFkZGluZyIsInRleHRBbGlnbiIsIm1hcmdpbkJvdHRvbSIsIndpZHRoIiwiaGVpZ2h0IiwidiIsInIiLCJsYWJlbCIsInZhbHVlIiwiYSIsImZvbnRTaXplIiwibGVuZ3RoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSG9sZGVkQ3VzdG9tZXJSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgeyBGbGV4LCBTcGluLCBTZWxlY3QsIFR5cG9ncmFwaHkgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBMb2FkaW5nT3V0bGluZWQgfSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuXHJcbmNvbnN0IHsgVGl0bGUgfSA9IFR5cG9ncmFwaHk7XHJcblxyXG5jb25zdCBIb2xkZWRDdXN0b21lclJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCBbaG9sZGVkQ3VzdG9tZXJzLCBzZXRIb2xkZWRDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IHJlZmVycmFscyA9IFtcIkFsbFwiLFwiQWdlbnRcIiwgXCJFbXBsb3llZVwiXTtcclxuICBjb25zdCBbc2VsZWN0ZWRSZWZmZXJhbCwgc2V0U2VsZWN0ZWRSZWZmZXJhbF0gPSB1c2VTdGF0ZShcIkFsbFwiKTtcclxuICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBZ2VudE9yRW1wbG95ZWUsIHNldFNlbGVjdGVkQWdlbnRPckVtcGxveWVlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIC8vIGluaXRpYWwgZGF0YVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAoYXN5bmMgKCkgPT4ge1xyXG4gICAgICBpZihzZWxlY3RlZFJlZmZlcmFsID09PSBcIkFsbFwiKXtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2Vucm9sbC9ob2xkZWRjdXN0b21lcnNcIik7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocmVzcG9uc2UuZGF0YSkpIHtcclxuICAgICAgICAgIHNldEhvbGRlZEN1c3RvbWVycyhcclxuICAgICAgICAgICAgcmVzcG9uc2UuZGF0YS5tYXAoKGMsIGkpID0+ICh7XHJcbiAgICAgICAgICAgICAgX2lkOiBjLl9pZCxcclxuICAgICAgICAgICAgICBzaV9ubzogaSArIDEsXHJcbiAgICAgICAgICAgICAgdXNlcl9uYW1lOiBjPy51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgICAgICAgICAgdXNlcl9waG9uZTogYz8udXNlcl9pZD8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiBjPy51c2VyX2lkPy5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICB0aWNrZXRfbm86IGM/LnRpY2tldHMsXHJcbiAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogYz8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgYWdlbnRfbmFtZTogYz8uYWdlbnQ/Lm5hbWUsXHJcbiAgICAgICAgICAgICAgYWdlbnRfY29kZTogYz8uYWdlbnQ/LmVtcGxveWVlQ29kZSxcclxuICAgICAgICAgICAgICBhZ2VudF9waG9uZV9udW1iZXI6IGM/LmFnZW50Py5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIHNldEhvbGRlZEN1c3RvbWVycyhbXSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJmYWlsZWQgdG8gZ2V0IGFsbCBjdXN0b21lcnNcIiwgZXJyKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB9KSgpO1xyXG4gIH0sIFtzZWxlY3RlZFJlZmZlcmFsXSk7XHJcblxyXG4gIC8vIGFnZW50c1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAoYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0XCIpO1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KHJlcy5kYXRhPy5hZ2VudCkpIHtcclxuICAgICAgICAgIHNldEFnZW50cyhcclxuICAgICAgICAgICAgcmVzLmRhdGEuYWdlbnQubWFwKChhZykgPT4gKHtcclxuICAgICAgICAgICAgICBfaWQ6IGFnLl9pZCxcclxuICAgICAgICAgICAgICBhZ2VudF9uYW1lOiBhZy5uYW1lLFxyXG4gICAgICAgICAgICAgIGFnZW50X3Bob25lX251bWJlcjogYWcucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgICAgICAgIGFnZW50X2lkOiBhZy5lbXBsb3llZUNvZGUsXHJcbiAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIHNldEFnZW50cyhbXSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJFcnJvciBmZXRjaGluZyBhZ2VudCBkYXRhXCIsIGVycik7XHJcbiAgICAgIH1cclxuICAgIH0pKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBlbXBsb3llZXNcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgKGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KHJlcy5kYXRhPy5lbXBsb3llZSkpIHtcclxuICAgICAgICAgIHNldEVtcGxveWVlcyhcclxuICAgICAgICAgICAgcmVzLmRhdGEuZW1wbG95ZWUubWFwKChlKSA9PiAoe1xyXG4gICAgICAgICAgICAgIF9pZDogZS5faWQsXHJcbiAgICAgICAgICAgICAgZW1wbG95ZWVfbmFtZTogZS5uYW1lLFxyXG4gICAgICAgICAgICAgIGVtcGxveWVlX3Bob25lX251bWJlcjogZS5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgZW1wbG95ZWVfaWQ6IGUuZW1wbG95ZWVDb2RlLFxyXG4gICAgICAgICAgICB9KSlcclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkVycm9yIGZldGNoaW5nIEVtcGxveWVlIGRhdGFcIiwgZXJyKTtcclxuICAgICAgfVxyXG4gICAgfSkoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoIXNlbGVjdGVkQWdlbnRPckVtcGxveWVlKSByZXR1cm47XHJcbiAgICAoYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgYC9lbnJvbGwvaG9sZGVkP2FnZW50PSR7c2VsZWN0ZWRBZ2VudE9yRW1wbG95ZWV9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkocmVzLmRhdGEpKSB7XHJcbiAgICAgICAgICBzZXRIb2xkZWRDdXN0b21lcnMoXHJcbiAgICAgICAgICAgIHJlcy5kYXRhLm1hcCgoYywgaSkgPT4gKHtcclxuICAgICAgICAgICAgICBfaWQ6IGMuX2lkLFxyXG4gICAgICAgICAgICAgIHNpX25vOiBpICsgMSxcclxuICAgICAgICAgICAgICB1c2VyX25hbWU6IGM/LnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICB1c2VyX3Bob25lOiBjPy51c2VyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IGM/LnVzZXJfaWQ/LmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgIHRpY2tldF9ubzogYz8udGlja2V0cyxcclxuICAgICAgICAgICAgICBncm91cF9uYW1lOiBjPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSxcclxuICAgICAgICAgICAgICBhZ2VudF9uYW1lOiBjPy5hZ2VudD8ubmFtZSxcclxuICAgICAgICAgICAgICBhZ2VudF9jb2RlOiBjPy5hZ2VudD8uZW1wbG95ZWVDb2RlLFxyXG4gICAgICAgICAgICAgIGFnZW50X3Bob25lX251bWJlcjogYz8uYWdlbnQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgc2V0SG9sZGVkQ3VzdG9tZXJzKFtdKTtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgRmV0Y2hpbmcgSG9sZGVkIEN1c3RvbWVyXCIsIGVycik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfSkoKTtcclxuICB9LCBbc2VsZWN0ZWRBZ2VudE9yRW1wbG95ZWVdKTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNpX25vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlcl9uYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJfcGhvbmVcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9pZFwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgSWRcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0X25vXCIsIGhlYWRlcjogXCJUaWNrZXQgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH1cclxuICBdO1xyXG4gIGlmIChzZWxlY3RlZFJlZmZlcmFsPT09XCJBbGxcIikge1xyXG4gICAgY29sdW1ucy5wdXNoKFxyXG4gICAgICB7IGtleTogXCJhZ2VudF9uYW1lXCIsIGhlYWRlcjogXCJBZ2VudCBOYW1lXCIgfSxcclxuICAgICAgeyBrZXk6IFwiYWdlbnRfY29kZVwiLCBoZWFkZXI6IFwiQWdlbnQgSWRcIiB9LFxyXG4gICAgICB7IGtleTogXCJhZ2VudF9waG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkFnZW50IFBob25lIE51bWJlclwiIH0sXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZzogMjQgfX0+XHJcbiAgICAgIDxUaXRsZSBsZXZlbD17M30gc3R5bGU9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiLCBtYXJnaW5Cb3R0b206IDI0IH19PlxyXG4gICAgICAgIEhvbGRlZCBDdXN0b21lciBSZXBvcnRcclxuICAgICAgPC9UaXRsZT5cclxuXHJcbiAgICAgIDxGbGV4IGdhcD1cImxhcmdlXCIgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAyNCB9fT5cclxuICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUmVmZXJyYWwgVHlwZVwiXHJcbiAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMzAwLCBoZWlnaHQ6IDU1IH19XHJcbiAgICAgICAgICBvbkNoYW5nZT17KHYpID0+IHtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRSZWZmZXJhbCh2KTtcclxuICAgICAgICAgICAgc2V0U2VsZWN0ZWRBZ2VudE9yRW1wbG95ZWUoXCJcIik7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgb3B0aW9ucz17cmVmZXJyYWxzLm1hcCgocikgPT4gKHsgbGFiZWw6IHIsIHZhbHVlOiByIH0pKX1cclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICB7c2VsZWN0ZWRSZWZmZXJhbCA9PT0gXCJFbXBsb3llZVwiICYmIChcclxuICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiA1MDAsIGhlaWdodDogNTUgfX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyh2KSA9PiBzZXRTZWxlY3RlZEFnZW50T3JFbXBsb3llZSh2KX1cclxuICAgICAgICAgICAgb3B0aW9ucz17ZW1wbG95ZWVzLm1hcCgoZSkgPT4gKHtcclxuICAgICAgICAgICAgICBsYWJlbDogYCR7ZS5lbXBsb3llZV9uYW1lfSB8ICR7ZS5lbXBsb3llZV9waG9uZV9udW1iZXJ9IHwgJHtlLmVtcGxveWVlX2lkfWAsXHJcbiAgICAgICAgICAgICAgdmFsdWU6IGUuX2lkLFxyXG4gICAgICAgICAgICB9KSl9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICl9XHJcblxyXG4gICAgICAgIHtzZWxlY3RlZFJlZmZlcmFsID09PSBcIkFnZW50XCIgJiYgKFxyXG4gICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEFnZW50XCJcclxuICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDUwMCwgaGVpZ2h0OiA1NSB9fVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KHYpID0+IHNldFNlbGVjdGVkQWdlbnRPckVtcGxveWVlKHYpfVxyXG4gICAgICAgICAgICBvcHRpb25zPXthZ2VudHMubWFwKChhKSA9PiAoe1xyXG4gICAgICAgICAgICAgIGxhYmVsOiBgJHthLmFnZW50X25hbWV9IHwgJHthLmFnZW50X3Bob25lX251bWJlcn0gfCAke2EuYWdlbnRfaWR9YCxcclxuICAgICAgICAgICAgICB2YWx1ZTogYS5faWQsXHJcbiAgICAgICAgICAgIH0pKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9GbGV4PlxyXG5cclxuICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICA8RmxleFxyXG4gICAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiBcIjYwdmhcIiB9fVxyXG4gICAgICAgICAgYWxpZ249XCJjZW50ZXJcIlxyXG4gICAgICAgICAganVzdGlmeT1cImNlbnRlclwiXHJcbiAgICAgICAgICB2ZXJ0aWNhbFxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxTcGluXHJcbiAgICAgICAgICAgIGluZGljYXRvcj17PExvYWRpbmdPdXRsaW5lZCBzdHlsZT17eyBmb250U2l6ZTogNjQgfX0gc3BpbiAvPn1cclxuICAgICAgICAgICAgdGlwPVwiTG9hZGluZyBkYXRhLi4uXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9GbGV4PlxyXG4gICAgICApIDogaG9sZGVkQ3VzdG9tZXJzLmxlbmd0aCA8PSAwID8gKFxyXG4gICAgICAgIDxGbGV4XHJcbiAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IFwiNDB2aFwiIH19XHJcbiAgICAgICAgICBhbGlnbj1cImNlbnRlclwiXHJcbiAgICAgICAgICBqdXN0aWZ5PVwiY2VudGVyXCJcclxuICAgICAgICAgIHZlcnRpY2FsXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgTm8gZGF0YSBmb3VuZFxyXG4gICAgICAgIDwvRmxleD5cclxuICAgICAgKSA6IChcclxuICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgIGRhdGE9e2hvbGRlZEN1c3RvbWVyc31cclxuICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJIb2xkZWRDdXN0b21lclwiXHJcbiAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgSG9sZGVkQ3VzdG9tZXIuY3N2YH1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEhvbGRlZEN1c3RvbWVyUmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvSG9sZGVkQ3VzdG9tZXJSZXBvcnQuanN4In0=