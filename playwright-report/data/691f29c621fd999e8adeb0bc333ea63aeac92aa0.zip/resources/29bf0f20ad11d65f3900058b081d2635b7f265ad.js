import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UnapprovedLoans.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import {
  message,
  Dropdown,
  Menu,
  Drawer,
  Button,
  Input,
  Form,
  Modal,
  Typography,
  Space,
  Divider,
  InputNumber,
  Select,
  DatePicker
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  MoreOutlined,
  UserOutlined,
  CheckCircleOutlined,
  EditOutlined,
  CloseOutlined,
  DollarOutlined,
  CalendarOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import api from "/src/instance/TokenInstance.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import moment from "/node_modules/.vite/deps/moment.js?v=819e0a34";
import { fieldSize } from "/src/data/fieldSize.js";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const { Title, Text } = Typography;
const { Option } = Select;
const { TextArea } = Input;
const UnapprovedLoans = () => {
  _s();
  const [tableData, setTableData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedLoan, setSelectedLoan] = useState(null);
  const [selectedUser, setSelectedUser] = useState(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [showApprovalModal, setShowApprovalModal] = useState(false);
  const [users, setUsers] = useState([]);
  const [agents, setAgents] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [form] = Form.useForm();
  useEffect(() => {
    const fetchUsers = async () => {
      const response = await api.get("/user/get-user");
      return response.data;
    };
    const fetchAgents = async () => {
      const response = await api.get("/agent/get");
      return response.data?.agent;
    };
    const fetchEmployees = async () => {
      const response = await api.get("/employee");
      return response.data?.employee;
    };
    const fetchMasterData = async () => {
      try {
        const [usersData, agentsData, employeesData] = await Promise.all(
          [
            fetchUsers(),
            fetchAgents(),
            fetchEmployees()
          ]
        );
        setUsers(usersData);
        setAgents(agentsData);
        setEmployees(employeesData);
      } catch (error) {
        console.error("Error fetching master data:", error);
        message.error("Failed to load initial data");
        setLoading(false);
      }
    };
    fetchMasterData();
  }, []);
  useEffect(() => {
    const fetchLoans = async () => {
      try {
        setLoading(true);
        const loanRes = await api.get("/loans/get-loan-approval-request");
        const loans = loanRes.data.data || [];
        const formatted = loans.map((loan, index) => {
          const user = users.find((u) => u._id === loan.user_id);
          const menu = /* @__PURE__ */ jsxDEV(Menu, { children: [
            /* @__PURE__ */ jsxDEV(
              Menu.Item,
              {
                onClick: () => handleApproveClick(loan, user),
                children: "Approve"
              },
              "approve",
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                lineNumber: 116,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Menu.Item,
              {
                onClick: () => handleDeleteClick(loan._id),
                children: "Delete"
              },
              "delete",
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                lineNumber: 122,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
            lineNumber: 115,
            columnNumber: 11
          }, this);
          return {
            id: index + 1,
            loanId: loan._id,
            customer_name: loan?.user?.full_name || loan?.user_id?.full_name || "-",
            phone_number: loan?.user?.phone_number || loan?.user_id?.phone_number || "-",
            address: loan?.user?.address || loan?.user_id?.address || "-",
            loan_amount: loan.loan_amount,
            loan_purpose: loan.loan_purpose,
            createdAt: loan?.createdAt ? new Date(loan.createdAt).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric"
            }) : "-",
            approval_status: /* @__PURE__ */ jsxDEV("span", { className: "inline-block px-3 py-1 text-sm font-medium text-yellow-800 bg-yellow-100 rounded-full", children: "Pending" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
              lineNumber: 147,
              columnNumber: 13
            }, this),
            approval_status_raw: loan?.approval_status,
            actions: /* @__PURE__ */ jsxDEV(Dropdown, { overlay: menu, trigger: ["click"], children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "text",
                icon: /* @__PURE__ */ jsxDEV(MoreOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                  lineNumber: 156,
                  columnNumber: 23
                }, this),
                onClick: (e) => e.preventDefault()
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                lineNumber: 154,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
              lineNumber: 153,
              columnNumber: 13
            }, this)
          };
        });
        setTableData(formatted);
      } catch (err) {
        console.error(err);
        message.error("Failed to fetch loan requests");
      } finally {
        setLoading(false);
      }
    };
    fetchLoans();
  }, [reloadTrigger]);
  const handleApproveClick = async (loan, user) => {
    setSelectedLoan(loan);
    setSelectedUser(user);
    setReloadTrigger((prev) => prev + 1);
    const userId = user?._id || loan.user_id;
    form.setFieldsValue({
      borrower: userId,
      loan_amount: loan.loan_amount,
      loan_purpose: loan.loan_purpose
    });
    setShowApprovalModal(true);
  };
  const handleDeleteClick = async (loanId) => {
    try {
      await api.delete(`/loans/delete-loan-request/${loanId}`);
      message.success("Loan request deleted successfully");
      setReloadTrigger((prev) => prev + 1);
    } catch (err) {
      console.error(err);
      message.error("Failed to delete loan request");
    }
  };
  const handleApproveLoan = async () => {
    try {
      const formValues = form.getFieldsValue();
      if (!formValues.start_date || !formValues.end_date) {
        message.error("Please select Start Date and End Date");
        return;
      }
      const formattedStartDate = moment(formValues.start_date).format(
        "YYYY-MM-DD"
      );
      const formattedEndDate = moment(formValues.end_date).format("YYYY-MM-DD");
      await api.put(`/loans/update-loan-approval-request/${selectedLoan._id}`, {
        approval_status: "approved"
      });
      const loanData = {
        borrower: formValues.borrower,
        loan_amount: Number(formValues.loan_amount),
        tenure: Number(formValues.tenure),
        service_charges: Number(formValues.service_charges),
        daily_payment_amount: Number(formValues.daily_payment_amount),
        start_date: formattedStartDate,
        end_date: formattedEndDate,
        note: formValues.note || "",
        referred_type: formValues.referred_type,
        referred_customer: formValues.referred_customer || "",
        referred_employee: formValues.referred_employee || "",
        referred_agent: formValues.referred_agent || "",
        approval_status: "approved"
      };
      await api.post("/loans/add-borrower", loanData);
      message.success("Loan approved successfully");
      setShowApprovalModal(false);
      setReloadTrigger((prev) => prev + 1);
    } catch (err) {
      console.error(err);
      message.error("Failed to approve loan");
    }
  };
  const columns = [
    { key: "id", header: "SL.NO" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "address", header: "Address" },
    { key: "loan_amount", header: "Loan Amount" },
    { key: "loan_purpose", header: "Loan Purpose" },
    { key: "approval_status", header: "Approval Status" },
    { key: "createdAt", header: "Created At" },
    { key: "actions", header: "Actions" }
  ];
  const loanColumns = [
    { key: "id", header: "SL.NO" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "address", header: "Address" },
    { key: "loan_amount", header: "Loan Amount" },
    { key: "loan_purpose", header: "Loan Purpose" },
    { key: "createdAt", header: "Created Date" },
    // <--- Column Added Here
    { key: "approval_status_raw", header: "Approval Status" }
    // { key: "actions", header: "Actions" },
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
      lineNumber: 276,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
      lineNumber: 277,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
        lineNumber: 280,
        columnNumber: 20
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold mb-6", children: "Unapproved Loan Requests" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
        lineNumber: 281,
        columnNumber: 9
      }, this),
      !loading && tableData.length > 0 ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: tableData,
          columns,
          exportCols: loanColumns,
          exportedPdfName: "Unapproved Loans",
          exportedFileName: "unapproved_loans.csv"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
          lineNumber: 286,
          columnNumber: 9
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading: loading,
          failure: tableData.length === 0 && !loading,
          data: "Loan Requests"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
          lineNumber: 294,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
      lineNumber: 279,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        title: "Approve Loan Request",
        open: showApprovalModal,
        onCancel: () => {
          setShowApprovalModal(false);
          form.resetFields();
        },
        footer: null,
        width: 800,
        children: /* @__PURE__ */ jsxDEV(Form, { form, layout: "vertical", onFinish: handleApproveLoan, children: [
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              name: "borrower",
              className: "mt-10",
              label: "Borrower Name",
              rules: [{ required: true, message: "Please select borrower" }],
              children: /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  showSearch: true,
                  placeholder: "Select Or Search Borrower Name",
                  popupMatchSelectWidth: false,
                  filterOption: (input, option) => {
                    const text = option?.children?.toString().toLowerCase() || "";
                    return text.includes(input.toLowerCase());
                  },
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                      user.customer_id,
                      " | ",
                      user.full_name,
                      " | ",
                      user.phone_number
                    ] }, user._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                      lineNumber: 331,
                      columnNumber: 15
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                  lineNumber: 320,
                  columnNumber: 13
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
              lineNumber: 314,
              columnNumber: 11
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
            /* @__PURE__ */ jsxDEV(
              Form.Item,
              {
                name: "loan_amount",
                label: "Loan Amount",
                className: "w-1/2",
                rules: [{ required: true, message: "Enter loan amount" }],
                children: /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    placeholder: "Enter Loan Amount",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                    lineNumber: 346,
                    columnNumber: 15
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                lineNumber: 340,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Form.Item,
              {
                name: "tenure",
                label: "Tenure (Days)",
                className: "w-1/2",
                rules: [{ required: true, message: "Enter tenure" }],
                children: /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    placeholder: "Enter Tenure in Days",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                    lineNumber: 359,
                    columnNumber: 15
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                lineNumber: 353,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
            lineNumber: 339,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
            /* @__PURE__ */ jsxDEV(
              Form.Item,
              {
                name: "service_charges",
                label: "Service Charges",
                className: "w-1/2",
                rules: [{ required: true, message: "Enter service charges" }],
                children: /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    placeholder: "Enter Service Charges",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                    lineNumber: 374,
                    columnNumber: 15
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                lineNumber: 368,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Form.Item,
              {
                name: "daily_payment_amount",
                label: "Daily Payment Amount",
                className: "w-1/2",
                rules: [
                  { required: true, message: "Enter daily payment amount" }
                ],
                children: /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    placeholder: "Enter Daily Payment",
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                    lineNumber: 389,
                    columnNumber: 15
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                lineNumber: 381,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
            lineNumber: 367,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
            /* @__PURE__ */ jsxDEV(
              Form.Item,
              {
                name: "start_date",
                label: "Start Date",
                className: "w-1/2",
                rules: [{ required: true, message: "Select start date" }],
                children: /* @__PURE__ */ jsxDEV(
                  DatePicker,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                    format: "DD/MM/YYYY"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                    lineNumber: 405,
                    columnNumber: 15
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                lineNumber: 399,
                columnNumber: 13
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Form.Item,
              {
                name: "end_date",
                label: "End Date",
                className: "w-1/2",
                rules: [{ required: true, message: "Select end date" }],
                children: /* @__PURE__ */ jsxDEV(
                  DatePicker,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                    format: "DD/MM/YYYY"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                    lineNumber: 417,
                    columnNumber: 15
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                lineNumber: 411,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
            lineNumber: 398,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(
            Form.Item,
            {
              name: "referred_type",
              label: "Referred Type",
              rules: [{ required: true, message: "Select referred type" }],
              children: /* @__PURE__ */ jsxDEV(
                Select,
                {
                  placeholder: "Select Referred Type",
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  showSearch: true,
                  popupMatchSelectWidth: false,
                  filterOption: (input, option) => {
                    const text = option?.children?.toString().toLowerCase() || "";
                    return text.includes(input.toLowerCase());
                  },
                  children: ["Self Joining", "Customer", "Employee", "Agent", "Others"].map(
                    (type) => /* @__PURE__ */ jsxDEV(Select.Option, { value: type, children: type }, type, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                      lineNumber: 442,
                      columnNumber: 17
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                  lineNumber: 430,
                  columnNumber: 13
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
              lineNumber: 425,
              columnNumber: 11
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(Form.Item, { noStyle: true, shouldUpdate: (prev, curr) => prev.referred_type !== curr.referred_type, children: ({ getFieldValue }) => {
            const type = getFieldValue("referred_type");
            if (type === "Customer") {
              return /* @__PURE__ */ jsxDEV(
                Form.Item,
                {
                  name: "referred_customer",
                  label: "Referred Customer",
                  rules: [{ required: true, message: "Select customer" }],
                  children: /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      placeholder: "Select Referred Customer",
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      showSearch: true,
                      popupMatchSelectWidth: false,
                      filterOption: (input, option) => option?.children?.toString().toLowerCase().includes(input.toLowerCase()),
                      children: users.map(
                        (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                          user.full_name,
                          " | ",
                          user.phone_number
                        ] }, user._id, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                          lineNumber: 471,
                          columnNumber: 23
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                      lineNumber: 461,
                      columnNumber: 21
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                  lineNumber: 456,
                  columnNumber: 19
                },
                this
              );
            }
            if (type === "Employee") {
              return /* @__PURE__ */ jsxDEV(
                Form.Item,
                {
                  name: "referred_employee",
                  label: "Referred Employee",
                  rules: [{ required: true, message: "Select employee" }],
                  children: /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      placeholder: "Select Employee",
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      showSearch: true,
                      popupMatchSelectWidth: false,
                      filterOption: (input, option) => option?.children?.toString().toLowerCase().includes(input.toLowerCase()),
                      children: employees.map(
                        (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: [
                          emp.name,
                          " | ",
                          emp.phone_number
                        ] }, emp._id, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                          lineNumber: 497,
                          columnNumber: 23
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                      lineNumber: 487,
                      columnNumber: 21
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                  lineNumber: 482,
                  columnNumber: 19
                },
                this
              );
            }
            if (type === "Agent") {
              return /* @__PURE__ */ jsxDEV(
                Form.Item,
                {
                  name: "referred_agent",
                  label: "Referred Agent",
                  rules: [{ required: true, message: "Select agent" }],
                  children: /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      placeholder: "Select Agent",
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      showSearch: true,
                      popupMatchSelectWidth: false,
                      filterOption: (input, option) => option?.children?.toString().toLowerCase().includes(input.toLowerCase()),
                      children: agents.map(
                        (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: [
                          agent.name,
                          " | ",
                          agent.phone_number
                        ] }, agent._id, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                          lineNumber: 523,
                          columnNumber: 23
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                      lineNumber: 513,
                      columnNumber: 21
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                  lineNumber: 508,
                  columnNumber: 19
                },
                this
              );
            }
            if (type === "Others") {
              return /* @__PURE__ */ jsxDEV(
                Form.Item,
                {
                  name: "referred_others",
                  label: "Referred By",
                  rules: [{ required: true, message: "Enter reference name" }],
                  children: /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      placeholder: "Enter reference name",
                      className: "h-14 rounded-lg"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                      lineNumber: 539,
                      columnNumber: 21
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                  lineNumber: 534,
                  columnNumber: 19
                },
                this
              );
            }
            return null;
          } }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
            lineNumber: 450,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Form.Item, { name: "note", label: "Note", children: /* @__PURE__ */ jsxDEV(Input.TextArea, { rows: 3, placeholder: "Specify note if any" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
            lineNumber: 647,
            columnNumber: 13
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
            lineNumber: 646,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-3", children: [
            /* @__PURE__ */ jsxDEV(Button, { onClick: () => setShowApprovalModal(false), children: "Cancel" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
              lineNumber: 652,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "primary",
                htmlType: "submit",
                icon: /* @__PURE__ */ jsxDEV(CheckCircleOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                  lineNumber: 656,
                  columnNumber: 21
                }, this),
                children: "Approve Loan"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
                lineNumber: 653,
                columnNumber: 13
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
            lineNumber: 651,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
          lineNumber: 312,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
        lineNumber: 302,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx",
    lineNumber: 275,
    columnNumber: 5
  }, this);
};
_s(UnapprovedLoans, "XlaewNUyM5fCtvym1PMMOTNkJss=", false, function() {
  return [Form.useForm];
});
_c = UnapprovedLoans;
export default UnapprovedLoans;
var _c;
$RefreshReg$(_c, "UnapprovedLoans");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnapprovedLoans.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUhjOzJCQW5IZDtBQUFvQkEsb0JBQWdCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0M7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1A7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU0sRUFBRUMsT0FBT0MsS0FBSyxJQUFJdEI7QUFDeEIsTUFBTSxFQUFFdUIsT0FBTyxJQUFJbkI7QUFDbkIsTUFBTSxFQUFFb0IsU0FBUyxJQUFJM0I7QUFFckIsTUFBTTRCLGtCQUFrQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzVCLFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJckMsU0FBUyxFQUFFO0FBRTdDLFFBQU0sQ0FBQ3NDLFNBQVNDLFVBQVUsSUFBSXZDLFNBQVMsSUFBSTtBQUMzQyxRQUFNLENBQUN3QyxjQUFjQyxlQUFlLElBQUl6QyxTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDMEMsY0FBY0MsZUFBZSxJQUFJM0MsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQzRDLGNBQWNDLGVBQWUsSUFBSTdDLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUM4QyxtQkFBbUJDLG9CQUFvQixJQUFJL0MsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQ2dELG1CQUFtQkMsb0JBQW9CLElBQUlqRCxTQUFTLEtBQUs7QUFDaEUsUUFBTSxDQUFDa0QsT0FBT0MsUUFBUSxJQUFJbkQsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ29ELFFBQVFDLFNBQVMsSUFBSXJELFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNzRCxXQUFXQyxZQUFZLElBQUl2RCxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDd0QsZUFBZUMsZ0JBQWdCLElBQUl6RCxTQUFTLENBQUM7QUFDcEQsUUFBTSxDQUFDMEQsSUFBSSxJQUFJbkQsS0FBS29ELFFBQVE7QUFHNUJDLFlBQVUsTUFBTTtBQUNkLFVBQU1DLGFBQWEsWUFBWTtBQUM3QixZQUFNQyxXQUFXLE1BQU1yQyxJQUFJc0MsSUFBSSxnQkFBZ0I7QUFDL0MsYUFBT0QsU0FBU0U7QUFBQUEsSUFDbEI7QUFFQSxVQUFNQyxjQUFjLFlBQVk7QUFDOUIsWUFBTUgsV0FBVyxNQUFNckMsSUFBSXNDLElBQUksWUFBWTtBQUMzQyxhQUFPRCxTQUFTRSxNQUFNRTtBQUFBQSxJQUN4QjtBQUVBLFVBQU1DLGlCQUFpQixZQUFZO0FBQ2pDLFlBQU1MLFdBQVcsTUFBTXJDLElBQUlzQyxJQUFJLFdBQVc7QUFDMUMsYUFBT0QsU0FBU0UsTUFBTUk7QUFBQUEsSUFDeEI7QUFFQSxVQUFNQyxrQkFBa0IsWUFBWTtBQUNsQyxVQUFJO0FBRUYsY0FBTSxDQUFDQyxXQUFXQyxZQUFZQyxhQUFhLElBQUksTUFBTUMsUUFBUUM7QUFBQUEsVUFBSTtBQUFBLFlBQy9EYixXQUFXO0FBQUEsWUFDWEksWUFBWTtBQUFBLFlBQ1pFLGVBQWU7QUFBQSxVQUFDO0FBQUEsUUFDakI7QUFFRGhCLGlCQUFTbUIsU0FBUztBQUNsQmpCLGtCQUFVa0IsVUFBVTtBQUNwQmhCLHFCQUFhaUIsYUFBYTtBQUFBLE1BSTVCLFNBQVNHLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sK0JBQStCQSxLQUFLO0FBQ2xEMUUsZ0JBQVEwRSxNQUFNLDZCQUE2QjtBQUMzQ3BDLG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFFQThCLG9CQUFnQjtBQUFBLEVBQ2xCLEdBQUcsRUFBRTtBQUdMVCxZQUFVLE1BQU07QUFFZCxVQUFNaUIsYUFBYSxZQUFZO0FBSTdCLFVBQUk7QUFDRnRDLG1CQUFXLElBQUk7QUFDZixjQUFNdUMsVUFBVSxNQUFNckQsSUFBSXNDLElBQUksa0NBQWtDO0FBQ2hFLGNBQU1nQixRQUFRRCxRQUFRZCxLQUFLQSxRQUFRO0FBR25DLGNBQU1nQixZQUFZRCxNQUFNRSxJQUFJLENBQUNDLE1BQU1DLFVBQVU7QUFFM0MsZ0JBQU1DLE9BQU9sQyxNQUFNbUMsS0FBSyxDQUFDQyxNQUFNQSxFQUFFQyxRQUFRTCxLQUFLTSxPQUFPO0FBRXJELGdCQUFNQyxPQUNKLHVCQUFDLFFBQ0M7QUFBQTtBQUFBLGNBQUMsS0FBSztBQUFBLGNBQUw7QUFBQSxnQkFFQyxTQUFTLE1BQU1DLG1CQUFtQlIsTUFBTUUsSUFBSTtBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQUQxQztBQUFBLGNBRE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUMsS0FBSztBQUFBLGNBQUw7QUFBQSxnQkFFQyxTQUFTLE1BQU1PLGtCQUFrQlQsS0FBS0ssR0FBRztBQUFBLGdCQUFFO0FBQUE7QUFBQSxjQUR2QztBQUFBLGNBRE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWFBO0FBR0YsaUJBQU87QUFBQSxZQUNMSyxJQUFJVCxRQUFRO0FBQUEsWUFDWlUsUUFBUVgsS0FBS0s7QUFBQUEsWUFDYk8sZUFBZVosTUFBTUUsTUFBTVcsYUFBYWIsTUFBTU0sU0FBU08sYUFBYTtBQUFBLFlBQ3BFQyxjQUFjZCxNQUFNRSxNQUFNWSxnQkFBZ0JkLE1BQU1NLFNBQVNRLGdCQUFnQjtBQUFBLFlBQ3pFQyxTQUFTZixNQUFNRSxNQUFNYSxXQUFXZixNQUFNTSxTQUFTUyxXQUFXO0FBQUEsWUFDMURDLGFBQWFoQixLQUFLZ0I7QUFBQUEsWUFDbEJDLGNBQWNqQixLQUFLaUI7QUFBQUEsWUFDbkJDLFdBQVdsQixNQUFNa0IsWUFDYixJQUFJQyxLQUFLbkIsS0FBS2tCLFNBQVMsRUFBRUUsbUJBQW1CLFNBQVM7QUFBQSxjQUNyREMsS0FBSztBQUFBLGNBQ0xDLE9BQU87QUFBQSxjQUNQQyxNQUFNO0FBQUEsWUFDUixDQUFDLElBQ0M7QUFBQSxZQUNKQyxpQkFDRSx1QkFBQyxVQUFLLFdBQVUseUZBQXdGLHVCQUF4RztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFRkMscUJBQXFCekIsTUFBTXdCO0FBQUFBLFlBQzNCRSxTQUNFLHVCQUFDLFlBQVMsU0FBU25CLE1BQU0sU0FBUyxDQUFDLE9BQU8sR0FDeEM7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBTSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFhO0FBQUEsZ0JBQ25CLFNBQVMsQ0FBQ29CLE1BQU1BLEVBQUVDLGVBQWU7QUFBQTtBQUFBLGNBSG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUdxQyxLQUp2QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsVUFFSjtBQUFBLFFBQ0YsQ0FBQztBQUVEekUscUJBQWEyQyxTQUFTO0FBQUEsTUFDeEIsU0FBUytCLEtBQUs7QUFDWm5DLGdCQUFRRCxNQUFNb0MsR0FBRztBQUNqQjlHLGdCQUFRMEUsTUFBTSwrQkFBK0I7QUFBQSxNQUMvQyxVQUFDO0FBRUNwQyxtQkFBVyxLQUFLO0FBQUEsTUFDbEI7QUFBQSxJQUNGO0FBRUFzQyxlQUFXO0FBQUEsRUFDYixHQUFHLENBQUNyQixhQUFhLENBQUM7QUFFbEIsUUFBTWtDLHFCQUFxQixPQUFPUixNQUFNRSxTQUFTO0FBQy9DekMsb0JBQWdCdUMsSUFBSTtBQUNwQnJDLG9CQUFnQnVDLElBQUk7QUFDcEIzQixxQkFBaUIsQ0FBQ3VELFNBQVNBLE9BQU8sQ0FBQztBQUNuQyxVQUFNQyxTQUFTN0IsTUFBTUcsT0FBT0wsS0FBS007QUFFakM5QixTQUFLd0QsZUFBZTtBQUFBLE1BQ2xCQyxVQUFVRjtBQUFBQSxNQUNWZixhQUFhaEIsS0FBS2dCO0FBQUFBLE1BQ2xCQyxjQUFjakIsS0FBS2lCO0FBQUFBLElBQ3JCLENBQUM7QUFFRGxELHlCQUFxQixJQUFJO0FBQUEsRUFDM0I7QUFFQSxRQUFNMEMsb0JBQW9CLE9BQU9FLFdBQVc7QUFDMUMsUUFBSTtBQUNGLFlBQU1wRSxJQUFJMkYsT0FBTyw4QkFBOEJ2QixNQUFNLEVBQUU7QUFDdkQ1RixjQUFRb0gsUUFBUSxtQ0FBbUM7QUFDbkQ1RCx1QkFBaUIsQ0FBQ3VELFNBQVNBLE9BQU8sQ0FBQztBQUFBLElBQ3JDLFNBQVNELEtBQUs7QUFDWm5DLGNBQVFELE1BQU1vQyxHQUFHO0FBQ2pCOUcsY0FBUTBFLE1BQU0sK0JBQStCO0FBQUEsSUFDL0M7QUFBQSxFQUNGO0FBRUEsUUFBTTJDLG9CQUFvQixZQUFZO0FBQ3BDLFFBQUk7QUFDRixZQUFNQyxhQUFhN0QsS0FBSzhELGVBQWU7QUFFdkMsVUFBSSxDQUFDRCxXQUFXRSxjQUFjLENBQUNGLFdBQVdHLFVBQVU7QUFDbER6SCxnQkFBUTBFLE1BQU0sdUNBQXVDO0FBQ3JEO0FBQUEsTUFDRjtBQUVBLFlBQU1nRCxxQkFBcUJoRyxPQUFPNEYsV0FBV0UsVUFBVSxFQUFFRztBQUFBQSxRQUN2RDtBQUFBLE1BQ0Y7QUFDQSxZQUFNQyxtQkFBbUJsRyxPQUFPNEYsV0FBV0csUUFBUSxFQUFFRSxPQUFPLFlBQVk7QUFFeEUsWUFBTW5HLElBQUlxRyxJQUFJLHVDQUF1Q3BGLGFBQWE2QyxHQUFHLElBQUk7QUFBQSxRQUN2RW1CLGlCQUFpQjtBQUFBLE1BQ25CLENBQUM7QUFFRCxZQUFNcUIsV0FBVztBQUFBLFFBQ2ZaLFVBQVVJLFdBQVdKO0FBQUFBLFFBQ3JCakIsYUFBYThCLE9BQU9ULFdBQVdyQixXQUFXO0FBQUEsUUFDMUMrQixRQUFRRCxPQUFPVCxXQUFXVSxNQUFNO0FBQUEsUUFDaENDLGlCQUFpQkYsT0FBT1QsV0FBV1csZUFBZTtBQUFBLFFBQ2xEQyxzQkFBc0JILE9BQU9ULFdBQVdZLG9CQUFvQjtBQUFBLFFBQzVEVixZQUFZRTtBQUFBQSxRQUNaRCxVQUFVRztBQUFBQSxRQUNWTyxNQUFNYixXQUFXYSxRQUFRO0FBQUEsUUFDekJDLGVBQWVkLFdBQVdjO0FBQUFBLFFBQzFCQyxtQkFBbUJmLFdBQVdlLHFCQUFxQjtBQUFBLFFBQ25EQyxtQkFBbUJoQixXQUFXZ0IscUJBQXFCO0FBQUEsUUFDbkRDLGdCQUFnQmpCLFdBQVdpQixrQkFBa0I7QUFBQSxRQUM3QzlCLGlCQUFpQjtBQUFBLE1BQ25CO0FBRUEsWUFBTWpGLElBQUlnSCxLQUFLLHVCQUF1QlYsUUFBUTtBQUU5QzlILGNBQVFvSCxRQUFRLDRCQUE0QjtBQUM1Q3BFLDJCQUFxQixLQUFLO0FBRTFCUSx1QkFBaUIsQ0FBQ3VELFNBQVNBLE9BQU8sQ0FBQztBQUFBLElBQ3JDLFNBQVNELEtBQUs7QUFDWm5DLGNBQVFELE1BQU1vQyxHQUFHO0FBQ2pCOUcsY0FBUTBFLE1BQU0sd0JBQXdCO0FBQUEsSUFDeEM7QUFBQSxFQUNGO0FBRUEsUUFBTStELFVBQVU7QUFBQSxJQUNkLEVBQUVDLEtBQUssTUFBTUMsUUFBUSxRQUFRO0FBQUEsSUFDN0IsRUFBRUQsS0FBSyxpQkFBaUJDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxtQkFBbUJDLFFBQVEsa0JBQWtCO0FBQUEsSUFDcEQsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGFBQWE7QUFBQSxJQUN6QyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsVUFBVTtBQUFBLEVBQUM7QUFHdkMsUUFBTUMsY0FBYztBQUFBLElBQ2xCLEVBQUVGLEtBQUssTUFBTUMsUUFBUSxRQUFRO0FBQUEsSUFDN0IsRUFBRUQsS0FBSyxpQkFBaUJDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVELEtBQUssV0FBV0MsUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRUQsS0FBSyxlQUFlQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGVBQWU7QUFBQTtBQUFBLElBQzNDLEVBQUVELEtBQUssdUJBQXVCQyxRQUFRLGtCQUFrQjtBQUFBO0FBQUEsRUFDeEQ7QUFJRixTQUNFLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSLHVCQUFDLFVBQU8sWUFBVSxRQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtCO0FBQUEsSUFFbEIsdUJBQUMsU0FBSSxXQUFVLGlCQUNGO0FBQUEsNkJBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFXO0FBQUEsTUFDdEIsdUJBQUMsUUFBRyxXQUFVLCtCQUE4Qix3Q0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQyxDQUFDdEcsV0FBV0YsVUFBVTBHLFNBQVMsSUFDOUI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU0xRztBQUFBQSxVQUNOO0FBQUEsVUFDQSxZQUFZeUc7QUFBQUEsVUFDWixpQkFBZ0I7QUFBQSxVQUNoQixrQkFBaUI7QUFBQTtBQUFBLFFBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUt5QyxJQUd6QztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBV3ZHO0FBQUFBLFVBQ1gsU0FBU0YsVUFBVTBHLFdBQVcsS0FBSyxDQUFDeEc7QUFBQUEsVUFDcEMsTUFBSztBQUFBO0FBQUEsUUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHc0I7QUFBQSxTQWxCMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU07QUFBQSxRQUNOLE1BQU1VO0FBQUFBLFFBQ04sVUFBVSxNQUFNO0FBQ2RDLCtCQUFxQixLQUFLO0FBQzFCUyxlQUFLcUYsWUFBWTtBQUFBLFFBQ25CO0FBQUEsUUFDQSxRQUFRO0FBQUEsUUFDUixPQUFPO0FBQUEsUUFFUCxpQ0FBQyxRQUFLLE1BQVksUUFBTyxZQUFXLFVBQVV6QixtQkFFNUM7QUFBQTtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFdBQVU7QUFBQSxjQUNWLE9BQU07QUFBQSxjQUNOLE9BQU8sQ0FBQyxFQUFFMEIsVUFBVSxNQUFNL0ksU0FBUyx5QkFBeUIsQ0FBQztBQUFBLGNBRTdEO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVjtBQUFBLGtCQUNBLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkIsY0FBYyxDQUFDZ0osT0FBT0MsV0FBVztBQUMvQiwwQkFBTUMsT0FBT0QsUUFBUUUsVUFBVUMsU0FBUyxFQUFFQyxZQUFZLEtBQUs7QUFDM0QsMkJBQU9ILEtBQUtJLFNBQVNOLE1BQU1LLFlBQVksQ0FBQztBQUFBLGtCQUMxQztBQUFBLGtCQUVDcEcsZ0JBQU0rQjtBQUFBQSxvQkFBSSxDQUFDRyxTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLRyxLQUN2Q0g7QUFBQUEsMkJBQUtvRTtBQUFBQSxzQkFBWTtBQUFBLHNCQUFJcEUsS0FBS1c7QUFBQUEsc0JBQVU7QUFBQSxzQkFBSVgsS0FBS1k7QUFBQUEseUJBRDVCWixLQUFLRyxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWVBO0FBQUE7QUFBQSxZQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFzQkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBO0FBQUEsY0FBQyxLQUFLO0FBQUEsY0FBTDtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFNO0FBQUEsZ0JBQ04sV0FBVTtBQUFBLGdCQUNWLE9BQU8sQ0FBQyxFQUFFeUQsVUFBVSxNQUFNL0ksU0FBUyxvQkFBb0IsQ0FBQztBQUFBLGdCQUV4RDtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsYUFBWTtBQUFBLG9CQUNaLFdBQVcscUNBQXFDMkIsVUFBVTZILE1BQU07QUFBQTtBQUFBLGtCQUhsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBR2lLO0FBQUE7QUFBQSxjQVRuSztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXQTtBQUFBLFlBRUE7QUFBQSxjQUFDLEtBQUs7QUFBQSxjQUFMO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU07QUFBQSxnQkFDTixXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxDQUFDLEVBQUVULFVBQVUsTUFBTS9JLFNBQVMsZUFBZSxDQUFDO0FBQUEsZ0JBRW5EO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osV0FBVyxxQ0FBcUMyQixVQUFVNkgsTUFBTTtBQUFBO0FBQUEsa0JBSGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHaUs7QUFBQTtBQUFBLGNBVG5LO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdBO0FBQUEsZUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxjQUFDLEtBQUs7QUFBQSxjQUFMO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU07QUFBQSxnQkFDTixXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxDQUFDLEVBQUVULFVBQVUsTUFBTS9JLFNBQVMsd0JBQXdCLENBQUM7QUFBQSxnQkFFNUQ7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLGFBQVk7QUFBQSxvQkFDWixXQUFXLHFDQUFxQzJCLFVBQVU2SCxNQUFNO0FBQUE7QUFBQSxrQkFIbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUdpSztBQUFBO0FBQUEsY0FUbks7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV0E7QUFBQSxZQUVBO0FBQUEsY0FBQyxLQUFLO0FBQUEsY0FBTDtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxPQUFNO0FBQUEsZ0JBQ04sV0FBVTtBQUFBLGdCQUNWLE9BQU87QUFBQSxrQkFDTCxFQUFFVCxVQUFVLE1BQU0vSSxTQUFTLDZCQUE2QjtBQUFBLGdCQUFDO0FBQUEsZ0JBRzNEO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxhQUFZO0FBQUEsb0JBQ1osV0FBVyxxQ0FBcUMyQixVQUFVNkgsTUFBTTtBQUFBO0FBQUEsa0JBSGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHaUs7QUFBQTtBQUFBLGNBWG5LO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWFBO0FBQUEsZUEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE0QkE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUE7QUFBQSxjQUFDLEtBQUs7QUFBQSxjQUFMO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU07QUFBQSxnQkFDTixXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxDQUFDLEVBQUVULFVBQVUsTUFBTS9JLFNBQVMsb0JBQW9CLENBQUM7QUFBQSxnQkFFeEQ7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVyxxQ0FBcUMyQixVQUFVNkgsTUFBTTtBQUFBLG9CQUNoRSxRQUFPO0FBQUE7QUFBQSxrQkFGVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRXFCO0FBQUE7QUFBQSxjQVJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLFlBRUE7QUFBQSxjQUFDLEtBQUs7QUFBQSxjQUFMO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE9BQU07QUFBQSxnQkFDTixXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxDQUFDLEVBQUVULFVBQVUsTUFBTS9JLFNBQVMsa0JBQWtCLENBQUM7QUFBQSxnQkFFdEQ7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVyxxQ0FBcUMyQixVQUFVNkgsTUFBTTtBQUFBLG9CQUNoRSxRQUFPO0FBQUE7QUFBQSxrQkFGVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRXFCO0FBQUE7QUFBQSxjQVJ2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFVQTtBQUFBLGVBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd0JBO0FBQUEsVUFHQTtBQUFBLFlBQUMsS0FBSztBQUFBLFlBQUw7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE9BQU07QUFBQSxjQUNOLE9BQU8sQ0FBQyxFQUFFVCxVQUFVLE1BQU0vSSxTQUFTLHVCQUF1QixDQUFDO0FBQUEsY0FFM0Q7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsYUFBWTtBQUFBLGtCQUNaLFdBQVU7QUFBQSxrQkFDVjtBQUFBLGtCQUNBLHVCQUF1QjtBQUFBLGtCQUN2QixjQUFjLENBQUNnSixPQUFPQyxXQUFXO0FBQy9CLDBCQUFNQyxPQUFPRCxRQUFRRSxVQUFVQyxTQUFTLEVBQUVDLFlBQVksS0FBSztBQUMzRCwyQkFBT0gsS0FBS0ksU0FBU04sTUFBTUssWUFBWSxDQUFDO0FBQUEsa0JBQzFDO0FBQUEsa0JBRUMsV0FBQyxnQkFBZ0IsWUFBWSxZQUFZLFNBQVMsUUFBUSxFQUFFckU7QUFBQUEsb0JBQzNELENBQUN5RSxTQUNDLHVCQUFDLE9BQU8sUUFBUCxFQUF5QixPQUFPQSxNQUM5QkEsa0JBRGlCQSxNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBRUo7QUFBQTtBQUFBLGdCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpQkE7QUFBQTtBQUFBLFlBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXVCQTtBQUFBLFVBRUEsdUJBQUMsS0FBSyxNQUFMLEVBQVUsU0FBTyxNQUFDLGNBQWMsQ0FBQzFDLE1BQU0yQyxTQUFTM0MsS0FBS3FCLGtCQUFrQnNCLEtBQUt0QixlQUMxRSxXQUFDLEVBQUV1QixjQUFjLE1BQU07QUFDdEIsa0JBQU1GLE9BQU9FLGNBQWMsZUFBZTtBQUUxQyxnQkFBSUYsU0FBUyxZQUFZO0FBQ3ZCLHFCQUNFO0FBQUEsZ0JBQUMsS0FBSztBQUFBLGdCQUFMO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE9BQU07QUFBQSxrQkFDTixPQUFPLENBQUMsRUFBRVYsVUFBVSxNQUFNL0ksU0FBUyxrQkFBa0IsQ0FBQztBQUFBLGtCQUV0RDtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxhQUFZO0FBQUEsc0JBQ1osV0FBVTtBQUFBLHNCQUNWO0FBQUEsc0JBQ0EsdUJBQXVCO0FBQUEsc0JBQ3ZCLGNBQWMsQ0FBQ2dKLE9BQU9DLFdBQ3BCQSxRQUFRRSxVQUFVQyxTQUFTLEVBQUVDLFlBQVksRUFBRUMsU0FBU04sTUFBTUssWUFBWSxDQUFDO0FBQUEsc0JBR3hFcEcsZ0JBQU0rQjtBQUFBQSx3QkFBSSxDQUFDRyxTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLRyxLQUN2Q0g7QUFBQUEsK0JBQUtXO0FBQUFBLDBCQUFVO0FBQUEsMEJBQUlYLEtBQUtZO0FBQUFBLDZCQURQWixLQUFLRyxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsc0JBQ0Q7QUFBQTtBQUFBLG9CQWJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFjQTtBQUFBO0FBQUEsZ0JBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW9CQTtBQUFBLFlBRUo7QUFFQSxnQkFBSW1FLFNBQVMsWUFBWTtBQUN2QixxQkFDRTtBQUFBLGdCQUFDLEtBQUs7QUFBQSxnQkFBTDtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFNO0FBQUEsa0JBQ04sT0FBTyxDQUFDLEVBQUVWLFVBQVUsTUFBTS9JLFNBQVMsa0JBQWtCLENBQUM7QUFBQSxrQkFFdEQ7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsYUFBWTtBQUFBLHNCQUNaLFdBQVU7QUFBQSxzQkFDVjtBQUFBLHNCQUNBLHVCQUF1QjtBQUFBLHNCQUN2QixjQUFjLENBQUNnSixPQUFPQyxXQUNwQkEsUUFBUUUsVUFBVUMsU0FBUyxFQUFFQyxZQUFZLEVBQUVDLFNBQVNOLE1BQU1LLFlBQVksQ0FBQztBQUFBLHNCQUd4RWhHLG9CQUFVMkI7QUFBQUEsd0JBQUksQ0FBQzRFLFFBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLElBQUl0RSxLQUNyQ3NFO0FBQUFBLDhCQUFJQztBQUFBQSwwQkFBSztBQUFBLDBCQUFJRCxJQUFJN0Q7QUFBQUEsNkJBREE2RCxJQUFJdEUsS0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNEO0FBQUE7QUFBQSxvQkFiSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBY0E7QUFBQTtBQUFBLGdCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FvQkE7QUFBQSxZQUVKO0FBRUEsZ0JBQUltRSxTQUFTLFNBQVM7QUFDcEIscUJBQ0U7QUFBQSxnQkFBQyxLQUFLO0FBQUEsZ0JBQUw7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBTTtBQUFBLGtCQUNOLE9BQU8sQ0FBQyxFQUFFVixVQUFVLE1BQU0vSSxTQUFTLGVBQWUsQ0FBQztBQUFBLGtCQUVuRDtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxhQUFZO0FBQUEsc0JBQ1osV0FBVTtBQUFBLHNCQUNWO0FBQUEsc0JBQ0EsdUJBQXVCO0FBQUEsc0JBQ3ZCLGNBQWMsQ0FBQ2dKLE9BQU9DLFdBQ3BCQSxRQUFRRSxVQUFVQyxTQUFTLEVBQUVDLFlBQVksRUFBRUMsU0FBU04sTUFBTUssWUFBWSxDQUFDO0FBQUEsc0JBR3hFbEcsaUJBQU82QjtBQUFBQSx3QkFBSSxDQUFDZixVQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNcUIsS0FDekNyQjtBQUFBQSxnQ0FBTTRGO0FBQUFBLDBCQUFLO0FBQUEsMEJBQUk1RixNQUFNOEI7QUFBQUEsNkJBREo5QixNQUFNcUIsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNEO0FBQUE7QUFBQSxvQkFiSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBY0E7QUFBQTtBQUFBLGdCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FvQkE7QUFBQSxZQUVKO0FBRUEsZ0JBQUltRSxTQUFTLFVBQVU7QUFDckIscUJBQ0U7QUFBQSxnQkFBQyxLQUFLO0FBQUEsZ0JBQUw7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBTTtBQUFBLGtCQUNOLE9BQU8sQ0FBQyxFQUFFVixVQUFVLE1BQU0vSSxTQUFTLHVCQUF1QixDQUFDO0FBQUEsa0JBRTNEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLGFBQVk7QUFBQSxzQkFDWixXQUFVO0FBQUE7QUFBQSxvQkFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRTZCO0FBQUE7QUFBQSxnQkFQL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBU0E7QUFBQSxZQUVKO0FBRUEsbUJBQU87QUFBQSxVQUNULEtBbEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbUdBO0FBQUEsVUFpR0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxRQUFPLE9BQU0sUUFDM0IsaUNBQUMsTUFBTSxVQUFOLEVBQWUsTUFBTSxHQUFHLGFBQVkseUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBELEtBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUdBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLG1DQUFDLFVBQU8sU0FBUyxNQUFNZ0QscUJBQXFCLEtBQUssR0FBRyxzQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEQ7QUFBQSxZQUMxRDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxVQUFTO0FBQUEsZ0JBQ1QsTUFBTSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvQjtBQUFBLGdCQUFJO0FBQUE7QUFBQSxjQUhoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQTtBQUFBLGVBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFTQTtBQUFBLGFBNVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2VkE7QUFBQTtBQUFBLE1BdldGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXdXQTtBQUFBLE9BbllGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvWUE7QUFFSjtBQUFFZCxHQWpuQklELGlCQUFlO0FBQUEsVUFhSjNCLEtBQUtvRCxPQUFPO0FBQUE7QUFBQW9HLEtBYnZCN0g7QUFtbkJOLGVBQWVBO0FBQWdCLElBQUE2SDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJtZXNzYWdlIiwiRHJvcGRvd24iLCJNZW51IiwiRHJhd2VyIiwiQnV0dG9uIiwiSW5wdXQiLCJGb3JtIiwiTW9kYWwiLCJUeXBvZ3JhcGh5IiwiU3BhY2UiLCJEaXZpZGVyIiwiSW5wdXROdW1iZXIiLCJTZWxlY3QiLCJEYXRlUGlja2VyIiwiTW9yZU91dGxpbmVkIiwiVXNlck91dGxpbmVkIiwiQ2hlY2tDaXJjbGVPdXRsaW5lZCIsIkVkaXRPdXRsaW5lZCIsIkNsb3NlT3V0bGluZWQiLCJEb2xsYXJPdXRsaW5lZCIsIkNhbGVuZGFyT3V0bGluZWQiLCJTaWRlYmFyIiwiTmF2YmFyIiwiRGF0YVRhYmxlIiwiYXBpIiwiQ2lyY3VsYXJMb2FkZXIiLCJtb21lbnQiLCJmaWVsZFNpemUiLCJCcmVhZGNydW1iIiwiVGl0bGUiLCJUZXh0IiwiT3B0aW9uIiwiVGV4dEFyZWEiLCJVbmFwcHJvdmVkTG9hbnMiLCJfcyIsInRhYmxlRGF0YSIsInNldFRhYmxlRGF0YSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiaXNEcmF3ZXJPcGVuIiwic2V0SXNEcmF3ZXJPcGVuIiwic2VsZWN0ZWRMb2FuIiwic2V0U2VsZWN0ZWRMb2FuIiwic2VsZWN0ZWRVc2VyIiwic2V0U2VsZWN0ZWRVc2VyIiwic2hvd0NvbmZpcm1EaWFsb2ciLCJzZXRTaG93Q29uZmlybURpYWxvZyIsInNob3dBcHByb3ZhbE1vZGFsIiwic2V0U2hvd0FwcHJvdmFsTW9kYWwiLCJ1c2VycyIsInNldFVzZXJzIiwiYWdlbnRzIiwic2V0QWdlbnRzIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJmb3JtIiwidXNlRm9ybSIsInVzZUVmZmVjdCIsImZldGNoVXNlcnMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJmZXRjaEFnZW50cyIsImFnZW50IiwiZmV0Y2hFbXBsb3llZXMiLCJlbXBsb3llZSIsImZldGNoTWFzdGVyRGF0YSIsInVzZXJzRGF0YSIsImFnZW50c0RhdGEiLCJlbXBsb3llZXNEYXRhIiwiUHJvbWlzZSIsImFsbCIsImVycm9yIiwiY29uc29sZSIsImZldGNoTG9hbnMiLCJsb2FuUmVzIiwibG9hbnMiLCJmb3JtYXR0ZWQiLCJtYXAiLCJsb2FuIiwiaW5kZXgiLCJ1c2VyIiwiZmluZCIsInUiLCJfaWQiLCJ1c2VyX2lkIiwibWVudSIsImhhbmRsZUFwcHJvdmVDbGljayIsImhhbmRsZURlbGV0ZUNsaWNrIiwiaWQiLCJsb2FuSWQiLCJjdXN0b21lcl9uYW1lIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiYWRkcmVzcyIsImxvYW5fYW1vdW50IiwibG9hbl9wdXJwb3NlIiwiY3JlYXRlZEF0IiwiRGF0ZSIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImRheSIsIm1vbnRoIiwieWVhciIsImFwcHJvdmFsX3N0YXR1cyIsImFwcHJvdmFsX3N0YXR1c19yYXciLCJhY3Rpb25zIiwiZSIsInByZXZlbnREZWZhdWx0IiwiZXJyIiwicHJldiIsInVzZXJJZCIsInNldEZpZWxkc1ZhbHVlIiwiYm9ycm93ZXIiLCJkZWxldGUiLCJzdWNjZXNzIiwiaGFuZGxlQXBwcm92ZUxvYW4iLCJmb3JtVmFsdWVzIiwiZ2V0RmllbGRzVmFsdWUiLCJzdGFydF9kYXRlIiwiZW5kX2RhdGUiLCJmb3JtYXR0ZWRTdGFydERhdGUiLCJmb3JtYXQiLCJmb3JtYXR0ZWRFbmREYXRlIiwicHV0IiwibG9hbkRhdGEiLCJOdW1iZXIiLCJ0ZW51cmUiLCJzZXJ2aWNlX2NoYXJnZXMiLCJkYWlseV9wYXltZW50X2Ftb3VudCIsIm5vdGUiLCJyZWZlcnJlZF90eXBlIiwicmVmZXJyZWRfY3VzdG9tZXIiLCJyZWZlcnJlZF9lbXBsb3llZSIsInJlZmVycmVkX2FnZW50IiwicG9zdCIsImNvbHVtbnMiLCJrZXkiLCJoZWFkZXIiLCJsb2FuQ29sdW1ucyIsImxlbmd0aCIsInJlc2V0RmllbGRzIiwicmVxdWlyZWQiLCJpbnB1dCIsIm9wdGlvbiIsInRleHQiLCJjaGlsZHJlbiIsInRvU3RyaW5nIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsImN1c3RvbWVyX2lkIiwiaGVpZ2h0IiwidHlwZSIsImN1cnIiLCJnZXRGaWVsZFZhbHVlIiwiZW1wIiwibmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlVuYXBwcm92ZWRMb2Fucy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIG1lc3NhZ2UsXHJcbiAgRHJvcGRvd24sXHJcbiAgTWVudSxcclxuICBEcmF3ZXIsXHJcbiAgQnV0dG9uLFxyXG4gIElucHV0LFxyXG4gIEZvcm0sXHJcbiAgTW9kYWwsXHJcbiAgVHlwb2dyYXBoeSxcclxuICBTcGFjZSxcclxuICBEaXZpZGVyLFxyXG4gIElucHV0TnVtYmVyLFxyXG4gIFNlbGVjdCxcclxuICBEYXRlUGlja2VyLFxyXG59IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7XHJcbiAgTW9yZU91dGxpbmVkLFxyXG4gIFVzZXJPdXRsaW5lZCxcclxuICBDaGVja0NpcmNsZU91dGxpbmVkLFxyXG4gIEVkaXRPdXRsaW5lZCxcclxuICBDbG9zZU91dGxpbmVkLFxyXG4gIERvbGxhck91dGxpbmVkLFxyXG4gIENhbGVuZGFyT3V0bGluZWQsXHJcbn0gZnJvbSBcIkBhbnQtZGVzaWduL2ljb25zXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgbW9tZW50IGZyb20gXCJtb21lbnRcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcbmNvbnN0IHsgVGl0bGUsIFRleHQgfSA9IFR5cG9ncmFwaHk7XHJcbmNvbnN0IHsgT3B0aW9uIH0gPSBTZWxlY3Q7XHJcbmNvbnN0IHsgVGV4dEFyZWEgfSA9IElucHV0O1xyXG5cclxuY29uc3QgVW5hcHByb3ZlZExvYW5zID0gKCkgPT4ge1xyXG4gIGNvbnN0IFt0YWJsZURhdGEsIHNldFRhYmxlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgLy8gSW5pdGlhbGl6ZSBsb2FkaW5nIHRvIHRydWUgc28gdGhlIHNwaW5uZXIgc2hvd3MgaW1tZWRpYXRlbHkgb24gbW91bnRcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbaXNEcmF3ZXJPcGVuLCBzZXRJc0RyYXdlck9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZExvYW4sIHNldFNlbGVjdGVkTG9hbl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWRVc2VyLCBzZXRTZWxlY3RlZFVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dDb25maXJtRGlhbG9nLCBzZXRTaG93Q29uZmlybURpYWxvZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dBcHByb3ZhbE1vZGFsLCBzZXRTaG93QXBwcm92YWxNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FnZW50cywgc2V0QWdlbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtyZWxvYWRUcmlnZ2VyLCBzZXRSZWxvYWRUcmlnZ2VyXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtmb3JtXSA9IEZvcm0udXNlRm9ybSgpO1xyXG5cclxuICAvLyBGZXRjaCB1c2VycywgYWdlbnRzLCBhbmQgZW1wbG95ZWVzIGRhdGEgaW4gcGFyYWxsZWxcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hVc2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBmZXRjaEFnZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldFwiKTtcclxuICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE/LmFnZW50O1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YT8uZW1wbG95ZWU7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGZldGNoTWFzdGVyRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyBXYWl0IGZvciBhbGwgdGhyZWUgbWFzdGVyIGRhdGEgY2FsbHMgdG8gZmluaXNoXHJcbiAgICAgICAgY29uc3QgW3VzZXJzRGF0YSwgYWdlbnRzRGF0YSwgZW1wbG95ZWVzRGF0YV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICBmZXRjaFVzZXJzKCksXHJcbiAgICAgICAgICBmZXRjaEFnZW50cygpLFxyXG4gICAgICAgICAgZmV0Y2hFbXBsb3llZXMoKSxcclxuICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgc2V0VXNlcnModXNlcnNEYXRhKTtcclxuICAgICAgICBzZXRBZ2VudHMoYWdlbnRzRGF0YSk7XHJcbiAgICAgICAgc2V0RW1wbG95ZWVzKGVtcGxveWVlc0RhdGEpO1xyXG5cclxuICAgICAgICAvLyBXZSBkbyBOT1Qgc2V0IHNldExvYWRpbmcoZmFsc2UpIGhlcmUgeWV0LlxyXG4gICAgICAgIC8vIFdlIHdhaXQgZm9yIHRoZSBsb2FucyB0byBmZXRjaCBhcyB3ZWxsIGluIHRoZSBuZXh0IGVmZmVjdC5cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbWFzdGVyIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGxvYWQgaW5pdGlhbCBkYXRhXCIpO1xyXG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpOyAvLyBTdG9wIGxvYWRpbmcgaWYgbWFzdGVyIGRhdGEgZmFpbHNcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaE1hc3RlckRhdGEoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIC8vIEZldGNoIGxvYW5zIG9ubHkgYWZ0ZXIgdXNlcnMgYXJlIGF2YWlsYWJsZVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcblxyXG4gICAgY29uc3QgZmV0Y2hMb2FucyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgLy8gRW5zdXJlIHVzZXJzIGFyZSBsb2FkZWQgYmVmb3JlIHRyeWluZyB0byBtYXAgdGhlbVxyXG4gICAgICAvLyBpZiAodXNlcnMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7IC8vIEVuc3VyZSBsb2FkaW5nIGlzIHRydWUgd2hpbGUgZmV0Y2hpbmcgbG9hbnNcclxuICAgICAgICBjb25zdCBsb2FuUmVzID0gYXdhaXQgYXBpLmdldChcIi9sb2Fucy9nZXQtbG9hbi1hcHByb3ZhbC1yZXF1ZXN0XCIpO1xyXG4gICAgICAgIGNvbnN0IGxvYW5zID0gbG9hblJlcy5kYXRhLmRhdGEgfHwgW107XHJcblxyXG4gICAgICAgIC8vIE1hcCBzeW5jaHJvbm91c2x5IHVzaW5nIHRoZSAndXNlcnMnIHN0YXRlXHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkID0gbG9hbnMubWFwKChsb2FuLCBpbmRleCkgPT4ge1xyXG5cclxuICAgICAgICAgIGNvbnN0IHVzZXIgPSB1c2Vycy5maW5kKCh1KSA9PiB1Ll9pZCA9PT0gbG9hbi51c2VyX2lkKTtcclxuXHJcbiAgICAgICAgICBjb25zdCBtZW51ID0gKFxyXG4gICAgICAgICAgICA8TWVudT5cclxuICAgICAgICAgICAgICA8TWVudS5JdGVtXHJcbiAgICAgICAgICAgICAgICBrZXk9XCJhcHByb3ZlXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUFwcHJvdmVDbGljayhsb2FuLCB1c2VyKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBBcHByb3ZlXHJcbiAgICAgICAgICAgICAgPC9NZW51Lkl0ZW0+XHJcbiAgICAgICAgICAgICAgPE1lbnUuSXRlbVxyXG4gICAgICAgICAgICAgICAga2V5PVwiZGVsZXRlXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZUNsaWNrKGxvYW4uX2lkKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICA8L01lbnUuSXRlbT5cclxuICAgICAgICAgICAgPC9NZW51PlxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICBsb2FuSWQ6IGxvYW4uX2lkLFxyXG4gICAgICAgICAgICBjdXN0b21lcl9uYW1lOiBsb2FuPy51c2VyPy5mdWxsX25hbWUgfHwgbG9hbj8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwiLFxyXG4gICAgICAgICAgICBwaG9uZV9udW1iZXI6IGxvYW4/LnVzZXI/LnBob25lX251bWJlciB8fCBsb2FuPy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCItXCIsXHJcbiAgICAgICAgICAgIGFkZHJlc3M6IGxvYW4/LnVzZXI/LmFkZHJlc3MgfHwgbG9hbj8udXNlcl9pZD8uYWRkcmVzcyB8fCBcIi1cIixcclxuICAgICAgICAgICAgbG9hbl9hbW91bnQ6IGxvYW4ubG9hbl9hbW91bnQsXHJcbiAgICAgICAgICAgIGxvYW5fcHVycG9zZTogbG9hbi5sb2FuX3B1cnBvc2UsXHJcbiAgICAgICAgICAgIGNyZWF0ZWRBdDogbG9hbj8uY3JlYXRlZEF0XHJcbiAgICAgICAgICAgICAgPyBuZXcgRGF0ZShsb2FuLmNyZWF0ZWRBdCkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tR0JcIiwge1xyXG4gICAgICAgICAgICAgICAgZGF5OiBcIjItZGlnaXRcIixcclxuICAgICAgICAgICAgICAgIG1vbnRoOiBcInNob3J0XCIsXHJcbiAgICAgICAgICAgICAgICB5ZWFyOiBcIm51bWVyaWNcIixcclxuICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgIDogXCItXCIsXHJcbiAgICAgICAgICAgIGFwcHJvdmFsX3N0YXR1czogKFxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0zIHB5LTEgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXllbGxvdy04MDAgYmcteWVsbG93LTEwMCByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIFBlbmRpbmdcclxuICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIGFwcHJvdmFsX3N0YXR1c19yYXc6IGxvYW4/LmFwcHJvdmFsX3N0YXR1cyxcclxuICAgICAgICAgICAgYWN0aW9uczogKFxyXG4gICAgICAgICAgICAgIDxEcm9wZG93biBvdmVybGF5PXttZW51fSB0cmlnZ2VyPXtbXCJjbGlja1wiXX0+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgaWNvbj17PE1vcmVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGUucHJldmVudERlZmF1bHQoKX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHNldFRhYmxlRGF0YShmb3JtYXR0ZWQpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgICAgbWVzc2FnZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBsb2FuIHJlcXVlc3RzXCIpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIC8vIEFsbCBkYXRhIChNYXN0ZXIgKyBMb2FucykgaXMgbm93IGxvYWRlZC4gU3RvcCB0aGUgbG9hZGVyLlxyXG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoTG9hbnMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVBcHByb3ZlQ2xpY2sgPSBhc3luYyAobG9hbiwgdXNlcikgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRMb2FuKGxvYW4pO1xyXG4gICAgc2V0U2VsZWN0ZWRVc2VyKHVzZXIpO1xyXG4gICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgY29uc3QgdXNlcklkID0gdXNlcj8uX2lkIHx8IGxvYW4udXNlcl9pZDtcclxuXHJcbiAgICBmb3JtLnNldEZpZWxkc1ZhbHVlKHtcclxuICAgICAgYm9ycm93ZXI6IHVzZXJJZCxcclxuICAgICAgbG9hbl9hbW91bnQ6IGxvYW4ubG9hbl9hbW91bnQsXHJcbiAgICAgIGxvYW5fcHVycG9zZTogbG9hbi5sb2FuX3B1cnBvc2UsXHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXRTaG93QXBwcm92YWxNb2RhbCh0cnVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVDbGljayA9IGFzeW5jIChsb2FuSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5kZWxldGUoYC9sb2Fucy9kZWxldGUtbG9hbi1yZXF1ZXN0LyR7bG9hbklkfWApO1xyXG4gICAgICBtZXNzYWdlLnN1Y2Nlc3MoXCJMb2FuIHJlcXVlc3QgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZGVsZXRlIGxvYW4gcmVxdWVzdFwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVBcHByb3ZlTG9hbiA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IGZvcm1WYWx1ZXMgPSBmb3JtLmdldEZpZWxkc1ZhbHVlKCk7XHJcblxyXG4gICAgICBpZiAoIWZvcm1WYWx1ZXMuc3RhcnRfZGF0ZSB8fCAhZm9ybVZhbHVlcy5lbmRfZGF0ZSkge1xyXG4gICAgICAgIG1lc3NhZ2UuZXJyb3IoXCJQbGVhc2Ugc2VsZWN0IFN0YXJ0IERhdGUgYW5kIEVuZCBEYXRlXCIpO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgZm9ybWF0dGVkU3RhcnREYXRlID0gbW9tZW50KGZvcm1WYWx1ZXMuc3RhcnRfZGF0ZSkuZm9ybWF0KFxyXG4gICAgICAgIFwiWVlZWS1NTS1ERFwiLFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBmb3JtYXR0ZWRFbmREYXRlID0gbW9tZW50KGZvcm1WYWx1ZXMuZW5kX2RhdGUpLmZvcm1hdChcIllZWVktTU0tRERcIik7XHJcblxyXG4gICAgICBhd2FpdCBhcGkucHV0KGAvbG9hbnMvdXBkYXRlLWxvYW4tYXBwcm92YWwtcmVxdWVzdC8ke3NlbGVjdGVkTG9hbi5faWR9YCwge1xyXG4gICAgICAgIGFwcHJvdmFsX3N0YXR1czogXCJhcHByb3ZlZFwiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IGxvYW5EYXRhID0ge1xyXG4gICAgICAgIGJvcnJvd2VyOiBmb3JtVmFsdWVzLmJvcnJvd2VyLFxyXG4gICAgICAgIGxvYW5fYW1vdW50OiBOdW1iZXIoZm9ybVZhbHVlcy5sb2FuX2Ftb3VudCksXHJcbiAgICAgICAgdGVudXJlOiBOdW1iZXIoZm9ybVZhbHVlcy50ZW51cmUpLFxyXG4gICAgICAgIHNlcnZpY2VfY2hhcmdlczogTnVtYmVyKGZvcm1WYWx1ZXMuc2VydmljZV9jaGFyZ2VzKSxcclxuICAgICAgICBkYWlseV9wYXltZW50X2Ftb3VudDogTnVtYmVyKGZvcm1WYWx1ZXMuZGFpbHlfcGF5bWVudF9hbW91bnQpLFxyXG4gICAgICAgIHN0YXJ0X2RhdGU6IGZvcm1hdHRlZFN0YXJ0RGF0ZSxcclxuICAgICAgICBlbmRfZGF0ZTogZm9ybWF0dGVkRW5kRGF0ZSxcclxuICAgICAgICBub3RlOiBmb3JtVmFsdWVzLm5vdGUgfHwgXCJcIixcclxuICAgICAgICByZWZlcnJlZF90eXBlOiBmb3JtVmFsdWVzLnJlZmVycmVkX3R5cGUsXHJcbiAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IGZvcm1WYWx1ZXMucmVmZXJyZWRfY3VzdG9tZXIgfHwgXCJcIixcclxuICAgICAgICByZWZlcnJlZF9lbXBsb3llZTogZm9ybVZhbHVlcy5yZWZlcnJlZF9lbXBsb3llZSB8fCBcIlwiLFxyXG4gICAgICAgIHJlZmVycmVkX2FnZW50OiBmb3JtVmFsdWVzLnJlZmVycmVkX2FnZW50IHx8IFwiXCIsXHJcbiAgICAgICAgYXBwcm92YWxfc3RhdHVzOiBcImFwcHJvdmVkXCIsXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBhd2FpdCBhcGkucG9zdChcIi9sb2Fucy9hZGQtYm9ycm93ZXJcIiwgbG9hbkRhdGEpO1xyXG5cclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiTG9hbiBhcHByb3ZlZCBzdWNjZXNzZnVsbHlcIik7XHJcbiAgICAgIHNldFNob3dBcHByb3ZhbE1vZGFsKGZhbHNlKTtcclxuICAgICAgLy8gd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIGFwcHJvdmUgbG9hblwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLk5PXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyX25hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWRkcmVzc1wiLCBoZWFkZXI6IFwiQWRkcmVzc1wiIH0sXHJcbiAgICB7IGtleTogXCJsb2FuX2Ftb3VudFwiLCBoZWFkZXI6IFwiTG9hbiBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbl9wdXJwb3NlXCIsIGhlYWRlcjogXCJMb2FuIFB1cnBvc2VcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXBwcm92YWxfc3RhdHVzXCIsIGhlYWRlcjogXCJBcHByb3ZhbCBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3JlYXRlZEF0XCIsIGhlYWRlcjogXCJDcmVhdGVkIEF0XCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvbnNcIiwgaGVhZGVyOiBcIkFjdGlvbnNcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGxvYW5Db2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLk5PXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyX25hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWRkcmVzc1wiLCBoZWFkZXI6IFwiQWRkcmVzc1wiIH0sXHJcbiAgICB7IGtleTogXCJsb2FuX2Ftb3VudFwiLCBoZWFkZXI6IFwiTG9hbiBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwibG9hbl9wdXJwb3NlXCIsIGhlYWRlcjogXCJMb2FuIFB1cnBvc2VcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3JlYXRlZEF0XCIsIGhlYWRlcjogXCJDcmVhdGVkIERhdGVcIiB9LCAvLyA8LS0tIENvbHVtbiBBZGRlZCBIZXJlXHJcbiAgICB7IGtleTogXCJhcHByb3ZhbF9zdGF0dXNfcmF3XCIsIGhlYWRlcjogXCJBcHByb3ZhbCBTdGF0dXNcIiB9LFxyXG4gICAgLy8geyBrZXk6IFwiYWN0aW9uc1wiLCBoZWFkZXI6IFwiQWN0aW9uc1wiIH0sXHJcbiAgXTtcclxuXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgPFNpZGViYXIgLz5cclxuICAgICAgPE5hdmJhciB2aXNpYmlsaXR5IC8+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgICAgICAgIDxCcmVhZGNydW1iIC8+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgbWItNlwiPlxyXG4gICAgICAgICAgVW5hcHByb3ZlZCBMb2FuIFJlcXVlc3RzXHJcbiAgICAgICAgPC9oMT5cclxuXHJcbiAgICAgICAgeyFsb2FkaW5nICYmIHRhYmxlRGF0YS5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICBkYXRhPXt0YWJsZURhdGF9XHJcbiAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgIGV4cG9ydENvbHM9e2xvYW5Db2x1bW5zfVxyXG4gICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJVbmFwcHJvdmVkIExvYW5zXCJcclxuICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cInVuYXBwcm92ZWRfbG9hbnMuY3N2XCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKSA6IChcclxuICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICBpc0xvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICAgIGZhaWx1cmU9e3RhYmxlRGF0YS5sZW5ndGggPT09IDAgJiYgIWxvYWRpbmd9XHJcbiAgICAgICAgICAgIGRhdGE9XCJMb2FuIFJlcXVlc3RzXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8TW9kYWxcclxuICAgICAgICB0aXRsZT1cIkFwcHJvdmUgTG9hbiBSZXF1ZXN0XCJcclxuICAgICAgICBvcGVuPXtzaG93QXBwcm92YWxNb2RhbH1cclxuICAgICAgICBvbkNhbmNlbD17KCkgPT4ge1xyXG4gICAgICAgICAgc2V0U2hvd0FwcHJvdmFsTW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgZm9ybS5yZXNldEZpZWxkcygpO1xyXG4gICAgICAgIH19XHJcbiAgICAgICAgZm9vdGVyPXtudWxsfVxyXG4gICAgICAgIHdpZHRoPXs4MDB9XHJcbiAgICAgID5cclxuICAgICAgICA8Rm9ybSBmb3JtPXtmb3JtfSBsYXlvdXQ9XCJ2ZXJ0aWNhbFwiIG9uRmluaXNoPXtoYW5kbGVBcHByb3ZlTG9hbn0+XHJcbiAgICAgICAgICB7LyogQm9ycm93ZXIgKi99XHJcbiAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgIG5hbWU9XCJib3Jyb3dlclwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTEwXCJcclxuICAgICAgICAgICAgbGFiZWw9XCJCb3Jyb3dlciBOYW1lXCJcclxuICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgYm9ycm93ZXJcIiB9XX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBCb3Jyb3dlciBOYW1lXCJcclxuICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IHtcclxuICAgICAgICAgICAgICAgIGNvbnN0IHRleHQgPSBvcHRpb24/LmNoaWxkcmVuPy50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkgfHwgXCJcIjtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0ZXh0LmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICB7dXNlci5jdXN0b21lcl9pZH0gfCB7dXNlci5mdWxsX25hbWV9IHwge3VzZXIucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG5cclxuICAgICAgICAgIHsvKiBMb2FuIEFtb3VudCAmIFRlbnVyZSAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICBuYW1lPVwibG9hbl9hbW91bnRcIlxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiTG9hbiBBbW91bnRcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS8yXCJcclxuICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiRW50ZXIgbG9hbiBhbW91bnRcIiB9XX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIExvYW4gQW1vdW50XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG5cclxuICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgIG5hbWU9XCJ0ZW51cmVcIlxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiVGVudXJlIChEYXlzKVwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzJcIlxyXG4gICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJFbnRlciB0ZW51cmVcIiB9XX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFRlbnVyZSBpbiBEYXlzXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00XCI+XHJcbiAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICBuYW1lPVwic2VydmljZV9jaGFyZ2VzXCJcclxuICAgICAgICAgICAgICBsYWJlbD1cIlNlcnZpY2UgQ2hhcmdlc1wiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzJcIlxyXG4gICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJFbnRlciBzZXJ2aWNlIGNoYXJnZXNcIiB9XX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFNlcnZpY2UgQ2hhcmdlc1wiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcbiAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICBuYW1lPVwiZGFpbHlfcGF5bWVudF9hbW91bnRcIlxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiRGFpbHkgUGF5bWVudCBBbW91bnRcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS8yXCJcclxuICAgICAgICAgICAgICBydWxlcz17W1xyXG4gICAgICAgICAgICAgICAgeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJFbnRlciBkYWlseSBwYXltZW50IGFtb3VudFwiIH0sXHJcbiAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIERhaWx5IFBheW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogRGF0ZXMgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTRcIj5cclxuICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgIG5hbWU9XCJzdGFydF9kYXRlXCJcclxuICAgICAgICAgICAgICBsYWJlbD1cIlN0YXJ0IERhdGVcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS8yXCJcclxuICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiU2VsZWN0IHN0YXJ0IGRhdGVcIiB9XX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxEYXRlUGlja2VyXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIGZvcm1hdD1cIkREL01NL1lZWVlcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG5cclxuICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgIG5hbWU9XCJlbmRfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgbGFiZWw9XCJFbmQgRGF0ZVwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzJcIlxyXG4gICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJTZWxlY3QgZW5kIGRhdGVcIiB9XX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxEYXRlUGlja2VyXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIGZvcm1hdD1cIkREL01NL1lZWVlcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX3R5cGVcIlxyXG4gICAgICAgICAgICBsYWJlbD1cIlJlZmVycmVkIFR5cGVcIlxyXG4gICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiU2VsZWN0IHJlZmVycmVkIHR5cGVcIiB9XX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIFR5cGVcIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgdGV4dCA9IG9wdGlvbj8uY2hpbGRyZW4/LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKSB8fCBcIlwiO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRleHQuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtbXCJTZWxmIEpvaW5pbmdcIiwgXCJDdXN0b21lclwiLCBcIkVtcGxveWVlXCIsIFwiQWdlbnRcIiwgXCJPdGhlcnNcIl0ubWFwKFxyXG4gICAgICAgICAgICAgICAgKHR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt0eXBlfSB2YWx1ZT17dHlwZX0+XHJcbiAgICAgICAgICAgICAgICAgICAge3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgIHsvKiBDb25kaXRpb25hbCBGaWVsZHMg4oCUIENsZWFuIExheW91dCAqL31cclxuICAgICAgICAgIDxGb3JtLkl0ZW0gbm9TdHlsZSBzaG91bGRVcGRhdGU9eyhwcmV2LCBjdXJyKSA9PiBwcmV2LnJlZmVycmVkX3R5cGUgIT09IGN1cnIucmVmZXJyZWRfdHlwZX0+XHJcbiAgICAgICAgICAgIHsoeyBnZXRGaWVsZFZhbHVlIH0pID0+IHtcclxuICAgICAgICAgICAgICBjb25zdCB0eXBlID0gZ2V0RmllbGRWYWx1ZShcInJlZmVycmVkX3R5cGVcIik7XHJcblxyXG4gICAgICAgICAgICAgIGlmICh0eXBlID09PSBcIkN1c3RvbWVyXCIpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfY3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiUmVmZXJyZWQgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJTZWxlY3QgY3VzdG9tZXJcIiB9XX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uPy5jaGlsZHJlbj8udG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX0gfCB7dXNlci5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICBpZiAodHlwZSA9PT0gXCJFbXBsb3llZVwiKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX2VtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlJlZmVycmVkIEVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiU2VsZWN0IGVtcGxveWVlXCIgfV19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbj8uY2hpbGRyZW4/LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChlbXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2VtcC5uYW1lfSB8IHtlbXAucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgaWYgKHR5cGUgPT09IFwiQWdlbnRcIikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9hZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJSZWZlcnJlZCBBZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlNlbGVjdCBhZ2VudFwiIH1dfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmNoaWxkcmVuPy50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYWdlbnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfSB8IHthZ2VudC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICBpZiAodHlwZSA9PT0gXCJPdGhlcnNcIikge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9vdGhlcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiUmVmZXJyZWQgQnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJFbnRlciByZWZlcmVuY2UgbmFtZVwiIH1dfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHJlZmVyZW5jZSBuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTQgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuXHJcblxyXG5cclxuICAgICAgICAgIHsvKiA8Rm9ybS5JdGVtIHNob3VsZFVwZGF0ZT5cclxuICAgICAgICAgICAgeyh7IGdldEZpZWxkVmFsdWUgfSkgPT5cclxuICAgICAgICAgICAgICBnZXRGaWVsZFZhbHVlKFwicmVmZXJyZWRfdHlwZVwiKSA9PT0gXCJDdXN0b21lclwiICYmIChcclxuICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW1cclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX2N1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgbGFiZWw9XCJSZWZlcnJlZCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSwgbWVzc2FnZTogXCJTZWxlY3QgY3VzdG9tZXJcIiB9XX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGV4dCA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbj8uY2hpbGRyZW4/LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKSB8fCBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRleHQuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBSZWZlcnJlZCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9IHwge3VzZXIucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcblxyXG4gICAgICAgICAgPEZvcm0uSXRlbSBzaG91bGRVcGRhdGU+XHJcbiAgICAgICAgICAgIHsoeyBnZXRGaWVsZFZhbHVlIH0pID0+XHJcbiAgICAgICAgICAgICAgZ2V0RmllbGRWYWx1ZShcInJlZmVycmVkX3R5cGVcIikgPT09IFwiRW1wbG95ZWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF9lbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPVwiUmVmZXJyZWQgRW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgICBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUsIG1lc3NhZ2U6IFwiU2VsZWN0IGVtcGxveWVlXCIgfV19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBFbXBsb3llZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0ZXh0ID1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uPy5jaGlsZHJlbj8udG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpIHx8IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGV4dC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlbXAubmFtZX0gfCB7ZW1wLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG5cclxuICAgICAgICAgIDxGb3JtLkl0ZW0gc2hvdWxkVXBkYXRlPlxyXG4gICAgICAgICAgICB7KHsgZ2V0RmllbGRWYWx1ZSB9KSA9PlxyXG4gICAgICAgICAgICAgIGdldEZpZWxkVmFsdWUoXCJyZWZlcnJlZF90eXBlXCIpID09PSBcIkFnZW50XCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPEZvcm0uSXRlbVxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfYWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD1cIlJlZmVycmVkIEFnZW50XCJcclxuICAgICAgICAgICAgICAgICAgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlLCBtZXNzYWdlOiBcIlNlbGVjdCBhZ2VudFwiIH1dfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGV4dCA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbj8uY2hpbGRyZW4/LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKSB8fCBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRleHQuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChhZ2VudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWdlbnQubmFtZX0gfCB7YWdlbnQucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgPC9Gb3JtLkl0ZW0+ICAqL31cclxuXHJcblxyXG5cclxuICAgICAgICAgIHsvKiBOb3RlICovfVxyXG4gICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwibm90ZVwiIGxhYmVsPVwiTm90ZVwiPlxyXG4gICAgICAgICAgICA8SW5wdXQuVGV4dEFyZWEgcm93cz17M30gcGxhY2Vob2xkZXI9XCJTcGVjaWZ5IG5vdGUgaWYgYW55XCIgLz5cclxuICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG5cclxuICAgICAgICAgIHsvKiBCdXR0b25zICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd0FwcHJvdmFsTW9kYWwoZmFsc2UpfT5DYW5jZWw8L0J1dHRvbj5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICBodG1sVHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgaWNvbj17PENoZWNrQ2lyY2xlT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBBcHByb3ZlIExvYW5cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L0Zvcm0+XHJcbiAgICAgIDwvTW9kYWw+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVW5hcHByb3ZlZExvYW5zO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvVW5hcHByb3ZlZExvYW5zLmpzeCJ9