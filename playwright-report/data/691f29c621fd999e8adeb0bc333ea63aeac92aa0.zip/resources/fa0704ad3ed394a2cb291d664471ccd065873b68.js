import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/modals/ClosingGroupsModal.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { AlertTriangle, X, Clock } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import API from "/src/instance/TokenInstance.js";
const ClosingGroupsModal = () => {
  _s();
  const location = useLocation();
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(false);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    if (location.pathname !== "/dashboard") return;
    if (sessionStorage.getItem("closingGroupsDismissed") === "true") return;
    const fetchClosingGroups = async () => {
      try {
        setLoading(true);
        const response = await API.get("/v1/admin/groups/closing");
        if (response.data?.success) {
          const data = response.data.data || [];
          if (data.length > 0) {
            const sorted = [...data].sort(
              (a, b) => a.days_remaining - b.days_remaining
            );
            setGroups(sorted);
            setVisible(true);
          }
        }
      } catch (error) {
        console.error("Error fetching closing groups:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchClosingGroups();
  }, [location.pathname]);
  const handleRemindLater = () => {
    setVisible(false);
  };
  const handleDismissPermanently = () => {
    setVisible(false);
    sessionStorage.setItem("closingGroupsDismissed", "true");
  };
  const getUrgencyStyle = (days) => {
    if (days <= 30)
      return { badge: "bg-red-100 text-red-700", dot: "bg-red-500" };
    if (days <= 60)
      return { badge: "bg-amber-100 text-amber-700", dot: "bg-amber-500" };
    return { badge: "bg-blue-100 text-blue-700", dot: "bg-blue-500" };
  };
  if (!visible || loading) return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[9998] flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-200", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-2xl max-w-lg w-full mx-4 overflow-hidden animate-in zoom-in-95 duration-200 border border-amber-100", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-r from-amber-500 to-amber-400 px-6 py-5 flex items-start justify-between", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-11 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxDEV(AlertTriangle, { className: "w-6 h-6 text-white" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
          lineNumber: 75,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
          lineNumber: 74,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-lg font-extrabold text-white leading-tight", children: "Groups Closing Soon" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
            lineNumber: 78,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-amber-50 text-xs font-medium mt-0.5", children: [
            groups.length,
            " group",
            groups.length > 1 ? "s" : "",
            " need",
            groups.length === 1 ? "s" : "",
            " your attention"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
            lineNumber: 81,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
          lineNumber: 77,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
        lineNumber: 73,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: handleRemindLater,
          className: "text-white/80 hover:text-white hover:bg-white/10 rounded-lg p-1.5 transition-colors",
          children: /* @__PURE__ */ jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
            lineNumber: 91,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
          lineNumber: 87,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
      lineNumber: 72,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "max-h-80 overflow-y-auto divide-y divide-slate-100", children: groups.map((group) => {
      const style = getUrgencyStyle(group.days_remaining);
      return /* @__PURE__ */ jsxDEV(
        "div",
        {
          className: "px-6 py-4 flex items-center justify-between hover:bg-slate-50 transition-colors",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-slate-800 truncate", children: group.group_name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
                lineNumber: 105,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-400 mt-0.5 flex items-center gap-1", children: [
                /* @__PURE__ */ jsxDEV(Clock, { className: "w-3 h-3" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
                  lineNumber: 109,
                  columnNumber: 21
                }, this),
                "Ends",
                " ",
                new Date(group.end_date).toLocaleDateString("en-IN", {
                  day: "2-digit",
                  month: "short",
                  year: "numeric"
                })
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
                lineNumber: 108,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
              lineNumber: 104,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "ml-3 flex flex-wrap items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium shadow-sm ${style.badge}`,
                  children: [
                    group?.months_remaining,
                    " Month",
                    group?.months_remaining !== 1 ? "s" : ""
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
                  lineNumber: 119,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "span",
                {
                  className: `inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium shadow-sm ${style.badge}`,
                  children: [
                    group?.days_remaining,
                    " Days Left"
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
                  lineNumber: 126,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
              lineNumber: 118,
              columnNumber: 17
            }, this)
          ]
        },
        group._id,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
          lineNumber: 100,
          columnNumber: 15
        },
        this
      );
    }) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
      lineNumber: 96,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-3", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: handleRemindLater,
          className: "px-5 py-2.5 bg-white hover:bg-slate-100 text-slate-700 text-sm font-bold rounded-xl border border-slate-200 transition-colors",
          children: "Remind me later"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
          lineNumber: 139,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: handleDismissPermanently,
          className: "px-5 py-2.5 bg-slate-800 hover:bg-slate-900 text-white text-sm font-bold rounded-xl transition-colors",
          children: "Don't show again"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
          lineNumber: 145,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
      lineNumber: 138,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
    lineNumber: 70,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx",
    lineNumber: 69,
    columnNumber: 5
  }, this);
};
_s(ClosingGroupsModal, "UM+cYtVtAkEAhOqbqjjQDVrGjoA=", false, function() {
  return [useLocation];
});
_c = ClosingGroupsModal;
export default ClosingGroupsModal;
var _c;
$RefreshReg$(_c, "ClosingGroupsModal");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/modals/ClosingGroupsModal.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEVjOzJCQTFFZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBLFNBQVNBLFdBQVdDLGdCQUFnQjtBQUNwQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZUFBZUMsR0FBR0MsYUFBYTtBQUN4QyxPQUFPQyxTQUFTO0FBRWhCLE1BQU1DLHFCQUFxQkEsTUFBTTtBQUFBQyxLQUFBO0FBQy9CLFFBQU1DLFdBQVdQLFlBQVk7QUFDN0IsUUFBTSxDQUFDUSxRQUFRQyxTQUFTLElBQUlWLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNXLFNBQVNDLFVBQVUsSUFBSVosU0FBUyxLQUFLO0FBQzVDLFFBQU0sQ0FBQ2EsU0FBU0MsVUFBVSxJQUFJZCxTQUFTLEtBQUs7QUFFNUNELFlBQVUsTUFBTTtBQUVkLFFBQUlTLFNBQVNPLGFBQWEsYUFBYztBQUd4QyxRQUFJQyxlQUFlQyxRQUFRLHdCQUF3QixNQUFNLE9BQVE7QUFFakUsVUFBTUMscUJBQXFCLFlBQVk7QUFDckMsVUFBSTtBQUNGTixtQkFBVyxJQUFJO0FBQ2YsY0FBTU8sV0FBVyxNQUFNZCxJQUFJZSxJQUFJLDBCQUEwQjtBQUN6RCxZQUFJRCxTQUFTRSxNQUFNQyxTQUFTO0FBQzFCLGdCQUFNRCxPQUFPRixTQUFTRSxLQUFLQSxRQUFRO0FBQ25DLGNBQUlBLEtBQUtFLFNBQVMsR0FBRztBQUVuQixrQkFBTUMsU0FBUyxDQUFDLEdBQUdILElBQUksRUFBRUk7QUFBQUEsY0FDdkIsQ0FBQ0MsR0FBR0MsTUFBTUQsRUFBRUUsaUJBQWlCRCxFQUFFQztBQUFBQSxZQUNqQztBQUNBbEIsc0JBQVVjLE1BQU07QUFDaEJWLHVCQUFXLElBQUk7QUFBQSxVQUNqQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGLFNBQVNlLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sa0NBQWtDQSxLQUFLO0FBQUEsTUFDdkQsVUFBQztBQUNDakIsbUJBQVcsS0FBSztBQUFBLE1BQ2xCO0FBQUEsSUFDRjtBQUVBTSx1QkFBbUI7QUFBQSxFQUNyQixHQUFHLENBQUNWLFNBQVNPLFFBQVEsQ0FBQztBQUl0QixRQUFNZ0Isb0JBQW9CQSxNQUFNO0FBQzlCakIsZUFBVyxLQUFLO0FBQUEsRUFDbEI7QUFJQSxRQUFNa0IsMkJBQTJCQSxNQUFNO0FBQ3JDbEIsZUFBVyxLQUFLO0FBQ2hCRSxtQkFBZWlCLFFBQVEsMEJBQTBCLE1BQU07QUFBQSxFQUN6RDtBQUVBLFFBQU1DLGtCQUFrQkEsQ0FBQ0MsU0FBUztBQUNoQyxRQUFJQSxRQUFRO0FBQ1YsYUFBTyxFQUFFQyxPQUFPLDJCQUEyQkMsS0FBSyxhQUFhO0FBQy9ELFFBQUlGLFFBQVE7QUFDVixhQUFPLEVBQUVDLE9BQU8sK0JBQStCQyxLQUFLLGVBQWU7QUFDckUsV0FBTyxFQUFFRCxPQUFPLDZCQUE2QkMsS0FBSyxjQUFjO0FBQUEsRUFDbEU7QUFFQSxNQUFJLENBQUN4QixXQUFXRixRQUFTLFFBQU87QUFFaEMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsd0hBQ2IsaUNBQUMsU0FBSSxXQUFVLG1JQUViO0FBQUEsMkJBQUMsU0FBSSxXQUFVLDJGQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHFGQUNiLGlDQUFDLGlCQUFjLFdBQVUsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG1EQUFrRCxtQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLDRDQUNWRjtBQUFBQSxtQkFBT2M7QUFBQUEsWUFBTztBQUFBLFlBQU9kLE9BQU9jLFNBQVMsSUFBSSxNQUFNO0FBQUEsWUFBRztBQUFBLFlBQ2xEZCxPQUFPYyxXQUFXLElBQUksTUFBTTtBQUFBLFlBQUc7QUFBQSxlQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBO0FBQUEsYUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BQ0E7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNRO0FBQUFBLFVBQ1QsV0FBVTtBQUFBLFVBRVYsaUNBQUMsS0FBRSxXQUFVLGFBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBc0I7QUFBQTtBQUFBLFFBSnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUtBO0FBQUEsU0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLHNEQUNadEIsaUJBQU82QixJQUFJLENBQUNDLFVBQVU7QUFDckIsWUFBTUMsUUFBUU4sZ0JBQWdCSyxNQUFNWCxjQUFjO0FBQ2xELGFBQ0U7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUVDLFdBQVU7QUFBQSxVQUVWO0FBQUEsbUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEscUNBQUMsT0FBRSxXQUFVLDZDQUNWVyxnQkFBTUUsY0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUseURBQ1g7QUFBQSx1Q0FBQyxTQUFNLFdBQVUsYUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEI7QUFBQSxnQkFBRztBQUFBLGdCQUN4QjtBQUFBLGdCQUNKLElBQUlDLEtBQUtILE1BQU1JLFFBQVEsRUFBRUMsbUJBQW1CLFNBQVM7QUFBQSxrQkFDcERDLEtBQUs7QUFBQSxrQkFDTEMsT0FBTztBQUFBLGtCQUNQQyxNQUFNO0FBQUEsZ0JBQ1IsQ0FBQztBQUFBLG1CQVBIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxpQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLGdHQUFnR1AsTUFBTUosS0FBSztBQUFBLGtCQUdySEc7QUFBQUEsMkJBQU9TO0FBQUFBLG9CQUFpQjtBQUFBLG9CQUFPVCxPQUFPUyxxQkFBcUIsSUFBSSxNQUFNO0FBQUE7QUFBQTtBQUFBLGdCQUp4RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxnR0FBZ0dSLE1BQU1KLEtBQUs7QUFBQSxrQkFFckhHO0FBQUFBLDJCQUFPWDtBQUFBQSxvQkFBZTtBQUFBO0FBQUE7QUFBQSxnQkFIekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBSUE7QUFBQSxpQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUE7QUFBQTtBQUFBLFFBOUJLVyxNQUFNVTtBQUFBQSxRQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFnQ0E7QUFBQSxJQUVKLENBQUMsS0F0Q0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVDQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLDBFQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNsQjtBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUErSDtBQUFBO0FBQUEsUUFGM0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTQztBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUF1RztBQUFBO0FBQUEsUUFGbkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0E7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLE9BakZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrRkEsS0FuRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW9GQTtBQUVKO0FBQUV6QixHQXBKSUQsb0JBQWtCO0FBQUEsVUFDTEwsV0FBVztBQUFBO0FBQUFpRCxLQUR4QjVDO0FBc0pOLGVBQWVBO0FBQW1CLElBQUE0QztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VMb2NhdGlvbiIsIkFsZXJ0VHJpYW5nbGUiLCJYIiwiQ2xvY2siLCJBUEkiLCJDbG9zaW5nR3JvdXBzTW9kYWwiLCJfcyIsImxvY2F0aW9uIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJ2aXNpYmxlIiwic2V0VmlzaWJsZSIsInBhdGhuYW1lIiwic2Vzc2lvblN0b3JhZ2UiLCJnZXRJdGVtIiwiZmV0Y2hDbG9zaW5nR3JvdXBzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwic3VjY2VzcyIsImxlbmd0aCIsInNvcnRlZCIsInNvcnQiLCJhIiwiYiIsImRheXNfcmVtYWluaW5nIiwiZXJyb3IiLCJjb25zb2xlIiwiaGFuZGxlUmVtaW5kTGF0ZXIiLCJoYW5kbGVEaXNtaXNzUGVybWFuZW50bHkiLCJzZXRJdGVtIiwiZ2V0VXJnZW5jeVN0eWxlIiwiZGF5cyIsImJhZGdlIiwiZG90IiwibWFwIiwiZ3JvdXAiLCJzdHlsZSIsImdyb3VwX25hbWUiLCJEYXRlIiwiZW5kX2RhdGUiLCJ0b0xvY2FsZURhdGVTdHJpbmciLCJkYXkiLCJtb250aCIsInllYXIiLCJtb250aHNfcmVtYWluaW5nIiwiX2lkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ2xvc2luZ0dyb3Vwc01vZGFsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBjb21wb25lbnRzL21vZGFscy9DbG9zaW5nR3JvdXBzTW9kYWwuanN4XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBBbGVydFRyaWFuZ2xlLCBYLCBDbG9jayB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IEFQSSBmcm9tIFwiLi4vLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5cclxuY29uc3QgQ2xvc2luZ0dyb3Vwc01vZGFsID0gKCkgPT4ge1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyBPbmx5IHRyaWdnZXIgb24gdGhlIGRhc2hib2FyZCByb3V0ZVxyXG4gICAgaWYgKGxvY2F0aW9uLnBhdGhuYW1lICE9PSBcIi9kYXNoYm9hcmRcIikgcmV0dXJuO1xyXG5cclxuICAgIC8vIERvbid0IHJlLXNob3cgaWYgcGVybWFuZW50bHkgZGlzbWlzc2VkIHRoaXMgc2Vzc2lvblxyXG4gICAgaWYgKHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oXCJjbG9zaW5nR3JvdXBzRGlzbWlzc2VkXCIpID09PSBcInRydWVcIikgcmV0dXJuO1xyXG5cclxuICAgIGNvbnN0IGZldGNoQ2xvc2luZ0dyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi92MS9hZG1pbi9ncm91cHMvY2xvc2luZ1wiKTtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YT8uc3VjY2Vzcykge1xyXG4gICAgICAgICAgY29uc3QgZGF0YSA9IHJlc3BvbnNlLmRhdGEuZGF0YSB8fCBbXTtcclxuICAgICAgICAgIGlmIChkYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgLy8gTW9zdCB1cmdlbnQgKGZld2VzdCBkYXlzIHJlbWFpbmluZykgZmlyc3RcclxuICAgICAgICAgICAgY29uc3Qgc29ydGVkID0gWy4uLmRhdGFdLnNvcnQoXHJcbiAgICAgICAgICAgICAgKGEsIGIpID0+IGEuZGF5c19yZW1haW5pbmcgLSBiLmRheXNfcmVtYWluaW5nXHJcbiAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgIHNldEdyb3Vwcyhzb3J0ZWQpO1xyXG4gICAgICAgICAgICBzZXRWaXNpYmxlKHRydWUpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgY2xvc2luZyBncm91cHM6XCIsIGVycm9yKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaENsb3NpbmdHcm91cHMoKTtcclxuICB9LCBbbG9jYXRpb24ucGF0aG5hbWVdKTtcclxuXHJcbiAgLy8gXCJSZW1pbmQgbWUgbGF0ZXJcIiAtPiBqdXN0IGhpZGUgZm9yIG5vdywgZG8gTk9UIHBlcnNpc3QgdG8gc2Vzc2lvblN0b3JhZ2VcclxuICAvLyBzbyBpdCBzaG93cyBhZ2FpbiB0aGUgbmV4dCB0aW1lIHRoaXMgZWZmZWN0IHJ1bnMuXHJcbiAgY29uc3QgaGFuZGxlUmVtaW5kTGF0ZXIgPSAoKSA9PiB7XHJcbiAgICBzZXRWaXNpYmxlKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICAvLyBcIkRvbid0IHNob3cgYWdhaW5cIiAtPiBoaWRlIEFORCBwZXJzaXN0IHRvIHNlc3Npb25TdG9yYWdlIHNvIGl0IHdvbid0XHJcbiAgLy8gcG9wIHVwIGFnYWluIGZvciB0aGUgcmVzdCBvZiB0aGlzIHNlc3Npb24uXHJcbiAgY29uc3QgaGFuZGxlRGlzbWlzc1Blcm1hbmVudGx5ID0gKCkgPT4ge1xyXG4gICAgc2V0VmlzaWJsZShmYWxzZSk7XHJcbiAgICBzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKFwiY2xvc2luZ0dyb3Vwc0Rpc21pc3NlZFwiLCBcInRydWVcIik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0VXJnZW5jeVN0eWxlID0gKGRheXMpID0+IHtcclxuICAgIGlmIChkYXlzIDw9IDMwKVxyXG4gICAgICByZXR1cm4geyBiYWRnZTogXCJiZy1yZWQtMTAwIHRleHQtcmVkLTcwMFwiLCBkb3Q6IFwiYmctcmVkLTUwMFwiIH07XHJcbiAgICBpZiAoZGF5cyA8PSA2MClcclxuICAgICAgcmV0dXJuIHsgYmFkZ2U6IFwiYmctYW1iZXItMTAwIHRleHQtYW1iZXItNzAwXCIsIGRvdDogXCJiZy1hbWJlci01MDBcIiB9O1xyXG4gICAgcmV0dXJuIHsgYmFkZ2U6IFwiYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTcwMFwiLCBkb3Q6IFwiYmctYmx1ZS01MDBcIiB9O1xyXG4gIH07XHJcblxyXG4gIGlmICghdmlzaWJsZSB8fCBsb2FkaW5nKSByZXR1cm4gbnVsbDtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LVs5OTk4XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibGFjay82MCBiYWNrZHJvcC1ibHVyLXNtIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0yMDBcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIG1heC13LWxnIHctZnVsbCBteC00IG92ZXJmbG93LWhpZGRlbiBhbmltYXRlLWluIHpvb20taW4tOTUgZHVyYXRpb24tMjAwIGJvcmRlciBib3JkZXItYW1iZXItMTAwXCI+XHJcbiAgICAgICAgey8qIEhlYWRlciAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1hbWJlci01MDAgdG8tYW1iZXItNDAwIHB4LTYgcHktNSBmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTEgaC0xMSByb3VuZGVkLWZ1bGwgYmctd2hpdGUvMjAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIGNsYXNzTmFtZT1cInctNiBoLTYgdGV4dC13aGl0ZVwiIC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgbGVhZGluZy10aWdodFwiPlxyXG4gICAgICAgICAgICAgICAgR3JvdXBzIENsb3NpbmcgU29vblxyXG4gICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1hbWJlci01MCB0ZXh0LXhzIGZvbnQtbWVkaXVtIG10LTAuNVwiPlxyXG4gICAgICAgICAgICAgICAge2dyb3Vwcy5sZW5ndGh9IGdyb3Vwe2dyb3Vwcy5sZW5ndGggPiAxID8gXCJzXCIgOiBcIlwifSBuZWVkXHJcbiAgICAgICAgICAgICAgICB7Z3JvdXBzLmxlbmd0aCA9PT0gMSA/IFwic1wiIDogXCJcIn0geW91ciBhdHRlbnRpb25cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJlbWluZExhdGVyfVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlLzgwIGhvdmVyOnRleHQtd2hpdGUgaG92ZXI6Ymctd2hpdGUvMTAgcm91bmRlZC1sZyBwLTEuNSB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIHsvKiBMaXN0ICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LWgtODAgb3ZlcmZsb3cteS1hdXRvIGRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDBcIj5cclxuICAgICAgICAgIHtncm91cHMubWFwKChncm91cCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBzdHlsZSA9IGdldFVyZ2VuY3lTdHlsZShncm91cC5kYXlzX3JlbWFpbmluZyk7XHJcbiAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAga2V5PXtncm91cC5faWR9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGhvdmVyOmJnLXNsYXRlLTUwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIHRydW5jYXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Q2xvY2sgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgRW5kc3tcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoZ3JvdXAuZW5kX2RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGRheTogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBtb250aDogXCJzaG9ydFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC0zIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtZnVsbCBib3JkZXIgcHgtMyBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gc2hhZG93LXNtICR7c3R5bGUuYmFkZ2V9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7Z3JvdXA/Lm1vbnRoc19yZW1haW5pbmd9IE1vbnRoe2dyb3VwPy5tb250aHNfcmVtYWluaW5nICE9PSAxID8gXCJzXCIgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtZnVsbCBib3JkZXIgcHgtMyBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gc2hhZG93LXNtICR7c3R5bGUuYmFkZ2V9YH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtncm91cD8uZGF5c19yZW1haW5pbmd9IERheXMgTGVmdFxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKTtcclxuICAgICAgICAgIH0pfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRm9vdGVyICovfVxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgYmctc2xhdGUtNTAgZmxleCBqdXN0aWZ5LWVuZCBnYXAtM1wiPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVSZW1pbmRMYXRlcn1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yLjUgYmctd2hpdGUgaG92ZXI6Ymctc2xhdGUtMTAwIHRleHQtc2xhdGUtNzAwIHRleHQtc20gZm9udC1ib2xkIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBSZW1pbmQgbWUgbGF0ZXJcclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEaXNtaXNzUGVybWFuZW50bHl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMi41IGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSB0ZXh0LXNtIGZvbnQtYm9sZCByb3VuZGVkLXhsIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgRG9uJ3Qgc2hvdyBhZ2FpblxyXG4gICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENsb3NpbmdHcm91cHNNb2RhbDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL2NvbXBvbmVudHMvbW9kYWxzL0Nsb3NpbmdHcm91cHNNb2RhbC5qc3gifQ==