import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/printFormats/CustomerGroupEnrollPrint.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import mychitsLogo from "/src/assets/images/mychits.png?import";
const CustomerGroupEnrollPrint = ({ enrollment }) => {
  const user = enrollment.user_id || {};
  const group = enrollment.group_id || {};
  const agent = enrollment.agent || {};
  const referredCustomer = enrollment.referred_customer || {};
  const referredLead = enrollment.referred_lead || {};
  const formatDate = (dateStr) => {
    if (!dateStr) return "-";
    const d = new Date(dateStr);
    return d.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });
  };
  const maskAadhaar = (aadhaar) => {
    if (!aadhaar) return "-";
    const value = String(aadhaar).replace(/\s/g, "");
    if (value.length <= 4) return value;
    return `XXXX XXXX ${value.slice(-4)}`;
  };
  const maskPan = (pan) => {
    if (!pan) return "-";
    const value = String(pan);
    if (value.length <= 4) return value;
    return `${"X".repeat(Math.max(0, value.length - 4))}${value.slice(-4)}`;
  };
  let referredBy = "N/A";
  if (enrollment.referred_type === "Agent" && agent.name) {
    referredBy = `${agent.name} | ${agent.phone_number || ""}`;
  } else if (enrollment.referred_type === "Customer" && referredCustomer.full_name) {
    referredBy = `${referredCustomer.full_name} | ${referredCustomer.phone_number || ""}`;
  } else if (enrollment.referred_type === "Leads" && referredLead.lead_name) {
    referredBy = `${referredLead.lead_name} | ${referredLead.agent_number || ""}`;
  } else if (enrollment.referred_type === "Employee" && enrollment.agent?.name) {
    referredBy = `${enrollment.agent.name} | ${enrollment.agent.phone_number || ""}`;
  } else if (enrollment.referred_type) {
    referredBy = enrollment.referred_type;
  }
  const now = /* @__PURE__ */ new Date();
  const dateTimeStr = now.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true
  });
  return /* @__PURE__ */ jsxDEV("div", { className: "print-container", children: [
    /* @__PURE__ */ jsxDEV("style", { children: `
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }

                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: #fff;
                    padding: 30px;
                    color: #333;
                }

                .print-container {
                    max-width: 800px;
                    margin: 0 auto;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    padding: 30px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
                    background: #fff;
                }

                .header {
                    display: flex;
                    align-items: center;
                    justify-content: space-between;
                    border-bottom: 2px solid #4f46e5;
                    padding-bottom: 12px;
                    margin-bottom: 20px;
                }

                .header-left {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                }

                .logo {
                    height: 50px;
                    width: auto;
                }

                .company-name {
                    font-weight: bold;
                    font-size: 16px;
                    color: #1e293b;
                    letter-spacing: 0.5px;
                }

                .company-detail {
                    font-size: 10px;
                    color: #555;
                    line-height: 1.4;
                }

                .header-right {
                    text-align: right;
                    font-size: 10px;
                    color: #555;
                    line-height: 1.4;
                }

                .header-bottom {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    margin-top: 2px;
                    margin-bottom: 25px;
                }

                .brand {
                    font-size: 18px;
                    font-weight: bold;
                    color: #1e293b;
                }

                .title {
                    font-size: 18px;
                    font-weight: 600;
                    color: #1e293b;
                }

                .datetime {
                    font-size: 12px;
                    color: #666;
                }

                .acknowledgement-title {
                    text-align: center;
                    font-size: 22px;
                    font-weight: 700;
                    color: #1e293b;
                    letter-spacing: 0.5px;
                    margin: 20px 0 8px 0;
                }

                .acknowledgement-subtitle {
                    text-align: center;
                    font-size: 12px;
                    color: #64748b;
                    margin-bottom: 25px;
                }

                .acknowledgement-box {
                    border: 1px solid #dbeafe;
                    background: #f8fafc;
                    border-radius: 8px;
                    padding: 22px;
                    margin-bottom: 25px;
                }

                .acknowledgement-text {
                    font-size: 14px;
                    line-height: 1.9;
                    color: #334155;
                    text-align: justify;
                }

                .highlight {
                    font-weight: 700;
                    color: #1e293b;
                }

                .joined-status {
                    text-align: center;
                    margin: 20px 0;
                }

                .joined-badge {
                    display: inline-block;
                    padding: 8px 22px;
                    border-radius: 25px;
                    background: #dcfce7;
                    color: #166534;
                    border: 1px solid #bbf7d0;
                    font-size: 13px;
                    font-weight: 700;
                    letter-spacing: 0.3px;
                }

                .section-title {
                    font-size: 16px;
                    font-weight: 600;
                    margin: 22px 0 12px 0;
                    color: #1e293b;
                    border-left: 4px solid #4f46e5;
                    padding-left: 10px;
                }

                .details-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 20px;
                }

                .details-table td {
                    border: 1px solid #e2e8f0;
                    padding: 8px 12px;
                    font-size: 13px;
                }

                .details-table td:first-child {
                    width: 38%;
                    font-weight: 600;
                    color: #475569;
                    background: #f8fafc;
                }

                .details-table td:last-child {
                    color: #0f172a;
                    font-weight: 500;
                }

                .personal-details-grid {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 6px 20px;
                    margin: 12px 0 20px 0;
                    padding: 0;
                }

                .personal-item {
                    display: flex;
                    border-bottom: 1px dashed #e2e8f0;
                    padding: 4px 0;
                    font-size: 13px;
                }

                .personal-item .label {
                    width: 110px;
                    font-weight: 600;
                    color: #475569;
                    flex-shrink: 0;
                }

                .personal-item .value {
                    color: #0f172a;
                    font-weight: 500;
                }

                .declaration {
                    margin-top: 25px;
                    border-top: 1px solid #e2e8f0;
                    padding-top: 18px;
                }

                .declaration-title {
                    font-size: 14px;
                    font-weight: 700;
                    color: #1e293b;
                    margin-bottom: 8px;
                }

                .declaration-text {
                    font-size: 11px;
                    line-height: 1.7;
                    color: #64748b;
                    text-align: justify;
                }

                .signature-section {
                    display: flex;
                    justify-content: space-between;
                    margin-top: 55px;
                    gap: 50px;
                }

                .signature-box {
                    width: 45%;
                    text-align: center;
                }

                .signature-line {
                    border-top: 1px solid #475569;
                    margin-bottom: 7px;
                }

                .signature-label {
                    font-size: 11px;
                    color: #475569;
                    font-weight: 600;
                }

                .footer-note {
                    text-align: center;
                    font-size: 10px;
                    color: #94a3b8;
                    margin-top: 35px;
                }

                @media print {
                    body {
                        padding: 0;
                    }

                    .print-container {
                        border: none;
                        box-shadow: none;
                    }

                    .acknowledgement-box {
                        break-inside: avoid;
                    }

                    .details-table {
                        break-inside: avoid;
                    }

                    .signature-section {
                        break-inside: avoid;
                    }
                }
            ` }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 83,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "header", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "header-left", children: /* @__PURE__ */ jsxDEV(
        "img",
        {
          src: mychitsLogo,
          alt: "MyChits Logo",
          className: "logo"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 362,
          columnNumber: 21
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 361,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "header-right", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "company-name", children: "VIJAYA VINAYAK CHITFUNDS PRIVATE LIMITED" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 370,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "company-detail", children: "CIN: U65999KA2022PTC161858" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 374,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "company-detail", children: "No 11/36-25, 2nd Main, Kathirguppe Main Road, Bangalore, Karnataka, India - 560070" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 378,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 369,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 360,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "header-bottom", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "brand" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 387,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "title", children: "Enrollment Acknowledgement" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 389,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "datetime", children: dateTimeStr }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 393,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 386,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "acknowledgement-title", children: "ACKNOWLEDGEMENT OF CHIT GROUP JOINING" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 399,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "acknowledgement-subtitle", children: "Customer Enrollment Confirmation" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 403,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "joined-status", children: /* @__PURE__ */ jsxDEV("span", { className: "joined-badge", children: "✓ CHIT GROUP JOINING CONFIRMED" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 408,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 407,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "acknowledgement-box", children: /* @__PURE__ */ jsxDEV("p", { className: "acknowledgement-text", children: [
      /* @__PURE__ */ jsxDEV("span", { className: "highlight", children: "Dear Sir/Madam," }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 416,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 420,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 421,
        columnNumber: 21
      }, this),
      "Thank you for choosing and enrolling with",
      /* @__PURE__ */ jsxDEV("span", { className: "highlight", children: [
        " ",
        "VIJAYA VINAYAK CHITFUNDS PRIVATE LIMITED"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 424,
        columnNumber: 21
      }, this),
      ". We are pleased to welcome you as a valued member of our chit fund family.",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 430,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 431,
        columnNumber: 21
      }, this),
      "We hereby acknowledge that",
      /* @__PURE__ */ jsxDEV("span", { className: "highlight", children: [
        " ",
        user.full_name || "-"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 434,
        columnNumber: 21
      }, this),
      ", Customer ID",
      /* @__PURE__ */ jsxDEV("span", { className: "highlight", children: [
        " ",
        user.customer_id || "-"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 438,
        columnNumber: 21
      }, this),
      ", has successfully enrolled in the",
      /* @__PURE__ */ jsxDEV("span", { className: "highlight", children: [
        " ",
        group.group_name + " " || "-"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 442,
        columnNumber: 21
      }, this),
      "chit group with Ticket Number",
      /* @__PURE__ */ jsxDEV("span", { className: "highlight", children: [
        " ",
        enrollment.tickets || "-"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 446,
        columnNumber: 21
      }, this),
      ".",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 450,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 451,
        columnNumber: 21
      }, this),
      "Your enrollment has been successfully recorded in our company records. We sincerely thank you for placing your trust in us and look forward to providing you with our best services throughout your chit journey.",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 458,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 459,
        columnNumber: 21
      }, this),
      "Please keep this acknowledgement safely for your future reference and records.",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 464,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 465,
        columnNumber: 21
      }, this),
      "Thank you for being a valued customer of",
      /* @__PURE__ */ jsxDEV("span", { className: "highlight", children: [
        " ",
        "VIJAYA VINAYAK CHITFUNDS PRIVATE LIMITED"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 468,
        columnNumber: 21
      }, this),
      "."
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 415,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 414,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "section-title", children: "Chit Group Details" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 475,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("table", { className: "details-table", children: /* @__PURE__ */ jsxDEV("tbody", { children: [
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: "Customer Name" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 482,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: user.full_name || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 483,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 481,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: "Customer ID" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 487,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: user.customer_id || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 488,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 486,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: "Mobile Number" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 492,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: user.phone_number || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 493,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 491,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: "Chit Group" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 497,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: group.group_name || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 498,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 496,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: "Ticket Number" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 502,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: enrollment.tickets || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 503,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 501,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: "Payment Type" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 507,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: enrollment.payment_type || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 508,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 506,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: "Customer Status" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 512,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: enrollment.customer_status || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 513,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 511,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: "Chit Asking Month" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 517,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: enrollment.chit_asking_month || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 518,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 516,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: "Enrollment Date" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 522,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: formatDate(enrollment.createdAt) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 523,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 521,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: "Referred By" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 532,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: referredBy }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 533,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 531,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 480,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 479,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "section-title", children: "Customer Personal Information" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 539,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "personal-details-grid", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "Name" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 545,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.full_name || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 546,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 544,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "Gender" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 559,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.gender || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 560,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 558,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "Phone" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 566,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.phone_number || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 567,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 565,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "Email" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 573,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.email || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 574,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 572,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "Marital Status" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 580,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.marital_status || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 581,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 579,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "Nationality" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 587,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.nationality || "Indian" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 588,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 586,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "Address" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 594,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.address || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 595,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 593,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "Village" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 601,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.village || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 602,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 600,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "Taluk" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 608,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.taluk || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 609,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 607,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "District" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 615,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.district || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 616,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 614,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "State" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 622,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.state || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 623,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 621,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "Pincode" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 629,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.pincode || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 630,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 628,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "Father's Name" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 636,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.father_name || "-" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 637,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 635,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "Aadhaar No." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 643,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.adhaar_no }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 644,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 642,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "personal-item", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "label", children: "PAN No." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 651,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: "value", children: user.pan_no }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 652,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 650,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 543,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "section-title", children: "Acknowledgement" }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 660,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "acknowledgement-box", children: /* @__PURE__ */ jsxDEV("p", { className: "acknowledgement-text", children: [
      "We hereby confirm that the above customer has been enrolled in the mentioned chit group and the corresponding ticket has been allotted as per the enrollment records.",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 670,
        columnNumber: 21
      }, this),
      "This acknowledgement is issued as a confirmation of joining the chit group. It should be preserved by the customer for future reference and record purposes."
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 665,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 664,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "declaration", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "declaration-title", children: "Declaration" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 680,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "declaration-text", children: "The information stated in this acknowledgement is based on the enrollment details available in the company's records as on the date of issue. The customer's participation in the chit group is governed by the applicable chit agreement, rules, regulations and terms and conditions of the company." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 684,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 679,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "signature-section", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "signature-box", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "signature-line" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 697,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "signature-label", children: "Customer Signature" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 699,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 696,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "signature-box", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "signature-line" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 705,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "signature-label", children: "Authorized Signatory" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
          lineNumber: 707,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
        lineNumber: 704,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 695,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "footer-note", children: "This is a computer-generated acknowledgement and does not require a physical seal unless otherwise specified." }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
      lineNumber: 714,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx",
    lineNumber: 82,
    columnNumber: 5
  }, this);
};
_c = CustomerGroupEnrollPrint;
export default CustomerGroupEnrollPrint;
var _c;
$RefreshReg$(_c, "CustomerGroupEnrollPrint");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/components/printFormats/CustomerGroupEnrollPrint.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0ZZOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEZaLE9BQU9BLFdBQVc7QUFDbEIsT0FBT0MsaUJBQWlCO0FBRXhCLE1BQU1DLDJCQUEyQkEsQ0FBQyxFQUFFQyxXQUFXLE1BQU07QUFDakQsUUFBTUMsT0FBT0QsV0FBV0UsV0FBVyxDQUFDO0FBQ3BDLFFBQU1DLFFBQVFILFdBQVdJLFlBQVksQ0FBQztBQUN0QyxRQUFNQyxRQUFRTCxXQUFXSyxTQUFTLENBQUM7QUFDbkMsUUFBTUMsbUJBQW1CTixXQUFXTyxxQkFBcUIsQ0FBQztBQUMxRCxRQUFNQyxlQUFlUixXQUFXUyxpQkFBaUIsQ0FBQztBQUVsRCxRQUFNQyxhQUFhQSxDQUFDQyxZQUFZO0FBQzVCLFFBQUksQ0FBQ0EsUUFBUyxRQUFPO0FBRXJCLFVBQU1DLElBQUksSUFBSUMsS0FBS0YsT0FBTztBQUUxQixXQUFPQyxFQUFFRSxtQkFBbUIsU0FBUztBQUFBLE1BQ2pDQyxLQUFLO0FBQUEsTUFDTEMsT0FBTztBQUFBLE1BQ1BDLE1BQU07QUFBQSxJQUNWLENBQUM7QUFBQSxFQUNMO0FBRUEsUUFBTUMsY0FBY0EsQ0FBQ0MsWUFBWTtBQUM3QixRQUFJLENBQUNBLFFBQVMsUUFBTztBQUVyQixVQUFNQyxRQUFRQyxPQUFPRixPQUFPLEVBQUVHLFFBQVEsT0FBTyxFQUFFO0FBRS9DLFFBQUlGLE1BQU1HLFVBQVUsRUFBRyxRQUFPSDtBQUU5QixXQUFPLGFBQWFBLE1BQU1JLE1BQU0sRUFBRSxDQUFDO0FBQUEsRUFDdkM7QUFFQSxRQUFNQyxVQUFVQSxDQUFDQyxRQUFRO0FBQ3JCLFFBQUksQ0FBQ0EsSUFBSyxRQUFPO0FBRWpCLFVBQU1OLFFBQVFDLE9BQU9LLEdBQUc7QUFFeEIsUUFBSU4sTUFBTUcsVUFBVSxFQUFHLFFBQU9IO0FBRTlCLFdBQU8sR0FBRyxJQUFJTyxPQUFPQyxLQUFLQyxJQUFJLEdBQUdULE1BQU1HLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBR0gsTUFBTUksTUFBTSxFQUFFLENBQUM7QUFBQSxFQUN6RTtBQUdBLE1BQUlNLGFBQWE7QUFFakIsTUFBSTlCLFdBQVcrQixrQkFBa0IsV0FBVzFCLE1BQU0yQixNQUFNO0FBQ3BERixpQkFBYSxHQUFHekIsTUFBTTJCLElBQUksTUFBTTNCLE1BQU00QixnQkFBZ0IsRUFBRTtBQUFBLEVBQzVELFdBQ0lqQyxXQUFXK0Isa0JBQWtCLGNBQzdCekIsaUJBQWlCNEIsV0FDbkI7QUFDRUosaUJBQWEsR0FBR3hCLGlCQUFpQjRCLFNBQVMsTUFBTTVCLGlCQUFpQjJCLGdCQUFnQixFQUFFO0FBQUEsRUFDdkYsV0FDSWpDLFdBQVcrQixrQkFBa0IsV0FDN0J2QixhQUFhMkIsV0FDZjtBQUNFTCxpQkFBYSxHQUFHdEIsYUFBYTJCLFNBQVMsTUFBTTNCLGFBQWE0QixnQkFBZ0IsRUFBRTtBQUFBLEVBQy9FLFdBQ0lwQyxXQUFXK0Isa0JBQWtCLGNBQzdCL0IsV0FBV0ssT0FBTzJCLE1BQ3BCO0FBQ0VGLGlCQUFhLEdBQUc5QixXQUFXSyxNQUFNMkIsSUFBSSxNQUFNaEMsV0FBV0ssTUFBTTRCLGdCQUFnQixFQUFFO0FBQUEsRUFDbEYsV0FBV2pDLFdBQVcrQixlQUFlO0FBQ2pDRCxpQkFBYTlCLFdBQVcrQjtBQUFBQSxFQUM1QjtBQUdBLFFBQU1NLE1BQU0sb0JBQUl4QixLQUFLO0FBRXJCLFFBQU15QixjQUFjRCxJQUFJRSxlQUFlLFNBQVM7QUFBQSxJQUM1Q3hCLEtBQUs7QUFBQSxJQUNMQyxPQUFPO0FBQUEsSUFDUEMsTUFBTTtBQUFBLElBQ051QixNQUFNO0FBQUEsSUFDTkMsUUFBUTtBQUFBLElBQ1JDLFFBQVE7QUFBQSxFQUNaLENBQUM7QUFFRCxTQUNJLHVCQUFDLFNBQUksV0FBVSxtQkFDWDtBQUFBLDJCQUFDLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa1JFO0FBQUEsSUFHRix1QkFBQyxTQUFJLFdBQVUsVUFDWDtBQUFBLDZCQUFDLFNBQUksV0FBVSxlQUNYO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDRyxLQUFLNUM7QUFBQUEsVUFDTCxLQUFJO0FBQUEsVUFDSixXQUFVO0FBQUE7QUFBQSxRQUhkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdvQixLQUp4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxnQkFDWDtBQUFBLCtCQUFDLFNBQUksV0FBVSxnQkFBZSx3REFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQWlCLDBDQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSxrQkFBaUIsa0dBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0F0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsNkJBQUMsVUFBSyxXQUFVLFdBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0I7QUFBQSxNQUV4Qix1QkFBQyxVQUFLLFdBQVUsU0FBUSwwQ0FBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxVQUFLLFdBQVUsWUFDWHdDLHlCQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUseUJBQXdCLHFEQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSw0QkFBMkIsZ0RBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNYLGlDQUFDLFVBQUssV0FBVSxnQkFBZSw4Q0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ1gsaUNBQUMsT0FBRSxXQUFVLHdCQUNUO0FBQUEsNkJBQUMsVUFBSyxXQUFVLGFBQVksK0JBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUEsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUNILHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFBRztBQUFBLE1BR04sdUJBQUMsVUFBSyxXQUFVLGFBQ1g7QUFBQTtBQUFBLFFBQUk7QUFBQSxXQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQU87QUFBQSxNQUlQLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDSCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQUc7QUFBQSxNQUdOLHVCQUFDLFVBQUssV0FBVSxhQUNYO0FBQUE7QUFBQSxRQUFLckMsS0FBS2lDLGFBQWE7QUFBQSxXQUQ1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUFPO0FBQUEsTUFFUCx1QkFBQyxVQUFLLFdBQVUsYUFDWDtBQUFBO0FBQUEsUUFBS2pDLEtBQUswQyxlQUFlO0FBQUEsV0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFBTztBQUFBLE1BRVAsdUJBQUMsVUFBSyxXQUFVLGFBQ1g7QUFBQTtBQUFBLFFBQUt4QyxNQUFNeUMsYUFBYSxPQUFPO0FBQUEsV0FEcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFBTztBQUFBLE1BRVAsdUJBQUMsVUFBSyxXQUFVLGFBQ1g7QUFBQTtBQUFBLFFBQUs1QyxXQUFXNkMsV0FBVztBQUFBLFdBRGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQU87QUFBQSxNQUVQLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDSCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQUc7QUFBQSxNQU9OLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDSCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQUc7QUFBQSxNQUtOLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDSCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQUc7QUFBQSxNQUdOLHVCQUFDLFVBQUssV0FBVSxhQUNYO0FBQUE7QUFBQSxRQUFJO0FBQUEsV0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUFPO0FBQUEsU0F2RFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdEQSxLQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMERBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCLGtDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFdBQU0sV0FBVSxpQkFDYixpQ0FBQyxXQUNHO0FBQUEsNkJBQUMsUUFDRztBQUFBLCtCQUFDLFFBQUcsNkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQjtBQUFBLFFBQ2pCLHVCQUFDLFFBQUk1QyxlQUFLaUMsYUFBYSxPQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsV0FGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxRQUNHO0FBQUEsK0JBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWU7QUFBQSxRQUNmLHVCQUFDLFFBQUlqQyxlQUFLMEMsZUFBZSxPQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCO0FBQUEsV0FGakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxRQUNHO0FBQUEsK0JBQUMsUUFBRyw2QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlCO0FBQUEsUUFDakIsdUJBQUMsUUFBSTFDLGVBQUtnQyxnQkFBZ0IsT0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFdBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsUUFDRztBQUFBLCtCQUFDLFFBQUcsMEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFjO0FBQUEsUUFDZCx1QkFBQyxRQUFJOUIsZ0JBQU15QyxjQUFjLE9BQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkI7QUFBQSxXQUZqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFFBQ0c7QUFBQSwrQkFBQyxRQUFHLDZCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUI7QUFBQSxRQUNqQix1QkFBQyxRQUFJNUMscUJBQVc2QyxXQUFXLE9BQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0I7QUFBQSxXQUZuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFFBQ0c7QUFBQSwrQkFBQyxRQUFHLDRCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0I7QUFBQSxRQUNoQix1QkFBQyxRQUFJN0MscUJBQVc4QyxnQkFBZ0IsT0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQztBQUFBLFdBRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUEsdUJBQUMsUUFDRztBQUFBLCtCQUFDLFFBQUcsK0JBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQjtBQUFBLFFBQ25CLHVCQUFDLFFBQUk5QyxxQkFBVytDLG1CQUFtQixPQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDO0FBQUEsV0FGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxRQUNHO0FBQUEsK0JBQUMsUUFBRyxpQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFCO0FBQUEsUUFDckIsdUJBQUMsUUFBSS9DLHFCQUFXZ0QscUJBQXFCLE9BQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUM7QUFBQSxXQUY3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFFBQ0c7QUFBQSwrQkFBQyxRQUFHLCtCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUI7QUFBQSxRQUNuQix1QkFBQyxRQUFJdEMscUJBQVdWLFdBQVdpRCxTQUFTLEtBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQSxXQUYxQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQU9BLHVCQUFDLFFBQ0c7QUFBQSwrQkFBQyxRQUFHLDJCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZTtBQUFBLFFBQ2YsdUJBQUMsUUFBSW5CLHdCQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0I7QUFBQSxXQUZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQXRESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdURBLEtBeERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5REE7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSxpQkFBZ0IsNkNBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlCQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsVUFBSyxXQUFVLFNBQVEsb0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxRQUM1Qix1QkFBQyxVQUFLLFdBQVUsU0FDWDdCLGVBQUtpQyxhQUFhLE9BRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFTQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxVQUFLLFdBQVUsU0FBUSxzQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4QjtBQUFBLFFBQzlCLHVCQUFDLFVBQUssV0FBVSxTQUNYakMsZUFBS2lELFVBQVUsT0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFVBQUssV0FBVSxTQUFRLHFCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTZCO0FBQUEsUUFDN0IsdUJBQUMsVUFBSyxXQUFVLFNBQ1hqRCxlQUFLZ0MsZ0JBQWdCLE9BRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxVQUFLLFdBQVUsU0FBUSxxQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QjtBQUFBLFFBQzdCLHVCQUFDLFVBQUssV0FBVSxTQUNYaEMsZUFBS2tELFNBQVMsT0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFVBQUssV0FBVSxTQUFRLDhCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDO0FBQUEsUUFDdEMsdUJBQUMsVUFBSyxXQUFVLFNBQ1hsRCxlQUFLbUQsa0JBQWtCLE9BRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxVQUFLLFdBQVUsU0FBUSwyQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBQ25DLHVCQUFDLFVBQUssV0FBVSxTQUNYbkQsZUFBS29ELGVBQWUsWUFEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFVBQUssV0FBVSxTQUFRLHVCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQStCO0FBQUEsUUFDL0IsdUJBQUMsVUFBSyxXQUFVLFNBQ1hwRCxlQUFLcUQsV0FBVyxPQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsVUFBSyxXQUFVLFNBQVEsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0I7QUFBQSxRQUMvQix1QkFBQyxVQUFLLFdBQVUsU0FDWHJELGVBQUtzRCxXQUFXLE9BRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxVQUFLLFdBQVUsU0FBUSxxQkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QjtBQUFBLFFBQzdCLHVCQUFDLFVBQUssV0FBVSxTQUNYdEQsZUFBS3VELFNBQVMsT0FEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFVBQUssV0FBVSxTQUFRLHdCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdDO0FBQUEsUUFDaEMsdUJBQUMsVUFBSyxXQUFVLFNBQ1h2RCxlQUFLd0QsWUFBWSxPQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsVUFBSyxXQUFVLFNBQVEscUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkI7QUFBQSxRQUM3Qix1QkFBQyxVQUFLLFdBQVUsU0FDWHhELGVBQUt5RCxTQUFTLE9BRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxVQUFLLFdBQVUsU0FBUSx1QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQjtBQUFBLFFBQy9CLHVCQUFDLFVBQUssV0FBVSxTQUNYekQsZUFBSzBELFdBQVcsT0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDWDtBQUFBLCtCQUFDLFVBQUssV0FBVSxTQUFRLDZCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUEsUUFDckMsdUJBQUMsVUFBSyxXQUFVLFNBQ1gxRCxlQUFLMkQsZUFBZSxPQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlCQUNYO0FBQUEsK0JBQUMsVUFBSyxXQUFVLFNBQVEsMkJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQSxRQUNuQyx1QkFBQyxVQUFLLFdBQVUsU0FFTjNELGVBQUs0RCxhQUZmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFdBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxVQUFLLFdBQVUsU0FBUSx1QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQjtBQUFBLFFBQy9CLHVCQUFDLFVBQUssV0FBVSxTQUVQNUQsZUFBSzZELFVBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsV0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQWpISjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0hBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsaUJBQWdCLCtCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx1QkFDWCxpQ0FBQyxPQUFFLFdBQVUsd0JBQXVCO0FBQUE7QUFBQSxNQUtoQyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQUc7QUFBQSxTQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQSxLQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLGVBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUscUJBQW9CLDJCQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVBLHVCQUFDLE9BQUUsV0FBVSxvQkFBbUIsc1RBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFPQTtBQUFBLFNBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUscUJBQ1g7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsb0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQztBQUFBLFFBRWhDLHVCQUFDLFNBQUksV0FBVSxtQkFBa0Isa0NBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ1g7QUFBQSwrQkFBQyxTQUFJLFdBQVUsb0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnQztBQUFBLFFBRWhDLHVCQUFDLFNBQUksV0FBVSxtQkFBa0Isb0NBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0FmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsZUFBYyw2SEFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsT0EzbkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0bkJBO0FBRVI7QUFBRUMsS0Exc0JJaEU7QUE0c0JOLGVBQWVBO0FBQXlCLElBQUFnRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJteWNoaXRzTG9nbyIsIkN1c3RvbWVyR3JvdXBFbnJvbGxQcmludCIsImVucm9sbG1lbnQiLCJ1c2VyIiwidXNlcl9pZCIsImdyb3VwIiwiZ3JvdXBfaWQiLCJhZ2VudCIsInJlZmVycmVkQ3VzdG9tZXIiLCJyZWZlcnJlZF9jdXN0b21lciIsInJlZmVycmVkTGVhZCIsInJlZmVycmVkX2xlYWQiLCJmb3JtYXREYXRlIiwiZGF0ZVN0ciIsImQiLCJEYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwiZGF5IiwibW9udGgiLCJ5ZWFyIiwibWFza0FhZGhhYXIiLCJhYWRoYWFyIiwidmFsdWUiLCJTdHJpbmciLCJyZXBsYWNlIiwibGVuZ3RoIiwic2xpY2UiLCJtYXNrUGFuIiwicGFuIiwicmVwZWF0IiwiTWF0aCIsIm1heCIsInJlZmVycmVkQnkiLCJyZWZlcnJlZF90eXBlIiwibmFtZSIsInBob25lX251bWJlciIsImZ1bGxfbmFtZSIsImxlYWRfbmFtZSIsImFnZW50X251bWJlciIsIm5vdyIsImRhdGVUaW1lU3RyIiwidG9Mb2NhbGVTdHJpbmciLCJob3VyIiwibWludXRlIiwiaG91cjEyIiwiY3VzdG9tZXJfaWQiLCJncm91cF9uYW1lIiwidGlja2V0cyIsInBheW1lbnRfdHlwZSIsImN1c3RvbWVyX3N0YXR1cyIsImNoaXRfYXNraW5nX21vbnRoIiwiY3JlYXRlZEF0IiwiZ2VuZGVyIiwiZW1haWwiLCJtYXJpdGFsX3N0YXR1cyIsIm5hdGlvbmFsaXR5IiwiYWRkcmVzcyIsInZpbGxhZ2UiLCJ0YWx1ayIsImRpc3RyaWN0Iiwic3RhdGUiLCJwaW5jb2RlIiwiZmF0aGVyX25hbWUiLCJhZGhhYXJfbm8iLCJwYW5fbm8iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDdXN0b21lckdyb3VwRW5yb2xsUHJpbnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIlxyXG4vKiBlc2xpbnQtZGlzYWJsZSByZWFjdC9wcm9wLXR5cGVzICovXHJcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IG15Y2hpdHNMb2dvIGZyb20gXCIuLi8uLi9hc3NldHMvaW1hZ2VzL215Y2hpdHMucG5nXCI7XHJcblxyXG5jb25zdCBDdXN0b21lckdyb3VwRW5yb2xsUHJpbnQgPSAoeyBlbnJvbGxtZW50IH0pID0+IHtcclxuICAgIGNvbnN0IHVzZXIgPSBlbnJvbGxtZW50LnVzZXJfaWQgfHwge307XHJcbiAgICBjb25zdCBncm91cCA9IGVucm9sbG1lbnQuZ3JvdXBfaWQgfHwge307XHJcbiAgICBjb25zdCBhZ2VudCA9IGVucm9sbG1lbnQuYWdlbnQgfHwge307XHJcbiAgICBjb25zdCByZWZlcnJlZEN1c3RvbWVyID0gZW5yb2xsbWVudC5yZWZlcnJlZF9jdXN0b21lciB8fCB7fTtcclxuICAgIGNvbnN0IHJlZmVycmVkTGVhZCA9IGVucm9sbG1lbnQucmVmZXJyZWRfbGVhZCB8fCB7fTtcclxuXHJcbiAgICBjb25zdCBmb3JtYXREYXRlID0gKGRhdGVTdHIpID0+IHtcclxuICAgICAgICBpZiAoIWRhdGVTdHIpIHJldHVybiBcIi1cIjtcclxuXHJcbiAgICAgICAgY29uc3QgZCA9IG5ldyBEYXRlKGRhdGVTdHIpO1xyXG5cclxuICAgICAgICByZXR1cm4gZC50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1JTlwiLCB7XHJcbiAgICAgICAgICAgIGRheTogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgICAgIG1vbnRoOiBcInNob3J0XCIsXHJcbiAgICAgICAgICAgIHllYXI6IFwibnVtZXJpY1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBtYXNrQWFkaGFhciA9IChhYWRoYWFyKSA9PiB7XHJcbiAgICAgICAgaWYgKCFhYWRoYWFyKSByZXR1cm4gXCItXCI7XHJcblxyXG4gICAgICAgIGNvbnN0IHZhbHVlID0gU3RyaW5nKGFhZGhhYXIpLnJlcGxhY2UoL1xccy9nLCBcIlwiKTtcclxuXHJcbiAgICAgICAgaWYgKHZhbHVlLmxlbmd0aCA8PSA0KSByZXR1cm4gdmFsdWU7XHJcblxyXG4gICAgICAgIHJldHVybiBgWFhYWCBYWFhYICR7dmFsdWUuc2xpY2UoLTQpfWA7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IG1hc2tQYW4gPSAocGFuKSA9PiB7XHJcbiAgICAgICAgaWYgKCFwYW4pIHJldHVybiBcIi1cIjtcclxuXHJcbiAgICAgICAgY29uc3QgdmFsdWUgPSBTdHJpbmcocGFuKTtcclxuXHJcbiAgICAgICAgaWYgKHZhbHVlLmxlbmd0aCA8PSA0KSByZXR1cm4gdmFsdWU7XHJcblxyXG4gICAgICAgIHJldHVybiBgJHtcIlhcIi5yZXBlYXQoTWF0aC5tYXgoMCwgdmFsdWUubGVuZ3RoIC0gNCkpfSR7dmFsdWUuc2xpY2UoLTQpfWA7XHJcbiAgICB9O1xyXG5cclxuICAgIC8vIEJ1aWxkIHJlZmVycmFsIGRpc3BsYXlcclxuICAgIGxldCByZWZlcnJlZEJ5ID0gXCJOL0FcIjtcclxuXHJcbiAgICBpZiAoZW5yb2xsbWVudC5yZWZlcnJlZF90eXBlID09PSBcIkFnZW50XCIgJiYgYWdlbnQubmFtZSkge1xyXG4gICAgICAgIHJlZmVycmVkQnkgPSBgJHthZ2VudC5uYW1lfSB8ICR7YWdlbnQucGhvbmVfbnVtYmVyIHx8IFwiXCJ9YDtcclxuICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgICAgZW5yb2xsbWVudC5yZWZlcnJlZF90eXBlID09PSBcIkN1c3RvbWVyXCIgJiZcclxuICAgICAgICByZWZlcnJlZEN1c3RvbWVyLmZ1bGxfbmFtZVxyXG4gICAgKSB7XHJcbiAgICAgICAgcmVmZXJyZWRCeSA9IGAke3JlZmVycmVkQ3VzdG9tZXIuZnVsbF9uYW1lfSB8ICR7cmVmZXJyZWRDdXN0b21lci5waG9uZV9udW1iZXIgfHwgXCJcIn1gO1xyXG4gICAgfSBlbHNlIGlmIChcclxuICAgICAgICBlbnJvbGxtZW50LnJlZmVycmVkX3R5cGUgPT09IFwiTGVhZHNcIiAmJlxyXG4gICAgICAgIHJlZmVycmVkTGVhZC5sZWFkX25hbWVcclxuICAgICkge1xyXG4gICAgICAgIHJlZmVycmVkQnkgPSBgJHtyZWZlcnJlZExlYWQubGVhZF9uYW1lfSB8ICR7cmVmZXJyZWRMZWFkLmFnZW50X251bWJlciB8fCBcIlwifWA7XHJcbiAgICB9IGVsc2UgaWYgKFxyXG4gICAgICAgIGVucm9sbG1lbnQucmVmZXJyZWRfdHlwZSA9PT0gXCJFbXBsb3llZVwiICYmXHJcbiAgICAgICAgZW5yb2xsbWVudC5hZ2VudD8ubmFtZVxyXG4gICAgKSB7XHJcbiAgICAgICAgcmVmZXJyZWRCeSA9IGAke2Vucm9sbG1lbnQuYWdlbnQubmFtZX0gfCAke2Vucm9sbG1lbnQuYWdlbnQucGhvbmVfbnVtYmVyIHx8IFwiXCJ9YDtcclxuICAgIH0gZWxzZSBpZiAoZW5yb2xsbWVudC5yZWZlcnJlZF90eXBlKSB7XHJcbiAgICAgICAgcmVmZXJyZWRCeSA9IGVucm9sbG1lbnQucmVmZXJyZWRfdHlwZTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBDdXJyZW50IGRhdGUvdGltZVxyXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuXHJcbiAgICBjb25zdCBkYXRlVGltZVN0ciA9IG5vdy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIsIHtcclxuICAgICAgICBkYXk6IFwiMi1kaWdpdFwiLFxyXG4gICAgICAgIG1vbnRoOiBcInNob3J0XCIsXHJcbiAgICAgICAgeWVhcjogXCJudW1lcmljXCIsXHJcbiAgICAgICAgaG91cjogXCIyLWRpZ2l0XCIsXHJcbiAgICAgICAgbWludXRlOiBcIjItZGlnaXRcIixcclxuICAgICAgICBob3VyMTI6IHRydWUsXHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJpbnQtY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgIDxzdHlsZT57YFxyXG4gICAgICAgICAgICAgICAgKiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBib2R5IHtcclxuICAgICAgICAgICAgICAgICAgICBmb250LWZhbWlseTogJ1NlZ29lIFVJJywgVGFob21hLCBHZW5ldmEsIFZlcmRhbmEsIHNhbnMtc2VyaWY7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAzMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMzMzO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC5wcmludC1jb250YWluZXIge1xyXG4gICAgICAgICAgICAgICAgICAgIG1heC13aWR0aDogODAwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2RkZDtcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMzBweDtcclxuICAgICAgICAgICAgICAgICAgICBib3gtc2hhZG93OiAwIDJweCAxMHB4IHJnYmEoMCwwLDAsMC4wNSk7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuaGVhZGVyIHtcclxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjNGY0NmU1O1xyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLmhlYWRlci1sZWZ0IHtcclxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgZ2FwOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC5sb2dvIHtcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IGF1dG87XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLmNvbXBhbnktbmFtZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMWUyOTNiO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAwLjVweDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuY29tcGFueS1kZXRhaWwge1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzU1NTtcclxuICAgICAgICAgICAgICAgICAgICBsaW5lLWhlaWdodDogMS40O1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC5oZWFkZXItcmlnaHQge1xyXG4gICAgICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzU1NTtcclxuICAgICAgICAgICAgICAgICAgICBsaW5lLWhlaWdodDogMS40O1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC5oZWFkZXItYm90dG9tIHtcclxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDJweDtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAyNXB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC5icmFuZCB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMWUyOTNiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC50aXRsZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICMxZTI5M2I7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLmRhdGV0aW1lIHtcclxuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM2NjY7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLmFja25vd2xlZGdlbWVudC10aXRsZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMWUyOTNiO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAwLjVweDtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDIwcHggMCA4cHggMDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuYWNrbm93bGVkZ2VtZW50LXN1YnRpdGxlIHtcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjNjQ3NDhiO1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDI1cHg7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLmFja25vd2xlZGdlbWVudC1ib3gge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNkYmVhZmU7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2Y4ZmFmYztcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMjJweDtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAyNXB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC5hY2tub3dsZWRnZW1lbnQtdGV4dCB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICMzMzQxNTU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dC1hbGlnbjoganVzdGlmeTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuaGlnaGxpZ2h0IHtcclxuICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMWUyOTNiO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC5qb2luZWQtc3RhdHVzIHtcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAyMHB4IDA7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLmpvaW5lZC1iYWRnZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDhweCAyMnB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2RjZmNlNztcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzE2NjUzNDtcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjYmJmN2QwO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICAgICAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAwLjNweDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuc2VjdGlvbi10aXRsZSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAyMnB4IDAgMTJweCAwO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMWUyOTNiO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1sZWZ0OiA0cHggc29saWQgIzRmNDZlNTtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLmRldGFpbHMtdGFibGUge1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuZGV0YWlscy10YWJsZSB0ZCB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2UyZThmMDtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiA4cHggMTJweDtcclxuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLmRldGFpbHMtdGFibGUgdGQ6Zmlyc3QtY2hpbGQge1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAzOCU7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzQ3NTU2OTtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZjhmYWZjO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC5kZXRhaWxzLXRhYmxlIHRkOmxhc3QtY2hpbGQge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMGYxNzJhO1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLnBlcnNvbmFsLWRldGFpbHMtZ3JpZCB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogZ3JpZDtcclxuICAgICAgICAgICAgICAgICAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnI7XHJcbiAgICAgICAgICAgICAgICAgICAgZ2FwOiA2cHggMjBweDtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDEycHggMCAyMHB4IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAucGVyc29uYWwtaXRlbSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggZGFzaGVkICNlMmU4ZjA7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogNHB4IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC5wZXJzb25hbC1pdGVtIC5sYWJlbCB7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDExMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM0NzU1Njk7XHJcbiAgICAgICAgICAgICAgICAgICAgZmxleC1zaHJpbms6IDA7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLnBlcnNvbmFsLWl0ZW0gLnZhbHVlIHtcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogIzBmMTcyYTtcclxuICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC5kZWNsYXJhdGlvbiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMjVweDtcclxuICAgICAgICAgICAgICAgICAgICBib3JkZXItdG9wOiAxcHggc29saWQgI2UyZThmMDtcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nLXRvcDogMThweDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuZGVjbGFyYXRpb24tdGl0bGUge1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAjMWUyOTNiO1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDhweDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuZGVjbGFyYXRpb24tdGV4dCB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxLjc7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM2NDc0OGI7XHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dC1hbGlnbjoganVzdGlmeTtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuc2lnbmF0dXJlLXNlY3Rpb24ge1xyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDU1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgZ2FwOiA1MHB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIC5zaWduYXR1cmUtYm94IHtcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDogNDUlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuc2lnbmF0dXJlLWxpbmUge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci10b3A6IDFweCBzb2xpZCAjNDc1NTY5O1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDdweDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuc2lnbmF0dXJlLWxhYmVsIHtcclxuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM0NzU1Njk7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAuZm9vdGVyLW5vdGUge1xyXG4gICAgICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICM5NGEzYjg7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMzVweDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICBAbWVkaWEgcHJpbnQge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvZHkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgLnByaW50LWNvbnRhaW5lciB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC5hY2tub3dsZWRnZW1lbnQtYm94IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWstaW5zaWRlOiBhdm9pZDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC5kZXRhaWxzLXRhYmxlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWstaW5zaWRlOiBhdm9pZDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC5zaWduYXR1cmUtc2VjdGlvbiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrLWluc2lkZTogYXZvaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBgfTwvc3R5bGU+XHJcblxyXG4gICAgICAgICAgICB7LyogSEVBREVSICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlclwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoZWFkZXItbGVmdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtteWNoaXRzTG9nb31cclxuICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiTXlDaGl0cyBMb2dvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibG9nb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyLXJpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb21wYW55LW5hbWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVklKQVlBIFZJTkFZQUsgQ0hJVEZVTkRTIFBSSVZBVEUgTElNSVRFRFxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbXBhbnktZGV0YWlsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENJTjogVTY1OTk5S0EyMDIyUFRDMTYxODU4XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29tcGFueS1kZXRhaWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTm8gMTEvMzYtMjUsIDJuZCBNYWluLCBLYXRoaXJndXBwZSBNYWluIFJvYWQsIEJhbmdhbG9yZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgS2FybmF0YWthLCBJbmRpYSAtIDU2MDA3MFxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFNFQ09ORCBMSU5FICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlci1ib3R0b21cIj5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJyYW5kXCI+PC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgRW5yb2xsbWVudCBBY2tub3dsZWRnZW1lbnRcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJkYXRldGltZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtkYXRlVGltZVN0cn1cclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogQUNLTk9XTEVER0VNRU5UIFRJVExFICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFja25vd2xlZGdlbWVudC10aXRsZVwiPlxyXG4gICAgICAgICAgICAgICAgQUNLTk9XTEVER0VNRU5UIE9GIENISVQgR1JPVVAgSk9JTklOR1xyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWNrbm93bGVkZ2VtZW50LXN1YnRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICBDdXN0b21lciBFbnJvbGxtZW50IENvbmZpcm1hdGlvblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiam9pbmVkLXN0YXR1c1wiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiam9pbmVkLWJhZGdlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAg4pyTIENISVQgR1JPVVAgSk9JTklORyBDT05GSVJNRURcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogTUFJTiBBQ0tOT1dMRURHRU1FTlQgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWNrbm93bGVkZ2VtZW50LWJveFwiPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYWNrbm93bGVkZ2VtZW50LXRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWdobGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgRGVhciBTaXIvTWFkYW0sXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8YnIgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgVGhhbmsgeW91IGZvciBjaG9vc2luZyBhbmQgZW5yb2xsaW5nIHdpdGhcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWdobGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge1wiIFwifVZJSkFZQSBWSU5BWUFLIENISVRGVU5EUyBQUklWQVRFIExJTUlURURcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+LlxyXG4gICAgICAgICAgICAgICAgICAgIFdlIGFyZSBwbGVhc2VkIHRvIHdlbGNvbWUgeW91IGFzIGEgdmFsdWVkIG1lbWJlciBvZiBvdXJcclxuICAgICAgICAgICAgICAgICAgICBjaGl0IGZ1bmQgZmFtaWx5LlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8YnIgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgV2UgaGVyZWJ5IGFja25vd2xlZGdlIHRoYXRcclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWdobGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge1wiIFwifXt1c2VyLmZ1bGxfbmFtZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+LFxyXG4gICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIElEXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlnaGxpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcIiBcIn17dXNlci5jdXN0b21lcl9pZCB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+LFxyXG4gICAgICAgICAgICAgICAgICAgIGhhcyBzdWNjZXNzZnVsbHkgZW5yb2xsZWQgaW4gdGhlXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlnaGxpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcIiBcIn17Z3JvdXAuZ3JvdXBfbmFtZSArIFwiIFwiIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICBjaGl0IGdyb3VwIHdpdGggVGlja2V0IE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZ2hsaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XCIgXCJ9e2Vucm9sbG1lbnQudGlja2V0cyB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+LlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8YnIgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgWW91ciBlbnJvbGxtZW50IGhhcyBiZWVuIHN1Y2Nlc3NmdWxseSByZWNvcmRlZCBpbiBvdXJcclxuICAgICAgICAgICAgICAgICAgICBjb21wYW55IHJlY29yZHMuIFdlIHNpbmNlcmVseSB0aGFuayB5b3UgZm9yIHBsYWNpbmcgeW91clxyXG4gICAgICAgICAgICAgICAgICAgIHRydXN0IGluIHVzIGFuZCBsb29rIGZvcndhcmQgdG8gcHJvdmlkaW5nIHlvdSB3aXRoIG91clxyXG4gICAgICAgICAgICAgICAgICAgIGJlc3Qgc2VydmljZXMgdGhyb3VnaG91dCB5b3VyIGNoaXQgam91cm5leS5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJyIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIFBsZWFzZSBrZWVwIHRoaXMgYWNrbm93bGVkZ2VtZW50IHNhZmVseSBmb3IgeW91ciBmdXR1cmVcclxuICAgICAgICAgICAgICAgICAgICByZWZlcmVuY2UgYW5kIHJlY29yZHMuXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxiciAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICBUaGFuayB5b3UgZm9yIGJlaW5nIGEgdmFsdWVkIGN1c3RvbWVyIG9mXHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlnaGxpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcIiBcIn1WSUpBWUEgVklOQVlBSyBDSElURlVORFMgUFJJVkFURSBMSU1JVEVEXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPi5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogR1JPVVAgREVUQUlMUyAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICBDaGl0IEdyb3VwIERldGFpbHNcclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwiZGV0YWlscy10YWJsZVwiPlxyXG4gICAgICAgICAgICAgICAgPHRib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPkN1c3RvbWVyIE5hbWU8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e3VzZXIuZnVsbF9uYW1lIHx8IFwiLVwifTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+Q3VzdG9tZXIgSUQ8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e3VzZXIuY3VzdG9tZXJfaWQgfHwgXCItXCJ9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5Nb2JpbGUgTnVtYmVyPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPnt1c2VyLnBob25lX251bWJlciB8fCBcIi1cIn08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPkNoaXQgR3JvdXA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e2dyb3VwLmdyb3VwX25hbWUgfHwgXCItXCJ9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5UaWNrZXQgTnVtYmVyPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPntlbnJvbGxtZW50LnRpY2tldHMgfHwgXCItXCJ9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5QYXltZW50IFR5cGU8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e2Vucm9sbG1lbnQucGF5bWVudF90eXBlIHx8IFwiLVwifTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+Q3VzdG9tZXIgU3RhdHVzPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPntlbnJvbGxtZW50LmN1c3RvbWVyX3N0YXR1cyB8fCBcIi1cIn08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPkNoaXQgQXNraW5nIE1vbnRoPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPntlbnJvbGxtZW50LmNoaXRfYXNraW5nX21vbnRoIHx8IFwiLVwifTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+RW5yb2xsbWVudCBEYXRlPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPntmb3JtYXREYXRlKGVucm9sbG1lbnQuY3JlYXRlZEF0KX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZD5SZWZlcnJlZCBUeXBlPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkPntlbnJvbGxtZW50LnJlZmVycmVkX3R5cGUgfHwgXCItXCJ9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPiAqL31cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+UmVmZXJyZWQgQnk8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQ+e3JlZmVycmVkQnl9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgPC90YWJsZT5cclxuXHJcbiAgICAgICAgICAgIHsvKiBDVVNUT01FUiBQRVJTT05BTCBJTkZPUk1BVElPTiAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICBDdXN0b21lciBQZXJzb25hbCBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGVyc29uYWwtZGV0YWlscy1ncmlkXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBlcnNvbmFsLWl0ZW1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYWJlbFwiPk5hbWU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cInBlcnNvbmFsLWl0ZW1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYWJlbFwiPkRPQjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ2YWx1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RGF0ZSh1c2VyLmRhdGVvZmJpcnRoKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZXJzb25hbC1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGFiZWxcIj5HZW5kZXI8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuZ2VuZGVyIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGVyc29uYWwtaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxhYmVsXCI+UGhvbmU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIucGhvbmVfbnVtYmVyIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGVyc29uYWwtaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxhYmVsXCI+RW1haWw8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuZW1haWwgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZXJzb25hbC1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGFiZWxcIj5NYXJpdGFsIFN0YXR1czwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ2YWx1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5tYXJpdGFsX3N0YXR1cyB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBlcnNvbmFsLWl0ZW1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYWJlbFwiPk5hdGlvbmFsaXR5PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLm5hdGlvbmFsaXR5IHx8IFwiSW5kaWFuXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZXJzb25hbC1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGFiZWxcIj5BZGRyZXNzPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmFkZHJlc3MgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZXJzb25hbC1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGFiZWxcIj5WaWxsYWdlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLnZpbGxhZ2UgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZXJzb25hbC1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGFiZWxcIj5UYWx1azwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ2YWx1ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dXNlci50YWx1ayB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBlcnNvbmFsLWl0ZW1cIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJsYWJlbFwiPkRpc3RyaWN0PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmRpc3RyaWN0IHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGVyc29uYWwtaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxhYmVsXCI+U3RhdGU8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuc3RhdGUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZXJzb25hbC1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGFiZWxcIj5QaW5jb2RlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLnBpbmNvZGUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZXJzb25hbC1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGFiZWxcIj5GYXRoZXIncyBOYW1lPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZhdGhlcl9uYW1lIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGVyc29uYWwtaXRlbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxhYmVsXCI+QWFkaGFhciBOby48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidmFsdWVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIHttYXNrQWFkaGFhcih1c2VyLmFkaGFhcl9ubyl9ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyh1c2VyLmFkaGFhcl9ubyl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwZXJzb25hbC1pdGVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGFiZWxcIj5QQU4gTm8uPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInZhbHVlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiB7bWFza1Bhbih1c2VyLnBhbl9ubyl9ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICB7KHVzZXIucGFuX25vKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogQUNLTk9XTEVER0VNRU5UIFNUQVRFTUVOVCAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWN0aW9uLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICBBY2tub3dsZWRnZW1lbnRcclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFja25vd2xlZGdlbWVudC1ib3hcIj5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImFja25vd2xlZGdlbWVudC10ZXh0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgV2UgaGVyZWJ5IGNvbmZpcm0gdGhhdCB0aGUgYWJvdmUgY3VzdG9tZXIgaGFzIGJlZW4gZW5yb2xsZWRcclxuICAgICAgICAgICAgICAgICAgICBpbiB0aGUgbWVudGlvbmVkIGNoaXQgZ3JvdXAgYW5kIHRoZSBjb3JyZXNwb25kaW5nIHRpY2tldFxyXG4gICAgICAgICAgICAgICAgICAgIGhhcyBiZWVuIGFsbG90dGVkIGFzIHBlciB0aGUgZW5yb2xsbWVudCByZWNvcmRzLlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8YnIgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgVGhpcyBhY2tub3dsZWRnZW1lbnQgaXMgaXNzdWVkIGFzIGEgY29uZmlybWF0aW9uIG9mXHJcbiAgICAgICAgICAgICAgICAgICAgam9pbmluZyB0aGUgY2hpdCBncm91cC4gSXQgc2hvdWxkIGJlIHByZXNlcnZlZCBieSB0aGVcclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21lciBmb3IgZnV0dXJlIHJlZmVyZW5jZSBhbmQgcmVjb3JkIHB1cnBvc2VzLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBERUNMQVJBVElPTiAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWNsYXJhdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZWNsYXJhdGlvbi10aXRsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIERlY2xhcmF0aW9uXHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJkZWNsYXJhdGlvbi10ZXh0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgVGhlIGluZm9ybWF0aW9uIHN0YXRlZCBpbiB0aGlzIGFja25vd2xlZGdlbWVudCBpcyBiYXNlZCBvblxyXG4gICAgICAgICAgICAgICAgICAgIHRoZSBlbnJvbGxtZW50IGRldGFpbHMgYXZhaWxhYmxlIGluIHRoZSBjb21wYW55J3MgcmVjb3Jkc1xyXG4gICAgICAgICAgICAgICAgICAgIGFzIG9uIHRoZSBkYXRlIG9mIGlzc3VlLiBUaGUgY3VzdG9tZXIncyBwYXJ0aWNpcGF0aW9uIGluXHJcbiAgICAgICAgICAgICAgICAgICAgdGhlIGNoaXQgZ3JvdXAgaXMgZ292ZXJuZWQgYnkgdGhlIGFwcGxpY2FibGUgY2hpdFxyXG4gICAgICAgICAgICAgICAgICAgIGFncmVlbWVudCwgcnVsZXMsIHJlZ3VsYXRpb25zIGFuZCB0ZXJtcyBhbmQgY29uZGl0aW9ucyBvZlxyXG4gICAgICAgICAgICAgICAgICAgIHRoZSBjb21wYW55LlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBTSUdOQVRVUkUgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbmF0dXJlLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbmF0dXJlLWJveFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbmF0dXJlLWxpbmVcIj48L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzaWduYXR1cmUtbGFiZWxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgU2lnbmF0dXJlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ25hdHVyZS1ib3hcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNpZ25hdHVyZS1saW5lXCI+PC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2lnbmF0dXJlLWxhYmVsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEF1dGhvcml6ZWQgU2lnbmF0b3J5XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogRk9PVEVSICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1ub3RlXCI+XHJcbiAgICAgICAgICAgICAgICBUaGlzIGlzIGEgY29tcHV0ZXItZ2VuZXJhdGVkIGFja25vd2xlZGdlbWVudCBhbmQgZG9lcyBub3RcclxuICAgICAgICAgICAgICAgIHJlcXVpcmUgYSBwaHlzaWNhbCBzZWFsIHVubGVzcyBvdGhlcndpc2Ugc3BlY2lmaWVkLlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDdXN0b21lckdyb3VwRW5yb2xsUHJpbnQ7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL2NvbXBvbmVudHMvcHJpbnRGb3JtYXRzL0N1c3RvbWVyR3JvdXBFbnJvbGxQcmludC5qc3gifQ==