import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CoApplicant.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Input, Select, Dropdown } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CoApplicantPrint from "/src/components/printFormats/CoApplicantPrint.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { fieldSize } from "/src/data/fieldSize.js";
import { IoMdClose } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const CoApplicant = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [coApplicant, setCoApplicant] = useState([]);
  const [TableCoApplicant, setTableCoApplicant] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentCoApplicant, setCurrentCoApplicant] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentUpdateCoApplicant, setCurrentUpdateCoApplicant] = useState(null);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [enrollment, setEnrollment] = useState([]);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [customRelationship, setCustomRelationship] = useState("");
  const [errors, setErrors] = useState({});
  const [filteredEnrollments, setFilteredEnrollments] = useState([]);
  const [formData, setFormData] = useState({
    user_id: "",
    co_applicant_name: "",
    co_applicant_email: "",
    user_co_applicant: "",
    co_applicant_phone_number: "",
    co_applicant_address: "",
    co_applicant_pincode: "",
    co_applicant_adhaar_no: "",
    co_applicant_pan_no: "",
    co_applicant_gender: "",
    co_applicant_marital_status: "",
    co_applicant_dateofbirth: "",
    co_applicant_nationality: "",
    co_applicant_village: "",
    co_applicant_taluk: "",
    co_applicant_father_name: "",
    co_applicant_district: "",
    co_applicant_state: "",
    co_applicant_description: "",
    enrollment_ids: [],
    co_applicant_alternate_number: "",
    co_applicant_referred_type: "",
    co_applicant_document_name: "",
    co_applicant_document: "",
    co_applicant_photo: "",
    co_applicant_pan_document: "",
    co_applicant_aadhar_document: "",
    co_applicant_relationship_type: "",
    co_applicant_occupation: "",
    co_applicant_sector_name: "",
    co_applicant_income_document: "",
    co_applicant_consent_document: "",
    co_applicant_bank_name: "",
    co_applicant_bank_account_number: "",
    co_applicant_bank_branch: "",
    co_applicant_bank_ifsc_code: "",
    co_applicant_bank_passbook: "",
    co_applicant_bank_passbook_photo: "",
    co_applicant_bussiness_type: "",
    co_applicant_bussiness_name: "",
    co_applicant_bussiness_address: "",
    co_applicant_profession_type: "",
    co_applicant_agri_rtc_no: "",
    co_applicant_land_holdings: "",
    co_applicant_occupation_sub: "",
    co_applicant_all_document_name: "",
    co_applicant_all_document: ""
  });
  const [updateFormData, setUpdateFormData] = useState({
    user_id: "",
    co_applicant_name: "",
    co_applicant_email: "",
    user_co_applicant: "",
    co_applicant_phone_number: "",
    co_applicant_address: "",
    co_applicant_pincode: "",
    co_applicant_adhaar_no: "",
    co_applicant_pan_no: "",
    co_applicant_gender: "",
    co_applicant_marital_status: "",
    co_applicant_dateofbirth: "",
    co_applicant_nationality: "",
    co_applicant_village: "",
    co_applicant_taluk: "",
    co_applicant_father_name: "",
    co_applicant_district: "",
    co_applicant_state: "",
    co_applicant_description: "",
    co_applicant_alternate_number: "",
    enrollment_ids: [],
    co_applicant_referred_type: "",
    co_applicant_document: "",
    co_applicant_document_name: "",
    co_applicant_photo: "",
    co_applicant_pan_document: "",
    co_applicant_aadhar_document: "",
    co_applicant_relationship_type: "",
    co_applicant_occupation: "",
    co_applicant_sector_name: "",
    co_applicant_income_document: "",
    co_applicant_consent_document: "",
    co_applicant_bank_name: "",
    co_applicant_bank_account_number: "",
    co_applicant_bank_branch: "",
    co_applicant_bank_ifsc_code: "",
    co_applicant_bank_passbook: "",
    co_applicant_bank_passbook_photo: "",
    co_applicant_bussiness_type: "",
    co_applicant_bussiness_name: "",
    co_applicant_bussiness_address: "",
    co_applicant_profession_type: "",
    co_applicant_agri_rtc_no: "",
    co_applicant_land_holdings: "",
    co_applicant_occupation_sub: "",
    co_applicant_all_document_name: "",
    co_applicant_all_document: ""
  });
  const [searchText, setSearchText] = useState("");
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [extraDocs, setExtraDocs] = useState(
    formData.co_applicant_all_document || [
      { document_name: "", file: null, preview: "" }
    ]
  );
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
    fetchUsers();
  }, []);
  const handleExtraDocNameChange = (index, e) => {
    const updated = [...extraDocs];
    updated[index].document_name = e.target.value;
    setExtraDocs(updated);
  };
  const handleExtraDocFileChange = (index, e) => {
    const file = e.target.files[0];
    if (file) {
      const updated = [...extraDocs];
      updated[index].file = file;
      updated[index].preview = URL.createObjectURL(file);
      setExtraDocs(updated);
    }
  };
  const addNewDocField = () => {
    setExtraDocs(
      [
        ...extraDocs,
        { document_name: "", file: null, preview: "" }
      ]
    );
  };
  const removeDocField = (index) => {
    const updated = extraDocs.filter((_, i) => i !== index);
    setExtraDocs(updated);
    setFormData({ ...formData, co_applicant_all_document: updated });
  };
  useEffect(() => {
    const fetchEnrollmentData = async () => {
      setIsLoading(true);
      try {
        const response = await api.get(`/enroll-report/get-enroll-report`);
        if (response.data) {
          setEnrollment(response.data);
        }
      } catch (error) {
        console.error("Error fetching Enrollment data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchEnrollmentData();
  }, []);
  useEffect(() => {
    const fetchCoApplicant = async () => {
      try {
        setIsLoading(true);
        if (!users || users.length === 0) return;
        const response = await api.get("/coapplicant/get-co-applicant-info");
        const coapplicants = response.data?.coApplicant || [];
        const formattedData = coapplicants.map((group, index) => {
          const enrollmentSummary = (group?.enrollment_ids || []).map((enroll) => {
            const groupName = enroll?.group_id?.group_name || "N/A";
            const ticket = enroll?.tickets || "N/A";
            return `${groupName} | Ticket: ${ticket}`;
          }).join(", ");
          const customerUser = group?.co_applicant_referred_type === "Customer" ? users.find((u) => u._id === group?.user_co_applicant) : null;
          const coApplicantName = group?.co_applicant_referred_type === "Customer" ? customerUser?.full_name ?? "N/A" : group?.co_applicant_name ?? "N/A";
          const coApplicantPhone = group?.co_applicant_referred_type === "Customer" ? customerUser?.phone_number ?? "N/A" : group?.co_applicant_phone_number ?? "N/A";
          return {
            _id: group?._id,
            id: index + 1,
            co_applicant_code: group?.co_applicant_code,
            user_id: group?.user_id?.full_name ?? "N/A",
            enrollment_summary: enrollmentSummary,
            co_applicant_referred_type: group?.co_applicant_referred_type,
            co_applicant_name: coApplicantName,
            co_applicant_phone_number: coApplicantPhone,
            co_applicant_description: group?.co_applicant_description ?? "-",
            action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
              Dropdown,
              {
                trigger: ["click"],
                placement: "bottomLeft",
                menu: {
                  items: [
                    {
                      key: "1",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-green-600",
                          onClick: () => handleUpdateModalOpen(group?._id),
                          children: "Edit"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 269,
                          columnNumber: 21
                        },
                        this
                      )
                    },
                    {
                      key: "2",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-red-600",
                          onClick: () => handleDeleteModalOpen(group?._id),
                          children: "Delete"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 280,
                          columnNumber: 21
                        },
                        this
                      )
                    },
                    {
                      key: "3",
                      label: /* @__PURE__ */ jsxDEV(
                        "div",
                        {
                          className: "text-violet-600",
                          onClick: () => CoApplicantPrint(group?._id),
                          children: "Print"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 291,
                          columnNumber: 21
                        },
                        this
                      )
                    }
                  ]
                },
                children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 302,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 261,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 260,
              columnNumber: 13
            }, this)
          };
        });
        setCoApplicant(coapplicants);
        setTableCoApplicant(formattedData);
      } catch (error) {
        console.error(
          "Error fetching Co Applicant data:",
          error?.message || error
        );
      } finally {
        setIsLoading(false);
      }
    };
    fetchCoApplicant();
  }, [reloadTrigger, users]);
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    if (value !== "Other") {
      setCustomRelationship("");
    }
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors({ ...errors, [field]: "" });
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: ""
    }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addCoApplicant" ? formData : updateFormData;
    const regex = {
      email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      phone: /^[6-9]\d{9}$/,
      pincode: /^\d{6}$/,
      adhaar: /^\d{12}$/,
      pan: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/
    };
    const validateFile = (file, name) => {
      if (!file) {
        return `${name} is required`;
      }
      const allowedTypes = ["image/jpeg", "image/png", "image/jpg"];
      if (file instanceof File) {
        if (!allowedTypes.includes(file.type)) {
          return "Only JPG and PNG files are allowed";
        }
        if (file.size > 2 * 1024 * 1024) {
          return "File size must be less than 2MB";
        }
      } else if (typeof file === "string" && file.trim() === "") {
        return `${name} is required`;
      }
      return null;
    };
    if (!data.user_id) newErrors.user_id = "Customer Name is required";
    if (!data.co_applicant_referred_type)
      newErrors.co_applicant_referred_type = "Referred Type is required";
    if (!data.enrollment_ids || data.enrollment_ids.length === 0)
      newErrors.enrollment_ids = "Enrollment is required";
    if (data.co_applicant_referred_type === "Customer") {
      if (!data.user_co_applicant)
        newErrors.user_co_applicant = "Referred Customer is required";
      if (!data.co_applicant_description?.trim())
        newErrors.co_applicant_description = "Description is required";
    } else if (data.co_applicant_referred_type === "Property") {
      if (!data.co_applicant_description?.trim())
        newErrors.co_applicant_description = "Description is required";
      if (!data.co_applicant_document_name?.trim())
        newErrors.co_applicant_document_name = "Document Name is required";
      let fileError = validateFile(
        data.co_applicant_document,
        "Property Document Photo"
      );
      if (fileError) newErrors.co_applicant_document = fileError;
    } else if (data.co_applicant_referred_type === "Third Party") {
      if (!data.co_applicant_name?.trim())
        newErrors.co_applicant_name = "Co Applicant Name is required";
      if (!data.co_applicant_relationship_type?.trim())
        newErrors.co_applicant_relationship_type = "Co Applicant Relationship is required";
      if (!data.co_applicant_phone_number || !regex.phone.test(data.co_applicant_phone_number)) {
        newErrors.co_applicant_phone_number = "Invalid Phone Number";
      }
      if (!data.co_applicant_email || !regex.email.test(data.co_applicant_email)) {
        newErrors.co_applicant_email = "Invalid Email";
      }
      if (!data.co_applicant_address?.trim())
        newErrors.co_applicant_address = "Address is required";
      if (!data.co_applicant_pincode || !regex.pincode.test(data.co_applicant_pincode)) {
        newErrors.co_applicant_pincode = "Invalid Pincode";
      }
      if (!data.co_applicant_adhaar_no || !regex.adhaar.test(data.co_applicant_adhaar_no)) {
        newErrors.co_applicant_adhaar_no = "Invalid Aadhaar Number";
      }
      if (!data.co_applicant_pan_no || !regex.pan.test(data.co_applicant_pan_no)) {
        newErrors.co_applicant_pan_no = "Invalid PAN Capital Alphabet with Number";
      }
      let fileError = validateFile(data.co_applicant_photo, "Profile Photo");
      if (fileError) newErrors.co_applicant_photo = fileError;
      fileError = validateFile(
        data.co_applicant_pan_document,
        "PAN Card Photo"
      );
      if (fileError) newErrors.co_applicant_pan_document = fileError;
      fileError = validateFile(
        data.co_applicant_aadhar_document,
        "Aadhaar Card Photo"
      );
      if (fileError) newErrors.co_applicant_aadhar_document = fileError;
      if (!data.co_applicant_occupation)
        newErrors.co_applicant_occupation = "Occupation is required";
      switch (data.co_applicant_occupation) {
        case "Self Employed":
        case "Salaried":
          if (!data.co_applicant_bussiness_type?.trim())
            newErrors.co_applicant_bussiness_type = "Business Type is required";
          if (!data.co_applicant_bussiness_name?.trim())
            newErrors.co_applicant_bussiness_name = "Business Name is required";
          if (!data.co_applicant_bussiness_address?.trim())
            newErrors.co_applicant_bussiness_address = "Business Address is required";
          break;
        case "Professional":
          if (!data.co_applicant_profession_type?.trim())
            newErrors.co_applicant_profession_type = "Profession Type is required";
          if (!data.co_applicant_bussiness_address?.trim())
            newErrors.co_applicant_bussiness_address = "Business Address is required";
          break;
        case "Agri Allied":
          if (!data.co_applicant_agri_rtc_no?.trim())
            newErrors.co_applicant_agri_rtc_no = "RTC Number is required";
          if (!data.co_applicant_land_holdings)
            newErrors.co_applicant_land_holdings = "Land Holdings is required";
          if (!data.co_applicant_bussiness_address?.trim())
            newErrors.co_applicant_bussiness_address = "Business Address is required";
          break;
        case "Other":
          if (!data.co_applicant_occupation_sub?.trim())
            newErrors.co_applicant_occupation_sub = "Occupation Sub-category is required";
          if (data.co_applicant_occupation_sub === "Running an unregistered Business" && !data.co_applicant_bussiness_address?.trim()) {
            newErrors.co_applicant_bussiness_address = "Address is required for this occupation";
          }
          break;
        default:
          break;
      }
      fileError = validateFile(
        data.co_applicant_income_document,
        "Income Document Photo"
      );
      if (fileError) newErrors.co_applicant_income_document = fileError;
      if (!data.co_applicant_bank_name?.trim())
        newErrors.co_applicant_bank_name = "Bank Name is required";
      if (!data.co_applicant_bank_account_number?.trim())
        newErrors.co_applicant_bank_account_number = "Bank Account Number is required";
      if (!data.co_applicant_bank_branch?.trim())
        newErrors.co_applicant_bank_branch = "Bank Branch is required";
      if (!data.co_applicant_bank_ifsc_code?.trim())
        newErrors.co_applicant_bank_ifsc_code = "Bank IFSC Code is required";
      fileError = validateFile(
        data.co_applicant_bank_passbook_photo,
        "Bank Passbook Photo"
      );
      if (fileError) newErrors.co_applicant_bank_passbook_photo = fileError;
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isvalid = validateForm("addCoApplicant");
    if (isvalid) {
      try {
        const fmData = new FormData();
        Object.entries(formData).forEach(([key, value]) => {
          if (value instanceof File) {
            fmData.append(key, value);
          } else if (Array.isArray(value)) {
            value.forEach((v) => fmData.append(`${key}[]`, v));
          } else if (value) {
            fmData.append(key, value);
          }
        });
        extraDocs.forEach((doc, i) => {
          if (doc.file) {
            fmData.append("co_applicant_all_document", doc.file);
            fmData.append(
              "document_name[]",
              doc.document_name || `Document_${i + 1}`
            );
          }
        });
        const response = await api.post(
          "/coapplicant/add-co-applicant-info",
          //formData,
          fmData,
          {
            headers: {
              "Content-Type": "multipart/form-data"
            }
          }
        );
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          type: "success",
          message: "Co Applicant Added Successfully",
          visibility: true
        });
        setShowModal(false);
        setFormData({
          user_id: "",
          co_applicant_name: "",
          co_applicant_email: "",
          user_co_applicant: "",
          co_applicant_phone_number: "",
          co_applicant_address: "",
          co_applicant_pincode: "",
          co_applicant_adhaar_no: "",
          co_applicant_pan_no: "",
          co_applicant_gender: "",
          co_applicant_marital_status: "",
          co_applicant_dateofbirth: "",
          co_applicant_nationality: "",
          co_applicant_village: "",
          co_applicant_taluk: "",
          co_applicant_father_name: "",
          co_applicant_district: "",
          co_applicant_state: "",
          co_applicant_description: "",
          enrollment_ids: [],
          co_applicant_alternate_number: "",
          co_applicant_referred_type: "",
          co_applicant_document: "",
          co_applicant_document_name: "",
          co_applicant_photo: "",
          co_applicant_pan_document: "",
          co_applicant_aadhar_document: "",
          co_applicant_relationship_type: "",
          co_applicant_occupation: "",
          co_applicant_income: "",
          co_applicant_consent_document: "",
          co_applicant_bank_name: "",
          co_applicant_bank_account_number: "",
          co_applicant_bank_branch: "",
          co_applicant_bank_ifsc_code: "",
          co_applicant_bank_passbook_photo: "",
          co_applicant_sector_name: "",
          co_applicant_income_document: "",
          co_applicant_bussiness_type: "",
          co_applicant_bussiness_name: "",
          co_applicant_bussiness_address: "",
          co_applicant_profession_type: "",
          co_applicant_agri_rtc_no: "",
          co_applicant_land_holdings: "",
          co_applicant_occupation_sub: "",
          co_applicant_all_document_name: "",
          co_applicant_all_document: ""
        });
      } catch (error) {
        console.error("Error adding Co Applicant:", error);
        setAlertConfig({
          type: "error",
          message: error?.response?.data?.message || "An unexpected error occurred.",
          visibility: true
        });
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const fmData = new FormData();
      const { co_applicant_all_document, ...rest } = updateFormData;
      Object.entries(rest).forEach(([key, value]) => {
        if (value) fmData.append(key, value);
      });
      const singleFileFields = [
        "co_applicant_photo",
        "co_applicant_aadhar_document",
        "co_applicant_pan_document",
        "co_applicant_income_document",
        "co_applicant_bank_passbook_photo",
        "co_applicant_document"
      ];
      singleFileFields.forEach((field) => {
        if (updateFormData[field] instanceof File) {
          fmData.append(field, updateFormData[field]);
        }
      });
      if (extraDocs && Array.isArray(extraDocs)) {
        extraDocs.forEach((doc, i) => {
          if (doc.file instanceof File) {
            fmData.append("co_applicant_all_document", doc.file);
            fmData.append(
              "document_name[]",
              // ✅ send as array
              doc.document_name || `Document_${i + 1}`
            );
          }
        });
      }
      await api.put(
        `/coapplicant/update-co-applicant-info/${currentUpdateCoApplicant?._id}`,
        fmData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );
      setShowModalUpdate(false);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        type: "success",
        message: "Co Applicant Updated Successfully",
        visibility: true
      });
    } catch (error) {
      console.error("Error updating Co Applicant:", error);
      setAlertConfig({
        type: "error",
        message: error?.response?.data?.message || "Update failed",
        visibility: true
      });
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "co_applicant_code", header: "Co Applicant Code" },
    { key: "user_id", header: "Customer Name" },
    { key: "co_applicant_referred_type", header: "Referred Type" },
    { key: "enrollment_summary", header: "Enrollment Details" },
    { key: "co_applicant_name", header: "Co Applicant Name" },
    { key: "co_applicant_phone_number", header: "Co Applicant Phone Number" },
    { key: "action", header: "Action" }
  ];
  const filteredGuarantor = users.filter(
    (users2) => users2.full_name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDeleteModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/coapplicant/get-co-applicant-info-by-id/${userId}`
      );
      setCurrentCoApplicant(response.data?.coApplicant?._id || null);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching Co Applicant:", error);
    }
  };
  const handleFileChange = (e) => {
    const { name, files } = e.target;
    const file = files[0];
    if (file) {
      setFormData((prev) => ({
        ...prev,
        [name]: file,
        // ✅ keep real file object
        [`${name}_preview`]: URL.createObjectURL(file)
        // for preview
      }));
    }
  };
  const handleInputFileChange = (e) => {
    const { name, files } = e.target;
    const file = files[0];
    if (file) {
      setFormData((prev) => ({
        ...prev,
        [name]: file,
        // ✅ keep real file object
        [`${name}_preview`]: URL.createObjectURL(file)
        // for preview
      }));
    }
  };
  const handleUpdateModalOpen = async (userId) => {
    try {
      const response = await api.get(
        `/coapplicant/get-co-applicant-info-by-id/${userId}`
      );
      const coapplicant = response?.data?.coApplicant;
      const matchedEnrollments = (coapplicant?.enrollment_ids || []).map(
        (e) => ({
          _id: e._id,
          group_name: e?.group_id?.group_name || "N/A",
          ticket: e?.tickets || "N/A"
        })
      );
      setFilteredEnrollments(matchedEnrollments);
      setUpdateFormData({
        user_id: coapplicant?.user_id?._id || "",
        enrollment_ids: coapplicant?.enrollment_ids?.map((e) => e._id) || [],
        co_applicant_name: coapplicant?.co_applicant_name || "",
        co_applicant_email: coapplicant?.co_applicant_email || "",
        co_applicant_phone_number: coapplicant?.co_applicant_phone_number || "",
        user_co_applicant: coapplicant?.user_co_applicant || "",
        co_applicant_address: coapplicant?.co_applicant_address || "",
        co_applicant_pincode: coapplicant?.co_applicant_pincode || "",
        co_applicant_adhaar_no: coapplicant?.co_applicant_adhaar_no || "",
        co_applicant_pan_no: coapplicant?.co_applicant_pan_no || "",
        co_applicant_gender: coapplicant?.co_applicant_gender || "",
        co_applicant_marital_status: coapplicant?.co_applicant_marital_status || "",
        co_applicant_dateofbirth: coapplicant?.co_applicant_dateofbirth || "",
        co_applicant_nationality: coapplicant?.co_applicant_nationality || "",
        co_applicant_village: coapplicant?.co_applicant_village || "",
        co_applicant_taluk: coapplicant?.co_applicant_taluk || "",
        co_applicant_father_name: coapplicant?.co_applicant_father_name || "",
        co_applicant_district: coapplicant?.co_applicant_district || "",
        co_applicant_state: coapplicant?.co_applicant_state || "",
        co_applicant_description: coapplicant?.co_applicant_description || "",
        co_applicant_alternate_number: coapplicant?.co_applicant_alternate_number,
        co_applicant_document: coapplicant?.co_applicant_document || "",
        co_applicant_document_name: coapplicant?.co_applicant_document_name || "",
        co_applicant_referred_type: coapplicant?.co_applicant_referred_type || "",
        co_applicant_photo: coapplicant?.co_applicant_photo || "",
        co_applicant_pan_document: coapplicant?.co_applicant_pan_document || "",
        co_applicant_aadhar_document: coapplicant?.co_applicant_aadhar_document || "",
        co_applicant_relationship_type: coapplicant?.co_applicant_relationship_type || "",
        co_applicant_occupation: coapplicant?.co_applicant_occupation || "",
        co_applicant_income: coapplicant?.co_applicant_income || "",
        co_applicant_consent_document: coapplicant?.co_applicant_consent_document || "",
        co_applicant_bank_name: coapplicant?.co_applicant_bank_name || "",
        co_applicant_bank_account_number: coapplicant?.co_applicant_bank_account_number || "",
        co_applicant_bank_branch: coapplicant?.co_applicant_bank_branch || "",
        co_applicant_bank_ifsc_code: coapplicant?.co_applicant_bank_ifsc_code || "",
        co_applicant_bank_passbook_photo: coapplicant?.co_applicant_bank_passbook_photo || "",
        co_applicant_income_document: coapplicant?.co_applicant_income_document || "",
        co_applicant_bussiness_type: coapplicant?.co_applicant_bussiness_type || "",
        co_applicant_bussiness_name: coapplicant?.co_applicant_bussiness_name || "",
        co_applicant_bussiness_address: coapplicant?.co_applicant_bussiness_address || "",
        co_applicant_profession_type: coapplicant?.co_applicant_profession_type || "",
        co_applicant_agri_rtc_no: coapplicant?.co_applicant_agri_rtc_no || "",
        co_applicant_land_holdings: coapplicant?.co_applicant_land_holdings || "",
        co_applicant_occupation_sub: coapplicant?.co_applicant_occupation_sub || "",
        co_applicant_all_document_name: coapplicant?.co_applicant_all_document_name || "",
        co_applicant_all_document: coapplicant?.co_applicant_all_document || ""
      });
      setExtraDocs(
        (coapplicant?.co_applicant_all_document || []).map((d) => ({
          document_name: d.document_name,
          file: null,
          // no new file yet
          preview: d.document_url,
          // show existing file preview
          existingUrl: d.document_url
          // keep original in case user doesn’t replace
        }))
      );
      setCurrentUpdateCoApplicant(coapplicant);
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching Co Applicant:", error);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const handleDeleteCoApplicant = async () => {
    if (currentCoApplicant) {
      try {
        const response = await api.delete(
          `/coapplicant/delete-co-applicant-info-by-id/${currentCoApplicant}`
        );
        console.info(response, "snfbgsgb");
        setAlertConfig({
          visibility: true,
          message: "co applicant deleted successfully",
          type: "success"
        });
        setReloadTrigger((prev) => prev + 1);
        setShowModalDelete(false);
        setCurrentCoApplicant(null);
      } catch (error) {
        console.error("Error deleting Co Applicant:", error);
      }
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
        lineNumber: 903,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
          lineNumber: 904,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
          lineNumber: 908,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
            lineNumber: 919,
            columnNumber: 18
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Co Applicant Application" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 921,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setShowModal(true);
                  setErrors({});
                },
                className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
                children: "+ Add Co Applicant"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 923,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
            lineNumber: 920,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
          lineNumber: 918,
          columnNumber: 13
        }, this),
        TableCoApplicant?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableCoApplicant, searchText),
            columns,
            exportedPdfName: "CoApplicant",
            exportedFileName: `CoApplicant.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
            lineNumber: 935,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableCoApplicant.length <= 0,
            data: "Co Applicant Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
            lineNumber: 944,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
        lineNumber: 917,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
      lineNumber: 902,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Co Applicant" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
        lineNumber: 954,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(
        "form",
        {
          className: "space-y-6",
          method: "POST",
          onSubmit: handleSubmit,
          enctype: "multipart/form-data",
          noValidate: true,
          children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Customer Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 966,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 965,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Or Search Customer",
                  showSearch: true,
                  value: formData.user_id || void 0,
                  onChange: (value) => {
                    setFormData((prev) => ({
                      ...prev,
                      user_id: value,
                      enrollment_ids: []
                    }));
                    const filtered = enrollment.filter((e) => e.user_id?._id === value).map((e) => ({
                      _id: e._id,
                      group_name: e.group_id?.group_name,
                      ticket: e.tickets
                    }));
                    setFilteredEnrollments(filtered);
                  },
                  filterOption: (input, option) => option?.children?.toLowerCase().includes(input.toLowerCase()),
                  children: Array.from(
                    new Map(
                      enrollment.filter((e) => e.user_id && e.user_id.full_name?.trim()).map((e) => [e.user_id._id, e.user_id])
                    ).values()
                  ).map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1003,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 968,
                  columnNumber: 17
                },
                this
              ),
              errors.user_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.user_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 1009,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 964,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Select Enrollment ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1014,
                  columnNumber: 37
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 1013,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "tags",
                  allowClear: true,
                  placeholder: "Select enrollments",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  value: formData.enrollment_ids,
                  onChange: (selectedEnrollmentIds) => {
                    setFormData((prev) => ({
                      ...prev,
                      enrollment_ids: selectedEnrollmentIds
                    }));
                  },
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  children: filteredEnrollments.map((en) => {
                    const parts = [];
                    if (en.group_name && en.group_name !== "N/A")
                      parts.push(en.group_name);
                    if (en.ticket && en.ticket !== "N/A")
                      parts.push(`Ticket: ${en.ticket}`);
                    return /* @__PURE__ */ jsxDEV(Select.Option, { value: en._id, children: parts.join(" | ") }, en._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1039,
                      columnNumber: 23
                    }, this);
                  })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1016,
                  columnNumber: 17
                },
                this
              ),
              errors.enrollment_ids && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.enrollment_ids }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 1047,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 1012,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "referred_type",
                  children: [
                    "Select Referred Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1058,
                      columnNumber: 40
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1054,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Referred Type",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "co_applicant_referred_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: formData?.co_applicant_referred_type || void 0,
                  onChange: (value) => handleAntDSelect("co_applicant_referred_type", value),
                  children: ["Customer", "Third Party", "Property"].map(
                    (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1075,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1060,
                  columnNumber: 17
                },
                this
              ),
              errors.co_applicant_referred_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_referred_type }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 1081,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 1053,
              columnNumber: 15
            }, this),
            formData.co_applicant_referred_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full mb-4", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Select Co Applicant Customer",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1095,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1090,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                    placeholder: "Select Or Search Referred Co Applicant",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "user_co_applicant",
                    filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                    value: formData?.user_co_applicant || void 0,
                    onChange: (value) => handleAntDSelect("user_co_applicant", value),
                    children: users.map(
                      (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1116,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1098,
                    columnNumber: 21
                  },
                  this
                ),
                errors.user_co_applicant && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.user_co_applicant }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1122,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 1089,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "desc",
                    children: [
                      "Description ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1132,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1128,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "co_applicant_description",
                    value: formData.co_applicant_description,
                    onChange: handleChange,
                    id: "name",
                    placeholder: "Enter the Description",
                    required: true,
                    className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1134,
                    columnNumber: 21
                  },
                  this
                ),
                errors.co_applicant_description && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_description }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1145,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 1127,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 1088,
              columnNumber: 15
            }, this),
            formData.co_applicant_referred_type === "Third Party" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 mt-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "Personal Information" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1156,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Co Applicant Name",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1165,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1163,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_name",
                        value: formData.co_applicant_name,
                        onChange: handleChange,
                        placeholder: "Enter Co Applicant Name",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1167,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1177,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1162,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Phone Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1184,
                        columnNumber: 40
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1183,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_phone_number",
                        value: formData.co_applicant_phone_number,
                        onChange: handleChange,
                        placeholder: "Enter Phone Number",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1186,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_phone_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1196,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1182,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1161,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Select Customer Relationship" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1206,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Customer Relationship",
                        showSearch: true,
                        name: "co_applicant_relationship_type",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData.co_applicant_relationship_type || void 0,
                        onChange: (value) => handleAntDSelect(
                          "co_applicant_relationship_type",
                          value
                        ),
                        children: ["Father", "Spouse", "Other"].map(
                          (rel) => /* @__PURE__ */ jsxDEV(Select.Option, { value: rel, children: rel }, rel, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 1230,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1209,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_relationship_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_relationship_type }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1236,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1205,
                    columnNumber: 23
                  }, this),
                  formData.co_applicant_relationship_type === "Other" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Please specify the relationship:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1244,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5",
                        placeholder: "Enter custom relationship",
                        value: customRelationship,
                        onChange: (e) => setCustomRelationship(e.target.value)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1247,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1243,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1204,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Email" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1263,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "email",
                        name: "co_applicant_email",
                        value: formData.co_applicant_email,
                        onChange: handleChange,
                        placeholder: "Enter Email",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1266,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_email }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1276,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1262,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Date of Birth" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1282,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "date",
                        name: "co_applicant_dateofbirth",
                        value: formData.co_applicant_dateofbirth ? new Date(formData.co_applicant_dateofbirth).toISOString().split("T")[0] : "",
                        onChange: handleChange,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1285,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1281,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1261,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Marital Status" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1304,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Marital Status",
                        showSearch: true,
                        name: "co_applicant_marital_status",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData.co_applicant_marital_status || void 0,
                        onChange: (value) => handleAntDSelect(
                          "co_applicant_marital_status",
                          value
                        ),
                        children: ["Married", "Unmarried", "Widow", "Divorced"].map(
                          (status) => /* @__PURE__ */ jsxDEV(Select.Option, { value: status, children: status }, status, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 1329,
                            columnNumber: 27
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1307,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1303,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Gender" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1337,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Gender",
                        showSearch: true,
                        name: "co_applicant_gender",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData.co_applicant_gender || void 0,
                        onChange: (value) => handleAntDSelect("co_applicant_gender", value),
                        children: ["Male", "Female"].map(
                          (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g, children: g }, g, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 1356,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1340,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1336,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1302,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Address ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1367,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1366,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      name: "co_applicant_address",
                      value: formData.co_applicant_address,
                      onChange: handleChange,
                      placeholder: "Enter the Address",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1369,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.co_applicant_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_address }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1379,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1365,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Village" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1388,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_village",
                        value: formData.co_applicant_village,
                        onChange: handleChange,
                        placeholder: "Enter Village",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1391,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1387,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Taluk" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1401,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_taluk",
                        value: formData.co_applicant_taluk,
                        onChange: handleChange,
                        placeholder: "Enter Taluk",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1404,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1400,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1386,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "State" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1418,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select State",
                        showSearch: true,
                        name: "co_applicant_state",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData.co_applicant_state || void 0,
                        onChange: (value) => handleAntDSelect("co_applicant_state", value),
                        children: ["Karnataka", "Maharashtra", "Tamil Nadu"].map(
                          (state) => /* @__PURE__ */ jsxDEV(Select.Option, { value: state, children: state }, state, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 1438,
                            columnNumber: 27
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1421,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1417,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "District" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1446,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_district",
                        value: formData.co_applicant_district,
                        onChange: handleChange,
                        placeholder: "Enter District",
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1449,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1445,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1416,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Pincode ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1464,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1463,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_pincode",
                        value: formData.co_applicant_pincode,
                        onChange: handleChange,
                        placeholder: "Enter Pincode",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1466,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_pincode }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1476,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1462,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Father Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1482,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_father_name",
                        value: formData.co_applicant_father_name,
                        onChange: handleChange,
                        placeholder: "Enter Father Name",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1485,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1481,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1461,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Nationality" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1499,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Nationality",
                        showSearch: true,
                        name: "co_applicant_nationality",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: formData.co_applicant_nationality || void 0,
                        onChange: (value) => handleAntDSelect("co_applicant_nationality", value),
                        children: ["Indian", "Other"].map(
                          (nation) => /* @__PURE__ */ jsxDEV(Select.Option, { value: nation, children: nation }, nation, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 1518,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1502,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1498,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Alternate Phone Number" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1525,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_alternate_number",
                        value: formData.co_applicant_alternate_number,
                        onChange: handleChange,
                        placeholder: "Enter Alternate Number",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1528,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1524,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1497,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 1155,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "KYC Documents" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1542,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Aadhaar Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1550,
                        columnNumber: 42
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1549,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_adhaar_no",
                        value: formData.co_applicant_adhaar_no,
                        onChange: handleChange,
                        placeholder: "Enter Aadhaar Number",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1552,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_adhaar_no }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1562,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1548,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "PAN Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1569,
                        columnNumber: 38
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1568,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_pan_no",
                        value: formData.co_applicant_pan_no,
                        onChange: handleChange,
                        placeholder: "Enter PAN Number",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1571,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_pan_no }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1581,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1567,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1547,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Profile Photo ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1590,
                      columnNumber: 39
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1589,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex gap-6 items-start", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        htmlFor: "co_applicant_photo",
                        className: "flex flex-col justify-center items-center w-56 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition",
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            "svg",
                            {
                              className: "w-8 h-8 mb-2 text-gray-400",
                              fill: "none",
                              stroke: "currentColor",
                              viewBox: "0 0 24 24",
                              children: /* @__PURE__ */ jsxDEV(
                                "path",
                                {
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: 2,
                                  d: "M7 16V4a1 1 0 011-1h8a1 1 0 011 1v12m-5 4h.01"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                  lineNumber: 1605,
                                  columnNumber: 29
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 1599,
                              columnNumber: 27
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
                            "Click to upload ",
                            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 1613,
                              columnNumber: 45
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "(PNG, JPG)" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 1614,
                              columnNumber: 29
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 1612,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              id: "co_applicant_photo",
                              type: "file",
                              name: "co_applicant_photo",
                              onChange: handleFileChange,
                              accept: "image/*",
                              required: true,
                              className: "hidden"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 1617,
                              columnNumber: 27
                            },
                            this
                          )
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1595,
                        columnNumber: 25
                      },
                      this
                    ),
                    formData.co_applicant_photo_preview ? /* @__PURE__ */ jsxDEV(Link, { to: formData.co_applicant_photo, download: true, children: /* @__PURE__ */ jsxDEV(
                      "img",
                      {
                        src: formData.co_applicant_photo_preview,
                        alt: "Profile Preview",
                        className: "w-40 h-40 object-cover rounded-lg border shadow-sm"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1631,
                        columnNumber: 29
                      },
                      this
                    ) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1630,
                      columnNumber: 23
                    }, this) : /* @__PURE__ */ jsxDEV("div", { className: "w-40 h-40 flex items-center justify-center border rounded-lg text-gray-400 text-sm", children: "No Preview" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1638,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1593,
                    columnNumber: 23
                  }, this),
                  errors.co_applicant_photo && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_photo }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1646,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1588,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "PAN Card Photo ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1655,
                        columnNumber: 42
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1654,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-6 items-start", children: [
                      /* @__PURE__ */ jsxDEV(
                        "label",
                        {
                          htmlFor: "co_applicant_pan_document",
                          className: "flex flex-col justify-center items-center w-56 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition",
                          children: [
                            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
                              "Click to upload ",
                              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 1664,
                                columnNumber: 47
                              }, this),
                              /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "(PNG, JPG)" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 1665,
                                columnNumber: 31
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 1663,
                              columnNumber: 29
                            }, this),
                            /* @__PURE__ */ jsxDEV(
                              "input",
                              {
                                id: "co_applicant_pan_document",
                                type: "file",
                                name: "co_applicant_pan_document",
                                onChange: handleFileChange,
                                accept: "image/*",
                                required: true,
                                className: "hidden"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 1668,
                                columnNumber: 29
                              },
                              this
                            )
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 1659,
                          columnNumber: 27
                        },
                        this
                      ),
                      formData.co_applicant_pan_document_preview ? /* @__PURE__ */ jsxDEV(
                        Link,
                        {
                          to: formData.co_applicant_pan_document,
                          download: true,
                          children: /* @__PURE__ */ jsxDEV(
                            "img",
                            {
                              src: formData.co_applicant_pan_document_preview,
                              className: "w-40 h-40 object-cover rounded-lg border shadow-sm"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 1684,
                              columnNumber: 31
                            },
                            this
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 1680,
                          columnNumber: 25
                        },
                        this
                      ) : /* @__PURE__ */ jsxDEV("div", { className: "w-40 h-40 flex items-center justify-center border rounded-lg text-gray-400 text-sm", children: "No Preview" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1690,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1658,
                      columnNumber: 25
                    }, this),
                    errors.co_applicant_pan_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_pan_document }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1697,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1653,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Aadhaar Card Photo",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1705,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1703,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-6 items-start", children: [
                      /* @__PURE__ */ jsxDEV(
                        "label",
                        {
                          htmlFor: "co_applicant_aadhar_document",
                          className: "flex flex-col justify-center items-center w-56 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition",
                          children: [
                            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
                              "Click to upload ",
                              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 1714,
                                columnNumber: 47
                              }, this),
                              /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "(PNG, JPG)" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 1715,
                                columnNumber: 31
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 1713,
                              columnNumber: 29
                            }, this),
                            /* @__PURE__ */ jsxDEV(
                              "input",
                              {
                                id: "co_applicant_aadhar_document",
                                type: "file",
                                name: "co_applicant_aadhar_document",
                                onChange: handleFileChange,
                                accept: "image/*",
                                required: true,
                                className: "hidden"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 1718,
                                columnNumber: 29
                              },
                              this
                            )
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 1709,
                          columnNumber: 27
                        },
                        this
                      ),
                      formData.co_applicant_aadhar_document_preview ? /* @__PURE__ */ jsxDEV(
                        Link,
                        {
                          to: formData.co_applicant_aadhar_document,
                          download: true,
                          children: /* @__PURE__ */ jsxDEV(
                            "img",
                            {
                              src: formData.co_applicant_aadhar_document_preview,
                              className: "w-40 h-40 object-cover rounded-lg border shadow-sm"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 1734,
                              columnNumber: 31
                            },
                            this
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 1730,
                          columnNumber: 25
                        },
                        this
                      ) : /* @__PURE__ */ jsxDEV("div", { className: "w-40 h-40 flex items-center justify-center border rounded-lg text-gray-400 text-sm", children: "No Preview" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1742,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1708,
                      columnNumber: 25
                    }, this),
                    errors.co_applicant_aadhar_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_aadhar_document }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1749,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1702,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1652,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold mb-2", children: "Additional Documents" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1758,
                    columnNumber: 23
                  }, this),
                  extraDocs.map(
                    (doc, index) => /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "mb-6 p-3 border border-gray-200 rounded-lg bg-gray-50",
                        children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-4", children: [
                            /* @__PURE__ */ jsxDEV(
                              Input,
                              {
                                type: "text",
                                placeholder: "Document Name (e.g. Passport, Voter ID)",
                                value: doc.document_name,
                                onChange: (e) => handleExtraDocNameChange(index, e),
                                className: "w-1/2 h-12 border border-gray-300 rounded-lg p-2"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 1768,
                                columnNumber: 29
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              "input",
                              {
                                type: "file",
                                name: "co_applicant_all_document",
                                onChange: (e) => handleExtraDocFileChange(index, e),
                                accept: "image/*",
                                className: "w-1/2 h-12 border border-gray-300 rounded-lg"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 1777,
                                columnNumber: 29
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              "button",
                              {
                                type: "button",
                                onClick: () => removeDocField(index),
                                className: "text-violet-600 font-bold text-xl",
                                children: /* @__PURE__ */ jsxDEV(IoMdClose, {}, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                  lineNumber: 1791,
                                  columnNumber: 31
                                }, this)
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 1786,
                                columnNumber: 29
                              },
                              this
                            )
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 1767,
                            columnNumber: 27
                          }, this),
                          doc.preview && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: /* @__PURE__ */ jsxDEV(
                            "img",
                            {
                              src: doc.preview,
                              alt: doc.document_name,
                              className: "w-56 h-56 object-cover rounded-md shadow"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 1798,
                              columnNumber: 31
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 1797,
                            columnNumber: 23
                          }, this)
                        ]
                      },
                      index,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1762,
                        columnNumber: 21
                      },
                      this
                    )
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: addNewDocField,
                      className: "mt-2 px-2 py-1 bg-violet-600 text-white rounded-lg shadow hover:bg-violet-700",
                      children: "+ Add Document"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1808,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1757,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 1541,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "Occupation Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1819,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Co Applicant Occupation" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1826,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      placeholder: "Select Occupation",
                      showSearch: true,
                      value: formData.co_applicant_occupation || void 0,
                      onChange: (value) => {
                        setFormData((prev) => ({
                          ...prev,
                          co_applicant_occupation: value,
                          co_applicant_occupation_sub: "",
                          co_applicant_bussiness_type: "",
                          co_applicant_bussiness_name: "",
                          co_applicant_bussiness_address: "",
                          co_applicant_profession_type: "",
                          co_applicant_agri_rtc_no: "",
                          co_applicant_land_holdings: ""
                        }));
                      },
                      filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                      children: [
                        "Self Employed",
                        "Salaried",
                        "Professional",
                        "Agri Allied",
                        "Other"
                      ].map(
                        (occ) => /* @__PURE__ */ jsxDEV(Select.Option, { value: occ, children: occ }, occ, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 1863,
                          columnNumber: 25
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1831,
                      columnNumber: 25
                    },
                    this
                  ),
                  errors.co_applicant_occupation && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_occupation }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1869,
                    columnNumber: 23
                  }, this),
                  formData.co_applicant_occupation === "Other" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-4 w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Please specify Occupation:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1877,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Select,
                        {
                          className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                          placeholder: "Select Sub-Category",
                          showSearch: true,
                          value: formData.co_applicant_occupation_sub || void 0,
                          onChange: (value) => setFormData((prev) => ({
                            ...prev,
                            co_applicant_occupation_sub: value
                          })),
                          filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                          children: [
                            "House Wife",
                            "Retired",
                            "Student",
                            "Investment",
                            "Running an unregistered Business"
                          ].map(
                            (sub) => /* @__PURE__ */ jsxDEV(Select.Option, { value: sub, children: sub }, sub, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 1907,
                              columnNumber: 29
                            }, this)
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 1880,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_occupation_sub && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_occupation_sub }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1913,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1876,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1919,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_bussiness_address",
                          value: formData.co_applicant_bussiness_address,
                          onChange: handleChange,
                          placeholder: "Enter  Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 1922,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1931,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1918,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1875,
                    columnNumber: 23
                  }, this),
                  ["Self Employed", "Salaried"].includes(
                    formData.co_applicant_occupation
                  ) && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Business Type" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1945,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_bussiness_type",
                          value: formData.co_applicant_bussiness_type,
                          onChange: handleChange,
                          placeholder: "e.g., Retail, Manufacturing",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 1948,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_bussiness_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_type }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1957,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1944,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Business Name" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1963,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_bussiness_name",
                          value: formData.co_applicant_bussiness_name,
                          onChange: handleChange,
                          placeholder: "Enter Business Name",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 1966,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_bussiness_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_name }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1975,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1962,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1981,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_bussiness_address",
                          value: formData.co_applicant_bussiness_address,
                          onChange: handleChange,
                          placeholder: "Enter Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 1984,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 1993,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 1980,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 1943,
                    columnNumber: 23
                  }, this),
                  formData.co_applicant_occupation === "Professional" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Profession Type" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2006,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_profession_type",
                          value: formData.co_applicant_profession_type,
                          onChange: handleChange,
                          placeholder: "e.g., Doctor, CA, Engineer",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 2009,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_profession_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_profession_type }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2018,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2005,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2024,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_bussiness_address",
                          value: formData.co_applicant_bussiness_address,
                          onChange: handleChange,
                          placeholder: "Clinic/Office Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 2027,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2036,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2023,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2004,
                    columnNumber: 23
                  }, this),
                  formData.co_applicant_occupation === "Agri Allied" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 w-full space-y-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "RTC No / Land Record ID" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2048,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_agri_rtc_no",
                          value: formData.co_applicant_agri_rtc_no,
                          onChange: handleChange,
                          placeholder: "Enter RTC Number",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 2051,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_agri_rtc_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_agri_rtc_no }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2060,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2047,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Land Holdings (in acres)" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2066,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "number",
                          name: "co_applicant_land_holdings",
                          value: formData.co_applicant_land_holdings,
                          onChange: handleChange,
                          placeholder: "e.g., 5.5",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 2069,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_land_holdings && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_land_holdings }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2078,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2065,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2084,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_bussiness_address",
                          value: formData.co_applicant_bussiness_address,
                          onChange: handleChange,
                          placeholder: "Farm or Operation Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 2087,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2096,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2083,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2046,
                    columnNumber: 23
                  }, this),
                  formData.co_applicant_occupation === "Other" && formData.co_applicant_occupation_sub === "Running an unregistered Business" && /* @__PURE__ */ jsxDEV("div", { className: " w-full mt-4", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2109,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_bussiness_address",
                        value: formData.co_applicant_bussiness_address,
                        onChange: handleChange,
                        placeholder: "Enter Address",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2112,
                        columnNumber: 31
                      },
                      this
                    ),
                    errors.co_applicant_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_address }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2121,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2108,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1825,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 1823,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Salary / Income Document",
                    " ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2134,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2132,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex gap-6 items-start", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        htmlFor: "co_applicant_income_document",
                        className: "flex flex-col justify-center items-center w-56 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition",
                        children: [
                          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
                            "Click to upload ",
                            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 2143,
                              columnNumber: 45
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "(PNG, JPG)" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 2144,
                              columnNumber: 29
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 2142,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              id: "co_applicant_income_document",
                              type: "file",
                              name: "co_applicant_income_document",
                              onChange: handleFileChange,
                              accept: "image/*",
                              required: true,
                              className: "hidden"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 2147,
                              columnNumber: 27
                            },
                            this
                          )
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2138,
                        columnNumber: 25
                      },
                      this
                    ),
                    formData.co_applicant_income_document_preview ? /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: formData.co_applicant_income_document,
                        download: true,
                        children: /* @__PURE__ */ jsxDEV(
                          "img",
                          {
                            src: formData.co_applicant_income_document_preview,
                            className: "w-40 h-40 object-cover rounded-lg border shadow-sm"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 2163,
                            columnNumber: 29
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2159,
                        columnNumber: 23
                      },
                      this
                    ) : /* @__PURE__ */ jsxDEV("div", { className: "w-40 h-40 flex items-center justify-center border rounded-lg text-gray-400 text-sm", children: "No Preview" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2171,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2137,
                    columnNumber: 23
                  }, this),
                  errors.co_applicant_income_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_income_document }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2178,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2131,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 1818,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "Bank Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2187,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2193,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_bank_name",
                        value: formData.co_applicant_bank_name,
                        onChange: handleChange,
                        placeholder: "Enter Bank Name",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2196,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_bank_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bank_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2205,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2192,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank Account Number" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2211,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_bank_account_number",
                        value: formData.co_applicant_bank_account_number,
                        onChange: handleChange,
                        placeholder: "Enter Account Number",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2214,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_bank_account_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bank_account_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2223,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2210,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2191,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank Branch" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2232,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_bank_branch",
                        value: formData.co_applicant_bank_branch,
                        onChange: handleChange,
                        placeholder: "Enter Branch",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2235,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_bank_branch && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bank_branch }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2244,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2231,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank IFSC Code" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2250,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_bank_ifsc_code",
                        value: formData.co_applicant_bank_ifsc_code,
                        onChange: handleChange,
                        placeholder: "Enter IFSC Code",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2253,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_bank_ifsc_code && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bank_ifsc_code }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2262,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2249,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2230,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Bank Passbook ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2271,
                      columnNumber: 39
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2270,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex gap-6 items-start", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        htmlFor: "co_applicant_bank_passbook_photo",
                        className: "flex flex-col justify-center items-center w-56 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition",
                        children: [
                          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
                            "Click to upload ",
                            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 2280,
                              columnNumber: 45
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "(PNG, JPG)" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 2281,
                              columnNumber: 29
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 2279,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              id: "co_applicant_bank_passbook_photo",
                              type: "file",
                              name: "co_applicant_bank_passbook_photo",
                              onChange: handleFileChange,
                              accept: "image/*",
                              required: true,
                              className: "hidden"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 2284,
                              columnNumber: 27
                            },
                            this
                          )
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2275,
                        columnNumber: 25
                      },
                      this
                    ),
                    formData.co_applicant_bank_passbook_photo_preview ? /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: formData.co_applicant_bank_passbook_photo,
                        download: true,
                        children: /* @__PURE__ */ jsxDEV(
                          "img",
                          {
                            src: formData.co_applicant_bank_passbook_photo_preview,
                            className: "w-40 h-40 object-cover rounded-lg border shadow-sm"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 2300,
                            columnNumber: 29
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2296,
                        columnNumber: 23
                      },
                      this
                    ) : /* @__PURE__ */ jsxDEV("div", { className: "w-40 h-40 flex items-center justify-center border rounded-lg text-gray-400 text-sm", children: "No Preview" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2308,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2274,
                    columnNumber: 23
                  }, this),
                  errors.co_applicant_bank_passbook_photo && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bank_passbook_photo }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2315,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2269,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2186,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 1153,
              columnNumber: 15
            }, this),
            formData.co_applicant_referred_type === "Property" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "email",
                    children: [
                      "Property Name ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2330,
                        columnNumber: 37
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2326,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "co_applicant_document_name",
                    value: formData.co_applicant_document_name,
                    onChange: handleChange,
                    id: "name",
                    placeholder: "Enter the Description",
                    required: true,
                    className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2332,
                    columnNumber: 21
                  },
                  this
                ),
                errors.co_applicant_document_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_document_name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2343,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2325,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Property Document ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2350,
                    columnNumber: 41
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2349,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex gap-6 items-start", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      htmlFor: "co_applicant_document",
                      className: "flex flex-col justify-center items-center w-56 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition",
                      children: [
                        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
                          "Click to upload ",
                          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 2359,
                            columnNumber: 43
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "(PNG, JPG)" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 2360,
                            columnNumber: 27
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 2358,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            id: "co_applicant_document",
                            type: "file",
                            name: "co_applicant_document",
                            onChange: handleFileChange,
                            accept: "image/*",
                            required: true,
                            className: "hidden"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 2363,
                            columnNumber: 25
                          },
                          this
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2354,
                      columnNumber: 23
                    },
                    this
                  ),
                  formData.co_applicant_document_preview ? /* @__PURE__ */ jsxDEV(Link, { to: formData.co_applicant_document, download: true, children: /* @__PURE__ */ jsxDEV(
                    "img",
                    {
                      src: formData.co_applicant_document_preview,
                      className: "w-40 h-40 object-cover rounded-lg border shadow-sm"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2376,
                      columnNumber: 27
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2375,
                    columnNumber: 21
                  }, this) : /* @__PURE__ */ jsxDEV("div", { className: "w-40 h-40 flex items-center justify-center border rounded-lg text-gray-400 text-sm", children: "No Preview" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2382,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2353,
                  columnNumber: 21
                }, this),
                errors.co_applicant_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_document }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2389,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2348,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "email",
                    children: [
                      "Description ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2399,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2395,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "co_applicant_description",
                    value: formData.co_applicant_description,
                    onChange: handleChange,
                    id: "name",
                    placeholder: "Enter the Description",
                    required: true,
                    className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2401,
                    columnNumber: 21
                  },
                  this
                ),
                errors.co_applicant_description && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_description }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2412,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2394,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 2324,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Save Co Applicant"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2421,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 2420,
              columnNumber: 15
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
          lineNumber: 957,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
      lineNumber: 953,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
      lineNumber: 952,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Co Applicant" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
            lineNumber: 2437,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Customer Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2443,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2442,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Or Search Customer",
                  showSearch: true,
                  value: updateFormData.user_id || "",
                  onChange: (value) => {
                    setUpdateFormData((prev) => ({
                      ...prev,
                      user_id: value,
                      enrollment_ids: []
                      // reset selected enrollments
                    }));
                    const filtered = enrollment.filter((e) => e.user_id?._id === value).map((e) => ({
                      _id: e._id,
                      group_name: e.group_id?.group_name,
                      ticket: e.tickets
                    }));
                    setFilteredEnrollments(filtered);
                  },
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  children: enrollment.filter((e) => e.user_id && e.user_id.full_name?.trim()).map(
                    (e) => /* @__PURE__ */ jsxDEV(Select.Option, { value: e.user_id._id, children: e.user_id.full_name }, e.user_id._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2474,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2445,
                  columnNumber: 17
                },
                this
              ),
              errors.user_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.user_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2480,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 2441,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Select Enrollment ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2485,
                  columnNumber: 37
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2484,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "tags",
                  allowClear: true,
                  placeholder: "Select enrollments",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  value: updateFormData.enrollment_ids,
                  onChange: (selectedEnrollmentIds) => {
                    setUpdateFormData((prev) => ({
                      ...prev,
                      enrollment_ids: selectedEnrollmentIds
                    }));
                  },
                  filterOption: (input, option) => option?.label?.toLowerCase().includes(input.toLowerCase()),
                  children: filteredEnrollments.map((en) => {
                    const parts = [];
                    if (en.group_name && en.group_name !== "N/A")
                      parts.push(en.group_name);
                    if (en.ticket && en.ticket !== "N/A")
                      parts.push(`Ticket: ${en.ticket}`);
                    return /* @__PURE__ */ jsxDEV(Select.Option, { value: en._id, children: parts.join(" | ") }, en._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2510,
                      columnNumber: 23
                    }, this);
                  })
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2487,
                  columnNumber: 17
                },
                this
              ),
              errors.enrollment_ids && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.enrollment_ids }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2517,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 2483,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "referred_type",
                  children: [
                    "Select Referred Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2528,
                      columnNumber: 40
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2524,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Referred Type",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "co_applicant_referred_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.co_applicant_referred_type || void 0,
                  onChange: (value) => handleAntInputDSelect("co_applicant_referred_type", value),
                  children: ["Customer", "Third Party", "Property"].map(
                    (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2547,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2530,
                  columnNumber: 17
                },
                this
              ),
              errors.co_applicant_referred_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_referred_type }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2553,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 2523,
              columnNumber: 15
            }, this),
            updateFormData.co_applicant_referred_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full mb-4", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Select Co Applicant Customer",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2567,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2562,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                    placeholder: "Select Or Search Referred Customer",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "user_co_applicant",
                    filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                    value: updateFormData?.user_co_applicant || void 0,
                    onChange: (value) => handleAntInputDSelect("user_co_applicant", value),
                    children: users.map(
                      (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: user.full_name }, user._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2588,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2570,
                    columnNumber: 21
                  },
                  this
                ),
                errors.user_co_applicant && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.user_co_applicant }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2594,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2561,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "email",
                    children: [
                      "Description ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2604,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2600,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "co_applicant_description",
                    value: updateFormData.co_applicant_description,
                    onChange: handleInputChange,
                    id: "name",
                    placeholder: "Enter the Description",
                    required: true,
                    className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2606,
                    columnNumber: 21
                  },
                  this
                ),
                errors.co_applicant_description && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_description }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2617,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2599,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 2560,
              columnNumber: 15
            }, this),
            updateFormData.co_applicant_referred_type === "Third Party" && /* @__PURE__ */ jsxDEV("div", { className: "space-y-6 mt-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "Personal Information" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2628,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Co Applicant Name",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2636,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2634,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_name",
                        value: updateFormData.co_applicant_name,
                        onChange: handleInputChange,
                        placeholder: "Enter Co Applicant Name",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2638,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2648,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2633,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Phone Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2656,
                        columnNumber: 40
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2655,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_phone_number",
                        value: updateFormData.co_applicant_phone_number,
                        onChange: handleInputChange,
                        placeholder: "Enter Phone Number",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2658,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_phone_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2668,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2654,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2632,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Select Customer Relationship" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2678,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Customer Relationship",
                        showSearch: true,
                        name: "co_applicant_relationship_type",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData.co_applicant_relationship_type || void 0,
                        onChange: (value) => handleAntInputDSelect(
                          "co_applicant_relationship_type",
                          value
                        ),
                        children: ["Father", "Spouse", "Other"].map(
                          (rel) => /* @__PURE__ */ jsxDEV(Select.Option, { value: rel, children: rel }, rel, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 2703,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2681,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_relationship_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_relationship_type }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2709,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2677,
                    columnNumber: 23
                  }, this),
                  updateFormData.co_applicant_relationship_type === "Other" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Please specify the relationship:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2718,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        type: "text",
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5",
                        placeholder: "Enter custom relationship",
                        value: customRelationship,
                        onChange: (e) => setCustomRelationship(e.target.value)
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2721,
                        columnNumber: 27
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2717,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2676,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Email" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2737,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "email",
                        name: "co_applicant_email",
                        value: updateFormData.co_applicant_email,
                        onChange: handleInputChange,
                        placeholder: "Enter Email",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2740,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_email }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2750,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2736,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Date of Birth" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2756,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "date",
                        name: "co_applicant_dateofbirth",
                        value: updateFormData.co_applicant_dateofbirth ? new Date(
                          updateFormData.co_applicant_dateofbirth
                        ).toISOString().split("T")[0] : "",
                        onChange: handleInputChange,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2759,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2755,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2735,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Marital Status" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2780,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Marital Status",
                        showSearch: true,
                        name: "co_applicant_marital_status",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData.co_applicant_marital_status || void 0,
                        onChange: (value) => handleAntInputDSelect(
                          "co_applicant_marital_status",
                          value
                        ),
                        children: ["Married", "Unmarried", "Widow", "Divorced"].map(
                          (status) => /* @__PURE__ */ jsxDEV(Select.Option, { value: status, children: status }, status, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 2806,
                            columnNumber: 27
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2783,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2779,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Gender" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2814,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Gender",
                        showSearch: true,
                        name: "co_applicant_gender",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData.co_applicant_gender || void 0,
                        onChange: (value) => handleAntInputDSelect("co_applicant_gender", value),
                        children: ["Male", "Female"].map(
                          (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g, children: g }, g, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 2835,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2817,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2813,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2778,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                    "Address ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2846,
                      columnNumber: 33
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2845,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      name: "co_applicant_address",
                      value: updateFormData.co_applicant_address,
                      onChange: handleInputChange,
                      placeholder: "Enter the Address",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2848,
                      columnNumber: 23
                    },
                    this
                  ),
                  errors.co_applicant_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_address }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2858,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2844,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Village" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2867,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_village",
                        value: updateFormData.co_applicant_village,
                        onChange: handleInputChange,
                        placeholder: "Enter Village",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2870,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2866,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Taluk" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2880,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_taluk",
                        value: updateFormData.co_applicant_taluk,
                        onChange: handleInputChange,
                        placeholder: "Enter Taluk",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2883,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2879,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2865,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "State" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2897,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select State",
                        showSearch: true,
                        name: "co_applicant_state",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData.co_applicant_state || void 0,
                        onChange: (value) => handleAntInputDSelect("co_applicant_state", value),
                        children: ["Karnataka", "Maharashtra", "Tamil Nadu"].map(
                          (state) => /* @__PURE__ */ jsxDEV(Select.Option, { value: state, children: state }, state, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 2917,
                            columnNumber: 27
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2900,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2896,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "District" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2925,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_district",
                        value: updateFormData.co_applicant_district,
                        onChange: handleInputChange,
                        placeholder: "Enter District",
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2928,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2924,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2895,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Pincode ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2943,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2942,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_pincode",
                        value: updateFormData.co_applicant_pincode,
                        onChange: handleInputChange,
                        placeholder: "Enter Pincode",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2945,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_pincode }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2955,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2941,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Father Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2961,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_father_name",
                        value: updateFormData.co_applicant_father_name,
                        onChange: handleInputChange,
                        placeholder: "Enter Father Name",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2964,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2960,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2940,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Nationality" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 2978,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                        placeholder: "Select Nationality",
                        showSearch: true,
                        name: "co_applicant_nationality",
                        filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                        value: updateFormData.co_applicant_nationality || void 0,
                        onChange: (value) => handleAntInputDSelect(
                          "co_applicant_nationality",
                          value
                        ),
                        children: ["Indian", "Other"].map(
                          (nation) => /* @__PURE__ */ jsxDEV(Select.Option, { value: nation, children: nation }, nation, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3002,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 2981,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 2977,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Alternate Phone Number" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3009,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_alternate_number",
                        value: updateFormData.co_applicant_alternate_number,
                        onChange: handleInputChange,
                        placeholder: "Enter Alternate Number",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3012,
                        columnNumber: 25
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3008,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 2976,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 2627,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "KYC Documents" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3026,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Aadhaar Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3034,
                        columnNumber: 42
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3033,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_adhaar_no",
                        value: updateFormData.co_applicant_adhaar_no,
                        onChange: handleInputChange,
                        placeholder: "Enter Aadhaar Number",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3036,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_adhaar_no }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3046,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3032,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "PAN Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3053,
                        columnNumber: 38
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3052,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_pan_no",
                        value: updateFormData.co_applicant_pan_no,
                        onChange: handleInputChange,
                        placeholder: "Enter PAN Number",
                        required: true,
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3055,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_pan_no }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3065,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3051,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3031,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Profile Photo ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3076,
                        columnNumber: 39
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3075,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        htmlFor: "co_applicant_photo",
                        className: "flex flex-col justify-center items-center w-56 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition",
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            "svg",
                            {
                              className: "w-8 h-8 mb-2 text-gray-400",
                              fill: "none",
                              stroke: "currentColor",
                              viewBox: "0 0 24 24",
                              children: /* @__PURE__ */ jsxDEV(
                                "path",
                                {
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: 2,
                                  d: "M7 16V4a1 1 0 011-1h8a1 1 0 011 1v12m-5 4h.01"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                  lineNumber: 3088,
                                  columnNumber: 29
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3082,
                              columnNumber: 27
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
                            "Click to upload ",
                            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3096,
                              columnNumber: 45
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "(PNG, JPG)" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3097,
                              columnNumber: 29
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3095,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              id: "co_applicant_photo",
                              type: "file",
                              name: "co_applicant_photo",
                              onChange: handleInputFileChange,
                              accept: "image/*",
                              required: true,
                              className: "hidden"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3100,
                              columnNumber: 27
                            },
                            this
                          )
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3078,
                        columnNumber: 23
                      },
                      this
                    ),
                    errors.co_applicant_photo && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_photo }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3111,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3074,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: updateFormData.co_applicant_photo && /* @__PURE__ */ jsxDEV(Link, { to: updateFormData.co_applicant_photo, download: true, children: /* @__PURE__ */ jsxDEV(
                    "img",
                    {
                      src: updateFormData.co_applicant_photo,
                      alt: "Profile",
                      className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3119,
                      columnNumber: 27
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3118,
                    columnNumber: 23
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3116,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3073,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "PAN Card Photo ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3133,
                        columnNumber: 42
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3132,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        htmlFor: "co_applicant_pan_document",
                        className: "flex flex-col justify-center items-center w-56 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition",
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            "svg",
                            {
                              className: "w-8 h-8 mb-2 text-gray-400",
                              fill: "none",
                              stroke: "currentColor",
                              viewBox: "0 0 24 24",
                              children: /* @__PURE__ */ jsxDEV(
                                "path",
                                {
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: 2,
                                  d: "M7 16V4a1 1 0 011-1h8a1 1 0 011 1v12m-5 4h.01"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                  lineNumber: 3145,
                                  columnNumber: 29
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3139,
                              columnNumber: 27
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
                            "Click to upload ",
                            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3153,
                              columnNumber: 45
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "(PNG, JPG)" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3154,
                              columnNumber: 29
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3152,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              id: "co_applicant_pan_document",
                              type: "file",
                              name: "co_applicant_pan_document",
                              onChange: handleInputFileChange,
                              accept: "image/*",
                              required: true,
                              className: "hidden"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3157,
                              columnNumber: 27
                            },
                            this
                          )
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3135,
                        columnNumber: 24
                      },
                      this
                    ),
                    errors.co_applicant_pan_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_pan_document }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3168,
                      columnNumber: 23
                    }, this),
                    updateFormData.co_applicant_pan_document && /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: updateFormData.co_applicant_pan_document,
                        download: true,
                        children: /* @__PURE__ */ jsxDEV(
                          "img",
                          {
                            src: updateFormData.co_applicant_pan_document,
                            alt: "PAN",
                            className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3177,
                            columnNumber: 29
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3173,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3131,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Aadhaar Card Photo",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3188,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3186,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        htmlFor: "co_applicant_aadhar_document",
                        className: "flex flex-col justify-center items-center w-56 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition",
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            "svg",
                            {
                              className: "w-8 h-8 mb-2 text-gray-400",
                              fill: "none",
                              stroke: "currentColor",
                              viewBox: "0 0 24 24",
                              children: /* @__PURE__ */ jsxDEV(
                                "path",
                                {
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: 2,
                                  d: "M7 16V4a1 1 0 011-1h8a1 1 0 011 1v12m-5 4h.01"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                  lineNumber: 3200,
                                  columnNumber: 29
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3194,
                              columnNumber: 27
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
                            "Click to upload ",
                            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3208,
                              columnNumber: 45
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "(PNG, JPG)" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3209,
                              columnNumber: 29
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3207,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              id: "co_applicant_aadhar_document",
                              type: "file",
                              name: "co_applicant_aadhar_document",
                              onChange: handleInputFileChange,
                              accept: "image/*",
                              required: true,
                              className: "hidden"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3212,
                              columnNumber: 27
                            },
                            this
                          )
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3190,
                        columnNumber: 24
                      },
                      this
                    ),
                    errors.co_applicant_aadhar_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_aadhar_document }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3223,
                      columnNumber: 23
                    }, this),
                    updateFormData.co_applicant_aadhar_document && /* @__PURE__ */ jsxDEV(
                      Link,
                      {
                        to: updateFormData.co_applicant_aadhar_document,
                        download: true,
                        children: /* @__PURE__ */ jsxDEV(
                          "img",
                          {
                            src: updateFormData.co_applicant_aadhar_document,
                            alt: "",
                            className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3232,
                            columnNumber: 29
                          },
                          this
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3228,
                        columnNumber: 23
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3185,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3130,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-6", children: [
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold mb-2", children: "Additional Documents" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3244,
                    columnNumber: 23
                  }, this),
                  extraDocs.map(
                    (doc, index) => /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "mb-6 p-3 border border-gray-200 rounded-lg bg-gray-50",
                        children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-4", children: [
                            /* @__PURE__ */ jsxDEV(
                              Input,
                              {
                                type: "text",
                                placeholder: "Document Name (e.g. Passport, Voter ID)",
                                value: doc.document_name,
                                onChange: (e) => handleExtraDocNameChange(index, e),
                                className: "w-1/2 h-12 border border-gray-300 rounded-lg p-2"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 3254,
                                columnNumber: 29
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              "input",
                              {
                                type: "file",
                                name: "co_applicant_all_document",
                                onChange: (e) => handleExtraDocFileChange(index, e),
                                accept: "image/*",
                                className: "w-1/2 h-12 border border-gray-300 rounded-lg"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 3263,
                                columnNumber: 29
                              },
                              this
                            ),
                            /* @__PURE__ */ jsxDEV(
                              "button",
                              {
                                type: "button",
                                onClick: () => removeDocField(index),
                                className: "text-violet-600 font-bold text-xl",
                                children: /* @__PURE__ */ jsxDEV(IoMdClose, {}, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                  lineNumber: 3277,
                                  columnNumber: 31
                                }, this)
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 3272,
                                columnNumber: 29
                              },
                              this
                            )
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3253,
                            columnNumber: 27
                          }, this),
                          doc.preview && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: /* @__PURE__ */ jsxDEV(
                            "img",
                            {
                              src: doc.preview,
                              alt: doc.document_name,
                              className: "w-56 h-56 object-cover rounded-md shadow"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3284,
                              columnNumber: 31
                            },
                            this
                          ) }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3283,
                            columnNumber: 23
                          }, this)
                        ]
                      },
                      index,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3248,
                        columnNumber: 21
                      },
                      this
                    )
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "button",
                      onClick: addNewDocField,
                      className: "mt-2 px-2 py-1 bg-violet-600 text-white rounded-lg shadow hover:bg-violet-700",
                      children: "+ Add Document"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3294,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3243,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 3025,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "Occupation Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3305,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Co Applicant Occupation" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3312,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    Select,
                    {
                      className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                      placeholder: "Select Occupation",
                      showSearch: true,
                      value: updateFormData.co_applicant_occupation || void 0,
                      onChange: (value) => {
                        setUpdateFormData((prev) => ({
                          ...prev,
                          co_applicant_occupation: value,
                          co_applicant_occupation_sub: "",
                          co_applicant_bussiness_type: "",
                          co_applicant_bussiness_name: "",
                          co_applicant_bussiness_address: "",
                          co_applicant_profession_type: "",
                          co_applicant_agri_rtc_no: "",
                          co_applicant_land_holdings: ""
                        }));
                      },
                      filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                      children: [
                        "Self Employed",
                        "Salaried",
                        "Professional",
                        "Agri Allied",
                        "Other"
                      ].map(
                        (occ) => /* @__PURE__ */ jsxDEV(Select.Option, { value: occ, children: occ }, occ, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3351,
                          columnNumber: 25
                        }, this)
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3317,
                      columnNumber: 25
                    },
                    this
                  ),
                  errors.co_applicant_occupation && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_occupation }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3357,
                    columnNumber: 23
                  }, this),
                  updateFormData.co_applicant_occupation === "Other" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "mt-4 w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Please specify Occupation:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3366,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Select,
                        {
                          className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                          placeholder: "Select Sub-Category",
                          showSearch: true,
                          value: updateFormData.co_applicant_occupation_sub || void 0,
                          onChange: (value) => setFormData((prev) => ({
                            ...prev,
                            co_applicant_occupation_sub: value
                          })),
                          filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                          children: [
                            "House Wife",
                            "Retired",
                            "Student",
                            "Investment",
                            "Running an unregistered Business"
                          ].map(
                            (sub) => /* @__PURE__ */ jsxDEV(Select.Option, { value: sub, children: sub }, sub, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3396,
                              columnNumber: 29
                            }, this)
                          )
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3369,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_occupation_sub && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_occupation_sub }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3402,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3365,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3408,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_bussiness_address",
                          value: updateFormData.co_applicant_bussiness_address,
                          onChange: handleInputChange,
                          placeholder: "Enter Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3411,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3422,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3407,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3364,
                    columnNumber: 23
                  }, this),
                  ["Self Employed", "Salaried"].includes(
                    updateFormData.co_applicant_occupation
                  ) && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Business Type" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3436,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_bussiness_type",
                          value: updateFormData.co_applicant_bussiness_type,
                          onChange: handleInputChange,
                          placeholder: "e.g., Retail, Manufacturing",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3439,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_bussiness_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_type }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3450,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3435,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Business Name" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3456,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_bussiness_name",
                          value: updateFormData.co_applicant_bussiness_name,
                          onChange: handleInputChange,
                          placeholder: "Enter Business Name",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3459,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_bussiness_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_name }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3470,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3455,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3476,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_bussiness_address",
                          value: updateFormData.co_applicant_bussiness_address,
                          onChange: handleInputChange,
                          placeholder: "Enter Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3479,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3490,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3475,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3434,
                    columnNumber: 23
                  }, this),
                  updateFormData.co_applicant_occupation === "Professional" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Profession Type" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3503,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_profession_type",
                          value: updateFormData.co_applicant_profession_type,
                          onChange: handleInputChange,
                          placeholder: "e.g., Doctor, CA, Engineer",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3506,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_profession_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_profession_type }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3517,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3502,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3523,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_bussiness_address",
                          value: updateFormData.co_applicant_bussiness_address,
                          onChange: handleInputChange,
                          placeholder: "Clinic/Office Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3526,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3537,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3522,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3501,
                    columnNumber: 23
                  }, this),
                  updateFormData.co_applicant_occupation === "Agri Allied" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 w-full space-y-4", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "RTC No / Land Record ID" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3550,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_agri_rtc_no",
                          value: updateFormData.co_applicant_agri_rtc_no,
                          onChange: handleInputChange,
                          placeholder: "Enter RTC Number",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3553,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_agri_rtc_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_agri_rtc_no }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3562,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3549,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Land Holdings (in acres)" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3568,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "number",
                          name: "co_applicant_land_holdings",
                          value: updateFormData.co_applicant_land_holdings,
                          onChange: handleInputChange,
                          placeholder: "e.g., 5.5",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3571,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_land_holdings && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_land_holdings }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3582,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3567,
                      columnNumber: 29
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                      /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3588,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        Input,
                        {
                          type: "text",
                          name: "co_applicant_bussiness_address",
                          value: updateFormData.co_applicant_bussiness_address,
                          onChange: handleInputChange,
                          placeholder: "Farm or Operation Address",
                          className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3591,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.co_applicant_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_address }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3602,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3587,
                      columnNumber: 29
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3548,
                    columnNumber: 23
                  }, this),
                  updateFormData.co_applicant_occupation === "Other" && updateFormData.co_applicant_occupation_sub === "Running an unregistered Business" && /* @__PURE__ */ jsxDEV("div", { className: " w-full mt-4", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: "Address" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3615,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_bussiness_address",
                        value: updateFormData.co_applicant_bussiness_address,
                        onChange: handleInputChange,
                        placeholder: "Enter Address",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-3 focus:ring-violet-500 focus:border-violet-500"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3618,
                        columnNumber: 31
                      },
                      this
                    ),
                    errors.co_applicant_bussiness_address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bussiness_address }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3629,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3614,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3311,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3309,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-700", children: [
                      "Salary/Income Document Photo",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3643,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3641,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        htmlFor: "co_applicant_income_document",
                        className: "flex flex-col justify-center items-center w-56 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition",
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            "svg",
                            {
                              className: "w-8 h-8 mb-2 text-gray-400",
                              fill: "none",
                              stroke: "currentColor",
                              viewBox: "0 0 24 24",
                              children: /* @__PURE__ */ jsxDEV(
                                "path",
                                {
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: 2,
                                  d: "M7 16V4a1 1 0 011-1h8a1 1 0 011 1v12m-5 4h.01"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                  lineNumber: 3655,
                                  columnNumber: 29
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3649,
                              columnNumber: 27
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
                            "Click to upload ",
                            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3663,
                              columnNumber: 45
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "(PNG, JPG)" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3664,
                              columnNumber: 29
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3662,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              id: "co_applicant_income_document",
                              type: "file",
                              name: "co_applicant_income_document",
                              onChange: handleInputFileChange,
                              accept: "image/*",
                              required: true,
                              className: "hidden"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3667,
                              columnNumber: 27
                            },
                            this
                          )
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3645,
                        columnNumber: 23
                      },
                      this
                    ),
                    errors.co_applicant_income_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_income_document }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3678,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3640,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: updateFormData.co_applicant_income_document && /* @__PURE__ */ jsxDEV(
                    Link,
                    {
                      to: updateFormData.co_applicant_income_document,
                      download: true,
                      children: /* @__PURE__ */ jsxDEV(
                        "img",
                        {
                          src: updateFormData.co_applicant_income_document,
                          alt: "Income Document",
                          className: "w-56 h-56 object-cover mt-4 rounded-md shadow-md border"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3689,
                          columnNumber: 27
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3685,
                      columnNumber: 23
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3683,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3639,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 3304,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "border border-gray-300 rounded-lg p-6 bg-white shadow-md", children: [
                /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-semibold text-gray-800 text-center mb-6", children: "Bank Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3702,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank Name" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3708,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_bank_name",
                        value: updateFormData.co_applicant_bank_name,
                        onChange: handleInputChange,
                        placeholder: "Enter Bank Name",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3711,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_bank_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bank_name }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3720,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3707,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank Account Number" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3726,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_bank_account_number",
                        value: updateFormData.co_applicant_bank_account_number,
                        onChange: handleInputChange,
                        placeholder: "Enter Account Number",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3729,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_bank_account_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bank_account_number }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3740,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3725,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3706,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank Branch" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3749,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_bank_branch",
                        value: updateFormData.co_applicant_bank_branch,
                        onChange: handleInputChange,
                        placeholder: "Enter Branch",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3752,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_bank_branch && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bank_branch }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3761,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3748,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bank IFSC Code" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3767,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      Input,
                      {
                        type: "text",
                        name: "co_applicant_bank_ifsc_code",
                        value: updateFormData.co_applicant_bank_ifsc_code,
                        onChange: handleInputChange,
                        placeholder: "Enter IFSC Code",
                        className: "bg-gray-50 border border-gray-300 h-14 text-gray-900 text-sm rounded-lg w-full p-2.5"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3770,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.co_applicant_bank_ifsc_code && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bank_ifsc_code }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3779,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3766,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3747,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex space-x-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                    /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                      "Bank Passbook ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3789,
                        columnNumber: 39
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3788,
                      columnNumber: 23
                    }, this),
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        htmlFor: "co_applicant_bank_passbook_photo",
                        className: "flex flex-col justify-center items-center w-56 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition",
                        children: [
                          /* @__PURE__ */ jsxDEV(
                            "svg",
                            {
                              className: "w-8 h-8 mb-2 text-gray-400",
                              fill: "none",
                              stroke: "currentColor",
                              viewBox: "0 0 24 24",
                              children: /* @__PURE__ */ jsxDEV(
                                "path",
                                {
                                  strokeLinecap: "round",
                                  strokeLinejoin: "round",
                                  strokeWidth: 2,
                                  d: "M7 16V4a1 1 0 011-1h8a1 1 0 011 1v12m-5 4h.01"
                                },
                                void 0,
                                false,
                                {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                  lineNumber: 3801,
                                  columnNumber: 29
                                },
                                this
                              )
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3795,
                              columnNumber: 27
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
                            "Click to upload ",
                            /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3809,
                              columnNumber: 45
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "(PNG, JPG)" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3810,
                              columnNumber: 29
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3808,
                            columnNumber: 27
                          }, this),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              id: "co_applicant_bank_passbook_photo",
                              type: "file",
                              name: "co_applicant_bank_passbook_photo",
                              onChange: handleInputFileChange,
                              accept: "image/*",
                              required: true,
                              className: "hidden"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                              lineNumber: 3813,
                              columnNumber: 27
                            },
                            this
                          )
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3791,
                        columnNumber: 22
                      },
                      this
                    ),
                    errors.co_applicant_bank_passbook_photo && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_bank_passbook_photo }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3824,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3787,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: updateFormData.co_applicant_bank_passbook_photo && /* @__PURE__ */ jsxDEV(
                    Link,
                    {
                      to: updateFormData.co_applicant_bank_passbook_photo,
                      download: true,
                      children: /* @__PURE__ */ jsxDEV(
                        "img",
                        {
                          src: updateFormData.co_applicant_bank_passbook_photo,
                          alt: "Passbook",
                          className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3835,
                          columnNumber: 27
                        },
                        this
                      )
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3831,
                      columnNumber: 23
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3829,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3786,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 3701,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 2625,
              columnNumber: 15
            }, this),
            updateFormData.co_applicant_referred_type === "Property" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "email",
                    children: [
                      "Property Name ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3856,
                        columnNumber: 37
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3852,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "co_applicant_document_name",
                    value: updateFormData.co_applicant_document_name,
                    onChange: handleInputChange,
                    id: "name",
                    placeholder: "Enter the Description",
                    required: true,
                    className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3858,
                    columnNumber: 21
                  },
                  this
                ),
                errors.co_applicant_document_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_document_name }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3869,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 3851,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-6 flex space-x-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "email",
                      children: [
                        "Property Document ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3880,
                          columnNumber: 41
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3876,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      htmlFor: "co_applicant_document",
                      className: "flex flex-col justify-center items-center w-56 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition",
                      children: [
                        /* @__PURE__ */ jsxDEV(
                          "svg",
                          {
                            className: "w-8 h-8 mb-2 text-gray-400",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /* @__PURE__ */ jsxDEV(
                              "path",
                              {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M7 16V4a1 1 0 011-1h8a1 1 0 011 1v12m-5 4h.01"
                              },
                              void 0,
                              false,
                              {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                                lineNumber: 3892,
                                columnNumber: 29
                              },
                              this
                            )
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3886,
                            columnNumber: 27
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 text-center", children: [
                          "Click to upload ",
                          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3900,
                            columnNumber: 45
                          }, this),
                          /* @__PURE__ */ jsxDEV("span", { className: "text-xs", children: "(PNG, JPG)" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3901,
                            columnNumber: 29
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3899,
                          columnNumber: 27
                        }, this),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            id: "co_applicant_document",
                            type: "file",
                            name: "co_applicant_document",
                            onChange: handleInputFileChange,
                            accept: "image/*",
                            required: true,
                            className: "hidden"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                            lineNumber: 3904,
                            columnNumber: 27
                          },
                          this
                        )
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3882,
                      columnNumber: 20
                    },
                    this
                  ),
                  errors.co_applicant_document && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_document }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3915,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3875,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: updateFormData.co_applicant_document && /* @__PURE__ */ jsxDEV(Link, { to: updateFormData.co_applicant_document, download: true, children: /* @__PURE__ */ jsxDEV(
                  "img",
                  {
                    src: updateFormData.co_applicant_document,
                    alt: "Property",
                    className: "w-56 h-56 object-cover mt-4 rounded-md shadow"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3924,
                    columnNumber: 25
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3923,
                  columnNumber: 21
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3920,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 3874,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "description",
                    children: [
                      "Description ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                        lineNumber: 3938,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3934,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "co_applicant_description",
                    value: updateFormData.co_applicant_description,
                    onChange: handleInputChange,
                    id: "description",
                    placeholder: "Enter the Description",
                    required: true,
                    className: `bg-gray-50 border ${fieldSize.height} border-gray-300 text-gray-900 text-sm rounded-lg w-full`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 3940,
                    columnNumber: 21
                  },
                  this
                ),
                errors.co_applicant_description && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.co_applicant_description }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3951,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 3933,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 3850,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                lineNumber: 3960,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 3959,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
            lineNumber: 2440,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
          lineNumber: 2436,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
        lineNumber: 2432,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentCoApplicant(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Co Applicant" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
            lineNumber: 3979,
            columnNumber: 13
          }, this),
          currentCoApplicant && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteCoApplicant();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentCoApplicant?.co_applicant_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 3996,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                          lineNumber: 4e3,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 3991,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the Co Applicant Name",
                      required: true,
                      className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                      lineNumber: 4002,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                  lineNumber: 3990,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
                    lineNumber: 4010,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
              lineNumber: 3983,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
          lineNumber: 3978,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
        lineNumber: 3971,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
    lineNumber: 901,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx",
    lineNumber: 900,
    columnNumber: 5
  }, this);
};
_s(CoApplicant, "DTGgQLksyTKWv4y2HxpKhVShd1Q=");
_c = CoApplicant;
export default CoApplicant;
var _c;
$RefreshReg$(_c, "CoApplicant");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CoApplicant.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNFF3QixTQXNrREUsVUF0a0RGOzJCQTVReEI7QUFBb0JBLG9CQUFnQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsT0FBT0MsUUFBUUMsZ0JBQWdCO0FBQ3hDLFNBQVNDLGdCQUFnQjtBQUN6QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxpQkFBaUI7QUFDMUIsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLGNBQWNBLE1BQU07QUFBQUMsS0FBQTtBQUN4QixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSXJCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUNzQixhQUFhQyxjQUFjLElBQUl2QixTQUFTLEVBQUU7QUFDakQsUUFBTSxDQUFDd0Isa0JBQWtCQyxtQkFBbUIsSUFBSXpCLFNBQVMsRUFBRTtBQUMzRCxRQUFNLENBQUMwQixZQUFZQyxhQUFhLElBQUkzQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDNEIsV0FBV0MsWUFBWSxJQUFJN0IsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzhCLGlCQUFpQkMsa0JBQWtCLElBQUkvQixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDZ0MsaUJBQWlCQyxrQkFBa0IsSUFBSWpDLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNrQyxvQkFBb0JDLHFCQUFxQixJQUFJbkMsU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQ29DLFdBQVdDLFlBQVksSUFBSXJDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNzQywwQkFBMEJDLDJCQUEyQixJQUMxRHZDLFNBQVMsSUFBSTtBQUNmLFFBQU0sQ0FBQ3dDLGVBQWVDLGdCQUFnQixJQUFJekMsU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQzBDLFlBQVlDLGFBQWEsSUFBSTNDLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUM0QyxhQUFhQyxjQUFjLElBQUk3QyxTQUFTO0FBQUEsSUFDN0M4QyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFDRCxRQUFNLENBQUNDLG9CQUFvQkMscUJBQXFCLElBQUlsRCxTQUFTLEVBQUU7QUFDL0QsUUFBTSxDQUFDbUQsUUFBUUMsU0FBUyxJQUFJcEQsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDcUQscUJBQXFCQyxzQkFBc0IsSUFBSXRELFNBQVMsRUFBRTtBQUVqRSxRQUFNLENBQUN1RCxVQUFVQyxXQUFXLElBQUl4RCxTQUFTO0FBQUEsSUFDdkN5RCxTQUFTO0FBQUEsSUFDVEMsbUJBQW1CO0FBQUEsSUFDbkJDLG9CQUFvQjtBQUFBLElBQ3BCQyxtQkFBbUI7QUFBQSxJQUNuQkMsMkJBQTJCO0FBQUEsSUFDM0JDLHNCQUFzQjtBQUFBLElBQ3RCQyxzQkFBc0I7QUFBQSxJQUN0QkMsd0JBQXdCO0FBQUEsSUFDeEJDLHFCQUFxQjtBQUFBLElBQ3JCQyxxQkFBcUI7QUFBQSxJQUNyQkMsNkJBQTZCO0FBQUEsSUFDN0JDLDBCQUEwQjtBQUFBLElBQzFCQywwQkFBMEI7QUFBQSxJQUMxQkMsc0JBQXNCO0FBQUEsSUFDdEJDLG9CQUFvQjtBQUFBLElBQ3BCQywwQkFBMEI7QUFBQSxJQUMxQkMsdUJBQXVCO0FBQUEsSUFDdkJDLG9CQUFvQjtBQUFBLElBQ3BCQywwQkFBMEI7QUFBQSxJQUMxQkMsZ0JBQWdCO0FBQUEsSUFDaEJDLCtCQUErQjtBQUFBLElBQy9CQyw0QkFBNEI7QUFBQSxJQUM1QkMsNEJBQTRCO0FBQUEsSUFDNUJDLHVCQUF1QjtBQUFBLElBQ3ZCQyxvQkFBb0I7QUFBQSxJQUNwQkMsMkJBQTJCO0FBQUEsSUFDM0JDLDhCQUE4QjtBQUFBLElBQzlCQyxnQ0FBZ0M7QUFBQSxJQUNoQ0MseUJBQXlCO0FBQUEsSUFDekJDLDBCQUEwQjtBQUFBLElBQzFCQyw4QkFBOEI7QUFBQSxJQUM5QkMsK0JBQStCO0FBQUEsSUFDL0JDLHdCQUF3QjtBQUFBLElBQ3hCQyxrQ0FBa0M7QUFBQSxJQUNsQ0MsMEJBQTBCO0FBQUEsSUFDMUJDLDZCQUE2QjtBQUFBLElBQzdCQyw0QkFBNEI7QUFBQSxJQUM1QkMsa0NBQWtDO0FBQUEsSUFDbENDLDZCQUE2QjtBQUFBLElBQzdCQyw2QkFBNkI7QUFBQSxJQUM3QkMsZ0NBQWdDO0FBQUEsSUFDaENDLDhCQUE4QjtBQUFBLElBQzlCQywwQkFBMEI7QUFBQSxJQUMxQkMsNEJBQTRCO0FBQUEsSUFDNUJDLDZCQUE2QjtBQUFBLElBQzdCQyxnQ0FBZ0M7QUFBQSxJQUNoQ0MsMkJBQTJCO0FBQUEsRUFDN0IsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSXpHLFNBQVM7QUFBQSxJQUNuRHlELFNBQVM7QUFBQSxJQUNUQyxtQkFBbUI7QUFBQSxJQUNuQkMsb0JBQW9CO0FBQUEsSUFDcEJDLG1CQUFtQjtBQUFBLElBQ25CQywyQkFBMkI7QUFBQSxJQUMzQkMsc0JBQXNCO0FBQUEsSUFDdEJDLHNCQUFzQjtBQUFBLElBQ3RCQyx3QkFBd0I7QUFBQSxJQUN4QkMscUJBQXFCO0FBQUEsSUFDckJDLHFCQUFxQjtBQUFBLElBQ3JCQyw2QkFBNkI7QUFBQSxJQUM3QkMsMEJBQTBCO0FBQUEsSUFDMUJDLDBCQUEwQjtBQUFBLElBQzFCQyxzQkFBc0I7QUFBQSxJQUN0QkMsb0JBQW9CO0FBQUEsSUFDcEJDLDBCQUEwQjtBQUFBLElBQzFCQyx1QkFBdUI7QUFBQSxJQUN2QkMsb0JBQW9CO0FBQUEsSUFDcEJDLDBCQUEwQjtBQUFBLElBQzFCRSwrQkFBK0I7QUFBQSxJQUMvQkQsZ0JBQWdCO0FBQUEsSUFDaEJFLDRCQUE0QjtBQUFBLElBQzVCRSx1QkFBdUI7QUFBQSxJQUN2QkQsNEJBQTRCO0FBQUEsSUFDNUJFLG9CQUFvQjtBQUFBLElBQ3BCQywyQkFBMkI7QUFBQSxJQUMzQkMsOEJBQThCO0FBQUEsSUFDOUJDLGdDQUFnQztBQUFBLElBQ2hDQyx5QkFBeUI7QUFBQSxJQUN6QkMsMEJBQTBCO0FBQUEsSUFDMUJDLDhCQUE4QjtBQUFBLElBQzlCQywrQkFBK0I7QUFBQSxJQUMvQkMsd0JBQXdCO0FBQUEsSUFDeEJDLGtDQUFrQztBQUFBLElBQ2xDQywwQkFBMEI7QUFBQSxJQUMxQkMsNkJBQTZCO0FBQUEsSUFDN0JDLDRCQUE0QjtBQUFBLElBQzVCQyxrQ0FBa0M7QUFBQSxJQUNsQ0MsNkJBQTZCO0FBQUEsSUFDN0JDLDZCQUE2QjtBQUFBLElBQzdCQyxnQ0FBZ0M7QUFBQSxJQUNoQ0MsOEJBQThCO0FBQUEsSUFDOUJDLDBCQUEwQjtBQUFBLElBQzFCQyw0QkFBNEI7QUFBQSxJQUM1QkMsNkJBQTZCO0FBQUEsSUFDN0JDLGdDQUFnQztBQUFBLElBQ2hDQywyQkFBMkI7QUFBQSxFQUM3QixDQUFDO0FBRUQsUUFBTSxDQUFDRyxZQUFZQyxhQUFhLElBQUkzRyxTQUFTLEVBQUU7QUFDL0MsUUFBTTRHLDRCQUE0QkEsQ0FBQ0MsTUFBTTtBQUN2QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJKLGtCQUFjRyxLQUFLO0FBQUEsRUFDckI7QUFDQSxRQUFNLENBQUNFLFdBQVdDLFlBQVksSUFBSWpIO0FBQUFBLElBQ2hDdUQsU0FBU2dELDZCQUE2QjtBQUFBLE1BQ3BDLEVBQUVXLGVBQWUsSUFBSUMsTUFBTSxNQUFNQyxTQUFTLEdBQUc7QUFBQSxJQUFDO0FBQUEsRUFFbEQ7QUFDQUMsWUFBVSxNQUFNO0FBQ2QsVUFBTUMsYUFBYSxZQUFZO0FBQzdCLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU1wSCxJQUFJcUgsSUFBSSxnQkFBZ0I7QUFFL0NuRyxpQkFBU2tHLFNBQVNFLElBQUk7QUFBQSxNQUN4QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUNBSixlQUFXO0FBQUEsRUFDYixHQUFHLEVBQUU7QUFFTCxRQUFNTSwyQkFBMkJBLENBQUNDLE9BQU9oQixNQUFNO0FBQzdDLFVBQU1pQixVQUFVLENBQUMsR0FBR2QsU0FBUztBQUM3QmMsWUFBUUQsS0FBSyxFQUFFWCxnQkFBZ0JMLEVBQUVFLE9BQU9EO0FBQ3hDRyxpQkFBYWEsT0FBTztBQUFBLEVBQ3RCO0FBRUEsUUFBTUMsMkJBQTJCQSxDQUFDRixPQUFPaEIsTUFBTTtBQUM3QyxVQUFNTSxPQUFPTixFQUFFRSxPQUFPaUIsTUFBTSxDQUFDO0FBQzdCLFFBQUliLE1BQU07QUFDUixZQUFNVyxVQUFVLENBQUMsR0FBR2QsU0FBUztBQUM3QmMsY0FBUUQsS0FBSyxFQUFFVixPQUFPQTtBQUN0QlcsY0FBUUQsS0FBSyxFQUFFVCxVQUFVYSxJQUFJQyxnQkFBZ0JmLElBQUk7QUFDakRGLG1CQUFhYSxPQUFPO0FBQUEsSUFDdEI7QUFBQSxFQUNGO0FBR0EsUUFBTUssaUJBQWlCQSxNQUFNO0FBQzNCbEI7QUFBQUEsTUFBYTtBQUFBLFFBQ1gsR0FBR0Q7QUFBQUEsUUFDSCxFQUFFRSxlQUFlLElBQUlDLE1BQU0sTUFBTUMsU0FBUyxHQUFHO0FBQUEsTUFBQztBQUFBLElBQy9DO0FBQUEsRUFDSDtBQUVBLFFBQU1nQixpQkFBaUJBLENBQUNQLFVBQVU7QUFDaEMsVUFBTUMsVUFBVWQsVUFBVXFCLE9BQU8sQ0FBQ0MsR0FBR0MsTUFBTUEsTUFBTVYsS0FBSztBQUN0RFosaUJBQWFhLE9BQU87QUFDcEJ0RSxnQkFBWSxFQUFFLEdBQUdELFVBQVVnRCwyQkFBMkJ1QixRQUFRLENBQUM7QUFBQSxFQUNqRTtBQUVBVCxZQUFVLE1BQU07QUFDZCxVQUFNbUIsc0JBQXNCLFlBQVk7QUFDdENuRyxtQkFBYSxJQUFJO0FBQ2pCLFVBQUk7QUFDRixjQUFNa0YsV0FBVyxNQUFNcEgsSUFBSXFILElBQUksa0NBQWtDO0FBQ2pFLFlBQUlELFNBQVNFLE1BQU07QUFDakI5RSx3QkFBYzRFLFNBQVNFLElBQUk7QUFBQSxRQUM3QjtBQUFBLE1BQ0YsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxtQ0FBbUNBLEtBQUs7QUFBQSxNQUN4RCxVQUFDO0FBQ0NyRixxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQ0FtRyx3QkFBb0I7QUFBQSxFQUN0QixHQUFHLEVBQUU7QUFFUG5CLFlBQVUsTUFBTTtBQUNkLFVBQU1vQixtQkFBbUIsWUFBWTtBQUNuQyxVQUFJO0FBQ0ZwRyxxQkFBYSxJQUFJO0FBR2pCLFlBQUksQ0FBQ2pCLFNBQVNBLE1BQU1zSCxXQUFXLEVBQUc7QUFFbEMsY0FBTW5CLFdBQVcsTUFBTXBILElBQUlxSCxJQUFJLG9DQUFvQztBQUNuRSxjQUFNbUIsZUFBZXBCLFNBQVNFLE1BQU1uRyxlQUFlO0FBRW5ELGNBQU1zSCxnQkFBZ0JELGFBQWFFLElBQUksQ0FBQ0MsT0FBT2pCLFVBQVU7QUFFdkQsZ0JBQU1rQixxQkFBcUJELE9BQU9sRSxrQkFBa0IsSUFDakRpRSxJQUFJLENBQUNHLFdBQVc7QUFDZixrQkFBTUMsWUFBWUQsUUFBUUUsVUFBVUMsY0FBYztBQUNsRCxrQkFBTUMsU0FBU0osUUFBUUssV0FBVztBQUNsQyxtQkFBTyxHQUFHSixTQUFTLGNBQWNHLE1BQU07QUFBQSxVQUN6QyxDQUFDLEVBQ0FFLEtBQUssSUFBSTtBQUdaLGdCQUFNQyxlQUNKVCxPQUFPaEUsK0JBQStCLGFBQ2xDMUQsTUFBTW9JLEtBQUssQ0FBQ0MsTUFBTUEsRUFBRUMsUUFBUVosT0FBT2xGLGlCQUFpQixJQUNwRDtBQUVOLGdCQUFNK0Ysa0JBQ0piLE9BQU9oRSwrQkFBK0IsYUFDbEN5RSxjQUFjSyxhQUFhLFFBQzNCZCxPQUFPcEYscUJBQXFCO0FBRWxDLGdCQUFNbUcsbUJBQ0pmLE9BQU9oRSwrQkFBK0IsYUFDbEN5RSxjQUFjTyxnQkFBZ0IsUUFDOUJoQixPQUFPakYsNkJBQTZCO0FBRTFDLGlCQUFPO0FBQUEsWUFDTDZGLEtBQUtaLE9BQU9ZO0FBQUFBLFlBQ1pLLElBQUlsQyxRQUFRO0FBQUEsWUFDWm1DLG1CQUFtQmxCLE9BQU9rQjtBQUFBQSxZQUMxQnZHLFNBQVNxRixPQUFPckYsU0FBU21HLGFBQWE7QUFBQSxZQUN0Q0ssb0JBQW9CbEI7QUFBQUEsWUFDcEJqRSw0QkFBNEJnRSxPQUFPaEU7QUFBQUEsWUFDbkNwQixtQkFBbUJpRztBQUFBQSxZQUNuQjlGLDJCQUEyQmdHO0FBQUFBLFlBQzNCbEYsMEJBQTBCbUUsT0FBT25FLDRCQUE0QjtBQUFBLFlBRTdEdUYsUUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTLENBQUMsT0FBTztBQUFBLGdCQUNqQixXQUFVO0FBQUEsZ0JBQ1YsTUFBTTtBQUFBLGtCQUNKQyxPQUFPO0FBQUEsb0JBQ0w7QUFBQSxzQkFDRUMsS0FBSztBQUFBLHNCQUNMQyxPQUNFO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVU7QUFBQSwwQkFDVixTQUFTLE1BQU1DLHNCQUFzQnhCLE9BQU9ZLEdBQUc7QUFBQSwwQkFBRTtBQUFBO0FBQUEsd0JBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLG9CQUVKO0FBQUEsb0JBQ0E7QUFBQSxzQkFDRVUsS0FBSztBQUFBLHNCQUNMQyxPQUNFO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVU7QUFBQSwwQkFDVixTQUFTLE1BQU1FLHNCQUFzQnpCLE9BQU9ZLEdBQUc7QUFBQSwwQkFBRTtBQUFBO0FBQUEsd0JBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLQTtBQUFBLG9CQUVKO0FBQUEsb0JBQ0E7QUFBQSxzQkFDRVUsS0FBSztBQUFBLHNCQUNMQyxPQUNFO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVU7QUFBQSwwQkFDVixTQUFTLE1BQU16SixpQkFBaUJrSSxPQUFPWSxHQUFHO0FBQUEsMEJBQUU7QUFBQTtBQUFBLHdCQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS0E7QUFBQSxvQkFFSjtBQUFBLGtCQUFDO0FBQUEsZ0JBRUw7QUFBQSxnQkFFQSxpQ0FBQyxZQUFTLFdBQVUsb0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW9DO0FBQUE7QUFBQSxjQXpDdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBMENBLEtBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNENBO0FBQUEsVUFFSjtBQUFBLFFBQ0YsQ0FBQztBQUVEbkksdUJBQWVvSCxZQUFZO0FBQzNCbEgsNEJBQW9CbUgsYUFBYTtBQUFBLE1BQ25DLFNBQVNsQixPQUFPO0FBQ2RDLGdCQUFRRDtBQUFBQSxVQUNOO0FBQUEsVUFDQUEsT0FBTzNFLFdBQVcyRTtBQUFBQSxRQUNwQjtBQUFBLE1BQ0YsVUFBQztBQUNDckYscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUVBb0cscUJBQWlCO0FBQUEsRUFDbkIsR0FBRyxDQUFDakcsZUFBZXBCLEtBQUssQ0FBQztBQUV2QixRQUFNb0osbUJBQW1CQSxDQUFDQyxPQUFPM0QsVUFBVTtBQUN6Q3RELGdCQUFZLENBQUNrSCxjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxLQUFLLEdBQUczRDtBQUFBQSxJQUNYLEVBQUU7QUFDRixRQUFJQSxVQUFVLFNBQVM7QUFDckI1RCw0QkFBc0IsRUFBRTtBQUFBLElBQzFCO0FBRUFFLGNBQVUsQ0FBQ3VILGdCQUFnQjtBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0YsS0FBSyxHQUFHO0FBQUEsSUFDWCxFQUFFO0FBQUEsRUFDSjtBQUNBLFFBQU1HLHdCQUF3QkEsQ0FBQ0gsT0FBTzNELFVBQVU7QUFDOUNMLHNCQUFrQixDQUFDaUUsY0FBYztBQUFBLE1BQy9CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0QsS0FBSyxHQUFHM0Q7QUFBQUEsSUFDWCxFQUFFO0FBRUYxRCxjQUFVLEVBQUUsR0FBR0QsUUFBUSxDQUFDc0gsS0FBSyxHQUFHLEdBQUcsQ0FBQztBQUFBLEVBQ3RDO0FBQ0EsUUFBTUksZUFBZUEsQ0FBQ2hFLE1BQU07QUFDMUIsVUFBTSxFQUFFaUUsTUFBTWhFLE1BQU0sSUFBSUQsRUFBRUU7QUFDMUJ2RCxnQkFBWSxDQUFDa0gsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0ksSUFBSSxHQUFHaEU7QUFBQUEsSUFDVixFQUFFO0FBQ0YxRCxjQUFVLENBQUN1SCxnQkFBZ0I7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUNHLElBQUksR0FBRztBQUFBLElBQ1YsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNQyxlQUFlQSxDQUFDL0gsU0FBUztBQUM3QixVQUFNZ0ksWUFBWSxDQUFDO0FBQ25CLFVBQU12RCxPQUFPekUsU0FBUyxtQkFBbUJPLFdBQVdpRDtBQUdwRCxVQUFNeUUsUUFBUTtBQUFBLE1BQ1pDLE9BQU87QUFBQSxNQUNQQyxPQUFPO0FBQUEsTUFDUEMsU0FBUztBQUFBLE1BQ1RDLFFBQVE7QUFBQSxNQUNSQyxLQUFLO0FBQUEsSUFDUDtBQUdBLFVBQU1DLGVBQWVBLENBQUNwRSxNQUFNMkQsU0FBUztBQUNuQyxVQUFJLENBQUMzRCxNQUFNO0FBQ1QsZUFBTyxHQUFHMkQsSUFBSTtBQUFBLE1BQ2hCO0FBQ0EsWUFBTVUsZUFBZSxDQUFDLGNBQWMsYUFBYSxXQUFXO0FBQzVELFVBQUlyRSxnQkFBZ0JzRSxNQUFNO0FBQ3hCLFlBQUksQ0FBQ0QsYUFBYUUsU0FBU3ZFLEtBQUtuRSxJQUFJLEdBQUc7QUFDckMsaUJBQU87QUFBQSxRQUNUO0FBQ0EsWUFBSW1FLEtBQUt3RSxPQUFPLElBQUksT0FBTyxNQUFNO0FBQy9CLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0YsV0FBVyxPQUFPeEUsU0FBUyxZQUFZQSxLQUFLeUUsS0FBSyxNQUFNLElBQUk7QUFDekQsZUFBTyxHQUFHZCxJQUFJO0FBQUEsTUFDaEI7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUdBLFFBQUksQ0FBQ3JELEtBQUtoRSxRQUFTdUgsV0FBVXZILFVBQVU7QUFDdkMsUUFBSSxDQUFDZ0UsS0FBSzNDO0FBQ1JrRyxnQkFBVWxHLDZCQUE2QjtBQUN6QyxRQUFJLENBQUMyQyxLQUFLN0Msa0JBQWtCNkMsS0FBSzdDLGVBQWU4RCxXQUFXO0FBQ3pEc0MsZ0JBQVVwRyxpQkFBaUI7QUFHN0IsUUFBSTZDLEtBQUszQywrQkFBK0IsWUFBWTtBQUNsRCxVQUFJLENBQUMyQyxLQUFLN0Q7QUFDUm9ILGtCQUFVcEgsb0JBQW9CO0FBQ2hDLFVBQUksQ0FBQzZELEtBQUs5QywwQkFBMEJpSCxLQUFLO0FBQ3ZDWixrQkFBVXJHLDJCQUEyQjtBQUFBLElBQ3pDLFdBQVc4QyxLQUFLM0MsK0JBQStCLFlBQVk7QUFDekQsVUFBSSxDQUFDMkMsS0FBSzlDLDBCQUEwQmlILEtBQUs7QUFDdkNaLGtCQUFVckcsMkJBQTJCO0FBQ3ZDLFVBQUksQ0FBQzhDLEtBQUsxQyw0QkFBNEI2RyxLQUFLO0FBQ3pDWixrQkFBVWpHLDZCQUE2QjtBQUN6QyxVQUFJOEcsWUFBWU47QUFBQUEsUUFDZDlELEtBQUt6QztBQUFBQSxRQUNMO0FBQUEsTUFDRjtBQUNBLFVBQUk2RyxVQUFXYixXQUFVaEcsd0JBQXdCNkc7QUFBQUEsSUFDbkQsV0FBV3BFLEtBQUszQywrQkFBK0IsZUFBZTtBQUU1RCxVQUFJLENBQUMyQyxLQUFLL0QsbUJBQW1Ca0ksS0FBSztBQUNoQ1osa0JBQVV0SCxvQkFBb0I7QUFDaEMsVUFBSSxDQUFDK0QsS0FBS3JDLGdDQUFnQ3dHLEtBQUs7QUFDN0NaLGtCQUFVNUYsaUNBQ1I7QUFDSixVQUNFLENBQUNxQyxLQUFLNUQsNkJBQ04sQ0FBQ29ILE1BQU1FLE1BQU1XLEtBQUtyRSxLQUFLNUQseUJBQXlCLEdBQ2hEO0FBQ0FtSCxrQkFBVW5ILDRCQUE0QjtBQUFBLE1BQ3hDO0FBQ0EsVUFDRSxDQUFDNEQsS0FBSzlELHNCQUNOLENBQUNzSCxNQUFNQyxNQUFNWSxLQUFLckUsS0FBSzlELGtCQUFrQixHQUN6QztBQUNBcUgsa0JBQVVySCxxQkFBcUI7QUFBQSxNQUNqQztBQUNBLFVBQUksQ0FBQzhELEtBQUszRCxzQkFBc0I4SCxLQUFLO0FBQ25DWixrQkFBVWxILHVCQUF1QjtBQUNuQyxVQUNFLENBQUMyRCxLQUFLMUQsd0JBQ04sQ0FBQ2tILE1BQU1HLFFBQVFVLEtBQUtyRSxLQUFLMUQsb0JBQW9CLEdBQzdDO0FBQ0FpSCxrQkFBVWpILHVCQUF1QjtBQUFBLE1BQ25DO0FBR0EsVUFDRSxDQUFDMEQsS0FBS3pELDBCQUNOLENBQUNpSCxNQUFNSSxPQUFPUyxLQUFLckUsS0FBS3pELHNCQUFzQixHQUM5QztBQUNBZ0gsa0JBQVVoSCx5QkFBeUI7QUFBQSxNQUNyQztBQUNBLFVBQ0UsQ0FBQ3lELEtBQUt4RCx1QkFDTixDQUFDZ0gsTUFBTUssSUFBSVEsS0FBS3JFLEtBQUt4RCxtQkFBbUIsR0FDeEM7QUFDQStHLGtCQUFVL0csc0JBQ1I7QUFBQSxNQUNKO0FBQ0EsVUFBSTRILFlBQVlOLGFBQWE5RCxLQUFLeEMsb0JBQW9CLGVBQWU7QUFDckUsVUFBSTRHLFVBQVdiLFdBQVUvRixxQkFBcUI0RztBQUM5Q0Esa0JBQVlOO0FBQUFBLFFBQ1Y5RCxLQUFLdkM7QUFBQUEsUUFDTDtBQUFBLE1BQ0Y7QUFDQSxVQUFJMkcsVUFBV2IsV0FBVTlGLDRCQUE0QjJHO0FBQ3JEQSxrQkFBWU47QUFBQUEsUUFDVjlELEtBQUt0QztBQUFBQSxRQUNMO0FBQUEsTUFDRjtBQUNBLFVBQUkwRyxVQUFXYixXQUFVN0YsK0JBQStCMEc7QUFHeEQsVUFBSSxDQUFDcEUsS0FBS3BDO0FBQ1IyRixrQkFBVTNGLDBCQUEwQjtBQUd0QyxjQUFRb0MsS0FBS3BDLHlCQUF1QjtBQUFBLFFBQ2xDLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFDSCxjQUFJLENBQUNvQyxLQUFLMUIsNkJBQTZCNkYsS0FBSztBQUMxQ1osc0JBQVVqRiw4QkFBOEI7QUFDMUMsY0FBSSxDQUFDMEIsS0FBS3pCLDZCQUE2QjRGLEtBQUs7QUFDMUNaLHNCQUFVaEYsOEJBQThCO0FBQzFDLGNBQUksQ0FBQ3lCLEtBQUt4QixnQ0FBZ0MyRixLQUFLO0FBQzdDWixzQkFBVS9FLGlDQUNSO0FBQ0o7QUFBQSxRQUNGLEtBQUs7QUFDSCxjQUFJLENBQUN3QixLQUFLdkIsOEJBQThCMEYsS0FBSztBQUMzQ1osc0JBQVU5RSwrQkFDUjtBQUNKLGNBQUksQ0FBQ3VCLEtBQUt4QixnQ0FBZ0MyRixLQUFLO0FBQzdDWixzQkFBVS9FLGlDQUNSO0FBQ0o7QUFBQSxRQUNGLEtBQUs7QUFDSCxjQUFJLENBQUN3QixLQUFLdEIsMEJBQTBCeUYsS0FBSztBQUN2Q1osc0JBQVU3RSwyQkFBMkI7QUFDdkMsY0FBSSxDQUFDc0IsS0FBS3JCO0FBQ1I0RSxzQkFBVTVFLDZCQUE2QjtBQUN6QyxjQUFJLENBQUNxQixLQUFLeEIsZ0NBQWdDMkYsS0FBSztBQUM3Q1osc0JBQVUvRSxpQ0FDUjtBQUNKO0FBQUEsUUFDRixLQUFLO0FBQ0gsY0FBSSxDQUFDd0IsS0FBS3BCLDZCQUE2QnVGLEtBQUs7QUFDMUNaLHNCQUFVM0UsOEJBQ1I7QUFDSixjQUNFb0IsS0FBS3BCLGdDQUNILHNDQUNGLENBQUNvQixLQUFLeEIsZ0NBQWdDMkYsS0FBSyxHQUMzQztBQUNBWixzQkFBVS9FLGlDQUNSO0FBQUEsVUFDSjtBQUNBO0FBQUEsUUFDRjtBQUNFO0FBQUEsTUFDSjtBQUNBNEYsa0JBQVlOO0FBQUFBLFFBQ1Y5RCxLQUFLbEM7QUFBQUEsUUFDTDtBQUFBLE1BQ0Y7QUFDQSxVQUFJc0csVUFBV2IsV0FBVXpGLCtCQUErQnNHO0FBR3hELFVBQUksQ0FBQ3BFLEtBQUtoQyx3QkFBd0JtRyxLQUFLO0FBQ3JDWixrQkFBVXZGLHlCQUF5QjtBQUNyQyxVQUFJLENBQUNnQyxLQUFLL0Isa0NBQWtDa0csS0FBSztBQUMvQ1osa0JBQVV0RixtQ0FDUjtBQUNKLFVBQUksQ0FBQytCLEtBQUs5QiwwQkFBMEJpRyxLQUFLO0FBQ3ZDWixrQkFBVXJGLDJCQUEyQjtBQUN2QyxVQUFJLENBQUM4QixLQUFLN0IsNkJBQTZCZ0csS0FBSztBQUMxQ1osa0JBQVVwRiw4QkFBOEI7QUFDMUNpRyxrQkFBWU47QUFBQUEsUUFDVjlELEtBQUszQjtBQUFBQSxRQUNMO0FBQUEsTUFDRjtBQUNBLFVBQUkrRixVQUFXYixXQUFVbEYsbUNBQW1DK0Y7QUFBQUEsSUFDOUQ7QUFFQXpJLGNBQVU0SCxTQUFTO0FBQ25CLFdBQU9lLE9BQU9DLEtBQUtoQixTQUFTLEVBQUV0QyxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNdUQsZUFBZSxPQUFPcEYsTUFBTTtBQUNoQ0EsTUFBRXFGLGVBQWU7QUFDakIsVUFBTUMsVUFBVXBCLGFBQWEsZ0JBQWdCO0FBQzdDLFFBQUlvQixTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU1DLFNBQVMsSUFBSUMsU0FBUztBQUM1Qk4sZUFBT08sUUFBUS9JLFFBQVEsRUFBRWdKLFFBQVEsQ0FBQyxDQUFDbkMsS0FBS3RELEtBQUssTUFBTTtBQUNqRCxjQUFJQSxpQkFBaUIyRSxNQUFNO0FBQ3pCVyxtQkFBT0ksT0FBT3BDLEtBQUt0RCxLQUFLO0FBQUEsVUFDMUIsV0FBVzJGLE1BQU1DLFFBQVE1RixLQUFLLEdBQUc7QUFDL0JBLGtCQUFNeUYsUUFBUSxDQUFDSSxNQUFNUCxPQUFPSSxPQUFPLEdBQUdwQyxHQUFHLE1BQU11QyxDQUFDLENBQUM7QUFBQSxVQUNuRCxXQUFXN0YsT0FBTztBQUNoQnNGLG1CQUFPSSxPQUFPcEMsS0FBS3RELEtBQUs7QUFBQSxVQUMxQjtBQUFBLFFBQ0YsQ0FBQztBQUVERSxrQkFBVXVGLFFBQVEsQ0FBQ0ssS0FBS3JFLE1BQU07QUFDNUIsY0FBSXFFLElBQUl6RixNQUFNO0FBQ1ppRixtQkFBT0ksT0FBTyw2QkFBNkJJLElBQUl6RixJQUFJO0FBQ25EaUYsbUJBQU9JO0FBQUFBLGNBQ0w7QUFBQSxjQUNBSSxJQUFJMUYsaUJBQWlCLFlBQVlxQixJQUFJLENBQUM7QUFBQSxZQUN4QztBQUFBLFVBQ0Y7QUFBQSxRQUNGLENBQUM7QUFFRCxjQUFNaEIsV0FBVyxNQUFNcEgsSUFBSTBNO0FBQUFBLFVBQ3pCO0FBQUE7QUFBQSxVQUVBVDtBQUFBQSxVQUNBO0FBQUEsWUFDRVUsU0FBUztBQUFBLGNBQ1AsZ0JBQWdCO0FBQUEsWUFDbEI7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUVBcksseUJBQWlCLENBQUNzSyxTQUFTQSxPQUFPLENBQUM7QUFDbkNsSyx1QkFBZTtBQUFBLFVBQ2JHLE1BQU07QUFBQSxVQUNORCxTQUFTO0FBQUEsVUFDVEQsWUFBWTtBQUFBLFFBQ2QsQ0FBQztBQUNEakIscUJBQWEsS0FBSztBQUNsQjJCLG9CQUFZO0FBQUEsVUFDVkMsU0FBUztBQUFBLFVBQ1RDLG1CQUFtQjtBQUFBLFVBQ25CQyxvQkFBb0I7QUFBQSxVQUNwQkMsbUJBQW1CO0FBQUEsVUFDbkJDLDJCQUEyQjtBQUFBLFVBQzNCQyxzQkFBc0I7QUFBQSxVQUN0QkMsc0JBQXNCO0FBQUEsVUFDdEJDLHdCQUF3QjtBQUFBLFVBQ3hCQyxxQkFBcUI7QUFBQSxVQUNyQkMscUJBQXFCO0FBQUEsVUFDckJDLDZCQUE2QjtBQUFBLFVBQzdCQywwQkFBMEI7QUFBQSxVQUMxQkMsMEJBQTBCO0FBQUEsVUFDMUJDLHNCQUFzQjtBQUFBLFVBQ3RCQyxvQkFBb0I7QUFBQSxVQUNwQkMsMEJBQTBCO0FBQUEsVUFDMUJDLHVCQUF1QjtBQUFBLFVBQ3ZCQyxvQkFBb0I7QUFBQSxVQUNwQkMsMEJBQTBCO0FBQUEsVUFDMUJDLGdCQUFnQjtBQUFBLFVBQ2hCQywrQkFBK0I7QUFBQSxVQUMvQkMsNEJBQTRCO0FBQUEsVUFDNUJFLHVCQUF1QjtBQUFBLFVBQ3ZCRCw0QkFBNEI7QUFBQSxVQUM1QkUsb0JBQW9CO0FBQUEsVUFDcEJDLDJCQUEyQjtBQUFBLFVBQzNCQyw4QkFBOEI7QUFBQSxVQUM5QkMsZ0NBQWdDO0FBQUEsVUFDaENDLHlCQUF5QjtBQUFBLFVBQ3pCMkgscUJBQXFCO0FBQUEsVUFDckJ4SCwrQkFBK0I7QUFBQSxVQUMvQkMsd0JBQXdCO0FBQUEsVUFDeEJDLGtDQUFrQztBQUFBLFVBQ2xDQywwQkFBMEI7QUFBQSxVQUMxQkMsNkJBQTZCO0FBQUEsVUFDN0JFLGtDQUFrQztBQUFBLFVBQ2xDUiwwQkFBMEI7QUFBQSxVQUMxQkMsOEJBQThCO0FBQUEsVUFDOUJRLDZCQUE2QjtBQUFBLFVBQzdCQyw2QkFBNkI7QUFBQSxVQUM3QkMsZ0NBQWdDO0FBQUEsVUFDaENDLDhCQUE4QjtBQUFBLFVBQzlCQywwQkFBMEI7QUFBQSxVQUMxQkMsNEJBQTRCO0FBQUEsVUFDNUJDLDZCQUE2QjtBQUFBLFVBQzdCQyxnQ0FBZ0M7QUFBQSxVQUNoQ0MsMkJBQTJCO0FBQUEsUUFDN0IsQ0FBQztBQUFBLE1BQ0gsU0FBU21CLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQ2pEN0UsdUJBQWU7QUFBQSxVQUNiRyxNQUFNO0FBQUEsVUFDTkQsU0FDRTJFLE9BQU9ILFVBQVVFLE1BQU0xRSxXQUFXO0FBQUEsVUFDcENELFlBQVk7QUFBQSxRQUNkLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNbUssZUFBZSxPQUFPcEcsTUFBTTtBQUNoQ0EsTUFBRXFGLGVBQWU7QUFDakIsUUFBSTtBQUNGLFlBQU1FLFNBQVMsSUFBSUMsU0FBUztBQUU1QixZQUFNLEVBQUU5RiwyQkFBMkIsR0FBRzJHLEtBQUssSUFBSTFHO0FBRy9DdUYsYUFBT08sUUFBUVksSUFBSSxFQUFFWCxRQUFRLENBQUMsQ0FBQ25DLEtBQUt0RCxLQUFLLE1BQU07QUFDN0MsWUFBSUEsTUFBT3NGLFFBQU9JLE9BQU9wQyxLQUFLdEQsS0FBSztBQUFBLE1BQ3JDLENBQUM7QUFHRCxZQUFNcUcsbUJBQW1CO0FBQUEsUUFDdkI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQXVCO0FBR3pCQSx1QkFBaUJaLFFBQVEsQ0FBQzlCLFVBQVU7QUFDbEMsWUFBSWpFLGVBQWVpRSxLQUFLLGFBQWFnQixNQUFNO0FBQ3pDVyxpQkFBT0ksT0FBTy9CLE9BQU9qRSxlQUFlaUUsS0FBSyxDQUFDO0FBQUEsUUFDNUM7QUFBQSxNQUNGLENBQUM7QUFHRCxVQUFJekQsYUFBYXlGLE1BQU1DLFFBQVExRixTQUFTLEdBQUc7QUFDekNBLGtCQUFVdUYsUUFBUSxDQUFDSyxLQUFLckUsTUFBTTtBQUM1QixjQUFJcUUsSUFBSXpGLGdCQUFnQnNFLE1BQU07QUFDNUJXLG1CQUFPSSxPQUFPLDZCQUE2QkksSUFBSXpGLElBQUk7QUFDbkRpRixtQkFBT0k7QUFBQUEsY0FDTDtBQUFBO0FBQUEsY0FDQUksSUFBSTFGLGlCQUFpQixZQUFZcUIsSUFBSSxDQUFDO0FBQUEsWUFDeEM7QUFBQSxVQUNGO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSDtBQUVBLFlBQU1wSSxJQUFJaU47QUFBQUEsUUFDUix5Q0FBeUM5SywwQkFBMEJvSCxHQUFHO0FBQUEsUUFDdEUwQztBQUFBQSxRQUNBLEVBQUVVLFNBQVMsRUFBRSxnQkFBZ0Isc0JBQXNCLEVBQUU7QUFBQSxNQUN2RDtBQUVBN0sseUJBQW1CLEtBQUs7QUFDeEJRLHVCQUFpQixDQUFDc0ssU0FBU0EsT0FBTyxDQUFDO0FBQ25DbEsscUJBQWU7QUFBQSxRQUNiRyxNQUFNO0FBQUEsUUFDTkQsU0FBUztBQUFBLFFBQ1RELFlBQVk7QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNILFNBQVM0RSxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sZ0NBQWdDQSxLQUFLO0FBQ25EN0UscUJBQWU7QUFBQSxRQUNiRyxNQUFNO0FBQUEsUUFDTkQsU0FBUzJFLE9BQU9ILFVBQVVFLE1BQU0xRSxXQUFXO0FBQUEsUUFDM0NELFlBQVk7QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUVBLFFBQU11SyxVQUFVO0FBQUEsSUFDZCxFQUFFakQsS0FBSyxNQUFNa0QsUUFBUSxTQUFTO0FBQUEsSUFDNUIsRUFBQ2xELEtBQUsscUJBQXFCa0QsUUFBUSxvQkFBbUI7QUFBQSxJQUN4RCxFQUFFbEQsS0FBSyxXQUFXa0QsUUFBUSxnQkFBZ0I7QUFBQSxJQUMxQyxFQUFFbEQsS0FBSyw4QkFBOEJrRCxRQUFRLGdCQUFnQjtBQUFBLElBQzdELEVBQUVsRCxLQUFLLHNCQUFzQmtELFFBQVEscUJBQXFCO0FBQUEsSUFDMUQsRUFBRWxELEtBQUsscUJBQXFCa0QsUUFBUSxvQkFBb0I7QUFBQSxJQUN4RCxFQUFFbEQsS0FBSyw2QkFBNkJrRCxRQUFRLDRCQUE0QjtBQUFBLElBQ3hFLEVBQUVsRCxLQUFLLFVBQVVrRCxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1DLG9CQUFvQm5NLE1BQU1pSDtBQUFBQSxJQUFPLENBQUNqSCxXQUN0Q0EsT0FBTXdJLFVBQVU0RCxZQUFZLEVBQUU5QixTQUFTaEssV0FBVzhMLFlBQVksQ0FBQztBQUFBLEVBQ2pFO0FBRUEsUUFBTWpELHdCQUF3QixPQUFPa0QsV0FBVztBQUM5QyxRQUFJO0FBQ0YsWUFBTWxHLFdBQVcsTUFBTXBILElBQUlxSDtBQUFBQSxRQUN6Qiw0Q0FBNENpRyxNQUFNO0FBQUEsTUFDcEQ7QUFFQXRMLDRCQUFzQm9GLFNBQVNFLE1BQU1uRyxhQUFhb0ksT0FBTyxJQUFJO0FBQzdEM0gseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTMkYsT0FBTztBQUNkQyxjQUFRRCxNQUFNLGdDQUFnQ0EsS0FBSztBQUFBLElBQ3JEO0FBQUEsRUFDRjtBQUVBLFFBQU1nRyxtQkFBbUJBLENBQUM3RyxNQUFNO0FBQzlCLFVBQU0sRUFBRWlFLE1BQU05QyxNQUFNLElBQUluQixFQUFFRTtBQUMxQixVQUFNSSxPQUFPYSxNQUFNLENBQUM7QUFFcEIsUUFBSWIsTUFBTTtBQUNSM0Qsa0JBQVksQ0FBQ3VKLFVBQVU7QUFBQSxRQUNyQixHQUFHQTtBQUFBQSxRQUNILENBQUNqQyxJQUFJLEdBQUczRDtBQUFBQTtBQUFBQSxRQUNSLENBQUMsR0FBRzJELElBQUksVUFBVSxHQUFHN0MsSUFBSUMsZ0JBQWdCZixJQUFJO0FBQUE7QUFBQSxNQUMvQyxFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFFRSxRQUFNd0csd0JBQXdCQSxDQUFDOUcsTUFBTTtBQUNyQyxVQUFNLEVBQUVpRSxNQUFNOUMsTUFBTSxJQUFJbkIsRUFBRUU7QUFDMUIsVUFBTUksT0FBT2EsTUFBTSxDQUFDO0FBRXBCLFFBQUliLE1BQU07QUFDUjNELGtCQUFZLENBQUN1SixVQUFVO0FBQUEsUUFDckIsR0FBR0E7QUFBQUEsUUFDSCxDQUFDakMsSUFBSSxHQUFHM0Q7QUFBQUE7QUFBQUEsUUFDUixDQUFDLEdBQUcyRCxJQUFJLFVBQVUsR0FBRzdDLElBQUlDLGdCQUFnQmYsSUFBSTtBQUFBO0FBQUEsTUFDL0MsRUFBRTtBQUFBLElBQ0o7QUFBQSxFQUNGO0FBRUEsUUFBTW1ELHdCQUF3QixPQUFPbUQsV0FBVztBQUM5QyxRQUFJO0FBQ0YsWUFBTWxHLFdBQVcsTUFBTXBILElBQUlxSDtBQUFBQSxRQUN6Qiw0Q0FBNENpRyxNQUFNO0FBQUEsTUFDcEQ7QUFDQSxZQUFNRyxjQUFjckcsVUFBVUUsTUFBTW5HO0FBQ3BDLFlBQU11TSxzQkFBc0JELGFBQWFoSixrQkFBa0IsSUFBSWlFO0FBQUFBLFFBQzdELENBQUNoQyxPQUFPO0FBQUEsVUFDTjZDLEtBQUs3QyxFQUFFNkM7QUFBQUEsVUFDUFAsWUFBWXRDLEdBQUdxQyxVQUFVQyxjQUFjO0FBQUEsVUFDdkNDLFFBQVF2QyxHQUFHd0MsV0FBVztBQUFBLFFBQ3hCO0FBQUEsTUFDRjtBQUNBL0YsNkJBQXVCdUssa0JBQWtCO0FBRXpDcEgsd0JBQWtCO0FBQUEsUUFDaEJoRCxTQUFTbUssYUFBYW5LLFNBQVNpRyxPQUFPO0FBQUEsUUFDdEM5RSxnQkFBZ0JnSixhQUFhaEosZ0JBQWdCaUUsSUFBSSxDQUFDaEMsTUFBTUEsRUFBRTZDLEdBQUcsS0FBSztBQUFBLFFBQ2xFaEcsbUJBQW1Ca0ssYUFBYWxLLHFCQUFxQjtBQUFBLFFBQ3JEQyxvQkFBb0JpSyxhQUFhakssc0JBQXNCO0FBQUEsUUFDdkRFLDJCQUEyQitKLGFBQWEvSiw2QkFBNkI7QUFBQSxRQUNyRUQsbUJBQW1CZ0ssYUFBYWhLLHFCQUFxQjtBQUFBLFFBQ3JERSxzQkFBc0I4SixhQUFhOUosd0JBQXdCO0FBQUEsUUFDM0RDLHNCQUFzQjZKLGFBQWE3Six3QkFBd0I7QUFBQSxRQUMzREMsd0JBQXdCNEosYUFBYTVKLDBCQUEwQjtBQUFBLFFBQy9EQyxxQkFBcUIySixhQUFhM0osdUJBQXVCO0FBQUEsUUFDekRDLHFCQUFxQjBKLGFBQWExSix1QkFBdUI7QUFBQSxRQUN6REMsNkJBQ0V5SixhQUFhekosK0JBQStCO0FBQUEsUUFDOUNDLDBCQUEwQndKLGFBQWF4Siw0QkFBNEI7QUFBQSxRQUNuRUMsMEJBQTBCdUosYUFBYXZKLDRCQUE0QjtBQUFBLFFBQ25FQyxzQkFBc0JzSixhQUFhdEosd0JBQXdCO0FBQUEsUUFDM0RDLG9CQUFvQnFKLGFBQWFySixzQkFBc0I7QUFBQSxRQUN2REMsMEJBQTBCb0osYUFBYXBKLDRCQUE0QjtBQUFBLFFBQ25FQyx1QkFBdUJtSixhQUFhbkoseUJBQXlCO0FBQUEsUUFDN0RDLG9CQUFvQmtKLGFBQWFsSixzQkFBc0I7QUFBQSxRQUN2REMsMEJBQTBCaUosYUFBYWpKLDRCQUE0QjtBQUFBLFFBQ25FRSwrQkFDRStJLGFBQWEvSTtBQUFBQSxRQUNmRyx1QkFBdUI0SSxhQUFhNUkseUJBQXlCO0FBQUEsUUFDN0RELDRCQUNFNkksYUFBYTdJLDhCQUE4QjtBQUFBLFFBQzdDRCw0QkFDRThJLGFBQWE5SSw4QkFBOEI7QUFBQSxRQUM3Q0csb0JBQW9CMkksYUFBYTNJLHNCQUFzQjtBQUFBLFFBQ3ZEQywyQkFBMkIwSSxhQUFhMUksNkJBQTZCO0FBQUEsUUFDckVDLDhCQUNFeUksYUFBYXpJLGdDQUFnQztBQUFBLFFBQy9DQyxnQ0FDRXdJLGFBQWF4SSxrQ0FBa0M7QUFBQSxRQUNqREMseUJBQXlCdUksYUFBYXZJLDJCQUEyQjtBQUFBLFFBQ2pFMkgscUJBQXFCWSxhQUFhWix1QkFBdUI7QUFBQSxRQUN6RHhILCtCQUNFb0ksYUFBYXBJLGlDQUFpQztBQUFBLFFBQ2hEQyx3QkFBd0JtSSxhQUFhbkksMEJBQTBCO0FBQUEsUUFDL0RDLGtDQUNFa0ksYUFBYWxJLG9DQUFvQztBQUFBLFFBQ25EQywwQkFBMEJpSSxhQUFhakksNEJBQTRCO0FBQUEsUUFDbkVDLDZCQUNFZ0ksYUFBYWhJLCtCQUErQjtBQUFBLFFBQzlDRSxrQ0FDRThILGFBQWE5SCxvQ0FBb0M7QUFBQSxRQUNuRFAsOEJBQ0VxSSxhQUFhckksZ0NBQWdDO0FBQUEsUUFDL0NRLDZCQUNFNkgsYUFBYTdILCtCQUErQjtBQUFBLFFBQzlDQyw2QkFDRTRILGFBQWE1SCwrQkFBK0I7QUFBQSxRQUM5Q0MsZ0NBQ0UySCxhQUFhM0gsa0NBQWtDO0FBQUEsUUFDakRDLDhCQUNFMEgsYUFBYTFILGdDQUFnQztBQUFBLFFBQy9DQywwQkFBMEJ5SCxhQUFhekgsNEJBQTRCO0FBQUEsUUFDbkVDLDRCQUNFd0gsYUFBYXhILDhCQUE4QjtBQUFBLFFBQzdDQyw2QkFDRXVILGFBQWF2SCwrQkFBK0I7QUFBQSxRQUM5Q0MsZ0NBQ0VzSCxhQUFhdEgsa0NBQWtDO0FBQUEsUUFDakRDLDJCQUEyQnFILGFBQWFySCw2QkFBNkI7QUFBQSxNQUN2RSxDQUFDO0FBQ0RVO0FBQUFBLFNBQ0cyRyxhQUFhckgsNkJBQTZCLElBQUlzQyxJQUFJLENBQUNpRixPQUFPO0FBQUEsVUFDekQ1RyxlQUFlNEcsRUFBRTVHO0FBQUFBLFVBQ2pCQyxNQUFNO0FBQUE7QUFBQSxVQUNOQyxTQUFTMEcsRUFBRUM7QUFBQUE7QUFBQUEsVUFDWEMsYUFBYUYsRUFBRUM7QUFBQUE7QUFBQUEsUUFDakIsRUFBRTtBQUFBLE1BQ0o7QUFFQXhMLGtDQUE0QnFMLFdBQVc7QUFDdkMzTCx5QkFBbUIsSUFBSTtBQUN2Qm1CLGdCQUFVLENBQUMsQ0FBQztBQUFBLElBQ2QsU0FBU3NFLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFBQSxJQUNyRDtBQUFBLEVBQ0Y7QUFDQSxRQUFNdUcsb0JBQW9CQSxDQUFDcEgsTUFBTTtBQUMvQixVQUFNLEVBQUVpRSxNQUFNaEUsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQk4sc0JBQWtCLENBQUNpRSxjQUFjO0FBQUEsTUFDL0IsR0FBR0E7QUFBQUEsTUFDSCxDQUFDSSxJQUFJLEdBQUdoRTtBQUFBQSxJQUNWLEVBQUU7QUFDRjFELGNBQVUsQ0FBQ3NILGNBQWM7QUFBQSxNQUN2QixHQUFHQTtBQUFBQSxNQUNILENBQUNJLElBQUksR0FBRztBQUFBLElBQ1YsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNb0QsMEJBQTBCLFlBQVk7QUFFMUMsUUFBSWhNLG9CQUFvQjtBQUN0QixVQUFJO0FBQ0YsY0FBTXFGLFdBQVcsTUFBTXBILElBQUlnTztBQUFBQSxVQUN6QiwrQ0FBK0NqTSxrQkFBa0I7QUFBQSxRQUNuRTtBQUNBeUYsZ0JBQVF5RyxLQUFLN0csVUFBVSxVQUFVO0FBRWpDMUUsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFDRFAseUJBQWlCLENBQUNzSyxTQUFTQSxPQUFPLENBQUM7QUFDbkNoTCwyQkFBbUIsS0FBSztBQUN4QkksOEJBQXNCLElBQUk7QUFBQSxNQUM1QixTQUFTdUYsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFBQSxNQUNyRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ1I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLDZCQUE2QmQ7QUFBQUEsVUFDN0IsWUFBWTtBQUFBO0FBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUI7QUFBQSxNQUVuQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTWhFLFlBQVlJO0FBQUFBLFVBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFVBQ3JCLFNBQVMsTUFDUEYsZUFBZSxDQUFDa0ssVUFBVSxFQUFFLEdBQUdBLE1BQU1qSyxZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUdILHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxhQUNWO0FBQUEsaUNBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBVztBQUFBLFVBQ2QsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDBCQUF5Qix3Q0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0Q7QUFBQSxZQUUvRDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTtBQUNiakIsK0JBQWEsSUFBSTtBQUNqQnVCLDRCQUFVLENBQUMsQ0FBQztBQUFBLGdCQUNkO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUF1RztBQUFBO0FBQUEsY0FMbkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUE7QUFBQSxlQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFFBQ0M1QixrQkFBa0JrSCxTQUFTLEtBQUssQ0FBQ3RHLFlBQ2hDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixlQUFla0k7QUFBQUEsWUFDZixNQUFNNUosYUFBYWMsa0JBQWtCa0YsVUFBVTtBQUFBLFlBQy9DO0FBQUEsWUFDQSxpQkFBZ0I7QUFBQSxZQUNoQixrQkFBa0I7QUFBQTtBQUFBLFVBTnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1zQyxJQUd0QztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLFNBQVNsRixpQkFBaUJrSCxVQUFVO0FBQUEsWUFDcEMsTUFBSztBQUFBO0FBQUEsVUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHMEI7QUFBQSxXQTlCOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlDQTtBQUFBLFNBaERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpREE7QUFBQSxJQUNBLHVCQUFDLFNBQU0sV0FBVzlHLFdBQVcsU0FBUyxNQUFNQyxhQUFhLEtBQUssR0FDNUQsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHdDQUF1QyxnQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsV0FBVTtBQUFBLFVBQ1YsUUFBTztBQUFBLFVBQ1AsVUFBVW9LO0FBQUFBLFVBQ1YsU0FBUTtBQUFBLFVBQ1IsWUFBVTtBQUFBLFVBRVY7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsZ0JBQ2hELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0M7QUFBQSxtQkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxxQ0FBcUNsTCxVQUFVc04sTUFBTTtBQUFBLGtCQUNoRSxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxPQUFPOUssU0FBU0UsV0FBVzZLO0FBQUFBLGtCQUMzQixVQUFVLENBQUN4SCxVQUFVO0FBQ25CdEQsZ0NBQVksQ0FBQ3VKLFVBQVU7QUFBQSxzQkFDckIsR0FBR0E7QUFBQUEsc0JBQ0h0SixTQUFTcUQ7QUFBQUEsc0JBQ1RsQyxnQkFBZ0I7QUFBQSxvQkFDbEIsRUFBRTtBQUVGLDBCQUFNMkosV0FBVzdMLFdBQ2QyRixPQUFPLENBQUN4QixNQUFNQSxFQUFFcEQsU0FBU2lHLFFBQVE1QyxLQUFLLEVBQ3RDK0IsSUFBSSxDQUFDaEMsT0FBTztBQUFBLHNCQUNYNkMsS0FBSzdDLEVBQUU2QztBQUFBQSxzQkFDUFAsWUFBWXRDLEVBQUVxQyxVQUFVQztBQUFBQSxzQkFDeEJDLFFBQVF2QyxFQUFFd0M7QUFBQUEsb0JBQ1osRUFBRTtBQUVKL0YsMkNBQXVCaUwsUUFBUTtBQUFBLGtCQUNqQztBQUFBLGtCQUNBLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLFFBQVFDLFVBQ0psQixZQUFZLEVBQ2I5QixTQUFTOEMsTUFBTWhCLFlBQVksQ0FBQztBQUFBLGtCQUdoQ2YsZ0JBQU1rQztBQUFBQSxvQkFDTCxJQUFJQztBQUFBQSxzQkFDRmxNLFdBQ0cyRixPQUFPLENBQUN4QixNQUFNQSxFQUFFcEQsV0FBV29ELEVBQUVwRCxRQUFRbUcsV0FBV2dDLEtBQUssQ0FBQyxFQUN0RC9DLElBQUksQ0FBQ2hDLE1BQU0sQ0FBQ0EsRUFBRXBELFFBQVFpRyxLQUFLN0MsRUFBRXBELE9BQU8sQ0FBQztBQUFBLG9CQUMxQyxFQUFFb0wsT0FBTztBQUFBLGtCQUNYLEVBQUVoRztBQUFBQSxvQkFBSSxDQUFDaUcsU0FDTCx1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBS3BGLEtBQ3ZDb0YsZUFBS2xGLGFBRFlrRixLQUFLcEYsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkF0Q0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBdUNBO0FBQUEsY0FDQ3ZHLE9BQU9NLFdBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qk4saUJBQU9NLFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsaUJBN0M3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStDQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDNUMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0w7QUFBQSxrQkFDQSxhQUFZO0FBQUEsa0JBQ1osV0FBVyxxQ0FBcUMxQyxVQUFVc04sTUFBTTtBQUFBLGtCQUNoRSxPQUFPOUssU0FBU3FCO0FBQUFBLGtCQUNoQixVQUFVLENBQUNtSywwQkFBMEI7QUFDbkN2TCxnQ0FBWSxDQUFDdUosVUFBVTtBQUFBLHNCQUNyQixHQUFHQTtBQUFBQSxzQkFDSG5JLGdCQUFnQm1LO0FBQUFBLG9CQUNsQixFQUFFO0FBQUEsa0JBQ0o7QUFBQSxrQkFDQSxjQUFjLENBQUNQLE9BQU9DLFdBQ3BCQSxRQUFRcEUsT0FBT21ELFlBQVksRUFBRTlCLFNBQVM4QyxNQUFNaEIsWUFBWSxDQUFDO0FBQUEsa0JBRzFEbkssOEJBQW9Cd0YsSUFBSSxDQUFDbUcsT0FBTztBQUMvQiwwQkFBTUMsUUFBUTtBQUNkLHdCQUFJRCxHQUFHN0YsY0FBYzZGLEdBQUc3RixlQUFlO0FBQ3JDOEYsNEJBQU1DLEtBQUtGLEdBQUc3RixVQUFVO0FBQzFCLHdCQUFJNkYsR0FBRzVGLFVBQVU0RixHQUFHNUYsV0FBVztBQUM3QjZGLDRCQUFNQyxLQUFLLFdBQVdGLEdBQUc1RixNQUFNLEVBQUU7QUFDbkMsMkJBQ0UsdUJBQUMsT0FBTyxRQUFQLEVBQTJCLE9BQU80RixHQUFHdEYsS0FDbkN1RixnQkFBTTNGLEtBQUssS0FBSyxLQURDMEYsR0FBR3RGLEtBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFFSixDQUFDO0FBQUE7QUFBQSxnQkEzQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBNEJBO0FBQUEsY0FFQ3ZHLE9BQU95QixrQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z6QixpQkFBT3lCLGtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFyQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1Q0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBZTtBQUFBO0FBQUEsb0JBRUYsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSnhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQzdELFVBQVVzTixNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDRyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU2xCLFlBQVksRUFBRTlCLFNBQVM4QyxNQUFNaEIsWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU9qSyxVQUFVdUIsOEJBQThCd0o7QUFBQUEsa0JBQy9DLFVBQVUsQ0FBQ3hILFVBQ1QwRCxpQkFBaUIsOEJBQThCMUQsS0FBSztBQUFBLGtCQUdyRCxXQUFDLFlBQVksZUFBZSxVQUFVLEVBQUUrQjtBQUFBQSxvQkFBSSxDQUFDc0csWUFDNUMsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLFNBQ2pDQSxxQkFEaUJBLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW1CQTtBQUFBLGNBQ0NoTSxPQUFPMkIsOEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWM0IsaUJBQU8yQiw4QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBOUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0NBO0FBQUEsWUFFQ3ZCLFNBQVN1QiwrQkFBK0IsY0FDdkMsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQVU7QUFBQTtBQUFBLHNCQUVXO0FBQUEsc0JBQzdCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHFDQUFxQy9ELFVBQVVzTixNQUFNO0FBQUEsb0JBQ2hFLGFBQVk7QUFBQSxvQkFDWix1QkFBdUI7QUFBQSxvQkFDdkI7QUFBQSxvQkFDQSxNQUFLO0FBQUEsb0JBQ0wsY0FBYyxDQUFDRyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSlUsU0FBUyxFQUNUNUIsWUFBWSxFQUNaOUIsU0FBUzhDLE1BQU1oQixZQUFZLENBQUM7QUFBQSxvQkFFakMsT0FBT2pLLFVBQVVLLHFCQUFxQjBLO0FBQUFBLG9CQUN0QyxVQUFVLENBQUN4SCxVQUNUMEQsaUJBQWlCLHFCQUFxQjFELEtBQUs7QUFBQSxvQkFHNUMxRixnQkFBTXlIO0FBQUFBLHNCQUFJLENBQUNpRyxTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLcEYsS0FDdkNvRixlQUFLbEYsYUFEWWtGLEtBQUtwRixLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBc0JBO0FBQUEsZ0JBQ0N2RyxPQUFPUyxxQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZULGlCQUFPUyxxQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBbkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUNBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVGLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9MLFNBQVNvQjtBQUFBQSxvQkFDaEIsVUFBVWtHO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFCQUFxQjlKLFVBQVVzTixNQUFNO0FBQUE7QUFBQSxrQkFSbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVE2RztBQUFBLGdCQUU1R2xMLE9BQU93Qiw0QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z4QixpQkFBT3dCLDRCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxpQkE3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4REE7QUFBQSxZQUVEcEIsU0FBU3VCLCtCQUErQixpQkFDdkMsdUJBQUMsU0FBSSxXQUFVLGtCQUViO0FBQUEscUNBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHlEQUF3RCxvQ0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQzVDO0FBQUEsc0JBQ2xCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT3ZCLFNBQVNHO0FBQUFBLHdCQUNoQixVQUFVbUg7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9nSjtBQUFBLG9CQUUvSTFILE9BQU9PLHFCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlAsaUJBQU9PLHFCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtQkE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLHNCQUNqRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9ILFNBQVNNO0FBQUFBLHdCQUNoQixVQUFVZ0g7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9nSjtBQUFBLG9CQUUvSTFILE9BQU9VLDZCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlYsaUJBQU9VLDZCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFrQkE7QUFBQSxxQkF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF3Q0E7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsNENBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLGNBQWMsQ0FBQzJLLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKbEIsWUFBWSxFQUNaOUIsU0FBUzhDLE1BQU1oQixZQUFZLENBQUM7QUFBQSx3QkFFakMsT0FDRWpLLFNBQVM2QixrQ0FBa0NrSjtBQUFBQSx3QkFFN0MsVUFBVSxDQUFDeEgsVUFDVDBEO0FBQUFBLDBCQUNFO0FBQUEsMEJBQ0ExRDtBQUFBQSx3QkFDRjtBQUFBLHdCQUdELFdBQUMsVUFBVSxVQUFVLE9BQU8sRUFBRStCO0FBQUFBLDBCQUFJLENBQUN3RyxRQUNsQyx1QkFBQyxPQUFPLFFBQVAsRUFBd0IsT0FBT0EsS0FDN0JBLGlCQURpQkEsS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLHdCQUNEO0FBQUE7QUFBQSxzQkF4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXlCQTtBQUFBLG9CQUNDbE0sT0FBT2lDLGtDQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmpDLGlCQUFPaUMsa0NBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWpDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW1DQTtBQUFBLGtCQUVDN0IsU0FBUzZCLG1DQUFtQyxXQUMzQyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsZ0RBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsV0FBVTtBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixPQUFPbkM7QUFBQUEsd0JBQ1AsVUFBVSxDQUFDNEQsTUFDVDNELHNCQUFzQjJELEVBQUVFLE9BQU9ELEtBQUs7QUFBQTtBQUFBLHNCQU54QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0c7QUFBQSx1QkFYTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFBO0FBQUEscUJBcERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBc0RBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHFCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPdkQsU0FBU0k7QUFBQUEsd0JBQ2hCLFVBQVVrSDtBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT2dKO0FBQUEsb0JBRS9JMUgsT0FBT1Esc0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWUixpQkFBT1Esc0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyw2QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FDRUosU0FBU2EsMkJBQ0wsSUFBSWtMLEtBQUsvTCxTQUFTYSx3QkFBd0IsRUFDdkNtTCxZQUFZLEVBQ1pDLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFDZjtBQUFBLHdCQUVOLFVBQVUzRTtBQUFBQSx3QkFDVixXQUFVO0FBQUE7QUFBQSxzQkFYWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBV2dKO0FBQUEsdUJBZmxKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUJBO0FBQUEscUJBckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBc0NBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDhCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLE1BQUs7QUFBQSx3QkFDTCxjQUFjLENBQUMyRCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmxCLFlBQVksRUFDWjlCLFNBQVM4QyxNQUFNaEIsWUFBWSxDQUFDO0FBQUEsd0JBRWpDLE9BQ0VqSyxTQUFTWSwrQkFBK0JtSztBQUFBQSx3QkFFMUMsVUFBVSxDQUFDeEgsVUFDVDBEO0FBQUFBLDBCQUNFO0FBQUEsMEJBQ0ExRDtBQUFBQSx3QkFDRjtBQUFBLHdCQUdELFdBQUMsV0FBVyxhQUFhLFNBQVMsVUFBVSxFQUFFK0I7QUFBQUEsMEJBQzdDLENBQUM0RyxXQUNDLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPQSxRQUNoQ0Esb0JBRGlCQSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBRUo7QUFBQTtBQUFBLHNCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBMkJBO0FBQUEsdUJBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZ0NBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHNCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLE1BQUs7QUFBQSx3QkFDTCxjQUFjLENBQUNqQixPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmxCLFlBQVksRUFDWjlCLFNBQVM4QyxNQUFNaEIsWUFBWSxDQUFDO0FBQUEsd0JBRWpDLE9BQU9qSyxTQUFTVyx1QkFBdUJvSztBQUFBQSx3QkFDdkMsVUFBVSxDQUFDeEgsVUFDVDBELGlCQUFpQix1QkFBdUIxRCxLQUFLO0FBQUEsd0JBRzlDLFdBQUMsUUFBUSxRQUFRLEVBQUUrQjtBQUFBQSwwQkFBSSxDQUFDNkcsTUFDdkIsdUJBQUMsT0FBTyxRQUFQLEVBQXNCLE9BQU9BLEdBQzNCQSxlQURpQkEsR0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLHdCQUNEO0FBQUE7QUFBQSxzQkFuQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQW9CQTtBQUFBLHVCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXlCQTtBQUFBLHFCQTNERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTREQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsb0JBQ3RELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsT0FBT25NLFNBQVNPO0FBQUFBLHNCQUNoQixVQUFVK0c7QUFBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsV0FBVTtBQUFBO0FBQUEsb0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9rRztBQUFBLGtCQUVqRzFILE9BQU9XLHdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlgsaUJBQU9XLHdCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFrQkE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9QLFNBQVNlO0FBQUFBLHdCQUNoQixVQUFVdUc7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSx1QkFWcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyxxQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT3RILFNBQVNnQjtBQUFBQSx3QkFDaEIsVUFBVXNHO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTWtHO0FBQUEsdUJBVnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWUE7QUFBQSxxQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEyQkE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MscUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLGNBQWMsQ0FBQzJELE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKbEIsWUFBWSxFQUNaOUIsU0FBUzhDLE1BQU1oQixZQUFZLENBQUM7QUFBQSx3QkFFakMsT0FBT2pLLFNBQVNtQixzQkFBc0I0SjtBQUFBQSx3QkFDdEMsVUFBVSxDQUFDeEgsVUFDVDBELGlCQUFpQixzQkFBc0IxRCxLQUFLO0FBQUEsd0JBRzdDLFdBQUMsYUFBYSxlQUFlLFlBQVksRUFBRStCO0FBQUFBLDBCQUMxQyxDQUFDOEcsVUFDQyx1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsT0FDL0JBLG1CQURpQkEsT0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLHdCQUVKO0FBQUE7QUFBQSxzQkFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXNCQTtBQUFBLHVCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTJCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyx3QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT3BNLFNBQVNrQjtBQUFBQSx3QkFDaEIsVUFBVW9HO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTWtHO0FBQUEsdUJBVnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWUE7QUFBQSxxQkF6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEwQ0E7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLHNCQUN0RCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU90SCxTQUFTUTtBQUFBQSx3QkFDaEIsVUFBVThHO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPa0c7QUFBQSxvQkFFakcxSCxPQUFPWSx3QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZaLGlCQUFPWSx3QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDJCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPUixTQUFTaUI7QUFBQUEsd0JBQ2hCLFVBQVVxRztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1rRztBQUFBLHVCQVZwRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEscUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBaUNBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDJCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLE1BQUs7QUFBQSx3QkFDTCxjQUFjLENBQUMyRCxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmxCLFlBQVksRUFDWjlCLFNBQVM4QyxNQUFNaEIsWUFBWSxDQUFDO0FBQUEsd0JBRWpDLE9BQU9qSyxTQUFTYyw0QkFBNEJpSztBQUFBQSx3QkFDNUMsVUFBVSxDQUFDeEgsVUFDVDBELGlCQUFpQiw0QkFBNEIxRCxLQUFLO0FBQUEsd0JBR25ELFdBQUMsVUFBVSxPQUFPLEVBQUUrQjtBQUFBQSwwQkFBSSxDQUFDK0csV0FDeEIsdUJBQUMsT0FBTyxRQUFQLEVBQTJCLE9BQU9BLFFBQ2hDQSxvQkFEaUJBLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSx3QkFDRDtBQUFBO0FBQUEsc0JBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFvQkE7QUFBQSx1QkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF5QkE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0Msc0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9yTSxTQUFTc0I7QUFBQUEsd0JBQ2hCLFVBQVVnRztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1rRztBQUFBLHVCQVZwRztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVlBO0FBQUEscUJBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBd0NBO0FBQUEsbUJBOVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBK1hBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUseURBQXdELDZCQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxzQkFDL0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBLHlCQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPdEgsU0FBU1M7QUFBQUEsd0JBQ2hCLFVBQVU2RztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT2tHO0FBQUEsb0JBRWpHMUgsT0FBT2EsMEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWYixpQkFBT2EsMEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQ25ELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT1QsU0FBU1U7QUFBQUEsd0JBQ2hCLFVBQVU0RztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT2tHO0FBQUEsb0JBRWpHMUgsT0FBT2MsdUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWZCxpQkFBT2MsdUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtCQTtBQUFBLHFCQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXVDQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsb0JBQ2hELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSwwQkFFYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFNBQVE7QUFBQSx3QkFDUixXQUFVO0FBQUEsd0JBRVY7QUFBQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxXQUFVO0FBQUEsOEJBQ1YsTUFBSztBQUFBLDhCQUNMLFFBQU87QUFBQSw4QkFDUCxTQUFRO0FBQUEsOEJBRVI7QUFBQSxnQ0FBQztBQUFBO0FBQUEsa0NBQ0MsZUFBYztBQUFBLGtDQUNkLGdCQUFlO0FBQUEsa0NBQ2YsYUFBYTtBQUFBLGtDQUNiLEdBQUU7QUFBQTtBQUFBLGdDQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFJbUQ7QUFBQTtBQUFBLDRCQVZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBWUE7QUFBQSwwQkFDQSx1QkFBQyxPQUFFLFdBQVUscUNBQW9DO0FBQUE7QUFBQSw0QkFDL0IsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFHO0FBQUEsNEJBQ25CLHVCQUFDLFVBQUssV0FBVSxXQUFVLDBCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFvQztBQUFBLCtCQUZ0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUdBO0FBQUEsMEJBRUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsSUFBRztBQUFBLDhCQUNILE1BQUs7QUFBQSw4QkFDTCxNQUFLO0FBQUEsOEJBQ0wsVUFBVXlKO0FBQUFBLDhCQUNWLFFBQU87QUFBQSw4QkFDUDtBQUFBLDhCQUNBLFdBQVU7QUFBQTtBQUFBLDRCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFPb0I7QUFBQTtBQUFBO0FBQUEsc0JBN0J0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBK0JBO0FBQUEsb0JBR0NuSyxTQUFTc00sNkJBQ1IsdUJBQUMsUUFBSyxJQUFJdE0sU0FBUzBCLG9CQUFvQixVQUFRLE1BQzdDO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLEtBQUsxQixTQUFTc007QUFBQUEsd0JBQ2QsS0FBSTtBQUFBLHdCQUNKLFdBQVU7QUFBQTtBQUFBLHNCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFHZ0UsS0FKbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFNQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxzRkFBcUYsMEJBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkEvQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpREE7QUFBQSxrQkFHQzFNLE9BQU84QixzQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y5QixpQkFBTzhCLHNCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkE1REo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE4REE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLHNCQUMvQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxTQUFRO0FBQUEsMEJBQ1IsV0FBVTtBQUFBLDBCQUVWO0FBQUEsbURBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsOEJBQy9CLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBRztBQUFBLDhCQUNuQix1QkFBQyxVQUFLLFdBQVUsV0FBVSwwQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBb0M7QUFBQSxpQ0FGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FHQTtBQUFBLDRCQUVBO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLElBQUc7QUFBQSxnQ0FDSCxNQUFLO0FBQUEsZ0NBQ0wsTUFBSztBQUFBLGdDQUNMLFVBQVV5STtBQUFBQSxnQ0FDVixRQUFPO0FBQUEsZ0NBQ1A7QUFBQSxnQ0FDQSxXQUFVO0FBQUE7QUFBQSw4QkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBT29CO0FBQUE7QUFBQTtBQUFBLHdCQWhCdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWtCQTtBQUFBLHNCQUVDbkssU0FBU3VNLG9DQUNSO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLElBQUl2TSxTQUFTMkI7QUFBQUEsMEJBQ2IsVUFBUTtBQUFBLDBCQUVSO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLEtBQUszQixTQUFTdU07QUFBQUEsOEJBQ2QsV0FBVTtBQUFBO0FBQUEsNEJBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUVnRTtBQUFBO0FBQUEsd0JBTmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFRQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxzRkFBcUYsMEJBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFsQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFvQ0E7QUFBQSxvQkFFQzNNLE9BQU8rQiw2QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1YvQixpQkFBTytCLDZCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkE5Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFnREE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLHNCQUMzQztBQUFBLHNCQUNuQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxvQkFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxTQUFRO0FBQUEsMEJBQ1IsV0FBVTtBQUFBLDBCQUVWO0FBQUEsbURBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsOEJBQy9CLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBRztBQUFBLDhCQUNuQix1QkFBQyxVQUFLLFdBQVUsV0FBVSwwQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBb0M7QUFBQSxpQ0FGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FHQTtBQUFBLDRCQUVBO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLElBQUc7QUFBQSxnQ0FDSCxNQUFLO0FBQUEsZ0NBQ0wsTUFBSztBQUFBLGdDQUNMLFVBQVV3STtBQUFBQSxnQ0FDVixRQUFPO0FBQUEsZ0NBQ1A7QUFBQSxnQ0FDQSxXQUFVO0FBQUE7QUFBQSw4QkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBT29CO0FBQUE7QUFBQTtBQUFBLHdCQWhCdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWtCQTtBQUFBLHNCQUVDbkssU0FBU3dNLHVDQUNSO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLElBQUl4TSxTQUFTNEI7QUFBQUEsMEJBQ2IsVUFBUTtBQUFBLDBCQUVSO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLEtBQ0U1QixTQUFTd007QUFBQUEsOEJBRVgsV0FBVTtBQUFBO0FBQUEsNEJBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUlnRTtBQUFBO0FBQUEsd0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFVQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxzRkFBcUYsMEJBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFwQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFzQ0E7QUFBQSxvQkFFQzVNLE9BQU9nQyxnQ0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZoQyxpQkFBT2dDLGdDQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFqREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFtREE7QUFBQSxxQkFyR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFzR0E7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLHlDQUFDLFFBQUcsV0FBVSw4QkFBNkIsb0NBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQzZCLFVBQVU2QjtBQUFBQSxvQkFBSSxDQUFDK0QsS0FBSy9FLFVBQ25CO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUVDLFdBQVU7QUFBQSx3QkFHVjtBQUFBLGlEQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLE1BQUs7QUFBQSxnQ0FDTCxhQUFZO0FBQUEsZ0NBQ1osT0FBTytFLElBQUkxRjtBQUFBQSxnQ0FDWCxVQUFVLENBQUNMLE1BQ1RlLHlCQUF5QkMsT0FBT2hCLENBQUM7QUFBQSxnQ0FFbkMsV0FBVTtBQUFBO0FBQUEsOEJBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQU84RDtBQUFBLDRCQUU5RDtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxNQUFLO0FBQUEsZ0NBQ0wsTUFBSztBQUFBLGdDQUNMLFVBQVUsQ0FBQ0EsTUFDVGtCLHlCQUF5QkYsT0FBT2hCLENBQUM7QUFBQSxnQ0FFbkMsUUFBTztBQUFBLGdDQUNQLFdBQVU7QUFBQTtBQUFBLDhCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFPMEQ7QUFBQSw0QkFFMUQ7QUFBQSw4QkFBQztBQUFBO0FBQUEsZ0NBQ0MsTUFBSztBQUFBLGdDQUNMLFNBQVMsTUFBTXVCLGVBQWVQLEtBQUs7QUFBQSxnQ0FDbkMsV0FBVTtBQUFBLGdDQUVWLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FBVTtBQUFBO0FBQUEsOEJBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQU1BO0FBQUEsK0JBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBMEJBO0FBQUEsMEJBR0MrRSxJQUFJeEYsV0FDSCx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxLQUFLd0YsSUFBSXhGO0FBQUFBLDhCQUNULEtBQUt3RixJQUFJMUY7QUFBQUEsOEJBQ1QsV0FBVTtBQUFBO0FBQUEsNEJBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUdzRCxLQUp4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQU1BO0FBQUE7QUFBQTtBQUFBLHNCQXhDR1c7QUFBQUEsc0JBRFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkEyQ0E7QUFBQSxrQkFDRDtBQUFBLGtCQUVEO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxTQUFTTTtBQUFBQSxzQkFDVCxXQUFVO0FBQUEsc0JBQStFO0FBQUE7QUFBQSxvQkFIM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1BO0FBQUEscUJBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBMERBO0FBQUEsbUJBbFJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbVJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsNERBQ2I7QUFBQSx1Q0FBQyxRQUFHLFdBQVUseURBQXdELGtDQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDJDQUViLGlDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQyx1Q0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUdBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVU7QUFBQSxzQkFDVixhQUFZO0FBQUEsc0JBQ1o7QUFBQSxzQkFDQSxPQUFPNUUsU0FBUzhCLDJCQUEyQmlKO0FBQUFBLHNCQUMzQyxVQUFVLENBQUN4SCxVQUFVO0FBRW5CdEQsb0NBQVksQ0FBQ3VKLFVBQVU7QUFBQSwwQkFDckIsR0FBR0E7QUFBQUEsMEJBQ0gxSCx5QkFBeUJ5QjtBQUFBQSwwQkFDekJULDZCQUE2QjtBQUFBLDBCQUM3Qk4sNkJBQTZCO0FBQUEsMEJBQzdCQyw2QkFBNkI7QUFBQSwwQkFDN0JDLGdDQUFnQztBQUFBLDBCQUNoQ0MsOEJBQThCO0FBQUEsMEJBQzlCQywwQkFBMEI7QUFBQSwwQkFDMUJDLDRCQUE0QjtBQUFBLHdCQUM5QixFQUFFO0FBQUEsc0JBQ0o7QUFBQSxzQkFDQSxjQUFjLENBQUNvSSxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmxCLFlBQVksRUFDWjlCLFNBQVM4QyxNQUFNaEIsWUFBWSxDQUFDO0FBQUEsc0JBR2hDO0FBQUEsd0JBQ0M7QUFBQSx3QkFDQTtBQUFBLHdCQUNBO0FBQUEsd0JBQ0E7QUFBQSx3QkFDQTtBQUFBLHNCQUFPLEVBQ1AzRTtBQUFBQSx3QkFBSSxDQUFDbUgsUUFDTCx1QkFBQyxPQUFPLFFBQVAsRUFBd0IsT0FBT0EsS0FDN0JBLGlCQURpQkEsS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLHNCQUNEO0FBQUE7QUFBQSxvQkFuQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW9DQTtBQUFBLGtCQUNDN00sT0FBT2tDLDJCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmxDLGlCQUFPa0MsMkJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUdEOUIsU0FBUzhCLDRCQUE0QixXQUNwQyxtQ0FDRTtBQUFBLDJDQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQywwQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLFdBQVU7QUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1o7QUFBQSwwQkFDQSxPQUNFOUIsU0FBUzhDLCtCQUNUaUk7QUFBQUEsMEJBRUYsVUFBVSxDQUFDeEgsVUFDVHRELFlBQVksQ0FBQ3VKLFVBQVU7QUFBQSw0QkFDckIsR0FBR0E7QUFBQUEsNEJBQ0gxRyw2QkFBNkJTO0FBQUFBLDBCQUMvQixFQUFFO0FBQUEsMEJBRUosY0FBYyxDQUFDMEgsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0psQixZQUFZLEVBQ1o5QixTQUFTOEMsTUFBTWhCLFlBQVksQ0FBQztBQUFBLDBCQUdoQztBQUFBLDRCQUNDO0FBQUEsNEJBQ0E7QUFBQSw0QkFDQTtBQUFBLDRCQUNBO0FBQUEsNEJBQ0E7QUFBQSwwQkFBa0MsRUFDbEMzRTtBQUFBQSw0QkFBSSxDQUFDb0gsUUFDTCx1QkFBQyxPQUFPLFFBQVAsRUFBd0IsT0FBT0EsS0FDN0JBLGlCQURpQkEsS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDBCQUNEO0FBQUE7QUFBQSx3QkE5Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQStCQTtBQUFBLHNCQUNDOU0sT0FBT2tELCtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmxELGlCQUFPa0QsK0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQXZDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXlDQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FBTzlDLFNBQVMwQztBQUFBQSwwQkFDaEIsVUFBVTRFO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTThJO0FBQUEsc0JBRTdJMUgsT0FBTzhDLGtDQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsa0NBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBO0FBQUEsdUJBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBNkRBO0FBQUEsa0JBSUQsQ0FBQyxpQkFBaUIsVUFBVSxFQUFFeUY7QUFBQUEsb0JBQzdCbkksU0FBUzhCO0FBQUFBLGtCQUNYLEtBQ0UsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDZCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUFPOUIsU0FBU3dDO0FBQUFBLDBCQUNoQixVQUFVOEU7QUFBQUEsMEJBQ1YsYUFBWTtBQUFBLDBCQUNaLFdBQVU7QUFBQTtBQUFBLHdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFNOEk7QUFBQSxzQkFFN0kxSCxPQUFPNEMsK0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWNUMsaUJBQU80QywrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFpQkE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsNkJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQU94QyxTQUFTeUM7QUFBQUEsMEJBQ2hCLFVBQVU2RTtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU04STtBQUFBLHNCQUU3STFILE9BQU82QywrQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y3QyxpQkFBTzZDLCtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWlCQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FBT3pDLFNBQVMwQztBQUFBQSwwQkFDaEIsVUFBVTRFO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTThJO0FBQUEsc0JBRTdJMUgsT0FBTzhDLGtDQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsa0NBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBO0FBQUEsdUJBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBdURBO0FBQUEsa0JBSUQxQyxTQUFTOEIsNEJBQ1Isa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLCtCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUFPOUIsU0FBUzJDO0FBQUFBLDBCQUNoQixVQUFVMkU7QUFBQUEsMEJBQ1YsYUFBWTtBQUFBLDBCQUNaLFdBQVU7QUFBQTtBQUFBLHdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFNOEk7QUFBQSxzQkFFN0kxSCxPQUFPK0MsZ0NBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWL0MsaUJBQU8rQyxnQ0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFpQkE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQU8zQyxTQUFTMEM7QUFBQUEsMEJBQ2hCLFVBQVU0RTtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU04STtBQUFBLHNCQUU3STFILE9BQU84QyxrQ0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y5QyxpQkFBTzhDLGtDQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWlCQTtBQUFBLHVCQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXFDQTtBQUFBLGtCQUlEMUMsU0FBUzhCLDRCQUE0QixpQkFDcEMsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUFPOUIsU0FBUzRDO0FBQUFBLDBCQUNoQixVQUFVMEU7QUFBQUEsMEJBQ1YsYUFBWTtBQUFBLDBCQUNaLFdBQVU7QUFBQTtBQUFBLHdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFNOEk7QUFBQSxzQkFFN0kxSCxPQUFPZ0QsNEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWaEQsaUJBQU9nRCw0QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFpQkE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0Msd0NBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQU81QyxTQUFTNkM7QUFBQUEsMEJBQ2hCLFVBQVV5RTtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU04STtBQUFBLHNCQUU3STFILE9BQU9pRCw4QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZqRCxpQkFBT2lELDhCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQWlCQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FBTzdDLFNBQVMwQztBQUFBQSwwQkFDaEIsVUFBVTRFO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTThJO0FBQUEsc0JBRTdJMUgsT0FBTzhDLGtDQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsa0NBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBO0FBQUEsdUJBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBdURBO0FBQUEsa0JBSUQxQyxTQUFTOEIsNEJBQTRCLFdBQ3BDOUIsU0FBUzhDLGdDQUNQLHNDQUNBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU85QyxTQUFTMEM7QUFBQUEsd0JBQ2hCLFVBQVU0RTtBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU04STtBQUFBLG9CQUU3STFILE9BQU84QyxrQ0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y5QyxpQkFBTzhDLGtDQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlCQTtBQUFBLHFCQTVTTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQThTQSxLQWhURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlUQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsb0JBQ3JDO0FBQUEsb0JBQ3pCLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFNBQVE7QUFBQSx3QkFDUixXQUFVO0FBQUEsd0JBRVY7QUFBQSxpREFBQyxPQUFFLFdBQVUscUNBQW9DO0FBQUE7QUFBQSw0QkFDL0IsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFHO0FBQUEsNEJBQ25CLHVCQUFDLFVBQUssV0FBVSxXQUFVLDBCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFvQztBQUFBLCtCQUZ0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUdBO0FBQUEsMEJBRUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsSUFBRztBQUFBLDhCQUNILE1BQUs7QUFBQSw4QkFDTCxNQUFLO0FBQUEsOEJBQ0wsVUFBVXlIO0FBQUFBLDhCQUNWLFFBQU87QUFBQSw4QkFDUDtBQUFBLDhCQUNBLFdBQVU7QUFBQTtBQUFBLDRCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFPb0I7QUFBQTtBQUFBO0FBQUEsc0JBaEJ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBa0JBO0FBQUEsb0JBRUNuSyxTQUFTMk0sdUNBQ1I7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsSUFBSTNNLFNBQVNnQztBQUFBQSx3QkFDYixVQUFRO0FBQUEsd0JBRVI7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsS0FDRWhDLFNBQVMyTTtBQUFBQSw0QkFFWCxXQUFVO0FBQUE7QUFBQSwwQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBSWdFO0FBQUE7QUFBQSxzQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVVBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHNGQUFxRiwwQkFBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQXBDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXNDQTtBQUFBLGtCQUVDL00sT0FBT29DLGdDQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnBDLGlCQUFPb0MsZ0NBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQWpESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1EQTtBQUFBLG1CQTVXRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTZXQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHlEQUF3RCw0QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyx5QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT2hDLFNBQVNrQztBQUFBQSx3QkFDaEIsVUFBVW9GO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTWtHO0FBQUEsb0JBRWpHMUgsT0FBT3NDLDBCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnRDLGlCQUFPc0MsMEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLG1DQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPbEMsU0FBU21DO0FBQUFBLHdCQUNoQixVQUFVbUY7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSxvQkFFakcxSCxPQUFPdUMsb0NBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWdkMsaUJBQU91QyxvQ0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQSxxQkFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFxQ0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsMkJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU9uQyxTQUFTb0M7QUFBQUEsd0JBQ2hCLFVBQVVrRjtBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1osV0FBVTtBQUFBO0FBQUEsc0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU1rRztBQUFBLG9CQUVqRzFILE9BQU93Qyw0QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z4QyxpQkFBT3dDLDRCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWlCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyw4QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT3BDLFNBQVNxQztBQUFBQSx3QkFDaEIsVUFBVWlGO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTWtHO0FBQUEsb0JBRWpHMUgsT0FBT3lDLCtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnpDLGlCQUFPeUMsK0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUJBO0FBQUEscUJBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcUNBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx5Q0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxvQkFDaEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBLHVCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUE7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsU0FBUTtBQUFBLHdCQUNSLFdBQVU7QUFBQSx3QkFFVjtBQUFBLGlEQUFDLE9BQUUsV0FBVSxxQ0FBb0M7QUFBQTtBQUFBLDRCQUMvQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQUc7QUFBQSw0QkFDbkIsdUJBQUMsVUFBSyxXQUFVLFdBQVUsMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQW9DO0FBQUEsK0JBRnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBR0E7QUFBQSwwQkFFQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxJQUFHO0FBQUEsOEJBQ0gsTUFBSztBQUFBLDhCQUNMLE1BQUs7QUFBQSw4QkFDTCxVQUFVOEg7QUFBQUEsOEJBQ1YsUUFBTztBQUFBLDhCQUNQO0FBQUEsOEJBQ0EsV0FBVTtBQUFBO0FBQUEsNEJBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQU9vQjtBQUFBO0FBQUE7QUFBQSxzQkFoQnRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFrQkE7QUFBQSxvQkFFQ25LLFNBQVM0TSwyQ0FDUjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxJQUFJNU0sU0FBU3VDO0FBQUFBLHdCQUNiLFVBQVE7QUFBQSx3QkFFUjtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxLQUNFdkMsU0FBUzRNO0FBQUFBLDRCQUVYLFdBQVU7QUFBQTtBQUFBLDBCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFJZ0U7QUFBQTtBQUFBLHNCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBVUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsc0ZBQXFGLDBCQUFwRztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBcENKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBc0NBO0FBQUEsa0JBRUNoTixPQUFPMkMsb0NBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWM0MsaUJBQU8yQyxvQ0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBaERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0RBO0FBQUEsbUJBcklGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0lBO0FBQUEsaUJBL29DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdwQ0E7QUFBQSxZQUVEdkMsU0FBU3VCLCtCQUErQixjQUN2QyxtQ0FDRTtBQUFBLHFDQUFDLFNBQ0M7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFPO0FBQUE7QUFBQSxzQkFFRCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPdkIsU0FBU3dCO0FBQUFBLG9CQUNoQixVQUFVOEY7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUJBQXFCOUosVUFBVXNOLE1BQU07QUFBQTtBQUFBLGtCQVJsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZHO0FBQUEsZ0JBRTVHbEwsT0FBTzRCLDhCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjVCLGlCQUFPNEIsOEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGNBQ0EsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGtCQUM1Qyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxTQUFRO0FBQUEsc0JBQ1IsV0FBVTtBQUFBLHNCQUVWO0FBQUEsK0NBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsMEJBQy9CLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBRztBQUFBLDBCQUNuQix1QkFBQyxVQUFLLFdBQVUsV0FBVSwwQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBb0M7QUFBQSw2QkFGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFHQTtBQUFBLHdCQUVBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLElBQUc7QUFBQSw0QkFDSCxNQUFLO0FBQUEsNEJBQ0wsTUFBSztBQUFBLDRCQUNMLFVBQVUySTtBQUFBQSw0QkFDVixRQUFPO0FBQUEsNEJBQ1A7QUFBQSw0QkFDQSxXQUFVO0FBQUE7QUFBQSwwQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBT29CO0FBQUE7QUFBQTtBQUFBLG9CQWhCdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWtCQTtBQUFBLGtCQUVDbkssU0FBUzZNLGdDQUNSLHVCQUFDLFFBQUssSUFBSTdNLFNBQVN5Qix1QkFBdUIsVUFBUSxNQUNoRDtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxLQUFLekIsU0FBUzZNO0FBQUFBLHNCQUNkLFdBQVU7QUFBQTtBQUFBLG9CQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFZ0UsS0FIbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFLQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxzRkFBcUYsMEJBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkEvQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFpQ0E7QUFBQSxnQkFFQ2pOLE9BQU82Qix5QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y3QixpQkFBTzZCLHlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkEzQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE2Q0E7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFPO0FBQUE7QUFBQSxzQkFFSCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPekIsU0FBU29CO0FBQUFBLG9CQUNoQixVQUFVa0c7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUJBQXFCOUosVUFBVXNOLE1BQU07QUFBQTtBQUFBLGtCQVJsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZHO0FBQUEsZ0JBRTVHbEwsT0FBT3dCLDRCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnhCLGlCQUFPd0IsNEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGlCQTVGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZGQTtBQUFBLFlBR0YsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDK0Y7QUFBQTtBQUFBLGNBSDNHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBO0FBQUE7QUFBQSxRQS83Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BZzhDQTtBQUFBLFNBcDhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcThDQSxLQXQ4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXU4Q0E7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXM0M7QUFBQUEsUUFDWCxTQUFTLE1BQU1DLG1CQUFtQixLQUFLO0FBQUEsUUFFdkMsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxtQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVWdMLGNBQWMsWUFBVSxNQUM1RDtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDaEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQ2xNLFVBQVVzTixNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWjtBQUFBLGtCQUNBLE9BQU83SCxlQUFlL0MsV0FBVztBQUFBLGtCQUNqQyxVQUFVLENBQUNxRCxVQUFVO0FBQ25CTCxzQ0FBa0IsQ0FBQ3NHLFVBQVU7QUFBQSxzQkFDM0IsR0FBR0E7QUFBQUEsc0JBQ0h0SixTQUFTcUQ7QUFBQUEsc0JBQ1RsQyxnQkFBZ0I7QUFBQTtBQUFBLG9CQUNsQixFQUFFO0FBRUYsMEJBQU0ySixXQUFXN0wsV0FDZDJGLE9BQU8sQ0FBQ3hCLE1BQU1BLEVBQUVwRCxTQUFTaUcsUUFBUTVDLEtBQUssRUFDdEMrQixJQUFJLENBQUNoQyxPQUFPO0FBQUEsc0JBQ1g2QyxLQUFLN0MsRUFBRTZDO0FBQUFBLHNCQUNQUCxZQUFZdEMsRUFBRXFDLFVBQVVDO0FBQUFBLHNCQUN4QkMsUUFBUXZDLEVBQUV3QztBQUFBQSxvQkFDWixFQUFFO0FBRUovRiwyQ0FBdUJpTCxRQUFRO0FBQUEsa0JBQ2pDO0FBQUEsa0JBQ0EsY0FBYyxDQUFDQyxPQUFPQyxXQUNwQkEsUUFBUXBFLE9BQU9tRCxZQUFZLEVBQUU5QixTQUFTOEMsTUFBTWhCLFlBQVksQ0FBQztBQUFBLGtCQUcxRDlLLHFCQUNFMkYsT0FBTyxDQUFDeEIsTUFBTUEsRUFBRXBELFdBQVdvRCxFQUFFcEQsUUFBUW1HLFdBQVdnQyxLQUFLLENBQUMsRUFDdEQvQztBQUFBQSxvQkFBSSxDQUFDaEMsTUFDSix1QkFBQyxPQUFPLFFBQVAsRUFBa0MsT0FBT0EsRUFBRXBELFFBQVFpRyxLQUNqRDdDLFlBQUVwRCxRQUFRbUcsYUFETy9DLEVBQUVwRCxRQUFRaUcsS0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFoQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBaUNBO0FBQUEsY0FDQ3ZHLE9BQU9NLFdBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2Qk4saUJBQU9NLFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlEO0FBQUEsaUJBdkM3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlDQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDNUMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0w7QUFBQSxrQkFDQSxhQUFZO0FBQUEsa0JBQ1osV0FBVyxxQ0FBcUMxQyxVQUFVc04sTUFBTTtBQUFBLGtCQUNoRSxPQUFPN0gsZUFBZTVCO0FBQUFBLGtCQUN0QixVQUFVLENBQUNtSywwQkFBMEI7QUFDbkN0SSxzQ0FBa0IsQ0FBQ3NHLFVBQVU7QUFBQSxzQkFDM0IsR0FBR0E7QUFBQUEsc0JBQ0huSSxnQkFBZ0JtSztBQUFBQSxvQkFDbEIsRUFBRTtBQUFBLGtCQUNKO0FBQUEsa0JBQ0EsY0FBYyxDQUFDUCxPQUFPQyxXQUNwQkEsUUFBUXBFLE9BQU9tRCxZQUFZLEVBQUU5QixTQUFTOEMsTUFBTWhCLFlBQVksQ0FBQztBQUFBLGtCQUcxRG5LLDhCQUFvQndGLElBQUksQ0FBQ21HLE9BQU87QUFDL0IsMEJBQU1DLFFBQVE7QUFDZCx3QkFBSUQsR0FBRzdGLGNBQWM2RixHQUFHN0YsZUFBZTtBQUNyQzhGLDRCQUFNQyxLQUFLRixHQUFHN0YsVUFBVTtBQUMxQix3QkFBSTZGLEdBQUc1RixVQUFVNEYsR0FBRzVGLFdBQVc7QUFDN0I2Riw0QkFBTUMsS0FBSyxXQUFXRixHQUFHNUYsTUFBTSxFQUFFO0FBQ25DLDJCQUNFLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPNEYsR0FBR3RGLEtBQ25DdUYsZ0JBQU0zRixLQUFLLEtBQUssS0FEQzBGLEdBQUd0RixLQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBRUosQ0FBQztBQUFBO0FBQUEsZ0JBM0JIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQTRCQTtBQUFBLGNBQ0N2RyxPQUFPeUIsa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWekIsaUJBQU95QixrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBcENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0NBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWU7QUFBQTtBQUFBLG9CQUVGLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUp4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVyxxQ0FBcUM3RCxVQUFVc04sTUFBTTtBQUFBLGtCQUNoRSxhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQ0csT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNsQixZQUFZLEVBQUU5QixTQUFTOEMsTUFBTWhCLFlBQVksQ0FBQztBQUFBLGtCQUU1RCxPQUNFaEgsZ0JBQWdCMUIsOEJBQThCd0o7QUFBQUEsa0JBRWhELFVBQVUsQ0FBQ3hILFVBQ1Q4RCxzQkFBc0IsOEJBQThCOUQsS0FBSztBQUFBLGtCQUcxRCxXQUFDLFlBQVksZUFBZSxVQUFVLEVBQUUrQjtBQUFBQSxvQkFBSSxDQUFDc0csWUFDNUMsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLFNBQ2pDQSxxQkFEaUJBLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXFCQTtBQUFBLGNBQ0NoTSxPQUFPMkIsOEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWM0IsaUJBQU8yQiw4QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBa0NBO0FBQUEsWUFFQzBCLGVBQWUxQiwrQkFBK0IsY0FDN0MsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQVU7QUFBQTtBQUFBLHNCQUVXO0FBQUEsc0JBQzdCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHFDQUFxQy9ELFVBQVVzTixNQUFNO0FBQUEsb0JBQ2hFLGFBQVk7QUFBQSxvQkFDWix1QkFBdUI7QUFBQSxvQkFDdkI7QUFBQSxvQkFDQSxNQUFLO0FBQUEsb0JBQ0wsY0FBYyxDQUFDRyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSlUsU0FBUyxFQUNUNUIsWUFBWSxFQUNaOUIsU0FBUzhDLE1BQU1oQixZQUFZLENBQUM7QUFBQSxvQkFFakMsT0FBT2hILGdCQUFnQjVDLHFCQUFxQjBLO0FBQUFBLG9CQUM1QyxVQUFVLENBQUN4SCxVQUNUOEQsc0JBQXNCLHFCQUFxQjlELEtBQUs7QUFBQSxvQkFHakQxRixnQkFBTXlIO0FBQUFBLHNCQUFJLENBQUNpRyxTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLcEYsS0FDdkNvRixlQUFLbEYsYUFEWWtGLEtBQUtwRixLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBc0JBO0FBQUEsZ0JBQ0N2RyxPQUFPUyxxQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZULGlCQUFPUyxxQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBbkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUNBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU87QUFBQTtBQUFBLHNCQUVILHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU80QyxlQUFlN0I7QUFBQUEsb0JBQ3RCLFVBQVVzSjtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQkFBcUJsTixVQUFVc04sTUFBTTtBQUFBO0FBQUEsa0JBUmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNkc7QUFBQSxnQkFFNUdsTCxPQUFPd0IsNEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWeEIsaUJBQU93Qiw0QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsaUJBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOERBO0FBQUEsWUFFRDZCLGVBQWUxQiwrQkFBK0IsaUJBQzdDLHVCQUFDLFNBQUksV0FBVSxrQkFFYjtBQUFBLHFDQUFDLFNBQUksV0FBVSw0REFDYjtBQUFBLHVDQUFDLFFBQUcsV0FBVSx5REFBd0Qsb0NBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLHNCQUM1QztBQUFBLHNCQUNsQix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRmxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBR0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQU8wQixlQUFlOUM7QUFBQUEsd0JBQ3RCLFVBQVV1SztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT2dKO0FBQUEsb0JBRS9JOUssT0FBT08scUJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWUCxpQkFBT08scUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW1CQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQ2pELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBTzhDLGVBQWUzQztBQUFBQSx3QkFDdEIsVUFBVW9LO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPZ0o7QUFBQSxvQkFFL0k5SyxPQUFPVSw2QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZWLGlCQUFPVSw2QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEscUJBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBeUNBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLE1BQUs7QUFBQSx3QkFDTCxjQUFjLENBQUMySyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmxCLFlBQVksRUFDWjlCLFNBQVM4QyxNQUFNaEIsWUFBWSxDQUFDO0FBQUEsd0JBRWpDLE9BQ0VoSCxlQUFlcEIsa0NBQ2ZrSjtBQUFBQSx3QkFFRixVQUFVLENBQUN4SCxVQUNUOEQ7QUFBQUEsMEJBQ0U7QUFBQSwwQkFDQTlEO0FBQUFBLHdCQUNGO0FBQUEsd0JBR0QsV0FBQyxVQUFVLFVBQVUsT0FBTyxFQUFFK0I7QUFBQUEsMEJBQUksQ0FBQ3dHLFFBQ2xDLHVCQUFDLE9BQU8sUUFBUCxFQUF3QixPQUFPQSxLQUM3QkEsaUJBRGlCQSxLQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBQ0Q7QUFBQTtBQUFBLHNCQXpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBMEJBO0FBQUEsb0JBQ0NsTSxPQUFPaUMsa0NBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWakMsaUJBQU9pQyxrQ0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBbENKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBb0NBO0FBQUEsa0JBRUNvQixlQUFlcEIsbUNBQ2QsV0FDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsZ0RBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsV0FBVTtBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixPQUFPbkM7QUFBQUEsd0JBQ1AsVUFBVSxDQUFDNEQsTUFDVDNELHNCQUFzQjJELEVBQUVFLE9BQU9ELEtBQUs7QUFBQTtBQUFBLHNCQU54QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT0c7QUFBQSx1QkFYTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWFBO0FBQUEscUJBdERKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBd0RBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHFCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPTixlQUFlN0M7QUFBQUEsd0JBQ3RCLFVBQVVzSztBQUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxXQUFVO0FBQUE7QUFBQSxzQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBT2dKO0FBQUEsb0JBRS9JOUssT0FBT1Esc0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWUixpQkFBT1Esc0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWtCQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyw2QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FDRTZDLGVBQWVwQywyQkFDWCxJQUFJa0w7QUFBQUEsMEJBQ0Y5SSxlQUFlcEM7QUFBQUEsd0JBQ2pCLEVBQ0dtTCxZQUFZLEVBQ1pDLE1BQU0sR0FBRyxFQUFFLENBQUMsSUFDZjtBQUFBLHdCQUVOLFVBQVV2QjtBQUFBQSx3QkFDVixXQUFVO0FBQUE7QUFBQSxzQkFiWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBYWdKO0FBQUEsdUJBakJsSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW1CQTtBQUFBLHFCQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXdDQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyw4QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxNQUFLO0FBQUEsd0JBQ0wsY0FBYyxDQUFDTyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmxCLFlBQVksRUFDWjlCLFNBQVM4QyxNQUFNaEIsWUFBWSxDQUFDO0FBQUEsd0JBRWpDLE9BQ0VoSCxlQUFlckMsK0JBQ2ZtSztBQUFBQSx3QkFFRixVQUFVLENBQUN4SCxVQUNUOEQ7QUFBQUEsMEJBQ0U7QUFBQSwwQkFDQTlEO0FBQUFBLHdCQUNGO0FBQUEsd0JBR0QsV0FBQyxXQUFXLGFBQWEsU0FBUyxVQUFVLEVBQUUrQjtBQUFBQSwwQkFDN0MsQ0FBQzRHLFdBQ0MsdUJBQUMsT0FBTyxRQUFQLEVBQTJCLE9BQU9BLFFBQ2hDQSxvQkFEaUJBLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSx3QkFFSjtBQUFBO0FBQUEsc0JBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkE0QkE7QUFBQSx1QkFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQ0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0Msc0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLGNBQWMsQ0FBQ2pCLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKbEIsWUFBWSxFQUNaOUIsU0FBUzhDLE1BQU1oQixZQUFZLENBQUM7QUFBQSx3QkFFakMsT0FDRWhILGVBQWV0Qyx1QkFBdUJvSztBQUFBQSx3QkFFeEMsVUFBVSxDQUFDeEgsVUFDVDhELHNCQUFzQix1QkFBdUI5RCxLQUFLO0FBQUEsd0JBR25ELFdBQUMsUUFBUSxRQUFRLEVBQUUrQjtBQUFBQSwwQkFBSSxDQUFDNkcsTUFDdkIsdUJBQUMsT0FBTyxRQUFQLEVBQXNCLE9BQU9BLEdBQzNCQSxlQURpQkEsR0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLHdCQUNEO0FBQUE7QUFBQSxzQkFyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXNCQTtBQUFBLHVCQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTJCQTtBQUFBLHFCQTlERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQStEQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsb0JBQ3RELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQSx1QkFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxNQUFLO0FBQUEsc0JBQ0wsT0FBT2xKLGVBQWUxQztBQUFBQSxzQkFDdEIsVUFBVW1LO0FBQUFBLHNCQUNWLGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFPa0c7QUFBQSxrQkFFakc5SyxPQUFPVyx3QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZYLGlCQUFPVyx3QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPMEMsZUFBZWxDO0FBQUFBLHdCQUN0QixVQUFVMko7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSx1QkFWcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyxxQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT3pILGVBQWVqQztBQUFBQSx3QkFDdEIsVUFBVTBKO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTWtHO0FBQUEsdUJBVnBHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWUE7QUFBQSxxQkExQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEyQkE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MscUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsTUFBSztBQUFBLHdCQUNMLGNBQWMsQ0FBQ08sT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0psQixZQUFZLEVBQ1o5QixTQUFTOEMsTUFBTWhCLFlBQVksQ0FBQztBQUFBLHdCQUVqQyxPQUFPaEgsZUFBZTlCLHNCQUFzQjRKO0FBQUFBLHdCQUM1QyxVQUFVLENBQUN4SCxVQUNUOEQsc0JBQXNCLHNCQUFzQjlELEtBQUs7QUFBQSx3QkFHbEQsV0FBQyxhQUFhLGVBQWUsWUFBWSxFQUFFK0I7QUFBQUEsMEJBQzFDLENBQUM4RyxVQUNDLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxPQUMvQkEsbUJBRGlCQSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBRUo7QUFBQTtBQUFBLHNCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBc0JBO0FBQUEsdUJBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMkJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHdCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPbkosZUFBZS9CO0FBQUFBLHdCQUN0QixVQUFVd0o7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSx1QkFWcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLHFCQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBDQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQ3RELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT3pILGVBQWV6QztBQUFBQSx3QkFDdEIsVUFBVWtLO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPa0c7QUFBQSxvQkFFakc5SyxPQUFPWSx3QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZaLGlCQUFPWSx3QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDJCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPeUMsZUFBZWhDO0FBQUFBLHdCQUN0QixVQUFVeUo7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSx1QkFWcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLHFCQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlDQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQywyQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixhQUFZO0FBQUEsd0JBQ1o7QUFBQSx3QkFDQSxNQUFLO0FBQUEsd0JBQ0wsY0FBYyxDQUFDTyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSmxCLFlBQVksRUFDWjlCLFNBQVM4QyxNQUFNaEIsWUFBWSxDQUFDO0FBQUEsd0JBRWpDLE9BQ0VoSCxlQUFlbkMsNEJBQTRCaUs7QUFBQUEsd0JBRTdDLFVBQVUsQ0FBQ3hILFVBQ1Q4RDtBQUFBQSwwQkFDRTtBQUFBLDBCQUNBOUQ7QUFBQUEsd0JBQ0Y7QUFBQSx3QkFHRCxXQUFDLFVBQVUsT0FBTyxFQUFFK0I7QUFBQUEsMEJBQUksQ0FBQytHLFdBQ3hCLHVCQUFDLE9BQU8sUUFBUCxFQUEyQixPQUFPQSxRQUNoQ0Esb0JBRGlCQSxRQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBQ0Q7QUFBQTtBQUFBLHNCQXhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBeUJBO0FBQUEsdUJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBOEJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLHNDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPcEosZUFBZTNCO0FBQUFBLHdCQUN0QixVQUFVb0o7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSx1QkFWcEc7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFZQTtBQUFBLHFCQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTZDQTtBQUFBLG1CQTFZRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTJZQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHlEQUF3RCw2QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUdBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQy9DLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT3pILGVBQWV4QztBQUFBQSx3QkFDdEIsVUFBVWlLO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWjtBQUFBLHdCQUNBLFdBQVU7QUFBQTtBQUFBLHNCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPa0c7QUFBQSxvQkFFakc5SyxPQUFPYSwwQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZiLGlCQUFPYSwwQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxzQkFDbkQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBLHlCQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPd0MsZUFBZXZDO0FBQUFBLHdCQUN0QixVQUFVZ0s7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaO0FBQUEsd0JBQ0EsV0FBVTtBQUFBO0FBQUEsc0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQU9rRztBQUFBLG9CQUVqRzlLLE9BQU9jLHVCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmQsaUJBQU9jLHVCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFrQkE7QUFBQSxxQkF0Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF1Q0E7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsdUJBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDZjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLHNCQUNoRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRyxTQUFRO0FBQUEsd0JBQ1IsV0FBVTtBQUFBLHdCQUVWO0FBQUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsV0FBVTtBQUFBLDhCQUNWLE1BQUs7QUFBQSw4QkFDTCxRQUFPO0FBQUEsOEJBQ1AsU0FBUTtBQUFBLDhCQUVSO0FBQUEsZ0NBQUM7QUFBQTtBQUFBLGtDQUNDLGVBQWM7QUFBQSxrQ0FDZCxnQkFBZTtBQUFBLGtDQUNmLGFBQWE7QUFBQSxrQ0FDYixHQUFFO0FBQUE7QUFBQSxnQ0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBSW1EO0FBQUE7QUFBQSw0QkFWckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQVlBO0FBQUEsMEJBQ0EsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsNEJBQy9CLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBRztBQUFBLDRCQUNuQix1QkFBQyxVQUFLLFdBQVUsV0FBVSwwQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBb0M7QUFBQSwrQkFGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FHQTtBQUFBLDBCQUVBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLElBQUc7QUFBQSw4QkFDSCxNQUFLO0FBQUEsOEJBQ0wsTUFBSztBQUFBLDhCQUNMLFVBQVUwSjtBQUFBQSw4QkFDVixRQUFPO0FBQUEsOEJBQ1A7QUFBQSw4QkFDQSxXQUFVO0FBQUE7QUFBQSw0QkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBT29CO0FBQUE7QUFBQTtBQUFBLHNCQTdCeEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQStCRTtBQUFBLG9CQUNEeEssT0FBTzhCLHNCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlCLGlCQUFPOEIsc0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQXZDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXlDQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNkdUIseUJBQWV2QixzQkFDZCx1QkFBQyxRQUFLLElBQUl1QixlQUFldkIsb0JBQW9CLFVBQVEsTUFDbkQ7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsS0FBS3VCLGVBQWV2QjtBQUFBQSxzQkFDcEIsS0FBSTtBQUFBLHNCQUNKLFdBQVU7QUFBQTtBQUFBLG9CQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFHMkQsS0FKN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVUE7QUFBQSxxQkFyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFzREE7QUFBQSxnQkFHQSx1QkFBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLHNCQUMvQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdDO0FBQUEseUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDRDtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDRSxTQUFRO0FBQUEsd0JBQ1IsV0FBVTtBQUFBLHdCQUVWO0FBQUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsV0FBVTtBQUFBLDhCQUNWLE1BQUs7QUFBQSw4QkFDTCxRQUFPO0FBQUEsOEJBQ1AsU0FBUTtBQUFBLDhCQUVSO0FBQUEsZ0NBQUM7QUFBQTtBQUFBLGtDQUNDLGVBQWM7QUFBQSxrQ0FDZCxnQkFBZTtBQUFBLGtDQUNmLGFBQWE7QUFBQSxrQ0FDYixHQUFFO0FBQUE7QUFBQSxnQ0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBSW1EO0FBQUE7QUFBQSw0QkFWckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQVlBO0FBQUEsMEJBQ0EsdUJBQUMsT0FBRSxXQUFVLHFDQUFvQztBQUFBO0FBQUEsNEJBQy9CLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBRztBQUFBLDRCQUNuQix1QkFBQyxVQUFLLFdBQVUsV0FBVSwwQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FBb0M7QUFBQSwrQkFGdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FHQTtBQUFBLDBCQUVBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLElBQUc7QUFBQSw4QkFDSCxNQUFLO0FBQUEsOEJBQ0wsTUFBSztBQUFBLDhCQUNMLFVBQVUwSTtBQUFBQSw4QkFDVixRQUFPO0FBQUEsOEJBQ1A7QUFBQSw4QkFDQSxXQUFVO0FBQUE7QUFBQSw0QkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBT29CO0FBQUE7QUFBQTtBQUFBLHNCQTdCdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQStCQztBQUFBLG9CQUNDeEssT0FBTytCLDZCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVi9CLGlCQUFPK0IsNkJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUVEc0IsZUFBZXRCLDZCQUNkO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLElBQUlzQixlQUFldEI7QUFBQUEsd0JBQ25CLFVBQVE7QUFBQSx3QkFFUjtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxLQUFLc0IsZUFBZXRCO0FBQUFBLDRCQUNwQixLQUFJO0FBQUEsNEJBQ0osV0FBVTtBQUFBO0FBQUEsMEJBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUcyRDtBQUFBO0FBQUEsc0JBUDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFTQTtBQUFBLHVCQW5ESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXFEQTtBQUFBLGtCQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsc0JBQzNDO0FBQUEsc0JBQ25CLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBZ0M7QUFBQSx5QkFGbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFHQTtBQUFBLG9CQUNEO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNFLFNBQVE7QUFBQSx3QkFDUixXQUFVO0FBQUEsd0JBRVY7QUFBQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxXQUFVO0FBQUEsOEJBQ1YsTUFBSztBQUFBLDhCQUNMLFFBQU87QUFBQSw4QkFDUCxTQUFRO0FBQUEsOEJBRVI7QUFBQSxnQ0FBQztBQUFBO0FBQUEsa0NBQ0MsZUFBYztBQUFBLGtDQUNkLGdCQUFlO0FBQUEsa0NBQ2YsYUFBYTtBQUFBLGtDQUNiLEdBQUU7QUFBQTtBQUFBLGdDQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFJbUQ7QUFBQTtBQUFBLDRCQVZyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBWUE7QUFBQSwwQkFDQSx1QkFBQyxPQUFFLFdBQVUscUNBQW9DO0FBQUE7QUFBQSw0QkFDL0IsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFHO0FBQUEsNEJBQ25CLHVCQUFDLFVBQUssV0FBVSxXQUFVLDBCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUFvQztBQUFBLCtCQUZ0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUdBO0FBQUEsMEJBRUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsSUFBRztBQUFBLDhCQUNILE1BQUs7QUFBQSw4QkFDTCxNQUFLO0FBQUEsOEJBQ0wsVUFBVXlJO0FBQUFBLDhCQUNWLFFBQU87QUFBQSw4QkFDUDtBQUFBLDhCQUNBLFdBQVU7QUFBQTtBQUFBLDRCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFPb0I7QUFBQTtBQUFBO0FBQUEsc0JBN0J2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBK0JDO0FBQUEsb0JBQ0N4SyxPQUFPZ0MsZ0NBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWaEMsaUJBQU9nQyxnQ0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBRURxQixlQUFlckIsZ0NBQ2Q7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsSUFBSXFCLGVBQWVyQjtBQUFBQSx3QkFDbkIsVUFBUTtBQUFBLHdCQUVSO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLEtBQUtxQixlQUFlckI7QUFBQUEsNEJBQ3BCLEtBQUk7QUFBQSw0QkFDSixXQUFVO0FBQUE7QUFBQSwwQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBRzJEO0FBQUE7QUFBQSxzQkFQN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVNBO0FBQUEsdUJBcERKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBc0RBO0FBQUEscUJBN0dGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBOEdBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsOEJBQTZCLG9DQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0M2QixVQUFVNkI7QUFBQUEsb0JBQUksQ0FBQytELEtBQUsvRSxVQUNuQjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFFQyxXQUFVO0FBQUEsd0JBR1Y7QUFBQSxpREFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQTtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxNQUFLO0FBQUEsZ0NBQ0wsYUFBWTtBQUFBLGdDQUNaLE9BQU8rRSxJQUFJMUY7QUFBQUEsZ0NBQ1gsVUFBVSxDQUFDTCxNQUNUZSx5QkFBeUJDLE9BQU9oQixDQUFDO0FBQUEsZ0NBRW5DLFdBQVU7QUFBQTtBQUFBLDhCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFPOEQ7QUFBQSw0QkFFOUQ7QUFBQSw4QkFBQztBQUFBO0FBQUEsZ0NBQ0MsTUFBSztBQUFBLGdDQUNMLE1BQUs7QUFBQSxnQ0FDTCxVQUFVLENBQUNBLE1BQ1RrQix5QkFBeUJGLE9BQU9oQixDQUFDO0FBQUEsZ0NBRW5DLFFBQU87QUFBQSxnQ0FDUCxXQUFVO0FBQUE7QUFBQSw4QkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBTzBEO0FBQUEsNEJBRTFEO0FBQUEsOEJBQUM7QUFBQTtBQUFBLGdDQUNDLE1BQUs7QUFBQSxnQ0FDTCxTQUFTLE1BQU11QixlQUFlUCxLQUFLO0FBQUEsZ0NBQ25DLFdBQVU7QUFBQSxnQ0FFVixpQ0FBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBQVU7QUFBQTtBQUFBLDhCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFNQTtBQUFBLCtCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQTBCQTtBQUFBLDBCQUdDK0UsSUFBSXhGLFdBQ0gsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsS0FBS3dGLElBQUl4RjtBQUFBQSw4QkFDVCxLQUFLd0YsSUFBSTFGO0FBQUFBLDhCQUNULFdBQVU7QUFBQTtBQUFBLDRCQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFHc0QsS0FKeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FNQTtBQUFBO0FBQUE7QUFBQSxzQkF4Q0dXO0FBQUFBLHNCQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBMkNBO0FBQUEsa0JBQ0Q7QUFBQSxrQkFFRDtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsU0FBU007QUFBQUEsc0JBQ1QsV0FBVTtBQUFBLHNCQUErRTtBQUFBO0FBQUEsb0JBSDNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFNQTtBQUFBLHFCQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBEQTtBQUFBLG1CQXBSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFSQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHlEQUF3RCxrQ0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FFYixpQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHlDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFHQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsT0FDRTNCLGVBQWVuQiwyQkFBMkJpSjtBQUFBQSxzQkFFNUMsVUFBVSxDQUFDeEgsVUFBVTtBQUVuQkwsMENBQWtCLENBQUNzRyxVQUFVO0FBQUEsMEJBQzNCLEdBQUdBO0FBQUFBLDBCQUNIMUgseUJBQXlCeUI7QUFBQUEsMEJBQ3pCVCw2QkFBNkI7QUFBQSwwQkFDN0JOLDZCQUE2QjtBQUFBLDBCQUM3QkMsNkJBQTZCO0FBQUEsMEJBQzdCQyxnQ0FBZ0M7QUFBQSwwQkFDaENDLDhCQUE4QjtBQUFBLDBCQUM5QkMsMEJBQTBCO0FBQUEsMEJBQzFCQyw0QkFBNEI7QUFBQSx3QkFDOUIsRUFBRTtBQUFBLHNCQUNKO0FBQUEsc0JBQ0EsY0FBYyxDQUFDb0ksT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0psQixZQUFZLEVBQ1o5QixTQUFTOEMsTUFBTWhCLFlBQVksQ0FBQztBQUFBLHNCQUdoQztBQUFBLHdCQUNDO0FBQUEsd0JBQ0E7QUFBQSx3QkFDQTtBQUFBLHdCQUNBO0FBQUEsd0JBQ0E7QUFBQSxzQkFBTyxFQUNQM0U7QUFBQUEsd0JBQUksQ0FBQ21ILFFBQ0wsdUJBQUMsT0FBTyxRQUFQLEVBQXdCLE9BQU9BLEtBQzdCQSxpQkFEaUJBLEtBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSxzQkFDRDtBQUFBO0FBQUEsb0JBckNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFzQ0E7QUFBQSxrQkFDQzdNLE9BQU9rQywyQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZsQyxpQkFBT2tDLDJCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFJRG1CLGVBQWVuQiw0QkFBNEIsV0FDMUMsbUNBQ0U7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsZUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsMENBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsYUFBWTtBQUFBLDBCQUNaO0FBQUEsMEJBQ0EsT0FDRW1CLGVBQWVILCtCQUNmaUk7QUFBQUEsMEJBRUYsVUFBVSxDQUFDeEgsVUFDVHRELFlBQVksQ0FBQ3VKLFVBQVU7QUFBQSw0QkFDckIsR0FBR0E7QUFBQUEsNEJBQ0gxRyw2QkFBNkJTO0FBQUFBLDBCQUMvQixFQUFFO0FBQUEsMEJBRUosY0FBYyxDQUFDMEgsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0psQixZQUFZLEVBQ1o5QixTQUFTOEMsTUFBTWhCLFlBQVksQ0FBQztBQUFBLDBCQUdoQztBQUFBLDRCQUNDO0FBQUEsNEJBQ0E7QUFBQSw0QkFDQTtBQUFBLDRCQUNBO0FBQUEsNEJBQ0E7QUFBQSwwQkFBa0MsRUFDbEMzRTtBQUFBQSw0QkFBSSxDQUFDb0gsUUFDTCx1QkFBQyxPQUFPLFFBQVAsRUFBd0IsT0FBT0EsS0FDN0JBLGlCQURpQkEsS0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDBCQUNEO0FBQUE7QUFBQSx3QkE5Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQStCQTtBQUFBLHNCQUNDOU0sT0FBT2tELCtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmxELGlCQUFPa0QsK0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQXZDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXlDQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FDRUcsZUFBZVA7QUFBQUEsMEJBRWpCLFVBQVVnSTtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVE4STtBQUFBLHNCQUU3STlLLE9BQU84QyxrQ0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y5QyxpQkFBTzhDLGtDQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFtQkE7QUFBQSx1QkE5REY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkErREE7QUFBQSxrQkFJRCxDQUFDLGlCQUFpQixVQUFVLEVBQUV5RjtBQUFBQSxvQkFDN0JsRixlQUFlbkI7QUFBQUEsa0JBQ2pCLEtBQ0UsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDZCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUNFbUIsZUFBZVQ7QUFBQUEsMEJBRWpCLFVBQVVrSTtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVE4STtBQUFBLHNCQUU3STlLLE9BQU80QywrQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y1QyxpQkFBTzRDLCtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFtQkE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsNkJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQ0VTLGVBQWVSO0FBQUFBLDBCQUVqQixVQUFVaUk7QUFBQUEsMEJBQ1YsYUFBWTtBQUFBLDBCQUNaLFdBQVU7QUFBQTtBQUFBLHdCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFROEk7QUFBQSxzQkFFN0k5SyxPQUFPNkMsK0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWN0MsaUJBQU82QywrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBbUJBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHVCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUNFUSxlQUFlUDtBQUFBQSwwQkFFakIsVUFBVWdJO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBUThJO0FBQUEsc0JBRTdJOUssT0FBTzhDLGtDQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlDLGlCQUFPOEMsa0NBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQW1CQTtBQUFBLHVCQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTZEQTtBQUFBLGtCQUlETyxlQUFlbkIsNEJBQ2Qsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLCtCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUNFbUIsZUFBZU47QUFBQUEsMEJBRWpCLFVBQVUrSDtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVE4STtBQUFBLHNCQUU3STlLLE9BQU8rQyxnQ0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1YvQyxpQkFBTytDLGdDQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFtQkE7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQ0VNLGVBQWVQO0FBQUFBLDBCQUVqQixVQUFVZ0k7QUFBQUEsMEJBQ1YsYUFBWTtBQUFBLDBCQUNaLFdBQVU7QUFBQTtBQUFBLHdCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFROEk7QUFBQSxzQkFFN0k5SyxPQUFPOEMsa0NBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWOUMsaUJBQU84QyxrQ0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBbUJBO0FBQUEsdUJBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBeUNBO0FBQUEsa0JBSURPLGVBQWVuQiw0QkFDZCxpQkFDQSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLDZDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLE9BQU9tQixlQUFlTDtBQUFBQSwwQkFDdEIsVUFBVThIO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTThJO0FBQUEsc0JBRTdJOUssT0FBT2dELDRCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmhELGlCQUFPZ0QsNEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaUJBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSw2Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHdDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsTUFBSztBQUFBLDBCQUNMLE1BQUs7QUFBQSwwQkFDTCxPQUNFSyxlQUFlSjtBQUFBQSwwQkFFakIsVUFBVTZIO0FBQUFBLDBCQUNWLGFBQVk7QUFBQSwwQkFDWixXQUFVO0FBQUE7QUFBQSx3QkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBUThJO0FBQUEsc0JBRTdJOUssT0FBT2lELDhCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmpELGlCQUFPaUQsOEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQW1CQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkNBQUMsV0FBTSxXQUFVLGdEQUErQyx1QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHNCQUNBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxNQUFLO0FBQUEsMEJBQ0wsT0FDRUksZUFBZVA7QUFBQUEsMEJBRWpCLFVBQVVnSTtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBUlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQVE4STtBQUFBLHNCQUU3STlLLE9BQU84QyxrQ0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y5QyxpQkFBTzhDLGtDQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFtQkE7QUFBQSx1QkExREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkEyREE7QUFBQSxrQkFJRE8sZUFBZW5CLDRCQUE0QixXQUMxQ21CLGVBQWVILGdDQUNiLHNDQUNBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsdUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQ0VHLGVBQWVQO0FBQUFBLHdCQUVqQixVQUFVZ0k7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFROEk7QUFBQSxvQkFFN0k5SyxPQUFPOEMsa0NBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWOUMsaUJBQU84QyxrQ0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBbUJBO0FBQUEscUJBbFVOO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBb1VBLEtBdFVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdVVBO0FBQUEsZ0JBR0EsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2Y7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxzQkFDakM7QUFBQSxzQkFDN0IsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBLHlCQUZsQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0csU0FBUTtBQUFBLHdCQUNSLFdBQVU7QUFBQSx3QkFFVjtBQUFBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFdBQVU7QUFBQSw4QkFDVixNQUFLO0FBQUEsOEJBQ0wsUUFBTztBQUFBLDhCQUNQLFNBQVE7QUFBQSw4QkFFUjtBQUFBLGdDQUFDO0FBQUE7QUFBQSxrQ0FDQyxlQUFjO0FBQUEsa0NBQ2QsZ0JBQWU7QUFBQSxrQ0FDZixhQUFhO0FBQUEsa0NBQ2IsR0FBRTtBQUFBO0FBQUEsZ0NBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUltRDtBQUFBO0FBQUEsNEJBVnJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFZQTtBQUFBLDBCQUNBLHVCQUFDLE9BQUUsV0FBVSxxQ0FBb0M7QUFBQTtBQUFBLDRCQUMvQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQUc7QUFBQSw0QkFDbkIsdUJBQUMsVUFBSyxXQUFVLFdBQVUsMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQW9DO0FBQUEsK0JBRnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBR0E7QUFBQSwwQkFFQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxJQUFHO0FBQUEsOEJBQ0gsTUFBSztBQUFBLDhCQUNMLE1BQUs7QUFBQSw4QkFDTCxVQUFVMEg7QUFBQUEsOEJBQ1YsUUFBTztBQUFBLDhCQUNQO0FBQUEsOEJBQ0EsV0FBVTtBQUFBO0FBQUEsNEJBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQU9vQjtBQUFBO0FBQUE7QUFBQSxzQkE3QnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkErQkU7QUFBQSxvQkFDRHhLLE9BQU9vQyxnQ0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZwQyxpQkFBT29DLGdDQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkF4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkEwQ0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDZGlCLHlCQUFlakIsZ0NBQ2Q7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsSUFBSWlCLGVBQWVqQjtBQUFBQSxzQkFDbkIsVUFBUTtBQUFBLHNCQUVSO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLEtBQUtpQixlQUFlakI7QUFBQUEsMEJBQ3BCLEtBQUk7QUFBQSwwQkFDSixXQUFVO0FBQUE7QUFBQSx3QkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBR3FFO0FBQUE7QUFBQSxvQkFQdkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFhQTtBQUFBLHFCQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBEQTtBQUFBLG1CQXpZRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTBZQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLDREQUNiO0FBQUEsdUNBQUMsUUFBRyxXQUFVLHlEQUF3RCw0QkFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsMkNBQUMsV0FBTSxXQUFVLGdEQUErQyx5QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLE1BQUs7QUFBQSx3QkFDTCxNQUFLO0FBQUEsd0JBQ0wsT0FBT2lCLGVBQWVmO0FBQUFBLHdCQUN0QixVQUFVd0k7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFNa0c7QUFBQSxvQkFFakc5SyxPQUFPc0MsMEJBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWdEMsaUJBQU9zQywwQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFpQkE7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLDJDQUFDLFdBQU0sV0FBVSxnREFBK0MsbUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxNQUFLO0FBQUEsd0JBQ0wsTUFBSztBQUFBLHdCQUNMLE9BQ0VlLGVBQWVkO0FBQUFBLHdCQUVqQixVQUFVdUk7QUFBQUEsd0JBQ1YsYUFBWTtBQUFBLHdCQUNaLFdBQVU7QUFBQTtBQUFBLHNCQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFRa0c7QUFBQSxvQkFFakc5SyxPQUFPdUMsb0NBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWdkMsaUJBQU91QyxvQ0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBbUJBO0FBQUEscUJBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBdUNBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDJCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPYyxlQUFlYjtBQUFBQSx3QkFDdEIsVUFBVXNJO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTWtHO0FBQUEsb0JBRWpHOUssT0FBT3dDLDRCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnhDLGlCQUFPd0MsNEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUJBO0FBQUEsa0JBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDhCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0E7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsTUFBSztBQUFBLHdCQUNMLE1BQUs7QUFBQSx3QkFDTCxPQUFPYSxlQUFlWjtBQUFBQSx3QkFDdEIsVUFBVXFJO0FBQUFBLHdCQUNWLGFBQVk7QUFBQSx3QkFDWixXQUFVO0FBQUE7QUFBQSxzQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBTWtHO0FBQUEsb0JBRWpHOUssT0FBT3lDLCtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnpDLGlCQUFPeUMsK0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLHVCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBaUJBO0FBQUEscUJBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBcUNBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEseUNBQUMsU0FBSSxXQUFVLFNBQ2Y7QUFBQSwyQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxzQkFDaEQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFnQztBQUFBLHlCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0Q7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0ksU0FBUTtBQUFBLHdCQUNSLFdBQVU7QUFBQSx3QkFFVjtBQUFBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFdBQVU7QUFBQSw4QkFDVixNQUFLO0FBQUEsOEJBQ0wsUUFBTztBQUFBLDhCQUNQLFNBQVE7QUFBQSw4QkFFUjtBQUFBLGdDQUFDO0FBQUE7QUFBQSxrQ0FDQyxlQUFjO0FBQUEsa0NBQ2QsZ0JBQWU7QUFBQSxrQ0FDZixhQUFhO0FBQUEsa0NBQ2IsR0FBRTtBQUFBO0FBQUEsZ0NBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUltRDtBQUFBO0FBQUEsNEJBVnJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFZQTtBQUFBLDBCQUNBLHVCQUFDLE9BQUUsV0FBVSxxQ0FBb0M7QUFBQTtBQUFBLDRCQUMvQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQUc7QUFBQSw0QkFDbkIsdUJBQUMsVUFBSyxXQUFVLFdBQVUsMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQW9DO0FBQUEsK0JBRnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBR0E7QUFBQSwwQkFFQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxJQUFHO0FBQUEsOEJBQ0gsTUFBSztBQUFBLDhCQUNMLE1BQUs7QUFBQSw4QkFDTCxVQUFVK0g7QUFBQUEsOEJBQ1YsUUFBTztBQUFBLDhCQUNQO0FBQUEsOEJBQ0EsV0FBVTtBQUFBO0FBQUEsNEJBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQU9vQjtBQUFBO0FBQUE7QUFBQSxzQkE3QnpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkErQkc7QUFBQSxvQkFDRHhLLE9BQU8yQyxvQ0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1YzQyxpQkFBTzJDLG9DQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSx1QkF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF5Q0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDZFUseUJBQWVWLG9DQUNkO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLElBQUlVLGVBQWVWO0FBQUFBLHNCQUNuQixVQUFRO0FBQUEsc0JBRVI7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsS0FDRVUsZUFBZVY7QUFBQUEsMEJBRWpCLEtBQUk7QUFBQSwwQkFDSixXQUFVO0FBQUE7QUFBQSx3QkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBSzJEO0FBQUE7QUFBQSxvQkFUN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVdBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFlQTtBQUFBLHFCQTFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTJEQTtBQUFBLG1CQWhKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlKQTtBQUFBLGlCQXJzQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFzc0NBO0FBQUEsWUFFRFUsZUFBZTFCLCtCQUErQixjQUM3QyxtQ0FDRTtBQUFBLHFDQUFDLFNBQ0M7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFPO0FBQUE7QUFBQSxzQkFFRCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPMEIsZUFBZXpCO0FBQUFBLG9CQUN0QixVQUFVa0o7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUJBQXFCbE4sVUFBVXNOLE1BQU07QUFBQTtBQUFBLGtCQVJsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZHO0FBQUEsZ0JBRTVHbEwsT0FBTzRCLDhCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjVCLGlCQUFPNEIsOEJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHVCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLFNBQ2Y7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFPO0FBQUE7QUFBQSx3QkFFRyx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUFpQztBQUFBO0FBQUE7QUFBQSxvQkFKckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUtBO0FBQUEsa0JBQ0Q7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ00sU0FBUTtBQUFBLHNCQUNSLFdBQVU7QUFBQSxzQkFFVjtBQUFBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixNQUFLO0FBQUEsNEJBQ0wsUUFBTztBQUFBLDRCQUNQLFNBQVE7QUFBQSw0QkFFUjtBQUFBLDhCQUFDO0FBQUE7QUFBQSxnQ0FDQyxlQUFjO0FBQUEsZ0NBQ2QsZ0JBQWU7QUFBQSxnQ0FDZixhQUFhO0FBQUEsZ0NBQ2IsR0FBRTtBQUFBO0FBQUEsOEJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUltRDtBQUFBO0FBQUEsMEJBVnJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFZQTtBQUFBLHdCQUNBLHVCQUFDLE9BQUUsV0FBVSxxQ0FBb0M7QUFBQTtBQUFBLDBCQUMvQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQUc7QUFBQSwwQkFDbkIsdUJBQUMsVUFBSyxXQUFVLFdBQVUsMEJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQW9DO0FBQUEsNkJBRnRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBR0E7QUFBQSx3QkFFQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxJQUFHO0FBQUEsNEJBQ0gsTUFBSztBQUFBLDRCQUNMLE1BQUs7QUFBQSw0QkFDTCxVQUFVNEk7QUFBQUEsNEJBQ1YsUUFBTztBQUFBLDRCQUNQO0FBQUEsNEJBQ0EsV0FBVTtBQUFBO0FBQUEsMEJBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU9vQjtBQUFBO0FBQUE7QUFBQSxvQkE3QjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkErQks7QUFBQSxrQkFDSHhLLE9BQU82Qix5QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y3QixpQkFBTzZCLHlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkExQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE0Q0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsU0FFZHdCLHlCQUFleEIseUJBQ2QsdUJBQUMsUUFBSyxJQUFJd0IsZUFBZXhCLHVCQUF1QixVQUFRLE1BQ3REO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLEtBQUt3QixlQUFleEI7QUFBQUEsb0JBQ3BCLEtBQUk7QUFBQSxvQkFDSixXQUFVO0FBQUE7QUFBQSxrQkFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRzJELEtBSjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsbUJBekRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMERBO0FBQUEsY0FDQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBYTtBQUFBO0FBQUEsc0JBRVQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT3dCLGVBQWU3QjtBQUFBQSxvQkFDdEIsVUFBVXNKO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFCQUFxQmxOLFVBQVVzTixNQUFNO0FBQUE7QUFBQSxrQkFSbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVE2RztBQUFBLGdCQUU1R2xMLE9BQU93Qiw0QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z4QixpQkFBT3dCLDRCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxpQkF6R0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEwR0E7QUFBQSxZQUdGLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxXQUFVO0FBQUEsZ0JBQytGO0FBQUE7QUFBQSxjQUgzRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxlQXYvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3L0NBO0FBQUEsYUE1L0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE2L0NBO0FBQUE7QUFBQSxNQWpnREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBa2dEQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVc3QztBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkksZ0NBQXNCLElBQUk7QUFBQSxRQUM1QjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxtQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0NELHNCQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVLENBQUMyRSxNQUFNO0FBQ2ZBLGtCQUFFcUYsZUFBZTtBQUNqQmdDLHdDQUF3QjtBQUFBLGNBQzFCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFXO0FBQUE7QUFBQSx3QkFFTjtBQUFBLHdCQUNiLHVCQUFDLFVBQUssV0FBVSwwQkFDYmhNLDhCQUFvQndCLHFCQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQVE7QUFBQSx3QkFBSTtBQUFBLHdCQUNTO0FBQUEsd0JBQ3JCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQVRuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVU7QUFBQTtBQUFBLG9CQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLMkk7QUFBQSxxQkFqQjdJO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBbUJBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDMkY7QUFBQTtBQUFBLGtCQUh2RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQTtBQUFBO0FBQUEsWUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0NBO0FBQUEsYUF2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlDQTtBQUFBO0FBQUEsTUFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBaURBO0FBQUEsT0EvaUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnakdBLEtBampHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa2pHQTtBQUVKO0FBQUV2QyxHQXQ2SElELGFBQVc7QUFBQW1QLEtBQVhuUDtBQXc2SE4sZUFBZUE7QUFBWSxJQUFBbVA7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiU2lkZWJhciIsIk1vZGFsIiwiYXBpIiwiRGF0YVRhYmxlIiwiSW5wdXQiLCJTZWxlY3QiLCJEcm9wZG93biIsIklvTWRNb3JlIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiQ2lyY3VsYXJMb2FkZXIiLCJDb0FwcGxpY2FudFByaW50IiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJMaW5rIiwiZmllbGRTaXplIiwiSW9NZENsb3NlIiwiQnJlYWRjcnVtYiIsIkNvQXBwbGljYW50IiwiX3MiLCJ1c2VycyIsInNldFVzZXJzIiwiY29BcHBsaWNhbnQiLCJzZXRDb0FwcGxpY2FudCIsIlRhYmxlQ29BcHBsaWNhbnQiLCJzZXRUYWJsZUNvQXBwbGljYW50Iiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJzaG93TW9kYWwiLCJzZXRTaG93TW9kYWwiLCJzaG93TW9kYWxEZWxldGUiLCJzZXRTaG93TW9kYWxEZWxldGUiLCJzaG93TW9kYWxVcGRhdGUiLCJzZXRTaG93TW9kYWxVcGRhdGUiLCJjdXJyZW50Q29BcHBsaWNhbnQiLCJzZXRDdXJyZW50Q29BcHBsaWNhbnQiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJjdXJyZW50VXBkYXRlQ29BcHBsaWNhbnQiLCJzZXRDdXJyZW50VXBkYXRlQ29BcHBsaWNhbnQiLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsImVucm9sbG1lbnQiLCJzZXRFbnJvbGxtZW50IiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwidHlwZSIsImN1c3RvbVJlbGF0aW9uc2hpcCIsInNldEN1c3RvbVJlbGF0aW9uc2hpcCIsImVycm9ycyIsInNldEVycm9ycyIsImZpbHRlcmVkRW5yb2xsbWVudHMiLCJzZXRGaWx0ZXJlZEVucm9sbG1lbnRzIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsInVzZXJfaWQiLCJjb19hcHBsaWNhbnRfbmFtZSIsImNvX2FwcGxpY2FudF9lbWFpbCIsInVzZXJfY29fYXBwbGljYW50IiwiY29fYXBwbGljYW50X3Bob25lX251bWJlciIsImNvX2FwcGxpY2FudF9hZGRyZXNzIiwiY29fYXBwbGljYW50X3BpbmNvZGUiLCJjb19hcHBsaWNhbnRfYWRoYWFyX25vIiwiY29fYXBwbGljYW50X3Bhbl9ubyIsImNvX2FwcGxpY2FudF9nZW5kZXIiLCJjb19hcHBsaWNhbnRfbWFyaXRhbF9zdGF0dXMiLCJjb19hcHBsaWNhbnRfZGF0ZW9mYmlydGgiLCJjb19hcHBsaWNhbnRfbmF0aW9uYWxpdHkiLCJjb19hcHBsaWNhbnRfdmlsbGFnZSIsImNvX2FwcGxpY2FudF90YWx1ayIsImNvX2FwcGxpY2FudF9mYXRoZXJfbmFtZSIsImNvX2FwcGxpY2FudF9kaXN0cmljdCIsImNvX2FwcGxpY2FudF9zdGF0ZSIsImNvX2FwcGxpY2FudF9kZXNjcmlwdGlvbiIsImVucm9sbG1lbnRfaWRzIiwiY29fYXBwbGljYW50X2FsdGVybmF0ZV9udW1iZXIiLCJjb19hcHBsaWNhbnRfcmVmZXJyZWRfdHlwZSIsImNvX2FwcGxpY2FudF9kb2N1bWVudF9uYW1lIiwiY29fYXBwbGljYW50X2RvY3VtZW50IiwiY29fYXBwbGljYW50X3Bob3RvIiwiY29fYXBwbGljYW50X3Bhbl9kb2N1bWVudCIsImNvX2FwcGxpY2FudF9hYWRoYXJfZG9jdW1lbnQiLCJjb19hcHBsaWNhbnRfcmVsYXRpb25zaGlwX3R5cGUiLCJjb19hcHBsaWNhbnRfb2NjdXBhdGlvbiIsImNvX2FwcGxpY2FudF9zZWN0b3JfbmFtZSIsImNvX2FwcGxpY2FudF9pbmNvbWVfZG9jdW1lbnQiLCJjb19hcHBsaWNhbnRfY29uc2VudF9kb2N1bWVudCIsImNvX2FwcGxpY2FudF9iYW5rX25hbWUiLCJjb19hcHBsaWNhbnRfYmFua19hY2NvdW50X251bWJlciIsImNvX2FwcGxpY2FudF9iYW5rX2JyYW5jaCIsImNvX2FwcGxpY2FudF9iYW5rX2lmc2NfY29kZSIsImNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rIiwiY29fYXBwbGljYW50X2JhbmtfcGFzc2Jvb2tfcGhvdG8iLCJjb19hcHBsaWNhbnRfYnVzc2luZXNzX3R5cGUiLCJjb19hcHBsaWNhbnRfYnVzc2luZXNzX25hbWUiLCJjb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3MiLCJjb19hcHBsaWNhbnRfcHJvZmVzc2lvbl90eXBlIiwiY29fYXBwbGljYW50X2FncmlfcnRjX25vIiwiY29fYXBwbGljYW50X2xhbmRfaG9sZGluZ3MiLCJjb19hcHBsaWNhbnRfb2NjdXBhdGlvbl9zdWIiLCJjb19hcHBsaWNhbnRfYWxsX2RvY3VtZW50X25hbWUiLCJjb19hcHBsaWNhbnRfYWxsX2RvY3VtZW50IiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImV4dHJhRG9jcyIsInNldEV4dHJhRG9jcyIsImRvY3VtZW50X25hbWUiLCJmaWxlIiwicHJldmlldyIsInVzZUVmZmVjdCIsImZldGNoVXNlcnMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJoYW5kbGVFeHRyYURvY05hbWVDaGFuZ2UiLCJpbmRleCIsInVwZGF0ZWQiLCJoYW5kbGVFeHRyYURvY0ZpbGVDaGFuZ2UiLCJmaWxlcyIsIlVSTCIsImNyZWF0ZU9iamVjdFVSTCIsImFkZE5ld0RvY0ZpZWxkIiwicmVtb3ZlRG9jRmllbGQiLCJmaWx0ZXIiLCJfIiwiaSIsImZldGNoRW5yb2xsbWVudERhdGEiLCJmZXRjaENvQXBwbGljYW50IiwibGVuZ3RoIiwiY29hcHBsaWNhbnRzIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsImdyb3VwIiwiZW5yb2xsbWVudFN1bW1hcnkiLCJlbnJvbGwiLCJncm91cE5hbWUiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJ0aWNrZXQiLCJ0aWNrZXRzIiwiam9pbiIsImN1c3RvbWVyVXNlciIsImZpbmQiLCJ1IiwiX2lkIiwiY29BcHBsaWNhbnROYW1lIiwiZnVsbF9uYW1lIiwiY29BcHBsaWNhbnRQaG9uZSIsInBob25lX251bWJlciIsImlkIiwiY29fYXBwbGljYW50X2NvZGUiLCJlbnJvbGxtZW50X3N1bW1hcnkiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwiaGFuZGxlQW50RFNlbGVjdCIsImZpZWxkIiwicHJldkRhdGEiLCJwcmV2RXJyb3JzIiwiaGFuZGxlQW50SW5wdXREU2VsZWN0IiwiaGFuZGxlQ2hhbmdlIiwibmFtZSIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsInJlZ2V4IiwiZW1haWwiLCJwaG9uZSIsInBpbmNvZGUiLCJhZGhhYXIiLCJwYW4iLCJ2YWxpZGF0ZUZpbGUiLCJhbGxvd2VkVHlwZXMiLCJGaWxlIiwiaW5jbHVkZXMiLCJzaXplIiwidHJpbSIsImZpbGVFcnJvciIsInRlc3QiLCJPYmplY3QiLCJrZXlzIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJpc3ZhbGlkIiwiZm1EYXRhIiwiRm9ybURhdGEiLCJlbnRyaWVzIiwiZm9yRWFjaCIsImFwcGVuZCIsIkFycmF5IiwiaXNBcnJheSIsInYiLCJkb2MiLCJwb3N0IiwiaGVhZGVycyIsInByZXYiLCJjb19hcHBsaWNhbnRfaW5jb21lIiwiaGFuZGxlVXBkYXRlIiwicmVzdCIsInNpbmdsZUZpbGVGaWVsZHMiLCJwdXQiLCJjb2x1bW5zIiwiaGVhZGVyIiwiZmlsdGVyZWRHdWFyYW50b3IiLCJ0b0xvd2VyQ2FzZSIsInVzZXJJZCIsImhhbmRsZUZpbGVDaGFuZ2UiLCJoYW5kbGVJbnB1dEZpbGVDaGFuZ2UiLCJjb2FwcGxpY2FudCIsIm1hdGNoZWRFbnJvbGxtZW50cyIsImQiLCJkb2N1bWVudF91cmwiLCJleGlzdGluZ1VybCIsImhhbmRsZUlucHV0Q2hhbmdlIiwiaGFuZGxlRGVsZXRlQ29BcHBsaWNhbnQiLCJkZWxldGUiLCJpbmZvIiwiaGVpZ2h0IiwidW5kZWZpbmVkIiwiZmlsdGVyZWQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwiZnJvbSIsIk1hcCIsInZhbHVlcyIsInVzZXIiLCJzZWxlY3RlZEVucm9sbG1lbnRJZHMiLCJlbiIsInBhcnRzIiwicHVzaCIsInJlZlR5cGUiLCJ0b1N0cmluZyIsInJlbCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0Iiwic3RhdHVzIiwiZyIsInN0YXRlIiwibmF0aW9uIiwiY29fYXBwbGljYW50X3Bob3RvX3ByZXZpZXciLCJjb19hcHBsaWNhbnRfcGFuX2RvY3VtZW50X3ByZXZpZXciLCJjb19hcHBsaWNhbnRfYWFkaGFyX2RvY3VtZW50X3ByZXZpZXciLCJvY2MiLCJzdWIiLCJjb19hcHBsaWNhbnRfaW5jb21lX2RvY3VtZW50X3ByZXZpZXciLCJjb19hcHBsaWNhbnRfYmFua19wYXNzYm9va19waG90b19wcmV2aWV3IiwiY29fYXBwbGljYW50X2RvY3VtZW50X3ByZXZpZXciLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDb0FwcGxpY2FudC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHsgSW5wdXQsIFNlbGVjdCwgRHJvcGRvd24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBDb0FwcGxpY2FudFByaW50IGZyb20gXCIuLi9jb21wb25lbnRzL3ByaW50Rm9ybWF0cy9Db0FwcGxpY2FudFByaW50XCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5pbXBvcnQgeyBJb01kQ2xvc2UgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IEJyZWFkY3J1bWIgZnJvbSBcIi4uL2hlbHBlcnMvQnJlYWRjcnVtYlwiO1xyXG5cclxuY29uc3QgQ29BcHBsaWNhbnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2NvQXBwbGljYW50LCBzZXRDb0FwcGxpY2FudF0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlQ29BcHBsaWNhbnQsIHNldFRhYmxlQ29BcHBsaWNhbnRdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50Q29BcHBsaWNhbnQsIHNldEN1cnJlbnRDb0FwcGxpY2FudF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlQ29BcHBsaWNhbnQsIHNldEN1cnJlbnRVcGRhdGVDb0FwcGxpY2FudF0gPVxyXG4gICAgdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2Vucm9sbG1lbnQsIHNldEVucm9sbG1lbnRdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2N1c3RvbVJlbGF0aW9uc2hpcCwgc2V0Q3VzdG9tUmVsYXRpb25zaGlwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkRW5yb2xsbWVudHMsIHNldEZpbHRlcmVkRW5yb2xsbWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfbmFtZTogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9lbWFpbDogXCJcIixcclxuICAgIHVzZXJfY29fYXBwbGljYW50OiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X3Bob25lX251bWJlcjogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9hZGRyZXNzOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X3BpbmNvZGU6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfYWRoYWFyX25vOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X3Bhbl9ubzogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9nZW5kZXI6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfbWFyaXRhbF9zdGF0dXM6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfZGF0ZW9mYmlydGg6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfbmF0aW9uYWxpdHk6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfdmlsbGFnZTogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF90YWx1azogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9mYXRoZXJfbmFtZTogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9kaXN0cmljdDogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9zdGF0ZTogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9kZXNjcmlwdGlvbjogXCJcIixcclxuICAgIGVucm9sbG1lbnRfaWRzOiBbXSxcclxuICAgIGNvX2FwcGxpY2FudF9hbHRlcm5hdGVfbnVtYmVyOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X3JlZmVycmVkX3R5cGU6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfZG9jdW1lbnRfbmFtZTogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9kb2N1bWVudDogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9waG90bzogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9wYW5fZG9jdW1lbnQ6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfYWFkaGFyX2RvY3VtZW50OiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X3JlbGF0aW9uc2hpcF90eXBlOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X29jY3VwYXRpb246IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfc2VjdG9yX25hbWU6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfaW5jb21lX2RvY3VtZW50OiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2NvbnNlbnRfZG9jdW1lbnQ6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfYmFua19uYW1lOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2JhbmtfYWNjb3VudF9udW1iZXI6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfYmFua19icmFuY2g6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfYmFua19pZnNjX2NvZGU6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfYmFua19wYXNzYm9vazogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2J1c3NpbmVzc190eXBlOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2J1c3NpbmVzc19uYW1lOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X3Byb2Zlc3Npb25fdHlwZTogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9hZ3JpX3J0Y19ubzogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9sYW5kX2hvbGRpbmdzOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X29jY3VwYXRpb25fc3ViOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2FsbF9kb2N1bWVudF9uYW1lOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2FsbF9kb2N1bWVudDogXCJcIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgW3VwZGF0ZUZvcm1EYXRhLCBzZXRVcGRhdGVGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X25hbWU6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfZW1haWw6IFwiXCIsXHJcbiAgICB1c2VyX2NvX2FwcGxpY2FudDogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9waG9uZV9udW1iZXI6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfYWRkcmVzczogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9waW5jb2RlOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2FkaGFhcl9ubzogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9wYW5fbm86IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfZ2VuZGVyOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X21hcml0YWxfc3RhdHVzOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2RhdGVvZmJpcnRoOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X25hdGlvbmFsaXR5OiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X3ZpbGxhZ2U6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfdGFsdWs6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfZmF0aGVyX25hbWU6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfZGlzdHJpY3Q6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfc3RhdGU6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfZGVzY3JpcHRpb246IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfYWx0ZXJuYXRlX251bWJlcjogXCJcIixcclxuICAgIGVucm9sbG1lbnRfaWRzOiBbXSxcclxuICAgIGNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2RvY3VtZW50OiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2RvY3VtZW50X25hbWU6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfcGhvdG86IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfcGFuX2RvY3VtZW50OiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2FhZGhhcl9kb2N1bWVudDogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9yZWxhdGlvbnNoaXBfdHlwZTogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9vY2N1cGF0aW9uOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X3NlY3Rvcl9uYW1lOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2luY29tZV9kb2N1bWVudDogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9jb25zZW50X2RvY3VtZW50OiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2JhbmtfbmFtZTogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9iYW5rX2FjY291bnRfbnVtYmVyOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2JhbmtfYnJhbmNoOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2JhbmtfaWZzY19jb2RlOiBcIlwiLFxyXG4gICAgY29fYXBwbGljYW50X2JhbmtfcGFzc2Jvb2s6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfYmFua19wYXNzYm9va19waG90bzogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9idXNzaW5lc3NfdHlwZTogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9idXNzaW5lc3NfbmFtZTogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzczogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9wcm9mZXNzaW9uX3R5cGU6IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfYWdyaV9ydGNfbm86IFwiXCIsXHJcbiAgICBjb19hcHBsaWNhbnRfbGFuZF9ob2xkaW5nczogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9vY2N1cGF0aW9uX3N1YjogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9hbGxfZG9jdW1lbnRfbmFtZTogXCJcIixcclxuICAgIGNvX2FwcGxpY2FudF9hbGxfZG9jdW1lbnQ6IFwiXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IEdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IFtleHRyYURvY3MsIHNldEV4dHJhRG9jc10gPSB1c2VTdGF0ZShcclxuICAgIGZvcm1EYXRhLmNvX2FwcGxpY2FudF9hbGxfZG9jdW1lbnQgfHwgW1xyXG4gICAgICB7IGRvY3VtZW50X25hbWU6IFwiXCIsIGZpbGU6IG51bGwsIHByZXZpZXc6IFwiXCIgfSxcclxuICAgIF1cclxuICApO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaFVzZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG5cclxuICAgICAgICBzZXRVc2VycyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaFVzZXJzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVFeHRyYURvY05hbWVDaGFuZ2UgPSAoaW5kZXgsIGUpID0+IHtcclxuICAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4uZXh0cmFEb2NzXTtcclxuICAgIHVwZGF0ZWRbaW5kZXhdLmRvY3VtZW50X25hbWUgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgIHNldEV4dHJhRG9jcyh1cGRhdGVkKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFeHRyYURvY0ZpbGVDaGFuZ2UgPSAoaW5kZXgsIGUpID0+IHtcclxuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlc1swXTtcclxuICAgIGlmIChmaWxlKSB7XHJcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSBbLi4uZXh0cmFEb2NzXTtcclxuICAgICAgdXBkYXRlZFtpbmRleF0uZmlsZSA9IGZpbGU7XHJcbiAgICAgIHVwZGF0ZWRbaW5kZXhdLnByZXZpZXcgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGZpbGUpO1xyXG4gICAgICBzZXRFeHRyYURvY3ModXBkYXRlZCk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gIEFkZC9yZW1vdmUgZXh0cmEgZG9jc1xyXG4gIGNvbnN0IGFkZE5ld0RvY0ZpZWxkID0gKCkgPT4ge1xyXG4gICAgc2V0RXh0cmFEb2NzKFtcclxuICAgICAgLi4uZXh0cmFEb2NzLFxyXG4gICAgICB7IGRvY3VtZW50X25hbWU6IFwiXCIsIGZpbGU6IG51bGwsIHByZXZpZXc6IFwiXCIgfSxcclxuICAgIF0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHJlbW92ZURvY0ZpZWxkID0gKGluZGV4KSA9PiB7XHJcbiAgICBjb25zdCB1cGRhdGVkID0gZXh0cmFEb2NzLmZpbHRlcigoXywgaSkgPT4gaSAhPT0gaW5kZXgpO1xyXG4gICAgc2V0RXh0cmFEb2NzKHVwZGF0ZWQpO1xyXG4gICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgY29fYXBwbGljYW50X2FsbF9kb2N1bWVudDogdXBkYXRlZCB9KTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hFbnJvbGxtZW50RGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2Vucm9sbC1yZXBvcnQvZ2V0LWVucm9sbC1yZXBvcnRgKTtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSkge1xyXG4gICAgICAgICAgc2V0RW5yb2xsbWVudChyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIEVucm9sbG1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEVucm9sbG1lbnREYXRhKCk7XHJcbiAgfSwgW10pO1xyXG5cclxudXNlRWZmZWN0KCgpID0+IHtcclxuICBjb25zdCBmZXRjaENvQXBwbGljYW50ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgLy8gd2FpdCB1bnRpbCB1c2VycyBhcmUgYXZhaWxhYmxlIChpbXBvcnRhbnQgZm9yIEN1c3RvbWVyIHR5cGUpXHJcbiAgICAgIGlmICghdXNlcnMgfHwgdXNlcnMubGVuZ3RoID09PSAwKSByZXR1cm47XHJcblxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvY29hcHBsaWNhbnQvZ2V0LWNvLWFwcGxpY2FudC1pbmZvXCIpO1xyXG4gICAgICBjb25zdCBjb2FwcGxpY2FudHMgPSByZXNwb25zZS5kYXRhPy5jb0FwcGxpY2FudCB8fCBbXTtcclxuXHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSBjb2FwcGxpY2FudHMubWFwKChncm91cCwgaW5kZXgpID0+IHtcclxuICAgICAgICAvLyAtLS0tIEVucm9sbG1lbnQgU3VtbWFyeSAtLS0tXHJcbiAgICAgICAgY29uc3QgZW5yb2xsbWVudFN1bW1hcnkgPSAoZ3JvdXA/LmVucm9sbG1lbnRfaWRzIHx8IFtdKVxyXG4gICAgICAgICAgLm1hcCgoZW5yb2xsKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGdyb3VwTmFtZSA9IGVucm9sbD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIjtcclxuICAgICAgICAgICAgY29uc3QgdGlja2V0ID0gZW5yb2xsPy50aWNrZXRzIHx8IFwiTi9BXCI7XHJcbiAgICAgICAgICAgIHJldHVybiBgJHtncm91cE5hbWV9IHwgVGlja2V0OiAke3RpY2tldH1gO1xyXG4gICAgICAgICAgfSlcclxuICAgICAgICAgIC5qb2luKFwiLCBcIik7XHJcblxyXG4gICAgICAgIC8vIC0tLS0gUmVzb2x2ZSBDdXN0b21lciBEZXRhaWxzIC0tLS1cclxuICAgICAgICBjb25zdCBjdXN0b21lclVzZXIgPVxyXG4gICAgICAgICAgZ3JvdXA/LmNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlID09PSBcIkN1c3RvbWVyXCJcclxuICAgICAgICAgICAgPyB1c2Vycy5maW5kKCh1KSA9PiB1Ll9pZCA9PT0gZ3JvdXA/LnVzZXJfY29fYXBwbGljYW50KVxyXG4gICAgICAgICAgICA6IG51bGw7XHJcblxyXG4gICAgICAgIGNvbnN0IGNvQXBwbGljYW50TmFtZSA9XHJcbiAgICAgICAgICBncm91cD8uY29fYXBwbGljYW50X3JlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICA/IGN1c3RvbWVyVXNlcj8uZnVsbF9uYW1lID8/IFwiTi9BXCJcclxuICAgICAgICAgICAgOiBncm91cD8uY29fYXBwbGljYW50X25hbWUgPz8gXCJOL0FcIjtcclxuXHJcbiAgICAgICAgY29uc3QgY29BcHBsaWNhbnRQaG9uZSA9XHJcbiAgICAgICAgICBncm91cD8uY29fYXBwbGljYW50X3JlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICA/IGN1c3RvbWVyVXNlcj8ucGhvbmVfbnVtYmVyID8/IFwiTi9BXCJcclxuICAgICAgICAgICAgOiBncm91cD8uY29fYXBwbGljYW50X3Bob25lX251bWJlciA/PyBcIk4vQVwiO1xyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgX2lkOiBncm91cD8uX2lkLFxyXG4gICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9jb2RlOiBncm91cD8uY29fYXBwbGljYW50X2NvZGUsXHJcbiAgICAgICAgICB1c2VyX2lkOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lID8/IFwiTi9BXCIsXHJcbiAgICAgICAgICBlbnJvbGxtZW50X3N1bW1hcnk6IGVucm9sbG1lbnRTdW1tYXJ5LFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X3JlZmVycmVkX3R5cGU6IGdyb3VwPy5jb19hcHBsaWNhbnRfcmVmZXJyZWRfdHlwZSxcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9uYW1lOiBjb0FwcGxpY2FudE5hbWUsXHJcbiAgICAgICAgICBjb19hcHBsaWNhbnRfcGhvbmVfbnVtYmVyOiBjb0FwcGxpY2FudFBob25lLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X2Rlc2NyaXB0aW9uOiBncm91cD8uY29fYXBwbGljYW50X2Rlc2NyaXB0aW9uID8/IFwiLVwiLFxyXG5cclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGdyb3VwPy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlTW9kYWxPcGVuKGdyb3VwPy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBDb0FwcGxpY2FudFByaW50KGdyb3VwPy5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUHJpbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlclwiIC8+XHJcbiAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0Q29BcHBsaWNhbnQoY29hcHBsaWNhbnRzKTtcclxuICAgICAgc2V0VGFibGVDb0FwcGxpY2FudChmb3JtYXR0ZWREYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXHJcbiAgICAgICAgXCJFcnJvciBmZXRjaGluZyBDbyBBcHBsaWNhbnQgZGF0YTpcIixcclxuICAgICAgICBlcnJvcj8ubWVzc2FnZSB8fCBlcnJvclxyXG4gICAgICApO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBmZXRjaENvQXBwbGljYW50KCk7XHJcbn0sIFtyZWxvYWRUcmlnZ2VyLCB1c2Vyc10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVBbnREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBpZiAodmFsdWUgIT09IFwiT3RoZXJcIikge1xyXG4gICAgICBzZXRDdXN0b21SZWxhdGlvbnNoaXAoXCJcIik7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RXJyb3JzLFxyXG4gICAgICBbZmllbGRdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlQW50SW5wdXREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKHsgLi4uZXJyb3JzLCBbZmllbGRdOiBcIlwiIH0pO1xyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkVycm9ycykgPT4gKHtcclxuICAgICAgLi4ucHJldkVycm9ycyxcclxuICAgICAgW25hbWVdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICh0eXBlKSA9PiB7XHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7fTtcclxuICAgIGNvbnN0IGRhdGEgPSB0eXBlID09PSBcImFkZENvQXBwbGljYW50XCIgPyBmb3JtRGF0YSA6IHVwZGF0ZUZvcm1EYXRhO1xyXG5cclxuICAgIC8vIERlZmluZSBhIHNpbmdsZSByZWdleCBvYmplY3RcclxuICAgIGNvbnN0IHJlZ2V4ID0ge1xyXG4gICAgICBlbWFpbDogL15bXlxcc0BdK0BbXlxcc0BdK1xcLlteXFxzQF0rJC8sXHJcbiAgICAgIHBob25lOiAvXls2LTldXFxkezl9JC8sXHJcbiAgICAgIHBpbmNvZGU6IC9eXFxkezZ9JC8sXHJcbiAgICAgIGFkaGFhcjogL15cXGR7MTJ9JC8sXHJcbiAgICAgIHBhbjogL15bQS1aXXs1fVswLTldezR9W0EtWl17MX0kLyxcclxuICAgIH07XHJcblxyXG4gICAgLy8gSGVscGVyIGZ1bmN0aW9uIGZvciBmaWxlIHZhbGlkYXRpb25cclxuICAgIGNvbnN0IHZhbGlkYXRlRmlsZSA9IChmaWxlLCBuYW1lKSA9PiB7XHJcbiAgICAgIGlmICghZmlsZSkge1xyXG4gICAgICAgIHJldHVybiBgJHtuYW1lfSBpcyByZXF1aXJlZGA7XHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgYWxsb3dlZFR5cGVzID0gW1wiaW1hZ2UvanBlZ1wiLCBcImltYWdlL3BuZ1wiLCBcImltYWdlL2pwZ1wiXTtcclxuICAgICAgaWYgKGZpbGUgaW5zdGFuY2VvZiBGaWxlKSB7XHJcbiAgICAgICAgaWYgKCFhbGxvd2VkVHlwZXMuaW5jbHVkZXMoZmlsZS50eXBlKSkge1xyXG4gICAgICAgICAgcmV0dXJuIFwiT25seSBKUEcgYW5kIFBORyBmaWxlcyBhcmUgYWxsb3dlZFwiO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZmlsZS5zaXplID4gMiAqIDEwMjQgKiAxMDI0KSB7XHJcbiAgICAgICAgICByZXR1cm4gXCJGaWxlIHNpemUgbXVzdCBiZSBsZXNzIHRoYW4gMk1CXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2UgaWYgKHR5cGVvZiBmaWxlID09PSBcInN0cmluZ1wiICYmIGZpbGUudHJpbSgpID09PSBcIlwiKSB7XHJcbiAgICAgICAgcmV0dXJuIGAke25hbWV9IGlzIHJlcXVpcmVkYDtcclxuICAgICAgfVxyXG4gICAgICByZXR1cm4gbnVsbDtcclxuICAgIH07XHJcblxyXG4gICAgLy8gR2VuZXJhbCB2YWxpZGF0aW9uIGZvciBhbGwgdHlwZXNcclxuICAgIGlmICghZGF0YS51c2VyX2lkKSBuZXdFcnJvcnMudXNlcl9pZCA9IFwiQ3VzdG9tZXIgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgaWYgKCFkYXRhLmNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlKVxyXG4gICAgICBuZXdFcnJvcnMuY29fYXBwbGljYW50X3JlZmVycmVkX3R5cGUgPSBcIlJlZmVycmVkIFR5cGUgaXMgcmVxdWlyZWRcIjtcclxuICAgIGlmICghZGF0YS5lbnJvbGxtZW50X2lkcyB8fCBkYXRhLmVucm9sbG1lbnRfaWRzLmxlbmd0aCA9PT0gMClcclxuICAgICAgbmV3RXJyb3JzLmVucm9sbG1lbnRfaWRzID0gXCJFbnJvbGxtZW50IGlzIHJlcXVpcmVkXCI7XHJcblxyXG4gICAgLy8gQ29uZGl0aW9uYWwgdmFsaWRhdGlvbiBiYXNlZCBvbiByZWZlcnJlZCB0eXBlXHJcbiAgICBpZiAoZGF0YS5jb19hcHBsaWNhbnRfcmVmZXJyZWRfdHlwZSA9PT0gXCJDdXN0b21lclwiKSB7XHJcbiAgICAgIGlmICghZGF0YS51c2VyX2NvX2FwcGxpY2FudClcclxuICAgICAgICBuZXdFcnJvcnMudXNlcl9jb19hcHBsaWNhbnQgPSBcIlJlZmVycmVkIEN1c3RvbWVyIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgIGlmICghZGF0YS5jb19hcHBsaWNhbnRfZGVzY3JpcHRpb24/LnRyaW0oKSlcclxuICAgICAgICBuZXdFcnJvcnMuY29fYXBwbGljYW50X2Rlc2NyaXB0aW9uID0gXCJEZXNjcmlwdGlvbiBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmIChkYXRhLmNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlID09PSBcIlByb3BlcnR5XCIpIHtcclxuICAgICAgaWYgKCFkYXRhLmNvX2FwcGxpY2FudF9kZXNjcmlwdGlvbj8udHJpbSgpKVxyXG4gICAgICAgIG5ld0Vycm9ycy5jb19hcHBsaWNhbnRfZGVzY3JpcHRpb24gPSBcIkRlc2NyaXB0aW9uIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgIGlmICghZGF0YS5jb19hcHBsaWNhbnRfZG9jdW1lbnRfbmFtZT8udHJpbSgpKVxyXG4gICAgICAgIG5ld0Vycm9ycy5jb19hcHBsaWNhbnRfZG9jdW1lbnRfbmFtZSA9IFwiRG9jdW1lbnQgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgICBsZXQgZmlsZUVycm9yID0gdmFsaWRhdGVGaWxlKFxyXG4gICAgICAgIGRhdGEuY29fYXBwbGljYW50X2RvY3VtZW50LFxyXG4gICAgICAgIFwiUHJvcGVydHkgRG9jdW1lbnQgUGhvdG9cIlxyXG4gICAgICApO1xyXG4gICAgICBpZiAoZmlsZUVycm9yKSBuZXdFcnJvcnMuY29fYXBwbGljYW50X2RvY3VtZW50ID0gZmlsZUVycm9yO1xyXG4gICAgfSBlbHNlIGlmIChkYXRhLmNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlID09PSBcIlRoaXJkIFBhcnR5XCIpIHtcclxuICAgICAgLy8gUGVyc29uYWwgSW5mb3JtYXRpb25cclxuICAgICAgaWYgKCFkYXRhLmNvX2FwcGxpY2FudF9uYW1lPy50cmltKCkpXHJcbiAgICAgICAgbmV3RXJyb3JzLmNvX2FwcGxpY2FudF9uYW1lID0gXCJDbyBBcHBsaWNhbnQgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgICBpZiAoIWRhdGEuY29fYXBwbGljYW50X3JlbGF0aW9uc2hpcF90eXBlPy50cmltKCkpXHJcbiAgICAgICAgbmV3RXJyb3JzLmNvX2FwcGxpY2FudF9yZWxhdGlvbnNoaXBfdHlwZSA9XHJcbiAgICAgICAgICBcIkNvIEFwcGxpY2FudCBSZWxhdGlvbnNoaXAgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgaWYgKFxyXG4gICAgICAgICFkYXRhLmNvX2FwcGxpY2FudF9waG9uZV9udW1iZXIgfHxcclxuICAgICAgICAhcmVnZXgucGhvbmUudGVzdChkYXRhLmNvX2FwcGxpY2FudF9waG9uZV9udW1iZXIpXHJcbiAgICAgICkge1xyXG4gICAgICAgIG5ld0Vycm9ycy5jb19hcHBsaWNhbnRfcGhvbmVfbnVtYmVyID0gXCJJbnZhbGlkIFBob25lIE51bWJlclwiO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChcclxuICAgICAgICAhZGF0YS5jb19hcHBsaWNhbnRfZW1haWwgfHxcclxuICAgICAgICAhcmVnZXguZW1haWwudGVzdChkYXRhLmNvX2FwcGxpY2FudF9lbWFpbClcclxuICAgICAgKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzLmNvX2FwcGxpY2FudF9lbWFpbCA9IFwiSW52YWxpZCBFbWFpbFwiO1xyXG4gICAgICB9XHJcbiAgICAgIGlmICghZGF0YS5jb19hcHBsaWNhbnRfYWRkcmVzcz8udHJpbSgpKVxyXG4gICAgICAgIG5ld0Vycm9ycy5jb19hcHBsaWNhbnRfYWRkcmVzcyA9IFwiQWRkcmVzcyBpcyByZXF1aXJlZFwiO1xyXG4gICAgICBpZiAoXHJcbiAgICAgICAgIWRhdGEuY29fYXBwbGljYW50X3BpbmNvZGUgfHxcclxuICAgICAgICAhcmVnZXgucGluY29kZS50ZXN0KGRhdGEuY29fYXBwbGljYW50X3BpbmNvZGUpXHJcbiAgICAgICkge1xyXG4gICAgICAgIG5ld0Vycm9ycy5jb19hcHBsaWNhbnRfcGluY29kZSA9IFwiSW52YWxpZCBQaW5jb2RlXCI7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIEtZQyBEb2N1bWVudHNcclxuICAgICAgaWYgKFxyXG4gICAgICAgICFkYXRhLmNvX2FwcGxpY2FudF9hZGhhYXJfbm8gfHxcclxuICAgICAgICAhcmVnZXguYWRoYWFyLnRlc3QoZGF0YS5jb19hcHBsaWNhbnRfYWRoYWFyX25vKVxyXG4gICAgICApIHtcclxuICAgICAgICBuZXdFcnJvcnMuY29fYXBwbGljYW50X2FkaGFhcl9ubyA9IFwiSW52YWxpZCBBYWRoYWFyIE51bWJlclwiO1xyXG4gICAgICB9XHJcbiAgICAgIGlmIChcclxuICAgICAgICAhZGF0YS5jb19hcHBsaWNhbnRfcGFuX25vIHx8XHJcbiAgICAgICAgIXJlZ2V4LnBhbi50ZXN0KGRhdGEuY29fYXBwbGljYW50X3Bhbl9ubylcclxuICAgICAgKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzLmNvX2FwcGxpY2FudF9wYW5fbm8gPVxyXG4gICAgICAgICAgXCJJbnZhbGlkIFBBTiBDYXBpdGFsIEFscGhhYmV0IHdpdGggTnVtYmVyXCI7XHJcbiAgICAgIH1cclxuICAgICAgbGV0IGZpbGVFcnJvciA9IHZhbGlkYXRlRmlsZShkYXRhLmNvX2FwcGxpY2FudF9waG90bywgXCJQcm9maWxlIFBob3RvXCIpO1xyXG4gICAgICBpZiAoZmlsZUVycm9yKSBuZXdFcnJvcnMuY29fYXBwbGljYW50X3Bob3RvID0gZmlsZUVycm9yO1xyXG4gICAgICBmaWxlRXJyb3IgPSB2YWxpZGF0ZUZpbGUoXHJcbiAgICAgICAgZGF0YS5jb19hcHBsaWNhbnRfcGFuX2RvY3VtZW50LFxyXG4gICAgICAgIFwiUEFOIENhcmQgUGhvdG9cIlxyXG4gICAgICApO1xyXG4gICAgICBpZiAoZmlsZUVycm9yKSBuZXdFcnJvcnMuY29fYXBwbGljYW50X3Bhbl9kb2N1bWVudCA9IGZpbGVFcnJvcjtcclxuICAgICAgZmlsZUVycm9yID0gdmFsaWRhdGVGaWxlKFxyXG4gICAgICAgIGRhdGEuY29fYXBwbGljYW50X2FhZGhhcl9kb2N1bWVudCxcclxuICAgICAgICBcIkFhZGhhYXIgQ2FyZCBQaG90b1wiXHJcbiAgICAgICk7XHJcbiAgICAgIGlmIChmaWxlRXJyb3IpIG5ld0Vycm9ycy5jb19hcHBsaWNhbnRfYWFkaGFyX2RvY3VtZW50ID0gZmlsZUVycm9yO1xyXG5cclxuICAgICAgLy8gT2NjdXBhdGlvbiBEZXRhaWxzXHJcbiAgICAgIGlmICghZGF0YS5jb19hcHBsaWNhbnRfb2NjdXBhdGlvbilcclxuICAgICAgICBuZXdFcnJvcnMuY29fYXBwbGljYW50X29jY3VwYXRpb24gPSBcIk9jY3VwYXRpb24gaXMgcmVxdWlyZWRcIjtcclxuXHJcbiAgICAgIC8vIENvbmRpdGlvbmFsIHZhbGlkYXRpb24gZm9yIE9jY3VwYXRpb24gZmllbGRzXHJcbiAgICAgIHN3aXRjaCAoZGF0YS5jb19hcHBsaWNhbnRfb2NjdXBhdGlvbikge1xyXG4gICAgICAgIGNhc2UgXCJTZWxmIEVtcGxveWVkXCI6XHJcbiAgICAgICAgY2FzZSBcIlNhbGFyaWVkXCI6XHJcbiAgICAgICAgICBpZiAoIWRhdGEuY29fYXBwbGljYW50X2J1c3NpbmVzc190eXBlPy50cmltKCkpXHJcbiAgICAgICAgICAgIG5ld0Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX3R5cGUgPSBcIkJ1c2luZXNzIFR5cGUgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgICAgIGlmICghZGF0YS5jb19hcHBsaWNhbnRfYnVzc2luZXNzX25hbWU/LnRyaW0oKSlcclxuICAgICAgICAgICAgbmV3RXJyb3JzLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfbmFtZSA9IFwiQnVzaW5lc3MgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgICAgaWYgKCFkYXRhLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzcz8udHJpbSgpKVxyXG4gICAgICAgICAgICBuZXdFcnJvcnMuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzID1cclxuICAgICAgICAgICAgICBcIkJ1c2luZXNzIEFkZHJlc3MgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJQcm9mZXNzaW9uYWxcIjpcclxuICAgICAgICAgIGlmICghZGF0YS5jb19hcHBsaWNhbnRfcHJvZmVzc2lvbl90eXBlPy50cmltKCkpXHJcbiAgICAgICAgICAgIG5ld0Vycm9ycy5jb19hcHBsaWNhbnRfcHJvZmVzc2lvbl90eXBlID1cclxuICAgICAgICAgICAgICBcIlByb2Zlc3Npb24gVHlwZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgICAgaWYgKCFkYXRhLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzcz8udHJpbSgpKVxyXG4gICAgICAgICAgICBuZXdFcnJvcnMuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzID1cclxuICAgICAgICAgICAgICBcIkJ1c2luZXNzIEFkZHJlc3MgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJBZ3JpIEFsbGllZFwiOlxyXG4gICAgICAgICAgaWYgKCFkYXRhLmNvX2FwcGxpY2FudF9hZ3JpX3J0Y19ubz8udHJpbSgpKVxyXG4gICAgICAgICAgICBuZXdFcnJvcnMuY29fYXBwbGljYW50X2FncmlfcnRjX25vID0gXCJSVEMgTnVtYmVyIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgICAgICBpZiAoIWRhdGEuY29fYXBwbGljYW50X2xhbmRfaG9sZGluZ3MpXHJcbiAgICAgICAgICAgIG5ld0Vycm9ycy5jb19hcHBsaWNhbnRfbGFuZF9ob2xkaW5ncyA9IFwiTGFuZCBIb2xkaW5ncyBpcyByZXF1aXJlZFwiO1xyXG4gICAgICAgICAgaWYgKCFkYXRhLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzcz8udHJpbSgpKVxyXG4gICAgICAgICAgICBuZXdFcnJvcnMuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzID1cclxuICAgICAgICAgICAgICBcIkJ1c2luZXNzIEFkZHJlc3MgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIGNhc2UgXCJPdGhlclwiOlxyXG4gICAgICAgICAgaWYgKCFkYXRhLmNvX2FwcGxpY2FudF9vY2N1cGF0aW9uX3N1Yj8udHJpbSgpKVxyXG4gICAgICAgICAgICBuZXdFcnJvcnMuY29fYXBwbGljYW50X29jY3VwYXRpb25fc3ViID1cclxuICAgICAgICAgICAgICBcIk9jY3VwYXRpb24gU3ViLWNhdGVnb3J5IGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgIGRhdGEuY29fYXBwbGljYW50X29jY3VwYXRpb25fc3ViID09PVxyXG4gICAgICAgICAgICAgIFwiUnVubmluZyBhbiB1bnJlZ2lzdGVyZWQgQnVzaW5lc3NcIiAmJlxyXG4gICAgICAgICAgICAhZGF0YS5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3M/LnRyaW0oKVxyXG4gICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgIG5ld0Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3MgPVxyXG4gICAgICAgICAgICAgIFwiQWRkcmVzcyBpcyByZXF1aXJlZCBmb3IgdGhpcyBvY2N1cGF0aW9uXCI7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgICAgZmlsZUVycm9yID0gdmFsaWRhdGVGaWxlKFxyXG4gICAgICAgIGRhdGEuY29fYXBwbGljYW50X2luY29tZV9kb2N1bWVudCxcclxuICAgICAgICBcIkluY29tZSBEb2N1bWVudCBQaG90b1wiXHJcbiAgICAgICk7XHJcbiAgICAgIGlmIChmaWxlRXJyb3IpIG5ld0Vycm9ycy5jb19hcHBsaWNhbnRfaW5jb21lX2RvY3VtZW50ID0gZmlsZUVycm9yO1xyXG5cclxuICAgICAgLy8gQmFuayBEZXRhaWxzXHJcbiAgICAgIGlmICghZGF0YS5jb19hcHBsaWNhbnRfYmFua19uYW1lPy50cmltKCkpXHJcbiAgICAgICAgbmV3RXJyb3JzLmNvX2FwcGxpY2FudF9iYW5rX25hbWUgPSBcIkJhbmsgTmFtZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgICBpZiAoIWRhdGEuY29fYXBwbGljYW50X2JhbmtfYWNjb3VudF9udW1iZXI/LnRyaW0oKSlcclxuICAgICAgICBuZXdFcnJvcnMuY29fYXBwbGljYW50X2JhbmtfYWNjb3VudF9udW1iZXIgPVxyXG4gICAgICAgICAgXCJCYW5rIEFjY291bnQgTnVtYmVyIGlzIHJlcXVpcmVkXCI7XHJcbiAgICAgIGlmICghZGF0YS5jb19hcHBsaWNhbnRfYmFua19icmFuY2g/LnRyaW0oKSlcclxuICAgICAgICBuZXdFcnJvcnMuY29fYXBwbGljYW50X2JhbmtfYnJhbmNoID0gXCJCYW5rIEJyYW5jaCBpcyByZXF1aXJlZFwiO1xyXG4gICAgICBpZiAoIWRhdGEuY29fYXBwbGljYW50X2JhbmtfaWZzY19jb2RlPy50cmltKCkpXHJcbiAgICAgICAgbmV3RXJyb3JzLmNvX2FwcGxpY2FudF9iYW5rX2lmc2NfY29kZSA9IFwiQmFuayBJRlNDIENvZGUgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgZmlsZUVycm9yID0gdmFsaWRhdGVGaWxlKFxyXG4gICAgICAgIGRhdGEuY29fYXBwbGljYW50X2JhbmtfcGFzc2Jvb2tfcGhvdG8sXHJcbiAgICAgICAgXCJCYW5rIFBhc3Nib29rIFBob3RvXCJcclxuICAgICAgKTtcclxuICAgICAgaWYgKGZpbGVFcnJvcikgbmV3RXJyb3JzLmNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvID0gZmlsZUVycm9yO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc3ZhbGlkID0gdmFsaWRhdGVGb3JtKFwiYWRkQ29BcHBsaWNhbnRcIik7XHJcbiAgICBpZiAoaXN2YWxpZCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGZtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG4gICAgICAgIE9iamVjdC5lbnRyaWVzKGZvcm1EYXRhKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcclxuICAgICAgICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIEZpbGUpIHtcclxuICAgICAgICAgICAgZm1EYXRhLmFwcGVuZChrZXksIHZhbHVlKTsgLy8gIGFjdHVhbCBmaWxlXHJcbiAgICAgICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XHJcbiAgICAgICAgICAgIHZhbHVlLmZvckVhY2goKHYpID0+IGZtRGF0YS5hcHBlbmQoYCR7a2V5fVtdYCwgdikpO1xyXG4gICAgICAgICAgfSBlbHNlIGlmICh2YWx1ZSkge1xyXG4gICAgICAgICAgICBmbURhdGEuYXBwZW5kKGtleSwgdmFsdWUpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBleHRyYURvY3MuZm9yRWFjaCgoZG9jLCBpKSA9PiB7XHJcbiAgICAgICAgICBpZiAoZG9jLmZpbGUpIHtcclxuICAgICAgICAgICAgZm1EYXRhLmFwcGVuZChcImNvX2FwcGxpY2FudF9hbGxfZG9jdW1lbnRcIiwgZG9jLmZpbGUpOyAvLyBmaWxlXHJcbiAgICAgICAgICAgIGZtRGF0YS5hcHBlbmQoXHJcbiAgICAgICAgICAgICAgXCJkb2N1bWVudF9uYW1lW11cIixcclxuICAgICAgICAgICAgICBkb2MuZG9jdW1lbnRfbmFtZSB8fCBgRG9jdW1lbnRfJHtpICsgMX1gXHJcbiAgICAgICAgICAgICk7IC8vIG5hbWUgc2VwYXJhdGVseVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFxyXG4gICAgICAgICAgXCIvY29hcHBsaWNhbnQvYWRkLWNvLWFwcGxpY2FudC1pbmZvXCIsXHJcbiAgICAgICAgICAvL2Zvcm1EYXRhLFxyXG4gICAgICAgICAgZm1EYXRhLFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCIsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJDbyBBcHBsaWNhbnQgQWRkZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgdXNlcl9pZDogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9uYW1lOiBcIlwiLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X2VtYWlsOiBcIlwiLFxyXG4gICAgICAgICAgdXNlcl9jb19hcHBsaWNhbnQ6IFwiXCIsXHJcbiAgICAgICAgICBjb19hcHBsaWNhbnRfcGhvbmVfbnVtYmVyOiBcIlwiLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X2FkZHJlc3M6IFwiXCIsXHJcbiAgICAgICAgICBjb19hcHBsaWNhbnRfcGluY29kZTogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9hZGhhYXJfbm86IFwiXCIsXHJcbiAgICAgICAgICBjb19hcHBsaWNhbnRfcGFuX25vOiBcIlwiLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X2dlbmRlcjogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9tYXJpdGFsX3N0YXR1czogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9kYXRlb2ZiaXJ0aDogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9uYXRpb25hbGl0eTogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF92aWxsYWdlOiBcIlwiLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X3RhbHVrOiBcIlwiLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X2ZhdGhlcl9uYW1lOiBcIlwiLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X2Rpc3RyaWN0OiBcIlwiLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X3N0YXRlOiBcIlwiLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X2Rlc2NyaXB0aW9uOiBcIlwiLFxyXG4gICAgICAgICAgZW5yb2xsbWVudF9pZHM6IFtdLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X2FsdGVybmF0ZV9udW1iZXI6IFwiXCIsXHJcbiAgICAgICAgICBjb19hcHBsaWNhbnRfcmVmZXJyZWRfdHlwZTogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9kb2N1bWVudDogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9kb2N1bWVudF9uYW1lOiBcIlwiLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X3Bob3RvOiBcIlwiLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X3Bhbl9kb2N1bWVudDogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9hYWRoYXJfZG9jdW1lbnQ6IFwiXCIsXHJcbiAgICAgICAgICBjb19hcHBsaWNhbnRfcmVsYXRpb25zaGlwX3R5cGU6IFwiXCIsXHJcbiAgICAgICAgICBjb19hcHBsaWNhbnRfb2NjdXBhdGlvbjogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9pbmNvbWU6IFwiXCIsXHJcbiAgICAgICAgICBjb19hcHBsaWNhbnRfY29uc2VudF9kb2N1bWVudDogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9iYW5rX25hbWU6IFwiXCIsXHJcbiAgICAgICAgICBjb19hcHBsaWNhbnRfYmFua19hY2NvdW50X251bWJlcjogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9iYW5rX2JyYW5jaDogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9iYW5rX2lmc2NfY29kZTogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvOiBcIlwiLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X3NlY3Rvcl9uYW1lOiBcIlwiLFxyXG4gICAgICAgICAgY29fYXBwbGljYW50X2luY29tZV9kb2N1bWVudDogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9idXNzaW5lc3NfdHlwZTogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9idXNzaW5lc3NfbmFtZTogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzczogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9wcm9mZXNzaW9uX3R5cGU6IFwiXCIsXHJcbiAgICAgICAgICBjb19hcHBsaWNhbnRfYWdyaV9ydGNfbm86IFwiXCIsXHJcbiAgICAgICAgICBjb19hcHBsaWNhbnRfbGFuZF9ob2xkaW5nczogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9vY2N1cGF0aW9uX3N1YjogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9hbGxfZG9jdW1lbnRfbmFtZTogXCJcIixcclxuICAgICAgICAgIGNvX2FwcGxpY2FudF9hbGxfZG9jdW1lbnQ6IFwiXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGFkZGluZyBDbyBBcHBsaWNhbnQ6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICBtZXNzYWdlOlxyXG4gICAgICAgICAgICBlcnJvcj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkLlwiLFxyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBmbURhdGEgPSBuZXcgRm9ybURhdGEoKTtcclxuXHJcbiAgICAgIGNvbnN0IHsgY29fYXBwbGljYW50X2FsbF9kb2N1bWVudCwgLi4ucmVzdCB9ID0gdXBkYXRlRm9ybURhdGE7XHJcblxyXG4gICAgICAvLyBBcHBlbmQgbm9uLWZpbGUgZmllbGRzXHJcbiAgICAgIE9iamVjdC5lbnRyaWVzKHJlc3QpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xyXG4gICAgICAgIGlmICh2YWx1ZSkgZm1EYXRhLmFwcGVuZChrZXksIHZhbHVlKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBIYW5kbGUgc2luZ2xlIGZpbGUgZmllbGRzXHJcbiAgICAgIGNvbnN0IHNpbmdsZUZpbGVGaWVsZHMgPSBbXHJcbiAgICAgICAgXCJjb19hcHBsaWNhbnRfcGhvdG9cIixcclxuICAgICAgICBcImNvX2FwcGxpY2FudF9hYWRoYXJfZG9jdW1lbnRcIixcclxuICAgICAgICBcImNvX2FwcGxpY2FudF9wYW5fZG9jdW1lbnRcIixcclxuICAgICAgICBcImNvX2FwcGxpY2FudF9pbmNvbWVfZG9jdW1lbnRcIixcclxuICAgICAgICBcImNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvXCIsXHJcbiAgICAgICAgXCJjb19hcHBsaWNhbnRfZG9jdW1lbnRcIixcclxuICAgICAgXTtcclxuXHJcbiAgICAgIHNpbmdsZUZpbGVGaWVsZHMuZm9yRWFjaCgoZmllbGQpID0+IHtcclxuICAgICAgICBpZiAodXBkYXRlRm9ybURhdGFbZmllbGRdIGluc3RhbmNlb2YgRmlsZSkge1xyXG4gICAgICAgICAgZm1EYXRhLmFwcGVuZChmaWVsZCwgdXBkYXRlRm9ybURhdGFbZmllbGRdKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgLy8gSGFuZGxlIG11bHRpcGxlIGV4dHJhIGRvY3NcclxuICAgICAgaWYgKGV4dHJhRG9jcyAmJiBBcnJheS5pc0FycmF5KGV4dHJhRG9jcykpIHtcclxuICAgICAgICBleHRyYURvY3MuZm9yRWFjaCgoZG9jLCBpKSA9PiB7XHJcbiAgICAgICAgICBpZiAoZG9jLmZpbGUgaW5zdGFuY2VvZiBGaWxlKSB7XHJcbiAgICAgICAgICAgIGZtRGF0YS5hcHBlbmQoXCJjb19hcHBsaWNhbnRfYWxsX2RvY3VtZW50XCIsIGRvYy5maWxlKTsgLy8gZmlsZVxyXG4gICAgICAgICAgICBmbURhdGEuYXBwZW5kKFxyXG4gICAgICAgICAgICAgIFwiZG9jdW1lbnRfbmFtZVtdXCIsIC8vIOKchSBzZW5kIGFzIGFycmF5XHJcbiAgICAgICAgICAgICAgZG9jLmRvY3VtZW50X25hbWUgfHwgYERvY3VtZW50XyR7aSArIDF9YFxyXG4gICAgICAgICAgICApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBhd2FpdCBhcGkucHV0KFxyXG4gICAgICAgIGAvY29hcHBsaWNhbnQvdXBkYXRlLWNvLWFwcGxpY2FudC1pbmZvLyR7Y3VycmVudFVwZGF0ZUNvQXBwbGljYW50Py5faWR9YCxcclxuICAgICAgICBmbURhdGEsXHJcbiAgICAgICAgeyBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwibXVsdGlwYXJ0L2Zvcm0tZGF0YVwiIH0gfVxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgbWVzc2FnZTogXCJDbyBBcHBsaWNhbnQgVXBkYXRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB1cGRhdGluZyBDbyBBcHBsaWNhbnQ6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICBtZXNzYWdlOiBlcnJvcj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJVcGRhdGUgZmFpbGVkXCIsXHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgICB7a2V5OiBcImNvX2FwcGxpY2FudF9jb2RlXCIsIGhlYWRlcjogXCJDbyBBcHBsaWNhbnQgQ29kZVwifSxcclxuICAgIHsga2V5OiBcInVzZXJfaWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29fYXBwbGljYW50X3JlZmVycmVkX3R5cGVcIiwgaGVhZGVyOiBcIlJlZmVycmVkIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW5yb2xsbWVudF9zdW1tYXJ5XCIsIGhlYWRlcjogXCJFbnJvbGxtZW50IERldGFpbHNcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29fYXBwbGljYW50X25hbWVcIiwgaGVhZGVyOiBcIkNvIEFwcGxpY2FudCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcImNvX2FwcGxpY2FudF9waG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkNvIEFwcGxpY2FudCBQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGZpbHRlcmVkR3VhcmFudG9yID0gdXNlcnMuZmlsdGVyKCh1c2VycykgPT5cclxuICAgIHVzZXJzLmZ1bGxfbmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSlcclxuICApO1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9jb2FwcGxpY2FudC9nZXQtY28tYXBwbGljYW50LWluZm8tYnktaWQvJHt1c2VySWR9YFxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2V0Q3VycmVudENvQXBwbGljYW50KHJlc3BvbnNlLmRhdGE/LmNvQXBwbGljYW50Py5faWQgfHwgbnVsbCk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBDbyBBcHBsaWNhbnQ6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVGaWxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgZmlsZXMgfSA9IGUudGFyZ2V0O1xyXG4gICAgY29uc3QgZmlsZSA9IGZpbGVzWzBdO1xyXG5cclxuICAgIGlmIChmaWxlKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgW25hbWVdOiBmaWxlLCAvLyDinIUga2VlcCByZWFsIGZpbGUgb2JqZWN0XHJcbiAgICAgICAgW2Ake25hbWV9X3ByZXZpZXdgXTogVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKSwgLy8gZm9yIHByZXZpZXdcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlSW5wdXRGaWxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgZmlsZXMgfSA9IGUudGFyZ2V0O1xyXG4gICAgY29uc3QgZmlsZSA9IGZpbGVzWzBdO1xyXG5cclxuICAgIGlmIChmaWxlKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgW25hbWVdOiBmaWxlLCAvLyDinIUga2VlcCByZWFsIGZpbGUgb2JqZWN0XHJcbiAgICAgICAgW2Ake25hbWV9X3ByZXZpZXdgXTogVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKSwgLy8gZm9yIHByZXZpZXdcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL2NvYXBwbGljYW50L2dldC1jby1hcHBsaWNhbnQtaW5mby1ieS1pZC8ke3VzZXJJZH1gXHJcbiAgICAgICk7XHJcbiAgICAgIGNvbnN0IGNvYXBwbGljYW50ID0gcmVzcG9uc2U/LmRhdGE/LmNvQXBwbGljYW50O1xyXG4gICAgICBjb25zdCBtYXRjaGVkRW5yb2xsbWVudHMgPSAoY29hcHBsaWNhbnQ/LmVucm9sbG1lbnRfaWRzIHx8IFtdKS5tYXAoXHJcbiAgICAgICAgKGUpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGUuX2lkLFxyXG4gICAgICAgICAgZ3JvdXBfbmFtZTogZT8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHRpY2tldDogZT8udGlja2V0cyB8fCBcIk4vQVwiLFxyXG4gICAgICAgIH0pXHJcbiAgICAgICk7XHJcbiAgICAgIHNldEZpbHRlcmVkRW5yb2xsbWVudHMobWF0Y2hlZEVucm9sbG1lbnRzKTtcclxuXHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICB1c2VyX2lkOiBjb2FwcGxpY2FudD8udXNlcl9pZD8uX2lkIHx8IFwiXCIsXHJcbiAgICAgICAgZW5yb2xsbWVudF9pZHM6IGNvYXBwbGljYW50Py5lbnJvbGxtZW50X2lkcz8ubWFwKChlKSA9PiBlLl9pZCkgfHwgW10sXHJcbiAgICAgICAgY29fYXBwbGljYW50X25hbWU6IGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF9lbWFpbDogY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9lbWFpbCB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF9waG9uZV9udW1iZXI6IGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfcGhvbmVfbnVtYmVyIHx8IFwiXCIsXHJcbiAgICAgICAgdXNlcl9jb19hcHBsaWNhbnQ6IGNvYXBwbGljYW50Py51c2VyX2NvX2FwcGxpY2FudCB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF9hZGRyZXNzOiBjb2FwcGxpY2FudD8uY29fYXBwbGljYW50X2FkZHJlc3MgfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfcGluY29kZTogY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9waW5jb2RlIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X2FkaGFhcl9ubzogY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9hZGhhYXJfbm8gfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfcGFuX25vOiBjb2FwcGxpY2FudD8uY29fYXBwbGljYW50X3Bhbl9ubyB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF9nZW5kZXI6IGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfZ2VuZGVyIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X21hcml0YWxfc3RhdHVzOlxyXG4gICAgICAgICAgY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9tYXJpdGFsX3N0YXR1cyB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF9kYXRlb2ZiaXJ0aDogY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9kYXRlb2ZiaXJ0aCB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF9uYXRpb25hbGl0eTogY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9uYXRpb25hbGl0eSB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF92aWxsYWdlOiBjb2FwcGxpY2FudD8uY29fYXBwbGljYW50X3ZpbGxhZ2UgfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfdGFsdWs6IGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfdGFsdWsgfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfZmF0aGVyX25hbWU6IGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfZmF0aGVyX25hbWUgfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfZGlzdHJpY3Q6IGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfZGlzdHJpY3QgfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfc3RhdGU6IGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfc3RhdGUgfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfZGVzY3JpcHRpb246IGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfZGVzY3JpcHRpb24gfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfYWx0ZXJuYXRlX251bWJlcjpcclxuICAgICAgICAgIGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfYWx0ZXJuYXRlX251bWJlcixcclxuICAgICAgICBjb19hcHBsaWNhbnRfZG9jdW1lbnQ6IGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfZG9jdW1lbnQgfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfZG9jdW1lbnRfbmFtZTpcclxuICAgICAgICAgIGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfZG9jdW1lbnRfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlOlxyXG4gICAgICAgICAgY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X3Bob3RvOiBjb2FwcGxpY2FudD8uY29fYXBwbGljYW50X3Bob3RvIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X3Bhbl9kb2N1bWVudDogY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9wYW5fZG9jdW1lbnQgfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfYWFkaGFyX2RvY3VtZW50OlxyXG4gICAgICAgICAgY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9hYWRoYXJfZG9jdW1lbnQgfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfcmVsYXRpb25zaGlwX3R5cGU6XHJcbiAgICAgICAgICBjb2FwcGxpY2FudD8uY29fYXBwbGljYW50X3JlbGF0aW9uc2hpcF90eXBlIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X29jY3VwYXRpb246IGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfb2NjdXBhdGlvbiB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF9pbmNvbWU6IGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfaW5jb21lIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X2NvbnNlbnRfZG9jdW1lbnQ6XHJcbiAgICAgICAgICBjb2FwcGxpY2FudD8uY29fYXBwbGljYW50X2NvbnNlbnRfZG9jdW1lbnQgfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfYmFua19uYW1lOiBjb2FwcGxpY2FudD8uY29fYXBwbGljYW50X2JhbmtfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF9iYW5rX2FjY291bnRfbnVtYmVyOlxyXG4gICAgICAgICAgY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9iYW5rX2FjY291bnRfbnVtYmVyIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X2JhbmtfYnJhbmNoOiBjb2FwcGxpY2FudD8uY29fYXBwbGljYW50X2JhbmtfYnJhbmNoIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X2JhbmtfaWZzY19jb2RlOlxyXG4gICAgICAgICAgY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9iYW5rX2lmc2NfY29kZSB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvOlxyXG4gICAgICAgICAgY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X2luY29tZV9kb2N1bWVudDpcclxuICAgICAgICAgIGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfaW5jb21lX2RvY3VtZW50IHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X2J1c3NpbmVzc190eXBlOlxyXG4gICAgICAgICAgY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9idXNzaW5lc3NfdHlwZSB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF9idXNzaW5lc3NfbmFtZTpcclxuICAgICAgICAgIGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfYnVzc2luZXNzX25hbWUgfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3M6XHJcbiAgICAgICAgICBjb2FwcGxpY2FudD8uY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X3Byb2Zlc3Npb25fdHlwZTpcclxuICAgICAgICAgIGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfcHJvZmVzc2lvbl90eXBlIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X2FncmlfcnRjX25vOiBjb2FwcGxpY2FudD8uY29fYXBwbGljYW50X2FncmlfcnRjX25vIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X2xhbmRfaG9sZGluZ3M6XHJcbiAgICAgICAgICBjb2FwcGxpY2FudD8uY29fYXBwbGljYW50X2xhbmRfaG9sZGluZ3MgfHwgXCJcIixcclxuICAgICAgICBjb19hcHBsaWNhbnRfb2NjdXBhdGlvbl9zdWI6XHJcbiAgICAgICAgICBjb2FwcGxpY2FudD8uY29fYXBwbGljYW50X29jY3VwYXRpb25fc3ViIHx8IFwiXCIsXHJcbiAgICAgICAgY29fYXBwbGljYW50X2FsbF9kb2N1bWVudF9uYW1lOlxyXG4gICAgICAgICAgY29hcHBsaWNhbnQ/LmNvX2FwcGxpY2FudF9hbGxfZG9jdW1lbnRfbmFtZSB8fCBcIlwiLFxyXG4gICAgICAgIGNvX2FwcGxpY2FudF9hbGxfZG9jdW1lbnQ6IGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfYWxsX2RvY3VtZW50IHx8IFwiXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRFeHRyYURvY3MoXHJcbiAgICAgICAgKGNvYXBwbGljYW50Py5jb19hcHBsaWNhbnRfYWxsX2RvY3VtZW50IHx8IFtdKS5tYXAoKGQpID0+ICh7XHJcbiAgICAgICAgICBkb2N1bWVudF9uYW1lOiBkLmRvY3VtZW50X25hbWUsXHJcbiAgICAgICAgICBmaWxlOiBudWxsLCAvLyBubyBuZXcgZmlsZSB5ZXRcclxuICAgICAgICAgIHByZXZpZXc6IGQuZG9jdW1lbnRfdXJsLCAvLyBzaG93IGV4aXN0aW5nIGZpbGUgcHJldmlld1xyXG4gICAgICAgICAgZXhpc3RpbmdVcmw6IGQuZG9jdW1lbnRfdXJsLCAvLyBrZWVwIG9yaWdpbmFsIGluIGNhc2UgdXNlciBkb2VzbuKAmXQgcmVwbGFjZVxyXG4gICAgICAgIH0pKVxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2V0Q3VycmVudFVwZGF0ZUNvQXBwbGljYW50KGNvYXBwbGljYW50KTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIENvIEFwcGxpY2FudDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVDb0FwcGxpY2FudCA9IGFzeW5jICgpID0+IHtcclxuICAgIC8vIGNvbnNvbGUubG9nKGN1cnJlbnRDb0FwcGxpY2FudCxcImN1cnJlbnQgY29hcHBsaWNhbnl0XCIpXHJcbiAgICBpZiAoY3VycmVudENvQXBwbGljYW50KSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZGVsZXRlKFxyXG4gICAgICAgICAgYC9jb2FwcGxpY2FudC9kZWxldGUtY28tYXBwbGljYW50LWluZm8tYnktaWQvJHtjdXJyZW50Q29BcHBsaWNhbnR9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKHJlc3BvbnNlLCBcInNuZmJnc2diXCIpO1xyXG5cclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJjbyBhcHBsaWNhbnQgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICBzZXRTaG93TW9kYWxEZWxldGUoZmFsc2UpO1xyXG4gICAgICAgIHNldEN1cnJlbnRDb0FwcGxpY2FudChudWxsKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgQ28gQXBwbGljYW50OlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17R2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5DbyBBcHBsaWNhbnQgQXBwbGljYXRpb248L2gxPlxyXG5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbCh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtbC00IGJnLXZpb2xldC05NTAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctdmlvbGV0LTgwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICsgQWRkIENvIEFwcGxpY2FudFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7VGFibGVDb0FwcGxpY2FudD8ubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgICAgICAgdXBkYXRlSGFuZGxlcj17aGFuZGxlVXBkYXRlTW9kYWxPcGVufVxyXG4gICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlQ29BcHBsaWNhbnQsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkNvQXBwbGljYW50XCJcclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BDb0FwcGxpY2FudC5jc3ZgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGZhaWx1cmU9e1RhYmxlQ29BcHBsaWNhbnQubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgICBkYXRhPVwiQ28gQXBwbGljYW50IERhdGFcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8TW9kYWwgaXNWaXNpYmxlPXtzaG93TW9kYWx9IG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbChmYWxzZSl9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIEFkZCBDbyBBcHBsaWNhbnRcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGZvcm1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTZcIlxyXG4gICAgICAgICAgICAgIG1ldGhvZD1cIlBPU1RcIlxyXG4gICAgICAgICAgICAgIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9XHJcbiAgICAgICAgICAgICAgZW5jdHlwZT1cIm11bHRpcGFydC9mb3JtLWRhdGFcIlxyXG4gICAgICAgICAgICAgIG5vVmFsaWRhdGVcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnVzZXJfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXNlcl9pZDogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICBlbnJvbGxtZW50X2lkczogW10sXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWx0ZXJlZCA9IGVucm9sbG1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKGUpID0+IGUudXNlcl9pZD8uX2lkID09PSB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKGUpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9pZDogZS5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwX25hbWU6IGUuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpY2tldDogZS50aWNrZXRzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJlZEVucm9sbG1lbnRzKGZpbHRlcmVkKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICA/LnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtBcnJheS5mcm9tKFxyXG4gICAgICAgICAgICAgICAgICAgIG5ldyBNYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICBlbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKGUpID0+IGUudXNlcl9pZCAmJiBlLnVzZXJfaWQuZnVsbF9uYW1lPy50cmltKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKGUpID0+IFtlLnVzZXJfaWQuX2lkLCBlLnVzZXJfaWRdKVxyXG4gICAgICAgICAgICAgICAgICAgICkudmFsdWVzKClcclxuICAgICAgICAgICAgICAgICAgKS5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnVzZXJfaWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBTZWxlY3QgRW5yb2xsbWVudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgbW9kZT1cInRhZ3NcIlxyXG4gICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IGVucm9sbG1lbnRzXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5lbnJvbGxtZW50X2lkc31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhzZWxlY3RlZEVucm9sbG1lbnRJZHMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICBlbnJvbGxtZW50X2lkczogc2VsZWN0ZWRFbnJvbGxtZW50SWRzLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmxhYmVsPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkRW5yb2xsbWVudHMubWFwKChlbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHBhcnRzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVuLmdyb3VwX25hbWUgJiYgZW4uZ3JvdXBfbmFtZSAhPT0gXCJOL0FcIilcclxuICAgICAgICAgICAgICAgICAgICAgIHBhcnRzLnB1c2goZW4uZ3JvdXBfbmFtZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVuLnRpY2tldCAmJiBlbi50aWNrZXQgIT09IFwiTi9BXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICBwYXJ0cy5wdXNoKGBUaWNrZXQ6ICR7ZW4udGlja2V0fWApO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2VuLl9pZH0gdmFsdWU9e2VuLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtwYXJ0cy5qb2luKFwiIHwgXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcblxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5lbnJvbGxtZW50X2lkcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmVucm9sbG1lbnRfaWRzfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInJlZmVycmVkX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBTZWxlY3QgUmVmZXJyZWQgVHlwZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBSZWZlcnJlZCBUeXBlXCJcclxuICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X3JlZmVycmVkX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5jb19hcHBsaWNhbnRfcmVmZXJyZWRfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcImNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtbXCJDdXN0b21lclwiLCBcIlRoaXJkIFBhcnR5XCIsIFwiUHJvcGVydHlcIl0ubWFwKChyZWZUeXBlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtyZWZUeXBlfSB2YWx1ZT17cmVmVHlwZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cmVmVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X3JlZmVycmVkX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHtmb3JtRGF0YS5jb19hcHBsaWNhbnRfcmVmZXJyZWRfdHlwZSA9PT0gXCJDdXN0b21lclwiICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IENvIEFwcGxpY2FudCBDdXN0b21lcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIENvIEFwcGxpY2FudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInVzZXJfY29fYXBwbGljYW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8udXNlcl9jb19hcHBsaWNhbnQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcInVzZXJfY29fYXBwbGljYW50XCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9jb19hcHBsaWNhbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnVzZXJfY29fYXBwbGljYW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRlc2NcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIERlc2NyaXB0aW9uIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2Rlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIERlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciAke2ZpZWxkU2l6ZS5oZWlnaHR9IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfZGVzY3JpcHRpb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAge2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlID09PSBcIlRoaXJkIFBhcnR5XCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgbXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICB7LyogUGVyc29uYWwgSW5mb3JtYXRpb24gQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC02IGJnLXdoaXRlIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGVyc29uYWwgSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogR3VhcmFudG9yIE5hbWUgJiBQaG9uZSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIENvIEFwcGxpY2FudCBOYW1le1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQ28gQXBwbGljYW50IE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X25hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9waG9uZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfcGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X3Bob25lX251bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfcGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQ3VzdG9tZXIgUmVsYXRpb25zaGlwICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBDdXN0b21lciBSZWxhdGlvbnNoaXBcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQ3VzdG9tZXIgUmVsYXRpb25zaGlwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9yZWxhdGlvbnNoaXBfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuY29fYXBwbGljYW50X3JlbGF0aW9uc2hpcF90eXBlIHx8IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJjb19hcHBsaWNhbnRfcmVsYXRpb25zaGlwX3R5cGVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7W1wiRmF0aGVyXCIsIFwiU3BvdXNlXCIsIFwiT3RoZXJcIl0ubWFwKChyZWwpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17cmVsfSB2YWx1ZT17cmVsfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3JlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X3JlbGF0aW9uc2hpcF90eXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9yZWxhdGlvbnNoaXBfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuY29fYXBwbGljYW50X3JlbGF0aW9uc2hpcF90eXBlID09PSBcIk90aGVyXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUGxlYXNlIHNwZWNpZnkgdGhlIHJlbGF0aW9uc2hpcDpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgY3VzdG9tIHJlbGF0aW9uc2hpcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VzdG9tUmVsYXRpb25zaGlwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDdXN0b21SZWxhdGlvbnNoaXAoZS50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogRW1haWwgJiBET0IgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBFbWFpbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9lbWFpbCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfZW1haWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIERhdGUgb2YgQmlydGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfZGF0ZW9mYmlydGhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmNvX2FwcGxpY2FudF9kYXRlb2ZiaXJ0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IG5ldyBEYXRlKGZvcm1EYXRhLmNvX2FwcGxpY2FudF9kYXRlb2ZiaXJ0aClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0lTT1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBNYXJpdGFsIFN0YXR1cyAmIEdlbmRlciAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE1hcml0YWwgU3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE1hcml0YWwgU3RhdHVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9tYXJpdGFsX3N0YXR1c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuY29fYXBwbGljYW50X21hcml0YWxfc3RhdHVzIHx8IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJjb19hcHBsaWNhbnRfbWFyaXRhbF9zdGF0dXNcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7W1wiTWFycmllZFwiLCBcIlVubWFycmllZFwiLCBcIldpZG93XCIsIFwiRGl2b3JjZWRcIl0ubWFwKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKHN0YXR1cykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3N0YXR1c30gdmFsdWU9e3N0YXR1c30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEdlbmRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHZW5kZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2dlbmRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9nZW5kZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwiY29fYXBwbGljYW50X2dlbmRlclwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7W1wiTWFsZVwiLCBcIkZlbWFsZVwiXS5tYXAoKGcpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z30gdmFsdWU9e2d9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEFkZHJlc3MgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzcyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogVmlsbGFnZSAmIFRhbHVrICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVmlsbGFnZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF92aWxsYWdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY29fYXBwbGljYW50X3ZpbGxhZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFZpbGxhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVGFsdWtcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfdGFsdWtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfdGFsdWt9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFRhbHVrXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBTdGF0ZSAmIERpc3RyaWN0ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgU3RhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgU3RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X3N0YXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY29fYXBwbGljYW50X3N0YXRlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50RFNlbGVjdChcImNvX2FwcGxpY2FudF9zdGF0ZVwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7W1wiS2FybmF0YWthXCIsIFwiTWFoYXJhc2h0cmFcIiwgXCJUYW1pbCBOYWR1XCJdLm1hcChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChzdGF0ZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3N0YXRlfSB2YWx1ZT17c3RhdGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIERpc3RyaWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2Rpc3RyaWN0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY29fYXBwbGljYW50X2Rpc3RyaWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBEaXN0cmljdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogUGluY29kZSAmIEZhdGhlciBOYW1lICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUGluY29kZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9waW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY29fYXBwbGljYW50X3BpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfcGluY29kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfcGluY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRmF0aGVyIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfZmF0aGVyX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfZmF0aGVyX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEZhdGhlciBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBOYXRpb25hbGl0eSAmIEFsdGVybmF0ZSBOdW1iZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBOYXRpb25hbGl0eVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBOYXRpb25hbGl0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfbmF0aW9uYWxpdHlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfbmF0aW9uYWxpdHkgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwiY29fYXBwbGljYW50X25hdGlvbmFsaXR5XCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJJbmRpYW5cIiwgXCJPdGhlclwiXS5tYXAoKG5hdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtuYXRpb259IHZhbHVlPXtuYXRpb259PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBbHRlcm5hdGUgUGhvbmUgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2FsdGVybmF0ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfYWx0ZXJuYXRlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWx0ZXJuYXRlIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBLWUMgRG9jdW1lbnRzIENhcmQgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHAtNiBiZy13aGl0ZSBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEtZQyBEb2N1bWVudHNcclxuICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogQWFkaGFhciAmIFBBTiBOdW1iZXIgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQWFkaGFhciBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfYWRoYWFyX25vXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY29fYXBwbGljYW50X2FkaGFhcl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWFkaGFhciBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYWRoYWFyX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9hZGhhYXJfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBBTiBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfcGFuX25vXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY29fYXBwbGljYW50X3Bhbl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUEFOIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9wYW5fbm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X3Bhbl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUHJvZmlsZSBQaG90byA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTYgaXRlbXMtc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFVwbG9hZCBCb3ggKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjb19hcHBsaWNhbnRfcGhvdG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHctNTYgaC00MCBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIGJnLWdyYXktNTAgaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IG1iLTIgdGV4dC1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTcgMTZWNGExIDEgMCAwMTEtMWg4YTEgMSAwIDAxMSAxdjEybS01IDRoLjAxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGljayB0byB1cGxvYWQgPGJyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+KFBORywgSlBHKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb19hcHBsaWNhbnRfcGhvdG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9waG90b1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBQcmV2aWV3ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuY29fYXBwbGljYW50X3Bob3RvX3ByZXZpZXcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9waG90b30gZG93bmxvYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17Zm9ybURhdGEuY29fYXBwbGljYW50X3Bob3RvX3ByZXZpZXd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIlByb2ZpbGUgUHJldmlld1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNDAgaC00MCBvYmplY3QtY292ZXIgcm91bmRlZC1sZyBib3JkZXIgc2hhZG93LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy00MCBoLTQwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlciByb3VuZGVkLWxnIHRleHQtZ3JheS00MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gUHJldmlld1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEVycm9yICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfcGhvdG8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUEFOIENhcmQgUGhvdG8gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNiBpdGVtcy1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNvX2FwcGxpY2FudF9wYW5fZG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgdy01NiBoLTQwIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXIgYmctZ3JheS01MCBob3ZlcjpiZy1ncmF5LTEwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2xpY2sgdG8gdXBsb2FkIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+KFBORywgSlBHKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb19hcHBsaWNhbnRfcGFuX2RvY3VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X3Bhbl9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVGaWxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9wYW5fZG9jdW1lbnRfcHJldmlldyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfcGFuX2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkb3dubG9hZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfcGFuX2RvY3VtZW50X3ByZXZpZXd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00MCBoLTQwIG9iamVjdC1jb3ZlciByb3VuZGVkLWxnIGJvcmRlciBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNDAgaC00MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBib3JkZXIgcm91bmRlZC1sZyB0ZXh0LWdyYXktNDAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gUHJldmlld1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9wYW5fZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X3Bhbl9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQWFkaGFhciBDYXJkIFBob3Rve1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTYgaXRlbXMtc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjb19hcHBsaWNhbnRfYWFkaGFyX2RvY3VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHctNTYgaC00MCBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIGJnLWdyYXktNTAgaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENsaWNrIHRvIHVwbG9hZCA8YnIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14c1wiPihQTkcsIEpQRyk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY29fYXBwbGljYW50X2FhZGhhcl9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9hYWRoYXJfZG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5jb19hcHBsaWNhbnRfYWFkaGFyX2RvY3VtZW50X3ByZXZpZXcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17Zm9ybURhdGEuY29fYXBwbGljYW50X2FhZGhhcl9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZG93bmxvYWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5jb19hcHBsaWNhbnRfYWFkaGFyX2RvY3VtZW50X3ByZXZpZXdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00MCBoLTQwIG9iamVjdC1jb3ZlciByb3VuZGVkLWxnIGJvcmRlciBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNDAgaC00MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBib3JkZXIgcm91bmRlZC1sZyB0ZXh0LWdyYXktNDAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gUHJldmlld1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9hYWRoYXJfZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2FhZGhhcl9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qICBFeHRyYSBEeW5hbWljIERvY3VtZW50cyBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFkZGl0aW9uYWwgRG9jdW1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2V4dHJhRG9jcy5tYXAoKGRvYywgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWItNiBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIGJnLWdyYXktNTBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFJvdyBmb3IgaW5wdXRzICsgcmVtb3ZlIGJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJEb2N1bWVudCBOYW1lIChlLmcuIFBhc3Nwb3J0LCBWb3RlciBJRClcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZG9jLmRvY3VtZW50X25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVFeHRyYURvY05hbWVDaGFuZ2UoaW5kZXgsIGUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzIgaC0xMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2FsbF9kb2N1bWVudFwiIC8vIOKaoO+4jyBtdXN0IG1hdGNoIG11bHRlciBjb25maWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUV4dHJhRG9jRmlsZUNoYW5nZShpbmRleCwgZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzIgaC0xMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHJlbW92ZURvY0ZpZWxkKGluZGV4KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIGZvbnQtYm9sZCB0ZXh0LXhsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElvTWRDbG9zZSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBQcmV2aWV3IHNob3duIGJlbG93ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtkb2MucHJldmlldyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17ZG9jLnByZXZpZXd9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtkb2MuZG9jdW1lbnRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIHJvdW5kZWQtbWQgc2hhZG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17YWRkTmV3RG9jRmllbGR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgcHgtMiBweS0xIGJnLXZpb2xldC02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBob3ZlcjpiZy12aW9sZXQtNzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKyBBZGQgRG9jdW1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIHAtNiBiZy13aGl0ZSBzaGFkb3ctbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIHRleHQtY2VudGVyIG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE9jY3VwYXRpb24gRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogTGVmdCBDb2x1bW46IE9jY3VwYXRpb24gJiBEeW5hbWljIEZpZWxkcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIENvIEFwcGxpY2FudCBPY2N1cGF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogTWFpbiBPY2N1cGF0aW9uIFNlbGVjdCAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT2NjdXBhdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfb2NjdXBhdGlvbiB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gUmVzZXQgcmVsYXRlZCBmaWVsZHMgd2hlbiBvY2N1cGF0aW9uIGNoYW5nZXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb19hcHBsaWNhbnRfb2NjdXBhdGlvbjogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvX2FwcGxpY2FudF9vY2N1cGF0aW9uX3N1YjogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29fYXBwbGljYW50X2J1c3NpbmVzc190eXBlOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb19hcHBsaWNhbnRfYnVzc2luZXNzX25hbWU6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzczogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29fYXBwbGljYW50X3Byb2Zlc3Npb25fdHlwZTogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29fYXBwbGljYW50X2FncmlfcnRjX25vOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb19hcHBsaWNhbnRfbGFuZF9ob2xkaW5nczogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiU2VsZiBFbXBsb3llZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJTYWxhcmllZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJQcm9mZXNzaW9uYWxcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiQWdyaSBBbGxpZWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiT3RoZXJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBdLm1hcCgob2NjKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e29jY30gdmFsdWU9e29jY30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtvY2N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9vY2N1cGF0aW9uICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9vY2N1cGF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFN1Yi1vcHRpb24gZm9yIFwiT3RoZXJcIiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9vY2N1cGF0aW9uID09PSBcIk90aGVyXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBsZWFzZSBzcGVjaWZ5IE9jY3VwYXRpb246XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFN1Yi1DYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmNvX2FwcGxpY2FudF9vY2N1cGF0aW9uX3N1YiB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29fYXBwbGljYW50X29jY3VwYXRpb25fc3ViOiB2YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkhvdXNlIFdpZmVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiUmV0aXJlZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJTdHVkZW50XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkludmVzdG1lbnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiUnVubmluZyBhbiB1bnJlZ2lzdGVyZWQgQnVzaW5lc3NcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLm1hcCgoc3ViKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3N1Yn0gdmFsdWU9e3N1Yn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzdWJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9vY2N1cGF0aW9uX3N1YiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfb2NjdXBhdGlvbl9zdWJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZGRyZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciAgQWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogU2VsZiBFbXBsb3llZCAmIFNhbGFyaWVkOiBCdXNpbmVzcyBUeXBlLCBOYW1lLCBBZGRyZXNzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7W1wiU2VsZiBFbXBsb3llZFwiLCBcIlNhbGFyaWVkXCJdLmluY2x1ZGVzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmNvX2FwcGxpY2FudF9vY2N1cGF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJ1c2luZXNzIFR5cGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfYnVzc2luZXNzX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfYnVzc2luZXNzX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIFJldGFpbCwgTWFudWZhY3R1cmluZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCdXNpbmVzcyBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2J1c3NpbmVzc19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY29fYXBwbGljYW50X2J1c3NpbmVzc19uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBCdXNpbmVzcyBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0zIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2J1c3NpbmVzc19uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkZHJlc3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIFByb2Zlc3Npb25hbDogUHJvZmVzc2lvbiBUeXBlICsgQnVzaW5lc3MgQWRkcmVzcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9vY2N1cGF0aW9uID09PVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFwiUHJvZmVzc2lvbmFsXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByb2Zlc3Npb24gVHlwZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9wcm9mZXNzaW9uX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfcHJvZmVzc2lvbl90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuLCBEb2N0b3IsIENBLCBFbmdpbmVlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9wcm9mZXNzaW9uX3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X3Byb2Zlc3Npb25fdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkZHJlc3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNsaW5pYy9PZmZpY2UgQWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogQWdyaSBBbGxpZWQ6IFJUQyBObywgTGFuZCBIb2xkaW5ncywgQnVzaW5lc3MgQWRkcmVzcyAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9vY2N1cGF0aW9uID09PSBcIkFncmkgQWxsaWVkXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCB3LWZ1bGwgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSVEMgTm8gLyBMYW5kIFJlY29yZCBJRFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9hZ3JpX3J0Y19ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9hZ3JpX3J0Y19ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUlRDIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9hZ3JpX3J0Y19ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYWdyaV9ydGNfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMYW5kIEhvbGRpbmdzIChpbiBhY3JlcylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9sYW5kX2hvbGRpbmdzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY29fYXBwbGljYW50X2xhbmRfaG9sZGluZ3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIDUuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9sYW5kX2hvbGRpbmdzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9sYW5kX2hvbGRpbmdzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRmFybSBvciBPcGVyYXRpb24gQWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogRm9yIFwiT3RoZXJcIiDihpIgT25seSBzaG93IEJ1c2luZXNzIEFkZHJlc3MgaWYgXCJSdW5uaW5nIGFuIHVucmVnaXN0ZXJlZCBCdXNpbmVzc1wiICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuY29fYXBwbGljYW50X29jY3VwYXRpb24gPT09IFwiT3RoZXJcIiAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLmNvX2FwcGxpY2FudF9vY2N1cGF0aW9uX3N1YiA9PT1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiUnVubmluZyBhbiB1bnJlZ2lzdGVyZWQgQnVzaW5lc3NcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIiB3LWZ1bGwgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZGRyZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0zIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBEb2N1bWVudCBVcGxvYWQgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTYWxhcnkgLyBJbmNvbWUgRG9jdW1lbnR7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNiBpdGVtcy1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY29fYXBwbGljYW50X2luY29tZV9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgdy01NiBoLTQwIGJvcmRlci0yIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXIgYmctZ3JheS01MCBob3ZlcjpiZy1ncmF5LTEwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2xpY2sgdG8gdXBsb2FkIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14c1wiPihQTkcsIEpQRyk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY29fYXBwbGljYW50X2luY29tZV9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2luY29tZV9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5jb19hcHBsaWNhbnRfaW5jb21lX2RvY3VtZW50X3ByZXZpZXcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfaW5jb21lX2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZG93bmxvYWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuY29fYXBwbGljYW50X2luY29tZV9kb2N1bWVudF9wcmV2aWV3XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy00MCBoLTQwIG9iamVjdC1jb3ZlciByb3VuZGVkLWxnIGJvcmRlciBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTQwIGgtNDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyIHJvdW5kZWQtbGcgdGV4dC1ncmF5LTQwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBObyBQcmV2aWV3XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9pbmNvbWVfZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfaW5jb21lX2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIHsvKiBCYW5rIERldGFpbHMgQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC02IGJnLXdoaXRlIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQmFuayBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2JhbmtfbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9iYW5rX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEJhbmsgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYmFua19uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9iYW5rX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgQWNjb3VudCBOdW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfYmFua19hY2NvdW50X251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9iYW5rX2FjY291bnRfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBY2NvdW50IE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYmFua19hY2NvdW50X251bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYmFua19hY2NvdW50X251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBCYW5rIEJyYW5jaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9iYW5rX2JyYW5jaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9iYW5rX2JyYW5jaH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9iYW5rX2JyYW5jaCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYmFua19icmFuY2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgSUZTQyBDb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2JhbmtfaWZzY19jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY29fYXBwbGljYW50X2JhbmtfaWZzY19jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBJRlNDIENvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2JhbmtfaWZzY19jb2RlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9iYW5rX2lmc2NfY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBQYXNzYm9vayA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTYgaXRlbXMtc3RhcnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciB3LTU2IGgtNDAgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlciBiZy1ncmF5LTUwIGhvdmVyOmJnLWdyYXktMTAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGljayB0byB1cGxvYWQgPGJyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+KFBORywgSlBHKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb19hcHBsaWNhbnRfYmFua19wYXNzYm9va19waG90b1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2JhbmtfcGFzc2Jvb2tfcGhvdG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Zm9ybURhdGEuY29fYXBwbGljYW50X2JhbmtfcGFzc2Jvb2tfcGhvdG9fcHJldmlldyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZG93bmxvYWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEuY29fYXBwbGljYW50X2JhbmtfcGFzc2Jvb2tfcGhvdG9fcHJldmlld1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNDAgaC00MCBvYmplY3QtY292ZXIgcm91bmRlZC1sZyBib3JkZXIgc2hhZG93LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy00MCBoLTQwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlciByb3VuZGVkLWxnIHRleHQtZ3JheS00MDAgdGV4dC1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgTm8gUHJldmlld1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYmFua19wYXNzYm9va19waG90byAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAge2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlID09PSBcIlByb3BlcnR5XCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUHJvcGVydHkgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9kb2N1bWVudF9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfZG9jdW1lbnRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyICR7ZmllbGRTaXplLmhlaWdodH0gYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9kb2N1bWVudF9uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfZG9jdW1lbnRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFByb3BlcnR5IERvY3VtZW50IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC02IGl0ZW1zLXN0YXJ0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNvX2FwcGxpY2FudF9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHctNTYgaC00MCBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIGJnLWdyYXktNTAgaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIENsaWNrIHRvIHVwbG9hZCA8YnIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+KFBORywgSlBHKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb19hcHBsaWNhbnRfZG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2RvY3VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5jb19hcHBsaWNhbnRfZG9jdW1lbnRfcHJldmlldyA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89e2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9kb2N1bWVudH0gZG93bmxvYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtmb3JtRGF0YS5jb19hcHBsaWNhbnRfZG9jdW1lbnRfcHJldmlld31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNDAgaC00MCBvYmplY3QtY292ZXIgcm91bmRlZC1sZyBib3JkZXIgc2hhZG93LXNtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNDAgaC00MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBib3JkZXIgcm91bmRlZC1sZyB0ZXh0LWdyYXktNDAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBObyBQcmV2aWV3XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRGVzY3JpcHRpb24gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfZGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNvX2FwcGxpY2FudF9kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyICR7ZmllbGRTaXplLmhlaWdodH0gYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9kZXNjcmlwdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDAgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXHJcbiAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2F2ZSBDbyBBcHBsaWNhbnRcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxVcGRhdGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBVcGRhdGUgQ28gQXBwbGljYW50XHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVVcGRhdGV9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBDdXN0b21lciBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEudXNlcl9pZCB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgdXNlcl9pZDogdmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICBlbnJvbGxtZW50X2lkczogW10sIC8vIHJlc2V0IHNlbGVjdGVkIGVucm9sbG1lbnRzXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWx0ZXJlZCA9IGVucm9sbG1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoKGUpID0+IGUudXNlcl9pZD8uX2lkID09PSB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgIC5tYXAoKGUpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF9pZDogZS5faWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwX25hbWU6IGUuZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpY2tldDogZS50aWNrZXRzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBzZXRGaWx0ZXJlZEVucm9sbG1lbnRzKGZpbHRlcmVkKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmxhYmVsPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2Vucm9sbG1lbnRcclxuICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKChlKSA9PiBlLnVzZXJfaWQgJiYgZS51c2VyX2lkLmZ1bGxfbmFtZT8udHJpbSgpKSAvLyByZW1vdmVzIGVtcHR5IG9yIGludmFsaWQgbmFtZXNcclxuICAgICAgICAgICAgICAgICAgICAubWFwKChlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2UudXNlcl9pZC5faWR9IHZhbHVlPXtlLnVzZXJfaWQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2UudXNlcl9pZC5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnVzZXJfaWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBTZWxlY3QgRW5yb2xsbWVudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgbW9kZT1cInRhZ3NcIlxyXG4gICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IGVucm9sbG1lbnRzXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5lbnJvbGxtZW50X2lkc31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhzZWxlY3RlZEVucm9sbG1lbnRJZHMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICBlbnJvbGxtZW50X2lkczogc2VsZWN0ZWRFbnJvbGxtZW50SWRzLFxyXG4gICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmxhYmVsPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2ZpbHRlcmVkRW5yb2xsbWVudHMubWFwKChlbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHBhcnRzID0gW107XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVuLmdyb3VwX25hbWUgJiYgZW4uZ3JvdXBfbmFtZSAhPT0gXCJOL0FcIilcclxuICAgICAgICAgICAgICAgICAgICAgIHBhcnRzLnB1c2goZW4uZ3JvdXBfbmFtZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVuLnRpY2tldCAmJiBlbi50aWNrZXQgIT09IFwiTi9BXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgICBwYXJ0cy5wdXNoKGBUaWNrZXQ6ICR7ZW4udGlja2V0fWApO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2VuLl9pZH0gdmFsdWU9e2VuLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtwYXJ0cy5qb2luKFwiIHwgXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmVucm9sbG1lbnRfaWRzICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW5yb2xsbWVudF9pZHN9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwicmVmZXJyZWRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfcmVmZXJyZWRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGE/LmNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlIHx8IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwiY29fYXBwbGljYW50X3JlZmVycmVkX3R5cGVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge1tcIkN1c3RvbWVyXCIsIFwiVGhpcmQgUGFydHlcIiwgXCJQcm9wZXJ0eVwiXS5tYXAoKHJlZlR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3JlZlR5cGV9IHZhbHVlPXtyZWZUeXBlfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtyZWZUeXBlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X3JlZmVycmVkX3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfcmVmZXJyZWRfdHlwZX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlID09PSBcIkN1c3RvbWVyXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQ28gQXBwbGljYW50IEN1c3RvbWVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggUmVmZXJyZWQgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ1c2VyX2NvX2FwcGxpY2FudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnVzZXJfY29fYXBwbGljYW50IHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcInVzZXJfY29fYXBwbGljYW50XCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5mdWxsX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9jb19hcHBsaWNhbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnVzZXJfY29fYXBwbGljYW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBEZXNjcmlwdGlvbiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9kZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIERlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciAke2ZpZWxkU2l6ZS5oZWlnaHR9IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfZGVzY3JpcHRpb24gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9yZWZlcnJlZF90eXBlID09PSBcIlRoaXJkIFBhcnR5XCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgbXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICB7LyogUGVyc29uYWwgSW5mb3JtYXRpb24gQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC02IGJnLXdoaXRlIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUGVyc29uYWwgSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIENvIEFwcGxpY2FudCBOYW1le1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBDbyBBcHBsaWNhbnQgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9waG9uZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfcGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfcGhvbmVfbnVtYmVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBDdXN0b21lciBSZWxhdGlvbnNoaXAgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IEN1c3RvbWVyIFJlbGF0aW9uc2hpcFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBDdXN0b21lciBSZWxhdGlvbnNoaXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X3JlbGF0aW9uc2hpcF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfcmVsYXRpb25zaGlwX3R5cGUgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImNvX2FwcGxpY2FudF9yZWxhdGlvbnNoaXBfdHlwZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJGYXRoZXJcIiwgXCJTcG91c2VcIiwgXCJPdGhlclwiXS5tYXAoKHJlbCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtyZWx9IHZhbHVlPXtyZWx9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfcmVsYXRpb25zaGlwX3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X3JlbGF0aW9uc2hpcF90eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfcmVsYXRpb25zaGlwX3R5cGUgPT09XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiT3RoZXJcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQbGVhc2Ugc3BlY2lmeSB0aGUgcmVsYXRpb25zaGlwOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBjdXN0b20gcmVsYXRpb25zaGlwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXN0b21SZWxhdGlvbnNoaXB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEN1c3RvbVJlbGF0aW9uc2hpcChlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBFbWFpbCAmIERPQiAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEVtYWlsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9lbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBFbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfZW1haWwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2VtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBEYXRlIG9mIEJpcnRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2RhdGVvZmJpcnRoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfZGF0ZW9mYmlydGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9kYXRlb2ZiaXJ0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0lTT1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIE1hcml0YWwgU3RhdHVzICYgR2VuZGVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTWFyaXRhbCBTdGF0dXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTWFyaXRhbCBTdGF0dXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X21hcml0YWxfc3RhdHVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfbWFyaXRhbF9zdGF0dXMgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImNvX2FwcGxpY2FudF9tYXJpdGFsX3N0YXR1c1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJNYXJyaWVkXCIsIFwiVW5tYXJyaWVkXCIsIFwiV2lkb3dcIiwgXCJEaXZvcmNlZFwiXS5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoc3RhdHVzKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17c3RhdHVzfSB2YWx1ZT17c3RhdHVzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgR2VuZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdlbmRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfZ2VuZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfZ2VuZGVyIHx8IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwiY29fYXBwbGljYW50X2dlbmRlclwiLCB2YWx1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7W1wiTWFsZVwiLCBcIkZlbWFsZVwiXS5tYXAoKGcpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z30gdmFsdWU9e2d9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIEFkZHJlc3MgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzcyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBBZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9hZGRyZXNzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBWaWxsYWdlICYgVGFsdWsgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBWaWxsYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X3ZpbGxhZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfdmlsbGFnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBWaWxsYWdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFRhbHVrXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X3RhbHVrXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X3RhbHVrfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFRhbHVrXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBTdGF0ZSAmIERpc3RyaWN0ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgU3RhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgU3RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X3N0YXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X3N0YXRlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFwiY29fYXBwbGljYW50X3N0YXRlXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJLYXJuYXRha2FcIiwgXCJNYWhhcmFzaHRyYVwiLCBcIlRhbWlsIE5hZHVcIl0ubWFwKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKHN0YXRlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17c3RhdGV9IHZhbHVlPXtzdGF0ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0YXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRGlzdHJpY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfZGlzdHJpY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfZGlzdHJpY3R9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRGlzdHJpY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFBpbmNvZGUgJiBGYXRoZXIgTmFtZSAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBpbmNvZGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfcGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfcGluY29kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfcGluY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRmF0aGVyIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfZmF0aGVyX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfZmF0aGVyX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRmF0aGVyIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIE5hdGlvbmFsaXR5ICYgQWx0ZXJuYXRlIE51bWJlciAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIE5hdGlvbmFsaXR5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE5hdGlvbmFsaXR5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9uYXRpb25hbGl0eVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X25hdGlvbmFsaXR5IHx8IHVuZGVmaW5lZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQW50SW5wdXREU2VsZWN0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImNvX2FwcGxpY2FudF9uYXRpb25hbGl0eVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJJbmRpYW5cIiwgXCJPdGhlclwiXS5tYXAoKG5hdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtuYXRpb259IHZhbHVlPXtuYXRpb259PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bmF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBbHRlcm5hdGUgUGhvbmUgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2FsdGVybmF0ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfYWx0ZXJuYXRlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBbHRlcm5hdGUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIEtZQyBEb2N1bWVudHMgQ2FyZCAqL31cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC02IGJnLXdoaXRlIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgS1lDIERvY3VtZW50c1xyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBBYWRoYWFyICYgUEFOIE51bWJlciAqL31cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBYWRoYWFyIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9hZGhhYXJfbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFhZGhhYXIgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2FkaGFhcl9ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYWRoYWFyX25vfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQQU4gTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X3Bhbl9ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9wYW5fbm99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUEFOIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9wYW5fbm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X3Bhbl9ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIFByb2ZpbGUgUGhvdG8gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGZsZXggc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUHJvZmlsZSBQaG90byA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjb19hcHBsaWNhbnRfcGhvdG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHctNTYgaC00MCBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIGJnLWdyYXktNTAgaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IG1iLTIgdGV4dC1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTcgMTZWNGExIDEgMCAwMTEtMWg4YTEgMSAwIDAxMSAxdjEybS01IDRoLjAxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGljayB0byB1cGxvYWQgPGJyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+KFBORywgSlBHKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb19hcHBsaWNhbnRfcGhvdG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9waG90b1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRGaWxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfcGhvdG8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfcGhvdG8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X3Bob3RvfSBkb3dubG9hZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9waG90b31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIlByb2ZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01NiBoLTU2IG9iamVjdC1jb3ZlciBtdC00IHJvdW5kZWQtbWQgc2hhZG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiBQQU4gJiBBYWRoYWFyIERvY3MgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTQgbXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQQU4gQ2FyZCBQaG90byA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjb19hcHBsaWNhbnRfcGFuX2RvY3VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciB3LTU2IGgtNDAgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlciBiZy1ncmF5LTUwIGhvdmVyOmJnLWdyYXktMTAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOCBtYi0yIHRleHQtZ3JheS00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZD1cIk03IDE2VjRhMSAxIDAgMDExLTFoOGExIDEgMCAwMTEgMXYxMm0tNSA0aC4wMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2xpY2sgdG8gdXBsb2FkIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14c1wiPihQTkcsIEpQRyk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY29fYXBwbGljYW50X3Bhbl9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X3Bhbl9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRGaWxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9wYW5fZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X3Bhbl9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfcGFuX2RvY3VtZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9wYW5fZG9jdW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkb3dubG9hZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfcGFuX2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9XCJQQU5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQWFkaGFhciBDYXJkIFBob3Rve1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNvX2FwcGxpY2FudF9hYWRoYXJfZG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHctNTYgaC00MCBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIGJnLWdyYXktNTAgaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IG1iLTIgdGV4dC1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTcgMTZWNGExIDEgMCAwMTEtMWg4YTEgMSAwIDAxMSAxdjEybS01IDRoLjAxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGljayB0byB1cGxvYWQgPGJyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+KFBORywgSlBHKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb19hcHBsaWNhbnRfYWFkaGFyX2RvY3VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfYWFkaGFyX2RvY3VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dEZpbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2FhZGhhcl9kb2N1bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYWFkaGFyX2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9hYWRoYXJfZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0bz17dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X2FhZGhhcl9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRvd25sb2FkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9hYWRoYXJfZG9jdW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNTYgaC01NiBvYmplY3QtY292ZXIgbXQtNCByb3VuZGVkLW1kIHNoYWRvd1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogIEV4dHJhIER5bmFtaWMgRG9jdW1lbnRzIFNlY3Rpb24gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQWRkaXRpb25hbCBEb2N1bWVudHNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXh0cmFEb2NzLm1hcCgoZG9jLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYi02IHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgYmctZ3JheS01MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogUm93IGZvciBpbnB1dHMgKyByZW1vdmUgYnV0dG9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkRvY3VtZW50IE5hbWUgKGUuZy4gUGFzc3BvcnQsIFZvdGVyIElEKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkb2MuZG9jdW1lbnRfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUV4dHJhRG9jTmFtZUNoYW5nZShpbmRleCwgZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvMiBoLTEyIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBwLTJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfYWxsX2RvY3VtZW50XCIgLy8g4pqg77iPIG11c3QgbWF0Y2ggbXVsdGVyIGNvbmZpZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRXh0cmFEb2NGaWxlQ2hhbmdlKGluZGV4LCBlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvMiBoLTEyIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlRG9jRmllbGQoaW5kZXgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgZm9udC1ib2xkIHRleHQteGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW9NZENsb3NlIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFByZXZpZXcgc2hvd24gYmVsb3cgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2RvYy5wcmV2aWV3ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtkb2MucHJldmlld31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e2RvYy5kb2N1bWVudF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNTYgaC01NiBvYmplY3QtY292ZXIgcm91bmRlZC1tZCBzaGFkb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXthZGROZXdEb2NGaWVsZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMiBweC0yIHB5LTEgYmctdmlvbGV0LTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93IGhvdmVyOmJnLXZpb2xldC03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICArIEFkZCBEb2N1bWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcC02IGJnLXdoaXRlIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgdGV4dC1jZW50ZXIgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgT2NjdXBhdGlvbiBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBMZWZ0IENvbHVtbjogT2NjdXBhdGlvbiAmIER5bmFtaWMgRmllbGRzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQ28gQXBwbGljYW50IE9jY3VwYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBNYWluIE9jY3VwYXRpb24gU2VsZWN0ICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPY2N1cGF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X29jY3VwYXRpb24gfHwgdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFJlc2V0IHJlbGF0ZWQgZmllbGRzIHdoZW4gb2NjdXBhdGlvbiBjaGFuZ2VzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29fYXBwbGljYW50X29jY3VwYXRpb246IHZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb19hcHBsaWNhbnRfb2NjdXBhdGlvbl9zdWI6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvX2FwcGxpY2FudF9idXNzaW5lc3NfdHlwZTogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29fYXBwbGljYW50X2J1c3NpbmVzc19uYW1lOiBcIlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3M6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvX2FwcGxpY2FudF9wcm9mZXNzaW9uX3R5cGU6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvX2FwcGxpY2FudF9hZ3JpX3J0Y19ubzogXCJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29fYXBwbGljYW50X2xhbmRfaG9sZGluZ3M6IFwiXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlNlbGYgRW1wbG95ZWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiU2FsYXJpZWRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiUHJvZmVzc2lvbmFsXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIkFncmkgQWxsaWVkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIk90aGVyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXS5tYXAoKG9jYykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtvY2N9IHZhbHVlPXtvY2N9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b2NjfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfb2NjdXBhdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfb2NjdXBhdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogU3ViLW9wdGlvbiBmb3IgXCJPdGhlclwiICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X29jY3VwYXRpb24gPT09IFwiT3RoZXJcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGxlYXNlIHNwZWNpZnkgT2NjdXBhdGlvbjpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgU3ViLUNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X29jY3VwYXRpb25fc3ViIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb19hcHBsaWNhbnRfb2NjdXBhdGlvbl9zdWI6IHZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiSG91c2UgV2lmZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJSZXRpcmVkXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlN0dWRlbnRcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiSW52ZXN0bWVudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJSdW5uaW5nIGFuIHVucmVnaXN0ZXJlZCBCdXNpbmVzc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0ubWFwKChzdWIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17c3VifSB2YWx1ZT17c3VifT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3N1Yn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X29jY3VwYXRpb25fc3ViICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9vY2N1cGF0aW9uX3N1Yn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkZHJlc3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0zIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBTZWxmIEVtcGxveWVkICYgU2FsYXJpZWQ6IEJ1c2luZXNzIFR5cGUsIE5hbWUsIEFkZHJlc3MgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtbXCJTZWxmIEVtcGxveWVkXCIsIFwiU2FsYXJpZWRcIl0uaW5jbHVkZXMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X29jY3VwYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQnVzaW5lc3MgVHlwZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9idXNzaW5lc3NfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X2J1c3NpbmVzc190eXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIFJldGFpbCwgTWFudWZhY3R1cmluZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfdHlwZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCdXNpbmVzcyBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2J1c3NpbmVzc19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfYnVzc2luZXNzX25hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQnVzaW5lc3MgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZGRyZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogUHJvZmVzc2lvbmFsOiBQcm9mZXNzaW9uIFR5cGUgKyBCdXNpbmVzcyBBZGRyZXNzICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X29jY3VwYXRpb24gPT09XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgXCJQcm9mZXNzaW9uYWxcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IHNwYWNlLXktNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJvZmVzc2lvbiBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X3Byb2Zlc3Npb25fdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X3Byb2Zlc3Npb25fdHlwZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuLCBEb2N0b3IsIENBLCBFbmdpbmVlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9wcm9mZXNzaW9uX3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X3Byb2Zlc3Npb25fdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkZHJlc3NcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJDbGluaWMvT2ZmaWNlIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEFncmkgQWxsaWVkOiBSVEMgTm8sIExhbmQgSG9sZGluZ3MsIEJ1c2luZXNzIEFkZHJlc3MgKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfb2NjdXBhdGlvbiA9PT1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBcIkFncmkgQWxsaWVkXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCB3LWZ1bGwgc3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSVEMgTm8gLyBMYW5kIFJlY29yZCBJRFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9hZ3JpX3J0Y19ub1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9hZ3JpX3J0Y19ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBSVEMgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0zIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2FncmlfcnRjX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9hZ3JpX3J0Y19ub31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIExhbmQgSG9sZGluZ3MgKGluIGFjcmVzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2xhbmRfaG9sZGluZ3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9sYW5kX2hvbGRpbmdzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4sIDUuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9sYW5kX2hvbGRpbmdzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9sYW5kX2hvbGRpbmdzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkZhcm0gb3IgT3BlcmF0aW9uIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgey8qIEZvciBcIk90aGVyXCIg4oaSIE9ubHkgc2hvdyBCdXNpbmVzcyBBZGRyZXNzIGlmIFwiUnVubmluZyBhbiB1bnJlZ2lzdGVyZWQgQnVzaW5lc3NcIiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9vY2N1cGF0aW9uID09PSBcIk90aGVyXCIgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfb2NjdXBhdGlvbl9zdWIgPT09XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIlJ1bm5pbmcgYW4gdW5yZWdpc3RlcmVkIEJ1c2luZXNzXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCIgdy1mdWxsIG10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWRkcmVzc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9idXNzaW5lc3NfYWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTMgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYnVzc2luZXNzX2FkZHJlc3MgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2J1c3NpbmVzc19hZGRyZXNzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgey8qIERvY3VtZW50IFVwbG9hZCBTZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBmbGV4IHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNhbGFyeS9JbmNvbWUgRG9jdW1lbnQgUGhvdG97XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNvX2FwcGxpY2FudF9pbmNvbWVfZG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHctNTYgaC00MCBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIGJnLWdyYXktNTAgaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IG1iLTIgdGV4dC1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTcgMTZWNGExIDEgMCAwMTEtMWg4YTEgMSAwIDAxMSAxdjEybS01IDRoLjAxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGljayB0byB1cGxvYWQgPGJyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+KFBORywgSlBHKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb19hcHBsaWNhbnRfaW5jb21lX2RvY3VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfaW5jb21lX2RvY3VtZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dEZpbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9pbmNvbWVfZG9jdW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfaW5jb21lX2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X2luY29tZV9kb2N1bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9pbmNvbWVfZG9jdW1lbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZG93bmxvYWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X2luY29tZV9kb2N1bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIkluY29tZSBEb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3ctbWQgYm9yZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIEJhbmsgRGV0YWlscyBDYXJkICovfVxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBwLTYgYmctd2hpdGUgc2hhZG93LW1kXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCB0ZXh0LWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBCYW5rIERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICA8L2gyPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBCYW5rIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJjb19hcHBsaWNhbnRfYmFua19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X2JhbmtfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBCYW5rIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2JhbmtfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYmFua19uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBCYW5rIEFjY291bnQgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2JhbmtfYWNjb3VudF9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9iYW5rX2FjY291bnRfbnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEFjY291bnQgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgaC0xNCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9iYW5rX2FjY291bnRfbnVtYmVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9iYW5rX2FjY291bnRfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNCBtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEJhbmsgQnJhbmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2JhbmtfYnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X2JhbmtfYnJhbmNofVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEJyYW5jaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGgtMTQgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfYmFua19icmFuY2ggJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2JhbmtfYnJhbmNofVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBCYW5rIElGU0MgQ29kZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9iYW5rX2lmc2NfY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9iYW5rX2lmc2NfY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBJRlNDIENvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBoLTE0IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2JhbmtfaWZzY19jb2RlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9iYW5rX2lmc2NfY29kZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IGZsZXggc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQmFuayBQYXNzYm9vayA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciB3LTU2IGgtNDAgYm9yZGVyLTIgYm9yZGVyLWRhc2hlZCBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlciBiZy1ncmF5LTUwIGhvdmVyOmJnLWdyYXktMTAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOCBtYi0yIHRleHQtZ3JheS00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZD1cIk03IDE2VjRhMSAxIDAgMDExLTFoOGExIDEgMCAwMTEgMXYxMm0tNSA0aC4wMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2xpY2sgdG8gdXBsb2FkIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14c1wiPihQTkcsIEpQRyk8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY29fYXBwbGljYW50X2JhbmtfcGFzc2Jvb2tfcGhvdG9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dEZpbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2JhbmtfcGFzc2Jvb2tfcGhvdG99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfYmFua19wYXNzYm9va19waG90byAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89e3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9iYW5rX3Bhc3Nib29rX3Bob3RvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRvd25sb2FkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtRGF0YS5jb19hcHBsaWNhbnRfYmFua19wYXNzYm9va19waG90b1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwiUGFzc2Jvb2tcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01NiBoLTU2IG9iamVjdC1jb3ZlciBtdC00IHJvdW5kZWQtbWQgc2hhZG93XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X3JlZmVycmVkX3R5cGUgPT09IFwiUHJvcGVydHlcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBQcm9wZXJ0eSBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29fYXBwbGljYW50X2RvY3VtZW50X25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9kb2N1bWVudF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIERlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciAke2ZpZWxkU2l6ZS5oZWlnaHR9IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxgfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfZG9jdW1lbnRfbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2RvY3VtZW50X25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBmbGV4IHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgUHJvcGVydHkgRG9jdW1lbnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjb19hcHBsaWNhbnRfZG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHctNTYgaC00MCBib3JkZXItMiBib3JkZXItZGFzaGVkIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyIGJnLWdyYXktNTAgaG92ZXI6YmctZ3JheS0xMDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IG1iLTIgdGV4dC1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTcgMTZWNGExIDEgMCAwMTEtMWg4YTEgMSAwIDAxMSAxdjEybS01IDRoLjAxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIHRleHQtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGljayB0byB1cGxvYWQgPGJyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+KFBORywgSlBHKTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjb19hcHBsaWNhbnRfZG9jdW1lbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9kb2N1bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRGaWxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWNjZXB0PVwiaW1hZ2UvKlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaGlkZGVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2RvY3VtZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj4gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLmNvX2FwcGxpY2FudF9kb2N1bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8TGluayB0bz17dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X2RvY3VtZW50fSBkb3dubG9hZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGltZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X2RvY3VtZW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGFsdD1cIlByb3BlcnR5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTU2IGgtNTYgb2JqZWN0LWNvdmVyIG10LTQgcm91bmRlZC1tZCBzaGFkb3dcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBEZXNjcmlwdGlvbiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNvX2FwcGxpY2FudF9kZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuY29fYXBwbGljYW50X2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBEZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgJHtmaWVsZFNpemUuaGVpZ2h0fSBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsYH1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY29fYXBwbGljYW50X2Rlc2NyaXB0aW9uICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jb19hcHBsaWNhbnRfZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLXZpb2xldC03MDAgaG92ZXI6YmctdmlvbGV0LTgwMCBib3JkZXItMiBib3JkZXItYmxhY2tcclxuICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBVcGRhdGVcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxEZWxldGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRDb0FwcGxpY2FudChudWxsKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIERlbGV0ZSBDbyBBcHBsaWNhbnRcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAge2N1cnJlbnRDb0FwcGxpY2FudCAmJiAoXHJcbiAgICAgICAgICAgICAgPGZvcm1cclxuICAgICAgICAgICAgICAgIG9uU3VibWl0PXsoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZUNvQXBwbGljYW50KCk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3BhY2UteS02XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQbGVhc2UgZW50ZXJ7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1wcmltYXJ5IGZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRDb0FwcGxpY2FudD8uY29fYXBwbGljYW50X25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICB0byBjb25maXJtIGRlbGV0aW9uLntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZ3JvdXBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBDbyBBcHBsaWNhbnQgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXdoaXRlIGJnLXJlZC03MDAgaG92ZXI6YmctcmVkLTgwMFxyXG4gICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb0FwcGxpY2FudDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0NvQXBwbGljYW50LmpzeCJ9