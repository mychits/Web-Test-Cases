import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PaymentWithPenalty.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { FaWhatsappSquare } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Modal as AntModal, Drawer, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import BackdropBlurLoader from "/src/components/loaders/BackdropBlurLoader.jsx";
import { FaReceipt } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import { WarningOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const PenaltyPayment = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [actualGroups, setActualGroups] = useState([]);
  const [TablePayments, setTablePayments] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [viewLoader, setViewLoader] = useState(false);
  const [filteredEnrollments, setFilteredEnrollments] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [enrollmentLoading, setEnrollmentLoading] = useState(false);
  const [showModalView, setShowModalView] = useState(false);
  const [currentViewGroup, setCurrentViewGroup] = useState(null);
  const [whatsappEnable, setWhatsappEnable] = useState(true);
  const [paymentMode, setPaymentMode] = useState("cash");
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [isLoading, setIsLoading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [borrowers, setBorrowers] = useState([]);
  const [pigmeCustomers, setPigmeCustomers] = useState([]);
  const [paymentGroupTickets, setPaymentGroupTickets] = useState([]);
  const [openBackdropLoader, setOpenBackdropLoader] = useState(false);
  const [currentGroupId, setCurrentGroupId] = useState(null);
  const [openAntDDrawer, setOpenAntDDrawer] = useState(false);
  const [showLoader, setShowLoader] = useState(false);
  const [lastThreePayments, setLastThreePayments] = useState([]);
  const [penaltyInfoMap, setPenaltyInfoMap] = useState({});
  const dropDownItems = (paymentObject) => {
    const dropDownItemList = [
      {
        key: "1",
        label: /* @__PURE__ */ jsxDEV(Link, { to: `/print/${paymentObject?._id}`, className: "text-violet-600 ", children: "Print" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
          lineNumber: 55,
          columnNumber: 7
        }, this)
      },
      {
        key: "3",
        label: /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "text-green-600 ",
            onClick: () => handleViewModalOpen(paymentObject?._id),
            children: "View"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
            lineNumber: 64,
            columnNumber: 7
          },
          this
        )
      }
    ];
    return dropDownItemList;
  };
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    noReload: false,
    type: "info"
  });
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    user_id: "",
    receipt_no: "",
    pay_date: today,
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    payment_group_tickets: [],
    account_type: "",
    cheque_number: "",
    cheque_date: "",
    cheque_bank_name: "",
    cheque_bank_branch: "",
    collection_time: ""
  });
  const [modifyPayment, setModifyPayment] = useState(false);
  const [modifyMinMaxPaymentDate, setModifyMinMaxPaymentDate] = useState(false);
  const yesterday = new Date((/* @__PURE__ */ new Date()).setDate((/* @__PURE__ */ new Date()).getDate() - 1)).toISOString().split("T")[0];
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj) {
      const adminAccessPermissions = userObj.admin_access_right_id?.access_permissions;
      if (adminAccessPermissions?.edit_payment === "true") {
        setModifyPayment(true);
      }
      if (adminAccessPermissions?.edit_limited_payment === "true") {
        setModifyPayment(true);
        setModifyMinMaxPaymentDate(true);
      }
    }
  }, []);
  const fetchLastThreeTransactions = async (event) => {
    event.preventDefault();
    setOpenAntDDrawer(true);
    if (formData.user_id && formData.payment_group_tickets) {
      try {
        setShowLoader(true);
        const response = await api.get("payment/get-last-n-transaction", {
          params: {
            user_id: formData.user_id,
            payment_group_tickets: paymentGroupTickets,
            limit: 3
          }
        });
        if (response?.data) {
          setLastThreePayments(response.data);
        } else {
          setLastThreePayments([]);
        }
      } catch (error) {
        setLastThreePayments([]);
      } finally {
        setShowLoader(false);
      }
    }
  };
  const fetchPenaltyForSelectedTickets = async (userId, ticketSelections) => {
    if (!userId || !Array.isArray(ticketSelections) || ticketSelections.length === 0) {
      setPenaltyInfoMap({});
      return;
    }
    const chitSelections = ticketSelections.filter(
      (sel) => typeof sel === "string" && sel.startsWith("chit-")
    );
    const newPenaltyMap = {};
    try {
      const groupToTickets = {};
      for (const sel of chitSelections) {
        const [_, entity] = sel.split("-");
        const [groupId, ticket] = entity.split("|");
        if (!groupToTickets[groupId]) groupToTickets[groupId] = [];
        groupToTickets[groupId].push({ selectionKey: sel, ticket });
      }
      for (const [groupId, tickets] of Object.entries(groupToTickets)) {
        const res = await api.get("/penalty/get-penalty-report", {
          params: { user_id: userId, group_id: groupId }
        });
        const penaltyDataList = res.data?.data || [];
        for (const { selectionKey, ticket } of tickets) {
          const match = penaltyDataList.find(
            (item) => String(item.user_id) === String(userId) && String(item.group_id) === String(groupId) && String(item.ticket_number) === String(ticket)
          );
          if (match?.summary) {
            const summary = match.summary;
            const regularPenalty = Number(summary.total_penalty || 0) - Number(summary.total_vacant_chit_penalty || 0);
            const vcPenalty = Number(summary.total_vacant_chit_penalty || 0);
            const lateFee = Number(summary.total_late_payment_charges || 0);
            const totalPenalty = regularPenalty + vcPenalty;
            newPenaltyMap[selectionKey] = {
              dueAmount: Number(summary.total_due) || 0,
              regularPenalty,
              vcPenalty,
              lateFee,
              penalty: totalPenalty,
              // regular + VC
              totalCharges: totalPenalty + lateFee,
              groupName: match.group_name || "Unknown Group",
              ticket
            };
          } else {
            newPenaltyMap[selectionKey] = null;
          }
        }
      }
      setPenaltyInfoMap(newPenaltyMap);
    } catch (err) {
      console.error("Failed to fetch penalties for selected tickets:", err);
      setPenaltyInfoMap({});
    }
  };
  useEffect(() => {
    setBorrowers([]);
    const fetchCustomerLoanDetails = async () => {
      try {
        const response = await api.get(
          `/loans/get-borrower-by-user-id/${selectedUserId}`
        );
        if (response.status >= 400)
          throw new Error("fetching loan borrowers Failed");
        setBorrowers(response.data);
      } catch (err) {
        setBorrowers([]);
        console.log("Error Occurred");
      }
    };
    fetchCustomerLoanDetails();
  }, [selectedUserId]);
  useEffect(() => {
    setPigmeCustomers([]);
    const fetchCustomerLoanDetails = async () => {
      try {
        const response = await api.get(
          `/pigme/get-pigme-customer-by-user-id/${selectedUserId}`
        );
        if (response.status >= 400)
          throw new Error("fetching pigme customers Failed");
        setPigmeCustomers(response.data);
      } catch (err) {
        setPigmeCustomers([]);
        console.log(
          "Error Occurred while fetching pigme customers,",
          err.message
        );
      }
    };
    fetchCustomerLoanDetails();
  }, [selectedUserId]);
  useEffect(() => {
    const fetchAllCustomers = async () => {
      try {
        const response = await api.get("user/verified");
        setUsers(response?.data?.data);
      } catch (error) {
        setUsers([]);
        console.error("Error fetching group data:", error);
      }
    };
    fetchAllCustomers();
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setActualGroups(response.data);
      } catch (error) {
        setActualGroups([]);
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  const validateForm = () => {
    const newErrors = {};
    if (!selectedUserId) {
      newErrors.customer = "Please select a customer";
    }
    if (!formData.payment_group_tickets) {
      newErrors.payment_group_tickets = "Please select a group and ticket";
    }
    if (!formData.pay_date) {
      newErrors.pay_date = "Payment date is required";
    }
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      newErrors.amount = "Please enter a valid positive amount";
    }
    if (paymentMode === "online" && !formData.transaction_id?.trim()) {
      newErrors.transaction_id = "Transaction ID is required for online payments";
    }
    if (paymentMode === "cheque" && !formData.cheque_date?.trim()) {
      newErrors.cheque_date = "Cheque Date is required for cheque payments";
    }
    if (paymentMode === "cheque" && !formData.cheque_number?.trim()) {
      newErrors.cheque_number = "Cheque Number is required for cheque payments";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "amount") {
      let cleaned = value.replace(/[^0-9.]/g, "");
      const dotCount = (cleaned.match(/\./g) || []).length;
      if (dotCount > 1) return;
      setFormData((prev) => ({
        ...prev,
        [name]: cleaned
      }));
      return;
    }
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };
  const handlePaymentAntSelect = async (values) => {
    setPaymentGroupTickets(values);
    setErrors((prev) => ({ ...prev, payment_group_tickets: "" }));
    if (selectedUserId) {
      await fetchPenaltyForSelectedTickets(selectedUserId, values);
    } else {
      setPenaltyInfoMap({});
    }
  };
  const formatIndianNumber = (value) => {
    if (!value) return "";
    value = value.toString().replace(/[^0-9.]/g, "");
    const parts = value.split(".");
    const integerPart = parts[0];
    const decimalPart = parts[1] ? parts[1].slice(0, 2) : "";
    let lastThree = integerPart.slice(-3);
    let otherNumbers = integerPart.slice(0, -3);
    let formattedInt = otherNumbers ? otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + "," + lastThree : lastThree;
    return decimalPart ? `${formattedInt}.${decimalPart}` : formattedInt;
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "date", header: "Paid Date" },
    { key: "transaction_date", header: "Transaction Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "group_name", header: "Group Name" },
    { key: "ticket", header: "Ticket Number" },
    { key: "old_receipt", header: "Old Receipt" },
    { key: "receipt", header: "Receipt" },
    { key: "amount", header: "Amount" },
    { key: "pay_type", header: "Payment Type" },
    { key: "collection_time", header: "Collection Time" },
    { key: "collected_by", header: "Collected By" },
    { key: "action", header: "Action" }
  ];
  const handleCustomer = async (userId) => {
    setFilteredUsers([]);
    setFilteredEnrollments([]);
    setSelectedUserId(userId);
    setFormData((prevFormData) => ({
      ...prevFormData,
      user_id: userId
    }));
    setErrors((prevData) => ({ ...prevData, customer: "" }));
    setPaymentGroupTickets([]);
    setPenaltyInfoMap({});
    handleGroupAuctionChange(userId);
  };
  const handleGroupPayment = async (groupId) => {
    if (groupId) {
      let url = `/payment/get-payments-by-dates?from_date=${today}&to_date=${today}`;
      try {
        setIsLoading(true);
        const response = await api.get(url);
        if (response.data && response.data.length > 0) {
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id?.group_name) return {};
            return {
              _id: group._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              ticket: group.ticket,
              receipt: group.receipt_no,
              old_receipt: group.old_receipt_no,
              amount: group.amount,
              pay_type: group?.pay_type,
              date: group?.pay_date.split("T")[0],
              transaction_date: group?.createdAt?.split("T")[0],
              collected_by: group?.collected_by?.name || group?.admin_type?.admin_name || "Super Admin",
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: dropDownItems(group)
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                    lineNumber: 454,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                  lineNumber: 447,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 446,
                columnNumber: 15
              }, this)
            };
          });
          setTablePayments(formattedData);
        }
      } catch (error) {
        setTablePayments([]);
        console.error("Error fetching payment data:", error);
      } finally {
        setIsLoading(false);
      }
    }
  };
  const handlePaymentModeChange = (e) => {
    const selectedMode = e.target.value;
    setPaymentMode(selectedMode);
    setFormData((prevData) => ({
      ...prevData,
      pay_type: selectedMode,
      transaction_id: selectedMode === "online" || selectedMode === "online/upi" ? prevData.transaction_id : ""
    }));
  };
  const handleAccountTypeChange = (e) => {
    const selectedMode = e.target.value;
    setFormData((prevData) => ({
      ...prevData,
      account_type: selectedMode
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        setAlertConfig((prev) => ({
          ...prev,
          visibility: false
        }));
        setShowModal(false);
        const usr = localStorage.getItem("user");
        let admin_type = null;
        try {
          if (usr) {
            admin_type = JSON.parse(usr);
          }
        } catch (e2) {
          console.error("Failed to parse user from localStorage:", e2);
        }
        formData.payment_group_tickets = paymentGroupTickets;
        formData.admin_type = admin_type?._id;
        setOpenBackdropLoader(true);
        await api.post("/payment/add-payments-auto-penalty", formData);
        setSelectedUserId("");
        setPaymentGroupTickets([]);
        setFormData({
          user_id: "",
          receipt_no: "",
          pay_date: today,
          amount: "",
          pay_type: "cash",
          transaction_id: "",
          payment_group_tickets: [],
          account_type: "",
          cheque_number: "",
          cheque_date: "",
          cheque_bank_name: "",
          cheque_bank_branch: ""
        });
        setAlertConfig({
          visibility: true,
          noReload: true,
          message: "Payment Added Successfully",
          type: "success"
        });
      }
    } catch (error) {
      setShowModal(false);
      setSelectedUserId("");
      setFormData({
        user_id: "",
        receipt_no: "",
        pay_date: "",
        amount: "",
        pay_type: "cash",
        transaction_id: "",
        payment_group_tickets: [],
        account_type: ""
      });
      setAlertConfig({
        visibility: true,
        noReload: true,
        message: `Error submitting payment data`,
        type: "error"
      });
      console.error("Error submitting payment data:", error);
    } finally {
      setOpenBackdropLoader(false);
    }
  };
  const handleViewModalOpen = async (paymentId) => {
    try {
      setLoading(true);
      setShowModalView(true);
      setCurrentGroupId(paymentId);
      setViewLoader(true);
      const response = await api.get(`/payment/get-payment-by-id/${paymentId}`);
      setCurrentViewGroup(response.data);
    } catch (error) {
      console.error("Error viewing Payment:", error);
    } finally {
      setLoading(false);
      setViewLoader(false);
    }
  };
  const handleGroupAuctionChange = async (groupId) => {
    if (groupId) {
      try {
        const response = await api.post(
          `/enroll/get-user-tickets-report/${groupId}`
        );
        if (response.data && response.data.length > 0) {
          const validEnrollments = response.data.filter(
            (auction) => auction.enrollment && auction.enrollment.group
          );
          setFilteredEnrollments(validEnrollments);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredEnrollments([]);
      }
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: openBackdropLoader ? /* @__PURE__ */ jsxDEV(BackdropBlurLoader, { title: "payment Data processing...." }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
    lineNumber: 607,
    columnNumber: 7
  }, this) : /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gray-50 overflow-x-hidden mt-20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex ", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
      lineNumber: 611,
      columnNumber: 14
    }, this),
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
        lineNumber: 612,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
        lineNumber: 616,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 flex-1 min-w-0   overflow-x-auto", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
        lineNumber: 625,
        columnNumber: 30
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Payments" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
        lineNumber: 626,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6  mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-10", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "font-bold", children: "Search or Select Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
            lineNumber: 629,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Select Group",
                popupMatchSelectWidth: false,
                showSearch: true,
                className: "w-full  h-14 max-w-md",
                filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                value: selectedGroupId || void 0,
                onChange: handleGroupPayment,
                children: actualGroups.map(
                  (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                    lineNumber: 646,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 631,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setShowModal(true),
                className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
                children: "+ Add Payment"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 652,
                columnNumber: 23
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 651,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
            lineNumber: 630,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
          lineNumber: 628,
          columnNumber: 17
        }, this),
        TablePayments && TablePayments.length > 0 ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            data: TablePayments.filter(
              (item) => Object.values(item).some(
                (value) => String(value).toLowerCase().includes(searchText.toLowerCase())
              )
            ),
            columns,
            exportedPdfName: "Payments",
            printHeaderKeys: ["Group Name"],
            printHeaderValues: ["Today's"],
            exportedFileName: `Payments.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
            lineNumber: 663,
            columnNumber: 15
          },
          this
        ) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            data: "Payments Data",
            failure: TablePayments.length <= 0
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
            lineNumber: 679,
            columnNumber: 21
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
          lineNumber: 678,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
        lineNumber: 627,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
      lineNumber: 624,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        open: showModal,
        onClose: () => {
          setSelectedUserId("");
          setShowModal(false);
          setErrors({});
          setPaymentGroupTickets([]);
        },
        width: "50%",
        className: "payment-drawer",
        extra: /* @__PURE__ */ jsxDEV(Tooltip, { title: "Last 3 Transactions", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: fetchLastThreeTransactions,
            value: "Last Three transaction",
            className: "flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-xl shadow-md transition-all duration-200 font-medium",
            children: [
              /* @__PURE__ */ jsxDEV(FaReceipt, { className: "text-lg" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 706,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("span", { children: "Last 3 Transactions" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 707,
                columnNumber: 21
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
            lineNumber: 701,
            columnNumber: 19
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
          lineNumber: 700,
          columnNumber: 13
        }, this),
        children: /* @__PURE__ */ jsxDEV("div", { className: "container mx-auto px-4 py-6 max-w-7xl", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col lg:flex-row gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "mb-6 text-2xl font-bold text-gray-900 border-b pb-3", children: "Add Payment" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 715,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              "form",
              {
                className: "space-y-6",
                onSubmit: handleSubmit,
                noValidate: true,
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "form-group", children: [
                    /* @__PURE__ */ jsxDEV(
                      "label",
                      {
                        className: "block mb-2 text-sm font-medium text-gray-900",
                        htmlFor: "category",
                        children: [
                          "Customer ",
                          /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 728,
                            columnNumber: 36
                          }, this)
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 724,
                        columnNumber: 25
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      Select,
                      {
                        className: `bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg w-full h-12`,
                        placeholder: "Select Or Search Customer",
                        popupMatchSelectWidth: false,
                        showSearch: true,
                        filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                        value: selectedUserId || void 0,
                        onChange: handleCustomer,
                        children: users.map(
                          (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: `${group.full_name} | ${group.phone_number}` }, group._id, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 745,
                            columnNumber: 25
                          }, this)
                        )
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 730,
                        columnNumber: 25
                      },
                      this
                    ),
                    errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.customer }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 751,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                    lineNumber: 723,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `form-group ${enrollmentLoading ? "cursor-progress" : ""}`,
                      children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "category",
                            children: [
                              "Group & Ticket ",
                              /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 765,
                                columnNumber: 42
                              }, this)
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 761,
                            columnNumber: 25
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          Select,
                          {
                            disabled: enrollmentLoading,
                            mode: "multiple",
                            name: "group_id",
                            placeholder: "Select Group | Ticket",
                            onChange: handlePaymentAntSelect,
                            loading: enrollmentLoading,
                            value: paymentGroupTickets,
                            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                            children: [
                              filteredEnrollments.map((entry, index) => {
                                const groupName = entry?.enrollment?.group?.group_name || "Unnamed Group";
                                const groupId = entry?.enrollment?.group?._id || `missing-${index}`;
                                const ticket = entry?.enrollment?.tickets || "Unknown";
                                return /* @__PURE__ */ jsxDEV(
                                  Select.Option,
                                  {
                                    value: `chit-${groupId}|${ticket}`,
                                    children: [
                                      groupName,
                                      " | ",
                                      ticket
                                    ]
                                  },
                                  `chit-${groupId}|${ticket}`,
                                  true,
                                  {
                                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                    lineNumber: 788,
                                    columnNumber: 29
                                  },
                                  this
                                );
                              }),
                              pigmeCustomers?.map((pigme) => {
                                return /* @__PURE__ */ jsxDEV(Select.Option, { value: `pigme-${pigme._id}`, children: `${pigme.pigme_id} | ₹ ${pigme.payable_amount}` }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                  lineNumber: 798,
                                  columnNumber: 29
                                }, this);
                              }),
                              borrowers?.map((borrower) => {
                                return /* @__PURE__ */ jsxDEV(Select.Option, { value: `loan-${borrower._id}`, children: `loan-${borrower.loan_id} | ₹ ${borrower.loan_amount}` }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                  lineNumber: 805,
                                  columnNumber: 29
                                }, this);
                              })
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 767,
                            columnNumber: 25
                          },
                          this
                        ),
                        errors.payment_group_tickets && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.payment_group_tickets }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 812,
                          columnNumber: 23
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 757,
                      columnNumber: 23
                    },
                    this
                  ),
                  paymentGroupTickets.length > 0 && /* @__PURE__ */ jsxDEV("div", { className: "mt-6 bg-white border border-gray-200 rounded-lg shadow-md", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "px-6 py-4 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-900 flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV(WarningOutlined, { className: "text-gray-600" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 822,
                        columnNumber: 31
                      }, this),
                      "Penalty Information"
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 821,
                      columnNumber: 29
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 820,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
                      paymentGroupTickets.map((selection, index) => {
                        const info = penaltyInfoMap[selection];
                        if (!info) return null;
                        const [_, entity] = selection.split("-");
                        const [groupId, ticket] = entity.split("|");
                        const displayName = `${info.groupName} | ${ticket}`;
                        return /* @__PURE__ */ jsxDEV("div", { className: index < paymentGroupTickets.length - 1 ? "mb-6 pb-6 border-b border-gray-100" : "mb-6", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-4", children: [
                            /* @__PURE__ */ jsxDEV("h4", { className: "text-base font-medium text-gray-900", children: displayName }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 839,
                              columnNumber: 37
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs font-medium", children: [
                              "Ticket #",
                              ticket
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 842,
                              columnNumber: 37
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 838,
                            columnNumber: 35
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [
                            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded p-3", children: [
                              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase tracking-wide mb-1", children: "Due Amount" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 849,
                                columnNumber: 39
                              }, this),
                              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold text-gray-900", children: [
                                "₹",
                                Number(info.dueAmount).toLocaleString("en-IN")
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 850,
                                columnNumber: 39
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 848,
                              columnNumber: 37
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded p-3", children: [
                              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase tracking-wide mb-1", children: "Penalty" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 856,
                                columnNumber: 39
                              }, this),
                              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold text-gray-900", children: [
                                "₹",
                                Number(info.penalty).toLocaleString("en-IN")
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 857,
                                columnNumber: 39
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 855,
                              columnNumber: 37
                            }, this),
                            /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded p-3", children: [
                              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase tracking-wide mb-1", children: "Late Fee" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 865,
                                columnNumber: 39
                              }, this),
                              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold text-gray-900", children: [
                                "₹",
                                Number(info.lateFee).toLocaleString("en-IN")
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 866,
                                columnNumber: 39
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 864,
                              columnNumber: 37
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 847,
                            columnNumber: 35
                          }, this)
                        ] }, selection, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 837,
                          columnNumber: 29
                        }, this);
                      }),
                      /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-4 border border-gray-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                        /* @__PURE__ */ jsxDEV("h4", { className: "text-base font-medium text-gray-900", children: "Total Penalty Summary" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 878,
                          columnNumber: 33
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-6", children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
                            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase tracking-wide", children: "Total Penalty" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 881,
                              columnNumber: 37
                            }, this),
                            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold text-gray-900", children: [
                              "₹",
                              paymentGroupTickets.reduce((sum, selection) => {
                                const info = penaltyInfoMap[selection];
                                return sum + (info ? Number(info.penalty) : 0);
                              }, 0).toLocaleString("en-IN")
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 882,
                              columnNumber: 37
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 880,
                            columnNumber: 35
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "text-right", children: [
                            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 uppercase tracking-wide", children: "Total Charges" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 890,
                              columnNumber: 37
                            }, this),
                            /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold text-gray-900", children: [
                              "₹",
                              paymentGroupTickets.reduce((sum, selection) => {
                                const info = penaltyInfoMap[selection];
                                return sum + (info ? Number(info.totalCharges) : 0);
                              }, 0).toLocaleString("en-IN")
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 891,
                              columnNumber: 37
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 889,
                            columnNumber: 35
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 879,
                          columnNumber: 33
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 877,
                        columnNumber: 31
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 876,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 827,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                    lineNumber: 819,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 p-4 rounded-lg", children: [
                    /* @__PURE__ */ jsxDEV("h4", { className: "text-lg font-semibold mb-4 text-gray-800", children: "Payment Details" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 906,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "group_install",
                            children: "Payment Date"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 912,
                            columnNumber: 29
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            disabled: !modifyPayment,
                            type: "date",
                            name: "pay_date",
                            min: modifyMinMaxPaymentDate ? yesterday : void 0,
                            max: modifyMinMaxPaymentDate ? today : void 0,
                            value: formData.pay_date,
                            id: "pay_date",
                            onChange: handleChange,
                            placeholder: "",
                            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 918,
                            columnNumber: 29
                          },
                          this
                        ),
                        errors.pay_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.pay_date }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 933,
                          columnNumber: 27
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 911,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV("div", { children: [
                          /* @__PURE__ */ jsxDEV(
                            "label",
                            {
                              className: "block mb-2 text-sm font-medium text-gray-900",
                              htmlFor: "group_value",
                              children: [
                                "Amount ",
                                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                  lineNumber: 945,
                                  columnNumber: 40
                                }, this)
                              ]
                            },
                            void 0,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 941,
                              columnNumber: 31
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              type: "text",
                              name: "amount",
                              value: formatIndianNumber(formData.amount),
                              id: "amount",
                              onChange: handleChange,
                              placeholder: "Enter Amount",
                              required: true,
                              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 947,
                              columnNumber: 31
                            },
                            this
                          ),
                          errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 958,
                            columnNumber: 29
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 940,
                          columnNumber: 29
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { className: "text-violet-900", children: numberToIndianWords(formData.amount) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 963,
                          columnNumber: 29
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 939,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "pay_mode",
                            children: "Payment Mode"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 967,
                            columnNumber: 29
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          "select",
                          {
                            name: "pay_mode",
                            id: "pay_mode",
                            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                            onChange: handlePaymentModeChange,
                            children: [
                              /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 979,
                                columnNumber: 31
                              }, this),
                              /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 980,
                                columnNumber: 31
                              }, this),
                              /* @__PURE__ */ jsxDEV("option", { value: "online/upi", children: "Online/UPI" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 981,
                                columnNumber: 31
                              }, this),
                              /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 982,
                                columnNumber: 31
                              }, this)
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 973,
                            columnNumber: 29
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 966,
                        columnNumber: 27
                      }, this),
                      modifyPayment && /* @__PURE__ */ jsxDEV("div", { children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "account_type",
                            children: "Account Type"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 988,
                            columnNumber: 31
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          "select",
                          {
                            name: "account_type",
                            id: "account_type",
                            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5",
                            onChange: handleAccountTypeChange,
                            children: [
                              /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Account Type" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 1e3,
                                columnNumber: 33
                              }, this),
                              /* @__PURE__ */ jsxDEV("option", { value: "suspense", children: "Suspense" }, void 0, false, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                lineNumber: 1001,
                                columnNumber: 33
                              }, this)
                            ]
                          },
                          void 0,
                          true,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 994,
                            columnNumber: 31
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 987,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 910,
                      columnNumber: 25
                    }, this),
                    formData.amount && paymentGroupTickets.length > 1 && /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                        /* @__PURE__ */ jsxDEV(
                          "label",
                          {
                            className: "block mb-2 text-sm font-medium text-gray-900",
                            htmlFor: "individual_amount",
                            children: "Individual Ticket Amount"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 1010,
                            columnNumber: 31
                          },
                          this
                        ),
                        /* @__PURE__ */ jsxDEV(
                          "input",
                          {
                            type: "text",
                            className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg hover:cursor-not-allowed w-full p-2.5",
                            placeholder: "Individual Amount",
                            value: formatIndianNumber(
                              Number(formData.amount) / paymentGroupTickets.length
                            ),
                            disabled: true
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 1016,
                            columnNumber: 31
                          },
                          this
                        )
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1009,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-violet-900", children: numberToIndianWords(
                        Number(formData.amount) / paymentGroupTickets.length
                      ) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1027,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 1008,
                      columnNumber: 23
                    }, this),
                    (paymentMode === "online" || paymentMode === "online/upi") && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                      /* @__PURE__ */ jsxDEV(
                        "label",
                        {
                          className: "block mb-2 text-sm font-medium text-gray-900",
                          htmlFor: "transaction_id",
                          children: [
                            "Transaction ID",
                            " ",
                            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 1044,
                              columnNumber: 33
                            }, this)
                          ]
                        },
                        void 0,
                        true,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1039,
                          columnNumber: 31
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "text",
                          name: "transaction_id",
                          id: "transaction_id",
                          value: formData.transaction_id,
                          onChange: handleChange,
                          placeholder: "Enter Transaction ID",
                          className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1046,
                          columnNumber: 31
                        },
                        this
                      ),
                      errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1056,
                        columnNumber: 25
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 1038,
                      columnNumber: 23
                    }, this),
                    paymentMode === "cheque" && /* @__PURE__ */ jsxDEV("div", { className: "mt-4 space-y-4", children: [
                      /* @__PURE__ */ jsxDEV("h5", { className: "text-md font-semibold text-gray-800", children: "Cheque Details" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1065,
                        columnNumber: 29
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
                        /* @__PURE__ */ jsxDEV("div", { children: [
                          /* @__PURE__ */ jsxDEV(
                            "label",
                            {
                              className: "block mb-2 text-sm font-medium text-gray-900",
                              htmlFor: "cheque_number",
                              children: [
                                "Cheque Number",
                                " ",
                                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                  lineNumber: 1075,
                                  columnNumber: 35
                                }, this)
                              ]
                            },
                            void 0,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 1070,
                              columnNumber: 33
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              type: "text",
                              name: "cheque_number",
                              id: "cheque_number",
                              value: formData.cheque_number,
                              onChange: handleChange,
                              placeholder: "Enter Cheque Number",
                              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 1077,
                              columnNumber: 33
                            },
                            this
                          ),
                          errors.cheque_number && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_number }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 1087,
                            columnNumber: 29
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1069,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { children: [
                          /* @__PURE__ */ jsxDEV(
                            "label",
                            {
                              className: "block mb-2 text-sm font-medium text-gray-900",
                              htmlFor: "cheque_date",
                              children: [
                                "Cheque Date",
                                " ",
                                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                                  lineNumber: 1099,
                                  columnNumber: 35
                                }, this)
                              ]
                            },
                            void 0,
                            true,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 1094,
                              columnNumber: 33
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              type: "date",
                              name: "cheque_date",
                              id: "cheque_date",
                              value: formData.cheque_date.split("T")[0],
                              onChange: handleChange,
                              placeholder: "Enter Cheque Date",
                              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 1101,
                              columnNumber: 33
                            },
                            this
                          ),
                          errors.cheque_date && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.cheque_date }, void 0, false, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                            lineNumber: 1111,
                            columnNumber: 29
                          }, this)
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1093,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { children: [
                          /* @__PURE__ */ jsxDEV(
                            "label",
                            {
                              className: "block mb-2 text-sm font-medium text-gray-900",
                              htmlFor: "cheque_bank_name",
                              children: "Bank Name"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 1118,
                              columnNumber: 33
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              type: "text",
                              name: "cheque_bank_name",
                              id: "cheque_bank_name",
                              value: formData.cheque_bank_name,
                              onChange: handleChange,
                              placeholder: "Enter Bank Name",
                              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 1124,
                              columnNumber: 33
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1117,
                          columnNumber: 31
                        }, this),
                        /* @__PURE__ */ jsxDEV("div", { children: [
                          /* @__PURE__ */ jsxDEV(
                            "label",
                            {
                              className: "block mb-2 text-sm font-medium text-gray-900",
                              htmlFor: "cheque_bank_branch",
                              children: "Bank Branch"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 1136,
                              columnNumber: 33
                            },
                            this
                          ),
                          /* @__PURE__ */ jsxDEV(
                            "input",
                            {
                              type: "text",
                              name: "cheque_bank_branch",
                              id: "cheque_bank_branch",
                              value: formData.cheque_bank_branch,
                              onChange: handleChange,
                              placeholder: "Enter Bank Branch",
                              className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5"
                            },
                            void 0,
                            false,
                            {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                              lineNumber: 1142,
                              columnNumber: 33
                            },
                            this
                          )
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1135,
                          columnNumber: 31
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1068,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 1064,
                      columnNumber: 23
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                    lineNumber: 905,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-4 rounded-lg border border-gray-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-2", children: [
                      /* @__PURE__ */ jsxDEV(
                        FaWhatsappSquare,
                        {
                          color: "green",
                          className: "w-8 h-8"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1160,
                          columnNumber: 29
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("h2", { className: "text-md font-semibold text-gray-800", children: "WhatsApp Notification" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1164,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 1159,
                      columnNumber: 27
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-2", children: [
                      /* @__PURE__ */ jsxDEV(
                        "input",
                        {
                          type: "checkbox",
                          checked: whatsappEnable,
                          className: "text-green-500 checked:ring-2 checked:ring-green-700 rounded-full w-4 h-4"
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1169,
                          columnNumber: 29
                        },
                        this
                      ),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-gray-700 text-sm", children: "Send Via WhatsApp" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1174,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 1168,
                      columnNumber: 27
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                    lineNumber: 1158,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                    lineNumber: 1157,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-4", children: /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      type: "submit",
                      className: "flex items-center gap-2 text-white bg-violet-600 hover:bg-violet-700 focus:ring-2 focus:outline-none focus:ring-violet-300 font-medium rounded-md text-sm px-6 py-3 shadow-sm transition-all",
                      children: "Save Payment"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                      lineNumber: 1183,
                      columnNumber: 25
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                    lineNumber: 1182,
                    columnNumber: 23
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 718,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
            lineNumber: 714,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            Drawer,
            {
              closable: true,
              destroyOnHidden: true,
              title: /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-semibold", children: "Last Three Transactions" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1197,
                columnNumber: 19
              }, this),
              placement: "right",
              open: openAntDDrawer,
              loading: showLoader,
              onClose: () => setOpenAntDDrawer(false),
              width: 400,
              children: lastThreePayments?.length <= 0 ? /* @__PURE__ */ jsxDEV("div", { className: "font-semibold text-center text-xl py-8", children: "No Transaction Found" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1208,
                columnNumber: 19
              }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4", children: lastThreePayments.map((payment, index) => {
                return /* @__PURE__ */ jsxDEV(
                  "section",
                  {
                    className: "bg-white shadow-md rounded-lg p-4 space-y-2 border border-gray-200",
                    children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                        "Payment Date:",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: payment?.pay_date }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1221,
                          columnNumber: 33
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1219,
                        columnNumber: 31
                      }, this),
                      payment.group_id && /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                        "Group:",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: payment.group_id?.group_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1229,
                          columnNumber: 35
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1227,
                        columnNumber: 27
                      }, this),
                      payment.ticket && /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                        "Ticket:",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "font-normal", children: payment?.ticket }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1237,
                          columnNumber: 35
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1235,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                        "Amount:",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "font-bold", children: [
                          "₹",
                          payment?.amount
                        ] }, void 0, true, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1244,
                          columnNumber: 33
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1242,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                        "Payment Type:",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "font-normal", children: payment?.pay_type }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1250,
                          columnNumber: 33
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1248,
                        columnNumber: 31
                      }, this),
                      /* @__PURE__ */ jsxDEV("div", { className: "text-gray-800 font-semibold", children: [
                        "Name:",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "font-normal", children: payment.user_id?.full_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                          lineNumber: 1256,
                          columnNumber: 33
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                        lineNumber: 1254,
                        columnNumber: 31
                      }, this)
                    ]
                  },
                  index,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                    lineNumber: 1215,
                    columnNumber: 25
                  },
                  this
                );
              }) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1212,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1193,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
          lineNumber: 713,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
          lineNumber: 712,
          columnNumber: 15
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
        lineNumber: 689,
        columnNumber: 13
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        open: showModalView,
        onCancel: () => setShowModalView(false),
        onClose: () => setShowModalView(false),
        onOk: () => setShowModalView(false),
        onReload: () => handleViewModalOpen(currentGroupId),
        footer: /* @__PURE__ */ jsxDEV("div", {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
          lineNumber: 1276,
          columnNumber: 21
        }, this),
        loading: viewLoader,
        children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Payment Details" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
            lineNumber: 1279,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Group: " }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1284,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_name
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1283,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Group Value:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1288,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_value
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1287,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Group Installment:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1292,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_install
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1291,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "User:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1296,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.user_id?.full_name,
              " ",
              "| Ticket: ",
              currentViewGroup?.ticket
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1295,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Bid Amount:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1300,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.group_id?.group_value - currentViewGroup?.win_amount ? currentViewGroup?.group_id?.group_value - currentViewGroup?.win_amount : ""
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1299,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Commission:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1308,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.commission
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1307,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Winning Amount:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1311,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.win_amount
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1310,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Divident:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1315,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.divident
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1314,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Divident per Head:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1318,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.divident_head
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1317,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Next Payable:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1322,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.payable
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1321,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Auction Date:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1325,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.auction_date
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1324,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Next Date:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1329,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.next_date
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1328,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Created At:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1332,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.createdAt?.split("T")[0]
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1331,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Updated At:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1336,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.updatedAt?.split("T")[0]
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1335,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Cheque Number:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1340,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.cheque_number
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1339,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Cheque Date:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1344,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.cheque_date?.split("T")[0]
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1343,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Cheque Bank Name:" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1348,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.cheque_bank_name
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1347,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mb-3 flex gap-x-2", children: [
              /* @__PURE__ */ jsxDEV("strong", { children: "Cheque Bank Branch Name :" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
                lineNumber: 1352,
                columnNumber: 19
              }, this),
              " ",
              currentViewGroup?.cheque_bank_branch
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
              lineNumber: 1351,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
            lineNumber: 1282,
            columnNumber: 15
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
        lineNumber: 1270,
        columnNumber: 13
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
    lineNumber: 610,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
    lineNumber: 609,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx",
    lineNumber: 605,
    columnNumber: 5
  }, this);
};
_s(PenaltyPayment, "CpKKq+Xoh6p90fOjRKurIm6mWrc=");
_c = PenaltyPayment;
export default PenaltyPayment;
var _c;
$RefreshReg$(_c, "PenaltyPayment");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PaymentWithPenalty.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RVLFNBc2lCTixVQXRpQk07MkJBdERWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0Msd0JBQXdCO0FBQ2pDLE9BQU9DLFlBQVk7QUFDbkIsU0FBU0MsUUFBUUMsVUFBVUMsU0FBU0MsVUFBVUMsUUFBUUMsZUFBZTtBQUNyRSxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsWUFBWTtBQUNyQixPQUFPQyx3QkFBd0I7QUFDL0IsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLDJCQUEyQjtBQUNwQyxTQUFTQyx1QkFBdUI7QUFDaEMsT0FBT0MsdUJBQXVCO0FBQzlCLE9BQU9DLGdCQUFnQjtBQUN2QixNQUFNQyxpQkFBaUJBLE1BQU07QUFBQUMsS0FBQTtBQUMzQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSXpCLFNBQVMsRUFBRTtBQUNyQyxRQUFNLENBQUMwQixjQUFjQyxlQUFlLElBQUkzQixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDNEIsZUFBZUMsZ0JBQWdCLElBQUk3QixTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDOEIsZ0JBQWdCQyxpQkFBaUIsSUFBSS9CLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNnQyxpQkFBaUJDLGtCQUFrQixJQUFJakMsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ2tDLGVBQWVDLGdCQUFnQixJQUFJbkMsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ29DLFlBQVlDLGFBQWEsSUFBSXJDLFNBQVMsS0FBSztBQUNsRCxRQUFNLENBQUNzQyxxQkFBcUJDLHNCQUFzQixJQUFJdkMsU0FBUyxFQUFFO0FBRWpFLFFBQU0sQ0FBQ3dDLFdBQVdDLFlBQVksSUFBSXpDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMwQyxtQkFBbUJDLG9CQUFvQixJQUFJM0MsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQzRDLGVBQWVDLGdCQUFnQixJQUFJN0MsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQzhDLGtCQUFrQkMsbUJBQW1CLElBQUkvQyxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDZ0QsZ0JBQWdCQyxpQkFBaUIsSUFBSWpELFNBQVMsSUFBSTtBQUN6RCxRQUFNLENBQUNrRCxhQUFhQyxjQUFjLElBQUluRCxTQUFTLE1BQU07QUFDckQsUUFBTW9ELFNBQVEsb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ25ELFFBQU0sQ0FBQ0MsV0FBV0MsWUFBWSxJQUFJekQsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzBELFNBQVNDLFVBQVUsSUFBSTNELFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUM0RCxZQUFZQyxhQUFhLElBQUk3RCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDOEQsV0FBV0MsWUFBWSxJQUFJL0QsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ2dFLGdCQUFnQkMsaUJBQWlCLElBQUlqRSxTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDa0UscUJBQXFCQyxzQkFBc0IsSUFBSW5FLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUNvRSxvQkFBb0JDLHFCQUFxQixJQUFJckUsU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQ3NFLGdCQUFnQkMsaUJBQWlCLElBQUl2RSxTQUFTLElBQUk7QUFDekQsUUFBTSxDQUFDd0UsZ0JBQWdCQyxpQkFBaUIsSUFBSXpFLFNBQVMsS0FBSztBQUMxRCxRQUFNLENBQUMwRSxZQUFZQyxhQUFhLElBQUkzRSxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDNEUsbUJBQW1CQyxvQkFBb0IsSUFBSTdFLFNBQVMsRUFBRTtBQUU3RCxRQUFNLENBQUM4RSxnQkFBZ0JDLGlCQUFpQixJQUFJL0UsU0FBUyxDQUFDLENBQUM7QUFFdkQsUUFBTWdGLGdCQUFnQkEsQ0FBQ0Msa0JBQWtCO0FBQ3ZDLFVBQU1DLG1CQUFtQjtBQUFBLE1BQ3ZCO0FBQUEsUUFDRUMsS0FBSztBQUFBLFFBQ0xDLE9BQ0UsdUJBQUMsUUFBSyxJQUFJLFVBQVVILGVBQWVJLEdBQUcsSUFBSSxXQUFVLG9CQUFtQixxQkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsTUFFSjtBQUFBLE1BRUE7QUFBQSxRQUNFRixLQUFLO0FBQUEsUUFDTEMsT0FDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsU0FBUyxNQUFNRSxvQkFBb0JMLGVBQWVJLEdBQUc7QUFBQSxZQUFFO0FBQUE7QUFBQSxVQUZ6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLE1BRUo7QUFBQSxJQUFDO0FBR0gsV0FBT0g7QUFBQUEsRUFDVDtBQUNBLFFBQU1LLDRCQUE0QkEsQ0FBQ0MsTUFBTTtBQUN2QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEI3QixrQkFBYzRCLEtBQUs7QUFBQSxFQUNyQjtBQUNBLFFBQU0sQ0FBQ0UsYUFBYUMsY0FBYyxJQUFJNUYsU0FBUztBQUFBLElBQzdDNkYsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsSUFDVkMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsUUFBUUMsU0FBUyxJQUFJbEcsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDbUcsVUFBVUMsV0FBVyxJQUFJcEcsU0FBUztBQUFBLElBQ3ZDcUcsU0FBUztBQUFBLElBQ1RDLFlBQVk7QUFBQSxJQUNaQyxVQUFVbkQ7QUFBQUEsSUFDVm9ELFFBQVE7QUFBQSxJQUNSQyxVQUFVO0FBQUEsSUFDVkMsZ0JBQWdCO0FBQUEsSUFDaEJDLHVCQUF1QjtBQUFBLElBQ3ZCQyxjQUFjO0FBQUEsSUFDZEMsZUFBZTtBQUFBLElBQ2ZDLGFBQWE7QUFBQSxJQUNiQyxrQkFBa0I7QUFBQSxJQUNsQkMsb0JBQW9CO0FBQUEsSUFDcEJDLGlCQUFpQjtBQUFBLEVBQ25CLENBQUM7QUFFRCxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJbkgsU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQ29ILHlCQUF5QkMsMEJBQTBCLElBQUlySCxTQUFTLEtBQUs7QUFDNUUsUUFBTXNILFlBQVksSUFBSWpFLE1BQUssb0JBQUlBLEtBQUssR0FBRWtFLFNBQVEsb0JBQUlsRSxLQUFLLEdBQUVtRSxRQUFRLElBQUksQ0FBQyxDQUFDLEVBQ3BFbEUsWUFBWSxFQUNaQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBRWZ4RCxZQUFVLE1BQU07QUFDZCxVQUFNMEgsT0FBT0MsYUFBYUMsUUFBUSxNQUFNO0FBQ3hDLFVBQU1DLFVBQVVDLEtBQUtDLE1BQU1MLElBQUk7QUFFL0IsUUFBSUcsU0FBUztBQUNYLFlBQU1HLHlCQUNKSCxRQUFRSSx1QkFBdUJDO0FBRWpDLFVBQUlGLHdCQUF3QkcsaUJBQWlCLFFBQVE7QUFDbkRmLHlCQUFpQixJQUFJO0FBQUEsTUFDdkI7QUFFQSxVQUFJWSx3QkFBd0JJLHlCQUF5QixRQUFRO0FBQzNEaEIseUJBQWlCLElBQUk7QUFDckJFLG1DQUEyQixJQUFJO0FBQUEsTUFDakM7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNZSw2QkFBNkIsT0FBT0MsVUFBVTtBQUNsREEsVUFBTUMsZUFBZTtBQUNyQjdELHNCQUFrQixJQUFJO0FBQ3RCLFFBQUkwQixTQUFTRSxXQUFXRixTQUFTUSx1QkFBdUI7QUFDdEQsVUFBSTtBQUNGaEMsc0JBQWMsSUFBSTtBQUNsQixjQUFNNEQsV0FBVyxNQUFNckksSUFBSXNJLElBQUksa0NBQWtDO0FBQUEsVUFDL0RDLFFBQVE7QUFBQSxZQUNOcEMsU0FBU0YsU0FBU0U7QUFBQUEsWUFDbEJNLHVCQUF1QnpDO0FBQUFBLFlBQ3ZCd0UsT0FBTztBQUFBLFVBQ1Q7QUFBQSxRQUNGLENBQUM7QUFDRCxZQUFJSCxVQUFVSSxNQUFNO0FBQ2xCOUQsK0JBQXFCMEQsU0FBU0ksSUFBSTtBQUFBLFFBQ3BDLE9BQU87QUFDTDlELCtCQUFxQixFQUFFO0FBQUEsUUFDekI7QUFBQSxNQUNGLFNBQVMrRCxPQUFPO0FBQ2QvRCw2QkFBcUIsRUFBRTtBQUFBLE1BQ3pCLFVBQUM7QUFDQ0Ysc0JBQWMsS0FBSztBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNa0UsaUNBQWlDLE9BQU9DLFFBQVFDLHFCQUFxQjtBQUN6RSxRQUFJLENBQUNELFVBQVUsQ0FBQ0UsTUFBTUMsUUFBUUYsZ0JBQWdCLEtBQUtBLGlCQUFpQkcsV0FBVyxHQUFHO0FBQ2hGbkUsd0JBQWtCLENBQUMsQ0FBQztBQUNwQjtBQUFBLElBQ0Y7QUFHQSxVQUFNb0UsaUJBQWlCSixpQkFBaUJLO0FBQUFBLE1BQU8sQ0FBQ0MsUUFDOUMsT0FBT0EsUUFBUSxZQUFZQSxJQUFJQyxXQUFXLE9BQU87QUFBQSxJQUNuRDtBQUVBLFVBQU1DLGdCQUFnQixDQUFDO0FBRXZCLFFBQUk7QUFFRixZQUFNQyxpQkFBaUIsQ0FBQztBQUN4QixpQkFBV0gsT0FBT0YsZ0JBQWdCO0FBQ2hDLGNBQU0sQ0FBQ00sR0FBR0MsTUFBTSxJQUFJTCxJQUFJOUYsTUFBTSxHQUFHO0FBQ2pDLGNBQU0sQ0FBQ29HLFNBQVNDLE1BQU0sSUFBSUYsT0FBT25HLE1BQU0sR0FBRztBQUMxQyxZQUFJLENBQUNpRyxlQUFlRyxPQUFPLEVBQUdILGdCQUFlRyxPQUFPLElBQUk7QUFDeERILHVCQUFlRyxPQUFPLEVBQUVFLEtBQUssRUFBRUMsY0FBY1QsS0FBS08sT0FBTyxDQUFDO0FBQUEsTUFDNUQ7QUFHQSxpQkFBVyxDQUFDRCxTQUFTSSxPQUFPLEtBQUtDLE9BQU9DLFFBQVFULGNBQWMsR0FBRztBQUMvRCxjQUFNVSxNQUFNLE1BQU1oSyxJQUFJc0ksSUFBSSwrQkFBK0I7QUFBQSxVQUN2REMsUUFBUSxFQUFFcEMsU0FBU3lDLFFBQVFxQixVQUFVUixRQUFRO0FBQUEsUUFDL0MsQ0FBQztBQUVELGNBQU1TLGtCQUFrQkYsSUFBSXZCLE1BQU1BLFFBQVE7QUFFMUMsbUJBQVcsRUFBRW1CLGNBQWNGLE9BQU8sS0FBS0csU0FBUztBQUM5QyxnQkFBTU0sUUFBUUQsZ0JBQWdCRTtBQUFBQSxZQUM1QixDQUFDQyxTQUNDQyxPQUFPRCxLQUFLbEUsT0FBTyxNQUFNbUUsT0FBTzFCLE1BQU0sS0FDdEMwQixPQUFPRCxLQUFLSixRQUFRLE1BQU1LLE9BQU9iLE9BQU8sS0FDeENhLE9BQU9ELEtBQUtFLGFBQWEsTUFBTUQsT0FBT1osTUFBTTtBQUFBLFVBQ2hEO0FBRUEsY0FBSVMsT0FBT0ssU0FBUztBQUNsQixrQkFBTUEsVUFBVUwsTUFBTUs7QUFDdEIsa0JBQU1DLGlCQUFpQkMsT0FBT0YsUUFBUUcsaUJBQWlCLENBQUMsSUFBSUQsT0FBT0YsUUFBUUksNkJBQTZCLENBQUM7QUFDekcsa0JBQU1DLFlBQVlILE9BQU9GLFFBQVFJLDZCQUE2QixDQUFDO0FBQy9ELGtCQUFNRSxVQUFVSixPQUFPRixRQUFRTyw4QkFBOEIsQ0FBQztBQUM5RCxrQkFBTUMsZUFBZVAsaUJBQWlCSTtBQUV0Q3hCLDBCQUFjTyxZQUFZLElBQUk7QUFBQSxjQUM1QnFCLFdBQVdQLE9BQU9GLFFBQVFVLFNBQVMsS0FBSztBQUFBLGNBQ3hDVDtBQUFBQSxjQUNBSTtBQUFBQSxjQUNBQztBQUFBQSxjQUNBSyxTQUFTSDtBQUFBQTtBQUFBQSxjQUNUSSxjQUFjSixlQUFlRjtBQUFBQSxjQUM3Qk8sV0FBV2xCLE1BQU1tQixjQUFjO0FBQUEsY0FDL0I1QjtBQUFBQSxZQUNGO0FBQUEsVUFDRixPQUFPO0FBQ0xMLDBCQUFjTyxZQUFZLElBQUk7QUFBQSxVQUNoQztBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUEvRSx3QkFBa0J3RSxhQUFhO0FBQUEsSUFDakMsU0FBU2tDLEtBQUs7QUFDWkMsY0FBUTlDLE1BQU0sbURBQW1ENkMsR0FBRztBQUNwRTFHLHdCQUFrQixDQUFDLENBQUM7QUFBQSxJQUN0QjtBQUFBLEVBQ0Y7QUFHQWhGLFlBQVUsTUFBTTtBQUNkZ0UsaUJBQWEsRUFBRTtBQUNmLFVBQU00SCwyQkFBMkIsWUFBWTtBQUMzQyxVQUFJO0FBQ0YsY0FBTXBELFdBQVcsTUFBTXJJLElBQUlzSTtBQUFBQSxVQUN6QixrQ0FBa0MxRyxjQUFjO0FBQUEsUUFDbEQ7QUFDQSxZQUFJeUcsU0FBU3FELFVBQVU7QUFDckIsZ0JBQU0sSUFBSUMsTUFBTSxnQ0FBZ0M7QUFDbEQ5SCxxQkFBYXdFLFNBQVNJLElBQUk7QUFBQSxNQUM1QixTQUFTOEMsS0FBSztBQUNaMUgscUJBQWEsRUFBRTtBQUNmMkgsZ0JBQVFJLElBQUksZ0JBQWdCO0FBQUEsTUFDOUI7QUFBQSxJQUNGO0FBRUFILDZCQUF5QjtBQUFBLEVBQzNCLEdBQUcsQ0FBQzdKLGNBQWMsQ0FBQztBQUVuQi9CLFlBQVUsTUFBTTtBQUNka0Usc0JBQWtCLEVBQUU7QUFDcEIsVUFBTTBILDJCQUEyQixZQUFZO0FBQzNDLFVBQUk7QUFDRixjQUFNcEQsV0FBVyxNQUFNckksSUFBSXNJO0FBQUFBLFVBQ3pCLHdDQUF3QzFHLGNBQWM7QUFBQSxRQUN4RDtBQUNBLFlBQUl5RyxTQUFTcUQsVUFBVTtBQUNyQixnQkFBTSxJQUFJQyxNQUFNLGlDQUFpQztBQUNuRDVILDBCQUFrQnNFLFNBQVNJLElBQUk7QUFBQSxNQUNqQyxTQUFTOEMsS0FBSztBQUNaeEgsMEJBQWtCLEVBQUU7QUFDcEJ5SCxnQkFBUUk7QUFBQUEsVUFDTjtBQUFBLFVBQ0FMLElBQUkzRjtBQUFBQSxRQUNOO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQTZGLDZCQUF5QjtBQUFBLEVBQzNCLEdBQUcsQ0FBQzdKLGNBQWMsQ0FBQztBQUVuQi9CLFlBQVUsTUFBTTtBQUNkLFVBQU1nTSxvQkFBb0IsWUFBWTtBQUNwQyxVQUFJO0FBQ0YsY0FBTXhELFdBQVcsTUFBTXJJLElBQUlzSSxJQUFJLGVBQWU7QUFDOUMvRyxpQkFBUzhHLFVBQVVJLE1BQU1BLElBQUk7QUFBQSxNQUMvQixTQUFTQyxPQUFPO0FBQ2RuSCxpQkFBUyxFQUFFO0FBQ1hpSyxnQkFBUTlDLE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0FtRCxzQkFBa0I7QUFBQSxFQUNwQixHQUFHLEVBQUU7QUFFTGhNLFlBQVUsTUFBTTtBQUNkLFVBQU1pTSxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGLGNBQU16RCxXQUFXLE1BQU1ySSxJQUFJc0ksSUFBSSx3QkFBd0I7QUFDdkQ3Ryx3QkFBZ0I0RyxTQUFTSSxJQUFJO0FBQUEsTUFDL0IsU0FBU0MsT0FBTztBQUNkakgsd0JBQWdCLEVBQUU7QUFDbEIrSixnQkFBUTlDLE1BQU0sOEJBQThCQSxLQUFLO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQ0FvRCxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBRUwsUUFBTUMsZUFBZUEsTUFBTTtBQUN6QixVQUFNQyxZQUFZLENBQUM7QUFFbkIsUUFBSSxDQUFDcEssZ0JBQWdCO0FBQ25Cb0ssZ0JBQVVDLFdBQVc7QUFBQSxJQUN2QjtBQUVBLFFBQUksQ0FBQ2hHLFNBQVNRLHVCQUF1QjtBQUNuQ3VGLGdCQUFVdkYsd0JBQXdCO0FBQUEsSUFDcEM7QUFFQSxRQUFJLENBQUNSLFNBQVNJLFVBQVU7QUFDdEIyRixnQkFBVTNGLFdBQVc7QUFBQSxJQUN2QjtBQUVBLFVBQU1DLFNBQVM0RixXQUFXakcsU0FBU0ssTUFBTTtBQUN6QyxRQUFJNkYsTUFBTTdGLE1BQU0sS0FBS0EsVUFBVSxHQUFHO0FBQ2hDMEYsZ0JBQVUxRixTQUFTO0FBQUEsSUFDckI7QUFFQSxRQUFJdEQsZ0JBQWdCLFlBQVksQ0FBQ2lELFNBQVNPLGdCQUFnQjRGLEtBQUssR0FBRztBQUNoRUosZ0JBQVV4RixpQkFDUjtBQUFBLElBQ0o7QUFFQSxRQUFJeEQsZ0JBQWdCLFlBQVksQ0FBQ2lELFNBQVNXLGFBQWF3RixLQUFLLEdBQUc7QUFDN0RKLGdCQUFVcEYsY0FBYztBQUFBLElBQzFCO0FBQ0EsUUFBSTVELGdCQUFnQixZQUFZLENBQUNpRCxTQUFTVSxlQUFleUYsS0FBSyxHQUFHO0FBQy9ESixnQkFBVXJGLGdCQUFnQjtBQUFBLElBQzVCO0FBRUFYLGNBQVVnRyxTQUFTO0FBQ25CLFdBQU9sQyxPQUFPdUMsS0FBS0wsU0FBUyxFQUFFaEQsV0FBVztBQUFBLEVBQzNDO0FBRUEsUUFBTXNELGVBQWVBLENBQUNoSCxNQUFNO0FBQzFCLFVBQU0sRUFBRWlILE1BQU1oSCxNQUFNLElBQUlELEVBQUVFO0FBRTFCLFFBQUkrRyxTQUFTLFVBQVU7QUFFckIsVUFBSUMsVUFBVWpILE1BQU1rSCxRQUFRLFlBQVksRUFBRTtBQUUxQyxZQUFNQyxZQUFZRixRQUFRckMsTUFBTSxLQUFLLEtBQUssSUFBSW5CO0FBQzlDLFVBQUkwRCxXQUFXLEVBQUc7QUFFbEJ4RyxrQkFBWSxDQUFDeUcsVUFBVTtBQUFBLFFBQ3JCLEdBQUdBO0FBQUFBLFFBQ0gsQ0FBQ0osSUFBSSxHQUFHQztBQUFBQSxNQUNWLEVBQUU7QUFFRjtBQUFBLElBQ0Y7QUFHQXRHLGdCQUFZLENBQUN5RyxVQUFVO0FBQUEsTUFDckIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDSixJQUFJLEdBQUdoSDtBQUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBR0EsUUFBTXFILHlCQUF5QixPQUFPQyxXQUFXO0FBQy9DNUksMkJBQXVCNEksTUFBTTtBQUM3QjdHLGNBQVUsQ0FBQzJHLFVBQVUsRUFBRSxHQUFHQSxNQUFNbEcsdUJBQXVCLEdBQUcsRUFBRTtBQUU1RCxRQUFJN0UsZ0JBQWdCO0FBQ2xCLFlBQU0rRywrQkFBK0IvRyxnQkFBZ0JpTCxNQUFNO0FBQUEsSUFDN0QsT0FBTztBQUNMaEksd0JBQWtCLENBQUMsQ0FBQztBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUtBLFFBQU1pSSxxQkFBcUJBLENBQUN2SCxVQUFVO0FBQ3BDLFFBQUksQ0FBQ0EsTUFBTyxRQUFPO0FBRW5CQSxZQUFRQSxNQUFNd0gsU0FBUyxFQUFFTixRQUFRLFlBQVksRUFBRTtBQUUvQyxVQUFNTyxRQUFRekgsTUFBTWxDLE1BQU0sR0FBRztBQUM3QixVQUFNNEosY0FBY0QsTUFBTSxDQUFDO0FBQzNCLFVBQU1FLGNBQWNGLE1BQU0sQ0FBQyxJQUFJQSxNQUFNLENBQUMsRUFBRUcsTUFBTSxHQUFHLENBQUMsSUFBSTtBQUV0RCxRQUFJQyxZQUFZSCxZQUFZRSxNQUFNLEVBQUU7QUFDcEMsUUFBSUUsZUFBZUosWUFBWUUsTUFBTSxHQUFHLEVBQUU7QUFFMUMsUUFBSUcsZUFBZUQsZUFDZkEsYUFBYVosUUFBUSx5QkFBeUIsR0FBRyxJQUFJLE1BQU1XLFlBQzNEQTtBQUVKLFdBQU9GLGNBQWMsR0FBR0ksWUFBWSxJQUFJSixXQUFXLEtBQUtJO0FBQUFBLEVBQzFEO0FBRUEsUUFBTUMsVUFBVTtBQUFBLElBQ2QsRUFBRXRJLEtBQUssTUFBTXVJLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUV2SSxLQUFLLFFBQVF1SSxRQUFRLFlBQVk7QUFBQSxJQUNuQyxFQUFFdkksS0FBSyxvQkFBb0J1SSxRQUFRLG1CQUFtQjtBQUFBLElBQ3RELEVBQUV2SSxLQUFLLFFBQVF1SSxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUV2SSxLQUFLLGdCQUFnQnVJLFFBQVEsd0JBQXdCO0FBQUEsSUFDdkQsRUFBRXZJLEtBQUssY0FBY3VJLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUV2SSxLQUFLLFVBQVV1SSxRQUFRLGdCQUFnQjtBQUFBLElBQ3pDLEVBQUV2SSxLQUFLLGVBQWV1SSxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFdkksS0FBSyxXQUFXdUksUUFBUSxVQUFVO0FBQUEsSUFDcEMsRUFBRXZJLEtBQUssVUFBVXVJLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUV2SSxLQUFLLFlBQVl1SSxRQUFRLGVBQWU7QUFBQSxJQUMxQyxFQUFFdkksS0FBSyxtQkFBbUJ1SSxRQUFRLGtCQUFrQjtBQUFBLElBQ3BELEVBQUV2SSxLQUFLLGdCQUFnQnVJLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUV2SSxLQUFLLFVBQVV1SSxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1DLGlCQUFpQixPQUFPN0UsV0FBVztBQUN2QzNHLHFCQUFpQixFQUFFO0FBQ25CSSwyQkFBdUIsRUFBRTtBQUN6QlIsc0JBQWtCK0csTUFBTTtBQUN4QjFDLGdCQUFZLENBQUN3SCxrQkFBa0I7QUFBQSxNQUM3QixHQUFHQTtBQUFBQSxNQUNIdkgsU0FBU3lDO0FBQUFBLElBQ1gsRUFBRTtBQUNGNUMsY0FBVSxDQUFDMkgsY0FBYyxFQUFFLEdBQUdBLFVBQVUxQixVQUFVLEdBQUcsRUFBRTtBQUN2RGhJLDJCQUF1QixFQUFFO0FBQ3pCWSxzQkFBa0IsQ0FBQyxDQUFDO0FBQ3BCK0ksNkJBQXlCaEYsTUFBTTtBQUFBLEVBQ2pDO0FBRUEsUUFBTWlGLHFCQUFxQixPQUFPcEUsWUFBWTtBQUM1QyxRQUFJQSxTQUFTO0FBQ1gsVUFBSXFFLE1BQU0sNENBQTRDNUssS0FBSyxZQUFZQSxLQUFLO0FBQzVFLFVBQUk7QUFDRksscUJBQWEsSUFBSTtBQUNqQixjQUFNOEUsV0FBVyxNQUFNckksSUFBSXNJLElBQUl3RixHQUFHO0FBRWxDLFlBQUl6RixTQUFTSSxRQUFRSixTQUFTSSxLQUFLTyxTQUFTLEdBQUc7QUFDN0MsZ0JBQU0rRSxnQkFBZ0IxRixTQUFTSSxLQUFLdUYsSUFBSSxDQUFDQyxPQUFPQyxVQUFVO0FBQ3hELGdCQUFJLENBQUNELE9BQU9oRSxVQUFVcUIsV0FBWSxRQUFPLENBQUM7QUFDMUMsbUJBQU87QUFBQSxjQUNMbkcsS0FBSzhJLE1BQU05STtBQUFBQSxjQUNYZ0osSUFBSUQsUUFBUTtBQUFBLGNBQ1ozQixNQUFNMEIsT0FBTzlILFNBQVNpSTtBQUFBQSxjQUN0QkMsY0FBY0osT0FBTzlILFNBQVNrSTtBQUFBQSxjQUM5Qi9DLFlBQVkyQyxPQUFPaEUsVUFBVXFCO0FBQUFBLGNBQzdCNUIsUUFBUXVFLE1BQU12RTtBQUFBQSxjQUNkNEUsU0FBU0wsTUFBTTdIO0FBQUFBLGNBQ2ZtSSxhQUFhTixNQUFNTztBQUFBQSxjQUNuQmxJLFFBQVEySCxNQUFNM0g7QUFBQUEsY0FDZEMsVUFBVTBILE9BQU8xSDtBQUFBQSxjQUNqQmtJLE1BQU1SLE9BQU81SCxTQUFTaEQsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLGNBQ2xDcUwsa0JBQWtCVCxPQUFPVSxXQUFXdEwsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLGNBQ2hEdUwsY0FDRVgsT0FBT1csY0FBY3JDLFFBQ3JCMEIsT0FBT1ksWUFBWUMsY0FDbkI7QUFBQSxjQUNGQyxRQUNFLHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxTQUFTLENBQUMsT0FBTztBQUFBLGtCQUNqQixNQUFNO0FBQUEsb0JBQ0pDLE9BQU9sSyxjQUFjbUosS0FBSztBQUFBLGtCQUM1QjtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQVBqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxZQUVKO0FBQUEsVUFDRixDQUFDO0FBQ0R0TSwyQkFBaUJvTSxhQUFhO0FBQUEsUUFDaEM7QUFBQSxNQUNGLFNBQVNyRixPQUFPO0FBQ2QvRyx5QkFBaUIsRUFBRTtBQUNuQjZKLGdCQUFROUMsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFBQSxNQUNyRCxVQUFDO0FBQ0NuRixxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU0wTCwwQkFBMEJBLENBQUMzSixNQUFNO0FBQ3JDLFVBQU00SixlQUFlNUosRUFBRUUsT0FBT0Q7QUFDOUJ0QyxtQkFBZWlNLFlBQVk7QUFDM0JoSixnQkFBWSxDQUFDeUgsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0hwSCxVQUFVMkk7QUFBQUEsTUFFVjFJLGdCQUNFMEksaUJBQWlCLFlBQVlBLGlCQUFpQixlQUMxQ3ZCLFNBQVNuSCxpQkFDVDtBQUFBLElBQ1IsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNMkksMEJBQTBCQSxDQUFDN0osTUFBTTtBQUNyQyxVQUFNNEosZUFBZTVKLEVBQUVFLE9BQU9EO0FBQzlCVyxnQkFBWSxDQUFDeUgsY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0hqSCxjQUFjd0k7QUFBQUEsSUFDaEIsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNRSxlQUFlLE9BQU85SixNQUFNO0FBQ2hDQSxNQUFFOEMsZUFBZTtBQUNqQixVQUFNaUgsVUFBVXRELGFBQWE7QUFDN0IsUUFBSTtBQUNGLFVBQUlzRCxTQUFTO0FBQ1gzSix1QkFBZSxDQUFDaUgsVUFBVTtBQUFBLFVBQ3hCLEdBQUdBO0FBQUFBLFVBQ0hoSCxZQUFZO0FBQUEsUUFDZCxFQUFFO0FBQ0ZwRCxxQkFBYSxLQUFLO0FBRWxCLGNBQU0rTSxNQUFNOUgsYUFBYUMsUUFBUSxNQUFNO0FBQ3ZDLFlBQUlvSCxhQUFhO0FBQ2pCLFlBQUk7QUFDRixjQUFJUyxLQUFLO0FBQ1BULHlCQUFhbEgsS0FBS0MsTUFBTTBILEdBQUc7QUFBQSxVQUM3QjtBQUFBLFFBQ0YsU0FBU2hLLElBQUc7QUFDVmtHLGtCQUFROUMsTUFBTSwyQ0FBMkNwRCxFQUFDO0FBQUEsUUFDNUQ7QUFFQVcsaUJBQVNRLHdCQUF3QnpDO0FBQ2pDaUMsaUJBQVM0SSxhQUFhQSxZQUFZMUo7QUFDbENoQiw4QkFBc0IsSUFBSTtBQUMxQixjQUFNbkUsSUFBSXVQLEtBQUssc0NBQXNDdEosUUFBUTtBQUU3RHBFLDBCQUFrQixFQUFFO0FBQ3BCb0MsK0JBQXVCLEVBQUU7QUFFekJpQyxvQkFBWTtBQUFBLFVBQ1ZDLFNBQVM7QUFBQSxVQUNUQyxZQUFZO0FBQUEsVUFDWkMsVUFBVW5EO0FBQUFBLFVBQ1ZvRCxRQUFRO0FBQUEsVUFDUkMsVUFBVTtBQUFBLFVBQ1ZDLGdCQUFnQjtBQUFBLFVBQ2hCQyx1QkFBdUI7QUFBQSxVQUN2QkMsY0FBYztBQUFBLFVBQ2RDLGVBQWU7QUFBQSxVQUNmQyxhQUFhO0FBQUEsVUFDYkMsa0JBQWtCO0FBQUEsVUFDbEJDLG9CQUFvQjtBQUFBLFFBQ3RCLENBQUM7QUFDRHBCLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pFLFVBQVU7QUFBQSxVQUNWRCxTQUFTO0FBQUEsVUFDVEUsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVM0QyxPQUFPO0FBQ2RuRyxtQkFBYSxLQUFLO0FBQ2xCVix3QkFBa0IsRUFBRTtBQUNwQnFFLGtCQUFZO0FBQUEsUUFDVkMsU0FBUztBQUFBLFFBQ1RDLFlBQVk7QUFBQSxRQUNaQyxVQUFVO0FBQUEsUUFDVkMsUUFBUTtBQUFBLFFBQ1JDLFVBQVU7QUFBQSxRQUNWQyxnQkFBZ0I7QUFBQSxRQUNoQkMsdUJBQXVCO0FBQUEsUUFDdkJDLGNBQWM7QUFBQSxNQUNoQixDQUFDO0FBQ0RoQixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaRSxVQUFVO0FBQUEsUUFDVkQsU0FBUztBQUFBLFFBQ1RFLE1BQU07QUFBQSxNQUNSLENBQUM7QUFFRDBGLGNBQVE5QyxNQUFNLGtDQUFrQ0EsS0FBSztBQUFBLElBQ3ZELFVBQUM7QUFDQ3ZFLDRCQUFzQixLQUFLO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBRUEsUUFBTWlCLHNCQUFzQixPQUFPb0ssY0FBYztBQUMvQyxRQUFJO0FBQ0YvTCxpQkFBVyxJQUFJO0FBQ2ZkLHVCQUFpQixJQUFJO0FBQ3JCMEIsd0JBQWtCbUwsU0FBUztBQUMzQnJOLG9CQUFjLElBQUk7QUFDbEIsWUFBTWtHLFdBQVcsTUFBTXJJLElBQUlzSSxJQUFJLDhCQUE4QmtILFNBQVMsRUFBRTtBQUN4RTNNLDBCQUFvQndGLFNBQVNJLElBQUk7QUFBQSxJQUNuQyxTQUFTQyxPQUFPO0FBQ2Q4QyxjQUFROUMsTUFBTSwwQkFBMEJBLEtBQUs7QUFBQSxJQUMvQyxVQUFDO0FBQ0NqRixpQkFBVyxLQUFLO0FBQ2hCdEIsb0JBQWMsS0FBSztBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU15TCwyQkFBMkIsT0FBT25FLFlBQVk7QUFDbEQsUUFBSUEsU0FBUztBQUNYLFVBQUk7QUFDRixjQUFNcEIsV0FBVyxNQUFNckksSUFBSXVQO0FBQUFBLFVBQ3pCLG1DQUFtQzlGLE9BQU87QUFBQSxRQUM1QztBQUNBLFlBQUlwQixTQUFTSSxRQUFRSixTQUFTSSxLQUFLTyxTQUFTLEdBQUc7QUFDN0MsZ0JBQU15RyxtQkFBbUJwSCxTQUFTSSxLQUFLUztBQUFBQSxZQUNyQyxDQUFDd0csWUFBWUEsUUFBUUMsY0FBY0QsUUFBUUMsV0FBVzFCO0FBQUFBLFVBQ3hEO0FBQ0E1TCxpQ0FBdUJvTixnQkFBZ0I7QUFBQSxRQUN6QztBQUFBLE1BQ0YsU0FBUy9HLE9BQU87QUFDZDhDLGdCQUFROUMsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdERyRywrQkFBdUIsRUFBRTtBQUFBLE1BQzNCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLG1DQUNHNkIsK0JBQ0MsdUJBQUMsc0JBQW1CLE9BQU8saUNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBeUQsSUFFMUQsdUJBQUMsU0FBSSxXQUFVLG1EQUNaLGlDQUFDLFNBQUksV0FBVSxTQUNaO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNYO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyw2QkFBNkJtQjtBQUFBQSxRQUM3QixZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRW5CO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNSSxZQUFZSztBQUFBQSxRQUNsQixXQUFXTCxZQUFZRTtBQUFBQSxRQUN2QixTQUFTRixZQUFZRztBQUFBQSxRQUNyQixTQUFTLE1BQ1BGLGVBQWUsQ0FBQ2lILFVBQVUsRUFBRSxHQUFHQSxNQUFNaEgsWUFBWSxNQUFNLEVBQUU7QUFBQTtBQUFBLE1BTDdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1HO0FBQUEsSUFFRCx1QkFBQyxTQUFJLFdBQVUsa0RBQ0U7QUFBQSw2QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUMxQix1QkFBQyxRQUFHLFdBQVUsMEJBQXlCLHdCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStDO0FBQUEsTUFDL0MsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxhQUFZLHNDQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLFVBQ25ELHVCQUFDLFNBQUksV0FBVSw0Q0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsYUFBWTtBQUFBLGdCQUNaLHVCQUF1QjtBQUFBLGdCQUN2QjtBQUFBLGdCQUNBLFdBQVU7QUFBQSxnQkFDVixjQUFjLENBQUNpSyxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSi9DLFNBQVMsRUFDVGdELFlBQVksRUFDWkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsZ0JBRWpDLE9BQU9qTyxtQkFBbUJtTztBQUFBQSxnQkFDMUIsVUFBVXBDO0FBQUFBLGdCQUVUck0sdUJBQWF3TTtBQUFBQSxrQkFBSSxDQUFDQyxVQUNqQix1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTTlJLEtBQ3pDOEksZ0JBQU0zQyxjQURXMkMsTUFBTTlJLEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUEsY0FsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBbUJBO0FBQUEsWUFDQSx1QkFBQyxTQUNDO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNNUMsYUFBYSxJQUFJO0FBQUEsZ0JBQ2hDLFdBQVU7QUFBQSxnQkFBdUc7QUFBQTtBQUFBLGNBRm5IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLGVBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkJBO0FBQUEsYUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdDQTtBQUFBLFFBRUNiLGlCQUFpQkEsY0FBY3NILFNBQVMsSUFDdkM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQU10SCxjQUFjd0g7QUFBQUEsY0FBTyxDQUFDbUIsU0FDMUJQLE9BQU8rQyxPQUFPeEMsSUFBSSxFQUFFNkY7QUFBQUEsZ0JBQUssQ0FBQzNLLFVBQ3hCK0UsT0FBTy9FLEtBQUssRUFDVHdLLFlBQVksRUFDWkMsU0FBU3RNLFdBQVdxTSxZQUFZLENBQUM7QUFBQSxjQUN0QztBQUFBLFlBQ0Y7QUFBQSxZQUNBO0FBQUEsWUFDQSxpQkFBZ0I7QUFBQSxZQUNoQixpQkFBaUIsQ0FBQyxZQUFZO0FBQUEsWUFDOUIsbUJBQW1CLENBQUMsU0FBUztBQUFBLFlBQzdCLGtCQUFrQjtBQUFBO0FBQUEsVUFacEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBWW1DLElBR25DLHVCQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLE1BQUs7QUFBQSxZQUNMLFNBQVNyTyxjQUFjc0gsVUFBVTtBQUFBO0FBQUEsVUFIbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3FDLEtBSnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFdBekRKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyREE7QUFBQSxTQTlERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0RBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTTFHO0FBQUFBLFFBQ04sU0FBUyxNQUFNO0FBQ2JULDRCQUFrQixFQUFFO0FBQ3BCVSx1QkFBYSxLQUFLO0FBQ2xCeUQsb0JBQVUsQ0FBQyxDQUFDO0FBQ1ovQixpQ0FBdUIsRUFBRTtBQUFBLFFBQzNCO0FBQUEsUUFDQSxPQUFPO0FBQUEsUUFDUCxXQUFVO0FBQUEsUUFDVixPQUNFLHVCQUFDLFdBQVEsT0FBTSx1QkFDYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBU2lFO0FBQUFBLFlBQ1QsT0FBTTtBQUFBLFlBQ04sV0FBVTtBQUFBLFlBRVY7QUFBQSxxQ0FBQyxhQUFVLFdBQVUsYUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBOEI7QUFBQSxjQUM5Qix1QkFBQyxVQUFLLG1DQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlCO0FBQUE7QUFBQTtBQUFBLFVBTjNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUEsUUFHRixpQ0FBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsdURBQXNELDJCQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixVQUFVa0g7QUFBQUEsZ0JBQ1YsWUFBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUTtBQUFBLHdCQUFVO0FBQUE7QUFBQSwwQkFFVCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBQWdDO0FBQUE7QUFBQTtBQUFBLHNCQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXO0FBQUEsd0JBQ1gsYUFBWTtBQUFBLHdCQUNaLHVCQUF1QjtBQUFBLHdCQUN2QjtBQUFBLHdCQUNBLGNBQWMsQ0FBQ1EsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0ovQyxTQUFTLEVBQ1RnRCxZQUFZLEVBQ1pDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLHdCQUVqQyxPQUFPbk8sa0JBQWtCcU87QUFBQUEsd0JBQ3pCLFVBQVV4QztBQUFBQSx3QkFFVG5NLGdCQUFNME07QUFBQUEsMEJBQUksQ0FBQ0MsVUFDVix1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTTlJLEtBQ3pDLGFBQUc4SSxNQUFNRyxTQUFTLE1BQU1ILE1BQU1JLFlBQVksTUFEekJKLE1BQU05SSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUVBO0FBQUEsd0JBQ0Q7QUFBQTtBQUFBLHNCQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBbUJBO0FBQUEsb0JBQ0NZLE9BQU9rRyxZQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmxHLGlCQUFPa0csWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsdUJBOUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZ0NBO0FBQUEsa0JBRUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsV0FBVyxjQUFjekosb0JBQW9CLG9CQUFvQixFQUFFO0FBQUEsc0JBR25FO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVE7QUFBQSw0QkFBVTtBQUFBO0FBQUEsOEJBRUgsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUFnQztBQUFBO0FBQUE7QUFBQSwwQkFKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsd0JBQ0E7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsVUFBVUE7QUFBQUEsNEJBQ1YsTUFBSztBQUFBLDRCQUNMLE1BQUs7QUFBQSw0QkFDTCxhQUFZO0FBQUEsNEJBQ1osVUFBVW9LO0FBQUFBLDRCQUNWLFNBQVNwSztBQUFBQSw0QkFDVCxPQUFPd0I7QUFBQUEsNEJBQ1AsV0FBVTtBQUFBLDRCQUVUNUI7QUFBQUEsa0RBQW9CNEwsSUFBSSxDQUFDbUMsT0FBT2pDLFVBQVU7QUFDekMsc0NBQU03QyxZQUNKOEUsT0FBT1IsWUFBWTFCLE9BQU8zQyxjQUMxQjtBQUNGLHNDQUFNN0IsVUFDSjBHLE9BQU9SLFlBQVkxQixPQUFPOUksT0FDMUIsV0FBVytJLEtBQUs7QUFDbEIsc0NBQU14RSxTQUNKeUcsT0FBT1IsWUFBWTlGLFdBQVc7QUFFaEMsdUNBQ0U7QUFBQSxrQ0FBQyxPQUFPO0FBQUEsa0NBQVA7QUFBQSxvQ0FFQyxPQUFPLFFBQVFKLE9BQU8sSUFBSUMsTUFBTTtBQUFBLG9DQUUvQjJCO0FBQUFBO0FBQUFBLHNDQUFVO0FBQUEsc0NBQUkzQjtBQUFBQTtBQUFBQTtBQUFBQSxrQ0FIVixRQUFRRCxPQUFPLElBQUlDLE1BQU07QUFBQSxrQ0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FLQTtBQUFBLDhCQUVKLENBQUM7QUFBQSw4QkFDQTVGLGdCQUFnQmtLLElBQUksQ0FBQ29DLFVBQVU7QUFDOUIsdUNBQ0UsdUJBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTyxTQUFTQSxNQUFNakwsR0FBRyxJQUNyQyxhQUFHaUwsTUFBTUMsUUFBUSxRQUFRRCxNQUFNRSxjQUFjLE1BRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSw4QkFFSixDQUFDO0FBQUEsOEJBQ0ExTSxXQUFXb0ssSUFBSSxDQUFDdUMsYUFBYTtBQUM1Qix1Q0FDRSx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFPLFFBQVFBLFNBQVNwTCxHQUFHLElBQ3ZDLGtCQUFRb0wsU0FBU0MsT0FBTyxRQUFRRCxTQUFTRSxXQUFXLE1BRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSw4QkFFSixDQUFDO0FBQUE7QUFBQTtBQUFBLDBCQTFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBMkNBO0FBQUEsd0JBQ0MxSyxPQUFPVSx5QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZWLGlCQUFPVSx5QkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUE7QUFBQTtBQUFBLG9CQXpESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBMkRBO0FBQUEsa0JBRUN6QyxvQkFBb0JnRixTQUFTLEtBQzVCLHVCQUFDLFNBQUksV0FBVSw2REFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxzQ0FDYixpQ0FBQyxRQUFHLFdBQVUsK0RBQ1o7QUFBQSw2Q0FBQyxtQkFBZ0IsV0FBVSxtQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBMEM7QUFBQSxzQkFBRztBQUFBLHlCQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFLQTtBQUFBLG9CQUVBLHVCQUFDLFNBQUksV0FBVSxPQUNaaEY7QUFBQUEsMENBQW9CZ0ssSUFBSSxDQUFDMEMsV0FBV3hDLFVBQVU7QUFDN0MsOEJBQU15QyxPQUFPL0wsZUFBZThMLFNBQVM7QUFDckMsNEJBQUksQ0FBQ0MsS0FBTSxRQUFPO0FBRWxCLDhCQUFNLENBQUNwSCxHQUFHQyxNQUFNLElBQUlrSCxVQUFVck4sTUFBTSxHQUFHO0FBQ3ZDLDhCQUFNLENBQUNvRyxTQUFTQyxNQUFNLElBQUlGLE9BQU9uRyxNQUFNLEdBQUc7QUFDMUMsOEJBQU11TixjQUFjLEdBQUdELEtBQUt0RixTQUFTLE1BQU0zQixNQUFNO0FBRWpELCtCQUNFLHVCQUFDLFNBQW9CLFdBQVd3RSxRQUFRbEssb0JBQW9CZ0YsU0FBUyxJQUFJLHVDQUF1QyxRQUM5RztBQUFBLGlEQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG1EQUFDLFFBQUcsV0FBVSx1Q0FDWDRILHlCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFDQSx1QkFBQyxVQUFLLFdBQVUsbUVBQWtFO0FBQUE7QUFBQSw4QkFDdkVsSDtBQUFBQSxpQ0FEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsK0JBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FPQTtBQUFBLDBCQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLG1EQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLHFEQUFDLE9BQUUsV0FBVSxzREFBcUQsMEJBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBQTRFO0FBQUEsOEJBQzVFLHVCQUFDLE9BQUUsV0FBVSx1Q0FBc0M7QUFBQTtBQUFBLGdDQUMvQ2dCLE9BQU9pRyxLQUFLMUYsU0FBUyxFQUFFNEYsZUFBZSxPQUFPO0FBQUEsbUNBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBRUE7QUFBQSxpQ0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUtBO0FBQUEsNEJBRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEscURBQUMsT0FBRSxXQUFVLHNEQUFxRCx1QkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBeUU7QUFBQSw4QkFDekUsdUJBQUMsT0FBRSxXQUFVLHVDQUFzQztBQUFBO0FBQUEsZ0NBQy9DbkcsT0FBT2lHLEtBQUt4RixPQUFPLEVBQUUwRixlQUFlLE9BQU87QUFBQSxtQ0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FFQTtBQUFBLGlDQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBS0E7QUFBQSw0QkFJQSx1QkFBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSxxREFBQyxPQUFFLFdBQVUsc0RBQXFELHdCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUEwRTtBQUFBLDhCQUMxRSx1QkFBQyxPQUFFLFdBQVUsdUNBQXNDO0FBQUE7QUFBQSxnQ0FDL0NuRyxPQUFPaUcsS0FBSzdGLE9BQU8sRUFBRStGLGVBQWUsT0FBTztBQUFBLG1DQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUVBO0FBQUEsaUNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FLQTtBQUFBLCtCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQXVCQTtBQUFBLDZCQWpDUUgsV0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQWtDQTtBQUFBLHNCQUVKLENBQUM7QUFBQSxzQkFHRCx1QkFBQyxTQUFJLFdBQVUsb0RBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsK0NBQUMsUUFBRyxXQUFVLHVDQUFzQyxxQ0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBeUU7QUFBQSx3QkFDekUsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsaURBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtREFBQyxPQUFFLFdBQVUsaURBQWdELDZCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUEwRTtBQUFBLDRCQUMxRSx1QkFBQyxPQUFFLFdBQVUsdUNBQXNDO0FBQUE7QUFBQSw4QkFDL0MxTSxvQkFBb0I4TSxPQUFPLENBQUNDLEtBQUtMLGNBQWM7QUFDL0Msc0NBQU1DLE9BQU8vTCxlQUFlOEwsU0FBUztBQUNyQyx1Q0FBT0ssT0FBT0osT0FBT2pHLE9BQU9pRyxLQUFLeEYsT0FBTyxJQUFJO0FBQUEsOEJBQzlDLEdBQUcsQ0FBQyxFQUFFMEYsZUFBZSxPQUFPO0FBQUEsaUNBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBS0E7QUFBQSwrQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQVFBO0FBQUEsMEJBQ0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxtREFBQyxPQUFFLFdBQVUsaURBQWdELDZCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUEwRTtBQUFBLDRCQUMxRSx1QkFBQyxPQUFFLFdBQVUsdUNBQXNDO0FBQUE7QUFBQSw4QkFDL0M3TSxvQkFBb0I4TSxPQUFPLENBQUNDLEtBQUtMLGNBQWM7QUFDL0Msc0NBQU1DLE9BQU8vTCxlQUFlOEwsU0FBUztBQUNyQyx1Q0FBT0ssT0FBT0osT0FBT2pHLE9BQU9pRyxLQUFLdkYsWUFBWSxJQUFJO0FBQUEsOEJBQ25ELEdBQUcsQ0FBQyxFQUFFeUYsZUFBZSxPQUFPO0FBQUEsaUNBSjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBS0E7QUFBQSwrQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQVFBO0FBQUEsNkJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBbUJBO0FBQUEsMkJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBc0JBLEtBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBd0JBO0FBQUEseUJBekVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBMEVBO0FBQUEsdUJBbEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBbUZBO0FBQUEsa0JBR0YsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsMkNBQUMsUUFBRyxXQUFVLDRDQUEyQywrQkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLDZDQUFDLFNBQ0M7QUFBQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFVO0FBQUEsNEJBQ1YsU0FBUTtBQUFBLDRCQUFlO0FBQUE7QUFBQSwwQkFGekI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsd0JBQ0E7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsVUFBVSxDQUFDN0o7QUFBQUEsNEJBQ1gsTUFBSztBQUFBLDRCQUNMLE1BQUs7QUFBQSw0QkFDTCxLQUNFRSwwQkFBMEJFLFlBQVk2STtBQUFBQSw0QkFFeEMsS0FBSy9JLDBCQUEwQmhFLFFBQVErTTtBQUFBQSw0QkFDdkMsT0FBT2hLLFNBQVNJO0FBQUFBLDRCQUNoQixJQUFHO0FBQUEsNEJBQ0gsVUFBVWlHO0FBQUFBLDRCQUNWLGFBQVk7QUFBQSw0QkFDWixXQUFVO0FBQUE7QUFBQSwwQkFaWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBWTJJO0FBQUEsd0JBRTFJdkcsT0FBT00sWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZOLGlCQUFPTSxZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSwyQkF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkEwQkE7QUFBQSxzQkFFQSx1QkFBQyxTQUNDO0FBQUEsK0NBQUMsU0FDQztBQUFBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLFdBQVU7QUFBQSw4QkFDVixTQUFRO0FBQUEsOEJBQWE7QUFBQTtBQUFBLGdDQUVkLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FBZ0M7QUFBQTtBQUFBO0FBQUEsNEJBSnpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFLQTtBQUFBLDBCQUNBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLE1BQUs7QUFBQSw4QkFDTCxNQUFLO0FBQUEsOEJBQ0wsT0FBT3lHLG1CQUFtQjdHLFNBQVNLLE1BQU07QUFBQSw4QkFDekMsSUFBRztBQUFBLDhCQUNILFVBQVVnRztBQUFBQSw4QkFDVixhQUFZO0FBQUEsOEJBQ1o7QUFBQSw4QkFDQSxXQUFVO0FBQUE7QUFBQSw0QkFSWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBUTJJO0FBQUEsMEJBRTFJdkcsT0FBT08sVUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZQLGlCQUFPTyxVQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFzQkE7QUFBQSx3QkFDQSx1QkFBQyxTQUFJLFdBQVUsbUJBQW1CdEYsOEJBQW9CaUYsU0FBU0ssTUFBTSxLQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUF1RTtBQUFBLDJCQXhCekU7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkF5QkE7QUFBQSxzQkFFQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVE7QUFBQSw0QkFBVTtBQUFBO0FBQUEsMEJBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTCxJQUFHO0FBQUEsNEJBQ0gsV0FBVTtBQUFBLDRCQUNWLFVBQVUySTtBQUFBQSw0QkFFVjtBQUFBLHFEQUFDLFlBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUF5QjtBQUFBLDhCQUN6Qix1QkFBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBNkI7QUFBQSw4QkFDN0IsdUJBQUMsWUFBTyxPQUFNLGNBQWEsMEJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBQXFDO0FBQUEsOEJBQ3JDLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUE2QjtBQUFBO0FBQUE7QUFBQSwwQkFUL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVVBO0FBQUEsMkJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBa0JBO0FBQUEsc0JBRUNqSSxpQkFDQyx1QkFBQyxTQUNDO0FBQUE7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVE7QUFBQSw0QkFBYztBQUFBO0FBQUEsMEJBRnhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTCxJQUFHO0FBQUEsNEJBQ0gsV0FBVTtBQUFBLDRCQUNWLFVBQVVtSTtBQUFBQSw0QkFFVjtBQUFBLHFEQUFDLFlBQU8sT0FBTSxJQUFHLG1DQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQUFvQztBQUFBLDhCQUNwQyx1QkFBQyxZQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FBaUM7QUFBQTtBQUFBO0FBQUEsMEJBUG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFRQTtBQUFBLDJCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBZ0JBO0FBQUEseUJBN0ZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBK0ZBO0FBQUEsb0JBRUNsSixTQUFTSyxVQUFVdEMsb0JBQW9CZ0YsU0FBUyxLQUMvQyx1QkFBQyxTQUNDO0FBQUEsNkNBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFVO0FBQUEsNEJBQ1YsU0FBUTtBQUFBLDRCQUFtQjtBQUFBO0FBQUEsMEJBRjdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHdCQUNBO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLE1BQUs7QUFBQSw0QkFDTCxXQUFVO0FBQUEsNEJBQ1YsYUFBWTtBQUFBLDRCQUNaLE9BQU84RDtBQUFBQSw4QkFDTHBDLE9BQU96RSxTQUFTSyxNQUFNLElBQ3RCdEMsb0JBQW9CZ0Y7QUFBQUEsNEJBQ3RCO0FBQUEsNEJBQ0EsVUFBUTtBQUFBO0FBQUEsMEJBUlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVFVO0FBQUEsMkJBZlo7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFpQkE7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsbUJBQ1poSTtBQUFBQSx3QkFDQzBKLE9BQU96RSxTQUFTSyxNQUFNLElBQ3RCdEMsb0JBQW9CZ0Y7QUFBQUEsc0JBQ3RCLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFLQTtBQUFBLHlCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXlCQTtBQUFBLHFCQUdBaEcsZ0JBQWdCLFlBQ2hCQSxnQkFBZ0IsaUJBQ2QsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxXQUFVO0FBQUEsMEJBQ1YsU0FBUTtBQUFBLDBCQUFnQjtBQUFBO0FBQUEsNEJBRVQ7QUFBQSw0QkFDZix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBQWdDO0FBQUE7QUFBQTtBQUFBLHdCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBTUE7QUFBQSxzQkFDQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxNQUFLO0FBQUEsMEJBQ0wsTUFBSztBQUFBLDBCQUNMLElBQUc7QUFBQSwwQkFDSCxPQUFPaUQsU0FBU087QUFBQUEsMEJBQ2hCLFVBQVU4RjtBQUFBQSwwQkFDVixhQUFZO0FBQUEsMEJBQ1osV0FBVTtBQUFBO0FBQUEsd0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU8ySTtBQUFBLHNCQUUxSXZHLE9BQU9TLGtCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlQsaUJBQU9TLGtCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFzQkE7QUFBQSxvQkFHSHhELGdCQUFnQixZQUNmLHVCQUFDLFNBQUksV0FBVSxrQkFDYjtBQUFBLDZDQUFDLFFBQUcsV0FBVSx1Q0FBc0MsOEJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSwrQ0FBQyxTQUNDO0FBQUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsV0FBVTtBQUFBLDhCQUNWLFNBQVE7QUFBQSw4QkFBZTtBQUFBO0FBQUEsZ0NBRVQ7QUFBQSxnQ0FDZCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBQWdDO0FBQUE7QUFBQTtBQUFBLDRCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBTUE7QUFBQSwwQkFDQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxNQUFLO0FBQUEsOEJBQ0wsTUFBSztBQUFBLDhCQUNMLElBQUc7QUFBQSw4QkFDSCxPQUFPaUQsU0FBU1U7QUFBQUEsOEJBQ2hCLFVBQVUyRjtBQUFBQSw4QkFDVixhQUFZO0FBQUEsOEJBQ1osV0FBVTtBQUFBO0FBQUEsNEJBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQU8ySTtBQUFBLDBCQUUxSXZHLE9BQU9ZLGlCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVlosaUJBQU9ZLGlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBRUE7QUFBQSw2QkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFzQkE7QUFBQSx3QkFFQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsV0FBVTtBQUFBLDhCQUNWLFNBQVE7QUFBQSw4QkFBYTtBQUFBO0FBQUEsZ0NBRVQ7QUFBQSxnQ0FDWix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBQWdDO0FBQUE7QUFBQTtBQUFBLDRCQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBTUE7QUFBQSwwQkFDQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxNQUFLO0FBQUEsOEJBQ0wsTUFBSztBQUFBLDhCQUNMLElBQUc7QUFBQSw4QkFDSCxPQUFPVixTQUFTVyxZQUFZdkQsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLDhCQUN4QyxVQUFVaUo7QUFBQUEsOEJBQ1YsYUFBWTtBQUFBLDhCQUNaLFdBQVU7QUFBQTtBQUFBLDRCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFPMkk7QUFBQSwwQkFFMUl2RyxPQUFPYSxlQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmIsaUJBQU9hLGVBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FFQTtBQUFBLDZCQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQXNCQTtBQUFBLHdCQUVBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxXQUFVO0FBQUEsOEJBQ1YsU0FBUTtBQUFBLDhCQUFrQjtBQUFBO0FBQUEsNEJBRjVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFLQTtBQUFBLDBCQUNBO0FBQUEsNEJBQUM7QUFBQTtBQUFBLDhCQUNDLE1BQUs7QUFBQSw4QkFDTCxNQUFLO0FBQUEsOEJBQ0wsSUFBRztBQUFBLDhCQUNILE9BQU9YLFNBQVNZO0FBQUFBLDhCQUNoQixVQUFVeUY7QUFBQUEsOEJBQ1YsYUFBWTtBQUFBLDhCQUNaLFdBQVU7QUFBQTtBQUFBLDRCQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFPMkk7QUFBQSw2QkFkN0k7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFnQkE7QUFBQSx3QkFFQSx1QkFBQyxTQUNDO0FBQUE7QUFBQSw0QkFBQztBQUFBO0FBQUEsOEJBQ0MsV0FBVTtBQUFBLDhCQUNWLFNBQVE7QUFBQSw4QkFBb0I7QUFBQTtBQUFBLDRCQUY5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBS0E7QUFBQSwwQkFDQTtBQUFBLDRCQUFDO0FBQUE7QUFBQSw4QkFDQyxNQUFLO0FBQUEsOEJBQ0wsTUFBSztBQUFBLDhCQUNMLElBQUc7QUFBQSw4QkFDSCxPQUFPckcsU0FBU2E7QUFBQUEsOEJBQ2hCLFVBQVV3RjtBQUFBQSw4QkFDVixhQUFZO0FBQUEsOEJBQ1osV0FBVTtBQUFBO0FBQUEsNEJBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQU8ySTtBQUFBLDZCQWQ3STtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQWdCQTtBQUFBLDJCQW5GRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQW9GQTtBQUFBLHlCQXhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXlGQTtBQUFBLHVCQXhQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQTBQQTtBQUFBLGtCQUVBLHVCQUFDLFNBQUksV0FBVSxrREFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQTtBQUFBLHdCQUFDO0FBQUE7QUFBQSwwQkFDQyxPQUFNO0FBQUEsMEJBQ04sV0FBVTtBQUFBO0FBQUEsd0JBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUVxQjtBQUFBLHNCQUVyQix1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLHFDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFRQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBO0FBQUEsd0JBQUM7QUFBQTtBQUFBLDBCQUNDLE1BQUs7QUFBQSwwQkFDTCxTQUFTeEo7QUFBQUEsMEJBQ1QsV0FBVTtBQUFBO0FBQUEsd0JBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUd1RjtBQUFBLHNCQUV2Rix1QkFBQyxVQUFLLFdBQVUseUJBQXdCLGlDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFTQTtBQUFBLHVCQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQW9CQSxLQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXNCQTtBQUFBLGtCQUdBLHVCQUFDLFNBQUksV0FBVSx5QkFDYjtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsV0FBVTtBQUFBLHNCQUE4TDtBQUFBO0FBQUEsb0JBRjFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBT0E7QUFBQTtBQUFBO0FBQUEsY0F2ZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBd2RBO0FBQUEsZUE1ZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE2ZEE7QUFBQSxVQUVBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQztBQUFBLGNBQ0E7QUFBQSxjQUNBLE9BQ0UsdUJBQUMsT0FBRSxXQUFVLHlCQUF3Qix1Q0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUYsV0FBVTtBQUFBLGNBQ1YsTUFBTXdCO0FBQUFBLGNBQ04sU0FBU0U7QUFBQUEsY0FDVCxTQUFTLE1BQU1ELGtCQUFrQixLQUFLO0FBQUEsY0FDdEMsT0FBTztBQUFBLGNBRU5HLDZCQUFtQnNFLFVBQVUsSUFDNUIsdUJBQUMsU0FBSSxXQUFVLDBDQUF5QyxvQ0FBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxJQUVBLHVCQUFDLFNBQUksV0FBVSx1QkFDWnRFLDRCQUFrQnNKLElBQUksQ0FBQ2dELFNBQVM5QyxVQUFVO0FBQ3pDLHVCQUNFO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUVDLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLFNBQUksV0FBVSwrQkFBOEI7QUFBQTtBQUFBLHdCQUM3QjtBQUFBLHdCQUNkLHVCQUFDLFVBQUssV0FBVSxhQUNiOEMsbUJBQVMzSyxZQURaO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSwyQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEsc0JBRUMySyxRQUFRL0csWUFDUCx1QkFBQyxTQUFJLFdBQVUsK0JBQThCO0FBQUE7QUFBQSx3QkFDcEM7QUFBQSx3QkFDUCx1QkFBQyxVQUFLLFdBQVUsYUFDYitHLGtCQUFRL0csVUFBVXFCLGNBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSwyQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEsc0JBRUQwRixRQUFRdEgsVUFDUCx1QkFBQyxTQUFJLFdBQVUsK0JBQThCO0FBQUE7QUFBQSx3QkFDbkM7QUFBQSx3QkFDUix1QkFBQyxVQUFLLFdBQVUsZUFDYnNILG1CQUFTdEgsVUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsMkJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFLQTtBQUFBLHNCQUVGLHVCQUFDLFNBQUksV0FBVSwrQkFBOEI7QUFBQTtBQUFBLHdCQUNuQztBQUFBLHdCQUNSLHVCQUFDLFVBQUssV0FBVSxhQUFZO0FBQUE7QUFBQSwwQkFDeEJzSCxTQUFTMUs7QUFBQUEsNkJBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLDJCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBS0E7QUFBQSxzQkFDQSx1QkFBQyxTQUFJLFdBQVUsK0JBQThCO0FBQUE7QUFBQSx3QkFDN0I7QUFBQSx3QkFDZCx1QkFBQyxVQUFLLFdBQVUsZUFDYjBLLG1CQUFTekssWUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsMkJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFLQTtBQUFBLHNCQUNBLHVCQUFDLFNBQUksV0FBVSwrQkFBOEI7QUFBQTtBQUFBLHdCQUNyQztBQUFBLHdCQUNOLHVCQUFDLFVBQUssV0FBVSxlQUNieUssa0JBQVE3SyxTQUFTaUksYUFEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFFQTtBQUFBLDJCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBS0E7QUFBQTtBQUFBO0FBQUEsa0JBM0NLRjtBQUFBQSxrQkFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQTZDQTtBQUFBLGNBRUosQ0FBQyxLQWxESDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1EQTtBQUFBO0FBQUEsWUF0RUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBd0VBO0FBQUEsYUF4aUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5aUJBLEtBMWlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMmlCQTtBQUFBO0FBQUEsTUFsa0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW1rQkE7QUFBQSxJQUVBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNeEw7QUFBQUEsUUFDTixVQUFVLE1BQU1DLGlCQUFpQixLQUFLO0FBQUEsUUFDdEMsU0FBUyxNQUFNQSxpQkFBaUIsS0FBSztBQUFBLFFBQ3JDLE1BQU0sTUFBTUEsaUJBQWlCLEtBQUs7QUFBQSxRQUNsQyxVQUFVLE1BQU15QyxvQkFBb0JoQixjQUFjO0FBQUEsUUFDbEQsUUFBUSx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBSztBQUFBLFFBQ2IsU0FBU2xDO0FBQUFBLFFBRVQ7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLCtCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsaUlBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLHVCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWU7QUFBQSxjQUFVO0FBQUEsY0FDeEJVLGtCQUFrQnFILFVBQVVxQjtBQUFBQSxpQkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyw0QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQjtBQUFBLGNBQVU7QUFBQSxjQUM3QjFJLGtCQUFrQnFILFVBQVVnSDtBQUFBQSxpQkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyxrQ0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwQjtBQUFBLGNBQVU7QUFBQSxjQUNuQ3JPLGtCQUFrQnFILFVBQVVpSDtBQUFBQSxpQkFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyxxQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFhO0FBQUEsY0FBUztBQUFBLGNBQUV0TyxrQkFBa0J1RCxTQUFTaUk7QUFBQUEsY0FBVztBQUFBLGNBQUk7QUFBQSxjQUN2RHhMLGtCQUFrQjhHO0FBQUFBLGlCQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLDJCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FBVTtBQUFBLGNBQzVCOUcsa0JBQWtCcUgsVUFBVWdILGNBQzNCck8sa0JBQWtCdU8sYUFDaEJ2TyxrQkFBa0JxSCxVQUFVZ0gsY0FDOUJyTyxrQkFBa0J1TyxhQUNoQjtBQUFBLGlCQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sMkJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUI7QUFBQSxjQUFTO0FBQUEsY0FBRXZPLGtCQUFrQndPO0FBQUFBLGlCQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLCtCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVCO0FBQUEsY0FBVTtBQUFBLGNBQ2hDeE8sa0JBQWtCdU87QUFBQUEsaUJBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8seUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUI7QUFBQSxjQUFTO0FBQUEsY0FBRXZPLGtCQUFrQnlPO0FBQUFBLGlCQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLGtDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTBCO0FBQUEsY0FBVTtBQUFBLGNBQ25Dek8sa0JBQWtCME87QUFBQUEsaUJBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sNkJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUI7QUFBQSxjQUFTO0FBQUEsY0FBRTFPLGtCQUFrQjJPO0FBQUFBLGlCQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLDZCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXFCO0FBQUEsY0FBVTtBQUFBLGNBQzlCM08sa0JBQWtCNE87QUFBQUEsaUJBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sMEJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBa0I7QUFBQSxjQUFTO0FBQUEsY0FBRTVPLGtCQUFrQjZPO0FBQUFBLGlCQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLDJCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1CO0FBQUEsY0FBVTtBQUFBLGNBQzVCN08sa0JBQWtCK0wsV0FBV3RMLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxpQkFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTywyQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtQjtBQUFBLGNBQVU7QUFBQSxjQUM1QlQsa0JBQWtCOE8sV0FBV3JPLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxpQkFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyw4QkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzQjtBQUFBLGNBQVU7QUFBQSxjQUMvQlQsa0JBQWtCK0Q7QUFBQUEsaUJBRnJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBLHFDQUFDLFlBQU8sNEJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0I7QUFBQSxjQUFVO0FBQUEsY0FDN0IvRCxrQkFBa0JnRSxhQUFhdkQsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLGlCQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxZQUFPLGlDQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlCO0FBQUEsY0FBVTtBQUFBLGNBQ2xDVCxrQkFBa0JpRTtBQUFBQSxpQkFGckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLHFCQUNiO0FBQUEscUNBQUMsWUFBTyx5Q0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGNBQVU7QUFBQSxjQUMxQ2pFLGtCQUFrQmtFO0FBQUFBLGlCQUZyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsZUF4RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5RUE7QUFBQTtBQUFBO0FBQUEsTUFyRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBc0ZBO0FBQUEsT0ExdUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EydUJBLEtBNXVCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNnVCQyxLQWp2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW12QkE7QUFFSjtBQUFFekYsR0EvekNJRCxnQkFBYztBQUFBdVEsS0FBZHZRO0FBaTBDTixlQUFlQTtBQUFlLElBQUF1UTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTaWRlYmFyIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnQiLCJDaXJjdWxhckxvYWRlciIsIkZhV2hhdHNhcHBTcXVhcmUiLCJOYXZiYXIiLCJTZWxlY3QiLCJEcm9wZG93biIsIk1vZGFsIiwiQW50TW9kYWwiLCJEcmF3ZXIiLCJUb29sdGlwIiwiSW9NZE1vcmUiLCJMaW5rIiwiQmFja2Ryb3BCbHVyTG9hZGVyIiwiRmFSZWNlaXB0IiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIldhcm5pbmdPdXRsaW5lZCIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiQnJlYWRjcnVtYiIsIlBlbmFsdHlQYXltZW50IiwiX3MiLCJ1c2VycyIsInNldFVzZXJzIiwiYWN0dWFsR3JvdXBzIiwic2V0QWN0dWFsR3JvdXBzIiwiVGFibGVQYXltZW50cyIsInNldFRhYmxlUGF5bWVudHMiLCJzZWxlY3RlZFVzZXJJZCIsInNldFNlbGVjdGVkVXNlcklkIiwic2VsZWN0ZWRHcm91cElkIiwic2V0U2VsZWN0ZWRHcm91cElkIiwiZmlsdGVyZWRVc2VycyIsInNldEZpbHRlcmVkVXNlcnMiLCJ2aWV3TG9hZGVyIiwic2V0Vmlld0xvYWRlciIsImZpbHRlcmVkRW5yb2xsbWVudHMiLCJzZXRGaWx0ZXJlZEVucm9sbG1lbnRzIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwiZW5yb2xsbWVudExvYWRpbmciLCJzZXRFbnJvbGxtZW50TG9hZGluZyIsInNob3dNb2RhbFZpZXciLCJzZXRTaG93TW9kYWxWaWV3IiwiY3VycmVudFZpZXdHcm91cCIsInNldEN1cnJlbnRWaWV3R3JvdXAiLCJ3aGF0c2FwcEVuYWJsZSIsInNldFdoYXRzYXBwRW5hYmxlIiwicGF5bWVudE1vZGUiLCJzZXRQYXltZW50TW9kZSIsInRvZGF5IiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInNlYXJjaFRleHQiLCJzZXRTZWFyY2hUZXh0IiwiYm9ycm93ZXJzIiwic2V0Qm9ycm93ZXJzIiwicGlnbWVDdXN0b21lcnMiLCJzZXRQaWdtZUN1c3RvbWVycyIsInBheW1lbnRHcm91cFRpY2tldHMiLCJzZXRQYXltZW50R3JvdXBUaWNrZXRzIiwib3BlbkJhY2tkcm9wTG9hZGVyIiwic2V0T3BlbkJhY2tkcm9wTG9hZGVyIiwiY3VycmVudEdyb3VwSWQiLCJzZXRDdXJyZW50R3JvdXBJZCIsIm9wZW5BbnRERHJhd2VyIiwic2V0T3BlbkFudEREcmF3ZXIiLCJzaG93TG9hZGVyIiwic2V0U2hvd0xvYWRlciIsImxhc3RUaHJlZVBheW1lbnRzIiwic2V0TGFzdFRocmVlUGF5bWVudHMiLCJwZW5hbHR5SW5mb01hcCIsInNldFBlbmFsdHlJbmZvTWFwIiwiZHJvcERvd25JdGVtcyIsInBheW1lbnRPYmplY3QiLCJkcm9wRG93bkl0ZW1MaXN0Iiwia2V5IiwibGFiZWwiLCJfaWQiLCJoYW5kbGVWaWV3TW9kYWxPcGVuIiwiR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsIm5vUmVsb2FkIiwidHlwZSIsImVycm9ycyIsInNldEVycm9ycyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJ1c2VyX2lkIiwicmVjZWlwdF9ubyIsInBheV9kYXRlIiwiYW1vdW50IiwicGF5X3R5cGUiLCJ0cmFuc2FjdGlvbl9pZCIsInBheW1lbnRfZ3JvdXBfdGlja2V0cyIsImFjY291bnRfdHlwZSIsImNoZXF1ZV9udW1iZXIiLCJjaGVxdWVfZGF0ZSIsImNoZXF1ZV9iYW5rX25hbWUiLCJjaGVxdWVfYmFua19icmFuY2giLCJjb2xsZWN0aW9uX3RpbWUiLCJtb2RpZnlQYXltZW50Iiwic2V0TW9kaWZ5UGF5bWVudCIsIm1vZGlmeU1pbk1heFBheW1lbnREYXRlIiwic2V0TW9kaWZ5TWluTWF4UGF5bWVudERhdGUiLCJ5ZXN0ZXJkYXkiLCJzZXREYXRlIiwiZ2V0RGF0ZSIsInVzZXIiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidXNlck9iaiIsIkpTT04iLCJwYXJzZSIsImFkbWluQWNjZXNzUGVybWlzc2lvbnMiLCJhZG1pbl9hY2Nlc3NfcmlnaHRfaWQiLCJhY2Nlc3NfcGVybWlzc2lvbnMiLCJlZGl0X3BheW1lbnQiLCJlZGl0X2xpbWl0ZWRfcGF5bWVudCIsImZldGNoTGFzdFRocmVlVHJhbnNhY3Rpb25zIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInJlc3BvbnNlIiwiZ2V0IiwicGFyYW1zIiwibGltaXQiLCJkYXRhIiwiZXJyb3IiLCJmZXRjaFBlbmFsdHlGb3JTZWxlY3RlZFRpY2tldHMiLCJ1c2VySWQiLCJ0aWNrZXRTZWxlY3Rpb25zIiwiQXJyYXkiLCJpc0FycmF5IiwibGVuZ3RoIiwiY2hpdFNlbGVjdGlvbnMiLCJmaWx0ZXIiLCJzZWwiLCJzdGFydHNXaXRoIiwibmV3UGVuYWx0eU1hcCIsImdyb3VwVG9UaWNrZXRzIiwiXyIsImVudGl0eSIsImdyb3VwSWQiLCJ0aWNrZXQiLCJwdXNoIiwic2VsZWN0aW9uS2V5IiwidGlja2V0cyIsIk9iamVjdCIsImVudHJpZXMiLCJyZXMiLCJncm91cF9pZCIsInBlbmFsdHlEYXRhTGlzdCIsIm1hdGNoIiwiZmluZCIsIml0ZW0iLCJTdHJpbmciLCJ0aWNrZXRfbnVtYmVyIiwic3VtbWFyeSIsInJlZ3VsYXJQZW5hbHR5IiwiTnVtYmVyIiwidG90YWxfcGVuYWx0eSIsInRvdGFsX3ZhY2FudF9jaGl0X3BlbmFsdHkiLCJ2Y1BlbmFsdHkiLCJsYXRlRmVlIiwidG90YWxfbGF0ZV9wYXltZW50X2NoYXJnZXMiLCJ0b3RhbFBlbmFsdHkiLCJkdWVBbW91bnQiLCJ0b3RhbF9kdWUiLCJwZW5hbHR5IiwidG90YWxDaGFyZ2VzIiwiZ3JvdXBOYW1lIiwiZ3JvdXBfbmFtZSIsImVyciIsImNvbnNvbGUiLCJmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMiLCJzdGF0dXMiLCJFcnJvciIsImxvZyIsImZldGNoQWxsQ3VzdG9tZXJzIiwiZmV0Y2hHcm91cHMiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJjdXN0b21lciIsInBhcnNlRmxvYXQiLCJpc05hTiIsInRyaW0iLCJrZXlzIiwiaGFuZGxlQ2hhbmdlIiwibmFtZSIsImNsZWFuZWQiLCJyZXBsYWNlIiwiZG90Q291bnQiLCJwcmV2IiwiaGFuZGxlUGF5bWVudEFudFNlbGVjdCIsInZhbHVlcyIsImZvcm1hdEluZGlhbk51bWJlciIsInRvU3RyaW5nIiwicGFydHMiLCJpbnRlZ2VyUGFydCIsImRlY2ltYWxQYXJ0Iiwic2xpY2UiLCJsYXN0VGhyZWUiLCJvdGhlck51bWJlcnMiLCJmb3JtYXR0ZWRJbnQiLCJjb2x1bW5zIiwiaGVhZGVyIiwiaGFuZGxlQ3VzdG9tZXIiLCJwcmV2Rm9ybURhdGEiLCJwcmV2RGF0YSIsImhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZSIsImhhbmRsZUdyb3VwUGF5bWVudCIsInVybCIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJncm91cCIsImluZGV4IiwiaWQiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJyZWNlaXB0Iiwib2xkX3JlY2VpcHQiLCJvbGRfcmVjZWlwdF9ubyIsImRhdGUiLCJ0cmFuc2FjdGlvbl9kYXRlIiwiY3JlYXRlZEF0IiwiY29sbGVjdGVkX2J5IiwiYWRtaW5fdHlwZSIsImFkbWluX25hbWUiLCJhY3Rpb24iLCJpdGVtcyIsImhhbmRsZVBheW1lbnRNb2RlQ2hhbmdlIiwic2VsZWN0ZWRNb2RlIiwiaGFuZGxlQWNjb3VudFR5cGVDaGFuZ2UiLCJoYW5kbGVTdWJtaXQiLCJpc1ZhbGlkIiwidXNyIiwicG9zdCIsInBheW1lbnRJZCIsInZhbGlkRW5yb2xsbWVudHMiLCJhdWN0aW9uIiwiZW5yb2xsbWVudCIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidW5kZWZpbmVkIiwic29tZSIsImVudHJ5IiwicGlnbWUiLCJwaWdtZV9pZCIsInBheWFibGVfYW1vdW50IiwiYm9ycm93ZXIiLCJsb2FuX2lkIiwibG9hbl9hbW91bnQiLCJzZWxlY3Rpb24iLCJpbmZvIiwiZGlzcGxheU5hbWUiLCJ0b0xvY2FsZVN0cmluZyIsInJlZHVjZSIsInN1bSIsInBheW1lbnQiLCJncm91cF92YWx1ZSIsImdyb3VwX2luc3RhbGwiLCJ3aW5fYW1vdW50IiwiY29tbWlzc2lvbiIsImRpdmlkZW50IiwiZGl2aWRlbnRfaGVhZCIsInBheWFibGUiLCJhdWN0aW9uX2RhdGUiLCJuZXh0X2RhdGUiLCJ1cGRhdGVkQXQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJQYXltZW50V2l0aFBlbmFsdHkuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHBTcXVhcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgeyBTZWxlY3QsIERyb3Bkb3duLCBNb2RhbCBhcyBBbnRNb2RhbCwgRHJhd2VyLCBUb29sdGlwIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBCYWNrZHJvcEJsdXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9CYWNrZHJvcEJsdXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgRmFSZWNlaXB0IH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IG51bWJlclRvSW5kaWFuV29yZHMgfSBmcm9tIFwiLi4vaGVscGVycy9udW1iZXJUb0luZGlhbldvcmRzXCI7XHJcbmltcG9ydCB7IFdhcm5pbmdPdXRsaW5lZCB9IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuY29uc3QgUGVuYWx0eVBheW1lbnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3VzZXJzLCBzZXRVc2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FjdHVhbEdyb3Vwcywgc2V0QWN0dWFsR3JvdXBzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbVGFibGVQYXltZW50cywgc2V0VGFibGVQYXltZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkVXNlcklkLCBzZXRTZWxlY3RlZFVzZXJJZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cElkLCBzZXRTZWxlY3RlZEdyb3VwSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2ZpbHRlcmVkVXNlcnMsIHNldEZpbHRlcmVkVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt2aWV3TG9hZGVyLCBzZXRWaWV3TG9hZGVyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZmlsdGVyZWRFbnJvbGxtZW50cywgc2V0RmlsdGVyZWRFbnJvbGxtZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Vucm9sbG1lbnRMb2FkaW5nLCBzZXRFbnJvbGxtZW50TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFZpZXcsIHNldFNob3dNb2RhbFZpZXddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50Vmlld0dyb3VwLCBzZXRDdXJyZW50Vmlld0dyb3VwXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFt3aGF0c2FwcEVuYWJsZSwgc2V0V2hhdHNhcHBFbmFibGVdID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW3BheW1lbnRNb2RlLCBzZXRQYXltZW50TW9kZV0gPSB1c2VTdGF0ZShcImNhc2hcIik7XHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtib3Jyb3dlcnMsIHNldEJvcnJvd2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3BpZ21lQ3VzdG9tZXJzLCBzZXRQaWdtZUN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3BheW1lbnRHcm91cFRpY2tldHMsIHNldFBheW1lbnRHcm91cFRpY2tldHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtvcGVuQmFja2Ryb3BMb2FkZXIsIHNldE9wZW5CYWNrZHJvcExvYWRlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRHcm91cElkLCBzZXRDdXJyZW50R3JvdXBJZF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbb3BlbkFudEREcmF3ZXIsIHNldE9wZW5BbnRERHJhd2VyXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd0xvYWRlciwgc2V0U2hvd0xvYWRlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2xhc3RUaHJlZVBheW1lbnRzLCBzZXRMYXN0VGhyZWVQYXltZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIGNvbnN0IFtwZW5hbHR5SW5mb01hcCwgc2V0UGVuYWx0eUluZm9NYXBdID0gdXNlU3RhdGUoe30pO1xyXG5cclxuICBjb25zdCBkcm9wRG93bkl0ZW1zID0gKHBheW1lbnRPYmplY3QpID0+IHtcclxuICAgIGNvbnN0IGRyb3BEb3duSXRlbUxpc3QgPSBbXHJcbiAgICAgIHtcclxuICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICA8TGluayB0bz17YC9wcmludC8ke3BheW1lbnRPYmplY3Q/Ll9pZH1gfSBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC02MDAgXCI+XHJcbiAgICAgICAgICAgIFByaW50XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgKSxcclxuICAgICAgfSxcclxuXHJcbiAgICAgIHtcclxuICAgICAgICBrZXk6IFwiM1wiLFxyXG4gICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIFwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVZpZXdNb2RhbE9wZW4ocGF5bWVudE9iamVjdD8uX2lkKX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgVmlld1xyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSxcclxuICAgICAgfSxcclxuICAgIF07XHJcblxyXG4gICAgcmV0dXJuIGRyb3BEb3duSXRlbUxpc3Q7XHJcbiAgfTtcclxuICBjb25zdCBHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbiAgfTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIG5vUmVsb2FkOiBmYWxzZSxcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgdXNlcl9pZDogXCJcIixcclxuICAgIHJlY2VpcHRfbm86IFwiXCIsXHJcbiAgICBwYXlfZGF0ZTogdG9kYXksXHJcbiAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogW10sXHJcbiAgICBhY2NvdW50X3R5cGU6IFwiXCIsXHJcbiAgICBjaGVxdWVfbnVtYmVyOiBcIlwiLFxyXG4gICAgY2hlcXVlX2RhdGU6IFwiXCIsXHJcbiAgICBjaGVxdWVfYmFua19uYW1lOiBcIlwiLFxyXG4gICAgY2hlcXVlX2JhbmtfYnJhbmNoOiBcIlwiLFxyXG4gICAgY29sbGVjdGlvbl90aW1lOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbbW9kaWZ5UGF5bWVudCwgc2V0TW9kaWZ5UGF5bWVudF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW21vZGlmeU1pbk1heFBheW1lbnREYXRlLCBzZXRNb2RpZnlNaW5NYXhQYXltZW50RGF0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgeWVzdGVyZGF5ID0gbmV3IERhdGUobmV3IERhdGUoKS5zZXREYXRlKG5ldyBEYXRlKCkuZ2V0RGF0ZSgpIC0gMSkpXHJcbiAgICAudG9JU09TdHJpbmcoKVxyXG4gICAgLnNwbGl0KFwiVFwiKVswXTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHVzZXIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBjb25zdCB1c2VyT2JqID0gSlNPTi5wYXJzZSh1c2VyKTtcclxuXHJcbiAgICBpZiAodXNlck9iaikge1xyXG4gICAgICBjb25zdCBhZG1pbkFjY2Vzc1Blcm1pc3Npb25zID1cclxuICAgICAgICB1c2VyT2JqLmFkbWluX2FjY2Vzc19yaWdodF9pZD8uYWNjZXNzX3Blcm1pc3Npb25zO1xyXG5cclxuICAgICAgaWYgKGFkbWluQWNjZXNzUGVybWlzc2lvbnM/LmVkaXRfcGF5bWVudCA9PT0gXCJ0cnVlXCIpIHtcclxuICAgICAgICBzZXRNb2RpZnlQYXltZW50KHRydWUpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoYWRtaW5BY2Nlc3NQZXJtaXNzaW9ucz8uZWRpdF9saW1pdGVkX3BheW1lbnQgPT09IFwidHJ1ZVwiKSB7XHJcbiAgICAgICAgc2V0TW9kaWZ5UGF5bWVudCh0cnVlKTtcclxuICAgICAgICBzZXRNb2RpZnlNaW5NYXhQYXltZW50RGF0ZSh0cnVlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hMYXN0VGhyZWVUcmFuc2FjdGlvbnMgPSBhc3luYyAoZXZlbnQpID0+IHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBzZXRPcGVuQW50RERyYXdlcih0cnVlKTtcclxuICAgIGlmIChmb3JtRGF0YS51c2VyX2lkICYmIGZvcm1EYXRhLnBheW1lbnRfZ3JvdXBfdGlja2V0cykge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldFNob3dMb2FkZXIodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwicGF5bWVudC9nZXQtbGFzdC1uLXRyYW5zYWN0aW9uXCIsIHtcclxuICAgICAgICAgIHBhcmFtczoge1xyXG4gICAgICAgICAgICB1c2VyX2lkOiBmb3JtRGF0YS51c2VyX2lkLFxyXG4gICAgICAgICAgICBwYXltZW50X2dyb3VwX3RpY2tldHM6IHBheW1lbnRHcm91cFRpY2tldHMsXHJcbiAgICAgICAgICAgIGxpbWl0OiAzLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICB9KTtcclxuICAgICAgICBpZiAocmVzcG9uc2U/LmRhdGEpIHtcclxuICAgICAgICAgIHNldExhc3RUaHJlZVBheW1lbnRzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRMYXN0VGhyZWVQYXltZW50cyhbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHNldExhc3RUaHJlZVBheW1lbnRzKFtdKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRTaG93TG9hZGVyKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoUGVuYWx0eUZvclNlbGVjdGVkVGlja2V0cyA9IGFzeW5jICh1c2VySWQsIHRpY2tldFNlbGVjdGlvbnMpID0+IHtcclxuICAgIGlmICghdXNlcklkIHx8ICFBcnJheS5pc0FycmF5KHRpY2tldFNlbGVjdGlvbnMpIHx8IHRpY2tldFNlbGVjdGlvbnMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIHNldFBlbmFsdHlJbmZvTWFwKHt9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIE9ubHkgcHJvY2VzcyBjaGl0LXR5cGUgc2VsZWN0aW9uc1xyXG4gICAgY29uc3QgY2hpdFNlbGVjdGlvbnMgPSB0aWNrZXRTZWxlY3Rpb25zLmZpbHRlcigoc2VsKSA9PlxyXG4gICAgICB0eXBlb2Ygc2VsID09PSBcInN0cmluZ1wiICYmIHNlbC5zdGFydHNXaXRoKFwiY2hpdC1cIilcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgbmV3UGVuYWx0eU1hcCA9IHt9O1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIC8vIEdyb3VwIGJ5IGdyb3VwX2lkIHRvIG1pbmltaXplIEFQSSBjYWxsc1xyXG4gICAgICBjb25zdCBncm91cFRvVGlja2V0cyA9IHt9O1xyXG4gICAgICBmb3IgKGNvbnN0IHNlbCBvZiBjaGl0U2VsZWN0aW9ucykge1xyXG4gICAgICAgIGNvbnN0IFtfLCBlbnRpdHldID0gc2VsLnNwbGl0KFwiLVwiKTtcclxuICAgICAgICBjb25zdCBbZ3JvdXBJZCwgdGlja2V0XSA9IGVudGl0eS5zcGxpdChcInxcIik7XHJcbiAgICAgICAgaWYgKCFncm91cFRvVGlja2V0c1tncm91cElkXSkgZ3JvdXBUb1RpY2tldHNbZ3JvdXBJZF0gPSBbXTtcclxuICAgICAgICBncm91cFRvVGlja2V0c1tncm91cElkXS5wdXNoKHsgc2VsZWN0aW9uS2V5OiBzZWwsIHRpY2tldCB9KTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gRmV0Y2ggcGVuYWx0eSByZXBvcnQgcGVyIGdyb3VwXHJcbiAgICAgIGZvciAoY29uc3QgW2dyb3VwSWQsIHRpY2tldHNdIG9mIE9iamVjdC5lbnRyaWVzKGdyb3VwVG9UaWNrZXRzKSkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvcGVuYWx0eS9nZXQtcGVuYWx0eS1yZXBvcnRcIiwge1xyXG4gICAgICAgICAgcGFyYW1zOiB7IHVzZXJfaWQ6IHVzZXJJZCwgZ3JvdXBfaWQ6IGdyb3VwSWQgfSxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgcGVuYWx0eURhdGFMaXN0ID0gcmVzLmRhdGE/LmRhdGEgfHwgW107XHJcblxyXG4gICAgICAgIGZvciAoY29uc3QgeyBzZWxlY3Rpb25LZXksIHRpY2tldCB9IG9mIHRpY2tldHMpIHtcclxuICAgICAgICAgIGNvbnN0IG1hdGNoID0gcGVuYWx0eURhdGFMaXN0LmZpbmQoXHJcbiAgICAgICAgICAgIChpdGVtKSA9PlxyXG4gICAgICAgICAgICAgIFN0cmluZyhpdGVtLnVzZXJfaWQpID09PSBTdHJpbmcodXNlcklkKSAmJlxyXG4gICAgICAgICAgICAgIFN0cmluZyhpdGVtLmdyb3VwX2lkKSA9PT0gU3RyaW5nKGdyb3VwSWQpICYmXHJcbiAgICAgICAgICAgICAgU3RyaW5nKGl0ZW0udGlja2V0X251bWJlcikgPT09IFN0cmluZyh0aWNrZXQpXHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgIGlmIChtYXRjaD8uc3VtbWFyeSkge1xyXG4gICAgICAgICAgICBjb25zdCBzdW1tYXJ5ID0gbWF0Y2guc3VtbWFyeTtcclxuICAgICAgICAgICAgY29uc3QgcmVndWxhclBlbmFsdHkgPSBOdW1iZXIoc3VtbWFyeS50b3RhbF9wZW5hbHR5IHx8IDApIC0gTnVtYmVyKHN1bW1hcnkudG90YWxfdmFjYW50X2NoaXRfcGVuYWx0eSB8fCAwKTtcclxuICAgICAgICAgICAgY29uc3QgdmNQZW5hbHR5ID0gTnVtYmVyKHN1bW1hcnkudG90YWxfdmFjYW50X2NoaXRfcGVuYWx0eSB8fCAwKTtcclxuICAgICAgICAgICAgY29uc3QgbGF0ZUZlZSA9IE51bWJlcihzdW1tYXJ5LnRvdGFsX2xhdGVfcGF5bWVudF9jaGFyZ2VzIHx8IDApO1xyXG4gICAgICAgICAgICBjb25zdCB0b3RhbFBlbmFsdHkgPSByZWd1bGFyUGVuYWx0eSArIHZjUGVuYWx0eTtcclxuXHJcbiAgICAgICAgICAgIG5ld1BlbmFsdHlNYXBbc2VsZWN0aW9uS2V5XSA9IHtcclxuICAgICAgICAgICAgICBkdWVBbW91bnQ6IE51bWJlcihzdW1tYXJ5LnRvdGFsX2R1ZSkgfHwgMCxcclxuICAgICAgICAgICAgICByZWd1bGFyUGVuYWx0eSxcclxuICAgICAgICAgICAgICB2Y1BlbmFsdHksXHJcbiAgICAgICAgICAgICAgbGF0ZUZlZSxcclxuICAgICAgICAgICAgICBwZW5hbHR5OiB0b3RhbFBlbmFsdHksIC8vIHJlZ3VsYXIgKyBWQ1xyXG4gICAgICAgICAgICAgIHRvdGFsQ2hhcmdlczogdG90YWxQZW5hbHR5ICsgbGF0ZUZlZSxcclxuICAgICAgICAgICAgICBncm91cE5hbWU6IG1hdGNoLmdyb3VwX25hbWUgfHwgXCJVbmtub3duIEdyb3VwXCIsXHJcbiAgICAgICAgICAgICAgdGlja2V0LFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgbmV3UGVuYWx0eU1hcFtzZWxlY3Rpb25LZXldID0gbnVsbDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHNldFBlbmFsdHlJbmZvTWFwKG5ld1BlbmFsdHlNYXApO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcGVuYWx0aWVzIGZvciBzZWxlY3RlZCB0aWNrZXRzOlwiLCBlcnIpO1xyXG4gICAgICBzZXRQZW5hbHR5SW5mb01hcCh7fSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZXRCb3Jyb3dlcnMoW10pO1xyXG4gICAgY29uc3QgZmV0Y2hDdXN0b21lckxvYW5EZXRhaWxzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICAgIGAvbG9hbnMvZ2V0LWJvcnJvd2VyLWJ5LXVzZXItaWQvJHtzZWxlY3RlZFVzZXJJZH1gXHJcbiAgICAgICAgKTtcclxuICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID49IDQwMClcclxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcImZldGNoaW5nIGxvYW4gYm9ycm93ZXJzIEZhaWxlZFwiKTtcclxuICAgICAgICBzZXRCb3Jyb3dlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIHNldEJvcnJvd2VycyhbXSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJFcnJvciBPY2N1cnJlZFwiKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMoKTtcclxuICB9LCBbc2VsZWN0ZWRVc2VySWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNldFBpZ21lQ3VzdG9tZXJzKFtdKTtcclxuICAgIGNvbnN0IGZldGNoQ3VzdG9tZXJMb2FuRGV0YWlscyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICBgL3BpZ21lL2dldC1waWdtZS1jdXN0b21lci1ieS11c2VyLWlkLyR7c2VsZWN0ZWRVc2VySWR9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA+PSA0MDApXHJcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJmZXRjaGluZyBwaWdtZSBjdXN0b21lcnMgRmFpbGVkXCIpO1xyXG4gICAgICAgIHNldFBpZ21lQ3VzdG9tZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBzZXRQaWdtZUN1c3RvbWVycyhbXSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXHJcbiAgICAgICAgICBcIkVycm9yIE9jY3VycmVkIHdoaWxlIGZldGNoaW5nIHBpZ21lIGN1c3RvbWVycyxcIixcclxuICAgICAgICAgIGVyci5tZXNzYWdlXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBmZXRjaEN1c3RvbWVyTG9hbkRldGFpbHMoKTtcclxuICB9LCBbc2VsZWN0ZWRVc2VySWRdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWxsQ3VzdG9tZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcInVzZXIvdmVyaWZpZWRcIik7XHJcbiAgICAgICAgc2V0VXNlcnMocmVzcG9uc2U/LmRhdGE/LmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIHNldFVzZXJzKFtdKTtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBbGxDdXN0b21lcnMoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZ3JvdXAvZ2V0LWdyb3VwLWFkbWluXCIpO1xyXG4gICAgICAgIHNldEFjdHVhbEdyb3VwcyhyZXNwb25zZS5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBzZXRBY3R1YWxHcm91cHMoW10pO1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcblxyXG4gICAgaWYgKCFzZWxlY3RlZFVzZXJJZCkge1xyXG4gICAgICBuZXdFcnJvcnMuY3VzdG9tZXIgPSBcIlBsZWFzZSBzZWxlY3QgYSBjdXN0b21lclwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZm9ybURhdGEucGF5bWVudF9ncm91cF90aWNrZXRzKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHMgPSBcIlBsZWFzZSBzZWxlY3QgYSBncm91cCBhbmQgdGlja2V0XCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFmb3JtRGF0YS5wYXlfZGF0ZSkge1xyXG4gICAgICBuZXdFcnJvcnMucGF5X2RhdGUgPSBcIlBheW1lbnQgZGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGFtb3VudCA9IHBhcnNlRmxvYXQoZm9ybURhdGEuYW1vdW50KTtcclxuICAgIGlmIChpc05hTihhbW91bnQpIHx8IGFtb3VudCA8PSAwKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hbW91bnQgPSBcIlBsZWFzZSBlbnRlciBhIHZhbGlkIHBvc2l0aXZlIGFtb3VudFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChwYXltZW50TW9kZSA9PT0gXCJvbmxpbmVcIiAmJiAhZm9ybURhdGEudHJhbnNhY3Rpb25faWQ/LnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMudHJhbnNhY3Rpb25faWQgPVxyXG4gICAgICAgIFwiVHJhbnNhY3Rpb24gSUQgaXMgcmVxdWlyZWQgZm9yIG9ubGluZSBwYXltZW50c1wiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChwYXltZW50TW9kZSA9PT0gXCJjaGVxdWVcIiAmJiAhZm9ybURhdGEuY2hlcXVlX2RhdGU/LnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMuY2hlcXVlX2RhdGUgPSBcIkNoZXF1ZSBEYXRlIGlzIHJlcXVpcmVkIGZvciBjaGVxdWUgcGF5bWVudHNcIjtcclxuICAgIH1cclxuICAgIGlmIChwYXltZW50TW9kZSA9PT0gXCJjaGVxdWVcIiAmJiAhZm9ybURhdGEuY2hlcXVlX251bWJlcj8udHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5jaGVxdWVfbnVtYmVyID0gXCJDaGVxdWUgTnVtYmVyIGlzIHJlcXVpcmVkIGZvciBjaGVxdWUgcGF5bWVudHNcIjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcblxyXG4gICAgaWYgKG5hbWUgPT09IFwiYW1vdW50XCIpIHtcclxuICAgICAgLy8gQWxsb3cgZGlnaXRzICYgT05MWSBvbmUgZG90XHJcbiAgICAgIGxldCBjbGVhbmVkID0gdmFsdWUucmVwbGFjZSgvW14wLTkuXS9nLCBcIlwiKTtcclxuXHJcbiAgICAgIGNvbnN0IGRvdENvdW50ID0gKGNsZWFuZWQubWF0Y2goL1xcLi9nKSB8fCBbXSkubGVuZ3RoO1xyXG4gICAgICBpZiAoZG90Q291bnQgPiAxKSByZXR1cm47XHJcblxyXG4gICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIFtuYW1lXTogY2xlYW5lZCxcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIE90aGVyIGZpZWxkc1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgIC4uLnByZXYsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcblxyXG4gIGNvbnN0IGhhbmRsZVBheW1lbnRBbnRTZWxlY3QgPSBhc3luYyAodmFsdWVzKSA9PiB7XHJcbiAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKHZhbHVlcyk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXYpID0+ICh7IC4uLnByZXYsIHBheW1lbnRfZ3JvdXBfdGlja2V0czogXCJcIiB9KSk7XHJcblxyXG4gICAgaWYgKHNlbGVjdGVkVXNlcklkKSB7XHJcbiAgICAgIGF3YWl0IGZldGNoUGVuYWx0eUZvclNlbGVjdGVkVGlja2V0cyhzZWxlY3RlZFVzZXJJZCwgdmFsdWVzKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldFBlbmFsdHlJbmZvTWFwKHt9KTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuXHJcblxyXG5cclxuICBjb25zdCBmb3JtYXRJbmRpYW5OdW1iZXIgPSAodmFsdWUpID0+IHtcclxuICAgIGlmICghdmFsdWUpIHJldHVybiBcIlwiO1xyXG5cclxuICAgIHZhbHVlID0gdmFsdWUudG9TdHJpbmcoKS5yZXBsYWNlKC9bXjAtOS5dL2csIFwiXCIpO1xyXG5cclxuICAgIGNvbnN0IHBhcnRzID0gdmFsdWUuc3BsaXQoXCIuXCIpO1xyXG4gICAgY29uc3QgaW50ZWdlclBhcnQgPSBwYXJ0c1swXTtcclxuICAgIGNvbnN0IGRlY2ltYWxQYXJ0ID0gcGFydHNbMV0gPyBwYXJ0c1sxXS5zbGljZSgwLCAyKSA6IFwiXCI7XHJcblxyXG4gICAgbGV0IGxhc3RUaHJlZSA9IGludGVnZXJQYXJ0LnNsaWNlKC0zKTtcclxuICAgIGxldCBvdGhlck51bWJlcnMgPSBpbnRlZ2VyUGFydC5zbGljZSgwLCAtMyk7XHJcblxyXG4gICAgbGV0IGZvcm1hdHRlZEludCA9IG90aGVyTnVtYmVyc1xyXG4gICAgICA/IG90aGVyTnVtYmVycy5yZXBsYWNlKC9cXEIoPz0oXFxkezJ9KSsoPyFcXGQpKS9nLCBcIixcIikgKyBcIixcIiArIGxhc3RUaHJlZVxyXG4gICAgICA6IGxhc3RUaHJlZTtcclxuXHJcbiAgICByZXR1cm4gZGVjaW1hbFBhcnQgPyBgJHtmb3JtYXR0ZWRJbnR9LiR7ZGVjaW1hbFBhcnR9YCA6IGZvcm1hdHRlZEludDtcclxuICB9O1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJkYXRlXCIsIGhlYWRlcjogXCJQYWlkIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNhY3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiVHJhbnNhY3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgUGhvbmUgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXQgTnVtYmVyXCIgfSxcclxuICAgIHsga2V5OiBcIm9sZF9yZWNlaXB0XCIsIGhlYWRlcjogXCJPbGQgUmVjZWlwdFwiIH0sXHJcbiAgICB7IGtleTogXCJyZWNlaXB0XCIsIGhlYWRlcjogXCJSZWNlaXB0XCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInBheV90eXBlXCIsIGhlYWRlcjogXCJQYXltZW50IFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29sbGVjdGlvbl90aW1lXCIsIGhlYWRlcjogXCJDb2xsZWN0aW9uIFRpbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiY29sbGVjdGVkX2J5XCIsIGhlYWRlcjogXCJDb2xsZWN0ZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUN1c3RvbWVyID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICBzZXRGaWx0ZXJlZEVucm9sbG1lbnRzKFtdKTtcclxuICAgIHNldFNlbGVjdGVkVXNlcklkKHVzZXJJZCk7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkZvcm1EYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2Rm9ybURhdGEsXHJcbiAgICAgIHVzZXJfaWQ6IHVzZXJJZCxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7IC4uLnByZXZEYXRhLCBjdXN0b21lcjogXCJcIiB9KSk7XHJcbiAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKFtdKTtcclxuICAgIHNldFBlbmFsdHlJbmZvTWFwKHt9KTtcclxuICAgIGhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZSh1c2VySWQpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwUGF5bWVudCA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICBsZXQgdXJsID0gYC9wYXltZW50L2dldC1wYXltZW50cy1ieS1kYXRlcz9mcm9tX2RhdGU9JHt0b2RheX0mdG9fZGF0ZT0ke3RvZGF5fWA7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldCh1cmwpO1xyXG5cclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcCgoZ3JvdXAsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lKSByZXR1cm4ge307XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgdGlja2V0OiBncm91cC50aWNrZXQsXHJcbiAgICAgICAgICAgICAgcmVjZWlwdDogZ3JvdXAucmVjZWlwdF9ubyxcclxuICAgICAgICAgICAgICBvbGRfcmVjZWlwdDogZ3JvdXAub2xkX3JlY2VpcHRfbm8sXHJcbiAgICAgICAgICAgICAgYW1vdW50OiBncm91cC5hbW91bnQsXHJcbiAgICAgICAgICAgICAgcGF5X3R5cGU6IGdyb3VwPy5wYXlfdHlwZSxcclxuICAgICAgICAgICAgICBkYXRlOiBncm91cD8ucGF5X2RhdGUuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgICAgICAgIHRyYW5zYWN0aW9uX2RhdGU6IGdyb3VwPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXSxcclxuICAgICAgICAgICAgICBjb2xsZWN0ZWRfYnk6XHJcbiAgICAgICAgICAgICAgICBncm91cD8uY29sbGVjdGVkX2J5Py5uYW1lIHx8XHJcbiAgICAgICAgICAgICAgICBncm91cD8uYWRtaW5fdHlwZT8uYWRtaW5fbmFtZSB8fFxyXG4gICAgICAgICAgICAgICAgXCJTdXBlciBBZG1pblwiLFxyXG4gICAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBkcm9wRG93bkl0ZW1zKGdyb3VwKSxcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRUYWJsZVBheW1lbnRzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBzZXRUYWJsZVBheW1lbnRzKFtdKTtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGF5bWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBheW1lbnRNb2RlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHNlbGVjdGVkTW9kZSA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgc2V0UGF5bWVudE1vZGUoc2VsZWN0ZWRNb2RlKTtcclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIHBheV90eXBlOiBzZWxlY3RlZE1vZGUsXHJcblxyXG4gICAgICB0cmFuc2FjdGlvbl9pZDpcclxuICAgICAgICBzZWxlY3RlZE1vZGUgPT09IFwib25saW5lXCIgfHwgc2VsZWN0ZWRNb2RlID09PSBcIm9ubGluZS91cGlcIlxyXG4gICAgICAgICAgPyBwcmV2RGF0YS50cmFuc2FjdGlvbl9pZFxyXG4gICAgICAgICAgOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFjY291bnRUeXBlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHNlbGVjdGVkTW9kZSA9IGUudGFyZ2V0LnZhbHVlO1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgYWNjb3VudF90eXBlOiBzZWxlY3RlZE1vZGUsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0ZUZvcm0oKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGlmIChpc1ZhbGlkKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcblxyXG4gICAgICAgIGNvbnN0IHVzciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgICAgICBsZXQgYWRtaW5fdHlwZSA9IG51bGw7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGlmICh1c3IpIHtcclxuICAgICAgICAgICAgYWRtaW5fdHlwZSA9IEpTT04ucGFyc2UodXNyKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHBhcnNlIHVzZXIgZnJvbSBsb2NhbFN0b3JhZ2U6XCIsIGUpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9ybURhdGEucGF5bWVudF9ncm91cF90aWNrZXRzID0gcGF5bWVudEdyb3VwVGlja2V0cztcclxuICAgICAgICBmb3JtRGF0YS5hZG1pbl90eXBlID0gYWRtaW5fdHlwZT8uX2lkO1xyXG4gICAgICAgIHNldE9wZW5CYWNrZHJvcExvYWRlcih0cnVlKTtcclxuICAgICAgICBhd2FpdCBhcGkucG9zdChcIi9wYXltZW50L2FkZC1wYXltZW50cy1hdXRvLXBlbmFsdHlcIiwgZm9ybURhdGEpO1xyXG5cclxuICAgICAgICBzZXRTZWxlY3RlZFVzZXJJZChcIlwiKTtcclxuICAgICAgICBzZXRQYXltZW50R3JvdXBUaWNrZXRzKFtdKTtcclxuXHJcbiAgICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgICAgdXNlcl9pZDogXCJcIixcclxuICAgICAgICAgIHJlY2VpcHRfbm86IFwiXCIsXHJcbiAgICAgICAgICBwYXlfZGF0ZTogdG9kYXksXHJcbiAgICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgICBwYXlfdHlwZTogXCJjYXNoXCIsXHJcbiAgICAgICAgICB0cmFuc2FjdGlvbl9pZDogXCJcIixcclxuICAgICAgICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogW10sXHJcbiAgICAgICAgICBhY2NvdW50X3R5cGU6IFwiXCIsXHJcbiAgICAgICAgICBjaGVxdWVfbnVtYmVyOiBcIlwiLFxyXG4gICAgICAgICAgY2hlcXVlX2RhdGU6IFwiXCIsXHJcbiAgICAgICAgICBjaGVxdWVfYmFua19uYW1lOiBcIlwiLFxyXG4gICAgICAgICAgY2hlcXVlX2JhbmtfYnJhbmNoOiBcIlwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBub1JlbG9hZDogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGF5bWVudCBBZGRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRTZWxlY3RlZFVzZXJJZChcIlwiKTtcclxuICAgICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICAgICAgcmVjZWlwdF9ubzogXCJcIixcclxuICAgICAgICBwYXlfZGF0ZTogXCJcIixcclxuICAgICAgICBhbW91bnQ6IFwiXCIsXHJcbiAgICAgICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgICAgIHRyYW5zYWN0aW9uX2lkOiBcIlwiLFxyXG4gICAgICAgIHBheW1lbnRfZ3JvdXBfdGlja2V0czogW10sXHJcbiAgICAgICAgYWNjb3VudF90eXBlOiBcIlwiLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbm9SZWxvYWQ6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogYEVycm9yIHN1Ym1pdHRpbmcgcGF5bWVudCBkYXRhYCxcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHN1Ym1pdHRpbmcgcGF5bWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRPcGVuQmFja2Ryb3BMb2FkZXIoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVZpZXdNb2RhbE9wZW4gPSBhc3luYyAocGF5bWVudElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG4gICAgICBzZXRTaG93TW9kYWxWaWV3KHRydWUpO1xyXG4gICAgICBzZXRDdXJyZW50R3JvdXBJZChwYXltZW50SWQpO1xyXG4gICAgICBzZXRWaWV3TG9hZGVyKHRydWUpO1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9wYXltZW50L2dldC1wYXltZW50LWJ5LWlkLyR7cGF5bWVudElkfWApO1xyXG4gICAgICBzZXRDdXJyZW50Vmlld0dyb3VwKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHZpZXdpbmcgUGF5bWVudDpcIiwgZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIHNldFZpZXdMb2FkZXIoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZSA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXHJcbiAgICAgICAgICBgL2Vucm9sbC9nZXQtdXNlci10aWNrZXRzLXJlcG9ydC8ke2dyb3VwSWR9YFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBjb25zdCB2YWxpZEVucm9sbG1lbnRzID0gcmVzcG9uc2UuZGF0YS5maWx0ZXIoXHJcbiAgICAgICAgICAgIChhdWN0aW9uKSA9PiBhdWN0aW9uLmVucm9sbG1lbnQgJiYgYXVjdGlvbi5lbnJvbGxtZW50Lmdyb3VwXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRFbnJvbGxtZW50cyh2YWxpZEVucm9sbG1lbnRzKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbG1lbnQgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldEZpbHRlcmVkRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHtvcGVuQmFja2Ryb3BMb2FkZXIgPyAoXHJcbiAgICAgICAgPEJhY2tkcm9wQmx1ckxvYWRlciB0aXRsZT17XCJwYXltZW50IERhdGEgcHJvY2Vzc2luZy4uLi5cIn0gLz5cclxuICAgICAgKSA6IChcclxuICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLWdyYXktNTAgb3ZlcmZsb3cteC1oaWRkZW4gbXQtMjBcIj5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBcIj5cclxuICAgICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17R2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03IGZsZXgtMSBtaW4tdy0wICAgb3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJyZWFkY3J1bWIgLz5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPlBheW1lbnRzPC9oMT5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgIG1iLThcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMTBcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlNlYXJjaCBvciBTZWxlY3QgR3JvdXA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHcm91cFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsICBoLTE0IG1heC13LW1kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwSWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdyb3VwUGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YWN0dWFsR3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWwodHJ1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctdmlvbGV0LTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy12aW9sZXQtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKyBBZGQgUGF5bWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAge1RhYmxlUGF5bWVudHMgJiYgVGFibGVQYXltZW50cy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT17VGFibGVQYXltZW50cy5maWx0ZXIoKGl0ZW0pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBPYmplY3QudmFsdWVzKGl0ZW0pLnNvbWUoKHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTdHJpbmcodmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoc2VhcmNoVGV4dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJQYXltZW50c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXCJHcm91cCBOYW1lXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyVmFsdWVzPXtbXCJUb2RheSdzXCJdfVxyXG4gICAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BQYXltZW50cy5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMCB0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGE9XCJQYXltZW50cyBEYXRhXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZhaWx1cmU9e1RhYmxlUGF5bWVudHMubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxEcmF3ZXJcclxuICAgICAgICAgICAgICBvcGVuPXtzaG93TW9kYWx9XHJcbiAgICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRVc2VySWQoXCJcIik7XHJcbiAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgICAgICAgIHNldFBheW1lbnRHcm91cFRpY2tldHMoW10pO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgd2lkdGg9e1wiNTAlXCJ9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicGF5bWVudC1kcmF3ZXJcIlxyXG4gICAgICAgICAgICAgIGV4dHJhPXtcclxuICAgICAgICAgICAgICAgIDxUb29sdGlwIHRpdGxlPVwiTGFzdCAzIFRyYW5zYWN0aW9uc1wiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17ZmV0Y2hMYXN0VGhyZWVUcmFuc2FjdGlvbnN9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9XCJMYXN0IFRocmVlIHRyYW5zYWN0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1ncmVlbi01MDAgaG92ZXI6YmctZ3JlZW4tNjAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQteGwgc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBmb250LW1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8RmFSZWNlaXB0IGNsYXNzTmFtZT1cInRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkxhc3QgMyBUcmFuc2FjdGlvbnM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyIG14LWF1dG8gcHgtNCBweS02IG1heC13LTd4bFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGxnOmZsZXgtcm93IGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTYgdGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDAgYm9yZGVyLWIgcGItM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQWRkIFBheW1lbnRcclxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTZcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH1cclxuICAgICAgICAgICAgICAgICAgICAgIG5vVmFsaWRhdGVcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tZ3JvdXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBoLTEyYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFVzZXJJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUN1c3RvbWVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Ake2dyb3VwLmZ1bGxfbmFtZX0gfCAke2dyb3VwLnBob25lX251bWJlcn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jdXN0b21lciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZvcm0tZ3JvdXAgJHtlbnJvbGxtZW50TG9hZGluZyA/IFwiY3Vyc29yLXByb2dyZXNzXCIgOiBcIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgR3JvdXAgJiBUaWNrZXQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtlbnJvbGxtZW50TG9hZGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBtb2RlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgR3JvdXAgfCBUaWNrZXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXltZW50QW50U2VsZWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e2Vucm9sbG1lbnRMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50R3JvdXBUaWNrZXRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZEVucm9sbG1lbnRzLm1hcCgoZW50cnksIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBncm91cE5hbWUgPVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbnRyeT8uZW5yb2xsbWVudD8uZ3JvdXA/Lmdyb3VwX25hbWUgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJVbm5hbWVkIEdyb3VwXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBncm91cElkID1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnk/LmVucm9sbG1lbnQ/Lmdyb3VwPy5faWQgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYG1pc3NpbmctJHtpbmRleH1gO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdGlja2V0ID1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW50cnk/LmVucm9sbG1lbnQ/LnRpY2tldHMgfHwgXCJVbmtub3duXCI7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2BjaGl0LSR7Z3JvdXBJZH18JHt0aWNrZXR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YGNoaXQtJHtncm91cElkfXwke3RpY2tldH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwTmFtZX0gfCB7dGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtwaWdtZUN1c3RvbWVycz8ubWFwKChwaWdtZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9e2BwaWdtZS0ke3BpZ21lLl9pZH1gfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YCR7cGlnbWUucGlnbWVfaWR9IHwg4oK5ICR7cGlnbWUucGF5YWJsZV9hbW91bnR9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Ym9ycm93ZXJzPy5tYXAoKGJvcnJvd2VyKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT17YGxvYW4tJHtib3Jyb3dlci5faWR9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Bsb2FuLSR7Ym9ycm93ZXIubG9hbl9pZH0gfCDigrkgJHtib3Jyb3dlci5sb2FuX2Ftb3VudH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXltZW50X2dyb3VwX3RpY2tldHMgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5bWVudF9ncm91cF90aWNrZXRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwYXltZW50R3JvdXBUaWNrZXRzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHNoYWRvdy1tZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxXYXJuaW5nT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTYwMFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlbmFsdHkgSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudEdyb3VwVGlja2V0cy5tYXAoKHNlbGVjdGlvbiwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaW5mbyA9IHBlbmFsdHlJbmZvTWFwW3NlbGVjdGlvbl07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghaW5mbykgcmV0dXJuIG51bGw7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBbXywgZW50aXR5XSA9IHNlbGVjdGlvbi5zcGxpdChcIi1cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IFtncm91cElkLCB0aWNrZXRdID0gZW50aXR5LnNwbGl0KFwifFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZGlzcGxheU5hbWUgPSBgJHtpbmZvLmdyb3VwTmFtZX0gfCAke3RpY2tldH1gO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17c2VsZWN0aW9ufSBjbGFzc05hbWU9e2luZGV4IDwgcGF5bWVudEdyb3VwVGlja2V0cy5sZW5ndGggLSAxID8gJ21iLTYgcGItNiBib3JkZXItYiBib3JkZXItZ3JheS0xMDAnIDogJ21iLTYnfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Rpc3BsYXlOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTEgYmctZ3JheS0xMDAgdGV4dC1ncmF5LTcwMCByb3VuZGVkIHRleHQteHMgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaWNrZXQgI3t0aWNrZXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtNCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZCBwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgbWItMVwiPkR1ZSBBbW91bnQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtOdW1iZXIoaW5mby5kdWVBbW91bnQpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkIHAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSBtYi0xXCI+UGVuYWx0eTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e051bWJlcihpbmZvLnBlbmFsdHkpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIG1iLTFcIj5MYXRlIEZlZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e051bWJlcihpbmZvLmxhdGVGZWUpLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgey8qIFN1bW1hcnkgU2VjdGlvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+VG90YWwgUGVuYWx0eSBTdW1tYXJ5PC9oND5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+VG90YWwgUGVuYWx0eTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7cGF5bWVudEdyb3VwVGlja2V0cy5yZWR1Y2UoKHN1bSwgc2VsZWN0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpbmZvID0gcGVuYWx0eUluZm9NYXBbc2VsZWN0aW9uXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBzdW0gKyAoaW5mbyA/IE51bWJlcihpbmZvLnBlbmFsdHkpIDogMCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlXCI+VG90YWwgQ2hhcmdlczwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7cGF5bWVudEdyb3VwVGlja2V0cy5yZWR1Y2UoKHN1bSwgc2VsZWN0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpbmZvID0gcGVuYWx0eUluZm9NYXBbc2VsZWN0aW9uXTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBzdW0gKyAoaW5mbyA/IE51bWJlcihpbmZvLnRvdGFsQ2hhcmdlcykgOiAwKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LCAwKS50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBwLTQgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIG1iLTQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBheW1lbnQgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cF9pbnN0YWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshbW9kaWZ5UGF5bWVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW49e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZGlmeU1pbk1heFBheW1lbnREYXRlID8geWVzdGVyZGF5IDogdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4PXttb2RpZnlNaW5NYXhQYXltZW50RGF0ZSA/IHRvZGF5IDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGF5X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwicGF5X2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBheV9kYXRlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGF5X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImdyb3VwX3ZhbHVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFtb3VudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1hdEluZGlhbk51bWJlcihmb3JtRGF0YS5hbW91bnQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXZpb2xldC05MDBcIj57bnVtYmVyVG9JbmRpYW5Xb3Jkcyhmb3JtRGF0YS5hbW91bnQpfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBNb2RlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5X21vZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBheV9tb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUGF5bWVudE1vZGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjYXNoXCI+Q2FzaDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib25saW5lXCI+T25saW5lPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvbmxpbmUvdXBpXCI+T25saW5lL1VQSTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2hlcXVlXCI+Q2hlcXVlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge21vZGlmeVBheW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJhY2NvdW50X3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQWNjb3VudCBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWNjb3VudF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImFjY291bnRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVBY2NvdW50VHlwZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIj5TZWxlY3QgQWNjb3VudCBUeXBlPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInN1c3BlbnNlXCI+U3VzcGVuc2U8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5hbW91bnQgJiYgcGF5bWVudEdyb3VwVGlja2V0cy5sZW5ndGggPiAxICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiaW5kaXZpZHVhbF9hbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSW5kaXZpZHVhbCBUaWNrZXQgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgaG92ZXI6Y3Vyc29yLW5vdC1hbGxvd2VkIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJJbmRpdmlkdWFsIEFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1hdEluZGlhbk51bWJlcihcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE51bWJlcihmb3JtRGF0YS5hbW91bnQpIC9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBheW1lbnRHcm91cFRpY2tldHMubGVuZ3RoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOdW1iZXIoZm9ybURhdGEuYW1vdW50KSAvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGF5bWVudEdyb3VwVGlja2V0cy5sZW5ndGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgeyhwYXltZW50TW9kZSA9PT0gXCJvbmxpbmVcIiB8fFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBheW1lbnRNb2RlID09PSBcIm9ubGluZS91cGlcIikgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwidHJhbnNhY3Rpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gSUR7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0cmFuc2FjdGlvbl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBUcmFuc2FjdGlvbiBJRFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudE1vZGUgPT09IFwiY2hlcXVlXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJ0ZXh0LW1kIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDaGVxdWUgRGV0YWlsc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oNT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNoZXF1ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoZXF1ZSBOdW1iZXJ7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX251bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNoZXF1ZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNoZXF1ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBDaGVxdWUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY2hlcXVlX251bWJlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY2hlcXVlX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2hlcXVlX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENoZXF1ZSBEYXRle1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY2hlcXVlX2RhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmNoZXF1ZV9kYXRlLnNwbGl0KFwiVFwiKVswXX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIENoZXF1ZSBEYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuY2hlcXVlX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmNoZXF1ZV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjaGVxdWVfYmFua19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCYW5rIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImNoZXF1ZV9iYW5rX25hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJjaGVxdWVfYmFua19uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jaGVxdWVfYmFua19uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQmFuayBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2hlcXVlX2JhbmtfYnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCYW5rIEJyYW5jaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlcXVlX2JhbmtfYnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwiY2hlcXVlX2JhbmtfYnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jaGVxdWVfYmFua19icmFuY2h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBCYW5rIEJyYW5jaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy12aW9sZXQtNTAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC00IHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFXaGF0c2FwcFNxdWFyZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cImdyZWVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbWQgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFdoYXRzQXBwIE5vdGlmaWNhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3doYXRzYXBwRW5hYmxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMCBjaGVja2VkOnJpbmctMiBjaGVja2VkOnJpbmctZ3JlZW4tNzAwIHJvdW5kZWQtZnVsbCB3LTQgaC00XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNzAwIHRleHQtc21cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2VuZCBWaWEgV2hhdHNBcHBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICB7LyogU3VibWl0IEJ1dHRvbiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBwdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXdoaXRlIGJnLXZpb2xldC02MDAgaG92ZXI6YmctdmlvbGV0LTcwMCBmb2N1czpyaW5nLTIgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctdmlvbGV0LTMwMCBmb250LW1lZGl1bSByb3VuZGVkLW1kIHRleHQtc20gcHgtNiBweS0zIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBTYXZlIFBheW1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPERyYXdlclxyXG4gICAgICAgICAgICAgICAgICAgIGNsb3NhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgZGVzdHJveU9uSGlkZGVuXHJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIExhc3QgVGhyZWUgVHJhbnNhY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cInJpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICBvcGVuPXtvcGVuQW50RERyYXdlcn1cclxuICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtzaG93TG9hZGVyfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldE9wZW5BbnRERHJhd2VyKGZhbHNlKX1cclxuICAgICAgICAgICAgICAgICAgICB3aWR0aD17NDAwfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2xhc3RUaHJlZVBheW1lbnRzPy5sZW5ndGggPD0gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWNlbnRlciB0ZXh0LXhsIHB5LThcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTm8gVHJhbnNhY3Rpb24gRm91bmRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2xhc3RUaHJlZVBheW1lbnRzLm1hcCgocGF5bWVudCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNlY3Rpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgc2hhZG93LW1kIHJvdW5kZWQtbGcgcC00IHNwYWNlLXktMiBib3JkZXIgYm9yZGVyLWdyYXktMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IERhdGU6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnQ/LnBheV9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudC5ncm91cF9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudC5ncm91cF9pZD8uZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnQudGlja2V0ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDAgZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlja2V0OntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbm9ybWFsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXltZW50Py50aWNrZXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQW1vdW50OntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtwYXltZW50Py5hbW91bnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXltZW50IFR5cGU6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbm9ybWFsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5bWVudD8ucGF5X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOYW1lOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW5vcm1hbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW1lbnQudXNlcl9pZD8uZnVsbF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NlY3Rpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L0RyYXdlcj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L0RyYXdlcj5cclxuXHJcbiAgICAgICAgICAgIDxBbnRNb2RhbFxyXG4gICAgICAgICAgICAgIG9wZW49e3Nob3dNb2RhbFZpZXd9XHJcbiAgICAgICAgICAgICAgb25DYW5jZWw9eygpID0+IHNldFNob3dNb2RhbFZpZXcoZmFsc2UpfVxyXG4gICAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbFZpZXcoZmFsc2UpfVxyXG4gICAgICAgICAgICAgIG9uT2s9eygpID0+IHNldFNob3dNb2RhbFZpZXcoZmFsc2UpfVxyXG4gICAgICAgICAgICAgIG9uUmVsb2FkPXsoKSA9PiBoYW5kbGVWaWV3TW9kYWxPcGVuKGN1cnJlbnRHcm91cElkKX1cclxuICAgICAgICAgICAgICBmb290ZXI9ezxkaXY+PC9kaXY+fVxyXG4gICAgICAgICAgICAgIGxvYWRpbmc9e3ZpZXdMb2FkZXJ9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICBQYXltZW50IERldGFpbHNcclxuICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Hcm91cDogPC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB7Y3VycmVudFZpZXdHcm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Hcm91cCBWYWx1ZTo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWV9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Hcm91cCBJbnN0YWxsbWVudDo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5ncm91cF9pZD8uZ3JvdXBfaW5zdGFsbH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPlVzZXI6PC9zdHJvbmc+IHtjdXJyZW50Vmlld0dyb3VwPy51c2VyX2lkPy5mdWxsX25hbWV9e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB8IFRpY2tldDoge2N1cnJlbnRWaWV3R3JvdXA/LnRpY2tldH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkJpZCBBbW91bnQ6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB7Y3VycmVudFZpZXdHcm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlIC1cclxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50Vmlld0dyb3VwPy53aW5fYW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgPyBjdXJyZW50Vmlld0dyb3VwPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWUgLVxyXG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnRWaWV3R3JvdXA/Lndpbl9hbW91bnRcclxuICAgICAgICAgICAgICAgICAgICA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Db21taXNzaW9uOjwvc3Ryb25nPiB7Y3VycmVudFZpZXdHcm91cD8uY29tbWlzc2lvbn1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPldpbm5pbmcgQW1vdW50Ojwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/Lndpbl9hbW91bnR9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5EaXZpZGVudDo8L3N0cm9uZz4ge2N1cnJlbnRWaWV3R3JvdXA/LmRpdmlkZW50fVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+RGl2aWRlbnQgcGVyIEhlYWQ6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB7Y3VycmVudFZpZXdHcm91cD8uZGl2aWRlbnRfaGVhZH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPk5leHQgUGF5YWJsZTo8L3N0cm9uZz4ge2N1cnJlbnRWaWV3R3JvdXA/LnBheWFibGV9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5BdWN0aW9uIERhdGU6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB7Y3VycmVudFZpZXdHcm91cD8uYXVjdGlvbl9kYXRlfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+TmV4dCBEYXRlOjwvc3Ryb25nPiB7Y3VycmVudFZpZXdHcm91cD8ubmV4dF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+Q3JlYXRlZCBBdDo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5jcmVhdGVkQXQ/LnNwbGl0KFwiVFwiKVswXX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIGZsZXggZ2FwLXgtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPlVwZGF0ZWQgQXQ6PC9zdHJvbmc+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB7Y3VycmVudFZpZXdHcm91cD8udXBkYXRlZEF0Py5zcGxpdChcIlRcIilbMF19XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5DaGVxdWUgTnVtYmVyOjwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/LmNoZXF1ZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBmbGV4IGdhcC14LTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5DaGVxdWUgRGF0ZTo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5jaGVxdWVfZGF0ZT8uc3BsaXQoXCJUXCIpWzBdfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+Q2hlcXVlIEJhbmsgTmFtZTo8L3N0cm9uZz57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHtjdXJyZW50Vmlld0dyb3VwPy5jaGVxdWVfYmFua19uYW1lfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTMgZmxleCBnYXAteC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdHJvbmc+Q2hlcXVlIEJhbmsgQnJhbmNoIE5hbWUgOjwvc3Ryb25nPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAge2N1cnJlbnRWaWV3R3JvdXA/LmNoZXF1ZV9iYW5rX2JyYW5jaH1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L0FudE1vZGFsPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGVuYWx0eVBheW1lbnQ7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9QYXltZW50V2l0aFBlbmFsdHkuanN4In0=