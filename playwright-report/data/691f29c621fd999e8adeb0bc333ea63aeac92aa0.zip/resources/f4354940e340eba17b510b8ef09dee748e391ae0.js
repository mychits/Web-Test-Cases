import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CreateLoanRequest.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Form, Input, DatePicker, Button, Select, notification, InputNumber, Divider } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import API from "/src/instance/TokenInstance.js";
import __vite__cjsImport6_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport6_dayjs.__esModule ? __vite__cjsImport6_dayjs.default : __vite__cjsImport6_dayjs;
const { Option } = Select;
const { TextArea } = Input;
function CreateLoanRequest() {
  _s();
  const [api, contextHolder] = notification.useNotification();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    form.setFieldsValue({ dateOfBirth: dayjs(), guarantorDob: dayjs() });
  }, []);
  const onFinish = async (values) => {
    try {
      setLoading(true);
      const payload = {
        ...values,
        dateOfBirth: values.dateOfBirth ? values.dateOfBirth.format("YYYY-MM-DD") : null,
        guarantorDob: values.guarantorDob ? values.guarantorDob.format("YYYY-MM-DD") : null
      };
      const response = await API.post("/loan-request/create", payload);
      api.success({
        message: "Success",
        description: "Loan Request submitted successfully!"
      });
      setTimeout(() => window.close(), 1500);
    } catch (error) {
      console.error("Error:", error);
      api.error({
        message: "Error",
        description: error.response?.data?.message || "Failed to save request."
      });
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gray-100 p-6 flex justify-center", children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV("div", { className: "w-full max-w-4xl bg-white shadow-lg font-sans text-sm text-gray-800 rounded-lg", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "border-b-2 border-blue-900 p-6 mb-6 flex justify-between items-center", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-blue-900 uppercase tracking-wider", children: "New Loan Request" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
          lineNumber: 56,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { onClick: () => window.close(), children: "Close Tab" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
          lineNumber: 59,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
        lineNumber: 55,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "px-8 pb-8", children: /* @__PURE__ */ jsxDEV(Form, { form, layout: "vertical", onFinish, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-blue-900 mb-4 border-b pb-2 text-lg", children: "Personal Information" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
            lineNumber: 67,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "fullName", label: "Full Name", rules: [{ required: true }], children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "Enter full name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 73,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 72,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "dateOfBirth", label: "Date of Birth", rules: [{ required: true }], children: /* @__PURE__ */ jsxDEV(DatePicker, { style: { width: "100%" } }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 76,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 75,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "gender", label: "Gender", children: /* @__PURE__ */ jsxDEV(Select, { placeholder: "Select Gender", children: [
              /* @__PURE__ */ jsxDEV(Option, { value: "Male", children: "Male" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
                lineNumber: 80,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV(Option, { value: "Female", children: "Female" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
                lineNumber: 81,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV(Option, { value: "Other", children: "Other" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
                lineNumber: 82,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 79,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 78,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "fathersName", label: "Father's Name", children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "Father's name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 86,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 85,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "phoneNumber", label: "Phone Number", rules: [{ required: true }], children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "10 digit mobile number" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 89,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 88,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "amountOfLoan", label: "Amount of Loan Required", rules: [{ required: true }], children: /* @__PURE__ */ jsxDEV(InputNumber, { style: { width: "100%" }, placeholder: "0.00", prefix: "₹" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 92,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 91,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
            lineNumber: 71,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 gap-4", children: [
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "residenceAddress", label: "Residence Address", children: /* @__PURE__ */ jsxDEV(TextArea, { rows: 2, placeholder: "Full address" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 98,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 97,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "businessAddress", label: "Business Address", children: /* @__PURE__ */ jsxDEV(TextArea, { rows: 2, placeholder: "Office address" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 101,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 100,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "occupationIncome", label: "Occupation & Income", children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "e.g. Business - 50,000/month" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 104,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 103,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "purposeOfLoan", label: "Purpose of Loan", rules: [{ required: true }], children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "Why do you need the loan?" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 107,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 106,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "repaymentProcess", label: "How Repayment is Processed", children: /* @__PURE__ */ jsxDEV(Select, { placeholder: "Select option", children: [
              /* @__PURE__ */ jsxDEV(Option, { value: "Daily", children: "Daily" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
                lineNumber: 111,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV(Option, { value: "Weekly", children: "Weekly" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
                lineNumber: 112,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV(Option, { value: "Monthly", children: "Monthly" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
                lineNumber: 113,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV(Option, { value: "Quarterly", children: "Quarterly" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
                lineNumber: 114,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 110,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 109,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "signature", label: "Signature (Type Name)", children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "Type your full name as signature" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 118,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 117,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
            lineNumber: 96,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
          lineNumber: 66,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV(Divider, { style: { borderColor: "#1e3a8a" } }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
          lineNumber: 123,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-8", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "font-bold text-blue-900 mb-4 border-b pb-2 text-lg", children: "Second Party (Guarantor)" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
            lineNumber: 127,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: [
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "guarantorName", label: "Name", children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "Guarantor's full name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 133,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 132,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "guarantorDob", label: "Date of Birth", children: /* @__PURE__ */ jsxDEV(DatePicker, { style: { width: "100%" } }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 136,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 135,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "guarantorGender", label: "Gender", children: /* @__PURE__ */ jsxDEV(Select, { placeholder: "Select Gender", children: [
              /* @__PURE__ */ jsxDEV(Option, { value: "Male", children: "Male" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
                lineNumber: 140,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ jsxDEV(Option, { value: "Female", children: "Female" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
                lineNumber: 141,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 139,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 138,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "guarantorFathersName", label: "Father's Name", children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "Father's name" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 145,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 144,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "guarantorResidenceAddress", label: "Residence Address", children: /* @__PURE__ */ jsxDEV(TextArea, { rows: 2 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 148,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 147,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "guarantorPhoneNumber", label: "Phone Number", children: /* @__PURE__ */ jsxDEV(Input, { placeholder: "10 digit mobile number" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 151,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 150,
              columnNumber: 33
            }, this),
            /* @__PURE__ */ jsxDEV(Form.Item, { name: "guarantorBusinessAddress", label: "Business Address", children: /* @__PURE__ */ jsxDEV(TextArea, { rows: 2 }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 154,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 153,
              columnNumber: 33
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
            lineNumber: 131,
            columnNumber: 29
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
          lineNumber: 126,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 pt-4 border-t", children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              onClick: () => window.close(),
              className: "flex-1 h-12 font-semibold border-gray-400 text-lg",
              children: "Cancel"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 160,
              columnNumber: 29
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              htmlType: "submit",
              loading,
              className: "flex-1 bg-blue-900 hover:bg-blue-800 h-12 font-bold uppercase tracking-wide text-lg",
              children: "Submit Request"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
              lineNumber: 166,
              columnNumber: 29
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
          lineNumber: 159,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
        lineNumber: 63,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
        lineNumber: 62,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
      lineNumber: 54,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx",
    lineNumber: 52,
    columnNumber: 5
  }, this);
}
_s(CreateLoanRequest, "KQ3GHsg5aVL945dFQfirsqDRaKA=", false, function() {
  return [notification.useNotification, Form.useForm];
});
_c = CreateLoanRequest;
export default CreateLoanRequest;
var _c;
$RefreshReg$(_c, "CreateLoanRequest");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CreateLoanRequest.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdURvQjsyQkF2RHBCO0FBQWdCQSxNQUFVQyxjQUFTLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbEQsU0FBU0MsTUFBTUMsT0FBT0MsWUFBWUMsUUFBUUMsUUFBUUMsY0FBY0MsYUFBYUMsZUFBZTtBQUM1RixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLFdBQVc7QUFFbEIsTUFBTSxFQUFFQyxPQUFPLElBQUlOO0FBQ25CLE1BQU0sRUFBRU8sU0FBUyxJQUFJVjtBQUVyQixTQUFTVyxvQkFBb0I7QUFBQUMsS0FBQTtBQUN6QixRQUFNLENBQUNDLEtBQUtDLGFBQWEsSUFBSVYsYUFBYVcsZ0JBQWdCO0FBQzFELFFBQU0sQ0FBQ0MsSUFBSSxJQUFJakIsS0FBS2tCLFFBQVE7QUFDNUIsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUl0QixTQUFTLEtBQUs7QUFHNUNDLFlBQVUsTUFBTTtBQUNaa0IsU0FBS0ksZUFBZSxFQUFFQyxhQUFhYixNQUFNLEdBQUdjLGNBQWNkLE1BQU0sRUFBRSxDQUFDO0FBQUEsRUFDdkUsR0FBRyxFQUFFO0FBRUwsUUFBTWUsV0FBVyxPQUFPQyxXQUFXO0FBQy9CLFFBQUk7QUFDQUwsaUJBQVcsSUFBSTtBQUdmLFlBQU1NLFVBQVU7QUFBQSxRQUNaLEdBQUdEO0FBQUFBLFFBQ0hILGFBQWFHLE9BQU9ILGNBQWNHLE9BQU9ILFlBQVlLLE9BQU8sWUFBWSxJQUFJO0FBQUEsUUFDNUVKLGNBQWNFLE9BQU9GLGVBQWVFLE9BQU9GLGFBQWFJLE9BQU8sWUFBWSxJQUFJO0FBQUEsTUFDbkY7QUFFQSxZQUFNQyxXQUFXLE1BQU1wQixJQUFJcUIsS0FBSyx3QkFBd0JILE9BQU87QUFFL0RaLFVBQUlnQixRQUFRO0FBQUEsUUFDUkMsU0FBUztBQUFBLFFBQ1RDLGFBQWE7QUFBQSxNQUNqQixDQUFDO0FBR0RDLGlCQUFXLE1BQU1DLE9BQU9DLE1BQU0sR0FBRyxJQUFJO0FBQUEsSUFFekMsU0FBU0MsT0FBTztBQUNaQyxjQUFRRCxNQUFNLFVBQVVBLEtBQUs7QUFDN0J0QixVQUFJc0IsTUFBTTtBQUFBLFFBQ05MLFNBQVM7QUFBQSxRQUNUQyxhQUFhSSxNQUFNUixVQUFVVSxNQUFNUCxXQUFXO0FBQUEsTUFDbEQsQ0FBQztBQUFBLElBQ0wsVUFBQztBQUNHWCxpQkFBVyxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBRUEsU0FDSSx1QkFBQyxTQUFJLFdBQVUsb0RBQ1ZMO0FBQUFBO0FBQUFBLElBQ0QsdUJBQUMsU0FBSSxXQUFVLGtGQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHlFQUNYO0FBQUEsK0JBQUMsUUFBRyxXQUFVLDZEQUE0RCxnQ0FBMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxVQUFPLFNBQVMsTUFBTW1CLE9BQU9DLE1BQU0sR0FBRyx5QkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFdBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGFBQ1gsaUNBQUMsUUFBSyxNQUFZLFFBQU8sWUFBVyxVQUdoQztBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNYO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHNEQUFxRCxvQ0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLHlDQUNYO0FBQUEsbUNBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxZQUFXLE9BQU0sYUFBWSxPQUFPLENBQUMsRUFBRUksVUFBVSxLQUFLLENBQUMsR0FDbkUsaUNBQUMsU0FBTSxhQUFZLHFCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvQyxLQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLGVBQWMsT0FBTSxpQkFBZ0IsT0FBTyxDQUFDLEVBQUVBLFVBQVUsS0FBSyxDQUFDLEdBQzFFLGlDQUFDLGNBQVcsT0FBTyxFQUFFQyxPQUFPLE9BQU8sS0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUMsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxVQUFTLE9BQU0sVUFDM0IsaUNBQUMsVUFBTyxhQUFZLGlCQUNoQjtBQUFBLHFDQUFDLFVBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5QjtBQUFBLGNBQ3pCLHVCQUFDLFVBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE2QjtBQUFBLGNBQzdCLHVCQUFDLFVBQU8sT0FBTSxTQUFRLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEyQjtBQUFBLGlCQUgvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlBLEtBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFNQTtBQUFBLFlBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxlQUFjLE9BQU0saUJBQ2hDLGlDQUFDLFNBQU0sYUFBWSxtQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0MsS0FEdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxlQUFjLE9BQU0sZ0JBQWUsT0FBTyxDQUFDLEVBQUVELFVBQVUsS0FBSyxDQUFDLEdBQ3pFLGlDQUFDLFNBQU0sYUFBWSw0QkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMkMsS0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxnQkFBZSxPQUFNLDJCQUEwQixPQUFPLENBQUMsRUFBRUEsVUFBVSxLQUFLLENBQUMsR0FDckYsaUNBQUMsZUFBWSxPQUFPLEVBQUVDLE9BQU8sT0FBTyxHQUFHLGFBQVksUUFBTyxRQUFPLE9BQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQW9FLEtBRHhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVCQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLDBCQUNYO0FBQUEsbUNBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxvQkFBbUIsT0FBTSxxQkFDckMsaUNBQUMsWUFBUyxNQUFNLEdBQUcsYUFBWSxrQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBNkMsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxtQkFBa0IsT0FBTSxvQkFDcEMsaUNBQUMsWUFBUyxNQUFNLEdBQUcsYUFBWSxvQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0MsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxvQkFBbUIsT0FBTSx1QkFDckMsaUNBQUMsU0FBTSxhQUFZLGtDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRCxLQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLGlCQUFnQixPQUFNLG1CQUFrQixPQUFPLENBQUMsRUFBRUQsVUFBVSxLQUFLLENBQUMsR0FDOUUsaUNBQUMsU0FBTSxhQUFZLCtCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4QyxLQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLG9CQUFtQixPQUFNLDhCQUNyQyxpQ0FBQyxVQUFPLGFBQVksaUJBQ2hCO0FBQUEscUNBQUMsVUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJCO0FBQUEsY0FDM0IsdUJBQUMsVUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZCO0FBQUEsY0FDN0IsdUJBQUMsVUFBTyxPQUFNLFdBQVUsdUJBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUEsY0FDL0IsdUJBQUMsVUFBTyxPQUFNLGFBQVkseUJBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1DO0FBQUEsaUJBSnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBS0EsS0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsWUFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLGFBQVksT0FBTSx5QkFDOUIsaUNBQUMsU0FBTSxhQUFZLHNDQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRCxLQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF2Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF3QkE7QUFBQSxhQXRESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdURBO0FBQUEsUUFFQSx1QkFBQyxXQUFRLE9BQU8sRUFBRUUsYUFBYSxVQUFVLEtBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkM7QUFBQSxRQUczQyx1QkFBQyxTQUFJLFdBQVUsUUFDWDtBQUFBLGlDQUFDLFFBQUcsV0FBVSxzREFBcUQsd0NBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSx5Q0FDWDtBQUFBLG1DQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssaUJBQWdCLE9BQU0sUUFDbEMsaUNBQUMsU0FBTSxhQUFZLDJCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEwQyxLQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLGdCQUFlLE9BQU0saUJBQ2pDLGlDQUFDLGNBQVcsT0FBTyxFQUFFRCxPQUFPLE9BQU8sS0FBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBcUMsS0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsS0FBSyxNQUFMLEVBQVUsTUFBSyxtQkFBa0IsT0FBTSxVQUNwQyxpQ0FBQyxVQUFPLGFBQVksaUJBQ2hCO0FBQUEscUNBQUMsVUFBTyxPQUFNLFFBQU8sb0JBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXlCO0FBQUEsY0FDekIsdUJBQUMsVUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZCO0FBQUEsaUJBRmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsS0FKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLHdCQUF1QixPQUFNLGlCQUN6QyxpQ0FBQyxTQUFNLGFBQVksbUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtDLEtBRHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssNkJBQTRCLE9BQU0scUJBQzlDLGlDQUFDLFlBQVMsTUFBTSxLQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQixLQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFDQSx1QkFBQyxLQUFLLE1BQUwsRUFBVSxNQUFLLHdCQUF1QixPQUFNLGdCQUN6QyxpQ0FBQyxTQUFNLGFBQVksNEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJDLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLEtBQUssTUFBTCxFQUFVLE1BQUssNEJBQTJCLE9BQU0sb0JBQzdDLGlDQUFDLFlBQVMsTUFBTSxLQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFrQixLQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUF4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5QkE7QUFBQSxhQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0JBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsNEJBQ1g7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0csU0FBUyxNQUFNTixPQUFPQyxNQUFNO0FBQUEsY0FDNUIsV0FBVTtBQUFBLGNBQW1EO0FBQUE7QUFBQSxZQUZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNHLE1BQUs7QUFBQSxjQUNMLFVBQVM7QUFBQSxjQUNUO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FBcUY7QUFBQTtBQUFBLFlBSm5HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU9BO0FBQUEsYUFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxXQS9HSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0hBLEtBakhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrSEE7QUFBQSxTQTFISjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkhBO0FBQUEsT0E3SEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQThIQTtBQUVSO0FBQUN0QixHQTNLUUQsbUJBQWlCO0FBQUEsVUFDT1AsYUFBYVcsaUJBQzNCaEIsS0FBS2tCLE9BQU87QUFBQTtBQUFBd0IsS0FGdEI5QjtBQTZLVCxlQUFlQTtBQUFrQixJQUFBOEI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiRm9ybSIsIklucHV0IiwiRGF0ZVBpY2tlciIsIkJ1dHRvbiIsIlNlbGVjdCIsIm5vdGlmaWNhdGlvbiIsIklucHV0TnVtYmVyIiwiRGl2aWRlciIsIkFQSSIsImRheWpzIiwiT3B0aW9uIiwiVGV4dEFyZWEiLCJDcmVhdGVMb2FuUmVxdWVzdCIsIl9zIiwiYXBpIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsImZvcm0iLCJ1c2VGb3JtIiwibG9hZGluZyIsInNldExvYWRpbmciLCJzZXRGaWVsZHNWYWx1ZSIsImRhdGVPZkJpcnRoIiwiZ3VhcmFudG9yRG9iIiwib25GaW5pc2giLCJ2YWx1ZXMiLCJwYXlsb2FkIiwiZm9ybWF0IiwicmVzcG9uc2UiLCJwb3N0Iiwic3VjY2VzcyIsIm1lc3NhZ2UiLCJkZXNjcmlwdGlvbiIsInNldFRpbWVvdXQiLCJ3aW5kb3ciLCJjbG9zZSIsImVycm9yIiwiY29uc29sZSIsImRhdGEiLCJyZXF1aXJlZCIsIndpZHRoIiwiYm9yZGVyQ29sb3IiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJDcmVhdGVMb2FuUmVxdWVzdC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgRm9ybSwgSW5wdXQsIERhdGVQaWNrZXIsIEJ1dHRvbiwgU2VsZWN0LCBub3RpZmljYXRpb24sIElucHV0TnVtYmVyLCBEaXZpZGVyIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IEFQSSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgZGF5anMgZnJvbSBcImRheWpzXCI7XHJcblxyXG5jb25zdCB7IE9wdGlvbiB9ID0gU2VsZWN0O1xyXG5jb25zdCB7IFRleHRBcmVhIH0gPSBJbnB1dDtcclxuXHJcbmZ1bmN0aW9uIENyZWF0ZUxvYW5SZXF1ZXN0KCkge1xyXG4gICAgY29uc3QgW2FwaSwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcbiAgICBjb25zdCBbZm9ybV0gPSBGb3JtLnVzZUZvcm0oKTtcclxuICAgIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgICAvLyBJbml0aWFsaXplIERhdGVcclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgZm9ybS5zZXRGaWVsZHNWYWx1ZSh7IGRhdGVPZkJpcnRoOiBkYXlqcygpLCBndWFyYW50b3JEb2I6IGRheWpzKCkgfSk7XHJcbiAgICB9LCBbXSk7XHJcblxyXG4gICAgY29uc3Qgb25GaW5pc2ggPSBhc3luYyAodmFsdWVzKSA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC8vIEZvcm1hdCBkYXRlc1xyXG4gICAgICAgICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgICAgICAgLi4udmFsdWVzLFxyXG4gICAgICAgICAgICAgICAgZGF0ZU9mQmlydGg6IHZhbHVlcy5kYXRlT2ZCaXJ0aCA/IHZhbHVlcy5kYXRlT2ZCaXJ0aC5mb3JtYXQoJ1lZWVktTU0tREQnKSA6IG51bGwsXHJcbiAgICAgICAgICAgICAgICBndWFyYW50b3JEb2I6IHZhbHVlcy5ndWFyYW50b3JEb2IgPyB2YWx1ZXMuZ3VhcmFudG9yRG9iLmZvcm1hdCgnWVlZWS1NTS1ERCcpIDogbnVsbCxcclxuICAgICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLnBvc3QoXCIvbG9hbi1yZXF1ZXN0L2NyZWF0ZVwiLCBwYXlsb2FkKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGFwaS5zdWNjZXNzKHsgXHJcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlN1Y2Nlc3NcIiwgXHJcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJMb2FuIFJlcXVlc3Qgc3VibWl0dGVkIHN1Y2Nlc3NmdWxseSFcIiBcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAvLyBDbG9zZSB0YWIgYWZ0ZXIgc3VjY2Vzc1xyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHdpbmRvdy5jbG9zZSgpLCAxNTAwKTsgXHJcblxyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvcjpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgICBhcGkuZXJyb3IoeyBcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiRXJyb3JcIiwgXHJcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gc2F2ZSByZXF1ZXN0LlwiIFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctZ3JheS0xMDAgcC02IGZsZXgganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAge2NvbnRleHRIb2xkZXJ9XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LTR4bCBiZy13aGl0ZSBzaGFkb3ctbGcgZm9udC1zYW5zIHRleHQtc20gdGV4dC1ncmF5LTgwMCByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci1iLTIgYm9yZGVyLWJsdWUtOTAwIHAtNiBtYi02IGZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ibHVlLTkwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTmV3IExvYW4gUmVxdWVzdFxyXG4gICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB3aW5kb3cuY2xvc2UoKX0+Q2xvc2UgVGFiPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTggcGItOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGb3JtIGZvcm09e2Zvcm19IGxheW91dD1cInZlcnRpY2FsXCIgb25GaW5pc2g9e29uRmluaXNofT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiAtLS0gUGVyc29uYWwgSW5mb3JtYXRpb24gLS0tICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLThcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1ibHVlLTkwMCBtYi00IGJvcmRlci1iIHBiLTIgdGV4dC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBlcnNvbmFsIEluZm9ybWF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJmdWxsTmFtZVwiIGxhYmVsPVwiRnVsbCBOYW1lXCIgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlIH1dfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0IHBsYWNlaG9sZGVyPVwiRW50ZXIgZnVsbCBuYW1lXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJkYXRlT2ZCaXJ0aFwiIGxhYmVsPVwiRGF0ZSBvZiBCaXJ0aFwiIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSB9XX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRlUGlja2VyIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScgfX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJnZW5kZXJcIiBsYWJlbD1cIkdlbmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0IHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdlbmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIk1hbGVcIj5NYWxlPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiRmVtYWxlXCI+RmVtYWxlPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiT3RoZXJcIj5PdGhlcjwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJmYXRoZXJzTmFtZVwiIGxhYmVsPVwiRmF0aGVyJ3MgTmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXQgcGxhY2Vob2xkZXI9XCJGYXRoZXIncyBuYW1lXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJwaG9uZU51bWJlclwiIGxhYmVsPVwiUGhvbmUgTnVtYmVyXCIgcnVsZXM9e1t7IHJlcXVpcmVkOiB0cnVlIH1dfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0IHBsYWNlaG9sZGVyPVwiMTAgZGlnaXQgbW9iaWxlIG51bWJlclwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiYW1vdW50T2ZMb2FuXCIgbGFiZWw9XCJBbW91bnQgb2YgTG9hbiBSZXF1aXJlZFwiIHJ1bGVzPXtbeyByZXF1aXJlZDogdHJ1ZSB9XX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dE51bWJlciBzdHlsZT17eyB3aWR0aDogJzEwMCUnIH19IHBsYWNlaG9sZGVyPVwiMC4wMFwiIHByZWZpeD1cIuKCuVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJyZXNpZGVuY2VBZGRyZXNzXCIgbGFiZWw9XCJSZXNpZGVuY2UgQWRkcmVzc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEFyZWEgcm93cz17Mn0gcGxhY2Vob2xkZXI9XCJGdWxsIGFkZHJlc3NcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImJ1c2luZXNzQWRkcmVzc1wiIGxhYmVsPVwiQnVzaW5lc3MgQWRkcmVzc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEFyZWEgcm93cz17Mn0gcGxhY2Vob2xkZXI9XCJPZmZpY2UgYWRkcmVzc1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwib2NjdXBhdGlvbkluY29tZVwiIGxhYmVsPVwiT2NjdXBhdGlvbiAmIEluY29tZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXQgcGxhY2Vob2xkZXI9XCJlLmcuIEJ1c2luZXNzIC0gNTAsMDAwL21vbnRoXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJwdXJwb3NlT2ZMb2FuXCIgbGFiZWw9XCJQdXJwb3NlIG9mIExvYW5cIiBydWxlcz17W3sgcmVxdWlyZWQ6IHRydWUgfV19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXQgcGxhY2Vob2xkZXI9XCJXaHkgZG8geW91IG5lZWQgdGhlIGxvYW4/XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJyZXBheW1lbnRQcm9jZXNzXCIgbGFiZWw9XCJIb3cgUmVwYXltZW50IGlzIFByb2Nlc3NlZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0IHBsYWNlaG9sZGVyPVwiU2VsZWN0IG9wdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIkRhaWx5XCI+RGFpbHk8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJXZWVrbHlcIj5XZWVrbHk8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJNb250aGx5XCI+TW9udGhseTwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIlF1YXJ0ZXJseVwiPlF1YXJ0ZXJseTwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJzaWduYXR1cmVcIiBsYWJlbD1cIlNpZ25hdHVyZSAoVHlwZSBOYW1lKVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW5wdXQgcGxhY2Vob2xkZXI9XCJUeXBlIHlvdXIgZnVsbCBuYW1lIGFzIHNpZ25hdHVyZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RGl2aWRlciBzdHlsZT17eyBib3JkZXJDb2xvcjogJyMxZTNhOGEnIH19IC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogLS0tIFNlY29uZCBQYXJ0eSAoR3VhcmFudG9yKSAtLS0gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWJsdWUtOTAwIG1iLTQgYm9yZGVyLWIgcGItMiB0ZXh0LWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU2Vjb25kIFBhcnR5IChHdWFyYW50b3IpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJndWFyYW50b3JOYW1lXCIgbGFiZWw9XCJOYW1lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dCBwbGFjZWhvbGRlcj1cIkd1YXJhbnRvcidzIGZ1bGwgbmFtZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiZ3VhcmFudG9yRG9iXCIgbGFiZWw9XCJEYXRlIG9mIEJpcnRoXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEYXRlUGlja2VyIHN0eWxlPXt7IHdpZHRoOiAnMTAwJScgfX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uSXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5JdGVtIG5hbWU9XCJndWFyYW50b3JHZW5kZXJcIiBsYWJlbD1cIkdlbmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0IHBsYWNlaG9sZGVyPVwiU2VsZWN0IEdlbmRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIk1hbGVcIj5NYWxlPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiRmVtYWxlXCI+RmVtYWxlPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImd1YXJhbnRvckZhdGhlcnNOYW1lXCIgbGFiZWw9XCJGYXRoZXIncyBOYW1lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dCBwbGFjZWhvbGRlcj1cIkZhdGhlcidzIG5hbWVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImd1YXJhbnRvclJlc2lkZW5jZUFkZHJlc3NcIiBsYWJlbD1cIlJlc2lkZW5jZSBBZGRyZXNzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0QXJlYSByb3dzPXsyfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkl0ZW0gbmFtZT1cImd1YXJhbnRvclBob25lTnVtYmVyXCIgbGFiZWw9XCJQaG9uZSBOdW1iZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPElucHV0IHBsYWNlaG9sZGVyPVwiMTAgZGlnaXQgbW9iaWxlIG51bWJlclwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uSXRlbSBuYW1lPVwiZ3VhcmFudG9yQnVzaW5lc3NBZGRyZXNzXCIgbGFiZWw9XCJCdXNpbmVzcyBBZGRyZXNzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUZXh0QXJlYSByb3dzPXsyfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5JdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC00IHB0LTQgYm9yZGVyLXRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gd2luZG93LmNsb3NlKCl9IFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBoLTEyIGZvbnQtc2VtaWJvbGQgYm9yZGVyLWdyYXktNDAwIHRleHQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCIgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHRtbFR5cGU9XCJzdWJtaXRcIiBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPXtsb2FkaW5nfSBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgYmctYmx1ZS05MDAgaG92ZXI6YmctYmx1ZS04MDAgaC0xMiBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3VibWl0IFJlcXVlc3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L0Zvcm0+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDcmVhdGVMb2FuUmVxdWVzdDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQ3JlYXRlTG9hblJlcXVlc3QuanN4In0=