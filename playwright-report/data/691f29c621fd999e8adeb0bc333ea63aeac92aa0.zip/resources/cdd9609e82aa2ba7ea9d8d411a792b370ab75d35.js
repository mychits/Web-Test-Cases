import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/DreamAsset.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { Input, Select, Dropdown, Button, Table } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import { fieldSize } from "/src/data/fieldSize.js";
const DreamAsset = () => {
  _s();
  const [assets, setAssets] = useState([]);
  const [selectedAssets, setSelectedAssets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [TableAsset, setTableAsset] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentAsset, setCurrentAsset] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [currentUpdateAsset, setCurrentUpdateAsset] = useState(null);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [deleteConfirmationText, setDeleteConfirmationText] = useState("");
  const [errors, setErrors] = useState({});
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [searchText, setSearchText] = useState("");
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [formData, setFormData] = useState({
    asset_type: ""
  });
  const [updateFormData, setUpdateFormData] = useState({
    asset_type: ""
  });
  useEffect(() => {
    const fetchDreamAsset = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/asset/get-asset-info");
        const assetData = response.data?.asset || [];
        setAssets(assetData);
        const formattedData = assetData.map((group, index) => ({
          _id: group?._id,
          id: index + 1,
          //asset_type: group?.asset_type,
          asset_type: Array.isArray(group?.asset_type) ? group.asset_type.map((type) => type.charAt(0).toUpperCase() + type.slice(1)).join(", ") : group?.asset_type?.charAt(0).toUpperCase() + group?.asset_type?.slice(1),
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(group?._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                        lineNumber: 76,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(group?._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                        lineNumber: 87,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                lineNumber: 99,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
              lineNumber: 69,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
            lineNumber: 68,
            columnNumber: 11
          }, this)
        }));
        setTableAsset(formattedData);
      } catch (error) {
        console.error("Error fetching Asset data:", error.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchDreamAsset();
  }, [reloadTrigger]);
  const handleAntDSelect = (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
  };
  const handleAntInputDSelect = (field, value) => {
    setUpdateFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors({ ...errors, [field]: "" });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await api.post("/asset/add-asset-info", formData, {
        headers: {
          "Content-Type": "application/json"
        }
      });
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        type: "success",
        message: "Asset Added Successfully",
        visibility: true
      });
      setShowModal(false);
      setFormData({
        asset_type: ""
      });
    } catch (error) {
      console.error("Error adding Asset:", error);
      setAlertConfig({
        type: "error",
        message: error?.response?.data?.message || "An unexpected error occurred.",
        visibility: true
      });
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await api.put(
        `/asset/update-asset-info/${currentUpdateAsset?._id}`,
        updateFormData,
        {
          headers: {
            "Content-Type": "application/json"
          }
        }
      );
      setShowModalUpdate(false);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        type: "success",
        message: "Asset Updated Successfully",
        visibility: true
      });
    } catch (error) {
      console.error("Error updating Asset:", error);
      setAlertConfig({
        type: "error",
        message: error?.response?.data?.message || "Update failed",
        visibility: true
      });
    }
  };
  const handleDeleteModalOpen = async (userId) => {
    try {
      const response = await api.get(`/asset/get-asset-info-by-id/${userId}`);
      setCurrentAsset(response.data?.asset);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching Asset:", error);
    }
  };
  const handleUpdateModalOpen = async (userId) => {
    try {
      const response = await api.get(`/asset/get-asset-info-by-id/${userId}`);
      setUpdateFormData({
        asset_type: response.data?.asset?.asset_type
      });
      setCurrentUpdateAsset(response.data?.asset);
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching Asset:", error);
    }
  };
  const handleDeleteAsset = async () => {
    if (!currentAsset || !currentAsset._id) return;
    try {
      await api.delete(`/asset/delete-asset-info-by-id/${currentAsset._id}`);
      setTableAsset(
        (prev) => prev.filter((item) => item._id !== currentAsset._id)
      );
      setAlertConfig({
        visibility: true,
        message: "Asset deleted successfully",
        type: "success"
      });
      setReloadTrigger((prev) => prev + 1);
      setShowModalDelete(false);
      setCurrentAsset(null);
    } catch (error) {
      console.error("Error deleting asset:", error);
      setAlertConfig({
        visibility: true,
        type: "error",
        message: "Failed to delete asset."
      });
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "asset_type", header: "Asset Name" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
          lineNumber: 264,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
          lineNumber: 268,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Dream Asset" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
            lineNumber: 280,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowModal(true);
                setErrors({});
              },
              className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
              children: "+ Add Asset"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
              lineNumber: 282,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
          lineNumber: 279,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
          lineNumber: 278,
          columnNumber: 13
        }, this),
        TableAsset?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableAsset, searchText),
            columns,
            exportedFileName: `Asset-${TableAsset.length > 0 ? TableAsset[0].name + " to " + TableAsset[TableAsset.length - 1].name : "empty"}.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
            lineNumber: 294,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableAsset.length <= 0,
            data: "Asset Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
            lineNumber: 308,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
        lineNumber: 277,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
      lineNumber: 262,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Asset" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
        lineNumber: 318,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "referred_type",
              children: [
                "Asset Type ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                  lineNumber: 325,
                  columnNumber: 30
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
              lineNumber: 321,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
              placeholder: "Select Asset Type",
              popupMatchSelectWidth: false,
              showSearch: true,
              name: "asset_type",
              filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
              value: formData?.asset_type || void 0,
              onChange: (value) => handleAntDSelect("asset_type", value),
              children: [
                "Car",
                "House",
                "Bike",
                "Travel",
                "Health",
                "Jewellery"
              ].map(
                (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType.toLowerCase(), children: refType }, refType, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                  lineNumber: 348,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
              lineNumber: 327,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
          lineNumber: 320,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
            children: "Save Asset"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
            lineNumber: 356,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
          lineNumber: 355,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
        lineNumber: 319,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
      lineNumber: 317,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
      lineNumber: 316,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Asset" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
            lineNumber: 372,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "referred_type",
                  children: [
                    "Asset Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                      lineNumber: 381,
                      columnNumber: 30
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                  lineNumber: 377,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`,
                  placeholder: "Select Asset Type",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "asset_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.asset_type || void 0,
                  onChange: (value) => handleAntInputDSelect("asset_type", value),
                  children: [
                    "Car",
                    "House",
                    "Bike",
                    "Travel",
                    "Health",
                    "Jewellery"
                  ].map(
                    (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType.toLowerCase() }, refType, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                      lineNumber: 406,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                  lineNumber: 383,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
              lineNumber: 376,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                lineNumber: 413,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
              lineNumber: 412,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
            lineNumber: 375,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
          lineNumber: 371,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
        lineNumber: 367,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentAsset(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Asset" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
            lineNumber: 432,
            columnNumber: 13
          }, this),
          currentAsset && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteAsset();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-700", children: [
                  "Are you sure you want to delete",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "font-bold text-primary", children: currentAsset.asset_type }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                    lineNumber: 445,
                    columnNumber: 19
                  }, this),
                  "? This action cannot be undone."
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                  lineNumber: 443,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n        focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
                    lineNumber: 450,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
              lineNumber: 436,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
          lineNumber: 431,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
        lineNumber: 424,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
    lineNumber: 261,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx",
    lineNumber: 260,
    columnNumber: 5
  }, this);
};
_s(DreamAsset, "NtoZXi3lFLk9mltLX9630JfUseM=");
_c = DreamAsset;
export default DreamAsset;
var _c;
$RefreshReg$(_c, "DreamAsset");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/DreamAsset.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkV3QixTQXdMcEIsVUF4TG9COzJCQTNFeEI7QUFBb0JBLG9CQUFnQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsT0FBT0MsUUFBUUMsVUFBVUMsUUFBUUMsYUFBYTtBQUN2RCxTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msb0JBQW9CO0FBRTNCLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGlCQUFpQjtBQUUxQixNQUFNQyxhQUFhQSxNQUFNO0FBQUFDLEtBQUE7QUFDdkIsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlwQixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDcUIsZ0JBQWdCQyxpQkFBaUIsSUFBSXRCLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUN1QixTQUFTQyxVQUFVLElBQUl4QixTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDeUIsWUFBWUMsYUFBYSxJQUFJMUIsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzJCLFlBQVlDLGFBQWEsSUFBSTVCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUM2QixXQUFXQyxZQUFZLElBQUk5QixTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDK0IsaUJBQWlCQyxrQkFBa0IsSUFBSWhDLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNpQyxpQkFBaUJDLGtCQUFrQixJQUFJbEMsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ21DLGNBQWNDLGVBQWUsSUFBSXBDLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNxQyxXQUFXQyxZQUFZLElBQUl0QyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDdUMsb0JBQW9CQyxxQkFBcUIsSUFBSXhDLFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUN5QyxlQUFlQyxnQkFBZ0IsSUFBSTFDLFNBQVMsQ0FBQztBQUNwRCxRQUFNLENBQUMyQyx3QkFBd0JDLHlCQUF5QixJQUFJNUMsU0FBUyxFQUFFO0FBQ3ZFLFFBQU0sQ0FBQzZDLFFBQVFDLFNBQVMsSUFBSTlDLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQytDLGFBQWFDLGNBQWMsSUFBSWhELFNBQVM7QUFBQSxJQUM3Q2lELFlBQVk7QUFBQSxJQUNaQyxTQUFTO0FBQUEsSUFDVEMsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJckQsU0FBUyxFQUFFO0FBQy9DLFFBQU1zRCw0QkFBNEJBLENBQUNDLE1BQU07QUFDdkMsVUFBTSxFQUFFQyxNQUFNLElBQUlELEVBQUVFO0FBQ3BCSixrQkFBY0csS0FBSztBQUFBLEVBQ3JCO0FBQ0EsUUFBTSxDQUFDRSxVQUFVQyxXQUFXLElBQUkzRCxTQUFTO0FBQUEsSUFDdkM0RCxZQUFZO0FBQUEsRUFDZCxDQUFDO0FBQ0QsUUFBTSxDQUFDQyxnQkFBZ0JDLGlCQUFpQixJQUFJOUQsU0FBUztBQUFBLElBQ25ENEQsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUVERyxZQUFVLE1BQU07QUFDZCxVQUFNQyxrQkFBa0IsWUFBWTtBQUNsQyxVQUFJO0FBQ0YxQixxQkFBYSxJQUFJO0FBQ2pCLGNBQU0yQixXQUFXLE1BQU05RCxJQUFJK0QsSUFBSSx1QkFBdUI7QUFDdEQsY0FBTUMsWUFBWUYsU0FBU0csTUFBTUMsU0FBUztBQUUxQ2pELGtCQUFVK0MsU0FBUztBQUVuQixjQUFNRyxnQkFBZ0JILFVBQVVJLElBQUksQ0FBQ0MsT0FBT0MsV0FBVztBQUFBLFVBQ3JEQyxLQUFLRixPQUFPRTtBQUFBQSxVQUNaQyxJQUFJRixRQUFRO0FBQUE7QUFBQSxVQUVaYixZQUFZZ0IsTUFBTUMsUUFBUUwsT0FBT1osVUFBVSxJQUN2Q1ksTUFBTVosV0FDSFcsSUFBSSxDQUFDcEIsU0FBU0EsS0FBSzJCLE9BQU8sQ0FBQyxFQUFFQyxZQUFZLElBQUk1QixLQUFLNkIsTUFBTSxDQUFDLENBQUMsRUFDMURDLEtBQUssSUFBSSxJQUNaVCxPQUFPWixZQUFZa0IsT0FBTyxDQUFDLEVBQUVDLFlBQVksSUFDekNQLE9BQU9aLFlBQVlvQixNQUFNLENBQUM7QUFBQSxVQUM5QkUsUUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsY0FDakIsTUFBTTtBQUFBLGdCQUNKQyxPQUFPO0FBQUEsa0JBQ0w7QUFBQSxvQkFDRUMsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQU1DLHNCQUFzQmQsT0FBT0UsR0FBRztBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRUo7QUFBQSxrQkFDQTtBQUFBLG9CQUNFVSxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFBTUUsc0JBQXNCZixPQUFPRSxHQUFHO0FBQUEsd0JBQUU7QUFBQTtBQUFBLHNCQUZuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFFSjtBQUFBLGdCQUFDO0FBQUEsY0FFTDtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVYsaUNBQUMsWUFBUyxXQUFVLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUE7QUFBQSxZQTlCakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBK0JBLEtBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBO0FBQUEsUUFFSixFQUFFO0FBRUZoRCxzQkFBYzRDLGFBQWE7QUFBQSxNQUM3QixTQUFTa0IsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLE1BQU10QyxPQUFPO0FBQUEsTUFDM0QsVUFBQztBQUNDWixxQkFBYSxLQUFLO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBRUEwQixvQkFBZ0I7QUFBQSxFQUNsQixHQUFHLENBQUN2QixhQUFhLENBQUM7QUFFbEIsUUFBTWlELG1CQUFtQkEsQ0FBQ0MsT0FBT25DLFVBQVU7QUFDekNHLGdCQUFZLENBQUNpQyxjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxLQUFLLEdBQUduQztBQUFBQSxJQUNYLEVBQUU7QUFFRlYsY0FBVSxDQUFDK0MsZ0JBQWdCO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRixLQUFLLEdBQUc7QUFBQSxJQUNYLEVBQUU7QUFBQSxFQUNKO0FBQ0EsUUFBTUcsd0JBQXdCQSxDQUFDSCxPQUFPbkMsVUFBVTtBQUM5Q00sc0JBQWtCLENBQUM4QixjQUFjO0FBQUEsTUFDL0IsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxLQUFLLEdBQUduQztBQUFBQSxJQUNYLEVBQUU7QUFFRlYsY0FBVSxFQUFFLEdBQUdELFFBQVEsQ0FBQzhDLEtBQUssR0FBRyxHQUFHLENBQUM7QUFBQSxFQUN0QztBQUVBLFFBQU1JLGVBQWUsT0FBT3hDLE1BQU07QUFDaENBLE1BQUV5QyxlQUFlO0FBRWpCLFFBQUk7QUFDRixZQUFNL0IsV0FBVyxNQUFNOUQsSUFBSThGLEtBQUsseUJBQXlCdkMsVUFBVTtBQUFBLFFBQ2pFd0MsU0FBUztBQUFBLFVBQ1AsZ0JBQWdCO0FBQUEsUUFDbEI7QUFBQSxNQUNGLENBQUM7QUFFRHhELHVCQUFpQixDQUFDeUQsU0FBU0EsT0FBTyxDQUFDO0FBQ25DbkQscUJBQWU7QUFBQSxRQUNiRyxNQUFNO0FBQUEsUUFDTkQsU0FBUztBQUFBLFFBQ1RELFlBQVk7QUFBQSxNQUNkLENBQUM7QUFDRG5CLG1CQUFhLEtBQUs7QUFDbEI2QixrQkFBWTtBQUFBLFFBQ1ZDLFlBQVk7QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNILFNBQVM0QixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sdUJBQXVCQSxLQUFLO0FBQzFDeEMscUJBQWU7QUFBQSxRQUNiRyxNQUFNO0FBQUEsUUFDTkQsU0FDRXNDLE9BQU92QixVQUFVRyxNQUFNbEIsV0FBVztBQUFBLFFBQ3BDRCxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNbUQsZUFBZSxPQUFPN0MsTUFBTTtBQUNoQ0EsTUFBRXlDLGVBQWU7QUFDakIsUUFBSTtBQUNGLFlBQU03RixJQUFJa0c7QUFBQUEsUUFDUiw0QkFBNEI5RCxvQkFBb0JtQyxHQUFHO0FBQUEsUUFDbkRiO0FBQUFBLFFBQ0E7QUFBQSxVQUNFcUMsU0FBUztBQUFBLFlBQ1AsZ0JBQWdCO0FBQUEsVUFDbEI7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBaEUseUJBQW1CLEtBQUs7QUFDeEJRLHVCQUFpQixDQUFDeUQsU0FBU0EsT0FBTyxDQUFDO0FBQ25DbkQscUJBQWU7QUFBQSxRQUNiRyxNQUFNO0FBQUEsUUFDTkQsU0FBUztBQUFBLFFBQ1RELFlBQVk7QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNILFNBQVN1QyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0seUJBQXlCQSxLQUFLO0FBQzVDeEMscUJBQWU7QUFBQSxRQUNiRyxNQUFNO0FBQUEsUUFDTkQsU0FBU3NDLE9BQU92QixVQUFVRyxNQUFNbEIsV0FBVztBQUFBLFFBQzNDRCxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNc0Msd0JBQXdCLE9BQU9lLFdBQVc7QUFDOUMsUUFBSTtBQUNGLFlBQU1yQyxXQUFXLE1BQU05RCxJQUFJK0QsSUFBSSwrQkFBK0JvQyxNQUFNLEVBQUU7QUFDdEVsRSxzQkFBZ0I2QixTQUFTRyxNQUFNQyxLQUFLO0FBQ3BDckMseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTd0QsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLElBQzlDO0FBQUEsRUFDRjtBQUVBLFFBQU1GLHdCQUF3QixPQUFPZ0IsV0FBVztBQUM5QyxRQUFJO0FBQ0YsWUFBTXJDLFdBQVcsTUFBTTlELElBQUkrRCxJQUFJLCtCQUErQm9DLE1BQU0sRUFBRTtBQUN0RXhDLHdCQUFrQjtBQUFBLFFBQ2hCRixZQUFZSyxTQUFTRyxNQUFNQyxPQUFPVDtBQUFBQSxNQUNwQyxDQUFDO0FBRURwQiw0QkFBc0J5QixTQUFTRyxNQUFNQyxLQUFLO0FBQzFDbkMseUJBQW1CLElBQUk7QUFDdkJZLGdCQUFVLENBQUMsQ0FBQztBQUFBLElBQ2QsU0FBUzBDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFJQSxRQUFNZSxvQkFBb0IsWUFBWTtBQUNwQyxRQUFJLENBQUNwRSxnQkFBZ0IsQ0FBQ0EsYUFBYXVDLElBQUs7QUFFeEMsUUFBSTtBQUNGLFlBQU12RSxJQUFJcUcsT0FBTyxrQ0FBa0NyRSxhQUFhdUMsR0FBRyxFQUFFO0FBRXJFaEQ7QUFBQUEsUUFBYyxDQUFDeUUsU0FDYkEsS0FBS00sT0FBTyxDQUFDQyxTQUFTQSxLQUFLaEMsUUFBUXZDLGFBQWF1QyxHQUFHO0FBQUEsTUFDckQ7QUFFQTFCLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBRURULHVCQUFpQixDQUFDeUQsU0FBU0EsT0FBTyxDQUFDO0FBQ25DbkUseUJBQW1CLEtBQUs7QUFDeEJJLHNCQUFnQixJQUFJO0FBQUEsSUFDdEIsU0FBU29ELE9BQU87QUFDZEMsY0FBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFDNUN4QyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaRSxNQUFNO0FBQUEsUUFDTkQsU0FBUztBQUFBLE1BQ1gsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTXlELFVBQVU7QUFBQSxJQUNkLEVBQUV2QixLQUFLLE1BQU13QixRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFeEIsS0FBSyxjQUFjd0IsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRXhCLEtBQUssVUFBVXdCLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBRWI7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsNkJBQTZCdEQ7QUFBQUEsVUFDN0IsWUFBWTtBQUFBO0FBQUEsUUFGZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFbUI7QUFBQSxNQUVuQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTVAsWUFBWUk7QUFBQUEsVUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsVUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUNtRCxVQUFVLEVBQUUsR0FBR0EsTUFBTWxELFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxRQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNRztBQUFBLE1BR0gsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ2IsaUNBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBCQUF5QiwyQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0Q7QUFBQSxVQUVsRDtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUyxNQUFNO0FBQ2JuQiw2QkFBYSxJQUFJO0FBQ2pCZ0IsMEJBQVUsQ0FBQyxDQUFDO0FBQUEsY0FDZDtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQXVHO0FBQUE7QUFBQSxZQUxuSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLGFBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVlBLEtBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFDQ3JCLFlBQVlvRixTQUFTLEtBQUssQ0FBQ3hFLFlBQzFCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixlQUFlaUQ7QUFBQUEsWUFDZixNQUFNMUUsYUFBYWEsWUFBWTJCLFVBQVU7QUFBQSxZQUN6QztBQUFBLFlBQ0Esa0JBQWtCLFNBQ2hCM0IsV0FBV29GLFNBQVMsSUFDaEJwRixXQUFXLENBQUMsRUFBRXFGLE9BQ2QsU0FDQXJGLFdBQVdBLFdBQVdvRixTQUFTLENBQUMsRUFBRUMsT0FDbEMsT0FBTztBQUFBO0FBQUEsVUFWZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXUyxJQUdUO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsU0FBU3JGLFdBQVdvRixVQUFVO0FBQUEsWUFDOUIsTUFBSztBQUFBO0FBQUEsVUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHbUI7QUFBQSxXQWxDdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFDQTtBQUFBLFNBcERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxREE7QUFBQSxJQUNBLHVCQUFDLFNBQU0sV0FBV2hGLFdBQVcsU0FBUyxNQUFNQyxhQUFhLEtBQUssR0FDNUQsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsNkJBQUMsUUFBRyxXQUFVLHdDQUF1Qyx5QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4RDtBQUFBLE1BQzlELHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVpRSxjQUFjLFlBQVUsTUFDNUQ7QUFBQSwrQkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFRO0FBQUEsY0FBZTtBQUFBO0FBQUEsZ0JBRVosdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQTtBQUFBO0FBQUEsWUFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxXQUFXLHFDQUFxQy9FLFVBQVUrRixNQUFNO0FBQUEsY0FDaEUsYUFBWTtBQUFBLGNBQ1osdUJBQXVCO0FBQUEsY0FDdkI7QUFBQSxjQUNBLE1BQUs7QUFBQSxjQUNMLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNDLFlBQVksRUFBRUMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsY0FFNUQsT0FBT3pELFVBQVVFLGNBQWN5RDtBQUFBQSxjQUMvQixVQUFVLENBQUM3RCxVQUFVa0MsaUJBQWlCLGNBQWNsQyxLQUFLO0FBQUEsY0FFeEQ7QUFBQSxnQkFDQztBQUFBLGdCQUNBO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQTtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0E7QUFBQSxjQUFXLEVBQ1hlO0FBQUFBLGdCQUFJLENBQUMrQyxZQUNMLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxRQUFRSCxZQUFZLEdBQ3JERyxxQkFEaUJBLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUE7QUFBQSxZQXhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUF5QkE7QUFBQSxhQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUNBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUMrRjtBQUFBO0FBQUEsVUFIM0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkNBO0FBQUEsU0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdEQSxLQWpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0RBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3JGO0FBQUFBLFFBQ1gsU0FBUyxNQUFNQyxtQkFBbUIsS0FBSztBQUFBLFFBRXZDLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsNEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVrRSxjQUFjLFlBQVUsTUFDNUQ7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWU7QUFBQTtBQUFBLG9CQUVaLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUo5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBRUMsV0FBVyxxQ0FBcUNwRixVQUFVK0YsTUFBTTtBQUFBLGtCQUNoRSxhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNDLFlBQVksRUFBRUMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU90RCxnQkFBZ0JELGNBQWN5RDtBQUFBQSxrQkFDckMsVUFBVSxDQUFDN0QsVUFDVHNDLHNCQUFzQixjQUFjdEMsS0FBSztBQUFBLGtCQUcxQztBQUFBLG9CQUNDO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLG9CQUNBO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLGtCQUFXLEVBQ1hlO0FBQUFBLG9CQUFJLENBQUMrQyxZQUNMLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxTQUNqQ0Esa0JBQVFILFlBQVksS0FESEcsU0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkExQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBMkJBO0FBQUEsaUJBbENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUNBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUMrRjtBQUFBO0FBQUEsY0FIM0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUE3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4Q0E7QUFBQSxhQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbURBO0FBQUE7QUFBQSxNQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF3REE7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXdkY7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsNkJBQW1CLEtBQUs7QUFDeEJJLDBCQUFnQixJQUFJO0FBQUEsUUFDdEI7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsNEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDRCxnQkFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsVUFBVSxDQUFDb0IsTUFBTTtBQUNmQSxrQkFBRXlDLGVBQWU7QUFDakJPLGtDQUFrQjtBQUFBLGNBQ3BCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLE9BQUUsV0FBVSx5QkFBd0I7QUFBQTtBQUFBLGtCQUNIO0FBQUEsa0JBQ2hDLHVCQUFDLFVBQUssV0FBVSwwQkFDYnBFLHVCQUFheUIsY0FEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUFPO0FBQUEscUJBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFNQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ3lGO0FBQUE7QUFBQSxrQkFIckc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUE7QUFBQTtBQUFBLFlBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXFCQTtBQUFBLGFBMUJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQTtBQUFBLE1BbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW9DQTtBQUFBLE9Bdk1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3TUEsS0F6TUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTBNQTtBQUVKO0FBQUUxQyxHQWhjSUQsWUFBVTtBQUFBc0csS0FBVnRHO0FBa2NOLGVBQWVBO0FBQVcsSUFBQXNHO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJNb2RhbCIsImFwaSIsIkRhdGFUYWJsZSIsIklucHV0IiwiU2VsZWN0IiwiRHJvcGRvd24iLCJCdXR0b24iLCJUYWJsZSIsIklvTWRNb3JlIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiQ2lyY3VsYXJMb2FkZXIiLCJDdXN0b21BbGVydERpYWxvZyIsIkxpbmsiLCJmaWVsZFNpemUiLCJEcmVhbUFzc2V0IiwiX3MiLCJhc3NldHMiLCJzZXRBc3NldHMiLCJzZWxlY3RlZEFzc2V0cyIsInNldFNlbGVjdGVkQXNzZXRzIiwibG9hZGluZyIsInNldExvYWRpbmciLCJUYWJsZUFzc2V0Iiwic2V0VGFibGVBc3NldCIsInNlYXJjaFRlcm0iLCJzZXRTZWFyY2hUZXJtIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsRGVsZXRlIiwic2V0U2hvd01vZGFsRGVsZXRlIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwiY3VycmVudEFzc2V0Iiwic2V0Q3VycmVudEFzc2V0IiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwiY3VycmVudFVwZGF0ZUFzc2V0Iiwic2V0Q3VycmVudFVwZGF0ZUFzc2V0IiwicmVsb2FkVHJpZ2dlciIsInNldFJlbG9hZFRyaWdnZXIiLCJkZWxldGVDb25maXJtYXRpb25UZXh0Iiwic2V0RGVsZXRlQ29uZmlybWF0aW9uVGV4dCIsImVycm9ycyIsInNldEVycm9ycyIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsIkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiYXNzZXRfdHlwZSIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJ1c2VFZmZlY3QiLCJmZXRjaERyZWFtQXNzZXQiLCJyZXNwb25zZSIsImdldCIsImFzc2V0RGF0YSIsImRhdGEiLCJhc3NldCIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJncm91cCIsImluZGV4IiwiX2lkIiwiaWQiLCJBcnJheSIsImlzQXJyYXkiLCJjaGFyQXQiLCJ0b1VwcGVyQ2FzZSIsInNsaWNlIiwiam9pbiIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwibGFiZWwiLCJoYW5kbGVVcGRhdGVNb2RhbE9wZW4iLCJoYW5kbGVEZWxldGVNb2RhbE9wZW4iLCJlcnJvciIsImNvbnNvbGUiLCJoYW5kbGVBbnREU2VsZWN0IiwiZmllbGQiLCJwcmV2RGF0YSIsInByZXZFcnJvcnMiLCJoYW5kbGVBbnRJbnB1dERTZWxlY3QiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsInBvc3QiLCJoZWFkZXJzIiwicHJldiIsImhhbmRsZVVwZGF0ZSIsInB1dCIsInVzZXJJZCIsImhhbmRsZURlbGV0ZUFzc2V0IiwiZGVsZXRlIiwiZmlsdGVyIiwiaXRlbSIsImNvbHVtbnMiLCJoZWFkZXIiLCJsZW5ndGgiLCJuYW1lIiwiaGVpZ2h0IiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ1bmRlZmluZWQiLCJyZWZUeXBlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRHJlYW1Bc3NldC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHsgSW5wdXQsIFNlbGVjdCwgRHJvcGRvd24sIEJ1dHRvbiwgVGFibGUgfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBJb01kTW9yZSB9IGZyb20gXCJyZWFjdC1pY29ucy9pb1wiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBmaWx0ZXJPcHRpb24gZnJvbSBcIi4uL2hlbHBlcnMvZmlsdGVyT3B0aW9uXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcblxyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuXHJcbmNvbnN0IERyZWFtQXNzZXQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2Fzc2V0cywgc2V0QXNzZXRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2VsZWN0ZWRBc3NldHMsIHNldFNlbGVjdGVkQXNzZXRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW1RhYmxlQXNzZXQsIHNldFRhYmxlQXNzZXRdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50QXNzZXQsIHNldEN1cnJlbnRBc3NldF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlQXNzZXQsIHNldEN1cnJlbnRVcGRhdGVBc3NldF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbZGVsZXRlQ29uZmlybWF0aW9uVGV4dCwgc2V0RGVsZXRlQ29uZmlybWF0aW9uVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gIH07XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBhc3NldF90eXBlOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFt1cGRhdGVGb3JtRGF0YSwgc2V0VXBkYXRlRm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgYXNzZXRfdHlwZTogXCJcIixcclxuICB9KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoRHJlYW1Bc3NldCA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2Fzc2V0L2dldC1hc3NldC1pbmZvXCIpO1xyXG4gICAgICAgIGNvbnN0IGFzc2V0RGF0YSA9IHJlc3BvbnNlLmRhdGE/LmFzc2V0IHx8IFtdO1xyXG5cclxuICAgICAgICBzZXRBc3NldHMoYXNzZXREYXRhKTtcclxuXHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IGFzc2V0RGF0YS5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgIF9pZDogZ3JvdXA/Ll9pZCxcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAvL2Fzc2V0X3R5cGU6IGdyb3VwPy5hc3NldF90eXBlLFxyXG4gICAgICAgICAgYXNzZXRfdHlwZTogQXJyYXkuaXNBcnJheShncm91cD8uYXNzZXRfdHlwZSlcclxuICAgICAgICAgICAgPyBncm91cC5hc3NldF90eXBlXHJcbiAgICAgICAgICAgICAgICAubWFwKCh0eXBlKSA9PiB0eXBlLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgdHlwZS5zbGljZSgxKSlcclxuICAgICAgICAgICAgICAgIC5qb2luKFwiLCBcIilcclxuICAgICAgICAgICAgOiBncm91cD8uYXNzZXRfdHlwZT8uY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgK1xyXG4gICAgICAgICAgICAgIGdyb3VwPy5hc3NldF90eXBlPy5zbGljZSgxKSxcclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZU1vZGFsT3Blbihncm91cD8uX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3Blbihncm91cD8uX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgXSxcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICksXHJcbiAgICAgICAgfSkpO1xyXG5cclxuICAgICAgICBzZXRUYWJsZUFzc2V0KGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBBc3NldCBkYXRhOlwiLCBlcnJvci5tZXNzYWdlKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGZldGNoRHJlYW1Bc3NldCgpO1xyXG4gIH0sIFtyZWxvYWRUcmlnZ2VyXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUFudERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbZmllbGRdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuXHJcbiAgICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7XHJcbiAgICAgIC4uLnByZXZFcnJvcnMsXHJcbiAgICAgIFtmaWVsZF06IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVBbnRJbnB1dERTZWxlY3QgPSAoZmllbGQsIHZhbHVlKSA9PiB7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbZmllbGRdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuXHJcbiAgICBzZXRFcnJvcnMoeyAuLi5lcnJvcnMsIFtmaWVsZF06IFwiXCIgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KFwiL2Fzc2V0L2FkZC1hc3NldC1pbmZvXCIsIGZvcm1EYXRhLCB7XHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICBtZXNzYWdlOiBcIkFzc2V0IEFkZGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgYXNzZXRfdHlwZTogXCJcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIEFzc2V0OlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgbWVzc2FnZTpcclxuICAgICAgICAgIGVycm9yPy5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWQuXCIsXHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgYC9hc3NldC91cGRhdGUtYXNzZXQtaW5mby8ke2N1cnJlbnRVcGRhdGVBc3NldD8uX2lkfWAsXHJcbiAgICAgICAgdXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfVxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgbWVzc2FnZTogXCJBc3NldCBVcGRhdGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIEFzc2V0OlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgbWVzc2FnZTogZXJyb3I/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiVXBkYXRlIGZhaWxlZFwiLFxyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL2Fzc2V0L2dldC1hc3NldC1pbmZvLWJ5LWlkLyR7dXNlcklkfWApO1xyXG4gICAgICBzZXRDdXJyZW50QXNzZXQocmVzcG9uc2UuZGF0YT8uYXNzZXQpO1xyXG4gICAgICBzZXRTaG93TW9kYWxEZWxldGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgQXNzZXQ6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9hc3NldC9nZXQtYXNzZXQtaW5mby1ieS1pZC8ke3VzZXJJZH1gKTtcclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgIGFzc2V0X3R5cGU6IHJlc3BvbnNlLmRhdGE/LmFzc2V0Py5hc3NldF90eXBlLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVBc3NldChyZXNwb25zZS5kYXRhPy5hc3NldCk7XHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBBc3NldDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG5cclxuICBcclxuICBjb25zdCBoYW5kbGVEZWxldGVBc3NldCA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghY3VycmVudEFzc2V0IHx8ICFjdXJyZW50QXNzZXQuX2lkKSByZXR1cm47XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL2Fzc2V0L2RlbGV0ZS1hc3NldC1pbmZvLWJ5LWlkLyR7Y3VycmVudEFzc2V0Ll9pZH1gKTtcclxuXHJcbiAgICAgIHNldFRhYmxlQXNzZXQoKHByZXYpID0+XHJcbiAgICAgICAgcHJldi5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uX2lkICE9PSBjdXJyZW50QXNzZXQuX2lkKVxyXG4gICAgICApO1xyXG5cclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJBc3NldCBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgc2V0Q3VycmVudEFzc2V0KG51bGwpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGFzc2V0OlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBkZWxldGUgYXNzZXQuXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImFzc2V0X3R5cGVcIiwgaGVhZGVyOiBcIkFzc2V0IE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIFxyXG4gICAgICAgICAgPE5hdmJhclxyXG4gICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e0dsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17YWxlcnRDb25maWcudmlzaWJpbGl0eX1cclxuICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT5cclxuICAgICAgICAgICAgICBzZXRBbGVydENvbmZpZygocHJldikgPT4gKHsgLi4ucHJldiwgdmlzaWJpbGl0eTogZmFsc2UgfSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3cgcC03XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1zZW1pYm9sZFwiPkRyZWFtIEFzc2V0PC9oMT5cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy12aW9sZXQtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLXZpb2xldC04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICArIEFkZCBBc3NldFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICB7VGFibGVBc3NldD8ubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGNhdGNoZXI9XCJfaWRcIlxyXG4gICAgICAgICAgICAgICAgdXBkYXRlSGFuZGxlcj17aGFuZGxlVXBkYXRlTW9kYWxPcGVufVxyXG4gICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlQXNzZXQsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BBc3NldC0ke1xyXG4gICAgICAgICAgICAgICAgICBUYWJsZUFzc2V0Lmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgICAgICAgICA/IFRhYmxlQXNzZXRbMF0ubmFtZSArXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIiB0byBcIiArXHJcbiAgICAgICAgICAgICAgICAgICAgICBUYWJsZUFzc2V0W1RhYmxlQXNzZXQubGVuZ3RoIC0gMV0ubmFtZVxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJlbXB0eVwiXHJcbiAgICAgICAgICAgICAgICB9LmNzdmB9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXJcclxuICAgICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgZmFpbHVyZT17VGFibGVBc3NldC5sZW5ndGggPD0gMH1cclxuICAgICAgICAgICAgICAgIGRhdGE9XCJBc3NldCBEYXRhXCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPE1vZGFsIGlzVmlzaWJsZT17c2hvd01vZGFsfSBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWwoZmFsc2UpfT5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5BZGQgQXNzZXQ8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwicmVmZXJyZWRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEFzc2V0IFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQXNzZXQgVHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImFzc2V0X3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5hc3NldF90eXBlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50RFNlbGVjdChcImFzc2V0X3R5cGVcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgIFwiQ2FyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJIb3VzZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiQmlrZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiVHJhdmVsXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJIZWFsdGhcIixcclxuICAgICAgICAgICAgICAgICAgICBcIkpld2VsbGVyeVwiLFxyXG4gICAgICAgICAgICAgICAgICBdLm1hcCgocmVmVHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17cmVmVHlwZX0gdmFsdWU9e3JlZlR5cGUudG9Mb3dlckNhc2UoKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cmVmVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctdmlvbGV0LTcwMCBob3ZlcjpiZy12aW9sZXQtODAwIGJvcmRlci0yIGJvcmRlci1ibGFja1xyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFNhdmUgQXNzZXRcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxVcGRhdGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBVcGRhdGUgQXNzZXRcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVVwZGF0ZX0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInJlZmVycmVkX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBBc3NldCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBBc3NldCBUeXBlXCJcclxuICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiYXNzZXRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmFzc2V0X3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudElucHV0RFNlbGVjdChcImFzc2V0X3R5cGVcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICBcIkNhclwiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiSG91c2VcIixcclxuICAgICAgICAgICAgICAgICAgICBcIkJpa2VcIixcclxuICAgICAgICAgICAgICAgICAgICBcIlRyYXZlbFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiSGVhbHRoXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJKZXdlbGxlcnlcIixcclxuICAgICAgICAgICAgICAgICAgXS5tYXAoKHJlZlR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3JlZlR5cGV9IHZhbHVlPXtyZWZUeXBlfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtyZWZUeXBlLnRvTG93ZXJDYXNlKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXgganVzdGlmeS1lbmRcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMS80IHRleHQtd2hpdGUgYmctdmlvbGV0LTcwMCBob3ZlcjpiZy12aW9sZXQtODAwIGJvcmRlci0yIGJvcmRlci1ibGFja1xyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFVwZGF0ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbERlbGV0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudEFzc2V0KG51bGwpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgRGVsZXRlIEFzc2V0XHJcbiAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgIHtjdXJyZW50QXNzZXQgJiYgKFxyXG4gICAgICAgICAgICAgIDxmb3JtXHJcbiAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVBc3NldCgpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGV7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXByaW1hcnlcIj5cclxuICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEFzc2V0LmFzc2V0X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPyBUaGlzIGFjdGlvbiBjYW5ub3QgYmUgdW5kb25lLlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwXHJcbiAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L01vZGFsPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEcmVhbUFzc2V0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRHJlYW1Bc3NldC5qc3gifQ==