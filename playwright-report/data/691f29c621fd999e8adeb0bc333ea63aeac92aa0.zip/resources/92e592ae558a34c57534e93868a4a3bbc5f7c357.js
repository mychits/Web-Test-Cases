import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ActivateCustomer.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import {
  Users,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  XCircle,
  Search,
  Filter,
  ChevronDown,
  UserX,
  TrendingUp,
  Calendar,
  Activity
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import {
  Select,
  Button,
  Modal,
  message,
  Tag,
  Space,
  Card,
  Row,
  Col,
  Statistic,
  Tooltip,
  Input,
  Table,
  DatePicker
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import {
  EyeOutlined,
  StopOutlined,
  ReloadOutlined,
  UserSwitchOutlined,
  PlayCircleOutlined,
  PauseCircleOutlined,
  SearchOutlined,
  UserOutlined,
  TeamOutlined,
  EnvironmentOutlined,
  InfoCircleOutlined,
  HistoryOutlined,
  BarChartOutlined,
  DownloadOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import __vite__cjsImport13_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport13_dayjs.__esModule ? __vite__cjsImport13_dayjs.default : __vite__cjsImport13_dayjs;
function ActivateCustomer() {
  _s();
  const [inactiveEnrollments, setInactiveEnrollments] = useState([]);
  const [filteredEnrollments, setFilteredEnrollments] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedEnrollment, setSelectedEnrollment] = useState(null);
  const [statusModalVisible, setStatusModalVisible] = useState(false);
  const [detailModalVisible, setDetailModalVisible] = useState(false);
  const [activating, setActivating] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [groups, setGroups] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [groupFilter, setGroupFilter] = useState("all");
  const [activationHistory, setActivationHistory] = useState([]);
  const [historyModalVisible, setHistoryModalVisible] = useState(false);
  const [activationStats, setActivationStats] = useState({
    totalActivated: 0,
    todayActivated: 0,
    weekActivated: 0,
    monthActivated: 0,
    lastActivation: null
  });
  const [dateRange, setDateRange] = useState(null);
  const [selectedStatsFilter, setSelectedStatsFilter] = useState("all");
  const fetchInactiveEnrollments = async () => {
    setLoading(true);
    try {
      const response = await api.get(
        "/v1/admin/enrolls/get-inactive-enrollments"
      );
      if (response.data && response.data.success) {
        setInactiveEnrollments(response.data.data);
        setFilteredEnrollments(response.data.data);
        console.log(
          "Total inactive enrollments fetched:",
          response.data.data.length
        );
      } else {
        setInactiveEnrollments([]);
        setFilteredEnrollments([]);
        message.warning("No inactive enrollments found");
      }
    } catch (error) {
      console.error("Error fetching inactive enrollments:", error);
      message.error(
        error.response?.data?.message || "Failed to fetch inactive enrollments"
      );
      setInactiveEnrollments([]);
      setFilteredEnrollments([]);
    } finally {
      setLoading(false);
    }
  };
  const fetchActivationHistory = async () => {
    try {
      const storedHistory = localStorage.getItem("activationHistory");
      if (storedHistory) {
        const history = JSON.parse(storedHistory);
        setActivationHistory(history);
        updateActivationStats(history);
      }
    } catch (error) {
      console.error("Error fetching activation history:", error);
    }
  };
  const updateActivationStats = (history) => {
    const now = /* @__PURE__ */ new Date();
    const today = new Date(now.setHours(0, 0, 0, 0));
    const weekAgo = new Date(now.setDate(now.getDate() - 7));
    const monthAgo = new Date(now.setMonth(now.getMonth() - 1));
    const todayActivations = history.filter(
      (item) => new Date(item.activatedAt) >= today
    ).length;
    const weekActivations = history.filter(
      (item) => new Date(item.activatedAt) >= weekAgo
    ).length;
    const monthActivations = history.filter(
      (item) => new Date(item.activatedAt) >= monthAgo
    ).length;
    const lastActivation = history.length > 0 ? history[history.length - 1] : null;
    setActivationStats({
      totalActivated: history.length,
      todayActivated: todayActivations,
      weekActivated: weekActivations,
      monthActivated: monthActivations,
      lastActivation
    });
  };
  const saveActivationToHistory = async (enrollment, adminUser) => {
    const activationRecord = {
      id: Date.now(),
      enrollmentId: enrollment._id,
      enrollCode: enrollment.enroll_code,
      customerName: enrollment.user_id?.full_name,
      phoneNumber: enrollment.user_id?.phone_number,
      groupName: enrollment.group_id?.group_name,
      ticket: enrollment.tickets,
      activatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      activatedBy: adminUser?.name || "Admin",
      status: "Activated"
    };
    const updatedHistory = [activationRecord, ...activationHistory];
    setActivationHistory(updatedHistory);
    localStorage.setItem("activationHistory", JSON.stringify(updatedHistory));
    updateActivationStats(updatedHistory);
  };
  useEffect(() => {
    fetchInactiveEnrollments();
    fetchActivationHistory();
  }, []);
  useEffect(() => {
    let filtered = [...inactiveEnrollments];
    if (groupFilter !== "all" && groupFilter) {
      filtered = filtered.filter(
        (enrollment) => enrollment.group_id?._id === groupFilter
      );
    }
    if (searchText.trim()) {
      const searchLower = searchText.toLowerCase();
      filtered = filtered.filter(
        (enrollment) => enrollment.user_id?.full_name?.toLowerCase().includes(searchLower) || enrollment.user_id?.phone_number?.includes(searchLower) || enrollment.tickets?.toString().includes(searchLower) || enrollment.enroll_code?.toLowerCase().includes(searchLower) || enrollment.group_id?.group_name?.toLowerCase().includes(searchLower)
      );
    }
    setFilteredEnrollments(filtered);
  }, [inactiveEnrollments, groupFilter, searchText]);
  const activateCustomer = async (enrollmentId) => {
    setActivating(true);
    try {
      const response = await api.get(
        `/v1/admin/enrolls/${enrollmentId}/payments/hold`
      );
      if (response.data && response.data.status === true) {
        const activatedEnrollment = inactiveEnrollments.find(
          (e) => e._id === enrollmentId
        );
        await saveActivationToHistory(activatedEnrollment, { name: "Admin" });
        message.success(
          response.data.message || "Customer activated successfully"
        );
        setInactiveEnrollments(
          (prevEnrollments) => prevEnrollments.filter(
            (enrollment) => enrollment._id !== enrollmentId
          )
        );
        setStatusModalVisible(false);
        setSelectedEnrollment(null);
        fetchInactiveEnrollments();
      } else {
        message.error(response.data?.message || "Failed to activate customer");
      }
    } catch (error) {
      console.error("Error activating customer:", error);
      message.error(
        error.response?.data?.message || "Failed to activate customer"
      );
    } finally {
      setActivating(false);
    }
  };
  const openActivationModal = (enrollment) => {
    setSelectedEnrollment(enrollment);
    setStatusModalVisible(true);
  };
  const openDetailModal = (enrollment) => {
    setSelectedEnrollment(enrollment);
    setDetailModalVisible(true);
  };
  const getStatusTag = (status) => {
    const statusConfig = {
      Inactive: {
        color: "error",
        bgColor: "bg-red-100",
        textColor: "text-red-800",
        icon: /* @__PURE__ */ jsxDEV(XCircle, { className: "w-3 h-3 mr-1" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
          lineNumber: 263,
          columnNumber: 15
        }, this),
        label: "Inactive"
      },
      Active: {
        color: "success",
        bgColor: "bg-green-100",
        textColor: "text-green-800",
        icon: /* @__PURE__ */ jsxDEV(CheckCircle, { className: "w-3 h-3 mr-1" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
          lineNumber: 270,
          columnNumber: 15
        }, this),
        label: "Active"
      }
    };
    const config = statusConfig[status] || statusConfig.Inactive;
    return /* @__PURE__ */ jsxDEV(
      "span",
      {
        className: `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bgColor} ${config.textColor}`,
        children: [
          config.icon,
          config.label
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
        lineNumber: 278,
        columnNumber: 7
      },
      this
    );
  };
  const historyColumns = [
    { key: "sl_no", header: "SL. NO", width: "60px" },
    { key: "activated_date", header: "Activation Date", width: "150px" },
    { key: "customer_name", header: "Customer Name", width: "200px" },
    { key: "phone_number", header: "Phone Number", width: "120px" },
    { key: "group_name", header: "Group Name", width: "200px" },
    { key: "ticket", header: "Ticket No", width: "80px" },
    { key: "enroll_code", header: "Enrollment Code", width: "150px" },
    { key: "activated_by", header: "Activated By", width: "120px" }
  ];
  const getFilteredHistory = () => {
    let filtered = [...activationHistory];
    if (selectedStatsFilter !== "all") {
      const now = /* @__PURE__ */ new Date();
      const today = new Date(now.setHours(0, 0, 0, 0));
      const weekAgo = new Date(now.setDate(now.getDate() - 7));
      const monthAgo = new Date(now.setMonth(now.getMonth() - 1));
      if (selectedStatsFilter === "today") {
        filtered = filtered.filter(
          (item) => new Date(item.activatedAt) >= today
        );
      } else if (selectedStatsFilter === "week") {
        filtered = filtered.filter(
          (item) => new Date(item.activatedAt) >= weekAgo
        );
      } else if (selectedStatsFilter === "month") {
        filtered = filtered.filter(
          (item) => new Date(item.activatedAt) >= monthAgo
        );
      }
    }
    if (dateRange && dateRange[0] && dateRange[1]) {
      filtered = filtered.filter((item) => {
        const itemDate = new Date(item.activatedAt);
        return itemDate >= dateRange[0].toDate() && itemDate <= dateRange[1].toDate();
      });
    }
    return filtered;
  };
  const historyTableData = getFilteredHistory().map((item, index) => ({
    key: item.id,
    sl_no: index + 1,
    activated_date: new Date(item.activatedAt).toLocaleString("en-IN"),
    customer_name: item.customerName,
    phone_number: item.phoneNumber,
    group_name: item.groupName,
    ticket: item.ticket,
    enroll_code: item.enrollCode,
    activated_by: item.activatedBy
  }));
  const columns = [
    { key: "sl_no", header: "SL. NO", width: "60px" },
    { key: "enroll_code", header: "Enrollment Code", width: "150px" },
    { key: "customer_name", header: "Customer Name", width: "200px" },
    { key: "phone_number", header: "Phone Number", width: "120px" },
    { key: "group_name", header: "Group Name", width: "200px" },
    { key: "ticket", header: "Ticket No", width: "80px" },
    { key: "enrollment_date", header: "Deactivated Date", width: "120px" },
    { key: "status", header: "Status", width: "100px" },
    { key: "action", header: "Actions", width: "150px" }
  ];
  const tableData = filteredEnrollments.map((enrollment, index) => ({
    key: enrollment._id,
    sl_no: index + 1,
    enroll_code: enrollment.enroll_code || "N/A",
    customer_name: enrollment.user_id?.full_name || "N/A",
    phone_number: enrollment.user_id?.phone_number || "N/A",
    group_name: enrollment.group_id?.group_name || "N/A",
    ticket: enrollment.tickets || "N/A",
    enrollment_date: enrollment.updatedAt ? new Date(enrollment.updatedAt).toLocaleDateString("en-IN") : "N/A",
    status: getStatusTag(enrollment.customer_status),
    action: /* @__PURE__ */ jsxDEV(Space, { size: "small", children: [
      /* @__PURE__ */ jsxDEV(Tooltip, { title: "View Details", children: /* @__PURE__ */ jsxDEV(
        Button,
        {
          type: "text",
          size: "small",
          icon: /* @__PURE__ */ jsxDEV(EyeOutlined, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
            lineNumber: 376,
            columnNumber: 17
          }, this),
          onClick: () => openDetailModal(enrollment)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
          lineNumber: 373,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
        lineNumber: 372,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Tooltip, { title: "Activate Customer", children: /* @__PURE__ */ jsxDEV(
        Button,
        {
          type: "primary",
          size: "small",
          icon: /* @__PURE__ */ jsxDEV(PlayCircleOutlined, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
            lineNumber: 384,
            columnNumber: 17
          }, this),
          onClick: () => openActivationModal(enrollment),
          className: "bg-green-500",
          loading: activating && selectedEnrollment?._id === enrollment._id,
          children: "Activate"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
          lineNumber: 381,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
        lineNumber: 380,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
      lineNumber: 371,
      columnNumber: 5
    }, this)
  }));
  const stats = {
    total: inactiveEnrollments.length
  };
  const uniqueGroups = [
    ...new Map(groups.map((group) => [group._id, group])).values()
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20 ", children: /* @__PURE__ */ jsxDEV("div", { className: "flex min-h-screen w-full bg-gray-50", children: [
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
      lineNumber: 407,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
        lineNumber: 409,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "p-6", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-2xl font-bold text-gray-900", children: "Inactive Customers Management" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
            lineNumber: 412,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-gray-600 mt-1", children: "View and manage customers with inactive status. Click Activate to restore their payments." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
            lineNumber: 415,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
          lineNumber: 411,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(BarChartOutlined, { className: "text-blue-500 text-lg" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 424,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("h3", { className: "text-base font-semibold text-gray-800", children: "Activation Statistics" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 425,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
              lineNumber: 423,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                icon: /* @__PURE__ */ jsxDEV(HistoryOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 430,
                  columnNumber: 25
                }, this),
                onClick: () => setHistoryModalVisible(true),
                className: "border-blue-500 text-blue-600",
                children: "View Activation History"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 429,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
            lineNumber: 422,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], className: "mb-6", children: [
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, lg: 6, children: /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm hover:shadow-md transition-all bg-red-50 border border-red-100", children: [
              /* @__PURE__ */ jsxDEV(
                Statistic,
                {
                  title: "Currently Inactive",
                  value: stats.total,
                  prefix: /* @__PURE__ */ jsxDEV(UserX, { className: "text-red-500", size: 20 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 443,
                    columnNumber: 31
                  }, this),
                  valueStyle: {
                    color: "#ef4444",
                    fontSize: "28px",
                    fontWeight: "bold"
                  }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 440,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-xs text-gray-500", children: "Customers awaiting activation" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 450,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
              lineNumber: 439,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
              lineNumber: 438,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, lg: 6, children: /* @__PURE__ */ jsxDEV(
              Card,
              {
                className: "shadow-sm hover:shadow-md transition-all cursor-pointer bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200",
                onClick: () => {
                  setSelectedStatsFilter("all");
                  setHistoryModalVisible(true);
                },
                children: [
                  /* @__PURE__ */ jsxDEV(
                    Statistic,
                    {
                      title: "Total Activated",
                      value: activationStats.totalActivated,
                      prefix: /* @__PURE__ */ jsxDEV(TrendingUp, { className: "text-green-500", size: 20 }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                        lineNumber: 468,
                        columnNumber: 23
                      }, this),
                      valueStyle: {
                        color: "#22c55e",
                        fontSize: "28px",
                        fontWeight: "bold"
                      }
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                      lineNumber: 464,
                      columnNumber: 21
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-xs text-gray-500", children: "All time activations" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 476,
                    columnNumber: 21
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 457,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
              lineNumber: 456,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
            lineNumber: 437,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
          lineNumber: 421,
          columnNumber: 13
        }, this),
        loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
          lineNumber: 486,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
          lineNumber: 485,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV(Card, { className: "shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-4 flex justify-between items-center", children: [
            /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: [
              "Showing ",
              filteredEnrollments.length,
              " of",
              " ",
              inactiveEnrollments.length,
              " inactive customers"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
              lineNumber: 492,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
              lineNumber: 491,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                icon: /* @__PURE__ */ jsxDEV(ReloadOutlined, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 498,
                  columnNumber: 25
                }, this),
                onClick: fetchInactiveEnrollments,
                children: "Refresh Data"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 497,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
            lineNumber: 490,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: tableData,
              columns,
              exportedPdfName: "Inactive_Customers_Report",
              exportedFileName: "inactive_customers_report.csv",
              printHeaderKeys: [
                "Total Inactive Customers",
                "Report Date",
                "Report Type"
              ],
              printHeaderValues: [
                stats.total,
                (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN"),
                "Inactive Customers List"
              ]
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
              lineNumber: 505,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
          lineNumber: 489,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Modal,
          {
            title: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(HistoryOutlined, { className: "text-blue-600 text-xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 528,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 527,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-gray-900", children: "Activation History" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 531,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mt-0.5", children: "Track all customer activations" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 534,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 530,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
              lineNumber: 526,
              columnNumber: 15
            }, this),
            open: historyModalVisible,
            onCancel: () => {
              setHistoryModalVisible(false);
              setSelectedStatsFilter("all");
              setDateRange(null);
            },
            width: 1e3,
            footer: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  onClick: () => {
                    setHistoryModalVisible(false);
                    setSelectedStatsFilter("all");
                    setDateRange(null);
                  },
                  children: "Close"
                },
                "close",
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 548,
                  columnNumber: 15
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  type: "primary",
                  icon: /* @__PURE__ */ jsxDEV(DownloadOutlined, {}, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 561,
                    columnNumber: 23
                  }, this),
                  onClick: () => {
                    const csvData = historyTableData.map((item) => ({
                      "SL No": item.sl_no,
                      "Activation Date": item.activated_date,
                      "Customer Name": item.customer_name,
                      "Phone Number": item.phone_number,
                      "Group Name": item.group_name,
                      Ticket: item.ticket,
                      "Enrollment Code": item.enroll_code,
                      "Activated By": item.activated_by
                    }));
                    message.success("Export feature coming soon");
                  },
                  children: "Export History"
                },
                "export",
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 558,
                  columnNumber: 15
                },
                this
              )
            ],
            children: /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4 mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
                  /* @__PURE__ */ jsxDEV("label", { className: "block text-xs font-medium text-gray-700 mb-1", children: "Filter by Date Range" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 583,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV(
                    DatePicker.RangePicker,
                    {
                      className: "w-full",
                      onChange: (dates) => setDateRange(dates),
                      placeholder: ["Start Date", "End Date"]
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                      lineNumber: 586,
                      columnNumber: 21
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 582,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-end", children: /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    onClick: () => {
                      setDateRange(null);
                      setSelectedStatsFilter("all");
                    },
                    children: "Clear Filters"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 593,
                    columnNumber: 21
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 592,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 581,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-4 gap-3 mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 rounded-lg p-2 text-center", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Total Records" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 606,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-green-600", children: getFilteredHistory().length }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 607,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 605,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 rounded-lg p-2 text-center", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Unique Groups" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 612,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-blue-600", children: new Set(getFilteredHistory().map((h) => h.groupName)).size }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 613,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 611,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50 rounded-lg p-2 text-center", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Unique Customers" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 621,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-purple-600", children: new Set(getFilteredHistory().map((h) => h.customerName)).size }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 622,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 620,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50 rounded-lg p-2 text-center", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: "Last 7 Days" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 630,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-orange-600", children: getFilteredHistory().filter((h) => {
                    const weekAgo = /* @__PURE__ */ new Date();
                    weekAgo.setDate(weekAgo.getDate() - 7);
                    return new Date(h.activatedAt) >= weekAgo;
                  }).length }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 631,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 629,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 604,
                columnNumber: 17
              }, this),
              historyTableData.length > 0 ? /* @__PURE__ */ jsxDEV(
                DataTable,
                {
                  data: historyTableData,
                  columns: historyColumns,
                  exportedPdfName: "Activation_History_Report",
                  exportedFileName: "activation_history.csv"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 644,
                  columnNumber: 17
                },
                this
              ) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12 bg-gray-50 rounded-lg", children: [
                /* @__PURE__ */ jsxDEV(HistoryOutlined, { className: "text-5xl text-gray-300 mb-3" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 652,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "No activation history found" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 653,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-400 mt-1", children: "Activations will appear here when you activate customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 654,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 651,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
              lineNumber: 580,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
            lineNumber: 524,
            columnNumber: 13
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Modal,
          {
            open: statusModalVisible,
            onCancel: () => {
              setStatusModalVisible(false);
              setSelectedEnrollment(null);
            },
            width: 550,
            footer: null,
            centered: true,
            bodyStyle: { padding: 0 },
            children: selectedEnrollment && /* @__PURE__ */ jsxDEV("div", { className: "relative overflow-hidden", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-100 to-emerald-100 rounded-full opacity-50 -mr-16 -mt-16" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 675,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-green-100 to-emerald-100 rounded-full opacity-50 -ml-12 -mb-12" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 676,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative p-6", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "text-center mb-6", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto shadow-lg mb-4", children: /* @__PURE__ */ jsxDEV(PlayCircleOutlined, { className: "text-4xl text-white" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 681,
                    columnNumber: 25
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 680,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: "Confirm Activation" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 683,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Please review the customer details below" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 686,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 679,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-xl p-4 mb-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-3", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-medium text-gray-500 uppercase", children: "Customer Information" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                      lineNumber: 693,
                      columnNumber: 25
                    }, this),
                    getStatusTag(selectedEnrollment.customer_status)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 692,
                    columnNumber: 23
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "space-y-2", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Full Name:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                        lineNumber: 700,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-900", children: selectedEnrollment.user_id?.full_name }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                        lineNumber: 703,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                      lineNumber: 699,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Phone Number:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                        lineNumber: 708,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-900", children: selectedEnrollment.user_id?.phone_number }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                        lineNumber: 711,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                      lineNumber: 707,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Group Name:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                        lineNumber: 716,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-900", children: selectedEnrollment.group_id?.group_name }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                        lineNumber: 719,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                      lineNumber: 715,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Ticket Number:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                        lineNumber: 724,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-900", children: selectedEnrollment.tickets }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                        lineNumber: 727,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                      lineNumber: 723,
                      columnNumber: 25
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-gray-600", children: "Enrollment Code:" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                        lineNumber: 732,
                        columnNumber: 27
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-900", children: selectedEnrollment.enroll_code || "N/A" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                        lineNumber: 735,
                        columnNumber: 27
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                      lineNumber: 731,
                      columnNumber: 25
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 698,
                    columnNumber: 23
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 691,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 rounded-lg p-3 mb-4 border border-blue-100", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-2", children: [
                  /* @__PURE__ */ jsxDEV(InfoCircleOutlined, { className: "text-blue-500 text-sm mt-0.5" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 744,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-blue-800", children: [
                    /* @__PURE__ */ jsxDEV("strong", { children: "Note:" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                      lineNumber: 747,
                      columnNumber: 29
                    }, this),
                    " Activating this customer will restore all payment capabilities and allow them to participate in future auctions."
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 746,
                    columnNumber: 27
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                    lineNumber: 745,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 743,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 742,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 mt-6", children: [
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      onClick: () => {
                        setStatusModalVisible(false);
                        setSelectedEnrollment(null);
                      },
                      className: "flex-1",
                      size: "large",
                      children: "Cancel"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                      lineNumber: 756,
                      columnNumber: 23
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Button,
                    {
                      type: "primary",
                      icon: /* @__PURE__ */ jsxDEV(PlayCircleOutlined, {}, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                        lineNumber: 768,
                        columnNumber: 29
                      }, this),
                      loading: activating,
                      onClick: () => activateCustomer(selectedEnrollment._id),
                      className: "flex-1 bg-green-600 hover:bg-green-700",
                      size: "large",
                      children: "Activate Customer"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                      lineNumber: 766,
                      columnNumber: 23
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                  lineNumber: 755,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
                lineNumber: 678,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
              lineNumber: 674,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
            lineNumber: 662,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
        lineNumber: 410,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
      lineNumber: 408,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
    lineNumber: 406,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx",
    lineNumber: 405,
    columnNumber: 5
  }, this);
}
_s(ActivateCustomer, "cNUfenSfWAcPnV6/2HVMth7qSPM=");
_c = ActivateCustomer;
export default ActivateCustomer;
var _c;
$RefreshReg$(_c, "ActivateCustomer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/ActivateCustomer.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc1FjOzJCQXRRZDtBQUFnQkEsTUFBVUMsY0FBUyxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xELFNBQVNDLFlBQVk7QUFDckIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxhQUFhO0FBQ3BCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsV0FBVztBQUVsQixTQUFTQyxtQkFBbUI7QUFBQUMsS0FBQTtBQUMxQixRQUFNLENBQUNDLHFCQUFxQkMsc0JBQXNCLElBQUlwRCxTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDcUQscUJBQXFCQyxzQkFBc0IsSUFBSXRELFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUN1RCxTQUFTQyxVQUFVLElBQUl4RCxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDeUQsb0JBQW9CQyxxQkFBcUIsSUFBSTFELFNBQVMsSUFBSTtBQUNqRSxRQUFNLENBQUMyRCxvQkFBb0JDLHFCQUFxQixJQUFJNUQsU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQzZELG9CQUFvQkMscUJBQXFCLElBQUk5RCxTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDK0QsWUFBWUMsYUFBYSxJQUFJaEUsU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQ2lFLGVBQWVDLGdCQUFnQixJQUFJbEUsU0FBUyxJQUFJO0FBQ3ZELFFBQU0sQ0FBQ21FLFFBQVFDLFNBQVMsSUFBSXBFLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNxRSxZQUFZQyxhQUFhLElBQUl0RSxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDdUUsYUFBYUMsY0FBYyxJQUFJeEUsU0FBUyxLQUFLO0FBRXBELFFBQU0sQ0FBQ3lFLG1CQUFtQkMsb0JBQW9CLElBQUkxRSxTQUFTLEVBQUU7QUFDN0QsUUFBTSxDQUFDMkUscUJBQXFCQyxzQkFBc0IsSUFBSTVFLFNBQVMsS0FBSztBQUNwRSxRQUFNLENBQUM2RSxpQkFBaUJDLGtCQUFrQixJQUFJOUUsU0FBUztBQUFBLElBQ3JEK0UsZ0JBQWdCO0FBQUEsSUFDaEJDLGdCQUFnQjtBQUFBLElBQ2hCQyxlQUFlO0FBQUEsSUFDZkMsZ0JBQWdCO0FBQUEsSUFDaEJDLGdCQUFnQjtBQUFBLEVBQ2xCLENBQUM7QUFDRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXJGLFNBQVMsSUFBSTtBQUMvQyxRQUFNLENBQUNzRixxQkFBcUJDLHNCQUFzQixJQUFJdkYsU0FBUyxLQUFLO0FBRXBFLFFBQU13RiwyQkFBMkIsWUFBWTtBQUMzQ2hDLGVBQVcsSUFBSTtBQUNmLFFBQUk7QUFDRixZQUFNaUMsV0FBVyxNQUFNNUMsSUFBSTZDO0FBQUFBLFFBQ3pCO0FBQUEsTUFDRjtBQUNBLFVBQUlELFNBQVNFLFFBQVFGLFNBQVNFLEtBQUtDLFNBQVM7QUFDMUN4QywrQkFBdUJxQyxTQUFTRSxLQUFLQSxJQUFJO0FBQ3pDckMsK0JBQXVCbUMsU0FBU0UsS0FBS0EsSUFBSTtBQUN6Q0UsZ0JBQVFDO0FBQUFBLFVBQ047QUFBQSxVQUNBTCxTQUFTRSxLQUFLQSxLQUFLSTtBQUFBQSxRQUNyQjtBQUFBLE1BQ0YsT0FBTztBQUNMM0MsK0JBQXVCLEVBQUU7QUFDekJFLCtCQUF1QixFQUFFO0FBQ3pCbEMsZ0JBQVE0RSxRQUFRLCtCQUErQjtBQUFBLE1BQ2pEO0FBQUEsSUFDRixTQUFTQyxPQUFPO0FBQ2RKLGNBQVFJLE1BQU0sd0NBQXdDQSxLQUFLO0FBQzNEN0UsY0FBUTZFO0FBQUFBLFFBQ05BLE1BQU1SLFVBQVVFLE1BQU12RSxXQUFXO0FBQUEsTUFDbkM7QUFDQWdDLDZCQUF1QixFQUFFO0FBQ3pCRSw2QkFBdUIsRUFBRTtBQUFBLElBQzNCLFVBQUM7QUFDQ0UsaUJBQVcsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFDRjtBQUVBLFFBQU0wQyx5QkFBeUIsWUFBWTtBQUN6QyxRQUFJO0FBQ0YsWUFBTUMsZ0JBQWdCQyxhQUFhQyxRQUFRLG1CQUFtQjtBQUM5RCxVQUFJRixlQUFlO0FBQ2pCLGNBQU1HLFVBQVVDLEtBQUtDLE1BQU1MLGFBQWE7QUFDeEN6Qiw2QkFBcUI0QixPQUFPO0FBQzVCRyw4QkFBc0JILE9BQU87QUFBQSxNQUMvQjtBQUFBLElBRUYsU0FBU0wsT0FBTztBQUNkSixjQUFRSSxNQUFNLHNDQUFzQ0EsS0FBSztBQUFBLElBQzNEO0FBQUEsRUFDRjtBQUVBLFFBQU1RLHdCQUF3QkEsQ0FBQ0gsWUFBWTtBQUN6QyxVQUFNSSxNQUFNLG9CQUFJQyxLQUFLO0FBQ3JCLFVBQU1DLFFBQVEsSUFBSUQsS0FBS0QsSUFBSUcsU0FBUyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUM7QUFDL0MsVUFBTUMsVUFBVSxJQUFJSCxLQUFLRCxJQUFJSyxRQUFRTCxJQUFJTSxRQUFRLElBQUksQ0FBQyxDQUFDO0FBQ3ZELFVBQU1DLFdBQVcsSUFBSU4sS0FBS0QsSUFBSVEsU0FBU1IsSUFBSVMsU0FBUyxJQUFJLENBQUMsQ0FBQztBQUUxRCxVQUFNQyxtQkFBbUJkLFFBQVFlO0FBQUFBLE1BQy9CLENBQUNDLFNBQVMsSUFBSVgsS0FBS1csS0FBS0MsV0FBVyxLQUFLWDtBQUFBQSxJQUMxQyxFQUFFYjtBQUNGLFVBQU15QixrQkFBa0JsQixRQUFRZTtBQUFBQSxNQUM5QixDQUFDQyxTQUFTLElBQUlYLEtBQUtXLEtBQUtDLFdBQVcsS0FBS1Q7QUFBQUEsSUFDMUMsRUFBRWY7QUFDRixVQUFNMEIsbUJBQW1CbkIsUUFBUWU7QUFBQUEsTUFDL0IsQ0FBQ0MsU0FBUyxJQUFJWCxLQUFLVyxLQUFLQyxXQUFXLEtBQUtOO0FBQUFBLElBQzFDLEVBQUVsQjtBQUNGLFVBQU1aLGlCQUNKbUIsUUFBUVAsU0FBUyxJQUFJTyxRQUFRQSxRQUFRUCxTQUFTLENBQUMsSUFBSTtBQUVyRGpCLHVCQUFtQjtBQUFBLE1BQ2pCQyxnQkFBZ0J1QixRQUFRUDtBQUFBQSxNQUN4QmYsZ0JBQWdCb0M7QUFBQUEsTUFDaEJuQyxlQUFldUM7QUFBQUEsTUFDZnRDLGdCQUFnQnVDO0FBQUFBLE1BQ2hCdEM7QUFBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVBLFFBQU11QywwQkFBMEIsT0FBT0MsWUFBWUMsY0FBYztBQUMvRCxVQUFNQyxtQkFBbUI7QUFBQSxNQUN2QkMsSUFBSW5CLEtBQUtELElBQUk7QUFBQSxNQUNicUIsY0FBY0osV0FBV0s7QUFBQUEsTUFDekJDLFlBQVlOLFdBQVdPO0FBQUFBLE1BQ3ZCQyxjQUFjUixXQUFXUyxTQUFTQztBQUFBQSxNQUNsQ0MsYUFBYVgsV0FBV1MsU0FBU0c7QUFBQUEsTUFDakNDLFdBQVdiLFdBQVdjLFVBQVVDO0FBQUFBLE1BQ2hDQyxRQUFRaEIsV0FBV2lCO0FBQUFBLE1BQ25CckIsY0FBYSxvQkFBSVosS0FBSyxHQUFFa0MsWUFBWTtBQUFBLE1BQ3BDQyxhQUFhbEIsV0FBV21CLFFBQVE7QUFBQSxNQUNoQ0MsUUFBUTtBQUFBLElBQ1Y7QUFFQSxVQUFNQyxpQkFBaUIsQ0FBQ3BCLGtCQUFrQixHQUFHcEQsaUJBQWlCO0FBQzlEQyx5QkFBcUJ1RSxjQUFjO0FBRW5DN0MsaUJBQWE4QyxRQUFRLHFCQUFxQjNDLEtBQUs0QyxVQUFVRixjQUFjLENBQUM7QUFFeEV4QywwQkFBc0J3QyxjQUFjO0FBQUEsRUFHdEM7QUFFQWhKLFlBQVUsTUFBTTtBQUNkdUYsNkJBQXlCO0FBQ3pCVSwyQkFBdUI7QUFBQSxFQUN6QixHQUFHLEVBQUU7QUFFTGpHLFlBQVUsTUFBTTtBQUNkLFFBQUltSixXQUFXLENBQUMsR0FBR2pHLG1CQUFtQjtBQUV0QyxRQUFJb0IsZ0JBQWdCLFNBQVNBLGFBQWE7QUFDeEM2RSxpQkFBV0EsU0FBUy9CO0FBQUFBLFFBQ2xCLENBQUNNLGVBQWVBLFdBQVdjLFVBQVVULFFBQVF6RDtBQUFBQSxNQUMvQztBQUFBLElBQ0Y7QUFFQSxRQUFJRixXQUFXZ0YsS0FBSyxHQUFHO0FBQ3JCLFlBQU1DLGNBQWNqRixXQUFXa0YsWUFBWTtBQUMzQ0gsaUJBQVdBLFNBQVMvQjtBQUFBQSxRQUNsQixDQUFDTSxlQUNDQSxXQUFXUyxTQUFTQyxXQUFXa0IsWUFBWSxFQUFFQyxTQUFTRixXQUFXLEtBQ2pFM0IsV0FBV1MsU0FBU0csY0FBY2lCLFNBQVNGLFdBQVcsS0FDdEQzQixXQUFXaUIsU0FBU2EsU0FBUyxFQUFFRCxTQUFTRixXQUFXLEtBQ25EM0IsV0FBV08sYUFBYXFCLFlBQVksRUFBRUMsU0FBU0YsV0FBVyxLQUMxRDNCLFdBQVdjLFVBQVVDLFlBQVlhLFlBQVksRUFBRUMsU0FBU0YsV0FBVztBQUFBLE1BQ3ZFO0FBQUEsSUFDRjtBQUVBaEcsMkJBQXVCOEYsUUFBUTtBQUFBLEVBQ2pDLEdBQUcsQ0FBQ2pHLHFCQUFxQm9CLGFBQWFGLFVBQVUsQ0FBQztBQUdqRCxRQUFNcUYsbUJBQW1CLE9BQU8zQixpQkFBaUI7QUFDL0MvRCxrQkFBYyxJQUFJO0FBQ2xCLFFBQUk7QUFDRixZQUFNeUIsV0FBVyxNQUFNNUMsSUFBSTZDO0FBQUFBLFFBQ3pCLHFCQUFxQnFDLFlBQVk7QUFBQSxNQUNuQztBQUVBLFVBQUl0QyxTQUFTRSxRQUFRRixTQUFTRSxLQUFLcUQsV0FBVyxNQUFNO0FBQ2xELGNBQU1XLHNCQUFzQnhHLG9CQUFvQnlHO0FBQUFBLFVBQzlDLENBQUNDLE1BQU1BLEVBQUU3QixRQUFRRDtBQUFBQSxRQUNuQjtBQUVBLGNBQU1MLHdCQUF3QmlDLHFCQUFxQixFQUFFWixNQUFNLFFBQVEsQ0FBQztBQUVwRTNILGdCQUFRd0U7QUFBQUEsVUFDTkgsU0FBU0UsS0FBS3ZFLFdBQVc7QUFBQSxRQUMzQjtBQUVBZ0M7QUFBQUEsVUFBdUIsQ0FBQzBHLG9CQUN0QkEsZ0JBQWdCekM7QUFBQUEsWUFDZCxDQUFDTSxlQUFlQSxXQUFXSyxRQUFRRDtBQUFBQSxVQUNyQztBQUFBLFFBQ0Y7QUFFQW5FLDhCQUFzQixLQUFLO0FBQzNCRiw4QkFBc0IsSUFBSTtBQUUxQjhCLGlDQUF5QjtBQUFBLE1BQzNCLE9BQU87QUFDTHBFLGdCQUFRNkUsTUFBTVIsU0FBU0UsTUFBTXZFLFdBQVcsNkJBQTZCO0FBQUEsTUFDdkU7QUFBQSxJQUNGLFNBQVM2RSxPQUFPO0FBQ2RKLGNBQVFJLE1BQU0sOEJBQThCQSxLQUFLO0FBQ2pEN0UsY0FBUTZFO0FBQUFBLFFBQ05BLE1BQU1SLFVBQVVFLE1BQU12RSxXQUFXO0FBQUEsTUFDbkM7QUFBQSxJQUNGLFVBQUM7QUFDQzRDLG9CQUFjLEtBQUs7QUFBQSxJQUNyQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNK0Ysc0JBQXNCQSxDQUFDcEMsZUFBZTtBQUMxQ2pFLDBCQUFzQmlFLFVBQVU7QUFDaEMvRCwwQkFBc0IsSUFBSTtBQUFBLEVBQzVCO0FBRUEsUUFBTW9HLGtCQUFrQkEsQ0FBQ3JDLGVBQWU7QUFDdENqRSwwQkFBc0JpRSxVQUFVO0FBQ2hDN0QsMEJBQXNCLElBQUk7QUFBQSxFQUM1QjtBQUVBLFFBQU1tRyxlQUFlQSxDQUFDakIsV0FBVztBQUMvQixVQUFNa0IsZUFBZTtBQUFBLE1BQ25CQyxVQUFVO0FBQUEsUUFDUkMsT0FBTztBQUFBLFFBQ1BDLFNBQVM7QUFBQSxRQUNUQyxXQUFXO0FBQUEsUUFDWEMsTUFBTSx1QkFBQyxXQUFRLFdBQVUsa0JBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUM7QUFBQSxRQUN2Q0MsT0FBTztBQUFBLE1BQ1Q7QUFBQSxNQUNBQyxRQUFRO0FBQUEsUUFDTkwsT0FBTztBQUFBLFFBQ1BDLFNBQVM7QUFBQSxRQUNUQyxXQUFXO0FBQUEsUUFDWEMsTUFBTSx1QkFBQyxlQUFZLFdBQVUsa0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUM7QUFBQSxRQUMzQ0MsT0FBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsVUFBTUUsU0FBU1IsYUFBYWxCLE1BQU0sS0FBS2tCLGFBQWFDO0FBRXBELFdBQ0U7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVcsMkVBQTJFTyxPQUFPTCxPQUFPLElBQUlLLE9BQU9KLFNBQVM7QUFBQSxRQUV2SEk7QUFBQUEsaUJBQU9IO0FBQUFBLFVBQ1BHLE9BQU9GO0FBQUFBO0FBQUFBO0FBQUFBLE1BSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBS0E7QUFBQSxFQUVKO0FBRUEsUUFBTUcsaUJBQWlCO0FBQUEsSUFDckIsRUFBRUMsS0FBSyxTQUFTQyxRQUFRLFVBQVVDLE9BQU8sT0FBTztBQUFBLElBQ2hELEVBQUVGLEtBQUssa0JBQWtCQyxRQUFRLG1CQUFtQkMsT0FBTyxRQUFRO0FBQUEsSUFDbkUsRUFBRUYsS0FBSyxpQkFBaUJDLFFBQVEsaUJBQWlCQyxPQUFPLFFBQVE7QUFBQSxJQUNoRSxFQUFFRixLQUFLLGdCQUFnQkMsUUFBUSxnQkFBZ0JDLE9BQU8sUUFBUTtBQUFBLElBQzlELEVBQUVGLEtBQUssY0FBY0MsUUFBUSxjQUFjQyxPQUFPLFFBQVE7QUFBQSxJQUMxRCxFQUFFRixLQUFLLFVBQVVDLFFBQVEsYUFBYUMsT0FBTyxPQUFPO0FBQUEsSUFDcEQsRUFBRUYsS0FBSyxlQUFlQyxRQUFRLG1CQUFtQkMsT0FBTyxRQUFRO0FBQUEsSUFDaEUsRUFBRUYsS0FBSyxnQkFBZ0JDLFFBQVEsZ0JBQWdCQyxPQUFPLFFBQVE7QUFBQSxFQUFDO0FBR2pFLFFBQU1DLHFCQUFxQkEsTUFBTTtBQUMvQixRQUFJM0IsV0FBVyxDQUFDLEdBQUczRSxpQkFBaUI7QUFFcEMsUUFBSWEsd0JBQXdCLE9BQU87QUFDakMsWUFBTW9CLE1BQU0sb0JBQUlDLEtBQUs7QUFDckIsWUFBTUMsUUFBUSxJQUFJRCxLQUFLRCxJQUFJRyxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQztBQUMvQyxZQUFNQyxVQUFVLElBQUlILEtBQUtELElBQUlLLFFBQVFMLElBQUlNLFFBQVEsSUFBSSxDQUFDLENBQUM7QUFDdkQsWUFBTUMsV0FBVyxJQUFJTixLQUFLRCxJQUFJUSxTQUFTUixJQUFJUyxTQUFTLElBQUksQ0FBQyxDQUFDO0FBRTFELFVBQUk3Qix3QkFBd0IsU0FBUztBQUNuQzhELG1CQUFXQSxTQUFTL0I7QUFBQUEsVUFDbEIsQ0FBQ0MsU0FBUyxJQUFJWCxLQUFLVyxLQUFLQyxXQUFXLEtBQUtYO0FBQUFBLFFBQzFDO0FBQUEsTUFDRixXQUFXdEIsd0JBQXdCLFFBQVE7QUFDekM4RCxtQkFBV0EsU0FBUy9CO0FBQUFBLFVBQ2xCLENBQUNDLFNBQVMsSUFBSVgsS0FBS1csS0FBS0MsV0FBVyxLQUFLVDtBQUFBQSxRQUMxQztBQUFBLE1BQ0YsV0FBV3hCLHdCQUF3QixTQUFTO0FBQzFDOEQsbUJBQVdBLFNBQVMvQjtBQUFBQSxVQUNsQixDQUFDQyxTQUFTLElBQUlYLEtBQUtXLEtBQUtDLFdBQVcsS0FBS047QUFBQUEsUUFDMUM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBLFFBQUk3QixhQUFhQSxVQUFVLENBQUMsS0FBS0EsVUFBVSxDQUFDLEdBQUc7QUFDN0NnRSxpQkFBV0EsU0FBUy9CLE9BQU8sQ0FBQ0MsU0FBUztBQUNuQyxjQUFNMEQsV0FBVyxJQUFJckUsS0FBS1csS0FBS0MsV0FBVztBQUMxQyxlQUNFeUQsWUFBWTVGLFVBQVUsQ0FBQyxFQUFFNkYsT0FBTyxLQUFLRCxZQUFZNUYsVUFBVSxDQUFDLEVBQUU2RixPQUFPO0FBQUEsTUFFekUsQ0FBQztBQUFBLElBQ0g7QUFFQSxXQUFPN0I7QUFBQUEsRUFDVDtBQUVBLFFBQU04QixtQkFBbUJILG1CQUFtQixFQUFFSSxJQUFJLENBQUM3RCxNQUFNOEQsV0FBVztBQUFBLElBQ2xFUixLQUFLdEQsS0FBS1E7QUFBQUEsSUFDVnVELE9BQU9ELFFBQVE7QUFBQSxJQUNmRSxnQkFBZ0IsSUFBSTNFLEtBQUtXLEtBQUtDLFdBQVcsRUFBRWdFLGVBQWUsT0FBTztBQUFBLElBQ2pFQyxlQUFlbEUsS0FBS2E7QUFBQUEsSUFDcEJJLGNBQWNqQixLQUFLZ0I7QUFBQUEsSUFDbkJJLFlBQVlwQixLQUFLa0I7QUFBQUEsSUFDakJHLFFBQVFyQixLQUFLcUI7QUFBQUEsSUFDYlQsYUFBYVosS0FBS1c7QUFBQUEsSUFDbEJ3RCxjQUFjbkUsS0FBS3dCO0FBQUFBLEVBQ3JCLEVBQUU7QUFFRixRQUFNNEMsVUFBVTtBQUFBLElBQ2QsRUFBRWQsS0FBSyxTQUFTQyxRQUFRLFVBQVVDLE9BQU8sT0FBTztBQUFBLElBQ2hELEVBQUVGLEtBQUssZUFBZUMsUUFBUSxtQkFBbUJDLE9BQU8sUUFBUTtBQUFBLElBQ2hFLEVBQUVGLEtBQUssaUJBQWlCQyxRQUFRLGlCQUFpQkMsT0FBTyxRQUFRO0FBQUEsSUFDaEUsRUFBRUYsS0FBSyxnQkFBZ0JDLFFBQVEsZ0JBQWdCQyxPQUFPLFFBQVE7QUFBQSxJQUM5RCxFQUFFRixLQUFLLGNBQWNDLFFBQVEsY0FBY0MsT0FBTyxRQUFRO0FBQUEsSUFDMUQsRUFBRUYsS0FBSyxVQUFVQyxRQUFRLGFBQWFDLE9BQU8sT0FBTztBQUFBLElBQ3BELEVBQUVGLEtBQUssbUJBQW1CQyxRQUFRLG9CQUFvQkMsT0FBTyxRQUFRO0FBQUEsSUFDckUsRUFBRUYsS0FBSyxVQUFVQyxRQUFRLFVBQVVDLE9BQU8sUUFBUTtBQUFBLElBQ2xELEVBQUVGLEtBQUssVUFBVUMsUUFBUSxXQUFXQyxPQUFPLFFBQVE7QUFBQSxFQUFDO0FBR3RELFFBQU1hLFlBQVl0SSxvQkFBb0I4SCxJQUFJLENBQUN4RCxZQUFZeUQsV0FBVztBQUFBLElBQ2hFUixLQUFLakQsV0FBV0s7QUFBQUEsSUFDaEJxRCxPQUFPRCxRQUFRO0FBQUEsSUFDZmxELGFBQWFQLFdBQVdPLGVBQWU7QUFBQSxJQUN2Q3NELGVBQWU3RCxXQUFXUyxTQUFTQyxhQUFhO0FBQUEsSUFDaERFLGNBQWNaLFdBQVdTLFNBQVNHLGdCQUFnQjtBQUFBLElBQ2xERyxZQUFZZixXQUFXYyxVQUFVQyxjQUFjO0FBQUEsSUFDL0NDLFFBQVFoQixXQUFXaUIsV0FBVztBQUFBLElBQzlCZ0QsaUJBQWlCakUsV0FBV2tFLFlBQ3hCLElBQUlsRixLQUFLZ0IsV0FBV2tFLFNBQVMsRUFBRUMsbUJBQW1CLE9BQU8sSUFDekQ7QUFBQSxJQUNKOUMsUUFBUWlCLGFBQWF0QyxXQUFXb0UsZUFBZTtBQUFBLElBQy9DQyxRQUNFLHVCQUFDLFNBQU0sTUFBSyxTQUNWO0FBQUEsNkJBQUMsV0FBUSxPQUFNLGdCQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxNQUFLO0FBQUEsVUFDTCxNQUFNLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVk7QUFBQSxVQUNsQixTQUFTLE1BQU1oQyxnQkFBZ0JyQyxVQUFVO0FBQUE7QUFBQSxRQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFJNkMsS0FML0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU9BO0FBQUEsTUFDQSx1QkFBQyxXQUFRLE9BQU0scUJBQ2I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE1BQUs7QUFBQSxVQUNMLE1BQU0sdUJBQUMsd0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBbUI7QUFBQSxVQUN6QixTQUFTLE1BQU1vQyxvQkFBb0JwQyxVQUFVO0FBQUEsVUFDN0MsV0FBVTtBQUFBLFVBQ1YsU0FBUzVELGNBQWNOLG9CQUFvQnVFLFFBQVFMLFdBQVdLO0FBQUFBLFVBQUk7QUFBQTtBQUFBLFFBTnBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVNBLEtBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXFCQTtBQUFBLEVBRUosRUFBRTtBQUVGLFFBQU1pRSxRQUFRO0FBQUEsSUFDWkMsT0FBTy9JLG9CQUFvQjRDO0FBQUFBLEVBQzdCO0FBRUEsUUFBTW9HLGVBQWU7QUFBQSxJQUNuQixHQUFHLElBQUlDLElBQUlqSSxPQUFPZ0gsSUFBSSxDQUFDa0IsVUFBVSxDQUFDQSxNQUFNckUsS0FBS3FFLEtBQUssQ0FBQyxDQUFDLEVBQUVDLE9BQU87QUFBQSxFQUFDO0FBR2hFLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGVBQ2IsaUNBQUMsU0FBSSxXQUFVLHVDQUNiO0FBQUEsMkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUNSLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsNkJBQUMsVUFBTyxZQUFZLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6Qix1QkFBQyxTQUFJLFdBQVUsT0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLG9DQUFtQyw2Q0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsT0FBRSxXQUFVLHNCQUFxQix5R0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFHQTtBQUFBLGFBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFFQSx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLG1DQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLG9CQUFpQixXQUFVLDJCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFtRDtBQUFBLGNBQ25ELHVCQUFDLFFBQUcsV0FBVSx5Q0FBd0MscUNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQU0sdUJBQUMscUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBZ0I7QUFBQSxnQkFDdEIsU0FBUyxNQUFNMUgsdUJBQXVCLElBQUk7QUFBQSxnQkFDMUMsV0FBVTtBQUFBLGdCQUErQjtBQUFBO0FBQUEsY0FIM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUE7QUFBQSxlQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0E7QUFBQSxVQUNBLHVCQUFDLE9BQUksUUFBUSxDQUFDLElBQUksRUFBRSxHQUFHLFdBQVUsUUFDL0I7QUFBQSxtQ0FBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QixpQ0FBQyxRQUFLLFdBQVUsNEVBQ2Q7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFNO0FBQUEsa0JBQ04sT0FBT3FILE1BQU1DO0FBQUFBLGtCQUNiLFFBQVEsdUJBQUMsU0FBTSxXQUFVLGdCQUFlLE1BQU0sTUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBeUM7QUFBQSxrQkFDakQsWUFBWTtBQUFBLG9CQUNWOUIsT0FBTztBQUFBLG9CQUNQbUMsVUFBVTtBQUFBLG9CQUNWQyxZQUFZO0FBQUEsa0JBQ2Q7QUFBQTtBQUFBLGdCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFJO0FBQUEsY0FFSix1QkFBQyxTQUFJLFdBQVUsOEJBQTZCLDZDQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQSxLQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFFQSx1QkFBQyxPQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxHQUN2QjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFTLE1BQU07QUFDYmpILHlDQUF1QixLQUFLO0FBQzVCWCx5Q0FBdUIsSUFBSTtBQUFBLGdCQUM3QjtBQUFBLGdCQUVBO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsT0FBTTtBQUFBLHNCQUNOLE9BQU9DLGdCQUFnQkU7QUFBQUEsc0JBQ3ZCLFFBQ0UsdUJBQUMsY0FBVyxXQUFVLGtCQUFpQixNQUFNLE1BQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWdEO0FBQUEsc0JBRWxELFlBQVk7QUFBQSx3QkFDVnFGLE9BQU87QUFBQSx3QkFDUG1DLFVBQVU7QUFBQSx3QkFDVkMsWUFBWTtBQUFBLHNCQUNkO0FBQUE7QUFBQSxvQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUk7QUFBQSxrQkFFSix1QkFBQyxTQUFJLFdBQVUsOEJBQTZCLG9DQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUE7QUFBQTtBQUFBLGNBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXNCQSxLQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdCQTtBQUFBLGVBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNENBO0FBQUEsYUE1REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZEQTtBQUFBLFFBRUNqSixVQUNDLHVCQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWUsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBLElBRUEsdUJBQUMsUUFBSyxXQUFVLGFBQ2Q7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxtQ0FBQyxTQUNDLGlDQUFDLE9BQUUsV0FBVSx5QkFBd0I7QUFBQTtBQUFBLGNBQzFCRixvQkFBb0IwQztBQUFBQSxjQUFPO0FBQUEsY0FBSTtBQUFBLGNBQ3ZDNUMsb0JBQW9CNEM7QUFBQUEsY0FBTztBQUFBLGlCQUY5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFNLHVCQUFDLG9CQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWU7QUFBQSxnQkFDckIsU0FBU1A7QUFBQUEsZ0JBQXlCO0FBQUE7QUFBQSxjQUZwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLGVBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLFVBRUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU1tRztBQUFBQSxjQUNOO0FBQUEsY0FDQSxpQkFBZ0I7QUFBQSxjQUNoQixrQkFBaUI7QUFBQSxjQUNqQixpQkFBaUI7QUFBQSxnQkFDZjtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0E7QUFBQSxjQUFhO0FBQUEsY0FFZixtQkFBbUI7QUFBQSxnQkFDakJNLE1BQU1DO0FBQUFBLGlCQUNOLG9CQUFJdkYsS0FBSyxHQUFFbUYsbUJBQW1CLE9BQU87QUFBQSxnQkFDckM7QUFBQSxjQUF5QjtBQUFBO0FBQUEsWUFiN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBY0k7QUFBQSxhQTlCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUEsUUFHRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsT0FDRSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsdUVBQ2IsaUNBQUMsbUJBQWdCLFdBQVUsMkJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQWtELEtBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQ0M7QUFBQSx1Q0FBQyxRQUFHLFdBQVUsdUNBQXNDLGtDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLGdDQUErQiw4Q0FBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxpQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUEsWUFFRixNQUFNbkg7QUFBQUEsWUFDTixVQUFVLE1BQU07QUFDZEMscUNBQXVCLEtBQUs7QUFDNUJXLHFDQUF1QixLQUFLO0FBQzVCRiwyQkFBYSxJQUFJO0FBQUEsWUFDbkI7QUFBQSxZQUNBLE9BQU87QUFBQSxZQUNQLFFBQVE7QUFBQSxjQUNOO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLFNBQVMsTUFBTTtBQUNiVCwyQ0FBdUIsS0FBSztBQUM1QlcsMkNBQXVCLEtBQUs7QUFDNUJGLGlDQUFhLElBQUk7QUFBQSxrQkFDbkI7QUFBQSxrQkFBRTtBQUFBO0FBQUEsZ0JBTEU7QUFBQSxnQkFETjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBU0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUVDLE1BQUs7QUFBQSxrQkFDTCxNQUFNLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlCO0FBQUEsa0JBQ3ZCLFNBQVMsTUFBTTtBQUNiLDBCQUFNb0gsVUFBVXZCLGlCQUFpQkMsSUFBSSxDQUFDN0QsVUFBVTtBQUFBLHNCQUM5QyxTQUFTQSxLQUFLK0Q7QUFBQUEsc0JBQ2QsbUJBQW1CL0QsS0FBS2dFO0FBQUFBLHNCQUN4QixpQkFBaUJoRSxLQUFLa0U7QUFBQUEsc0JBQ3RCLGdCQUFnQmxFLEtBQUtpQjtBQUFBQSxzQkFDckIsY0FBY2pCLEtBQUtvQjtBQUFBQSxzQkFDbkJnRSxRQUFRcEYsS0FBS3FCO0FBQUFBLHNCQUNiLG1CQUFtQnJCLEtBQUtZO0FBQUFBLHNCQUN4QixnQkFBZ0JaLEtBQUttRTtBQUFBQSxvQkFDdkIsRUFBRTtBQUNGckssNEJBQVF3RSxRQUFRLDRCQUE0QjtBQUFBLGtCQUM5QztBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFmRTtBQUFBLGdCQUROO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FtQkE7QUFBQSxZQUFTO0FBQUEsWUFHWCxpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxtQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEseUNBQUMsV0FBTSxXQUFVLGdEQUErQyxvQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUMsV0FBVztBQUFBLG9CQUFYO0FBQUEsc0JBQ0MsV0FBVTtBQUFBLHNCQUNWLFVBQVUsQ0FBQytHLFVBQVV0SCxhQUFhc0gsS0FBSztBQUFBLHNCQUN2QyxhQUFhLENBQUMsY0FBYyxVQUFVO0FBQUE7QUFBQSxvQkFIeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUcwQztBQUFBLHFCQVA1QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVNBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFNBQVMsTUFBTTtBQUNidEgsbUNBQWEsSUFBSTtBQUNqQkUsNkNBQXVCLEtBQUs7QUFBQSxvQkFDOUI7QUFBQSxvQkFBRTtBQUFBO0FBQUEsa0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFTQTtBQUFBLG1CQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFCQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF3Qiw2QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBa0Q7QUFBQSxrQkFDbEQsdUJBQUMsT0FBRSxXQUFVLG9DQUNWd0YsNkJBQW1CLEVBQUVoRixVQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSx5Q0FDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSx5QkFBd0IsNkJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtEO0FBQUEsa0JBQ2xELHVCQUFDLE9BQUUsV0FBVSxtQ0FFVCxjQUFJNkcsSUFBSTdCLG1CQUFtQixFQUFFSSxJQUFJLENBQUMwQixNQUFNQSxFQUFFckUsU0FBUyxDQUFDLEVBQ2pEc0UsUUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHlDQUFDLE9BQUUsV0FBVSx5QkFBd0IsZ0NBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFEO0FBQUEsa0JBQ3JELHVCQUFDLE9BQUUsV0FBVSxxQ0FFVCxjQUFJRixJQUFJN0IsbUJBQW1CLEVBQUVJLElBQUksQ0FBQzBCLE1BQU1BLEVBQUUxRSxZQUFZLENBQUMsRUFDcEQyRSxRQUhQO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxxQkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVFBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHlCQUF3QiwyQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0Q7QUFBQSxrQkFDaEQsdUJBQUMsT0FBRSxXQUFVLHFDQUVUL0IsNkJBQW1CLEVBQUUxRCxPQUFPLENBQUN3RixNQUFNO0FBQ2pDLDBCQUFNL0YsVUFBVSxvQkFBSUgsS0FBSztBQUN6QkcsNEJBQVFDLFFBQVFELFFBQVFFLFFBQVEsSUFBSSxDQUFDO0FBQ3JDLDJCQUFPLElBQUlMLEtBQUtrRyxFQUFFdEYsV0FBVyxLQUFLVDtBQUFBQSxrQkFDcEMsQ0FBQyxFQUFFZixVQU5QO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUUE7QUFBQSxxQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsbUJBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUNBO0FBQUEsY0FFQ21GLGlCQUFpQm5GLFNBQVMsSUFDekI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTW1GO0FBQUFBLGtCQUNOLFNBQVNQO0FBQUFBLGtCQUNULGlCQUFnQjtBQUFBLGtCQUNoQixrQkFBaUI7QUFBQTtBQUFBLGdCQUpuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FJMkMsSUFHM0MsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsdUNBQUMsbUJBQWdCLFdBQVUsaUNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsZ0JBQ3hELHVCQUFDLE9BQUUsV0FBVSxpQkFBZ0IsMkNBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsZ0JBQ3hELHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsd0VBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU1BO0FBQUEsaUJBN0VKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBK0VBO0FBQUE7QUFBQSxVQXZJRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUF3SUE7QUFBQSxRQUVBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFNaEg7QUFBQUEsWUFDTixVQUFVLE1BQU07QUFDZEMsb0NBQXNCLEtBQUs7QUFDM0JGLG9DQUFzQixJQUFJO0FBQUEsWUFDNUI7QUFBQSxZQUNBLE9BQU87QUFBQSxZQUNQLFFBQVE7QUFBQSxZQUNSO0FBQUEsWUFDQSxXQUFXLEVBQUVxSixTQUFTLEVBQUU7QUFBQSxZQUV2QnRKLGdDQUNDLHVCQUFDLFNBQUksV0FBVSw0QkFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSw0SEFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF3STtBQUFBLGNBQ3hJLHVCQUFDLFNBQUksV0FBVSw4SEFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwSTtBQUFBLGNBRTFJLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSxvQkFDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSxrSUFDYixpQ0FBQyxzQkFBbUIsV0FBVSx5QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUQsS0FEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxtQ0FBa0Msa0NBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLHdEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFVQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLHlDQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLDJDQUFDLFVBQUssV0FBVSwrQ0FBOEMsb0NBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQ3dHLGFBQWF4RyxtQkFBbUJzSSxlQUFlO0FBQUEsdUJBSmxEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBS0E7QUFBQSxrQkFDQSx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLDJDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDZDQUFDLFVBQUssV0FBVSx5QkFBd0IsMEJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxVQUFLLFdBQVUsdUNBQ2J0SSw2QkFBbUIyRSxTQUFTQyxhQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFPQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLDZDQUFDLFVBQUssV0FBVSx5QkFBd0IsNkJBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFDQSx1QkFBQyxVQUFLLFdBQVUsdUNBQ2I1RSw2QkFBbUIyRSxTQUFTRyxnQkFEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSw2Q0FBQyxVQUFLLFdBQVUseUJBQXdCLDJCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsVUFBSyxXQUFVLHVDQUNiOUUsNkJBQW1CZ0YsVUFBVUMsY0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSw2Q0FBQyxVQUFLLFdBQVUseUJBQXdCLDhCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsVUFBSyxXQUFVLHVDQUNiakYsNkJBQW1CbUYsV0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBT0E7QUFBQSxvQkFDQSx1QkFBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSw2Q0FBQyxVQUFLLFdBQVUseUJBQXdCLGdDQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0EsdUJBQUMsVUFBSyxXQUFVLHVDQUNibkYsNkJBQW1CeUUsZUFBZSxTQURyQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFPQTtBQUFBLHVCQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXlDQTtBQUFBLHFCQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWlEQTtBQUFBLGdCQUVBLHVCQUFDLFNBQUksV0FBVSx5REFDYixpQ0FBQyxTQUFJLFdBQVUsMEJBQ2I7QUFBQSx5Q0FBQyxzQkFBbUIsV0FBVSxrQ0FBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBNEQ7QUFBQSxrQkFDNUQsdUJBQUMsU0FDQyxpQ0FBQyxPQUFFLFdBQVUseUJBQ1g7QUFBQSwyQ0FBQyxZQUFPLHFCQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWE7QUFBQSxvQkFBUztBQUFBLHVCQUR4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFNQTtBQUFBLHFCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVdBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLG1CQUNiO0FBQUE7QUFBQSxvQkFBQztBQUFBO0FBQUEsc0JBQ0MsU0FBUyxNQUFNO0FBQ2J0RSw4Q0FBc0IsS0FBSztBQUMzQkYsOENBQXNCLElBQUk7QUFBQSxzQkFDNUI7QUFBQSxzQkFDQSxXQUFVO0FBQUEsc0JBQ1YsTUFBSztBQUFBLHNCQUFPO0FBQUE7QUFBQSxvQkFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBU0E7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsTUFBTSx1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFtQjtBQUFBLHNCQUN6QixTQUFTSztBQUFBQSxzQkFDVCxTQUFTLE1BQU0yRixpQkFBaUJqRyxtQkFBbUJ1RSxHQUFHO0FBQUEsc0JBQ3RELFdBQVU7QUFBQSxzQkFDVixNQUFLO0FBQUEsc0JBQU87QUFBQTtBQUFBLG9CQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTQTtBQUFBLHFCQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXFCQTtBQUFBLG1CQWxHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1HQTtBQUFBLGlCQXZHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXdHQTtBQUFBO0FBQUEsVUFwSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBc0hBO0FBQUEsV0FsWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXNYQTtBQUFBLFNBeFhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5WEE7QUFBQSxPQTNYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNFhBLEtBN1hGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4WEE7QUFFSjtBQUFDOUUsR0E3dEJRRCxrQkFBZ0I7QUFBQStKLEtBQWhCL0o7QUErdEJULGVBQWVBO0FBQWlCLElBQUErSjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJMaW5rIiwiTmF2YmFyIiwiU2lkZWJhciIsIlVzZXJzIiwiUmVmcmVzaEN3IiwiQWxlcnRDaXJjbGUiLCJDaGVja0NpcmNsZSIsIlhDaXJjbGUiLCJTZWFyY2giLCJGaWx0ZXIiLCJDaGV2cm9uRG93biIsIlVzZXJYIiwiVHJlbmRpbmdVcCIsIkNhbGVuZGFyIiwiQWN0aXZpdHkiLCJTZWxlY3QiLCJCdXR0b24iLCJNb2RhbCIsIm1lc3NhZ2UiLCJUYWciLCJTcGFjZSIsIkNhcmQiLCJSb3ciLCJDb2wiLCJTdGF0aXN0aWMiLCJUb29sdGlwIiwiSW5wdXQiLCJUYWJsZSIsIkRhdGVQaWNrZXIiLCJFeWVPdXRsaW5lZCIsIlN0b3BPdXRsaW5lZCIsIlJlbG9hZE91dGxpbmVkIiwiVXNlclN3aXRjaE91dGxpbmVkIiwiUGxheUNpcmNsZU91dGxpbmVkIiwiUGF1c2VDaXJjbGVPdXRsaW5lZCIsIlNlYXJjaE91dGxpbmVkIiwiVXNlck91dGxpbmVkIiwiVGVhbU91dGxpbmVkIiwiRW52aXJvbm1lbnRPdXRsaW5lZCIsIkluZm9DaXJjbGVPdXRsaW5lZCIsIkhpc3RvcnlPdXRsaW5lZCIsIkJhckNoYXJ0T3V0bGluZWQiLCJEb3dubG9hZE91dGxpbmVkIiwiYXBpIiwiRGF0YVRhYmxlIiwiQ2lyY3VsYXJMb2FkZXIiLCJkYXlqcyIsIkFjdGl2YXRlQ3VzdG9tZXIiLCJfcyIsImluYWN0aXZlRW5yb2xsbWVudHMiLCJzZXRJbmFjdGl2ZUVucm9sbG1lbnRzIiwiZmlsdGVyZWRFbnJvbGxtZW50cyIsInNldEZpbHRlcmVkRW5yb2xsbWVudHMiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsInNlbGVjdGVkRW5yb2xsbWVudCIsInNldFNlbGVjdGVkRW5yb2xsbWVudCIsInN0YXR1c01vZGFsVmlzaWJsZSIsInNldFN0YXR1c01vZGFsVmlzaWJsZSIsImRldGFpbE1vZGFsVmlzaWJsZSIsInNldERldGFpbE1vZGFsVmlzaWJsZSIsImFjdGl2YXRpbmciLCJzZXRBY3RpdmF0aW5nIiwic2VsZWN0ZWRHcm91cCIsInNldFNlbGVjdGVkR3JvdXAiLCJncm91cHMiLCJzZXRHcm91cHMiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsImdyb3VwRmlsdGVyIiwic2V0R3JvdXBGaWx0ZXIiLCJhY3RpdmF0aW9uSGlzdG9yeSIsInNldEFjdGl2YXRpb25IaXN0b3J5IiwiaGlzdG9yeU1vZGFsVmlzaWJsZSIsInNldEhpc3RvcnlNb2RhbFZpc2libGUiLCJhY3RpdmF0aW9uU3RhdHMiLCJzZXRBY3RpdmF0aW9uU3RhdHMiLCJ0b3RhbEFjdGl2YXRlZCIsInRvZGF5QWN0aXZhdGVkIiwid2Vla0FjdGl2YXRlZCIsIm1vbnRoQWN0aXZhdGVkIiwibGFzdEFjdGl2YXRpb24iLCJkYXRlUmFuZ2UiLCJzZXREYXRlUmFuZ2UiLCJzZWxlY3RlZFN0YXRzRmlsdGVyIiwic2V0U2VsZWN0ZWRTdGF0c0ZpbHRlciIsImZldGNoSW5hY3RpdmVFbnJvbGxtZW50cyIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsInN1Y2Nlc3MiLCJjb25zb2xlIiwibG9nIiwibGVuZ3RoIiwid2FybmluZyIsImVycm9yIiwiZmV0Y2hBY3RpdmF0aW9uSGlzdG9yeSIsInN0b3JlZEhpc3RvcnkiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiaGlzdG9yeSIsIkpTT04iLCJwYXJzZSIsInVwZGF0ZUFjdGl2YXRpb25TdGF0cyIsIm5vdyIsIkRhdGUiLCJ0b2RheSIsInNldEhvdXJzIiwid2Vla0FnbyIsInNldERhdGUiLCJnZXREYXRlIiwibW9udGhBZ28iLCJzZXRNb250aCIsImdldE1vbnRoIiwidG9kYXlBY3RpdmF0aW9ucyIsImZpbHRlciIsIml0ZW0iLCJhY3RpdmF0ZWRBdCIsIndlZWtBY3RpdmF0aW9ucyIsIm1vbnRoQWN0aXZhdGlvbnMiLCJzYXZlQWN0aXZhdGlvblRvSGlzdG9yeSIsImVucm9sbG1lbnQiLCJhZG1pblVzZXIiLCJhY3RpdmF0aW9uUmVjb3JkIiwiaWQiLCJlbnJvbGxtZW50SWQiLCJfaWQiLCJlbnJvbGxDb2RlIiwiZW5yb2xsX2NvZGUiLCJjdXN0b21lck5hbWUiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwicGhvbmVOdW1iZXIiLCJwaG9uZV9udW1iZXIiLCJncm91cE5hbWUiLCJncm91cF9pZCIsImdyb3VwX25hbWUiLCJ0aWNrZXQiLCJ0aWNrZXRzIiwidG9JU09TdHJpbmciLCJhY3RpdmF0ZWRCeSIsIm5hbWUiLCJzdGF0dXMiLCJ1cGRhdGVkSGlzdG9yeSIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJmaWx0ZXJlZCIsInRyaW0iLCJzZWFyY2hMb3dlciIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ0b1N0cmluZyIsImFjdGl2YXRlQ3VzdG9tZXIiLCJhY3RpdmF0ZWRFbnJvbGxtZW50IiwiZmluZCIsImUiLCJwcmV2RW5yb2xsbWVudHMiLCJvcGVuQWN0aXZhdGlvbk1vZGFsIiwib3BlbkRldGFpbE1vZGFsIiwiZ2V0U3RhdHVzVGFnIiwic3RhdHVzQ29uZmlnIiwiSW5hY3RpdmUiLCJjb2xvciIsImJnQ29sb3IiLCJ0ZXh0Q29sb3IiLCJpY29uIiwibGFiZWwiLCJBY3RpdmUiLCJjb25maWciLCJoaXN0b3J5Q29sdW1ucyIsImtleSIsImhlYWRlciIsIndpZHRoIiwiZ2V0RmlsdGVyZWRIaXN0b3J5IiwiaXRlbURhdGUiLCJ0b0RhdGUiLCJoaXN0b3J5VGFibGVEYXRhIiwibWFwIiwiaW5kZXgiLCJzbF9ubyIsImFjdGl2YXRlZF9kYXRlIiwidG9Mb2NhbGVTdHJpbmciLCJjdXN0b21lcl9uYW1lIiwiYWN0aXZhdGVkX2J5IiwiY29sdW1ucyIsInRhYmxlRGF0YSIsImVucm9sbG1lbnRfZGF0ZSIsInVwZGF0ZWRBdCIsInRvTG9jYWxlRGF0ZVN0cmluZyIsImN1c3RvbWVyX3N0YXR1cyIsImFjdGlvbiIsInN0YXRzIiwidG90YWwiLCJ1bmlxdWVHcm91cHMiLCJNYXAiLCJncm91cCIsInZhbHVlcyIsImZvbnRTaXplIiwiZm9udFdlaWdodCIsImNzdkRhdGEiLCJUaWNrZXQiLCJkYXRlcyIsIlNldCIsImgiLCJzaXplIiwicGFkZGluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkFjdGl2YXRlQ3VzdG9tZXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQge1xyXG4gIFVzZXJzLFxyXG4gIFJlZnJlc2hDdyxcclxuICBBbGVydENpcmNsZSxcclxuICBDaGVja0NpcmNsZSxcclxuICBYQ2lyY2xlLFxyXG4gIFNlYXJjaCxcclxuICBGaWx0ZXIsXHJcbiAgQ2hldnJvbkRvd24sXHJcbiAgVXNlclgsXHJcbiAgVHJlbmRpbmdVcCxcclxuICBDYWxlbmRhcixcclxuICBBY3Rpdml0eSxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgU2VsZWN0LFxyXG4gIEJ1dHRvbixcclxuICBNb2RhbCxcclxuICBtZXNzYWdlLFxyXG4gIFRhZyxcclxuICBTcGFjZSxcclxuICBDYXJkLFxyXG4gIFJvdyxcclxuICBDb2wsXHJcbiAgU3RhdGlzdGljLFxyXG4gIFRvb2x0aXAsXHJcbiAgSW5wdXQsXHJcbiAgVGFibGUsXHJcbiAgRGF0ZVBpY2tlcixcclxufSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQge1xyXG4gIEV5ZU91dGxpbmVkLFxyXG4gIFN0b3BPdXRsaW5lZCxcclxuICBSZWxvYWRPdXRsaW5lZCxcclxuICBVc2VyU3dpdGNoT3V0bGluZWQsXHJcbiAgUGxheUNpcmNsZU91dGxpbmVkLFxyXG4gIFBhdXNlQ2lyY2xlT3V0bGluZWQsXHJcbiAgU2VhcmNoT3V0bGluZWQsXHJcbiAgVXNlck91dGxpbmVkLFxyXG4gIFRlYW1PdXRsaW5lZCxcclxuICBFbnZpcm9ubWVudE91dGxpbmVkLFxyXG4gIEluZm9DaXJjbGVPdXRsaW5lZCxcclxuICBIaXN0b3J5T3V0bGluZWQsXHJcbiAgQmFyQ2hhcnRPdXRsaW5lZCxcclxuICBEb3dubG9hZE91dGxpbmVkLFxyXG59IGZyb20gXCJAYW50LWRlc2lnbi9pY29uc1wiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5cclxuZnVuY3Rpb24gQWN0aXZhdGVDdXN0b21lcigpIHtcclxuICBjb25zdCBbaW5hY3RpdmVFbnJvbGxtZW50cywgc2V0SW5hY3RpdmVFbnJvbGxtZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkRW5yb2xsbWVudHMsIHNldEZpbHRlcmVkRW5yb2xsbWVudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRFbnJvbGxtZW50LCBzZXRTZWxlY3RlZEVucm9sbG1lbnRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3N0YXR1c01vZGFsVmlzaWJsZSwgc2V0U3RhdHVzTW9kYWxWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZGV0YWlsTW9kYWxWaXNpYmxlLCBzZXREZXRhaWxNb2RhbFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFthY3RpdmF0aW5nLCBzZXRBY3RpdmF0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VsZWN0ZWRHcm91cCwgc2V0U2VsZWN0ZWRHcm91cF0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtncm91cEZpbHRlciwgc2V0R3JvdXBGaWx0ZXJdID0gdXNlU3RhdGUoXCJhbGxcIik7XHJcblxyXG4gIGNvbnN0IFthY3RpdmF0aW9uSGlzdG9yeSwgc2V0QWN0aXZhdGlvbkhpc3RvcnldID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtoaXN0b3J5TW9kYWxWaXNpYmxlLCBzZXRIaXN0b3J5TW9kYWxWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbYWN0aXZhdGlvblN0YXRzLCBzZXRBY3RpdmF0aW9uU3RhdHNdID0gdXNlU3RhdGUoe1xyXG4gICAgdG90YWxBY3RpdmF0ZWQ6IDAsXHJcbiAgICB0b2RheUFjdGl2YXRlZDogMCxcclxuICAgIHdlZWtBY3RpdmF0ZWQ6IDAsXHJcbiAgICBtb250aEFjdGl2YXRlZDogMCxcclxuICAgIGxhc3RBY3RpdmF0aW9uOiBudWxsLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtkYXRlUmFuZ2UsIHNldERhdGVSYW5nZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWRTdGF0c0ZpbHRlciwgc2V0U2VsZWN0ZWRTdGF0c0ZpbHRlcl0gPSB1c2VTdGF0ZShcImFsbFwiKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hJbmFjdGl2ZUVucm9sbG1lbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBcIi92MS9hZG1pbi9lbnJvbGxzL2dldC1pbmFjdGl2ZS1lbnJvbGxtZW50c1wiLFxyXG4gICAgICApO1xyXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLnN1Y2Nlc3MpIHtcclxuICAgICAgICBzZXRJbmFjdGl2ZUVucm9sbG1lbnRzKHJlc3BvbnNlLmRhdGEuZGF0YSk7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRFbnJvbGxtZW50cyhyZXNwb25zZS5kYXRhLmRhdGEpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFxyXG4gICAgICAgICAgXCJUb3RhbCBpbmFjdGl2ZSBlbnJvbGxtZW50cyBmZXRjaGVkOlwiLFxyXG4gICAgICAgICAgcmVzcG9uc2UuZGF0YS5kYXRhLmxlbmd0aCxcclxuICAgICAgICApO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEluYWN0aXZlRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICAgIHNldEZpbHRlcmVkRW5yb2xsbWVudHMoW10pO1xyXG4gICAgICAgIG1lc3NhZ2Uud2FybmluZyhcIk5vIGluYWN0aXZlIGVucm9sbG1lbnRzIGZvdW5kXCIpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgaW5hY3RpdmUgZW5yb2xsbWVudHM6XCIsIGVycm9yKTtcclxuICAgICAgbWVzc2FnZS5lcnJvcihcclxuICAgICAgICBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBmZXRjaCBpbmFjdGl2ZSBlbnJvbGxtZW50c1wiLFxyXG4gICAgICApO1xyXG4gICAgICBzZXRJbmFjdGl2ZUVucm9sbG1lbnRzKFtdKTtcclxuICAgICAgc2V0RmlsdGVyZWRFbnJvbGxtZW50cyhbXSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaEFjdGl2YXRpb25IaXN0b3J5ID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3Qgc3RvcmVkSGlzdG9yeSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwiYWN0aXZhdGlvbkhpc3RvcnlcIik7XHJcbiAgICAgIGlmIChzdG9yZWRIaXN0b3J5KSB7XHJcbiAgICAgICAgY29uc3QgaGlzdG9yeSA9IEpTT04ucGFyc2Uoc3RvcmVkSGlzdG9yeSk7XHJcbiAgICAgICAgc2V0QWN0aXZhdGlvbkhpc3RvcnkoaGlzdG9yeSk7XHJcbiAgICAgICAgdXBkYXRlQWN0aXZhdGlvblN0YXRzKGhpc3RvcnkpO1xyXG4gICAgICB9XHJcblxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGFjdGl2YXRpb24gaGlzdG9yeTpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHVwZGF0ZUFjdGl2YXRpb25TdGF0cyA9IChoaXN0b3J5KSA9PiB7XHJcbiAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xyXG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZShub3cuc2V0SG91cnMoMCwgMCwgMCwgMCkpO1xyXG4gICAgY29uc3Qgd2Vla0FnbyA9IG5ldyBEYXRlKG5vdy5zZXREYXRlKG5vdy5nZXREYXRlKCkgLSA3KSk7XHJcbiAgICBjb25zdCBtb250aEFnbyA9IG5ldyBEYXRlKG5vdy5zZXRNb250aChub3cuZ2V0TW9udGgoKSAtIDEpKTtcclxuXHJcbiAgICBjb25zdCB0b2RheUFjdGl2YXRpb25zID0gaGlzdG9yeS5maWx0ZXIoXHJcbiAgICAgIChpdGVtKSA9PiBuZXcgRGF0ZShpdGVtLmFjdGl2YXRlZEF0KSA+PSB0b2RheSxcclxuICAgICkubGVuZ3RoO1xyXG4gICAgY29uc3Qgd2Vla0FjdGl2YXRpb25zID0gaGlzdG9yeS5maWx0ZXIoXHJcbiAgICAgIChpdGVtKSA9PiBuZXcgRGF0ZShpdGVtLmFjdGl2YXRlZEF0KSA+PSB3ZWVrQWdvLFxyXG4gICAgKS5sZW5ndGg7XHJcbiAgICBjb25zdCBtb250aEFjdGl2YXRpb25zID0gaGlzdG9yeS5maWx0ZXIoXHJcbiAgICAgIChpdGVtKSA9PiBuZXcgRGF0ZShpdGVtLmFjdGl2YXRlZEF0KSA+PSBtb250aEFnbyxcclxuICAgICkubGVuZ3RoO1xyXG4gICAgY29uc3QgbGFzdEFjdGl2YXRpb24gPVxyXG4gICAgICBoaXN0b3J5Lmxlbmd0aCA+IDAgPyBoaXN0b3J5W2hpc3RvcnkubGVuZ3RoIC0gMV0gOiBudWxsO1xyXG5cclxuICAgIHNldEFjdGl2YXRpb25TdGF0cyh7XHJcbiAgICAgIHRvdGFsQWN0aXZhdGVkOiBoaXN0b3J5Lmxlbmd0aCxcclxuICAgICAgdG9kYXlBY3RpdmF0ZWQ6IHRvZGF5QWN0aXZhdGlvbnMsXHJcbiAgICAgIHdlZWtBY3RpdmF0ZWQ6IHdlZWtBY3RpdmF0aW9ucyxcclxuICAgICAgbW9udGhBY3RpdmF0ZWQ6IG1vbnRoQWN0aXZhdGlvbnMsXHJcbiAgICAgIGxhc3RBY3RpdmF0aW9uOiBsYXN0QWN0aXZhdGlvbixcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNhdmVBY3RpdmF0aW9uVG9IaXN0b3J5ID0gYXN5bmMgKGVucm9sbG1lbnQsIGFkbWluVXNlcikgPT4ge1xyXG4gICAgY29uc3QgYWN0aXZhdGlvblJlY29yZCA9IHtcclxuICAgICAgaWQ6IERhdGUubm93KCksXHJcbiAgICAgIGVucm9sbG1lbnRJZDogZW5yb2xsbWVudC5faWQsXHJcbiAgICAgIGVucm9sbENvZGU6IGVucm9sbG1lbnQuZW5yb2xsX2NvZGUsXHJcbiAgICAgIGN1c3RvbWVyTmFtZTogZW5yb2xsbWVudC51c2VyX2lkPy5mdWxsX25hbWUsXHJcbiAgICAgIHBob25lTnVtYmVyOiBlbnJvbGxtZW50LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgZ3JvdXBOYW1lOiBlbnJvbGxtZW50Lmdyb3VwX2lkPy5ncm91cF9uYW1lLFxyXG4gICAgICB0aWNrZXQ6IGVucm9sbG1lbnQudGlja2V0cyxcclxuICAgICAgYWN0aXZhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcclxuICAgICAgYWN0aXZhdGVkQnk6IGFkbWluVXNlcj8ubmFtZSB8fCBcIkFkbWluXCIsXHJcbiAgICAgIHN0YXR1czogXCJBY3RpdmF0ZWRcIixcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgdXBkYXRlZEhpc3RvcnkgPSBbYWN0aXZhdGlvblJlY29yZCwgLi4uYWN0aXZhdGlvbkhpc3RvcnldO1xyXG4gICAgc2V0QWN0aXZhdGlvbkhpc3RvcnkodXBkYXRlZEhpc3RvcnkpO1xyXG5cclxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFwiYWN0aXZhdGlvbkhpc3RvcnlcIiwgSlNPTi5zdHJpbmdpZnkodXBkYXRlZEhpc3RvcnkpKTtcclxuXHJcbiAgICB1cGRhdGVBY3RpdmF0aW9uU3RhdHModXBkYXRlZEhpc3RvcnkpO1xyXG5cclxuICBcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hJbmFjdGl2ZUVucm9sbG1lbnRzKCk7XHJcbiAgICBmZXRjaEFjdGl2YXRpb25IaXN0b3J5KCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgbGV0IGZpbHRlcmVkID0gWy4uLmluYWN0aXZlRW5yb2xsbWVudHNdO1xyXG5cclxuICAgIGlmIChncm91cEZpbHRlciAhPT0gXCJhbGxcIiAmJiBncm91cEZpbHRlcikge1xyXG4gICAgICBmaWx0ZXJlZCA9IGZpbHRlcmVkLmZpbHRlcihcclxuICAgICAgICAoZW5yb2xsbWVudCkgPT4gZW5yb2xsbWVudC5ncm91cF9pZD8uX2lkID09PSBncm91cEZpbHRlcixcclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoc2VhcmNoVGV4dC50cmltKCkpIHtcclxuICAgICAgY29uc3Qgc2VhcmNoTG93ZXIgPSBzZWFyY2hUZXh0LnRvTG93ZXJDYXNlKCk7XHJcbiAgICAgIGZpbHRlcmVkID0gZmlsdGVyZWQuZmlsdGVyKFxyXG4gICAgICAgIChlbnJvbGxtZW50KSA9PlxyXG4gICAgICAgICAgZW5yb2xsbWVudC51c2VyX2lkPy5mdWxsX25hbWU/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoTG93ZXIpIHx8XHJcbiAgICAgICAgICBlbnJvbGxtZW50LnVzZXJfaWQ/LnBob25lX251bWJlcj8uaW5jbHVkZXMoc2VhcmNoTG93ZXIpIHx8XHJcbiAgICAgICAgICBlbnJvbGxtZW50LnRpY2tldHM/LnRvU3RyaW5nKCkuaW5jbHVkZXMoc2VhcmNoTG93ZXIpIHx8XHJcbiAgICAgICAgICBlbnJvbGxtZW50LmVucm9sbF9jb2RlPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaExvd2VyKSB8fFxyXG4gICAgICAgICAgZW5yb2xsbWVudC5ncm91cF9pZD8uZ3JvdXBfbmFtZT8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hMb3dlciksXHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0RmlsdGVyZWRFbnJvbGxtZW50cyhmaWx0ZXJlZCk7XHJcbiAgfSwgW2luYWN0aXZlRW5yb2xsbWVudHMsIGdyb3VwRmlsdGVyLCBzZWFyY2hUZXh0XSk7XHJcblxyXG4gIC8vIEFjdGl2YXRlIGN1c3RvbWVyXHJcbiAgY29uc3QgYWN0aXZhdGVDdXN0b21lciA9IGFzeW5jIChlbnJvbGxtZW50SWQpID0+IHtcclxuICAgIHNldEFjdGl2YXRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC92MS9hZG1pbi9lbnJvbGxzLyR7ZW5yb2xsbWVudElkfS9wYXltZW50cy9ob2xkYCxcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEuc3RhdHVzID09PSB0cnVlKSB7XHJcbiAgICAgICAgY29uc3QgYWN0aXZhdGVkRW5yb2xsbWVudCA9IGluYWN0aXZlRW5yb2xsbWVudHMuZmluZChcclxuICAgICAgICAgIChlKSA9PiBlLl9pZCA9PT0gZW5yb2xsbWVudElkLFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGF3YWl0IHNhdmVBY3RpdmF0aW9uVG9IaXN0b3J5KGFjdGl2YXRlZEVucm9sbG1lbnQsIHsgbmFtZTogXCJBZG1pblwiIH0pO1xyXG5cclxuICAgICAgICBtZXNzYWdlLnN1Y2Nlc3MoXHJcbiAgICAgICAgICByZXNwb25zZS5kYXRhLm1lc3NhZ2UgfHwgXCJDdXN0b21lciBhY3RpdmF0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgc2V0SW5hY3RpdmVFbnJvbGxtZW50cygocHJldkVucm9sbG1lbnRzKSA9PlxyXG4gICAgICAgICAgcHJldkVucm9sbG1lbnRzLmZpbHRlcihcclxuICAgICAgICAgICAgKGVucm9sbG1lbnQpID0+IGVucm9sbG1lbnQuX2lkICE9PSBlbnJvbGxtZW50SWQsXHJcbiAgICAgICAgICApLFxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIHNldFN0YXR1c01vZGFsVmlzaWJsZShmYWxzZSk7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50KG51bGwpO1xyXG5cclxuICAgICAgICBmZXRjaEluYWN0aXZlRW5yb2xsbWVudHMoKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBtZXNzYWdlLmVycm9yKHJlc3BvbnNlLmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gYWN0aXZhdGUgY3VzdG9tZXJcIik7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBhY3RpdmF0aW5nIGN1c3RvbWVyOlwiLCBlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJGYWlsZWQgdG8gYWN0aXZhdGUgY3VzdG9tZXJcIixcclxuICAgICAgKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldEFjdGl2YXRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9wZW5BY3RpdmF0aW9uTW9kYWwgPSAoZW5yb2xsbWVudCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50KGVucm9sbG1lbnQpO1xyXG4gICAgc2V0U3RhdHVzTW9kYWxWaXNpYmxlKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9wZW5EZXRhaWxNb2RhbCA9IChlbnJvbGxtZW50KSA9PiB7XHJcbiAgICBzZXRTZWxlY3RlZEVucm9sbG1lbnQoZW5yb2xsbWVudCk7XHJcbiAgICBzZXREZXRhaWxNb2RhbFZpc2libGUodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0U3RhdHVzVGFnID0gKHN0YXR1cykgPT4ge1xyXG4gICAgY29uc3Qgc3RhdHVzQ29uZmlnID0ge1xyXG4gICAgICBJbmFjdGl2ZToge1xyXG4gICAgICAgIGNvbG9yOiBcImVycm9yXCIsXHJcbiAgICAgICAgYmdDb2xvcjogXCJiZy1yZWQtMTAwXCIsXHJcbiAgICAgICAgdGV4dENvbG9yOiBcInRleHQtcmVkLTgwMFwiLFxyXG4gICAgICAgIGljb246IDxYQ2lyY2xlIGNsYXNzTmFtZT1cInctMyBoLTMgbXItMVwiIC8+LFxyXG4gICAgICAgIGxhYmVsOiBcIkluYWN0aXZlXCIsXHJcbiAgICAgIH0sXHJcbiAgICAgIEFjdGl2ZToge1xyXG4gICAgICAgIGNvbG9yOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICBiZ0NvbG9yOiBcImJnLWdyZWVuLTEwMFwiLFxyXG4gICAgICAgIHRleHRDb2xvcjogXCJ0ZXh0LWdyZWVuLTgwMFwiLFxyXG4gICAgICAgIGljb246IDxDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ3LTMgaC0zIG1yLTFcIiAvPixcclxuICAgICAgICBsYWJlbDogXCJBY3RpdmVcIixcclxuICAgICAgfSxcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgY29uZmlnID0gc3RhdHVzQ29uZmlnW3N0YXR1c10gfHwgc3RhdHVzQ29uZmlnLkluYWN0aXZlO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxzcGFuXHJcbiAgICAgICAgY2xhc3NOYW1lPXtgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1tZWRpdW0gJHtjb25maWcuYmdDb2xvcn0gJHtjb25maWcudGV4dENvbG9yfWB9XHJcbiAgICAgID5cclxuICAgICAgICB7Y29uZmlnLmljb259XHJcbiAgICAgICAge2NvbmZpZy5sYWJlbH1cclxuICAgICAgPC9zcGFuPlxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoaXN0b3J5Q29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsX25vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiwgd2lkdGg6IFwiNjBweFwiIH0sXHJcbiAgICB7IGtleTogXCJhY3RpdmF0ZWRfZGF0ZVwiLCBoZWFkZXI6IFwiQWN0aXZhdGlvbiBEYXRlXCIsIHdpZHRoOiBcIjE1MHB4XCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyX25hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiwgd2lkdGg6IFwiMjAwcHhcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiwgd2lkdGg6IFwiMTIwcHhcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfbmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiLCB3aWR0aDogXCIyMDBweFwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldCBOb1wiLCB3aWR0aDogXCI4MHB4XCIgfSxcclxuICAgIHsga2V5OiBcImVucm9sbF9jb2RlXCIsIGhlYWRlcjogXCJFbnJvbGxtZW50IENvZGVcIiwgd2lkdGg6IFwiMTUwcHhcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aXZhdGVkX2J5XCIsIGhlYWRlcjogXCJBY3RpdmF0ZWQgQnlcIiwgd2lkdGg6IFwiMTIwcHhcIiB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IGdldEZpbHRlcmVkSGlzdG9yeSA9ICgpID0+IHtcclxuICAgIGxldCBmaWx0ZXJlZCA9IFsuLi5hY3RpdmF0aW9uSGlzdG9yeV07XHJcblxyXG4gICAgaWYgKHNlbGVjdGVkU3RhdHNGaWx0ZXIgIT09IFwiYWxsXCIpIHtcclxuICAgICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKTtcclxuICAgICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZShub3cuc2V0SG91cnMoMCwgMCwgMCwgMCkpO1xyXG4gICAgICBjb25zdCB3ZWVrQWdvID0gbmV3IERhdGUobm93LnNldERhdGUobm93LmdldERhdGUoKSAtIDcpKTtcclxuICAgICAgY29uc3QgbW9udGhBZ28gPSBuZXcgRGF0ZShub3cuc2V0TW9udGgobm93LmdldE1vbnRoKCkgLSAxKSk7XHJcblxyXG4gICAgICBpZiAoc2VsZWN0ZWRTdGF0c0ZpbHRlciA9PT0gXCJ0b2RheVwiKSB7XHJcbiAgICAgICAgZmlsdGVyZWQgPSBmaWx0ZXJlZC5maWx0ZXIoXHJcbiAgICAgICAgICAoaXRlbSkgPT4gbmV3IERhdGUoaXRlbS5hY3RpdmF0ZWRBdCkgPj0gdG9kYXksXHJcbiAgICAgICAgKTtcclxuICAgICAgfSBlbHNlIGlmIChzZWxlY3RlZFN0YXRzRmlsdGVyID09PSBcIndlZWtcIikge1xyXG4gICAgICAgIGZpbHRlcmVkID0gZmlsdGVyZWQuZmlsdGVyKFxyXG4gICAgICAgICAgKGl0ZW0pID0+IG5ldyBEYXRlKGl0ZW0uYWN0aXZhdGVkQXQpID49IHdlZWtBZ28sXHJcbiAgICAgICAgKTtcclxuICAgICAgfSBlbHNlIGlmIChzZWxlY3RlZFN0YXRzRmlsdGVyID09PSBcIm1vbnRoXCIpIHtcclxuICAgICAgICBmaWx0ZXJlZCA9IGZpbHRlcmVkLmZpbHRlcihcclxuICAgICAgICAgIChpdGVtKSA9PiBuZXcgRGF0ZShpdGVtLmFjdGl2YXRlZEF0KSA+PSBtb250aEFnbyxcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGRhdGVSYW5nZSAmJiBkYXRlUmFuZ2VbMF0gJiYgZGF0ZVJhbmdlWzFdKSB7XHJcbiAgICAgIGZpbHRlcmVkID0gZmlsdGVyZWQuZmlsdGVyKChpdGVtKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaXRlbURhdGUgPSBuZXcgRGF0ZShpdGVtLmFjdGl2YXRlZEF0KTtcclxuICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgaXRlbURhdGUgPj0gZGF0ZVJhbmdlWzBdLnRvRGF0ZSgpICYmIGl0ZW1EYXRlIDw9IGRhdGVSYW5nZVsxXS50b0RhdGUoKVxyXG4gICAgICAgICk7XHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBmaWx0ZXJlZDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoaXN0b3J5VGFibGVEYXRhID0gZ2V0RmlsdGVyZWRIaXN0b3J5KCkubWFwKChpdGVtLCBpbmRleCkgPT4gKHtcclxuICAgIGtleTogaXRlbS5pZCxcclxuICAgIHNsX25vOiBpbmRleCArIDEsXHJcbiAgICBhY3RpdmF0ZWRfZGF0ZTogbmV3IERhdGUoaXRlbS5hY3RpdmF0ZWRBdCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKSxcclxuICAgIGN1c3RvbWVyX25hbWU6IGl0ZW0uY3VzdG9tZXJOYW1lLFxyXG4gICAgcGhvbmVfbnVtYmVyOiBpdGVtLnBob25lTnVtYmVyLFxyXG4gICAgZ3JvdXBfbmFtZTogaXRlbS5ncm91cE5hbWUsXHJcbiAgICB0aWNrZXQ6IGl0ZW0udGlja2V0LFxyXG4gICAgZW5yb2xsX2NvZGU6IGl0ZW0uZW5yb2xsQ29kZSxcclxuICAgIGFjdGl2YXRlZF9ieTogaXRlbS5hY3RpdmF0ZWRCeSxcclxuICB9KSk7XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJzbF9ub1wiLCBoZWFkZXI6IFwiU0wuIE5PXCIsIHdpZHRoOiBcIjYwcHhcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW5yb2xsX2NvZGVcIiwgaGVhZGVyOiBcIkVucm9sbG1lbnQgQ29kZVwiLCB3aWR0aDogXCIxNTBweFwiIH0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lcl9uYW1lXCIsIGhlYWRlcjogXCJDdXN0b21lciBOYW1lXCIsIHdpZHRoOiBcIjIwMHB4XCIgfSxcclxuICAgIHsga2V5OiBcInBob25lX251bWJlclwiLCBoZWFkZXI6IFwiUGhvbmUgTnVtYmVyXCIsIHdpZHRoOiBcIjEyMHB4XCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiwgd2lkdGg6IFwiMjAwcHhcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXQgTm9cIiwgd2lkdGg6IFwiODBweFwiIH0sXHJcbiAgICB7IGtleTogXCJlbnJvbGxtZW50X2RhdGVcIiwgaGVhZGVyOiBcIkRlYWN0aXZhdGVkIERhdGVcIiwgd2lkdGg6IFwiMTIwcHhcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiwgd2lkdGg6IFwiMTAwcHhcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25zXCIsIHdpZHRoOiBcIjE1MHB4XCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCB0YWJsZURhdGEgPSBmaWx0ZXJlZEVucm9sbG1lbnRzLm1hcCgoZW5yb2xsbWVudCwgaW5kZXgpID0+ICh7XHJcbiAgICBrZXk6IGVucm9sbG1lbnQuX2lkLFxyXG4gICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAgIGVucm9sbF9jb2RlOiBlbnJvbGxtZW50LmVucm9sbF9jb2RlIHx8IFwiTi9BXCIsXHJcbiAgICBjdXN0b21lcl9uYW1lOiBlbnJvbGxtZW50LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgcGhvbmVfbnVtYmVyOiBlbnJvbGxtZW50LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIk4vQVwiLFxyXG4gICAgZ3JvdXBfbmFtZTogZW5yb2xsbWVudC5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgdGlja2V0OiBlbnJvbGxtZW50LnRpY2tldHMgfHwgXCJOL0FcIixcclxuICAgIGVucm9sbG1lbnRfZGF0ZTogZW5yb2xsbWVudC51cGRhdGVkQXRcclxuICAgICAgPyBuZXcgRGF0ZShlbnJvbGxtZW50LnVwZGF0ZWRBdCkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tSU5cIilcclxuICAgICAgOiBcIk4vQVwiLFxyXG4gICAgc3RhdHVzOiBnZXRTdGF0dXNUYWcoZW5yb2xsbWVudC5jdXN0b21lcl9zdGF0dXMpLFxyXG4gICAgYWN0aW9uOiAoXHJcbiAgICAgIDxTcGFjZSBzaXplPVwic21hbGxcIj5cclxuICAgICAgICA8VG9vbHRpcCB0aXRsZT1cIlZpZXcgRGV0YWlsc1wiPlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgIGljb249ezxFeWVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb3BlbkRldGFpbE1vZGFsKGVucm9sbG1lbnQpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgPFRvb2x0aXAgdGl0bGU9XCJBY3RpdmF0ZSBDdXN0b21lclwiPlxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgIGljb249ezxQbGF5Q2lyY2xlT3V0bGluZWQgLz59XHJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9wZW5BY3RpdmF0aW9uTW9kYWwoZW5yb2xsbWVudCl9XHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwMFwiXHJcbiAgICAgICAgICAgIGxvYWRpbmc9e2FjdGl2YXRpbmcgJiYgc2VsZWN0ZWRFbnJvbGxtZW50Py5faWQgPT09IGVucm9sbG1lbnQuX2lkfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBBY3RpdmF0ZVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICA8L1NwYWNlPlxyXG4gICAgKSxcclxuICB9KSk7XHJcblxyXG4gIGNvbnN0IHN0YXRzID0ge1xyXG4gICAgdG90YWw6IGluYWN0aXZlRW5yb2xsbWVudHMubGVuZ3RoLFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHVuaXF1ZUdyb3VwcyA9IFtcclxuICAgIC4uLm5ldyBNYXAoZ3JvdXBzLm1hcCgoZ3JvdXApID0+IFtncm91cC5faWQsIGdyb3VwXSkpLnZhbHVlcygpLFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjAgXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4taC1zY3JlZW4gdy1mdWxsIGJnLWdyYXktNTBcIj5cclxuICAgICAgICA8U2lkZWJhciAvPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgIEluYWN0aXZlIEN1c3RvbWVycyBNYW5hZ2VtZW50XHJcbiAgICAgICAgICAgICAgPC9oMj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNjAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgIFZpZXcgYW5kIG1hbmFnZSBjdXN0b21lcnMgd2l0aCBpbmFjdGl2ZSBzdGF0dXMuIENsaWNrIEFjdGl2YXRlXHJcbiAgICAgICAgICAgICAgICB0byByZXN0b3JlIHRoZWlyIHBheW1lbnRzLlxyXG4gICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxCYXJDaGFydE91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDAgdGV4dC1sZ1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQWN0aXZhdGlvbiBTdGF0aXN0aWNzXHJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgaWNvbj17PEhpc3RvcnlPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SGlzdG9yeU1vZGFsVmlzaWJsZSh0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyLWJsdWUtNTAwIHRleHQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBWaWV3IEFjdGl2YXRpb24gSGlzdG9yeVxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPFJvdyBndXR0ZXI9e1sxNiwgMTZdfSBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgICA8Q29sIHhzPXsyNH0gc209ezEyfSBsZz17Nn0+XHJcbiAgICAgICAgICAgICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInNoYWRvdy1zbSBob3ZlcjpzaGFkb3ctbWQgdHJhbnNpdGlvbi1hbGwgYmctcmVkLTUwIGJvcmRlciBib3JkZXItcmVkLTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdGF0aXN0aWNcclxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ3VycmVudGx5IEluYWN0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzdGF0cy50b3RhbH1cclxuICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD17PFVzZXJYIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiIHNpemU9ezIwfSAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlU3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiI2VmNDQ0NFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIyOHB4XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVycyBhd2FpdGluZyBhY3RpdmF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgIDwvQ29sPlxyXG5cclxuICAgICAgICAgICAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IGxnPXs2fT5cclxuICAgICAgICAgICAgICAgICAgPENhcmRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGN1cnNvci1wb2ludGVyIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ncmVlbi01MCB0by1lbWVyYWxkLTUwIGJvcmRlciBib3JkZXItZ3JlZW4tMjAwXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFN0YXRzRmlsdGVyKFwiYWxsXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0SGlzdG9yeU1vZGFsVmlzaWJsZSh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFN0YXRpc3RpY1xyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJUb3RhbCBBY3RpdmF0ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2FjdGl2YXRpb25TdGF0cy50b3RhbEFjdGl2YXRlZH1cclxuICAgICAgICAgICAgICAgICAgICAgIHByZWZpeD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUcmVuZGluZ1VwIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNTAwXCIgc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZVN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiBcIiMyMmM1NWVcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMjhweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250V2VpZ2h0OiBcImJvbGRcIixcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBbGwgdGltZSBhY3RpdmF0aW9uc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgICA8L0NvbD5cclxuICAgICAgICAgICAgICA8L1Jvdz5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHB5LTIwXCI+XHJcbiAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNCBmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFNob3dpbmcge2ZpbHRlcmVkRW5yb2xsbWVudHMubGVuZ3RofSBvZntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIHtpbmFjdGl2ZUVucm9sbG1lbnRzLmxlbmd0aH0gaW5hY3RpdmUgY3VzdG9tZXJzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIGljb249ezxSZWxvYWRPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtmZXRjaEluYWN0aXZlRW5yb2xsbWVudHN9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBSZWZyZXNoIERhdGFcclxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgIGRhdGE9e3RhYmxlRGF0YX1cclxuICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiSW5hY3RpdmVfQ3VzdG9tZXJzX1JlcG9ydFwiXHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJpbmFjdGl2ZV9jdXN0b21lcnNfcmVwb3J0LmNzdlwiXHJcbiAgICAgICAgICAgICAgICAgIHByaW50SGVhZGVyS2V5cz17W1xyXG4gICAgICAgICAgICAgICAgICAgIFwiVG90YWwgSW5hY3RpdmUgQ3VzdG9tZXJzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJSZXBvcnQgRGF0ZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiUmVwb3J0IFR5cGVcIixcclxuICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJWYWx1ZXM9e1tcclxuICAgICAgICAgICAgICAgICAgICBzdGF0cy50b3RhbCxcclxuICAgICAgICAgICAgICAgICAgICBuZXcgRGF0ZSgpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLUlOXCIpLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiSW5hY3RpdmUgQ3VzdG9tZXJzIExpc3RcIixcclxuICAgICAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICAgICAgdGl0bGU9e1xyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCBiZy1ibHVlLTEwMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8SGlzdG9yeU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgdGV4dC14bFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQWN0aXZhdGlvbiBIaXN0b3J5XHJcbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBUcmFjayBhbGwgY3VzdG9tZXIgYWN0aXZhdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIG9wZW49e2hpc3RvcnlNb2RhbFZpc2libGV9XHJcbiAgICAgICAgICAgICAgb25DYW5jZWw9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldEhpc3RvcnlNb2RhbFZpc2libGUoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRTdGF0c0ZpbHRlcihcImFsbFwiKTtcclxuICAgICAgICAgICAgICAgIHNldERhdGVSYW5nZShudWxsKTtcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgIHdpZHRoPXsxMDAwfVxyXG4gICAgICAgICAgICAgIGZvb3Rlcj17W1xyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBrZXk9XCJjbG9zZVwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRIaXN0b3J5TW9kYWxWaXNpYmxlKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFN0YXRzRmlsdGVyKFwiYWxsXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldERhdGVSYW5nZShudWxsKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ2xvc2VcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPixcclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAga2V5PVwiZXhwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICBpY29uPXs8RG93bmxvYWRPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNzdkRhdGEgPSBoaXN0b3J5VGFibGVEYXRhLm1hcCgoaXRlbSkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIFwiU0wgTm9cIjogaXRlbS5zbF9ubyxcclxuICAgICAgICAgICAgICAgICAgICAgIFwiQWN0aXZhdGlvbiBEYXRlXCI6IGl0ZW0uYWN0aXZhdGVkX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkN1c3RvbWVyIE5hbWVcIjogaXRlbS5jdXN0b21lcl9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJQaG9uZSBOdW1iZXJcIjogaXRlbS5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkdyb3VwIE5hbWVcIjogaXRlbS5ncm91cF9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgICAgVGlja2V0OiBpdGVtLnRpY2tldCxcclxuICAgICAgICAgICAgICAgICAgICAgIFwiRW5yb2xsbWVudCBDb2RlXCI6IGl0ZW0uZW5yb2xsX2NvZGUsXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIkFjdGl2YXRlZCBCeVwiOiBpdGVtLmFjdGl2YXRlZF9ieSxcclxuICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiRXhwb3J0IGZlYXR1cmUgY29taW5nIHNvb25cIik7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEV4cG9ydCBIaXN0b3J5XHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj4sXHJcbiAgICAgICAgICAgICAgXX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRmlsdGVyIGJ5IERhdGUgUmFuZ2VcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxEYXRlUGlja2VyLlJhbmdlUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhkYXRlcykgPT4gc2V0RGF0ZVJhbmdlKGRhdGVzKX1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPXtbXCJTdGFydCBEYXRlXCIsIFwiRW5kIERhdGVcIl19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1lbmRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldERhdGVSYW5nZShudWxsKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRTdGF0c0ZpbHRlcihcImFsbFwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ2xlYXIgRmlsdGVyc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBnYXAtMyBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAgcm91bmRlZC1sZyBwLTIgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5Ub3RhbCBSZWNvcmRzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JlZW4tNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z2V0RmlsdGVyZWRIaXN0b3J5KCkubGVuZ3RofVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCByb3VuZGVkLWxnIHAtMiB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMFwiPlVuaXF1ZSBHcm91cHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBuZXcgU2V0KGdldEZpbHRlcmVkSGlzdG9yeSgpLm1hcCgoaCkgPT4gaC5ncm91cE5hbWUpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5zaXplXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1wdXJwbGUtNTAgcm91bmRlZC1sZyBwLTIgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5VbmlxdWUgQ3VzdG9tZXJzPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtcHVycGxlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBuZXcgU2V0KGdldEZpbHRlcmVkSGlzdG9yeSgpLm1hcCgoaCkgPT4gaC5jdXN0b21lck5hbWUpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5zaXplXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1vcmFuZ2UtNTAgcm91bmRlZC1sZyBwLTIgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5MYXN0IDcgRGF5czwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LW9yYW5nZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZ2V0RmlsdGVyZWRIaXN0b3J5KCkuZmlsdGVyKChoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgd2Vla0FnbyA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgd2Vla0Fnby5zZXREYXRlKHdlZWtBZ28uZ2V0RGF0ZSgpIC0gNyk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBEYXRlKGguYWN0aXZhdGVkQXQpID49IHdlZWtBZ287XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pLmxlbmd0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7aGlzdG9yeVRhYmxlRGF0YS5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT17aGlzdG9yeVRhYmxlRGF0YX1cclxuICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtoaXN0b3J5Q29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJBY3RpdmF0aW9uX0hpc3RvcnlfUmVwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiYWN0aXZhdGlvbl9oaXN0b3J5LmNzdlwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEyIGJnLWdyYXktNTAgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxIaXN0b3J5T3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC01eGwgdGV4dC1ncmF5LTMwMCBtYi0zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwXCI+Tm8gYWN0aXZhdGlvbiBoaXN0b3J5IGZvdW5kPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTQwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBY3RpdmF0aW9ucyB3aWxsIGFwcGVhciBoZXJlIHdoZW4geW91IGFjdGl2YXRlIGN1c3RvbWVyc1xyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICAgICAgb3Blbj17c3RhdHVzTW9kYWxWaXNpYmxlfVxyXG4gICAgICAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRTdGF0dXNNb2RhbFZpc2libGUoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRFbnJvbGxtZW50KG51bGwpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgd2lkdGg9ezU1MH1cclxuICAgICAgICAgICAgICBmb290ZXI9e251bGx9XHJcbiAgICAgICAgICAgICAgY2VudGVyZWRcclxuICAgICAgICAgICAgICBib2R5U3R5bGU9e3sgcGFkZGluZzogMCB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3NlbGVjdGVkRW5yb2xsbWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG92ZXJmbG93LWhpZGRlblwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIHJpZ2h0LTAgdy0zMiBoLTMyIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JlZW4tMTAwIHRvLWVtZXJhbGQtMTAwIHJvdW5kZWQtZnVsbCBvcGFjaXR5LTUwIC1tci0xNiAtbXQtMTZcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCBsZWZ0LTAgdy0yNCBoLTI0IGJnLWdyYWRpZW50LXRvLXRyIGZyb20tZ3JlZW4tMTAwIHRvLWVtZXJhbGQtMTAwIHJvdW5kZWQtZnVsbCBvcGFjaXR5LTUwIC1tbC0xMiAtbWItMTJcIj48L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMjAgaC0yMCBiZy1ncmFkaWVudC10by1iciBmcm9tLWdyZWVuLTUwMCB0by1lbWVyYWxkLTUwMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byBzaGFkb3ctbGcgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGxheUNpcmNsZU91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtNHhsIHRleHQtd2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDb25maXJtIEFjdGl2YXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBQbGVhc2UgcmV2aWV3IHRoZSBjdXN0b21lciBkZXRhaWxzIGJlbG93XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLXhsIHAtNCBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtnZXRTdGF0dXNUYWcoc2VsZWN0ZWRFbnJvbGxtZW50LmN1c3RvbWVyX3N0YXR1cyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBGdWxsIE5hbWU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbnJvbGxtZW50LnVzZXJfaWQ/LmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUGhvbmUgTnVtYmVyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRW5yb2xsbWVudC51c2VyX2lkPy5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIE5hbWU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbnJvbGxtZW50Lmdyb3VwX2lkPy5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaWNrZXQgTnVtYmVyOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRW5yb2xsbWVudC50aWNrZXRzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbnJvbGxtZW50IENvZGU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRFbnJvbGxtZW50LmVucm9sbF9jb2RlIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgcm91bmRlZC1sZyBwLTMgbWItNCBib3JkZXIgYm9yZGVyLWJsdWUtMTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEluZm9DaXJjbGVPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNTAwIHRleHQtc20gbXQtMC41XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtYmx1ZS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+Tm90ZTo8L3N0cm9uZz4gQWN0aXZhdGluZyB0aGlzIGN1c3RvbWVyIHdpbGxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3RvcmUgYWxsIHBheW1lbnQgY2FwYWJpbGl0aWVzIGFuZCBhbGxvdyB0aGVtIHRvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJ0aWNpcGF0ZSBpbiBmdXR1cmUgYXVjdGlvbnMuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTMgbXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U3RhdHVzTW9kYWxWaXNpYmxlKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZEVucm9sbG1lbnQobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWNvbj17PFBsYXlDaXJjbGVPdXRsaW5lZCAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17YWN0aXZhdGluZ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gYWN0aXZhdGVDdXN0b21lcihzZWxlY3RlZEVucm9sbG1lbnQuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJnLWdyZWVuLTYwMCBob3ZlcjpiZy1ncmVlbi03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBY3RpdmF0ZSBDdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgICBcclxuICAgICAgICBcclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFjdGl2YXRlQ3VzdG9tZXI7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9BY3RpdmF0ZUN1c3RvbWVyLmpzeCJ9