import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UnverifiedAgent.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { MdDelete } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { CiEdit } from "/node_modules/.vite/deps/react-icons_ci.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { Input, Select, Dropdown, Modal as madal } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const { confirm } = madal;
const UnverifiedAgent = () => {
  _s();
  const [users, setUsers] = useState([]);
  const [TableAgents, setTableAgents] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [currentUpdateUser, setCurrentUpdateUser] = useState(null);
  const [errors, setErrors] = useState({});
  const [searchText, setSearchText] = useState("");
  const [selectedManagerId, setSelectedManagerId] = useState("");
  const [selectedReportingManagerId, setSelectedReportingManagerId] = useState("");
  const [managers, setManagers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [selectedManagerTitle, setSelectedManagerTitle] = useState("");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone_number: "",
    password: "",
    address: "",
    pincode: "",
    adhaar_no: "",
    designation_id: "",
    pan_no: "",
    agent_type: "agent",
    isVerified: "false"
  });
  const [updateFormData, setUpdateFormData] = useState({
    name: "",
    email: "",
    phone_number: "",
    password: "",
    address: "",
    pincode: "",
    adhaar_no: "",
    designation_id: "",
    pan_no: "",
    isVerified: "false"
  });
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/agent/get");
        setUsers(response?.data?.agent);
        const formattedData = response.data?.agent?.filter((v) => v.isVerified === false || v.isVerified === "false").map((group, index) => ({
          _id: group?._id,
          id: index + 1,
          name: group?.name,
          employeeCode: group?.employeeCode || "N/A",
          phone_number: group?.phone_number,
          password: group?.password,
          designation: group?.designation_id?.title,
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center  gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              trigger: ["click"],
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(group._id),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                        lineNumber: 105,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-blue-600 cursor-pointer",
                        onClick: () => handleVerifyAgent(group._id),
                        children: "Verify"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                        lineNumber: 116,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "3",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(group._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                        lineNumber: 127,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 139,
                columnNumber: 19
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 98,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 91,
            columnNumber: 11
          }, this)
        }));
        setTableAgents(formattedData);
      } catch (error) {
        console.error("Error fetching user data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchAgents();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchManagers = async () => {
      try {
        const response = await api.get("/designation/get-designation");
        setManagers(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchManagers();
  }, [reloadTrigger]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const validateForm = (type) => {
    const newErrors = {};
    const data = type === "addEmployee" ? formData : updateFormData;
    const regex = {
      email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
      phone: /^[6-9]\d{9}$/,
      password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{5,}$/,
      pincode: /^\d{6}$/,
      aadhaar: /^\d{12}$/,
      pan: /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/
    };
    if (!data.name.trim()) {
      newErrors.name = "Full Name is required";
    }
    if (!data.email) {
      newErrors.email = "Email is required";
    } else if (!regex.email.test(data.email)) {
      newErrors.email = "Invalid email format";
    }
    if (!data.phone_number) {
      newErrors.phone_number = "Phone number is required";
    } else if (!regex.phone.test(data.phone_number)) {
      newErrors.phone_number = "Invalid  phone number";
    }
    if (!data.password) {
      newErrors.password = "Password is required";
    } else if (!regex.password.test(data.password)) {
      newErrors.password = "Password must contain at least 5 characters, one uppercase, one lowercase, one number, and one special character";
    }
    if (!data.pincode) {
      newErrors.pincode = "Pincode is required";
    } else if (!regex.pincode.test(data.pincode)) {
      newErrors.pincode = "Invalid pincode (6 digits required)";
    }
    if (!data.adhaar_no) {
      newErrors.adhaar_no = "Aadhaar number is required";
    } else if (!regex.aadhaar.test(data.adhaar_no)) {
      newErrors.adhaar_no = "Invalid Aadhaar number (12 digits required)";
    }
    if (!selectedManagerId) {
      newErrors.reporting_manager = "Reporting Manager is required";
    }
    if (!data.pan_no) {
      newErrors.pan_no = "PAN number is required";
    } else if (!regex.pan.test(data.pan_no.toUpperCase())) {
      newErrors.pan_no = "Invalid PAN format (e.g., ABCDE1234F)";
    }
    if (!data.address.trim()) {
      newErrors.address = "Address is required";
    } else if (data.address.trim().length < 10) {
      newErrors.address = "Address should be at least 10 characters";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleAntDSelectManager = (managerId) => {
    setSelectedManagerId(managerId);
    const selected = managers.find((mgr) => mgr._id === managerId);
    const title = selected?.title || "";
    setSelectedManagerTitle(title);
    setFormData((prev) => ({
      ...prev,
      managerId,
      managerTitle: title
    }));
    setErrors((prev) => ({
      ...prev,
      managerId: "",
      managerTitle: ""
    }));
  };
  const handleAntInputDSelectManager = (managerId) => {
    setSelectedManagerId(managerId);
    const selected = managers.find((mgr) => mgr._id === managerId);
    const title = selected?.title || "";
    setSelectedManagerTitle(title);
    setUpdateFormData((prev) => ({
      ...prev,
      managerId,
      managerTitle: title
    }));
    setErrors((prev) => ({
      ...prev,
      managerId: "",
      managerTitle: ""
    }));
  };
  const handleAntDSelectReportingManager = (reportingId) => {
    setSelectedReportingManagerId(reportingId);
    setUpdateFormData((prev) => ({
      ...prev,
      reportingManagerId: reportingId
    }));
    setErrors((prev) => ({
      ...prev,
      reportingManagerId: ""
    }));
  };
  const handleReportingManager = (value) => {
    setSelectedReportingManagerId(value);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isValidate = validateForm("addEmployee");
    try {
      if (isValidate) {
        const dataToSend = {
          ...formData,
          designation_id: selectedManagerId,
          reporting_manager_id: selectedReportingManagerId
        };
        const response = await api.post("/agent/add", dataToSend, {
          headers: {
            "Content-Type": "application/json"
          }
        });
        setShowModal(false);
        setFormData({
          name: "",
          email: "",
          phone_number: "",
          password: "",
          address: "",
          pincode: "",
          adhaar_no: "",
          pan_no: ""
        });
        setSelectedManagerId("");
        setSelectedReportingManagerId("");
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Agent Added Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error adding agent:", error);
      if (error.response && error.response.data && error.response.data.message) {
        const errMsg = error.response.data.message.toLowerCase();
        if (errMsg.includes("phone number")) {
          setErrors((prevErrors) => ({
            ...prevErrors,
            phone_number: "Phone number already exists"
          }));
        } else {
          setAlertConfig({
            visibility: true,
            message: error.response.data.message,
            type: "error"
          });
        }
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "name", header: "Agent Name" },
    { key: "employeeCode", header: "Employee ID" },
    { key: "phone_number", header: "Agent Phone Number" },
    { key: "designation", header: "Designation" },
    { key: "password", header: "Agent Password" },
    { key: "action", header: "Action" }
  ];
  const filteredUsers = users.filter(
    (user) => user.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const handleDeleteModalOpen = async (userId) => {
    try {
      const response = await api.get(`/agent/get-by-id/${userId}`);
      setCurrentUser(response.data?.agent);
      setShowModalDelete(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleUpdateModalOpen = async (userId) => {
    try {
      const response = await api.get(`/agent/get-by-id/${userId}`);
      setCurrentUpdateUser(response.data?.agent);
      setUpdateFormData({
        name: response?.data?.agent?.name,
        email: response?.data?.agent?.email,
        phone_number: response?.data?.agent?.phone_number,
        password: response?.data?.agent?.password,
        pincode: response?.data?.agent?.pincode,
        adhaar_no: response?.data?.agent?.adhaar_no,
        pan_no: response?.data?.agent?.pan_no,
        address: response?.data?.agent?.address
      });
      setSelectedManagerId(response.data?.agent?.designation_id?._id || "");
      setSelectedReportingManagerId(
        response.data?.agent?.reporting_manager_id || ""
      );
      setSelectedManagerTitle(response.data?.agent?.designation_id?.title);
      setShowModalUpdate(true);
      setErrors({});
    } catch (error) {
      console.error("Error fetching user:", error);
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleDeleteUser = async () => {
    if (currentUser) {
      try {
        await api.delete(`/agent/delete/${currentUser._id}`);
        setShowModalDelete(false);
        setCurrentUser(null);
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Agent deleted successfully",
          type: "success"
        });
      } catch (error) {
        console.error("Error deleting user:", error);
      }
    }
  };
  const handleVerifyAgent = async (userId) => {
    try {
      const response = await api.put(`/agent/update/${userId}`, {
        isVerified: true
      });
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "Agent Verified Successfully",
        type: "success"
      });
    } catch (error) {
      console.error("Error verifying agent:", error);
      setAlertConfig({
        visibility: true,
        message: error?.response?.data?.message || "Failed to verify agent",
        type: "error"
      });
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    try {
      if (isValid) {
        const dataToSend = {
          ...updateFormData,
          designation_id: selectedManagerId,
          reporting_manager_id: selectedReportingManagerId
        };
        const response = await api.put(
          `/agent/update/${currentUpdateUser._id}`,
          dataToSend
        );
        setShowModalUpdate(false);
        setSelectedManagerId("");
        setSelectedReportingManagerId("");
        setReloadTrigger((prev) => prev + 1);
        setAlertConfig({
          visibility: true,
          message: "Agent Updated Successfully",
          type: "success"
        });
      }
    } catch (error) {
      console.error("Error updating agent:", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          visibility: true,
          message: `${error.response.data.message}`,
          type: "error"
        });
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  const handleManager = async (event) => {
    const groupId = event.target.value;
    setSelectedManagerId(groupId);
    const selected = managers.find((mgr) => mgr._id === groupId);
    setSelectedManagerTitle(selected?.title || "");
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
          lineNumber: 537,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
        lineNumber: 541,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
          lineNumber: 542,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
          /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 553,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Unverified Agents" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 555,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  setShowModal(true);
                  setErrors({});
                },
                className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
                children: "+ Add Agent"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 556,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 554,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
          lineNumber: 552,
          columnNumber: 13
        }, this),
        TableAgents?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            updateHandler: handleUpdateModalOpen,
            data: filterOption(TableAgents, searchText),
            columns,
            exportedPdfName: `Agents`,
            exportedFileName: `Agents.csv`
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 568,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: TableAgents?.length <= 0,
            data: "Employee Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 576,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
        lineNumber: 551,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
      lineNumber: 536,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Add Agent" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
        lineNumber: 587,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "email",
              children: [
                "Full Name ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 594,
                  columnNumber: 29
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 590,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "name",
              value: formData.name,
              onChange: handleChange,
              id: "name",
              placeholder: "Enter the Full Name",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 596,
              columnNumber: 17
            },
            this
          ),
          errors.name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 607,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
          lineNumber: 589,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Email ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 616,
                    columnNumber: 27
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 612,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "email",
                name: "email",
                value: formData.email,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Email",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 618,
                columnNumber: 19
              },
              this
            ),
            errors.email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.email }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 629,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 611,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Phone Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 637,
                    columnNumber: 34
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 633,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "phone_number",
                value: formData.phone_number,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Phone Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 639,
                columnNumber: 19
              },
              this
            ),
            errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone_number }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 650,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 632,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
          lineNumber: 610,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Password ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 662,
                    columnNumber: 30
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 658,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "text",
                name: "password",
                value: formData.password,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Password",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 664,
                columnNumber: 19
              },
              this
            ),
            errors.password && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.password }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 675,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 657,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Pincode ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 685,
                    columnNumber: 29
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 681,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "pincode",
                value: formData.pincode,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Pincode",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 687,
                columnNumber: 19
              },
              this
            ),
            errors.pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pincode }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 698,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 680,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
          lineNumber: 656,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Adhaar Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 710,
                    columnNumber: 35
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 706,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "number",
                name: "adhaar_no",
                value: formData.adhaar_no,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Adhaar Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 712,
                columnNumber: 19
              },
              this
            ),
            errors.adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.adhaar_no }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 723,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 705,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
            /* @__PURE__ */ jsxDEV(
              "label",
              {
                className: "block mb-2 text-sm font-medium text-gray-900",
                htmlFor: "date",
                children: [
                  "Pan Number ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 733,
                    columnNumber: 32
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 729,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                type: "text",
                name: "pan_no",
                value: formData.pan_no,
                onChange: handleChange,
                id: "text",
                placeholder: "Enter Pan Number",
                required: true,
                className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 735,
                columnNumber: 19
              },
              this
            ),
            errors.pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pan_no }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 746,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 728,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
          lineNumber: 704,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "email",
              children: [
                "Address ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 755,
                  columnNumber: 27
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 751,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Input,
            {
              type: "text",
              name: "address",
              value: formData.address,
              onChange: handleChange,
              id: "name",
              placeholder: "Enter the Address",
              required: true,
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 757,
              columnNumber: 17
            },
            this
          ),
          errors.address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.address }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 768,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
          lineNumber: 750,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV(
            "label",
            {
              className: "block mb-2 text-sm font-medium text-gray-900",
              htmlFor: "category",
              children: [
                "Designation ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 776,
                  columnNumber: 31
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 772,
              columnNumber: 17
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              id: "manager-select",
              name: "managerId",
              value: selectedManagerId || void 0,
              onChange: handleAntDSelectManager,
              placeholder: "Select Designation",
              className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
              showSearch: true,
              popupMatchSelectWidth: false,
              filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
              children: managers.map(
                (mgr) => /* @__PURE__ */ jsxDEV(Select.Option, { value: mgr._id, children: mgr.title }, mgr._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 806,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 792,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
          lineNumber: 771,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center border-2 border-black",
            children: "Save Agent"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 814,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
          lineNumber: 813,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
        lineNumber: 588,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
      lineNumber: 586,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
      lineNumber: 585,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Agent" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 831,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Full Name ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                      lineNumber: 840,
                      columnNumber: 29
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 836,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "name",
                  value: updateFormData.name,
                  onChange: handleInputChange,
                  id: "name",
                  placeholder: "Enter the Full Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 842,
                  columnNumber: 17
                },
                this
              ),
              errors.name && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 853,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 835,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Email ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                        lineNumber: 862,
                        columnNumber: 27
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 858,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "email",
                    name: "email",
                    value: updateFormData.email,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Email",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 864,
                    columnNumber: 19
                  },
                  this
                ),
                errors.email && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.email }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 875,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 857,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Phone Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                        lineNumber: 883,
                        columnNumber: 34
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 879,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "number",
                    name: "phone_number",
                    value: updateFormData.phone_number,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Phone Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 885,
                    columnNumber: 19
                  },
                  this
                ),
                errors.phone_number && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.phone_number }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 896,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 878,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 856,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Password ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                        lineNumber: 908,
                        columnNumber: 30
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 904,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "password",
                    value: updateFormData.password,
                    onChange: handleInputChange,
                    id: "update-password",
                    placeholder: "Enter Password",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 910,
                    columnNumber: 19
                  },
                  this
                ),
                errors.password && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.password }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 921,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 903,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Pincode ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                        lineNumber: 931,
                        columnNumber: 29
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 927,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "pincode",
                    value: updateFormData.pincode,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Pincode",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 933,
                    columnNumber: 19
                  },
                  this
                ),
                errors.pincode && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pincode }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 944,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 926,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 902,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Adhaar Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                        lineNumber: 956,
                        columnNumber: 35
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 952,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "adhaar_no",
                    value: updateFormData.adhaar_no,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Adhaar Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 958,
                    columnNumber: 19
                  },
                  this
                ),
                errors.adhaar_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.adhaar_no }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 969,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 951,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "date",
                    children: [
                      "Pan Number ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                        lineNumber: 979,
                        columnNumber: 32
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 975,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Input,
                  {
                    type: "text",
                    name: "pan_no",
                    value: updateFormData.pan_no,
                    onChange: handleInputChange,
                    id: "text",
                    placeholder: "Enter Pan Number",
                    required: true,
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 981,
                    columnNumber: 19
                  },
                  this
                ),
                errors.pan_no && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.pan_no }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 992,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 974,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 950,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "email",
                  children: [
                    "Address ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                      lineNumber: 1001,
                      columnNumber: 27
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 997,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "address",
                  value: updateFormData.address,
                  onChange: handleInputChange,
                  id: "name",
                  placeholder: "Enter the Address",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 1003,
                  columnNumber: 17
                },
                this
              ),
              errors.address && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.address }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 1014,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 996,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: [
                    "Designation ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                      lineNumber: 1022,
                      columnNumber: 31
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 1018,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  id: "selectedManagerId",
                  name: "selectedManagerId",
                  value: selectedManagerId || void 0,
                  onChange: handleAntInputDSelectManager,
                  placeholder: "Select Designation",
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  showSearch: true,
                  popupMatchSelectWidth: false,
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  children: managers.map(
                    (manager) => /* @__PURE__ */ jsxDEV(Select.Option, { value: manager._id, children: manager.title }, manager._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                      lineNumber: 1052,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 1038,
                  columnNumber: 17
                },
                this
              ),
              errors.designation_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.designation_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 1059,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 1017,
              columnNumber: 15
            }, this),
            (selectedManagerTitle === "Sales Excecutive" || selectedManagerTitle === "Business Agent" || selectedManagerTitle === "Office Executive") && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "category",
                  children: "Reporting Manager"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 1068,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: selectedReportingManagerId || void 0,
                  id: "selectedReportingManagerId",
                  onChange: handleReportingManager,
                  placeholder: "Select Reporting Manager",
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
                  showSearch: true,
                  popupMatchSelectWidth: false,
                  filterOption: (input, option) => option?.children?.toString().toLowerCase().includes(input.toLowerCase()),
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "", hidden: true, children: "Select Reporting Manager" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                      lineNumber: 1089,
                      columnNumber: 21
                    }, this),
                    users.map(
                      (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: [
                        group.name,
                        " - ",
                        group?.designation_id?.title
                      ] }, group._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                        lineNumber: 1093,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 1074,
                  columnNumber: 19
                },
                this
              ),
              errors.reporting_manager && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-red-600", children: errors.reporting_manager }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 1099,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 1067,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 border-2 border-black\r\n              focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update Agent"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                lineNumber: 1106,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 1105,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 834,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
          lineNumber: 830,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
        lineNumber: 826,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentUser(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Agent" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
            lineNumber: 1126,
            columnNumber: 13
          }, this),
          currentUser && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteUser();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentUser.name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                          lineNumber: 1143,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion.",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                          lineNumber: 1147,
                          columnNumber: 21
                        }, this)
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                      lineNumber: 1138,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "groupName",
                      placeholder: "Enter the employee Full Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                      lineNumber: 1149,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                  lineNumber: 1137,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n          focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
                    lineNumber: 1157,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
              lineNumber: 1130,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
          lineNumber: 1125,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
        lineNumber: 1118,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
    lineNumber: 535,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx",
    lineNumber: 534,
    columnNumber: 5
  }, this);
};
_s(UnverifiedAgent, "rSa5HR23iBpPdumF26yZI3R8gxg=");
_c = UnverifiedAgent;
export default UnverifiedAgent;
var _c;
$RefreshReg$(_c, "UnverifiedAgent");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/UnverifiedAgent.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0cwQixTQTZhdEIsVUE3YXNCOzJCQXhHMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsYUFBYTtBQUNwQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsT0FBT0MsUUFBUUMsVUFBVUMsU0FBU0MsYUFBWTtBQUN2RCxPQUFPRCxXQUFXO0FBQ2xCLE9BQU9FLFNBQVM7QUFDaEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGlCQUFpQjtBQUMxQixPQUFPQyxnQkFBZ0I7QUFDdkIsTUFBTSxFQUFFQyxRQUFRLElBQUlUO0FBQ3BCLE1BQU1VLGtCQUFrQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzVCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJdEIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3VCLGFBQWFDLGNBQWMsSUFBSXhCLFNBQVMsRUFBRTtBQUNqRCxRQUFNLENBQUN5QixZQUFZQyxhQUFhLElBQUkxQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDMkIsV0FBV0MsWUFBWSxJQUFJNUIsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQzZCLGlCQUFpQkMsa0JBQWtCLElBQUk5QixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDK0IsaUJBQWlCQyxrQkFBa0IsSUFBSWhDLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNpQyxhQUFhQyxjQUFjLElBQUlsQyxTQUFTLElBQUk7QUFDbkQsUUFBTSxDQUFDbUMsbUJBQW1CQyxvQkFBb0IsSUFBSXBDLFNBQVMsSUFBSTtBQUMvRCxRQUFNLENBQUNxQyxRQUFRQyxTQUFTLElBQUl0QyxTQUFTLENBQUMsQ0FBQztBQUN2QyxRQUFNLENBQUN1QyxZQUFZQyxhQUFhLElBQUl4QyxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDeUMsbUJBQW1CQyxvQkFBb0IsSUFBSTFDLFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUMyQyw0QkFBNEJDLDZCQUE2QixJQUM5RDVDLFNBQVMsRUFBRTtBQUNiLFFBQU0sQ0FBQzZDLFVBQVVDLFdBQVcsSUFBSTlDLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUMrQyxXQUFXQyxZQUFZLElBQUloRCxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDaUQsZUFBZUMsZ0JBQWdCLElBQUlsRCxTQUFTLENBQUM7QUFDcEQsUUFBTW1ELDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN6QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJkLGtCQUFjYSxLQUFLO0FBQUEsRUFDckI7QUFDQSxRQUFNLENBQUNFLHNCQUFzQkMsdUJBQXVCLElBQUl4RCxTQUFTLEVBQUU7QUFFbkUsUUFBTSxDQUFDeUQsYUFBYUMsY0FBYyxJQUFJMUQsU0FBUztBQUFBLElBQzdDMkQsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBRUQsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUkvRCxTQUFTO0FBQUEsSUFDdkNnRSxNQUFNO0FBQUEsSUFDTkMsT0FBTztBQUFBLElBQ1BDLGNBQWM7QUFBQSxJQUNkQyxVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RDLFNBQVM7QUFBQSxJQUNUQyxXQUFXO0FBQUEsSUFDWEMsZ0JBQWdCO0FBQUEsSUFDaEJDLFFBQVE7QUFBQSxJQUNSQyxZQUFZO0FBQUEsSUFDWkMsWUFBWTtBQUFBLEVBQ2QsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSTVFLFNBQVM7QUFBQSxJQUNuRGdFLE1BQU07QUFBQSxJQUNOQyxPQUFPO0FBQUEsSUFDUEMsY0FBYztBQUFBLElBQ2RDLFVBQVU7QUFBQSxJQUNWQyxTQUFTO0FBQUEsSUFDVEMsU0FBUztBQUFBLElBQ1RDLFdBQVc7QUFBQSxJQUNYQyxnQkFBZ0I7QUFBQSxJQUNoQkMsUUFBUTtBQUFBLElBQ1JFLFlBQVk7QUFBQSxFQUNkLENBQUM7QUFFRDNFLFlBQVUsTUFBTTtBQUNkLFVBQU04RSxjQUFjLFlBQVk7QUFDOUIsVUFBSTtBQUNGN0IscUJBQWEsSUFBSTtBQUNqQixjQUFNOEIsV0FBVyxNQUFNcEUsSUFBSXFFLElBQUksWUFBWTtBQUMzQ3pELGlCQUFTd0QsVUFBVUUsTUFBTUMsS0FBSztBQUM5QixjQUFNQyxnQkFBZ0JKLFNBQVNFLE1BQU1DLE9BQ2pDRSxPQUFPLENBQUNDLE1BQU1BLEVBQUVWLGVBQWUsU0FBU1UsRUFBRVYsZUFBZSxPQUFPLEVBQ2pFVyxJQUFJLENBQUNDLE9BQU9DLFdBQVc7QUFBQSxVQUN0QkMsS0FBS0YsT0FBT0U7QUFBQUEsVUFDWkMsSUFBSUYsUUFBUTtBQUFBLFVBQ1p2QixNQUFNc0IsT0FBT3RCO0FBQUFBLFVBQ2IwQixjQUFjSixPQUFPSSxnQkFBZ0I7QUFBQSxVQUNyQ3hCLGNBQWNvQixPQUFPcEI7QUFBQUEsVUFDckJDLFVBQVVtQixPQUFPbkI7QUFBQUEsVUFDakJ3QixhQUFhTCxPQUFPZixnQkFBZ0JxQjtBQUFBQSxVQUNwQ0MsUUFDRSx1QkFBQyxTQUFJLFdBQVUsOEJBT2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsQ0FBQyxPQUFPO0FBQUEsY0FDakIsTUFBTTtBQUFBLGdCQUNKQyxPQUFPO0FBQUEsa0JBQ0w7QUFBQSxvQkFDRUMsS0FBSztBQUFBLG9CQUNMQyxPQUNFO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUNDLFdBQVU7QUFBQSx3QkFDVixTQUFTLE1BQU1DLHNCQUFzQlgsTUFBTUUsR0FBRztBQUFBLHdCQUFFO0FBQUE7QUFBQSxzQkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRUo7QUFBQSxrQkFDQTtBQUFBLG9CQUNFTyxLQUFLO0FBQUEsb0JBQ0xDLE9BQ0U7QUFBQSxzQkFBQztBQUFBO0FBQUEsd0JBQ0MsV0FBVTtBQUFBLHdCQUNWLFNBQVMsTUFBTUUsa0JBQWtCWixNQUFNRSxHQUFHO0FBQUEsd0JBQUU7QUFBQTtBQUFBLHNCQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFFSjtBQUFBLGtCQUNBO0FBQUEsb0JBQ0VPLEtBQUs7QUFBQSxvQkFDTEMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNRyxzQkFBc0JiLE1BQU1FLEdBQUc7QUFBQSx3QkFBRTtBQUFBO0FBQUEsc0JBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFLQTtBQUFBLGtCQUVKO0FBQUEsZ0JBQUM7QUFBQSxjQUVMO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBK0I7QUFBQTtBQUFBLFlBekNqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUEwQ0EsS0FqREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrREE7QUFBQSxRQUVKLEVBQUU7QUFDSmhFLHVCQUFlMEQsYUFBYTtBQUFBLE1BQzlCLFNBQVNrQixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xELFVBQUM7QUFDQ3BELHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQTZCLGdCQUFZO0FBQUEsRUFDZCxHQUFHLENBQUM1QixhQUFhLENBQUM7QUFFbEJsRCxZQUFVLE1BQU07QUFDZCxVQUFNdUcsZ0JBQWdCLFlBQVk7QUFDaEMsVUFBSTtBQUNGLGNBQU14QixXQUFXLE1BQU1wRSxJQUFJcUUsSUFBSSw4QkFBOEI7QUFDN0RqQyxvQkFBWWdDLFNBQVNFLElBQUk7QUFBQSxNQUMzQixTQUFTb0IsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQUUsa0JBQWM7QUFBQSxFQUNoQixHQUFHLENBQUNyRCxhQUFhLENBQUM7QUFFbEIsUUFBTXNELGVBQWVBLENBQUNuRCxNQUFNO0FBQzFCLFVBQU0sRUFBRVksTUFBTVgsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQlMsZ0JBQVksQ0FBQ3lDLGNBQWM7QUFBQSxNQUN6QixHQUFHQTtBQUFBQSxNQUNILENBQUN4QyxJQUFJLEdBQUdYO0FBQUFBLElBQ1YsRUFBRTtBQUNGZixjQUFVLENBQUNrRSxjQUFjO0FBQUEsTUFDdkIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDeEMsSUFBSSxHQUFHO0FBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU15QyxlQUFlQSxDQUFDNUMsU0FBUztBQUM3QixVQUFNNkMsWUFBWSxDQUFDO0FBQ25CLFVBQU0xQixPQUFPbkIsU0FBUyxnQkFBZ0JDLFdBQVdhO0FBQ2pELFVBQU1nQyxRQUFRO0FBQUEsTUFDWjFDLE9BQU87QUFBQSxNQUNQMkMsT0FBTztBQUFBLE1BQ1B6QyxVQUNFO0FBQUEsTUFDRkUsU0FBUztBQUFBLE1BQ1R3QyxTQUFTO0FBQUEsTUFDVEMsS0FBSztBQUFBLElBQ1A7QUFFQSxRQUFJLENBQUM5QixLQUFLaEIsS0FBSytDLEtBQUssR0FBRztBQUNyQkwsZ0JBQVUxQyxPQUFPO0FBQUEsSUFDbkI7QUFFQSxRQUFJLENBQUNnQixLQUFLZixPQUFPO0FBQ2Z5QyxnQkFBVXpDLFFBQVE7QUFBQSxJQUNwQixXQUFXLENBQUMwQyxNQUFNMUMsTUFBTStDLEtBQUtoQyxLQUFLZixLQUFLLEdBQUc7QUFDeEN5QyxnQkFBVXpDLFFBQVE7QUFBQSxJQUNwQjtBQUVBLFFBQUksQ0FBQ2UsS0FBS2QsY0FBYztBQUN0QndDLGdCQUFVeEMsZUFBZTtBQUFBLElBQzNCLFdBQVcsQ0FBQ3lDLE1BQU1DLE1BQU1JLEtBQUtoQyxLQUFLZCxZQUFZLEdBQUc7QUFDL0N3QyxnQkFBVXhDLGVBQWU7QUFBQSxJQUMzQjtBQUVBLFFBQUksQ0FBQ2MsS0FBS2IsVUFBVTtBQUNsQnVDLGdCQUFVdkMsV0FBVztBQUFBLElBQ3ZCLFdBQVcsQ0FBQ3dDLE1BQU14QyxTQUFTNkMsS0FBS2hDLEtBQUtiLFFBQVEsR0FBRztBQUM5Q3VDLGdCQUFVdkMsV0FDUjtBQUFBLElBQ0o7QUFFQSxRQUFJLENBQUNhLEtBQUtYLFNBQVM7QUFDakJxQyxnQkFBVXJDLFVBQVU7QUFBQSxJQUN0QixXQUFXLENBQUNzQyxNQUFNdEMsUUFBUTJDLEtBQUtoQyxLQUFLWCxPQUFPLEdBQUc7QUFDNUNxQyxnQkFBVXJDLFVBQVU7QUFBQSxJQUN0QjtBQUVBLFFBQUksQ0FBQ1csS0FBS1YsV0FBVztBQUNuQm9DLGdCQUFVcEMsWUFBWTtBQUFBLElBQ3hCLFdBQVcsQ0FBQ3FDLE1BQU1FLFFBQVFHLEtBQUtoQyxLQUFLVixTQUFTLEdBQUc7QUFDOUNvQyxnQkFBVXBDLFlBQVk7QUFBQSxJQUN4QjtBQUNBLFFBQUksQ0FBQzdCLG1CQUFtQjtBQUN0QmlFLGdCQUFVTyxvQkFBb0I7QUFBQSxJQUNoQztBQUNBLFFBQUksQ0FBQ2pDLEtBQUtSLFFBQVE7QUFDaEJrQyxnQkFBVWxDLFNBQVM7QUFBQSxJQUNyQixXQUFXLENBQUNtQyxNQUFNRyxJQUFJRSxLQUFLaEMsS0FBS1IsT0FBTzBDLFlBQVksQ0FBQyxHQUFHO0FBQ3JEUixnQkFBVWxDLFNBQVM7QUFBQSxJQUNyQjtBQUVBLFFBQUksQ0FBQ1EsS0FBS1osUUFBUTJDLEtBQUssR0FBRztBQUN4QkwsZ0JBQVV0QyxVQUFVO0FBQUEsSUFDdEIsV0FBV1ksS0FBS1osUUFBUTJDLEtBQUssRUFBRUksU0FBUyxJQUFJO0FBQzFDVCxnQkFBVXRDLFVBQVU7QUFBQSxJQUN0QjtBQUVBOUIsY0FBVW9FLFNBQVM7QUFDbkIsV0FBT1UsT0FBT0MsS0FBS1gsU0FBUyxFQUFFUyxXQUFXO0FBQUEsRUFDM0M7QUFFQSxRQUFNRywwQkFBMEJBLENBQUNDLGNBQWM7QUFDN0M3RSx5QkFBcUI2RSxTQUFTO0FBRTlCLFVBQU1DLFdBQVczRSxTQUFTNEUsS0FBSyxDQUFDQyxRQUFRQSxJQUFJbEMsUUFBUStCLFNBQVM7QUFDN0QsVUFBTTNCLFFBQVE0QixVQUFVNUIsU0FBUztBQUVqQ3BDLDRCQUF3Qm9DLEtBQUs7QUFFN0I3QixnQkFBWSxDQUFDNEQsVUFBVTtBQUFBLE1BQ3JCLEdBQUdBO0FBQUFBLE1BQ0hKO0FBQUFBLE1BQ0FLLGNBQWNoQztBQUFBQSxJQUNoQixFQUFFO0FBRUZ0RCxjQUFVLENBQUNxRixVQUFVO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSEosV0FBVztBQUFBLE1BQ1hLLGNBQWM7QUFBQSxJQUNoQixFQUFFO0FBQUEsRUFDSjtBQUNBLFFBQU1DLCtCQUErQkEsQ0FBQ04sY0FBYztBQUNsRDdFLHlCQUFxQjZFLFNBQVM7QUFFOUIsVUFBTUMsV0FBVzNFLFNBQVM0RSxLQUFLLENBQUNDLFFBQVFBLElBQUlsQyxRQUFRK0IsU0FBUztBQUM3RCxVQUFNM0IsUUFBUTRCLFVBQVU1QixTQUFTO0FBRWpDcEMsNEJBQXdCb0MsS0FBSztBQUU3QmhCLHNCQUFrQixDQUFDK0MsVUFBVTtBQUFBLE1BQzNCLEdBQUdBO0FBQUFBLE1BQ0hKO0FBQUFBLE1BQ0FLLGNBQWNoQztBQUFBQSxJQUNoQixFQUFFO0FBRUZ0RCxjQUFVLENBQUNxRixVQUFVO0FBQUEsTUFDbkIsR0FBR0E7QUFBQUEsTUFDSEosV0FBVztBQUFBLE1BQ1hLLGNBQWM7QUFBQSxJQUNoQixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU1FLG1DQUFtQ0EsQ0FBQ0MsZ0JBQWdCO0FBQ3hEbkYsa0NBQThCbUYsV0FBVztBQUV6Q25ELHNCQUFrQixDQUFDK0MsVUFBVTtBQUFBLE1BQzNCLEdBQUdBO0FBQUFBLE1BQ0hLLG9CQUFvQkQ7QUFBQUEsSUFDdEIsRUFBRTtBQUVGekYsY0FBVSxDQUFDcUYsVUFBVTtBQUFBLE1BQ25CLEdBQUdBO0FBQUFBLE1BQ0hLLG9CQUFvQjtBQUFBLElBQ3RCLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTUMseUJBQXlCQSxDQUFDNUUsVUFBVTtBQUN4Q1Qsa0NBQThCUyxLQUFLO0FBQUEsRUFDckM7QUFFQSxRQUFNNkUsZUFBZSxPQUFPOUUsTUFBTTtBQUNoQ0EsTUFBRStFLGVBQWU7QUFDakIsVUFBTUMsYUFBYTNCLGFBQWEsYUFBYTtBQUU3QyxRQUFJO0FBQ0YsVUFBSTJCLFlBQVk7QUFDZCxjQUFNQyxhQUFhO0FBQUEsVUFDakIsR0FBR3ZFO0FBQUFBLFVBQ0hTLGdCQUFnQjlCO0FBQUFBLFVBQ2hCNkYsc0JBQXNCM0Y7QUFBQUEsUUFDeEI7QUFFQSxjQUFNbUMsV0FBVyxNQUFNcEUsSUFBSTZILEtBQUssY0FBY0YsWUFBWTtBQUFBLFVBQ3hERyxTQUFTO0FBQUEsWUFDUCxnQkFBZ0I7QUFBQSxVQUNsQjtBQUFBLFFBQ0YsQ0FBQztBQUVENUcscUJBQWEsS0FBSztBQUNsQm1DLG9CQUFZO0FBQUEsVUFDVkMsTUFBTTtBQUFBLFVBQ05DLE9BQU87QUFBQSxVQUNQQyxjQUFjO0FBQUEsVUFDZEMsVUFBVTtBQUFBLFVBQ1ZDLFNBQVM7QUFBQSxVQUNUQyxTQUFTO0FBQUEsVUFDVEMsV0FBVztBQUFBLFVBQ1hFLFFBQVE7QUFBQSxRQUNWLENBQUM7QUFDRDlCLDZCQUFxQixFQUFFO0FBQ3ZCRSxzQ0FBOEIsRUFBRTtBQUNoQ00seUJBQWlCLENBQUN5RSxTQUFTQSxPQUFPLENBQUM7QUFDbkNqRSx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVN1QyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sdUJBQXVCQSxLQUFLO0FBQzFDLFVBQ0VBLE1BQU10QixZQUNOc0IsTUFBTXRCLFNBQVNFLFFBQ2ZvQixNQUFNdEIsU0FBU0UsS0FBS3BCLFNBQ3BCO0FBQ0EsY0FBTTZFLFNBQVNyQyxNQUFNdEIsU0FBU0UsS0FBS3BCLFFBQVE4RSxZQUFZO0FBRXZELFlBQUlELE9BQU9FLFNBQVMsY0FBYyxHQUFHO0FBQ25Dckcsb0JBQVUsQ0FBQ3NHLGdCQUFnQjtBQUFBLFlBQ3pCLEdBQUdBO0FBQUFBLFlBQ0gxRSxjQUFjO0FBQUEsVUFDaEIsRUFBRTtBQUFBLFFBQ0osT0FBTztBQUNMUix5QkFBZTtBQUFBLFlBQ2JDLFlBQVk7QUFBQSxZQUNaQyxTQUFTd0MsTUFBTXRCLFNBQVNFLEtBQUtwQjtBQUFBQSxZQUM3QkMsTUFBTTtBQUFBLFVBQ1IsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGLE9BQU87QUFDTEgsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0YsVUFBVTtBQUFBLElBQ2QsRUFBRTlDLEtBQUssTUFBTStDLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUUvQyxLQUFLLFFBQVErQyxRQUFRLGFBQWE7QUFBQSxJQUNwQyxFQUFFL0MsS0FBSyxnQkFBZ0IrQyxRQUFRLGNBQWM7QUFBQSxJQUM3QyxFQUFFL0MsS0FBSyxnQkFBZ0IrQyxRQUFRLHFCQUFxQjtBQUFBLElBQ3BELEVBQUUvQyxLQUFLLGVBQWUrQyxRQUFRLGNBQWM7QUFBQSxJQUM1QyxFQUFFL0MsS0FBSyxZQUFZK0MsUUFBUSxpQkFBaUI7QUFBQSxJQUM1QyxFQUFFL0MsS0FBSyxVQUFVK0MsUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQyxRQUFNQyxnQkFBZ0IxSCxNQUFNOEQ7QUFBQUEsSUFBTyxDQUFDNkQsU0FDbENBLEtBQUtoRixLQUFLMEUsWUFBWSxFQUFFQyxTQUFTbEgsV0FBV2lILFlBQVksQ0FBQztBQUFBLEVBQzNEO0FBRUEsUUFBTXZDLHdCQUF3QixPQUFPOEMsV0FBVztBQUM5QyxRQUFJO0FBQ0YsWUFBTW5FLFdBQVcsTUFBTXBFLElBQUlxRSxJQUFJLG9CQUFvQmtFLE1BQU0sRUFBRTtBQUMzRC9HLHFCQUFlNEMsU0FBU0UsTUFBTUMsS0FBSztBQUNuQ25ELHlCQUFtQixJQUFJO0FBQ3ZCUSxnQkFBVSxDQUFDLENBQUM7QUFBQSxJQUNkLFNBQVM4RCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsSUFDN0M7QUFBQSxFQUNGO0FBRUEsUUFBTUgsd0JBQXdCLE9BQU9nRCxXQUFXO0FBQzlDLFFBQUk7QUFDRixZQUFNbkUsV0FBVyxNQUFNcEUsSUFBSXFFLElBQUksb0JBQW9Ca0UsTUFBTSxFQUFFO0FBQzNEN0csMkJBQXFCMEMsU0FBU0UsTUFBTUMsS0FBSztBQUN6Q0wsd0JBQWtCO0FBQUEsUUFDaEJaLE1BQU1jLFVBQVVFLE1BQU1DLE9BQU9qQjtBQUFBQSxRQUM3QkMsT0FBT2EsVUFBVUUsTUFBTUMsT0FBT2hCO0FBQUFBLFFBQzlCQyxjQUFjWSxVQUFVRSxNQUFNQyxPQUFPZjtBQUFBQSxRQUNyQ0MsVUFBVVcsVUFBVUUsTUFBTUMsT0FBT2Q7QUFBQUEsUUFDakNFLFNBQVNTLFVBQVVFLE1BQU1DLE9BQU9aO0FBQUFBLFFBQ2hDQyxXQUFXUSxVQUFVRSxNQUFNQyxPQUFPWDtBQUFBQSxRQUNsQ0UsUUFBUU0sVUFBVUUsTUFBTUMsT0FBT1Q7QUFBQUEsUUFDL0JKLFNBQVNVLFVBQVVFLE1BQU1DLE9BQU9iO0FBQUFBLE1BQ2xDLENBQUM7QUFDRDFCLDJCQUFxQm9DLFNBQVNFLE1BQU1DLE9BQU9WLGdCQUFnQmlCLE9BQU8sRUFBRTtBQUNwRTVDO0FBQUFBLFFBQ0VrQyxTQUFTRSxNQUFNQyxPQUFPcUQsd0JBQXdCO0FBQUEsTUFDaEQ7QUFDQTlFLDhCQUF3QnNCLFNBQVNFLE1BQU1DLE9BQU9WLGdCQUFnQnFCLEtBQUs7QUFDbkU1RCx5QkFBbUIsSUFBSTtBQUN2Qk0sZ0JBQVUsQ0FBQyxDQUFDO0FBQUEsSUFDZCxTQUFTOEQsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDO0FBQUEsRUFDRjtBQUlBLFFBQU04QyxvQkFBb0JBLENBQUM5RixNQUFNO0FBQy9CLFVBQU0sRUFBRVksTUFBTVgsTUFBTSxJQUFJRCxFQUFFRTtBQUMxQnNCLHNCQUFrQixDQUFDNEIsY0FBYztBQUFBLE1BQy9CLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ3hDLElBQUksR0FBR1g7QUFBQUEsSUFDVixFQUFFO0FBQUEsRUFDSjtBQUVBLFFBQU04RixtQkFBbUIsWUFBWTtBQUNuQyxRQUFJbEgsYUFBYTtBQUNmLFVBQUk7QUFDRixjQUFNdkIsSUFBSTBJLE9BQU8saUJBQWlCbkgsWUFBWXVELEdBQUcsRUFBRTtBQUNuRDFELDJCQUFtQixLQUFLO0FBQ3hCSSx1QkFBZSxJQUFJO0FBQ25CZ0IseUJBQWlCLENBQUN5RSxTQUFTQSxPQUFPLENBQUM7QUFDbkNqRSx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0gsU0FBU3VDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sd0JBQXdCQSxLQUFLO0FBQUEsTUFDN0M7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQVFGLG9CQUFvQixPQUFPK0MsV0FBVztBQUM5QyxRQUFJO0FBQ0YsWUFBTW5FLFdBQVcsTUFBTXBFLElBQUkySSxJQUFJLGlCQUFpQkosTUFBTSxJQUFJO0FBQUEsUUFDeER2RSxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBRUR4Qix1QkFBaUIsQ0FBQ3lFLFNBQVNBLE9BQU8sQ0FBQztBQUVuQ2pFLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxTQUFTdUMsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUU3QzFDLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVN3QyxPQUFPdEIsVUFBVUUsTUFBTXBCLFdBQVc7QUFBQSxRQUMzQ0MsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUUsUUFBTXlGLGVBQWUsT0FBT2xHLE1BQU07QUFDaENBLE1BQUUrRSxlQUFlO0FBQ2pCLFVBQU1vQixVQUFVOUMsYUFBYTtBQUM3QixRQUFJO0FBQ0YsVUFBSThDLFNBQVM7QUFDWCxjQUFNbEIsYUFBYTtBQUFBLFVBQ2pCLEdBQUcxRDtBQUFBQSxVQUNISixnQkFBZ0I5QjtBQUFBQSxVQUNoQjZGLHNCQUFzQjNGO0FBQUFBLFFBQ3hCO0FBQ0EsY0FBTW1DLFdBQVcsTUFBTXBFLElBQUkySTtBQUFBQSxVQUN6QixpQkFBaUJsSCxrQkFBa0JxRCxHQUFHO0FBQUEsVUFDdEM2QztBQUFBQSxRQUNGO0FBQ0FyRywyQkFBbUIsS0FBSztBQUN4QlUsNkJBQXFCLEVBQUU7QUFDdkJFLHNDQUE4QixFQUFFO0FBQ2hDTSx5QkFBaUIsQ0FBQ3lFLFNBQVNBLE9BQU8sQ0FBQztBQUNuQ2pFLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU3VDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFDNUMsVUFDRUEsTUFBTXRCLFlBQ05zQixNQUFNdEIsU0FBU0UsUUFDZm9CLE1BQU10QixTQUFTRSxLQUFLcEIsU0FDcEI7QUFDQUYsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUyxHQUFHd0MsTUFBTXRCLFNBQVNFLEtBQUtwQixPQUFPO0FBQUEsVUFDdkNDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILE9BQU87QUFDTEgsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNMkYsZ0JBQWdCLE9BQU9DLFVBQVU7QUFDckMsVUFBTUMsVUFBVUQsTUFBTW5HLE9BQU9EO0FBQzdCWCx5QkFBcUJnSCxPQUFPO0FBQzVCLFVBQU1sQyxXQUFXM0UsU0FBUzRFLEtBQUssQ0FBQ0MsUUFBUUEsSUFBSWxDLFFBQVFrRSxPQUFPO0FBQzNEbEcsNEJBQXdCZ0UsVUFBVTVCLFNBQVMsRUFBRTtBQUFBLEVBQy9DO0FBT0EsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLFlBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1CO0FBQUEsTUFFbkIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNbkMsWUFBWUk7QUFBQUEsVUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWUc7QUFBQUEsVUFDckIsU0FBUyxNQUNQRixlQUFlLENBQUNpRSxVQUFVLEVBQUUsR0FBR0EsTUFBTWhFLFlBQVksTUFBTSxFQUFFO0FBQUE7QUFBQSxRQUw3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNRztBQUFBLE1BR0gsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLGFBQ1A7QUFBQSxpQ0FBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsVUFDakIsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDBCQUF5QixpQ0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBd0Q7QUFBQSxZQUN4RDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTTtBQUNiL0IsK0JBQWEsSUFBSTtBQUNqQlUsNEJBQVUsQ0FBQyxDQUFDO0FBQUEsZ0JBQ2Q7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQW1HO0FBQUE7QUFBQSxjQUwvRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLGVBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFXQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFDQ2YsYUFBYTRGLFNBQVMsS0FBSyxDQUFDcEUsWUFDM0I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLGVBQWVrRDtBQUFBQSxZQUNmLE1BQU1uRixhQUFhUyxhQUFhZ0IsVUFBVTtBQUFBLFlBQzFDO0FBQUEsWUFDQSxpQkFBaUI7QUFBQSxZQUNqQixrQkFBa0I7QUFBQTtBQUFBLFVBTHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtpQyxJQUdqQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLFNBQVNoQixhQUFhNEYsVUFBVTtBQUFBLFlBQ2hDLE1BQUs7QUFBQTtBQUFBLFVBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR3NCO0FBQUEsV0E1QjFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErQkE7QUFBQSxTQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0NBO0FBQUEsSUFFQSx1QkFBQyxTQUFNLFdBQVd4RixXQUFXLFNBQVMsTUFBTUMsYUFBYSxLQUFLLEdBQzVELGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBdUMseUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEQ7QUFBQSxNQUM5RCx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVc0csY0FBYyxZQUFVLE1BQzVEO0FBQUEsK0JBQUMsU0FDQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFRO0FBQUEsY0FBTztBQUFBO0FBQUEsZ0JBRUwsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBO0FBQUE7QUFBQSxZQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU9wRSxTQUFTRTtBQUFBQSxjQUNoQixVQUFVdUM7QUFBQUEsY0FDVixJQUFHO0FBQUEsY0FDSCxhQUFZO0FBQUEsY0FDWjtBQUFBLGNBQ0EsV0FBVyxxQ0FBcUN2RixVQUFVMkksTUFBTTtBQUFBO0FBQUEsWUFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUTZKO0FBQUEsVUFFNUp0SCxPQUFPMkIsUUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCM0IsaUJBQU8yQixRQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRDtBQUFBLGFBbEIxRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsa0JBRVIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUp4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9GLFNBQVNHO0FBQUFBLGdCQUNoQixVQUFVc0M7QUFBQUEsZ0JBQ1YsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVcscUNBQXFDdkYsVUFBVTJJLE1BQU07QUFBQTtBQUFBLGNBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVE2SjtBQUFBLFlBRTVKdEgsT0FBTzRCLFNBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjVCLGlCQUFPNEIsU0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBdUQ7QUFBQSxlQWxCM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFvQkE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsU0FBUTtBQUFBLGdCQUFNO0FBQUE7QUFBQSxrQkFFRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUE7QUFBQTtBQUFBLGNBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxNQUFLO0FBQUEsZ0JBQ0wsT0FBT0gsU0FBU0k7QUFBQUEsZ0JBQ2hCLFVBQVVxQztBQUFBQSxnQkFDVixJQUFHO0FBQUEsZ0JBQ0gsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0EsV0FBVyxxQ0FBcUN2RixVQUFVMkksTUFBTTtBQUFBO0FBQUEsY0FSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUTZKO0FBQUEsWUFFNUp0SCxPQUFPNkIsZ0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWN0IsaUJBQU82QixnQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxhQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNkNBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsa0JBRUwsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9KLFNBQVNLO0FBQUFBLGdCQUNoQixVQUFVb0M7QUFBQUEsZ0JBQ1YsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVcscUNBQXFDdkYsVUFBVTJJLE1BQU07QUFBQTtBQUFBLGNBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVE2SjtBQUFBLFlBRTVKdEgsT0FBTzhCLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWOUIsaUJBQU84QixZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQU07QUFBQTtBQUFBLGtCQUVOLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FKMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPTCxTQUFTTztBQUFBQSxnQkFDaEIsVUFBVWtDO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ3ZGLFVBQVUySSxNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRNko7QUFBQSxZQUU1SnRILE9BQU9nQyxXQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVmhDLGlCQUFPZ0MsV0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFzQkE7QUFBQSxhQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0NBO0FBQUEsUUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFBTTtBQUFBO0FBQUEsa0JBRUEsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBO0FBQUE7QUFBQSxjQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFLQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsTUFBSztBQUFBLGdCQUNMLE9BQU9QLFNBQVNRO0FBQUFBLGdCQUNoQixVQUFVaUM7QUFBQUEsZ0JBQ1YsSUFBRztBQUFBLGdCQUNILGFBQVk7QUFBQSxnQkFDWjtBQUFBLGdCQUNBLFdBQVcscUNBQXFDdkYsVUFBVTJJLE1BQU07QUFBQTtBQUFBLGNBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVE2SjtBQUFBLFlBRTVKdEgsT0FBT2lDLGFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWakMsaUJBQU9pQyxhQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxlQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixTQUFRO0FBQUEsZ0JBQU07QUFBQTtBQUFBLGtCQUVILHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQTtBQUFBO0FBQUEsY0FKN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLE1BQUs7QUFBQSxnQkFDTCxPQUFPUixTQUFTVTtBQUFBQSxnQkFDaEIsVUFBVStCO0FBQUFBLGdCQUNWLElBQUc7QUFBQSxnQkFDSCxhQUFZO0FBQUEsZ0JBQ1o7QUFBQSxnQkFDQSxXQUFXLHFDQUFxQ3ZGLFVBQVUySSxNQUFNO0FBQUE7QUFBQSxjQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRNko7QUFBQSxZQUU1SnRILE9BQU9tQyxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJuQyxpQkFBT21DLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXdEO0FBQUEsZUFsQjVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsYUE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZDQTtBQUFBLFFBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVixTQUFRO0FBQUEsY0FBTztBQUFBO0FBQUEsZ0JBRVAsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBO0FBQUE7QUFBQSxZQUoxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU9WLFNBQVNNO0FBQUFBLGNBQ2hCLFVBQVVtQztBQUFBQSxjQUNWLElBQUc7QUFBQSxjQUNILGFBQVk7QUFBQSxjQUNaO0FBQUEsY0FDQSxXQUFXLHFDQUFxQ3ZGLFVBQVUySSxNQUFNO0FBQUE7QUFBQSxZQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRNko7QUFBQSxVQUU1SnRILE9BQU8rQixXQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkIvQixpQkFBTytCLFdBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXlEO0FBQUEsYUFsQjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUFVO0FBQUE7QUFBQSxnQkFFTix1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBO0FBQUE7QUFBQSxZQUovQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBZUE7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLElBQUc7QUFBQSxjQUNILE1BQUs7QUFBQSxjQUNMLE9BQU8zQixxQkFBcUJtSDtBQUFBQSxjQUM1QixVQUFVdEM7QUFBQUEsY0FDVixhQUFZO0FBQUEsY0FDWixXQUFVO0FBQUEsY0FDVjtBQUFBLGNBQ0EsdUJBQXVCO0FBQUEsY0FDdkIsY0FBYyxDQUFDdUMsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNyQixZQUFZLEVBQUVDLFNBQVNrQixNQUFNbkIsWUFBWSxDQUFDO0FBQUEsY0FHM0Q3RixtQkFBU3dDO0FBQUFBLGdCQUFJLENBQUNxQyxRQUNiLHVCQUFDLE9BQU8sUUFBUCxFQUE0QixPQUFPQSxJQUFJbEMsS0FDckNrQyxjQUFJOUIsU0FEYThCLElBQUlsQyxLQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFqQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0JBO0FBQUEsYUF2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdDQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDbUg7QUFBQTtBQUFBLFVBSC9IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0F6T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBPQTtBQUFBLFNBNU9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2T0EsS0E5T0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQStPQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVd6RDtBQUFBQSxRQUNYLFNBQVMsTUFBTUMsbUJBQW1CLEtBQUs7QUFBQSxRQUV2QyxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLDRCQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVc0gsY0FBYyxZQUFVLE1BQzVEO0FBQUEsbUNBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLG9CQUVMLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUo3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPM0UsZUFBZVg7QUFBQUEsa0JBQ3RCLFVBQVVrRjtBQUFBQSxrQkFDVixJQUFHO0FBQUEsa0JBQ0gsYUFBWTtBQUFBLGtCQUNaO0FBQUEsa0JBQ0EsV0FBVyxxQ0FBcUNsSSxVQUFVMkksTUFBTTtBQUFBO0FBQUEsZ0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVE2SjtBQUFBLGNBRTVKdEgsT0FBTzJCLFFBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjNCLGlCQUFPMkIsUUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0Q7QUFBQSxpQkFsQjFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVSLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUp6QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9XLGVBQWVWO0FBQUFBLG9CQUN0QixVQUFVaUY7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDbEksVUFBVTJJLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZKO0FBQUEsZ0JBRTVKdEgsT0FBTzRCLFNBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjVCLGlCQUFPNEIsU0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBdUQ7QUFBQSxtQkFsQjNEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0JBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVELHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9VLGVBQWVUO0FBQUFBLG9CQUN0QixVQUFVZ0Y7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDbEksVUFBVTJJLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZKO0FBQUEsZ0JBRTVKdEgsT0FBTzZCLGdCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdCLGlCQUFPNkIsZ0JBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGlCQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZDQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFTCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPUyxlQUFlUjtBQUFBQSxvQkFDdEIsVUFBVStFO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ2xJLFVBQVUySSxNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVE2SjtBQUFBLGdCQUU1SnRILE9BQU84QixZQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjlCLGlCQUFPOEIsWUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQU07QUFBQTtBQUFBLHNCQUVOLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9RLGVBQWVOO0FBQUFBLG9CQUN0QixVQUFVNkU7QUFBQUEsb0JBQ1YsSUFBRztBQUFBLG9CQUNILGFBQVk7QUFBQSxvQkFDWjtBQUFBLG9CQUNBLFdBQVcscUNBQXFDbEksVUFBVTJJLE1BQU07QUFBQTtBQUFBLGtCQVJsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUTZKO0FBQUEsZ0JBRTVKdEgsT0FBT2dDLFdBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWaEMsaUJBQU9nQyxXQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFzQkE7QUFBQSxpQkE5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErQ0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBTTtBQUFBO0FBQUEsc0JBRUEsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBSmpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT00sZUFBZUw7QUFBQUEsb0JBQ3RCLFVBQVU0RTtBQUFBQSxvQkFDVixJQUFHO0FBQUEsb0JBQ0gsYUFBWTtBQUFBLG9CQUNaO0FBQUEsb0JBQ0EsV0FBVyxxQ0FBcUNsSSxVQUFVMkksTUFBTTtBQUFBO0FBQUEsa0JBUmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFRNko7QUFBQSxnQkFFNUp0SCxPQUFPaUMsYUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZqQyxpQkFBT2lDLGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXNCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsU0FBUTtBQUFBLG9CQUFNO0FBQUE7QUFBQSxzQkFFSCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFpQztBQUFBO0FBQUE7QUFBQSxrQkFKOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPSyxlQUFlSDtBQUFBQSxvQkFDdEIsVUFBVTBFO0FBQUFBLG9CQUNWLElBQUc7QUFBQSxvQkFDSCxhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxXQUFXLHFDQUFxQ2xJLFVBQVUySSxNQUFNO0FBQUE7QUFBQSxrQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVE2SjtBQUFBLGdCQUU1SnRILE9BQU9tQyxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJuQyxpQkFBT21DLFVBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdEO0FBQUEsbUJBbEI1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW9CQTtBQUFBLGlCQTVDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTZDQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLG9CQUVQLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWlDO0FBQUE7QUFBQTtBQUFBLGdCQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPRyxlQUFlUDtBQUFBQSxrQkFDdEIsVUFBVThFO0FBQUFBLGtCQUNWLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFXLHFDQUFxQ2xJLFVBQVUySSxNQUFNO0FBQUE7QUFBQSxnQkFSbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBUTZKO0FBQUEsY0FFNUp0SCxPQUFPK0IsV0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCL0IsaUJBQU8rQixXQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUF5RDtBQUFBLGlCQWxCN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFvQkE7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLFNBQVE7QUFBQSxrQkFBVTtBQUFBO0FBQUEsb0JBRU4sdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBaUM7QUFBQTtBQUFBO0FBQUEsZ0JBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FlQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxJQUFHO0FBQUEsa0JBQ0gsTUFBSztBQUFBLGtCQUNMLE9BQU8zQixxQkFBcUJtSDtBQUFBQSxrQkFDNUIsVUFBVS9CO0FBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUEsa0JBQ1Y7QUFBQSxrQkFDQSx1QkFBdUI7QUFBQSxrQkFDdkIsY0FBYyxDQUFDZ0MsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNyQixZQUFZLEVBQUVDLFNBQVNrQixNQUFNbkIsWUFBWSxDQUFDO0FBQUEsa0JBRzNEN0YsbUJBQVN3QztBQUFBQSxvQkFBSSxDQUFDMkUsWUFDYix1QkFBQyxPQUFPLFFBQVAsRUFBZ0MsT0FBT0EsUUFBUXhFLEtBQzdDd0Usa0JBQVFwRSxTQURTb0UsUUFBUXhFLEtBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWtCQTtBQUFBLGNBRUNuRCxPQUFPa0Msa0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWbEMsaUJBQU9rQyxrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBNUNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOENBO0FBQUEsYUFDRWhCLHlCQUF5QixzQkFDekJBLHlCQUF5QixvQkFDekJBLHlCQUF5Qix1QkFDekIsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFVO0FBQUE7QUFBQSxnQkFGcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQU9aLDhCQUE4QmlIO0FBQUFBLGtCQUNyQyxJQUFHO0FBQUEsa0JBQ0gsVUFBVTNCO0FBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWixXQUFVO0FBQUEsa0JBQ1Y7QUFBQSxrQkFDQSx1QkFBdUI7QUFBQSxrQkFDdkIsY0FBYyxDQUFDNEIsT0FBT0MsV0FDcEJBLFFBQVFDLFVBQ0pFLFNBQVMsRUFDVnZCLFlBQVksRUFDWkMsU0FBU2tCLE1BQU1uQixZQUFZLENBQUM7QUFBQSxrQkFHakM7QUFBQSwyQ0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLElBQUcsUUFBTSxNQUFDLHdDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0NySCxNQUFNZ0U7QUFBQUEsc0JBQUksQ0FBQ0MsVUFDVix1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTUUsS0FDekNGO0FBQUFBLDhCQUFNdEI7QUFBQUEsd0JBQUs7QUFBQSx3QkFBSXNCLE9BQU9mLGdCQUFnQnFCO0FBQUFBLDJCQURyQk4sTUFBTUUsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQTtBQUFBLGdCQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F1QkE7QUFBQSxjQUNDbkQsT0FBTzRFLHFCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjVFLGlCQUFPNEUscUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWxDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9DQTtBQUFBLFlBRUYsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFDNkY7QUFBQTtBQUFBLGNBSHpHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFRQTtBQUFBLGVBdlJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBd1JBO0FBQUEsYUE1UkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTZSQTtBQUFBO0FBQUEsTUFqU0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBa1NBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3BGO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCSSx5QkFBZSxJQUFJO0FBQUEsUUFDckI7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsNEJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDRCxlQUNDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxVQUFVLENBQUNtQixNQUFNO0FBQ2ZBLGtCQUFFK0UsZUFBZTtBQUNqQmdCLGlDQUFpQjtBQUFBLGNBQ25CO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFXO0FBQUE7QUFBQSx3QkFFTjtBQUFBLHdCQUNiLHVCQUFDLFVBQUssV0FBVSwwQkFDYmxILHNCQUFZK0IsUUFEZjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsd0JBQVE7QUFBQSx3QkFBSTtBQUFBLHdCQUNTO0FBQUEsd0JBQ3JCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQWlDO0FBQUE7QUFBQTtBQUFBLG9CQVRuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBVUE7QUFBQSxrQkFDQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxNQUFLO0FBQUEsc0JBQ0wsSUFBRztBQUFBLHNCQUNILGFBQVk7QUFBQSxzQkFDWjtBQUFBLHNCQUNBLFdBQVcscUNBQXFDaEQsVUFBVTJJLE1BQU07QUFBQTtBQUFBLG9CQUxsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSzZKO0FBQUEscUJBakIvSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW1CQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBQ3lGO0FBQUE7QUFBQSxrQkFIckc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUE7QUFBQTtBQUFBLFlBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWtDQTtBQUFBLGFBdkNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5Q0E7QUFBQTtBQUFBLE1BaERGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWlEQTtBQUFBLE9BeG5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeW5CQSxLQTFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJuQkE7QUFFSjtBQUFFdkksR0Fqb0NJRCxpQkFBZTtBQUFBK0ksS0FBZi9JO0FBbW9DTixlQUFlQTtBQUFnQixJQUFBK0k7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsIk1kRGVsZXRlIiwiQ2lFZGl0IiwiSW9NZE1vcmUiLCJJbnB1dCIsIlNlbGVjdCIsIkRyb3Bkb3duIiwiTW9kYWwiLCJtYWRhbCIsImFwaSIsIkRhdGFUYWJsZSIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiTmF2YmFyIiwiZmlsdGVyT3B0aW9uIiwiQ2lyY3VsYXJMb2FkZXIiLCJmaWVsZFNpemUiLCJCcmVhZGNydW1iIiwiY29uZmlybSIsIlVudmVyaWZpZWRBZ2VudCIsIl9zIiwidXNlcnMiLCJzZXRVc2VycyIsIlRhYmxlQWdlbnRzIiwic2V0VGFibGVBZ2VudHMiLCJzZWFyY2hUZXJtIiwic2V0U2VhcmNoVGVybSIsInNob3dNb2RhbCIsInNldFNob3dNb2RhbCIsInNob3dNb2RhbERlbGV0ZSIsInNldFNob3dNb2RhbERlbGV0ZSIsInNob3dNb2RhbFVwZGF0ZSIsInNldFNob3dNb2RhbFVwZGF0ZSIsImN1cnJlbnRVc2VyIiwic2V0Q3VycmVudFVzZXIiLCJjdXJyZW50VXBkYXRlVXNlciIsInNldEN1cnJlbnRVcGRhdGVVc2VyIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJzZWxlY3RlZE1hbmFnZXJJZCIsInNldFNlbGVjdGVkTWFuYWdlcklkIiwic2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWQiLCJzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZCIsIm1hbmFnZXJzIiwic2V0TWFuYWdlcnMiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsIm9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsInNlbGVjdGVkTWFuYWdlclRpdGxlIiwic2V0U2VsZWN0ZWRNYW5hZ2VyVGl0bGUiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsIm5hbWUiLCJlbWFpbCIsInBob25lX251bWJlciIsInBhc3N3b3JkIiwiYWRkcmVzcyIsInBpbmNvZGUiLCJhZGhhYXJfbm8iLCJkZXNpZ25hdGlvbl9pZCIsInBhbl9ubyIsImFnZW50X3R5cGUiLCJpc1ZlcmlmaWVkIiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsImZldGNoQWdlbnRzIiwicmVzcG9uc2UiLCJnZXQiLCJkYXRhIiwiYWdlbnQiLCJmb3JtYXR0ZWREYXRhIiwiZmlsdGVyIiwidiIsIm1hcCIsImdyb3VwIiwiaW5kZXgiLCJfaWQiLCJpZCIsImVtcGxveWVlQ29kZSIsImRlc2lnbmF0aW9uIiwidGl0bGUiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlVmVyaWZ5QWdlbnQiLCJoYW5kbGVEZWxldGVNb2RhbE9wZW4iLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaE1hbmFnZXJzIiwiaGFuZGxlQ2hhbmdlIiwicHJldkRhdGEiLCJ2YWxpZGF0ZUZvcm0iLCJuZXdFcnJvcnMiLCJyZWdleCIsInBob25lIiwiYWFkaGFhciIsInBhbiIsInRyaW0iLCJ0ZXN0IiwicmVwb3J0aW5nX21hbmFnZXIiLCJ0b1VwcGVyQ2FzZSIsImxlbmd0aCIsIk9iamVjdCIsImtleXMiLCJoYW5kbGVBbnREU2VsZWN0TWFuYWdlciIsIm1hbmFnZXJJZCIsInNlbGVjdGVkIiwiZmluZCIsIm1nciIsInByZXYiLCJtYW5hZ2VyVGl0bGUiLCJoYW5kbGVBbnRJbnB1dERTZWxlY3RNYW5hZ2VyIiwiaGFuZGxlQW50RFNlbGVjdFJlcG9ydGluZ01hbmFnZXIiLCJyZXBvcnRpbmdJZCIsInJlcG9ydGluZ01hbmFnZXJJZCIsImhhbmRsZVJlcG9ydGluZ01hbmFnZXIiLCJoYW5kbGVTdWJtaXQiLCJwcmV2ZW50RGVmYXVsdCIsImlzVmFsaWRhdGUiLCJkYXRhVG9TZW5kIiwicmVwb3J0aW5nX21hbmFnZXJfaWQiLCJwb3N0IiwiaGVhZGVycyIsImVyck1zZyIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJwcmV2RXJyb3JzIiwiY29sdW1ucyIsImhlYWRlciIsImZpbHRlcmVkVXNlcnMiLCJ1c2VyIiwidXNlcklkIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJoYW5kbGVEZWxldGVVc2VyIiwiZGVsZXRlIiwicHV0IiwiaGFuZGxlVXBkYXRlIiwiaXNWYWxpZCIsImhhbmRsZU1hbmFnZXIiLCJldmVudCIsImdyb3VwSWQiLCJoZWlnaHQiLCJ1bmRlZmluZWQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwibWFuYWdlciIsInRvU3RyaW5nIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVW52ZXJpZmllZEFnZW50LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBNZERlbGV0ZSB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBDaUVkaXQgfSBmcm9tIFwicmVhY3QtaWNvbnMvY2lcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgSW5wdXQsIFNlbGVjdCwgRHJvcGRvd24gLE1vZGFsIGFzIG1hZGFsfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IENpcmN1bGFyTG9hZGVyIGZyb20gXCIuLi9jb21wb25lbnRzL2xvYWRlcnMvQ2lyY3VsYXJMb2FkZXJcIjtcclxuaW1wb3J0IHsgZmllbGRTaXplIH0gZnJvbSBcIi4uL2RhdGEvZmllbGRTaXplXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuY29uc3QgeyBjb25maXJtIH0gPSBtYWRhbDtcclxuY29uc3QgVW52ZXJpZmllZEFnZW50ID0gKCkgPT4ge1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtUYWJsZUFnZW50cywgc2V0VGFibGVBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd01vZGFsVXBkYXRlLCBzZXRTaG93TW9kYWxVcGRhdGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXNlciwgc2V0Q3VycmVudFVzZXJdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2N1cnJlbnRVcGRhdGVVc2VyLCBzZXRDdXJyZW50VXBkYXRlVXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZE1hbmFnZXJJZCwgc2V0U2VsZWN0ZWRNYW5hZ2VySWRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkLCBzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZF0gPVxyXG4gICAgdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW21hbmFnZXJzLCBzZXRNYW5hZ2Vyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG4gIGNvbnN0IFtzZWxlY3RlZE1hbmFnZXJUaXRsZSwgc2V0U2VsZWN0ZWRNYW5hZ2VyVGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgbmFtZTogXCJcIixcclxuICAgIGVtYWlsOiBcIlwiLFxyXG4gICAgcGhvbmVfbnVtYmVyOiBcIlwiLFxyXG4gICAgcGFzc3dvcmQ6IFwiXCIsXHJcbiAgICBhZGRyZXNzOiBcIlwiLFxyXG4gICAgcGluY29kZTogXCJcIixcclxuICAgIGFkaGFhcl9ubzogXCJcIixcclxuICAgIGRlc2lnbmF0aW9uX2lkOiBcIlwiLFxyXG4gICAgcGFuX25vOiBcIlwiLFxyXG4gICAgYWdlbnRfdHlwZTogXCJhZ2VudFwiLFxyXG4gICAgaXNWZXJpZmllZDogXCJmYWxzZVwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIG5hbWU6IFwiXCIsXHJcbiAgICBlbWFpbDogXCJcIixcclxuICAgIHBob25lX251bWJlcjogXCJcIixcclxuICAgIHBhc3N3b3JkOiBcIlwiLFxyXG4gICAgYWRkcmVzczogXCJcIixcclxuICAgIHBpbmNvZGU6IFwiXCIsXHJcbiAgICBhZGhhYXJfbm86IFwiXCIsXHJcbiAgICBkZXNpZ25hdGlvbl9pZDogXCJcIixcclxuICAgIHBhbl9ubzogXCJcIixcclxuICAgIGlzVmVyaWZpZWQ6IFwiZmFsc2VcIixcclxuICB9KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQWdlbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0XCIpO1xyXG4gICAgICAgIHNldFVzZXJzKHJlc3BvbnNlPy5kYXRhPy5hZ2VudCk7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGE/LmFnZW50XHJcbiAgICAgICAgICA/LmZpbHRlcigodikgPT4gdi5pc1ZlcmlmaWVkID09PSBmYWxzZSB8fCB2LmlzVmVyaWZpZWQgPT09IFwiZmFsc2VcIilcclxuICAgICAgICAgIC5tYXAoKGdyb3VwLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgICAgX2lkOiBncm91cD8uX2lkLFxyXG4gICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICBuYW1lOiBncm91cD8ubmFtZSxcclxuICAgICAgICAgICAgZW1wbG95ZWVDb2RlOiBncm91cD8uZW1wbG95ZWVDb2RlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgcGFzc3dvcmQ6IGdyb3VwPy5wYXNzd29yZCxcclxuICAgICAgICAgICAgZGVzaWduYXRpb246IGdyb3VwPy5kZXNpZ25hdGlvbl9pZD8udGl0bGUsXHJcbiAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciAgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIHsvKiA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItZ3JlZW4tNDAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQtbWQgc2hhZG93IGhvdmVyOmJvcmRlci1ncmVlbi03MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxDaUVkaXQgY29sb3I9XCJncmVlblwiIC8+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+ICovfVxyXG4gICAgICAgICAgICAgICAgPERyb3Bkb3duXHJcbiAgICAgICAgICAgICAgICAgIHRyaWdnZXI9e1tcImNsaWNrXCJdfVxyXG4gICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbXM6IFtcclxuICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVmVyaWZ5QWdlbnQoZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBWZXJpZnlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZFwiIC8+XHJcbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldFRhYmxlQWdlbnRzKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyB1c2VyIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hBZ2VudHMoKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hNYW5hZ2VycyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvZGVzaWduYXRpb24vZ2V0LWRlc2lnbmF0aW9uXCIpO1xyXG4gICAgICAgIHNldE1hbmFnZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaE1hbmFnZXJzKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgIH0pKTtcclxuICAgIHNldEVycm9ycygocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgY29uc3QgZGF0YSA9IHR5cGUgPT09IFwiYWRkRW1wbG95ZWVcIiA/IGZvcm1EYXRhIDogdXBkYXRlRm9ybURhdGE7XHJcbiAgICBjb25zdCByZWdleCA9IHtcclxuICAgICAgZW1haWw6IC9eW15cXHNAXStAW15cXHNAXStcXC5bXlxcc0BdKyQvLFxyXG4gICAgICBwaG9uZTogL15bNi05XVxcZHs5fSQvLFxyXG4gICAgICBwYXNzd29yZDpcclxuICAgICAgICAvXig/PS4qW2Etel0pKD89LipbQS1aXSkoPz0uKlxcZCkoPz0uKltAJCElKj8mXSlbQS1aYS16XFxkQCQhJSo/Jl17NSx9JC8sXHJcbiAgICAgIHBpbmNvZGU6IC9eXFxkezZ9JC8sXHJcbiAgICAgIGFhZGhhYXI6IC9eXFxkezEyfSQvLFxyXG4gICAgICBwYW46IC9eW0EtWl17NX1bMC05XXs0fVtBLVpdezF9JC8sXHJcbiAgICB9O1xyXG5cclxuICAgIGlmICghZGF0YS5uYW1lLnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMubmFtZSA9IFwiRnVsbCBOYW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLmVtYWlsKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5lbWFpbCA9IFwiRW1haWwgaXMgcmVxdWlyZWRcIjtcclxuICAgIH0gZWxzZSBpZiAoIXJlZ2V4LmVtYWlsLnRlc3QoZGF0YS5lbWFpbCkpIHtcclxuICAgICAgbmV3RXJyb3JzLmVtYWlsID0gXCJJbnZhbGlkIGVtYWlsIGZvcm1hdFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5waG9uZV9udW1iZXIpIHtcclxuICAgICAgbmV3RXJyb3JzLnBob25lX251bWJlciA9IFwiUGhvbmUgbnVtYmVyIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKCFyZWdleC5waG9uZS50ZXN0KGRhdGEucGhvbmVfbnVtYmVyKSkge1xyXG4gICAgICBuZXdFcnJvcnMucGhvbmVfbnVtYmVyID0gXCJJbnZhbGlkICBwaG9uZSBudW1iZXJcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEucGFzc3dvcmQpIHtcclxuICAgICAgbmV3RXJyb3JzLnBhc3N3b3JkID0gXCJQYXNzd29yZCBpcyByZXF1aXJlZFwiO1xyXG4gICAgfSBlbHNlIGlmICghcmVnZXgucGFzc3dvcmQudGVzdChkYXRhLnBhc3N3b3JkKSkge1xyXG4gICAgICBuZXdFcnJvcnMucGFzc3dvcmQgPVxyXG4gICAgICAgIFwiUGFzc3dvcmQgbXVzdCBjb250YWluIGF0IGxlYXN0IDUgY2hhcmFjdGVycywgb25lIHVwcGVyY2FzZSwgb25lIGxvd2VyY2FzZSwgb25lIG51bWJlciwgYW5kIG9uZSBzcGVjaWFsIGNoYXJhY3RlclwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZGF0YS5waW5jb2RlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5waW5jb2RlID0gXCJQaW5jb2RlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKCFyZWdleC5waW5jb2RlLnRlc3QoZGF0YS5waW5jb2RlKSkge1xyXG4gICAgICBuZXdFcnJvcnMucGluY29kZSA9IFwiSW52YWxpZCBwaW5jb2RlICg2IGRpZ2l0cyByZXF1aXJlZClcIjtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoIWRhdGEuYWRoYWFyX25vKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hZGhhYXJfbm8gPSBcIkFhZGhhYXIgbnVtYmVyIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKCFyZWdleC5hYWRoYWFyLnRlc3QoZGF0YS5hZGhhYXJfbm8pKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hZGhhYXJfbm8gPSBcIkludmFsaWQgQWFkaGFhciBudW1iZXIgKDEyIGRpZ2l0cyByZXF1aXJlZClcIjtcclxuICAgIH1cclxuICAgIGlmICghc2VsZWN0ZWRNYW5hZ2VySWQpIHtcclxuICAgICAgbmV3RXJyb3JzLnJlcG9ydGluZ19tYW5hZ2VyID0gXCJSZXBvcnRpbmcgTWFuYWdlciBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLnBhbl9ubykge1xyXG4gICAgICBuZXdFcnJvcnMucGFuX25vID0gXCJQQU4gbnVtYmVyIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKCFyZWdleC5wYW4udGVzdChkYXRhLnBhbl9uby50b1VwcGVyQ2FzZSgpKSkge1xyXG4gICAgICBuZXdFcnJvcnMucGFuX25vID0gXCJJbnZhbGlkIFBBTiBmb3JtYXQgKGUuZy4sIEFCQ0RFMTIzNEYpXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFkYXRhLmFkZHJlc3MudHJpbSgpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hZGRyZXNzID0gXCJBZGRyZXNzIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKGRhdGEuYWRkcmVzcy50cmltKCkubGVuZ3RoIDwgMTApIHtcclxuICAgICAgbmV3RXJyb3JzLmFkZHJlc3MgPSBcIkFkZHJlc3Mgc2hvdWxkIGJlIGF0IGxlYXN0IDEwIGNoYXJhY3RlcnNcIjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVBbnREU2VsZWN0TWFuYWdlciA9IChtYW5hZ2VySWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkTWFuYWdlcklkKG1hbmFnZXJJZCk7XHJcblxyXG4gICAgY29uc3Qgc2VsZWN0ZWQgPSBtYW5hZ2Vycy5maW5kKChtZ3IpID0+IG1nci5faWQgPT09IG1hbmFnZXJJZCk7XHJcbiAgICBjb25zdCB0aXRsZSA9IHNlbGVjdGVkPy50aXRsZSB8fCBcIlwiO1xyXG5cclxuICAgIHNldFNlbGVjdGVkTWFuYWdlclRpdGxlKHRpdGxlKTtcclxuXHJcbiAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgbWFuYWdlcklkLFxyXG4gICAgICBtYW5hZ2VyVGl0bGU6IHRpdGxlLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgbWFuYWdlcklkOiBcIlwiLFxyXG4gICAgICBtYW5hZ2VyVGl0bGU6IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVBbnRJbnB1dERTZWxlY3RNYW5hZ2VyID0gKG1hbmFnZXJJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRNYW5hZ2VySWQobWFuYWdlcklkKTtcclxuXHJcbiAgICBjb25zdCBzZWxlY3RlZCA9IG1hbmFnZXJzLmZpbmQoKG1ncikgPT4gbWdyLl9pZCA9PT0gbWFuYWdlcklkKTtcclxuICAgIGNvbnN0IHRpdGxlID0gc2VsZWN0ZWQ/LnRpdGxlIHx8IFwiXCI7XHJcblxyXG4gICAgc2V0U2VsZWN0ZWRNYW5hZ2VyVGl0bGUodGl0bGUpO1xyXG5cclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBtYW5hZ2VySWQsXHJcbiAgICAgIG1hbmFnZXJUaXRsZTogdGl0bGUsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICBtYW5hZ2VySWQ6IFwiXCIsXHJcbiAgICAgIG1hbmFnZXJUaXRsZTogXCJcIixcclxuICAgIH0pKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVBbnREU2VsZWN0UmVwb3J0aW5nTWFuYWdlciA9IChyZXBvcnRpbmdJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWQocmVwb3J0aW5nSWQpO1xyXG5cclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAuLi5wcmV2LFxyXG4gICAgICByZXBvcnRpbmdNYW5hZ2VySWQ6IHJlcG9ydGluZ0lkLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIHNldEVycm9ycygocHJldikgPT4gKHtcclxuICAgICAgLi4ucHJldixcclxuICAgICAgcmVwb3J0aW5nTWFuYWdlcklkOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlcG9ydGluZ01hbmFnZXIgPSAodmFsdWUpID0+IHtcclxuICAgIHNldFNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkKHZhbHVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZGF0ZSA9IHZhbGlkYXRlRm9ybShcImFkZEVtcGxveWVlXCIpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGlmIChpc1ZhbGlkYXRlKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YVRvU2VuZCA9IHtcclxuICAgICAgICAgIC4uLmZvcm1EYXRhLFxyXG4gICAgICAgICAgZGVzaWduYXRpb25faWQ6IHNlbGVjdGVkTWFuYWdlcklkLFxyXG4gICAgICAgICAgcmVwb3J0aW5nX21hbmFnZXJfaWQ6IHNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkLFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoXCIvYWdlbnQvYWRkXCIsIGRhdGFUb1NlbmQsIHtcclxuICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZXRTaG93TW9kYWwoZmFsc2UpO1xyXG4gICAgICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgICAgIG5hbWU6IFwiXCIsXHJcbiAgICAgICAgICBlbWFpbDogXCJcIixcclxuICAgICAgICAgIHBob25lX251bWJlcjogXCJcIixcclxuICAgICAgICAgIHBhc3N3b3JkOiBcIlwiLFxyXG4gICAgICAgICAgYWRkcmVzczogXCJcIixcclxuICAgICAgICAgIHBpbmNvZGU6IFwiXCIsXHJcbiAgICAgICAgICBhZGhhYXJfbm86IFwiXCIsXHJcbiAgICAgICAgICBwYW5fbm86IFwiXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRNYW5hZ2VySWQoXCJcIik7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWQoXCJcIik7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkFnZW50IEFkZGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBhZGRpbmcgYWdlbnQ6XCIsIGVycm9yKTtcclxuICAgICAgaWYgKFxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlICYmXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YSAmJlxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZVxyXG4gICAgICApIHtcclxuICAgICAgICBjb25zdCBlcnJNc2cgPSBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2UudG9Mb3dlckNhc2UoKTtcclxuXHJcbiAgICAgICAgaWYgKGVyck1zZy5pbmNsdWRlcyhcInBob25lIG51bWJlclwiKSkge1xyXG4gICAgICAgICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5wcmV2RXJyb3JzLFxyXG4gICAgICAgICAgICBwaG9uZV9udW1iZXI6IFwiUGhvbmUgbnVtYmVyIGFscmVhZHkgZXhpc3RzXCIsXHJcbiAgICAgICAgICB9KSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgbWVzc2FnZTogZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlLFxyXG4gICAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZC4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkFnZW50IE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW1wbG95ZWVDb2RlXCIsIGhlYWRlcjogXCJFbXBsb3llZSBJRFwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkFnZW50IFBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJkZXNpZ25hdGlvblwiLCBoZWFkZXI6IFwiRGVzaWduYXRpb25cIiB9LFxyXG4gICAgeyBrZXk6IFwicGFzc3dvcmRcIiwgaGVhZGVyOiBcIkFnZW50IFBhc3N3b3JkXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBmaWx0ZXJlZFVzZXJzID0gdXNlcnMuZmlsdGVyKCh1c2VyKSA9PlxyXG4gICAgdXNlci5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGVybS50b0xvd2VyQ2FzZSgpKSxcclxuICApO1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9hZ2VudC9nZXQtYnktaWQvJHt1c2VySWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRVc2VyKHJlc3BvbnNlLmRhdGE/LmFnZW50KTtcclxuICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXI6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGVNb2RhbE9wZW4gPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9hZ2VudC9nZXQtYnktaWQvJHt1c2VySWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVVc2VyKHJlc3BvbnNlLmRhdGE/LmFnZW50KTtcclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoe1xyXG4gICAgICAgIG5hbWU6IHJlc3BvbnNlPy5kYXRhPy5hZ2VudD8ubmFtZSxcclxuICAgICAgICBlbWFpbDogcmVzcG9uc2U/LmRhdGE/LmFnZW50Py5lbWFpbCxcclxuICAgICAgICBwaG9uZV9udW1iZXI6IHJlc3BvbnNlPy5kYXRhPy5hZ2VudD8ucGhvbmVfbnVtYmVyLFxyXG4gICAgICAgIHBhc3N3b3JkOiByZXNwb25zZT8uZGF0YT8uYWdlbnQ/LnBhc3N3b3JkLFxyXG4gICAgICAgIHBpbmNvZGU6IHJlc3BvbnNlPy5kYXRhPy5hZ2VudD8ucGluY29kZSxcclxuICAgICAgICBhZGhhYXJfbm86IHJlc3BvbnNlPy5kYXRhPy5hZ2VudD8uYWRoYWFyX25vLFxyXG4gICAgICAgIHBhbl9ubzogcmVzcG9uc2U/LmRhdGE/LmFnZW50Py5wYW5fbm8sXHJcbiAgICAgICAgYWRkcmVzczogcmVzcG9uc2U/LmRhdGE/LmFnZW50Py5hZGRyZXNzLFxyXG4gICAgICB9KTtcclxuICAgICAgc2V0U2VsZWN0ZWRNYW5hZ2VySWQocmVzcG9uc2UuZGF0YT8uYWdlbnQ/LmRlc2lnbmF0aW9uX2lkPy5faWQgfHwgXCJcIik7XHJcbiAgICAgIHNldFNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkKFxyXG4gICAgICAgIHJlc3BvbnNlLmRhdGE/LmFnZW50Py5yZXBvcnRpbmdfbWFuYWdlcl9pZCB8fCBcIlwiLFxyXG4gICAgICApO1xyXG4gICAgICBzZXRTZWxlY3RlZE1hbmFnZXJUaXRsZShyZXNwb25zZS5kYXRhPy5hZ2VudD8uZGVzaWduYXRpb25faWQ/LnRpdGxlKTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcnMoe30pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXI6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBcclxuXHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBbbmFtZV06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZVVzZXIgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoY3VycmVudFVzZXIpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKGAvYWdlbnQvZGVsZXRlLyR7Y3VycmVudFVzZXIuX2lkfWApO1xyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudFVzZXIobnVsbCk7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkFnZW50IGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZGVsZXRpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgICBoYW5kbGVWZXJpZnlBZ2VudCA9IGFzeW5jICh1c2VySWQpID0+IHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucHV0KGAvYWdlbnQvdXBkYXRlLyR7dXNlcklkfWAsIHtcclxuICAgICAgaXNWZXJpZmllZDogdHJ1ZSxcclxuICAgIH0pO1xyXG5cclxuICAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuXHJcbiAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIG1lc3NhZ2U6IFwiQWdlbnQgVmVyaWZpZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgfSk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciB2ZXJpZnlpbmcgYWdlbnQ6XCIsIGVycm9yKTtcclxuXHJcbiAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIG1lc3NhZ2U6IGVycm9yPy5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byB2ZXJpZnkgYWdlbnRcIixcclxuICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgfSk7XHJcbiAgfVxyXG59O1xyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXNWYWxpZCA9IHZhbGlkYXRlRm9ybSgpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgaWYgKGlzVmFsaWQpIHtcclxuICAgICAgICBjb25zdCBkYXRhVG9TZW5kID0ge1xyXG4gICAgICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgICAgICBkZXNpZ25hdGlvbl9pZDogc2VsZWN0ZWRNYW5hZ2VySWQsXHJcbiAgICAgICAgICByZXBvcnRpbmdfbWFuYWdlcl9pZDogc2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWQsXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgICBgL2FnZW50L3VwZGF0ZS8ke2N1cnJlbnRVcGRhdGVVc2VyLl9pZH1gLFxyXG4gICAgICAgICAgZGF0YVRvU2VuZCxcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRNYW5hZ2VySWQoXCJcIik7XHJcbiAgICAgICAgc2V0U2VsZWN0ZWRSZXBvcnRpbmdNYW5hZ2VySWQoXCJcIik7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkFnZW50IFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIGFnZW50OlwiLCBlcnJvcik7XHJcbiAgICAgIGlmIChcclxuICAgICAgICBlcnJvci5yZXNwb25zZSAmJlxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlLmRhdGEgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2VcclxuICAgICAgKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IGAke2Vycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZX1gLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWQuIFBsZWFzZSB0cnkgYWdhaW4uXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVNYW5hZ2VyID0gYXN5bmMgKGV2ZW50KSA9PiB7XHJcbiAgICBjb25zdCBncm91cElkID0gZXZlbnQudGFyZ2V0LnZhbHVlO1xyXG4gICAgc2V0U2VsZWN0ZWRNYW5hZ2VySWQoZ3JvdXBJZCk7XHJcbiAgICBjb25zdCBzZWxlY3RlZCA9IG1hbmFnZXJzLmZpbmQoKG1ncikgPT4gbWdyLl9pZCA9PT0gZ3JvdXBJZCk7XHJcbiAgICBzZXRTZWxlY3RlZE1hbmFnZXJUaXRsZShzZWxlY3RlZD8udGl0bGUgfHwgXCJcIik7XHJcbiAgfTtcclxuXHJcbiAgLy8gY29uc3QgaGFuZGxlUmVwb3J0aW5nTWFuYWdlciA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gIC8vICAgY29uc3QgcmVwb3J0aW5nSWQgPSBldmVudC50YXJnZXQudmFsdWU7XHJcbiAgLy8gICBzZXRTZWxlY3RlZFJlcG9ydGluZ01hbmFnZXJJZChyZXBvcnRpbmdJZCk7XHJcbiAgLy8gfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTdcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5VbnZlcmlmaWVkIEFnZW50czwvaDE+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy1ibHVlLTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ibHVlLTgwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICsgQWRkIEFnZW50XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHtUYWJsZUFnZW50cz8ubGVuZ3RoID4gMCAmJiAhaXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9e2hhbmRsZVVwZGF0ZU1vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbihUYWJsZUFnZW50cywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPXtgQWdlbnRzYH1cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9e2BBZ2VudHMuY3N2YH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICBmYWlsdXJlPXtUYWJsZUFnZW50cz8ubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgICBkYXRhPVwiRW1wbG95ZWUgRGF0YVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8TW9kYWwgaXNWaXNpYmxlPXtzaG93TW9kYWx9IG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbChmYWxzZSl9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPkFkZCBBZ2VudDwvaDM+XHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEZ1bGwgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEZ1bGwgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5uYW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMubmFtZX08L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBFbWFpbCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIEVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZW1haWwgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmVtYWlsfTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGhvbmUgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwaG9uZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGhvbmUgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGhvbmVfbnVtYmVyICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGFzc3dvcmQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBhc3N3b3JkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFzc3dvcmQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQaW5jb2RlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGluY29kZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGluY29kZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBBZGhhYXIgTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZGhhYXJfbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5hZGhhYXJfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgQWRoYWFyIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkaGFhcl9ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZGhhYXJfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQYW4gTnVtYmVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFuX25vXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEucGFuX25vfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIFBhbiBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYW5fbm8gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnBhbl9ub308L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQWRkcmVzcyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEFkZHJlc3NcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRkcmVzcyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmFkZHJlc3N9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRGVzaWduYXRpb24gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgey8qIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkTWFuYWdlcklkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlTWFuYWdlcn1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJcIiBoaWRkZW4+XHJcbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0IERlc2lnbmF0aW9uXHJcbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICB7bWFuYWdlcnMubWFwKChncm91cCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2dyb3VwLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PiAqL31cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJtYW5hZ2VyLXNlbGVjdFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJtYW5hZ2VySWRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRNYW5hZ2VySWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQW50RFNlbGVjdE1hbmFnZXJ9XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IERlc2lnbmF0aW9uXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge21hbmFnZXJzLm1hcCgobWdyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXttZ3IuX2lkfSB2YWx1ZT17bWdyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bWdyLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMFxyXG4gICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXIgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2F2ZSBBZ2VudFxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxVcGRhdGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBVcGRhdGUgQWdlbnRcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS02XCIgb25TdWJtaXQ9e2hhbmRsZVVwZGF0ZX0gbm9WYWxpZGF0ZT5cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgRnVsbCBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLm5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgRnVsbCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLm5hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+e2Vycm9ycy5uYW1lfTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIEVtYWlsIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJlbWFpbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmVtYWlsfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgRW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5lbWFpbCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuZW1haWx9PC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQaG9uZSBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwaG9uZV9udW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBQaG9uZSBOdW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5waG9uZV9udW1iZXIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGFzc3dvcmQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5wYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ1cGRhdGUtcGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBQaW5jb2RlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5waW5jb2RlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBpbmNvZGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMucGluY29kZX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQWRoYWFyIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZGhhYXJfbm9cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5hZGhhYXJfbm99XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBBZGhhYXIgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYWRoYWFyX25vICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmFkaGFhcl9ub31cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBhbiBOdW1iZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGFuX25vXCJcclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEucGFuX25vfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgUGFuIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnBhbl9ubyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMucGFuX25vfTwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBBZGRyZXNzIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZGRyZXNzXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmFkZHJlc3N9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgaWQ9XCJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQWRkcmVzc1wiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5hZGRyZXNzICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuYWRkcmVzc308L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEZXNpZ25hdGlvbiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICB7LyogPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRNYW5hZ2VySWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVNYW5hZ2VyfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCIgaGlkZGVuPlxyXG4gICAgICAgICAgICAgICAgICAgIFNlbGVjdCBEZXNpZ25hdGlvblxyXG4gICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAge21hbmFnZXJzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cC50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD4gKi99XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwic2VsZWN0ZWRNYW5hZ2VySWRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwic2VsZWN0ZWRNYW5hZ2VySWRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRNYW5hZ2VySWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQW50SW5wdXREU2VsZWN0TWFuYWdlcn1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRGVzaWduYXRpb25cIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7bWFuYWdlcnMubWFwKChtYW5hZ2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXttYW5hZ2VyLl9pZH0gdmFsdWU9e21hbmFnZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHttYW5hZ2VyLnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuXHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmRlc2lnbmF0aW9uX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuZGVzaWduYXRpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgeyhzZWxlY3RlZE1hbmFnZXJUaXRsZSA9PT0gXCJTYWxlcyBFeGNlY3V0aXZlXCIgfHxcclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkTWFuYWdlclRpdGxlID09PSBcIkJ1c2luZXNzIEFnZW50XCIgfHxcclxuICAgICAgICAgICAgICAgIHNlbGVjdGVkTWFuYWdlclRpdGxlID09PSBcIk9mZmljZSBFeGVjdXRpdmVcIikgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBSZXBvcnRpbmcgTWFuYWdlclxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICBpZD1cInNlbGVjdGVkUmVwb3J0aW5nTWFuYWdlcklkXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUmVwb3J0aW5nTWFuYWdlcn1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBSZXBvcnRpbmcgTWFuYWdlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uPy5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA/LnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJcIiBoaWRkZW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgUmVwb3J0aW5nIE1hbmFnZXJcclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLm5hbWV9IC0ge2dyb3VwPy5kZXNpZ25hdGlvbl9pZD8udGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLnJlcG9ydGluZ19tYW5hZ2VyICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnJlcG9ydGluZ19tYW5hZ2VyfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMCBib3JkZXItMiBib3JkZXItYmxhY2tcclxuICAgICAgICAgICAgICBmb2N1czpyaW5nLTQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctYmx1ZS0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgVXBkYXRlIEFnZW50XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbERlbGV0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudFVzZXIobnVsbCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtYi00IHRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICBEZWxldGUgQWdlbnRcclxuICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAge2N1cnJlbnRVc2VyICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlVXNlcigpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJncm91cE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGxlYXNlIGVudGVye1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdG8gY29uZmlybSBkZWxldGlvbi57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBpZD1cImdyb3VwTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgZW1wbG95ZWUgRnVsbCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNWB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LXdoaXRlIGJnLXJlZC03MDAgaG92ZXI6YmctcmVkLTgwMFxyXG4gICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWJsdWUtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVW52ZXJpZmllZEFnZW50O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvVW52ZXJpZmllZEFnZW50LmpzeCJ9