import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AuctionWinnerDocuments.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Select } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { Ticket } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import { FaUsers, FaCheckCircle } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const AuctionWinnerDocuments = () => {
  _s();
  const [searchText, setSearchText] = useState("");
  const [usersData, setUsersData] = useState([]);
  const [groupFilter, setGroupFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [activeUserData, setActiveUserData] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [totalUsers, setTotalUsers] = useState(0);
  const [notifier, contextHolder] = notification.useNotification();
  const [selectAll, setSelectAll] = useState(false);
  const [auctionData, setAuctionData] = useState([]);
  const groupOptions = [
    ...new Set(
      usersData.filter((u) => u.groupName !== void 0 && u.groupName !== "" && u.groupName !== "   ").map((u) => u.groupName)
    )
  ];
  const filteredUsers = useMemo(() => {
    const filtered = filterOption(
      usersData.filter((u) => {
        const matchGroup = groupFilter ? u.groupName === groupFilter : true;
        const enrollmentDate = new Date(u.enrollmentDate);
        const matchFromDate = fromDate ? enrollmentDate >= new Date(fromDate) : true;
        const matchToDate = toDate ? enrollmentDate <= new Date(toDate) : true;
        return matchGroup && matchFromDate && matchToDate;
      }),
      searchText
    );
    return filtered.map((user, index) => {
      const isSelected = !!activeUserData[user._id]?.info?.status;
      return {
        ...user,
        sl_no: index + 1,
        checkBoxs: /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "checkbox",
            checked: isSelected,
            onChange: (e) => {
              setActiveUserData((prev) => ({
                ...prev,
                [user._id]: {
                  info: {
                    status: e.target.checked,
                    userPhone: user.userPhone,
                    groupName: user.groupName,
                    userName: user.userName,
                    ticket: user.ticket
                    // groupId: user.groupId,
                    // userId: user.userId,
                  }
                }
              }));
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
            lineNumber: 58,
            columnNumber: 9
          },
          this
        ),
        isSelected
      };
    });
  }, [usersData, groupFilter, fromDate, toDate, searchText, activeUserData]);
  const visibleSelectedCount = useMemo(() => {
    return filteredUsers.filter((user) => user.isSelected).length;
  }, [filteredUsers]);
  const sendWhatsapp = async () => {
    const key = "updatable";
    try {
      notifier.open({
        key,
        message: "Sending Messages Via Whatsapp..",
        description: "Processing...",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
      const visibleActiveUsers = {};
      filteredUsers.forEach((user) => {
        if (user.isSelected && activeUserData[user._id]) {
          visibleActiveUsers[user._id] = activeUserData[user._id];
        }
      });
      await api.post("/whatsapp/auction-winner-document-list", {
        receivers: visibleActiveUsers
      });
      const newActiveUserData = { ...activeUserData };
      filteredUsers.forEach((user) => {
        if (user.isSelected) {
          delete newActiveUserData[user._id];
        }
      });
      setActiveUserData(newActiveUserData);
      notifier.open({
        key,
        message: "Whatsapp Messages Has Been Sent Successfully",
        description: "Success",
        className: "bg-green-300 rounded-lg font-bold",
        duration: 2
      });
    } catch (err) {
      notifier.open({
        key,
        message: "Failed to Send Whatsapp",
        description: err.message || "Something went wrong",
        className: "bg-red-300 rounded-lg font-bold",
        duration: 2
      });
    }
  };
  useEffect(() => {
    const allChecked = filteredUsers.length > 0 && filteredUsers.every((user) => activeUserData[user._id]?.info?.status);
    setSelectAll(allChecked);
  }, [filteredUsers, activeUserData]);
  const fetchData = async () => {
    try {
      setIsLoading(true);
      const reportResponse = await api.get("/auction/get-auction");
      const usersList = [];
      const tempActive = {};
      const auctionData2 = reportResponse.data?.auction.map((auction, index) => {
        const id = auction._id;
        const userName = auction.user_id?.full_name;
        const userPhone = auction.user_id?.phone_number;
        const groupName = auction.group_id?.group_name;
        const ticket = auction.ticket;
        tempActive[id] = {
          info: { status: false }
        };
        const tempUser = {
          _id: id,
          userName,
          userPhone,
          groupName,
          ticket,
          enrollmentDate: auction.group_id?.createdAt
        };
        usersList.push(tempUser);
        return {
          slNo: index + 1,
          groupName,
          userPhone,
          userName,
          ticket
        };
      });
      setAuctionData(auctionData2);
      setUsersData(usersList);
      setTotalUsers(usersList.length);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, []);
  const Auctioncolumns = [
    { key: "sl_no", header: "SL. NO" },
    { key: "checkBoxs", header: "Select User" },
    { key: "userName", header: "Customer Name" },
    { key: "userPhone", header: "Phone Number" },
    // { key: "customerId", header: "Customer Id" },
    { key: "groupName", header: "Group Name" },
    { key: "ticket", header: "Ticket" }
    //  {key: "paymentsTicket", header: "Ticket"},
  ];
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler: (e) => setSearchText(e.target.value),
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
        lineNumber: 206,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
      lineNumber: 210,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
        lineNumber: 213,
        columnNumber: 16
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold text-center mt-2", children: "Auction Winner Douments List Message" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
        lineNumber: 214,
        columnNumber: 13
      }, this),
      contextHolder,
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-start border-b border-gray-300 mb-4" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
          lineNumber: 220,
          columnNumber: 15
        }, this),
        isLoading ? /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { color: "text-green-600" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
          lineNumber: 223,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
          lineNumber: 222,
          columnNumber: 13
        }, this) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-6 mt-8 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-violet-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Total Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                  lineNumber: 230,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-violet-700", children: filteredUsers.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                  lineNumber: 231,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                lineNumber: 229,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaUsers, { className: "text-violet-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                lineNumber: 235,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
              lineNumber: 228,
              columnNumber: 3
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 rounded-xl p-6 shadow flex items-center justify-between", children: [
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-600", children: "Selected Customers" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                  lineNumber: 240,
                  columnNumber: 7
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold text-green-700", children: visibleSelectedCount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                  lineNumber: 241,
                  columnNumber: 7
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                lineNumber: 239,
                columnNumber: 5
              }, this),
              /* @__PURE__ */ jsxDEV(FaCheckCircle, { className: "text-green-600 text-4xl" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                lineNumber: 245,
                columnNumber: 5
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
              lineNumber: 238,
              columnNumber: 3
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
            lineNumber: 227,
            columnNumber: 29
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center gap-4 mb-6", children: /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Select Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
              lineNumber: 250,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                style: { width: 200 },
                allowClear: true,
                placeholder: "--All groups--",
                onChange: (value) => setGroupFilter(value),
                value: groupFilter || void 0,
                className: "w-full max-w-xs h-11 ",
                children: groupOptions.map(
                  (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group, children: group }, group, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                    lineNumber: 262,
                    columnNumber: 21
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                lineNumber: 253,
                columnNumber: 21
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
            lineNumber: 249,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
            lineNumber: 248,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mb-4", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: sendWhatsapp,
              className: "relative bg-green-600 text-white px-4 py-2 rounded shadow-md hover:bg-green-700 transition duration-200 flex items-center",
              children: [
                visibleSelectedCount > 0 && /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "min-w-6 h-6 absolute -right-3 -top-2 shadow-lg hover:bg-red-600 bg-red-400 rounded-full text-white flex items-center justify-center text-xs",
                    title: `Message will be sent to total ${visibleSelectedCount} customers`,
                    children: /* @__PURE__ */ jsxDEV("span", { children: visibleSelectedCount }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                      lineNumber: 281,
                      columnNumber: 25
                    }, this)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                    lineNumber: 277,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "mr-2", size: 20 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
                  lineNumber: 284,
                  columnNumber: 21
                }, this),
                "WhatsApp"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
              lineNumber: 272,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
            lineNumber: 271,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: filteredUsers,
              columns: Auctioncolumns,
              catcher: "_id",
              exportedPdfName: "Auction Winner Documents List",
              printHeaderKeys: ["Group Name"],
              printHeaderValues: [groupFilter],
              exportedFileName: `Auction Winner Documents List.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
              lineNumber: 288,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
          lineNumber: 226,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
        lineNumber: 219,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
      lineNumber: 212,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
    lineNumber: 205,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx",
    lineNumber: 204,
    columnNumber: 5
  }, this);
};
_s(AuctionWinnerDocuments, "UpOOdTDCTciX84H4xF7wEjgI16M=", false, function() {
  return [notification.useNotification];
});
_c = AuctionWinnerDocuments;
export default AuctionWinnerDocuments;
var _c;
$RefreshReg$(_c, "AuctionWinnerDocuments");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionWinnerDocuments.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeURVOzJCQXpEVjtBQUFnQkEsTUFBV0MsY0FBVUMsT0FBTyxzQkFBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzRCxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msb0JBQW9CO0FBQzNCLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxjQUFjO0FBQ3ZCLE9BQU9DLGFBQWE7QUFDcEIsU0FBU0MsU0FBU0MscUJBQXFCO0FBQ3ZDLE9BQU9DLGdCQUFnQjtBQUd2QixNQUFNQyx5QkFBeUJBLE1BQU07QUFBQUMsS0FBQTtBQUNuQyxRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSWxCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNtQixXQUFXQyxZQUFZLElBQUlwQixTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDcUIsYUFBYUMsY0FBYyxJQUFJdEIsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ3VCLFVBQVVDLFdBQVcsSUFBSXhCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUN5QixRQUFRQyxTQUFTLElBQUkxQixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDMkIsZ0JBQWdCQyxpQkFBaUIsSUFBSTVCLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZELFFBQU0sQ0FBQzZCLFdBQVdDLFlBQVksSUFBSTlCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMrQixZQUFZQyxhQUFhLElBQUloQyxTQUFTLENBQUM7QUFDOUMsUUFBTSxDQUFDaUMsVUFBVUMsYUFBYSxJQUFJekIsYUFBYTBCLGdCQUFnQjtBQUMvRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXJDLFNBQVMsS0FBSztBQUM5QyxRQUFNLENBQUNzQyxhQUFZQyxjQUFjLElBQUl2QyxTQUFTLEVBQUU7QUFHcEQsUUFBTXdDLGVBQWU7QUFBQSxJQUNuQixHQUFHLElBQUlDO0FBQUFBLE1BQ0x0QixVQUNHdUIsT0FBTyxDQUFBQyxNQUFLQSxFQUFFQyxjQUFjQyxVQUFhRixFQUFFQyxjQUFjLE1BQU1ELEVBQUVDLGNBQWMsS0FBSyxFQUNwRkUsSUFBSSxDQUFBSCxNQUFLQSxFQUFFQyxTQUFTO0FBQUEsSUFDekI7QUFBQSxFQUFDO0FBRUQsUUFBTUcsZ0JBQWdCOUMsUUFBUSxNQUFNO0FBQ2xDLFVBQU0rQyxXQUFXekM7QUFBQUEsTUFDZlksVUFBVXVCLE9BQU8sQ0FBQ0MsTUFBTTtBQUN0QixjQUFNTSxhQUFhNUIsY0FBY3NCLEVBQUVDLGNBQWN2QixjQUFjO0FBQy9ELGNBQU02QixpQkFBaUIsSUFBSUMsS0FBS1IsRUFBRU8sY0FBYztBQUNoRCxjQUFNRSxnQkFBZ0I3QixXQUNsQjJCLGtCQUFrQixJQUFJQyxLQUFLNUIsUUFBUSxJQUNuQztBQUNKLGNBQU04QixjQUFjNUIsU0FBU3lCLGtCQUFrQixJQUFJQyxLQUFLMUIsTUFBTSxJQUFJO0FBQ2xFLGVBQU93QixjQUFjRyxpQkFBaUJDO0FBQUFBLE1BQ3hDLENBQUM7QUFBQSxNQUNEcEM7QUFBQUEsSUFDRjtBQUVBLFdBQU8rQixTQUFTRixJQUFJLENBQUNRLE1BQU1DLFVBQVU7QUFDbkMsWUFBTUMsYUFBYSxDQUFDLENBQUM3QixlQUFlMkIsS0FBS0csR0FBRyxHQUFHQyxNQUFNQztBQUVyRCxhQUFPO0FBQUEsUUFDTCxHQUFHTDtBQUFBQSxRQUNITSxPQUFPTCxRQUFRO0FBQUEsUUFDZk0sV0FDRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsU0FBU0w7QUFBQUEsWUFDVCxVQUFVLENBQUNNLE1BQU07QUFDZmxDLGdDQUFrQixDQUFDbUMsVUFBVTtBQUFBLGdCQUMzQixHQUFHQTtBQUFBQSxnQkFDSCxDQUFDVCxLQUFLRyxHQUFHLEdBQUc7QUFBQSxrQkFDVkMsTUFBTTtBQUFBLG9CQUNKQyxRQUFRRyxFQUFFRSxPQUFPQztBQUFBQSxvQkFDakJDLFdBQVdaLEtBQUtZO0FBQUFBLG9CQUNoQnRCLFdBQVdVLEtBQUtWO0FBQUFBLG9CQUNoQnVCLFVBQVViLEtBQUthO0FBQUFBLG9CQUNmQyxRQUFRZCxLQUFLYztBQUFBQTtBQUFBQTtBQUFBQSxrQkFHZjtBQUFBLGdCQUNGO0FBQUEsY0FDRixFQUFFO0FBQUEsWUFDSjtBQUFBO0FBQUEsVUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBa0JJO0FBQUEsUUFHTlo7QUFBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsR0FBRyxDQUFDckMsV0FBV0UsYUFBYUUsVUFBVUUsUUFBUVIsWUFBWVUsY0FBYyxDQUFDO0FBRXpFLFFBQU0wQyx1QkFBdUJwRSxRQUFRLE1BQU07QUFDekMsV0FBTzhDLGNBQWNMLE9BQU8sQ0FBQ1ksU0FBU0EsS0FBS0UsVUFBVSxFQUFFYztBQUFBQSxFQUN6RCxHQUFHLENBQUN2QixhQUFhLENBQUM7QUFFbEIsUUFBTXdCLGVBQWUsWUFBWTtBQUMvQixVQUFNQyxNQUFNO0FBQ1osUUFBSTtBQUNGdkMsZUFBU3dDLEtBQUs7QUFBQSxRQUNaRDtBQUFBQSxRQUNBRSxTQUFTO0FBQUEsUUFDVEMsYUFBYTtBQUFBLFFBQ2JDLFdBQVc7QUFBQSxRQUNYQyxVQUFVO0FBQUEsTUFDWixDQUFDO0FBRUQsWUFBTUMscUJBQXFCLENBQUM7QUFDNUIvQixvQkFBY2dDLFFBQVEsQ0FBQ3pCLFNBQVM7QUFDOUIsWUFBSUEsS0FBS0UsY0FBYzdCLGVBQWUyQixLQUFLRyxHQUFHLEdBQUc7QUFDL0NxQiw2QkFBbUJ4QixLQUFLRyxHQUFHLElBQUk5QixlQUFlMkIsS0FBS0csR0FBRztBQUFBLFFBQ3hEO0FBQUEsTUFDRixDQUFDO0FBRUQsWUFBTXZELElBQUk4RSxLQUFLLDBDQUEwQztBQUFBLFFBQzdEQyxXQUFXSDtBQUFBQSxNQUViLENBQUM7QUFFSyxZQUFNSSxvQkFBb0IsRUFBRSxHQUFHdkQsZUFBZTtBQUM5Q29CLG9CQUFjZ0MsUUFBUSxDQUFDekIsU0FBUztBQUM5QixZQUFJQSxLQUFLRSxZQUFZO0FBQ25CLGlCQUFPMEIsa0JBQWtCNUIsS0FBS0csR0FBRztBQUFBLFFBQ25DO0FBQUEsTUFDRixDQUFDO0FBQ0Q3Qix3QkFBa0JzRCxpQkFBaUI7QUFFbkNqRCxlQUFTd0MsS0FBSztBQUFBLFFBQ1pEO0FBQUFBLFFBQ0FFLFNBQVM7QUFBQSxRQUNUQyxhQUFhO0FBQUEsUUFDYkMsV0FBVztBQUFBLFFBQ1hDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNILFNBQVNNLEtBQUs7QUFDWmxELGVBQVN3QyxLQUFLO0FBQUEsUUFDWkQ7QUFBQUEsUUFDQUUsU0FBUztBQUFBLFFBQ1RDLGFBQWFRLElBQUlULFdBQVc7QUFBQSxRQUM1QkUsV0FBVztBQUFBLFFBQ1hDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUNBOUUsWUFBVSxNQUFNO0FBRWQsVUFBTXFGLGFBQ0pyQyxjQUFjdUIsU0FBUyxLQUN2QnZCLGNBQWNzQyxNQUFNLENBQUMvQixTQUFTM0IsZUFBZTJCLEtBQUtHLEdBQUcsR0FBR0MsTUFBTUMsTUFBTTtBQUN0RXRCLGlCQUFhK0MsVUFBVTtBQUFBLEVBQ3pCLEdBQUcsQ0FBQ3JDLGVBQWVwQixjQUFjLENBQUM7QUFDbEMsUUFBTTJELFlBQVksWUFBWTtBQUM1QixRQUFJO0FBQ0Z4RCxtQkFBYSxJQUFJO0FBQ2pCLFlBQU15RCxpQkFBaUIsTUFBTXJGLElBQUlzRixJQUFJLHNCQUFzQjtBQUMzRCxZQUFNQyxZQUFZO0FBQ2xCLFlBQU1DLGFBQWEsQ0FBQztBQUVwQixZQUFNcEQsZUFBY2lELGVBQWVJLE1BQU1DLFFBQVE5QyxJQUFJLENBQUM4QyxTQUFTckMsVUFBVTtBQUN2RSxjQUFNc0MsS0FBS0QsUUFBUW5DO0FBQ25CLGNBQU1VLFdBQVd5QixRQUFRRSxTQUFTQztBQUNsQyxjQUFNN0IsWUFBWTBCLFFBQVFFLFNBQVNFO0FBQ25DLGNBQU1wRCxZQUFZZ0QsUUFBUUssVUFBVUM7QUFDcEMsY0FBTTlCLFNBQVN3QixRQUFReEI7QUFFdkJzQixtQkFBV0csRUFBRSxJQUFJO0FBQUEsVUFDYm5DLE1BQU0sRUFBRUMsUUFBUSxNQUFNO0FBQUEsUUFDMUI7QUFDQSxjQUFNd0MsV0FBVztBQUFBLFVBQ2IxQyxLQUFLb0M7QUFBQUEsVUFDTDFCO0FBQUFBLFVBQ0FEO0FBQUFBLFVBQ0F0QjtBQUFBQSxVQUNBd0I7QUFBQUEsVUFDQWxCLGdCQUFnQjBDLFFBQVFLLFVBQVVHO0FBQUFBLFFBQ3RDO0FBQ0FYLGtCQUFVWSxLQUFLRixRQUFRO0FBRXZCLGVBQU87QUFBQSxVQUNIRyxNQUFNL0MsUUFBUTtBQUFBLFVBQ2RYO0FBQUFBLFVBQ0FzQjtBQUFBQSxVQUNBQztBQUFBQSxVQUNBQztBQUFBQSxRQUNKO0FBQUEsTUFDRixDQUFDO0FBQ0Q3QixxQkFBZUQsWUFBVztBQUMxQmxCLG1CQUFhcUUsU0FBUztBQUN0QnpELG9CQUFjeUQsVUFBVW5CLE1BQU07QUFBQSxJQUNoQyxTQUFTaUMsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHdCQUF3QkEsS0FBSztBQUFBLElBQzdDLFVBQUM7QUFDQ3pFLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQS9CLFlBQVUsTUFBTTtBQUNkdUYsY0FBVTtBQUFBLEVBQ1osR0FBRyxFQUFFO0FBRUwsUUFBTW1CLGlCQUFpQjtBQUFBLElBQ3JCLEVBQUVqQyxLQUFLLFNBQVNrQyxRQUFRLFNBQVM7QUFBQSxJQUNqQyxFQUFFbEMsS0FBSyxhQUFha0MsUUFBUSxjQUFjO0FBQUEsSUFDMUMsRUFBRWxDLEtBQUssWUFBWWtDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDM0MsRUFBRWxDLEtBQUssYUFBYWtDLFFBQVEsZUFBZTtBQUFBO0FBQUEsSUFFM0MsRUFBRWxDLEtBQUssYUFBYWtDLFFBQVEsYUFBYTtBQUFBLElBQ3pDLEVBQUNsQyxLQUFLLFVBQVVrQyxRQUFRLFNBQVE7QUFBQTtBQUFBLEVBQ2xDO0FBR0EsU0FDRSx1QkFBQyxTQUFJLFdBQVUsVUFDYixpQ0FBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyw2QkFBNkIsQ0FBQzVDLE1BQU01QyxjQUFjNEMsRUFBRUUsT0FBTzJDLEtBQUs7QUFBQSxRQUNoRSxZQUFZO0FBQUE7QUFBQSxNQUZkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUVtQjtBQUFBLElBRW5CLHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFRO0FBQUEsSUFFTix1QkFBQyxTQUFJLFdBQVUsaUJBQ1Y7QUFBQSw2QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVc7QUFBQSxNQUNkLHVCQUFDLFFBQUcsV0FBVSx1Q0FBc0Msb0RBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUN6RTtBQUFBQSxNQUNELHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLHNEQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0U7QUFBQSxRQUNqRUwsWUFDTCx1QkFBQyxTQUFJLFdBQVUsVUFDYixpQ0FBQyxrQkFBZSxPQUFNLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNDLEtBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxJQUVJLHVCQUFDLFNBQUksV0FBVSxTQUNEO0FBQUEsaUNBQUMsU0FBSSxXQUFVLG1EQUN6QztBQUFBLG1DQUFDLFNBQUksV0FBVSx5RUFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUseUJBQXdCLCtCQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNwRCx1QkFBQyxPQUFFLFdBQVUsc0NBQ1ZrQix3QkFBY3VCLFVBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxXQUFRLFdBQVUsOEJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTZDO0FBQUEsaUJBUC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUUE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSx3RUFDYjtBQUFBLHFDQUFDLFNBQ0M7QUFBQSx1Q0FBQyxPQUFFLFdBQVUseUJBQXdCLGtDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF1RDtBQUFBLGdCQUN2RCx1QkFBQyxPQUFFLFdBQVUscUNBQ1ZELGtDQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FDQSx1QkFBQyxpQkFBYyxXQUFVLDZCQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFrRDtBQUFBLGlCQVBwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUFuQjBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0I1QjtBQUFBLFVBQ2dCLHVCQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFPLEVBQUV1QyxPQUFPLElBQUk7QUFBQSxnQkFDcEI7QUFBQSxnQkFDQSxhQUFZO0FBQUEsZ0JBQ1osVUFBVSxDQUFDRCxVQUFVckYsZUFBZXFGLEtBQUs7QUFBQSxnQkFDekMsT0FBT3RGLGVBQWV3QjtBQUFBQSxnQkFDdEIsV0FBVTtBQUFBLGdCQUVUTCx1QkFBYU07QUFBQUEsa0JBQUksQ0FBQytELFVBQ2pCLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxPQUMvQkEsbUJBRGlCQSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBWkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBYUE7QUFBQSxlQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXNCQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTdEM7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVEY7QUFBQUEsdUNBQXVCLEtBQ3RCO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixPQUFPLGlDQUFpQ0Esb0JBQW9CO0FBQUEsb0JBRTVELGlDQUFDLFVBQU1BLGtDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTRCO0FBQUE7QUFBQSxrQkFKOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUtBO0FBQUEsZ0JBRUYsdUJBQUMsY0FBVyxXQUFVLFFBQU8sTUFBTSxNQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFzQztBQUFBLGdCQUFHO0FBQUE7QUFBQTtBQUFBLFlBWjNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFNdEI7QUFBQUEsY0FDTixTQUFTMEQ7QUFBQUEsY0FDVCxTQUFRO0FBQUEsY0FDUixpQkFBZ0I7QUFBQSxjQUNoQixpQkFBaUIsQ0FBQyxZQUFZO0FBQUEsY0FDOUIsbUJBQW1CLENBQUNwRixXQUFXO0FBQUEsY0FDL0Isa0JBQWtCO0FBQUE7QUFBQSxZQVBwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPd0Q7QUFBQSxhQXJFMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXVFQTtBQUFBLFdBOUVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnRkE7QUFBQSxTQXZGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBd0ZBO0FBQUEsT0EvRko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlHQSxLQWxHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUdBO0FBRUo7QUFBRUwsR0FqU0lELHdCQUFzQjtBQUFBLFVBU1FOLGFBQWEwQixlQUFlO0FBQUE7QUFBQTJFLEtBVDFEL0Y7QUFtU04sZUFBZUE7QUFBdUIsSUFBQStGO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZU1lbW8iLCJhcGkiLCJEYXRhVGFibGUiLCJDaXJjdWxhckxvYWRlciIsIlNlbGVjdCIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIkZhV2hhdHNhcHAiLCJub3RpZmljYXRpb24iLCJUaWNrZXQiLCJTaWRlYmFyIiwiRmFVc2VycyIsIkZhQ2hlY2tDaXJjbGUiLCJCcmVhZGNydW1iIiwiQXVjdGlvbldpbm5lckRvY3VtZW50cyIsIl9zIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJ1c2Vyc0RhdGEiLCJzZXRVc2Vyc0RhdGEiLCJncm91cEZpbHRlciIsInNldEdyb3VwRmlsdGVyIiwiZnJvbURhdGUiLCJzZXRGcm9tRGF0ZSIsInRvRGF0ZSIsInNldFRvRGF0ZSIsImFjdGl2ZVVzZXJEYXRhIiwic2V0QWN0aXZlVXNlckRhdGEiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJ0b3RhbFVzZXJzIiwic2V0VG90YWxVc2VycyIsIm5vdGlmaWVyIiwiY29udGV4dEhvbGRlciIsInVzZU5vdGlmaWNhdGlvbiIsInNlbGVjdEFsbCIsInNldFNlbGVjdEFsbCIsImF1Y3Rpb25EYXRhIiwic2V0QXVjdGlvbkRhdGEiLCJncm91cE9wdGlvbnMiLCJTZXQiLCJmaWx0ZXIiLCJ1IiwiZ3JvdXBOYW1lIiwidW5kZWZpbmVkIiwibWFwIiwiZmlsdGVyZWRVc2VycyIsImZpbHRlcmVkIiwibWF0Y2hHcm91cCIsImVucm9sbG1lbnREYXRlIiwiRGF0ZSIsIm1hdGNoRnJvbURhdGUiLCJtYXRjaFRvRGF0ZSIsInVzZXIiLCJpbmRleCIsImlzU2VsZWN0ZWQiLCJfaWQiLCJpbmZvIiwic3RhdHVzIiwic2xfbm8iLCJjaGVja0JveHMiLCJlIiwicHJldiIsInRhcmdldCIsImNoZWNrZWQiLCJ1c2VyUGhvbmUiLCJ1c2VyTmFtZSIsInRpY2tldCIsInZpc2libGVTZWxlY3RlZENvdW50IiwibGVuZ3RoIiwic2VuZFdoYXRzYXBwIiwia2V5Iiwib3BlbiIsIm1lc3NhZ2UiLCJkZXNjcmlwdGlvbiIsImNsYXNzTmFtZSIsImR1cmF0aW9uIiwidmlzaWJsZUFjdGl2ZVVzZXJzIiwiZm9yRWFjaCIsInBvc3QiLCJyZWNlaXZlcnMiLCJuZXdBY3RpdmVVc2VyRGF0YSIsImVyciIsImFsbENoZWNrZWQiLCJldmVyeSIsImZldGNoRGF0YSIsInJlcG9ydFJlc3BvbnNlIiwiZ2V0IiwidXNlcnNMaXN0IiwidGVtcEFjdGl2ZSIsImRhdGEiLCJhdWN0aW9uIiwiaWQiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXBfaWQiLCJncm91cF9uYW1lIiwidGVtcFVzZXIiLCJjcmVhdGVkQXQiLCJwdXNoIiwic2xObyIsImVycm9yIiwiY29uc29sZSIsIkF1Y3Rpb25jb2x1bW5zIiwiaGVhZGVyIiwidmFsdWUiLCJ3aWR0aCIsImdyb3VwIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQXVjdGlvbldpbm5lckRvY3VtZW50cy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgRGF0YVRhYmxlIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvRGF0YXRhYmxlXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IHsgRmFXaGF0c2FwcCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xyXG5pbXBvcnQgeyBub3RpZmljYXRpb24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgeyBUaWNrZXQgfSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgeyBGYVVzZXJzLCBGYUNoZWNrQ2lyY2xlIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcblxyXG5jb25zdCBBdWN0aW9uV2lubmVyRG9jdW1lbnRzID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt1c2Vyc0RhdGEsIHNldFVzZXJzRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2dyb3VwRmlsdGVyLCBzZXRHcm91cEZpbHRlcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZnJvbURhdGUsIHNldEZyb21EYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFt0b0RhdGUsIHNldFRvRGF0ZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbYWN0aXZlVXNlckRhdGEsIHNldEFjdGl2ZVVzZXJEYXRhXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFt0b3RhbFVzZXJzLCBzZXRUb3RhbFVzZXJzXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFtub3RpZmllciwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcbiAgY29uc3QgW3NlbGVjdEFsbCwgc2V0U2VsZWN0QWxsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICAgIGNvbnN0IFthdWN0aW9uRGF0YSxzZXRBdWN0aW9uRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gLy8gY29uc3QgZ3JvdXBPcHRpb25zID0gWy4uLm5ldyBTZXQodXNlcnNEYXRhLm1hcCgodSkgPT4gdS5ncm91cE5hbWUpKV07XHJcbmNvbnN0IGdyb3VwT3B0aW9ucyA9IFtcclxuICAuLi5uZXcgU2V0KFxyXG4gICAgdXNlcnNEYXRhXHJcbiAgICAgIC5maWx0ZXIodSA9PiB1Lmdyb3VwTmFtZSAhPT0gdW5kZWZpbmVkICYmIHUuZ3JvdXBOYW1lICE9PSBcIlwiICYmIHUuZ3JvdXBOYW1lICE9PSBcIiAgIFwiKSAvLyBGaWx0ZXIgb3V0IHVuZGVmaW5lZCwgZW1wdHksIGFuZCB3aGl0ZXNwYWNlLW9ubHkgdmFsdWVzXHJcbiAgICAgIC5tYXAodSA9PiB1Lmdyb3VwTmFtZSlcclxuICApXHJcbl07XHJcbiAgY29uc3QgZmlsdGVyZWRVc2VycyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4gICAgY29uc3QgZmlsdGVyZWQgPSBmaWx0ZXJPcHRpb24oXHJcbiAgICAgIHVzZXJzRGF0YS5maWx0ZXIoKHUpID0+IHtcclxuICAgICAgICBjb25zdCBtYXRjaEdyb3VwID0gZ3JvdXBGaWx0ZXIgPyB1Lmdyb3VwTmFtZSA9PT0gZ3JvdXBGaWx0ZXIgOiB0cnVlO1xyXG4gICAgICAgIGNvbnN0IGVucm9sbG1lbnREYXRlID0gbmV3IERhdGUodS5lbnJvbGxtZW50RGF0ZSk7XHJcbiAgICAgICAgY29uc3QgbWF0Y2hGcm9tRGF0ZSA9IGZyb21EYXRlXHJcbiAgICAgICAgICA/IGVucm9sbG1lbnREYXRlID49IG5ldyBEYXRlKGZyb21EYXRlKVxyXG4gICAgICAgICAgOiB0cnVlO1xyXG4gICAgICAgIGNvbnN0IG1hdGNoVG9EYXRlID0gdG9EYXRlID8gZW5yb2xsbWVudERhdGUgPD0gbmV3IERhdGUodG9EYXRlKSA6IHRydWU7XHJcbiAgICAgICAgcmV0dXJuIG1hdGNoR3JvdXAgJiYgbWF0Y2hGcm9tRGF0ZSAmJiBtYXRjaFRvRGF0ZTtcclxuICAgICAgfSksXHJcbiAgICAgIHNlYXJjaFRleHRcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGZpbHRlcmVkLm1hcCgodXNlciwgaW5kZXgpID0+IHtcclxuICAgICAgY29uc3QgaXNTZWxlY3RlZCA9ICEhYWN0aXZlVXNlckRhdGFbdXNlci5faWRdPy5pbmZvPy5zdGF0dXM7XHJcblxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnVzZXIsXHJcbiAgICAgICAgc2xfbm86IGluZGV4ICsgMSxcclxuICAgICAgICBjaGVja0JveHM6IChcclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxyXG4gICAgICAgICAgICBjaGVja2VkPXtpc1NlbGVjdGVkfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICBzZXRBY3RpdmVVc2VyRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICBbdXNlci5faWRdOiB7XHJcbiAgICAgICAgICAgICAgICAgIGluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlclBob25lOiB1c2VyLnVzZXJQaG9uZSxcclxuICAgICAgICAgICAgICAgICAgICBncm91cE5hbWU6IHVzZXIuZ3JvdXBOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lOiB1c2VyLnVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHRpY2tldDogdXNlci50aWNrZXQsXHJcbiAgICAgICAgICAgICAgICAgICAgLy8gZ3JvdXBJZDogdXNlci5ncm91cElkLFxyXG4gICAgICAgICAgICAgICAgICAgIC8vIHVzZXJJZDogdXNlci51c2VySWQsXHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKSxcclxuICAgICAgICBpc1NlbGVjdGVkLFxyXG4gICAgICB9O1xyXG4gICAgfSk7XHJcbiAgfSwgW3VzZXJzRGF0YSwgZ3JvdXBGaWx0ZXIsIGZyb21EYXRlLCB0b0RhdGUsIHNlYXJjaFRleHQsIGFjdGl2ZVVzZXJEYXRhXSk7XHJcblxyXG4gIGNvbnN0IHZpc2libGVTZWxlY3RlZENvdW50ID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICByZXR1cm4gZmlsdGVyZWRVc2Vycy5maWx0ZXIoKHVzZXIpID0+IHVzZXIuaXNTZWxlY3RlZCkubGVuZ3RoO1xyXG4gIH0sIFtmaWx0ZXJlZFVzZXJzXSk7XHJcblxyXG4gIGNvbnN0IHNlbmRXaGF0c2FwcCA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IGtleSA9IFwidXBkYXRhYmxlXCI7XHJcbiAgICB0cnkge1xyXG4gICAgICBub3RpZmllci5vcGVuKHtcclxuICAgICAgICBrZXksXHJcbiAgICAgICAgbWVzc2FnZTogXCJTZW5kaW5nIE1lc3NhZ2VzIFZpYSBXaGF0c2FwcC4uXCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IFwiUHJvY2Vzc2luZy4uLlwiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1ncmVlbi0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgICBkdXJhdGlvbjogMixcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCB2aXNpYmxlQWN0aXZlVXNlcnMgPSB7fTtcclxuICAgICAgZmlsdGVyZWRVc2Vycy5mb3JFYWNoKCh1c2VyKSA9PiB7XHJcbiAgICAgICAgaWYgKHVzZXIuaXNTZWxlY3RlZCAmJiBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF0pIHtcclxuICAgICAgICAgIHZpc2libGVBY3RpdmVVc2Vyc1t1c2VyLl9pZF0gPSBhY3RpdmVVc2VyRGF0YVt1c2VyLl9pZF07XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGF3YWl0IGFwaS5wb3N0KFwiL3doYXRzYXBwL2F1Y3Rpb24td2lubmVyLWRvY3VtZW50LWxpc3RcIiwge1xyXG4gIHJlY2VpdmVyczogdmlzaWJsZUFjdGl2ZVVzZXJzLFxyXG4gIFxyXG59KTtcclxuXHJcbiAgICAgIGNvbnN0IG5ld0FjdGl2ZVVzZXJEYXRhID0geyAuLi5hY3RpdmVVc2VyRGF0YSB9O1xyXG4gICAgICBmaWx0ZXJlZFVzZXJzLmZvckVhY2goKHVzZXIpID0+IHtcclxuICAgICAgICBpZiAodXNlci5pc1NlbGVjdGVkKSB7XHJcbiAgICAgICAgICBkZWxldGUgbmV3QWN0aXZlVXNlckRhdGFbdXNlci5faWRdO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICAgIHNldEFjdGl2ZVVzZXJEYXRhKG5ld0FjdGl2ZVVzZXJEYXRhKTtcclxuXHJcbiAgICAgIG5vdGlmaWVyLm9wZW4oe1xyXG4gICAgICAgIGtleSxcclxuICAgICAgICBtZXNzYWdlOiBcIldoYXRzYXBwIE1lc3NhZ2VzIEhhcyBCZWVuIFNlbnQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IFwiU3VjY2Vzc1wiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1ncmVlbi0zMDAgcm91bmRlZC1sZyBmb250LWJvbGRcIixcclxuICAgICAgICBkdXJhdGlvbjogMixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgbm90aWZpZXIub3Blbih7XHJcbiAgICAgICAga2V5LFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIFNlbmQgV2hhdHNhcHBcIixcclxuICAgICAgICBkZXNjcmlwdGlvbjogZXJyLm1lc3NhZ2UgfHwgXCJTb21ldGhpbmcgd2VudCB3cm9uZ1wiLFxyXG4gICAgICAgIGNsYXNzTmFtZTogXCJiZy1yZWQtMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkXCIsXHJcbiAgICAgICAgZHVyYXRpb246IDIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIC8vIEF1dG9tYXRpY2FsbHkgdXBkYXRlIHNlbGVjdEFsbCBiYXNlZCBvbiBmaWx0ZXJlZFVzZXJzXHJcbiAgICBjb25zdCBhbGxDaGVja2VkID1cclxuICAgICAgZmlsdGVyZWRVc2Vycy5sZW5ndGggPiAwICYmXHJcbiAgICAgIGZpbHRlcmVkVXNlcnMuZXZlcnkoKHVzZXIpID0+IGFjdGl2ZVVzZXJEYXRhW3VzZXIuX2lkXT8uaW5mbz8uc3RhdHVzKTtcclxuICAgIHNldFNlbGVjdEFsbChhbGxDaGVja2VkKTtcclxuICB9LCBbZmlsdGVyZWRVc2VycywgYWN0aXZlVXNlckRhdGFdKTtcclxuICBjb25zdCBmZXRjaERhdGEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHJlcG9ydFJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9hdWN0aW9uL2dldC1hdWN0aW9uXCIpO1xyXG4gICAgICBjb25zdCB1c2Vyc0xpc3QgPSBbXTtcclxuICAgICAgY29uc3QgdGVtcEFjdGl2ZSA9IHt9O1xyXG5cclxuICAgICAgY29uc3QgYXVjdGlvbkRhdGEgPSByZXBvcnRSZXNwb25zZS5kYXRhPy5hdWN0aW9uLm1hcCgoYXVjdGlvbiwgaW5kZXgpID0+IHtcclxuICAgICAgICBjb25zdCBpZCA9IGF1Y3Rpb24uX2lkO1xyXG4gICAgICAgIGNvbnN0IHVzZXJOYW1lID0gYXVjdGlvbi51c2VyX2lkPy5mdWxsX25hbWU7XHJcbiAgICAgICAgY29uc3QgdXNlclBob25lID0gYXVjdGlvbi51c2VyX2lkPy5waG9uZV9udW1iZXI7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBOYW1lID0gYXVjdGlvbi5ncm91cF9pZD8uZ3JvdXBfbmFtZTtcclxuICAgICAgICBjb25zdCB0aWNrZXQgPSBhdWN0aW9uLnRpY2tldDtcclxuXHJcbiAgICAgICAgdGVtcEFjdGl2ZVtpZF0gPSB7XHJcbiAgICAgICAgICAgIGluZm86IHsgc3RhdHVzOiBmYWxzZSx9LFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgY29uc3QgdGVtcFVzZXIgPSB7XHJcbiAgICAgICAgICAgIF9pZDogaWQsXHJcbiAgICAgICAgICAgIHVzZXJOYW1lLFxyXG4gICAgICAgICAgICB1c2VyUGhvbmUsXHJcbiAgICAgICAgICAgIGdyb3VwTmFtZSxcclxuICAgICAgICAgICAgdGlja2V0LFxyXG4gICAgICAgICAgICBlbnJvbGxtZW50RGF0ZTogYXVjdGlvbi5ncm91cF9pZD8uY3JlYXRlZEF0LFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgdXNlcnNMaXN0LnB1c2godGVtcFVzZXIpO1xyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBzbE5vOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgIGdyb3VwTmFtZSxcclxuICAgICAgICAgICAgdXNlclBob25lLFxyXG4gICAgICAgICAgICB1c2VyTmFtZSxcclxuICAgICAgICAgICAgdGlja2V0LFxyXG4gICAgICAgIH1cclxuICAgICAgfSkgXHJcbiAgICAgIHNldEF1Y3Rpb25EYXRhKGF1Y3Rpb25EYXRhKTtcclxuICAgICAgc2V0VXNlcnNEYXRhKHVzZXJzTGlzdCk7XHJcbiAgICAgIHNldFRvdGFsVXNlcnModXNlcnNMaXN0Lmxlbmd0aCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hEYXRhKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBBdWN0aW9uY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcInNsX25vXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY2hlY2tCb3hzXCIsIGhlYWRlcjogXCJTZWxlY3QgVXNlclwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyTmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJ1c2VyUGhvbmVcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgIC8vIHsga2V5OiBcImN1c3RvbWVySWRcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIElkXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwTmFtZVwiLCBoZWFkZXI6IFwiR3JvdXAgTmFtZVwiIH0sXHJcbiAgICB7a2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCJ9LFxyXG4gIC8vICB7a2V5OiBcInBheW1lbnRzVGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIn0sXHJcbiAgXTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yMFwiPlxyXG4gICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17KGUpID0+IHNldFNlYXJjaFRleHQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTaWRlYmFyLz5cclxuICAgICAgICBcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtY2VudGVyIG10LTJcIj5cclxuICAgICAgICAgICAgICBBdWN0aW9uIFdpbm5lciBEb3VtZW50cyBMaXN0IE1lc3NhZ2VcclxuICAgICAgICAgICAgPC9oMT5cclxuXHJcbiAgICAgICAgICAgIHtjb250ZXh0SG9sZGVyfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LXN0YXJ0IGJvcmRlci1iIGJvcmRlci1ncmF5LTMwMCBtYi00XCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBjb2xvcj1cInRleHQtZ3JlZW4tNjAwXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC02IG10LTggbWItNlwiPlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwiYmctdmlvbGV0LTEwMCByb3VuZGVkLXhsIHAtNiBzaGFkb3cgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICA8ZGl2PlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS02MDBcIj5Ub3RhbCBDdXN0b21lcnM8L3A+XHJcbiAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtM3hsIGZvbnQtYm9sZCB0ZXh0LXZpb2xldC03MDBcIj5cclxuICAgICAgICB7ZmlsdGVyZWRVc2Vycy5sZW5ndGh9XHJcbiAgICAgIDwvcD5cclxuICAgIDwvZGl2PlxyXG4gICAgPEZhVXNlcnMgY2xhc3NOYW1lPVwidGV4dC12aW9sZXQtNjAwIHRleHQtNHhsXCIgLz5cclxuICA8L2Rpdj5cclxuXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi0xMDAgcm91bmRlZC14bCBwLTYgc2hhZG93IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgPGRpdj5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNjAwXCI+U2VsZWN0ZWQgQ3VzdG9tZXJzPC9wPlxyXG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1ncmVlbi03MDBcIj5cclxuICAgICAgICB7dmlzaWJsZVNlbGVjdGVkQ291bnR9XHJcbiAgICAgIDwvcD5cclxuICAgIDwvZGl2PlxyXG4gICAgPEZhQ2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDAgdGV4dC00eGxcIiAvPlxyXG4gIDwvZGl2PlxyXG48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBHcm91cFxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDIwMCB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCItLUFsbCBncm91cHMtLVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRHcm91cEZpbHRlcih2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Z3JvdXBGaWx0ZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LXhzIGgtMTEgXCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBPcHRpb25zLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cH0gdmFsdWU9e2dyb3VwfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17c2VuZFdoYXRzYXBwfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIGJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ncmVlbi03MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3Zpc2libGVTZWxlY3RlZENvdW50ID4gMCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1pbi13LTYgaC02IGFic29sdXRlIC1yaWdodC0zIC10b3AtMiBzaGFkb3ctbGcgaG92ZXI6YmctcmVkLTYwMCBiZy1yZWQtNDAwIHJvdW5kZWQtZnVsbCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQteHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17YE1lc3NhZ2Ugd2lsbCBiZSBzZW50IHRvIHRvdGFsICR7dmlzaWJsZVNlbGVjdGVkQ291bnR9IGN1c3RvbWVyc2B9XHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPnt2aXNpYmxlU2VsZWN0ZWRDb3VudH08L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cIm1yLTJcIiBzaXplPXsyMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICBXaGF0c0FwcFxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICBkYXRhPXtmaWx0ZXJlZFVzZXJzfVxyXG4gICAgICAgICAgICAgICAgICBjb2x1bW5zPXtBdWN0aW9uY29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgY2F0Y2hlcj1cIl9pZFwiXHJcbiAgICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkF1Y3Rpb24gV2lubmVyIERvY3VtZW50cyBMaXN0XCJcclxuICAgICAgICAgICAgICAgICAgcHJpbnRIZWFkZXJLZXlzPXtbXCJHcm91cCBOYW1lXCJdfVxyXG4gICAgICAgICAgICAgICAgICBwcmludEhlYWRlclZhbHVlcz17W2dyb3VwRmlsdGVyXX1cclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEF1Y3Rpb24gV2lubmVyIERvY3VtZW50cyBMaXN0LmNzdmB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgXHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEF1Y3Rpb25XaW5uZXJEb2N1bWVudHM7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9BdWN0aW9uV2lubmVyRG9jdW1lbnRzLmpzeCJ9