import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/GSTServiceChargeReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import {
  Card,
  Row,
  Col,
  Select,
  DatePicker,
  Button,
  Statistic,
  message
} from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import __vite__cjsImport5_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport5_dayjs.__esModule ? __vite__cjsImport5_dayjs.default : __vite__cjsImport5_dayjs;
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
const { RangePicker } = DatePicker;
const { Option } = Select;
const GSTServiceChargeReport = () => {
  _s();
  const [loading, setLoading] = useState(false);
  const [customers, setCustomers] = useState([]);
  const [groups, setGroups] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [summary, setSummary] = useState({
    total_service_charge: 0,
    total_gst: 0
  });
  const [filters, setFilters] = useState({
    fromDate: null,
    toDate: null,
    userId: void 0,
    groupId: void 0,
    type: void 0
  });
  const [searchText, setSearchText] = useState("");
  useEffect(() => {
    fetchCustomers();
    fetchGroups();
    fetchReport();
  }, []);
  const fetchCustomers = async () => {
    try {
      const res = await api.get("/user/get-user");
      setCustomers(res.data || []);
    } catch (err) {
      console.log(err);
    }
  };
  const fetchGroups = async () => {
    try {
      const res = await api.get("/group/get-group-admin");
      setGroups(res.data || []);
    } catch (err) {
      console.log(err);
    }
  };
  const fetchReport = async () => {
    try {
      setLoading(true);
      const params = {};
      if (filters.fromDate) {
        params.fromDate = dayjs(filters.fromDate).format("YYYY-MM-DD");
      }
      if (filters.toDate) {
        params.toDate = dayjs(filters.toDate).format("YYYY-MM-DD");
      }
      if (filters.userId) {
        params.userId = filters.userId;
      }
      if (filters.groupId) {
        params.groupId = filters.groupId;
      }
      if (filters.type) {
        params.type = filters.type;
      }
      const response = await api.get("/v1/admin/transaction-history/gst", {
        params
      });
      if (response.data.data?.length > 0) {
        const result = response.data.data[0];
        setSummary({
          total_service_charge: result.total_service_charge || 0,
          total_gst: result.total_gst || 0
        });
        const formattedData = result.transactions.filter((e) => e.reason !== "Pigmy Withdrawal").map((item, index) => ({
          _id: item._id,
          id: index + 1,
          transaction_id: item.transaction_id,
          customer_name: item?.enroll?.customer_name || "N/A",
          phone_number: item?.enroll?.phone_number || "N/A",
          group_name: item?.enroll?.group_name || "N/A",
          transaction_type: item.transaction_type || "-",
          reason: item.reason || "-",
          interest_amount: item.interest_amount || 0,
          service_charge: item.service_charge || 0,
          gst_amount: item.gst_amount || 0,
          remarks: item.remarks || "-",
          transaction_date: item.transaction_date ? dayjs(item.transaction_date).format("DD-MM-YYYY") : "-"
        }));
        setTableData(formattedData);
      } else {
        setTableData([]);
        setSummary({
          total_service_charge: 0,
          total_gst: 0
        });
      }
    } catch (error) {
      console.error(error);
      message.error("Failed to fetch report");
    } finally {
      setLoading(false);
    }
  };
  const resetFilters = () => {
    setFilters({
      fromDate: null,
      toDate: null,
      userId: void 0,
      groupId: void 0,
      type: void 0
    });
    setSummary({
      total_service_charge: 0,
      total_gst: 0
    });
    setTimeout(() => {
      fetchReport();
    }, 100);
  };
  const filterOption = (data, search) => {
    if (!search) return data;
    return data.filter(
      (item) => JSON.stringify(item).toLowerCase().includes(search.toLowerCase())
    );
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "transaction_id", header: "Transaction ID" },
    { key: "customer_name", header: "Customer Name" },
    { key: "phone_number", header: "Phone Number" },
    { key: "group_name", header: "Group" },
    { key: "transaction_type", header: "Transaction Type" },
    { key: "reason", header: "Reason" },
    { key: "service_charge", header: "Service Charge" },
    { key: "gst_amount", header: "GST Amount" },
    { key: "remarks", header: "Remarks" },
    { key: "transaction_date", header: "Transaction Date" }
  ];
  return /* @__PURE__ */ jsxDEV(Card, { title: "GST & Service Charge Report", children: [
    /* @__PURE__ */ jsxDEV(Row, { gutter: [16, 16], align: "middle", children: [
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, lg: 3, children: /* @__PURE__ */ jsxDEV(
        Select,
        {
          allowClear: true,
          showSearch: true,
          optionFilterProp: "children",
          filterOption: (input, option) => String(option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
          style: { width: "100%" },
          placeholder: "Select Type",
          value: filters.type,
          onChange: (value) => setFilters({
            ...filters,
            type: value
          }),
          children: [
            /* @__PURE__ */ jsxDEV(Option, { value: "service_charge", children: "Service Charge" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
              lineNumber: 220,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(Option, { value: "gst_amount", children: "GST" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
              lineNumber: 221,
              columnNumber: 11
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
          lineNumber: 201,
          columnNumber: 9
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 200,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, lg: 5, children: /* @__PURE__ */ jsxDEV(
        Select,
        {
          allowClear: true,
          showSearch: true,
          optionFilterProp: "children",
          filterOption: (input, option) => String(option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
          style: { width: "100%" },
          placeholder: "Select Customer",
          value: filters.userId,
          onChange: (value) => setFilters({
            ...filters,
            userId: value
          }),
          children: customers.map(
            (item) => /* @__PURE__ */ jsxDEV(Option, { value: item._id, children: `${item.full_name} | ${item.phone_number}` }, item._id, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
              lineNumber: 245,
              columnNumber: 13
            }, this)
          )
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
          lineNumber: 225,
          columnNumber: 9
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 224,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 6, lg: 4, children: /* @__PURE__ */ jsxDEV(
        Select,
        {
          allowClear: true,
          showSearch: true,
          optionFilterProp: "children",
          filterOption: (input, option) => String(option?.children ?? "").toLowerCase().includes(input.toLowerCase()),
          style: { width: "100%" },
          placeholder: "Select Group",
          value: filters.groupId,
          onChange: (value) => setFilters({
            ...filters,
            groupId: value
          }),
          children: groups.map(
            (item) => /* @__PURE__ */ jsxDEV(Option, { value: item._id, children: item.group_name }, item._id, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
              lineNumber: 274,
              columnNumber: 13
            }, this)
          )
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
          lineNumber: 254,
          columnNumber: 9
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 253,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, sm: 12, md: 8, lg: 6, children: /* @__PURE__ */ jsxDEV(
        RangePicker,
        {
          style: { width: "100%" },
          value: filters.fromDate ? [dayjs(filters.fromDate), dayjs(filters.toDate)] : null,
          onChange: (dates) => {
            if (!dates) {
              setFilters({
                ...filters,
                fromDate: null,
                toDate: null
              });
              return;
            }
            setFilters({
              ...filters,
              fromDate: dates[0],
              toDate: dates[1]
            });
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
          lineNumber: 286,
          columnNumber: 9
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 285,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(Col, { children: /* @__PURE__ */ jsxDEV(Button, { type: "primary", onClick: fetchReport, children: "Search" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 314,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 313,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(Col, { children: /* @__PURE__ */ jsxDEV(Button, { onClick: resetFilters, children: "Reset" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 321,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 320,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
      lineNumber: 199,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV(Row, { gutter: 16, style: { marginTop: 20, marginBottom: 20 }, children: [
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, md: 12, children: /* @__PURE__ */ jsxDEV(Card, { children: /* @__PURE__ */ jsxDEV(
        Statistic,
        {
          title: "Total Service Charge",
          value: summary.total_service_charge,
          precision: 2
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
          lineNumber: 328,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 327,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 326,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV(Col, { xs: 24, md: 12, children: /* @__PURE__ */ jsxDEV(Card, { children: /* @__PURE__ */ jsxDEV(
        Statistic,
        {
          title: "Total GST",
          value: summary.total_gst,
          precision: 2
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
          lineNumber: 338,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 337,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 336,
        columnNumber: 7
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
      lineNumber: 325,
      columnNumber: 5
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mb-20", children: tableData?.length > 0 ? /* @__PURE__ */ jsxDEV(
      DataTable,
      {
        data: filterOption(tableData, searchText),
        columns,
        exportedPdfName: "GST & Service Charge Report",
        exportedFileName: "GST_Service_Charge_Report.csv"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 349,
        columnNumber: 9
      },
      this
    ) : /* @__PURE__ */ jsxDEV(
      CircularLoader,
      {
        isLoading: loading,
        failure: tableData?.length <= 0,
        data: "GST & Service Charge Data"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
        lineNumber: 356,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
      lineNumber: 347,
      columnNumber: 5
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx",
    lineNumber: 198,
    columnNumber: 5
  }, this);
};
_s(GSTServiceChargeReport, "cfXZ+4eK2tq2dHB5memCLj7izis=");
_c = GSTServiceChargeReport;
export default GSTServiceChargeReport;
var _c;
$RefreshReg$(_c, "GSTServiceChargeReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/GSTServiceChargeReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMk5VOzJCQTNOVjtBQUFnQkEsTUFBV0MsY0FBUSxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2xEO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLE9BQU9DLFdBQVc7QUFFbEIsT0FBT0MsU0FBUztBQUVoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLG9CQUFvQjtBQUUzQixNQUFNLEVBQUVDLFlBQVksSUFBSVI7QUFDeEIsTUFBTSxFQUFFUyxPQUFPLElBQUlWO0FBRW5CLE1BQU1XLHlCQUF5QkEsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJbEIsU0FBUyxLQUFLO0FBRTVDLFFBQU0sQ0FBQ21CLFdBQVdDLFlBQVksSUFBSXBCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNxQixRQUFRQyxTQUFTLElBQUl0QixTQUFTLEVBQUU7QUFFdkMsUUFBTSxDQUFDdUIsV0FBV0MsWUFBWSxJQUFJeEIsU0FBUyxFQUFFO0FBRTdDLFFBQU0sQ0FBQ3lCLFNBQVNDLFVBQVUsSUFBSTFCLFNBQVM7QUFBQSxJQUNyQzJCLHNCQUFzQjtBQUFBLElBQ3RCQyxXQUFXO0FBQUEsRUFDYixDQUFDO0FBRUQsUUFBTSxDQUFDQyxTQUFTQyxVQUFVLElBQUk5QixTQUFTO0FBQUEsSUFDckMrQixVQUFVO0FBQUEsSUFDVkMsUUFBUTtBQUFBLElBQ1JDLFFBQVFDO0FBQUFBLElBQ1JDLFNBQVNEO0FBQUFBLElBQ1RFLE1BQU1GO0FBQUFBLEVBQ1IsQ0FBQztBQUVELFFBQU0sQ0FBQ0csWUFBWUMsYUFBYSxJQUFJdEMsU0FBUyxFQUFFO0FBRS9DRCxZQUFVLE1BQU07QUFDZHdDLG1CQUFlO0FBQ2ZDLGdCQUFZO0FBQ1pDLGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFFTCxRQUFNRixpQkFBaUIsWUFBWTtBQUNqQyxRQUFJO0FBQ0YsWUFBTUcsTUFBTSxNQUFNaEMsSUFBSWlDLElBQUksZ0JBQWdCO0FBRTFDdkIsbUJBQWFzQixJQUFJRSxRQUFRLEVBQUU7QUFBQSxJQUM3QixTQUFTQyxLQUFLO0FBQ1pDLGNBQVFDLElBQUlGLEdBQUc7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNTCxjQUFjLFlBQVk7QUFDOUIsUUFBSTtBQUNGLFlBQU1FLE1BQU0sTUFBTWhDLElBQUlpQyxJQUFJLHdCQUF3QjtBQUVsRHJCLGdCQUFVb0IsSUFBSUUsUUFBUSxFQUFFO0FBQUEsSUFDMUIsU0FBU0MsS0FBSztBQUNaQyxjQUFRQyxJQUFJRixHQUFHO0FBQUEsSUFDakI7QUFBQSxFQUNGO0FBRUEsUUFBTUosY0FBYyxZQUFZO0FBQzlCLFFBQUk7QUFDRnZCLGlCQUFXLElBQUk7QUFFZixZQUFNOEIsU0FBUyxDQUFDO0FBRWhCLFVBQUluQixRQUFRRSxVQUFVO0FBQ3BCaUIsZUFBT2pCLFdBQVd0QixNQUFNb0IsUUFBUUUsUUFBUSxFQUFFa0IsT0FBTyxZQUFZO0FBQUEsTUFDL0Q7QUFFQSxVQUFJcEIsUUFBUUcsUUFBUTtBQUNsQmdCLGVBQU9oQixTQUFTdkIsTUFBTW9CLFFBQVFHLE1BQU0sRUFBRWlCLE9BQU8sWUFBWTtBQUFBLE1BQzNEO0FBRUEsVUFBSXBCLFFBQVFJLFFBQVE7QUFDbEJlLGVBQU9mLFNBQVNKLFFBQVFJO0FBQUFBLE1BQzFCO0FBRUEsVUFBSUosUUFBUU0sU0FBUztBQUNuQmEsZUFBT2IsVUFBVU4sUUFBUU07QUFBQUEsTUFDM0I7QUFFQSxVQUFJTixRQUFRTyxNQUFNO0FBQ2hCWSxlQUFPWixPQUFPUCxRQUFRTztBQUFBQSxNQUN4QjtBQUVBLFlBQU1jLFdBQVcsTUFBTXhDLElBQUlpQyxJQUFJLHFDQUFxQztBQUFBLFFBQ2xFSztBQUFBQSxNQUNGLENBQUM7QUFFRCxVQUFJRSxTQUFTTixLQUFLQSxNQUFNTyxTQUFTLEdBQUc7QUFDbEMsY0FBTUMsU0FBU0YsU0FBU04sS0FBS0EsS0FBSyxDQUFDO0FBRW5DbEIsbUJBQVc7QUFBQSxVQUNUQyxzQkFBc0J5QixPQUFPekIsd0JBQXdCO0FBQUEsVUFDckRDLFdBQVd3QixPQUFPeEIsYUFBYTtBQUFBLFFBQ2pDLENBQUM7QUFFRCxjQUFNeUIsZ0JBQWdCRCxPQUFPRSxhQUFhQyxPQUFPLENBQUNDLE1BQUtBLEVBQUVDLFdBQVcsa0JBQWtCLEVBQUVDLElBQUksQ0FBQ0MsTUFBTUMsV0FBVztBQUFBLFVBQzVHQyxLQUFLRixLQUFLRTtBQUFBQSxVQUNWQyxJQUFJRixRQUFRO0FBQUEsVUFFWkcsZ0JBQWdCSixLQUFLSTtBQUFBQSxVQUVyQkMsZUFBZUwsTUFBTU0sUUFBUUQsaUJBQWlCO0FBQUEsVUFFOUNFLGNBQWNQLE1BQU1NLFFBQVFDLGdCQUFnQjtBQUFBLFVBRTVDQyxZQUFZUixNQUFNTSxRQUFRRSxjQUFjO0FBQUEsVUFFeENDLGtCQUFrQlQsS0FBS1Msb0JBQW9CO0FBQUEsVUFFM0NYLFFBQVFFLEtBQUtGLFVBQVU7QUFBQSxVQUV2QlksaUJBQWlCVixLQUFLVSxtQkFBbUI7QUFBQSxVQUV6Q0MsZ0JBQWdCWCxLQUFLVyxrQkFBa0I7QUFBQSxVQUV2Q0MsWUFBWVosS0FBS1ksY0FBYztBQUFBLFVBRS9CQyxTQUFTYixLQUFLYSxXQUFXO0FBQUEsVUFFekJDLGtCQUFrQmQsS0FBS2MsbUJBQ25CaEUsTUFBTWtELEtBQUtjLGdCQUFnQixFQUFFeEIsT0FBTyxZQUFZLElBQ2hEO0FBQUEsUUFDTixFQUFFO0FBR0Z6QixxQkFBYTZCLGFBQWE7QUFBQSxNQUM1QixPQUFPO0FBQ0w3QixxQkFBYSxFQUFFO0FBRWZFLG1CQUFXO0FBQUEsVUFDVEMsc0JBQXNCO0FBQUEsVUFDdEJDLFdBQVc7QUFBQSxRQUNiLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTOEMsT0FBTztBQUNkNUIsY0FBUTRCLE1BQU1BLEtBQUs7QUFDbkJsRSxjQUFRa0UsTUFBTSx3QkFBd0I7QUFBQSxJQUN4QyxVQUFDO0FBQ0N4RCxpQkFBVyxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTXlELGVBQWVBLE1BQU07QUFDekI3QyxlQUFXO0FBQUEsTUFDVEMsVUFBVTtBQUFBLE1BQ1ZDLFFBQVE7QUFBQSxNQUNSQyxRQUFRQztBQUFBQSxNQUNSQyxTQUFTRDtBQUFBQSxNQUNURSxNQUFNRjtBQUFBQSxJQUNSLENBQUM7QUFFRFIsZUFBVztBQUFBLE1BQ1RDLHNCQUFzQjtBQUFBLE1BQ3RCQyxXQUFXO0FBQUEsSUFDYixDQUFDO0FBRURnRCxlQUFXLE1BQU07QUFDZm5DLGtCQUFZO0FBQUEsSUFDZCxHQUFHLEdBQUc7QUFBQSxFQUNSO0FBRUEsUUFBTW9DLGVBQWVBLENBQUNqQyxNQUFNa0MsV0FBVztBQUNyQyxRQUFJLENBQUNBLE9BQVEsUUFBT2xDO0FBRXBCLFdBQU9BLEtBQUtXO0FBQUFBLE1BQU8sQ0FBQ0ksU0FDbEJvQixLQUFLQyxVQUFVckIsSUFBSSxFQUFFc0IsWUFBWSxFQUFFQyxTQUFTSixPQUFPRyxZQUFZLENBQUM7QUFBQSxJQUNsRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNRSxVQUFVO0FBQUEsSUFDZCxFQUFFQyxLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssa0JBQWtCQyxRQUFRLGlCQUFpQjtBQUFBLElBQ2xELEVBQUVELEtBQUssaUJBQWlCQyxRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsUUFBUTtBQUFBLElBQ3JDLEVBQUVELEtBQUssb0JBQW9CQyxRQUFRLG1CQUFtQjtBQUFBLElBQ3RELEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxrQkFBa0JDLFFBQVEsaUJBQWlCO0FBQUEsSUFDbEQsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUVELEtBQUssb0JBQW9CQyxRQUFRLG1CQUFtQjtBQUFBLEVBQUM7QUFHMUQsU0FDQyx1QkFBQyxRQUFLLE9BQU0sK0JBQ1Y7QUFBQSwyQkFBQyxPQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsR0FBRyxPQUFNLFVBQzNCO0FBQUEsNkJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLEdBQzlCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0E7QUFBQSxVQUNBLGtCQUFpQjtBQUFBLFVBQ2pCLGNBQWMsQ0FBQ0MsT0FBT0MsV0FDcEJDLE9BQU9ELFFBQVFFLFlBQVksRUFBRSxFQUMxQlIsWUFBWSxFQUNaQyxTQUFTSSxNQUFNTCxZQUFZLENBQUM7QUFBQSxVQUVqQyxPQUFPLEVBQUVTLE9BQU8sT0FBTztBQUFBLFVBQ3ZCLGFBQVk7QUFBQSxVQUNaLE9BQU83RCxRQUFRTztBQUFBQSxVQUNmLFVBQVUsQ0FBQ3VELFVBQ1Q3RCxXQUFXO0FBQUEsWUFDVCxHQUFHRDtBQUFBQSxZQUNITyxNQUFNdUQ7QUFBQUEsVUFDUixDQUFDO0FBQUEsVUFHSDtBQUFBLG1DQUFDLFVBQU8sT0FBTSxrQkFBaUIsOEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTZDO0FBQUEsWUFDN0MsdUJBQUMsVUFBTyxPQUFNLGNBQWEsbUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQThCO0FBQUE7QUFBQTtBQUFBLFFBcEJoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFxQkEsS0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQTtBQUFBLE1BQ0EsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLEdBQzlCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0E7QUFBQSxVQUNBLGtCQUFpQjtBQUFBLFVBQ2pCLGNBQWMsQ0FBQ0wsT0FBT0MsV0FDcEJDLE9BQU9ELFFBQVFFLFlBQVksRUFBRSxFQUMxQlIsWUFBWSxFQUNaQyxTQUFTSSxNQUFNTCxZQUFZLENBQUM7QUFBQSxVQUVqQyxPQUFPLEVBQUVTLE9BQU8sT0FBTztBQUFBLFVBQ3ZCLGFBQVk7QUFBQSxVQUNaLE9BQU83RCxRQUFRSTtBQUFBQSxVQUNmLFVBQVUsQ0FBQzBELFVBQ1Q3RCxXQUFXO0FBQUEsWUFDVCxHQUFHRDtBQUFBQSxZQUNISSxRQUFRMEQ7QUFBQUEsVUFDVixDQUFDO0FBQUEsVUFHRnhFLG9CQUFVdUM7QUFBQUEsWUFBSSxDQUFDQyxTQUNkLHVCQUFDLFVBQXNCLE9BQU9BLEtBQUtFLEtBQ2hDLGFBQUdGLEtBQUtpQyxTQUFTLE1BQU1qQyxLQUFLTyxZQUFZLE1BRDlCUCxLQUFLRSxLQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsVUFDRDtBQUFBO0FBQUEsUUF2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Bd0JBLEtBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEwQkE7QUFBQSxNQUdBLHVCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUM5QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBO0FBQUEsVUFDQSxrQkFBaUI7QUFBQSxVQUNqQixjQUFjLENBQUN5QixPQUFPQyxXQUNwQkMsT0FBT0QsUUFBUUUsWUFBWSxFQUFFLEVBQzFCUixZQUFZLEVBQ1pDLFNBQVNJLE1BQU1MLFlBQVksQ0FBQztBQUFBLFVBRWpDLE9BQU8sRUFBRVMsT0FBTyxPQUFPO0FBQUEsVUFDdkIsYUFBWTtBQUFBLFVBQ1osT0FBTzdELFFBQVFNO0FBQUFBLFVBQ2YsVUFBVSxDQUFDd0QsVUFDVDdELFdBQVc7QUFBQSxZQUNULEdBQUdEO0FBQUFBLFlBQ0hNLFNBQVN3RDtBQUFBQSxVQUNYLENBQUM7QUFBQSxVQUdGdEUsaUJBQU9xQztBQUFBQSxZQUFJLENBQUNDLFNBQ1gsdUJBQUMsVUFBc0IsT0FBT0EsS0FBS0UsS0FDaENGLGVBQUtRLGNBREtSLEtBQUtFLEtBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxVQUNEO0FBQUE7QUFBQSxRQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUF3QkEsS0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBCQTtBQUFBLE1BTUEsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLEdBQzlCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPLEVBQUU2QixPQUFPLE9BQU87QUFBQSxVQUN2QixPQUNFN0QsUUFBUUUsV0FDSixDQUFDdEIsTUFBTW9CLFFBQVFFLFFBQVEsR0FBR3RCLE1BQU1vQixRQUFRRyxNQUFNLENBQUMsSUFDL0M7QUFBQSxVQUVOLFVBQVUsQ0FBQzZELFVBQVU7QUFDbkIsZ0JBQUksQ0FBQ0EsT0FBTztBQUNWL0QseUJBQVc7QUFBQSxnQkFDVCxHQUFHRDtBQUFBQSxnQkFDSEUsVUFBVTtBQUFBLGdCQUNWQyxRQUFRO0FBQUEsY0FDVixDQUFDO0FBQ0Q7QUFBQSxZQUNGO0FBRUFGLHVCQUFXO0FBQUEsY0FDVCxHQUFHRDtBQUFBQSxjQUNIRSxVQUFVOEQsTUFBTSxDQUFDO0FBQUEsY0FDakI3RCxRQUFRNkQsTUFBTSxDQUFDO0FBQUEsWUFDakIsQ0FBQztBQUFBLFVBQ0g7QUFBQTtBQUFBLFFBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXNCSSxLQXZCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsTUFHQSx1QkFBQyxPQUNDLGlDQUFDLFVBQU8sTUFBSyxXQUFVLFNBQVNwRCxhQUFhLHNCQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUdBLHVCQUFDLE9BQ0MsaUNBQUMsVUFBTyxTQUFTa0MsY0FBYyxxQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQyxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQTNIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEhBO0FBQUEsSUFFQSx1QkFBQyxPQUFJLFFBQVEsSUFBSSxPQUFPLEVBQUVtQixXQUFXLElBQUlDLGNBQWMsR0FBRyxHQUN4RDtBQUFBLDZCQUFDLE9BQUksSUFBSSxJQUFJLElBQUksSUFDZixpQ0FBQyxRQUNDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFNO0FBQUEsVUFDTixPQUFPdEUsUUFBUUU7QUFBQUEsVUFDZixXQUFXO0FBQUE7QUFBQSxRQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdlLEtBSmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BRUEsdUJBQUMsT0FBSSxJQUFJLElBQUksSUFBSSxJQUNmLGlDQUFDLFFBQ0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE9BQU07QUFBQSxVQUNOLE9BQU9GLFFBQVFHO0FBQUFBLFVBQ2YsV0FBVztBQUFBO0FBQUEsUUFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHZSxLQUpqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxTQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsU0FDWkwscUJBQVc0QixTQUFTLElBQ25CO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNMEIsYUFBYXRELFdBQVdjLFVBQVU7QUFBQSxRQUN4QztBQUFBLFFBQ0EsaUJBQWdCO0FBQUEsUUFDaEIsa0JBQWlCO0FBQUE7QUFBQSxNQUpuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFJa0QsSUFHbEQ7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVdwQjtBQUFBQSxRQUNYLFNBQVNNLFdBQVc0QixVQUFVO0FBQUEsUUFDOUIsTUFBSztBQUFBO0FBQUEsTUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHa0MsS0FadEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWVBO0FBQUEsT0FwS0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFLQTtBQUVGO0FBQUVuQyxHQXZWSUQsd0JBQXNCO0FBQUFpRixLQUF0QmpGO0FBeVZOLGVBQWVBO0FBQXVCLElBQUFpRjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJDYXJkIiwiUm93IiwiQ29sIiwiU2VsZWN0IiwiRGF0ZVBpY2tlciIsIkJ1dHRvbiIsIlN0YXRpc3RpYyIsIm1lc3NhZ2UiLCJkYXlqcyIsImFwaSIsIkRhdGFUYWJsZSIsIkNpcmN1bGFyTG9hZGVyIiwiUmFuZ2VQaWNrZXIiLCJPcHRpb24iLCJHU1RTZXJ2aWNlQ2hhcmdlUmVwb3J0IiwiX3MiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImN1c3RvbWVycyIsInNldEN1c3RvbWVycyIsImdyb3VwcyIsInNldEdyb3VwcyIsInRhYmxlRGF0YSIsInNldFRhYmxlRGF0YSIsInN1bW1hcnkiLCJzZXRTdW1tYXJ5IiwidG90YWxfc2VydmljZV9jaGFyZ2UiLCJ0b3RhbF9nc3QiLCJmaWx0ZXJzIiwic2V0RmlsdGVycyIsImZyb21EYXRlIiwidG9EYXRlIiwidXNlcklkIiwidW5kZWZpbmVkIiwiZ3JvdXBJZCIsInR5cGUiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsImZldGNoQ3VzdG9tZXJzIiwiZmV0Y2hHcm91cHMiLCJmZXRjaFJlcG9ydCIsInJlcyIsImdldCIsImRhdGEiLCJlcnIiLCJjb25zb2xlIiwibG9nIiwicGFyYW1zIiwiZm9ybWF0IiwicmVzcG9uc2UiLCJsZW5ndGgiLCJyZXN1bHQiLCJmb3JtYXR0ZWREYXRhIiwidHJhbnNhY3Rpb25zIiwiZmlsdGVyIiwiZSIsInJlYXNvbiIsIm1hcCIsIml0ZW0iLCJpbmRleCIsIl9pZCIsImlkIiwidHJhbnNhY3Rpb25faWQiLCJjdXN0b21lcl9uYW1lIiwiZW5yb2xsIiwicGhvbmVfbnVtYmVyIiwiZ3JvdXBfbmFtZSIsInRyYW5zYWN0aW9uX3R5cGUiLCJpbnRlcmVzdF9hbW91bnQiLCJzZXJ2aWNlX2NoYXJnZSIsImdzdF9hbW91bnQiLCJyZW1hcmtzIiwidHJhbnNhY3Rpb25fZGF0ZSIsImVycm9yIiwicmVzZXRGaWx0ZXJzIiwic2V0VGltZW91dCIsImZpbHRlck9wdGlvbiIsInNlYXJjaCIsIkpTT04iLCJzdHJpbmdpZnkiLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiY29sdW1ucyIsImtleSIsImhlYWRlciIsImlucHV0Iiwib3B0aW9uIiwiU3RyaW5nIiwiY2hpbGRyZW4iLCJ3aWR0aCIsInZhbHVlIiwiZnVsbF9uYW1lIiwiZGF0ZXMiLCJtYXJnaW5Ub3AiLCJtYXJnaW5Cb3R0b20iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJHU1RTZXJ2aWNlQ2hhcmdlUmVwb3J0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIENhcmQsXHJcbiAgUm93LFxyXG4gIENvbCxcclxuICBTZWxlY3QsXHJcbiAgRGF0ZVBpY2tlcixcclxuICBCdXR0b24sXHJcbiAgU3RhdGlzdGljLFxyXG4gIG1lc3NhZ2UsXHJcbn0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IGRheWpzIGZyb20gXCJkYXlqc1wiO1xyXG5cclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5cclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5cclxuY29uc3QgeyBSYW5nZVBpY2tlciB9ID0gRGF0ZVBpY2tlcjtcclxuY29uc3QgeyBPcHRpb24gfSA9IFNlbGVjdDtcclxuXHJcbmNvbnN0IEdTVFNlcnZpY2VDaGFyZ2VSZXBvcnQgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICBjb25zdCBbY3VzdG9tZXJzLCBzZXRDdXN0b21lcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIGNvbnN0IFt0YWJsZURhdGEsIHNldFRhYmxlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcblxyXG4gIGNvbnN0IFtzdW1tYXJ5LCBzZXRTdW1tYXJ5XSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsX3NlcnZpY2VfY2hhcmdlOiAwLFxyXG4gICAgdG90YWxfZ3N0OiAwLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbZmlsdGVycywgc2V0RmlsdGVyc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBmcm9tRGF0ZTogbnVsbCxcclxuICAgIHRvRGF0ZTogbnVsbCxcclxuICAgIHVzZXJJZDogdW5kZWZpbmVkLFxyXG4gICAgZ3JvdXBJZDogdW5kZWZpbmVkLFxyXG4gICAgdHlwZTogdW5kZWZpbmVkLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbc2VhcmNoVGV4dCwgc2V0U2VhcmNoVGV4dF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoQ3VzdG9tZXJzKCk7XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gICAgZmV0Y2hSZXBvcnQoKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIGNvbnN0IGZldGNoQ3VzdG9tZXJzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpO1xyXG5cclxuICAgICAgc2V0Q3VzdG9tZXJzKHJlcy5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmxvZyhlcnIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoR3JvdXBzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcblxyXG4gICAgICBzZXRHcm91cHMocmVzLmRhdGEgfHwgW10pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hSZXBvcnQgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgY29uc3QgcGFyYW1zID0ge307XHJcblxyXG4gICAgICBpZiAoZmlsdGVycy5mcm9tRGF0ZSkge1xyXG4gICAgICAgIHBhcmFtcy5mcm9tRGF0ZSA9IGRheWpzKGZpbHRlcnMuZnJvbURhdGUpLmZvcm1hdChcIllZWVktTU0tRERcIik7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChmaWx0ZXJzLnRvRGF0ZSkge1xyXG4gICAgICAgIHBhcmFtcy50b0RhdGUgPSBkYXlqcyhmaWx0ZXJzLnRvRGF0ZSkuZm9ybWF0KFwiWVlZWS1NTS1ERFwiKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKGZpbHRlcnMudXNlcklkKSB7XHJcbiAgICAgICAgcGFyYW1zLnVzZXJJZCA9IGZpbHRlcnMudXNlcklkO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBpZiAoZmlsdGVycy5ncm91cElkKSB7XHJcbiAgICAgICAgcGFyYW1zLmdyb3VwSWQgPSBmaWx0ZXJzLmdyb3VwSWQ7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChmaWx0ZXJzLnR5cGUpIHtcclxuICAgICAgICBwYXJhbXMudHlwZSA9IGZpbHRlcnMudHlwZTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3YxL2FkbWluL3RyYW5zYWN0aW9uLWhpc3RvcnkvZ3N0XCIsIHtcclxuICAgICAgICBwYXJhbXMsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGEuZGF0YT8ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHJlc3BvbnNlLmRhdGEuZGF0YVswXTtcclxuXHJcbiAgICAgICAgc2V0U3VtbWFyeSh7XHJcbiAgICAgICAgICB0b3RhbF9zZXJ2aWNlX2NoYXJnZTogcmVzdWx0LnRvdGFsX3NlcnZpY2VfY2hhcmdlIHx8IDAsXHJcbiAgICAgICAgICB0b3RhbF9nc3Q6IHJlc3VsdC50b3RhbF9nc3QgfHwgMCxcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3VsdC50cmFuc2FjdGlvbnMuZmlsdGVyKChlKT0+IGUucmVhc29uICE9PSBcIlBpZ215IFdpdGhkcmF3YWxcIikubWFwKChpdGVtLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgIF9pZDogaXRlbS5faWQsXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG5cclxuICAgICAgICAgIHRyYW5zYWN0aW9uX2lkOiBpdGVtLnRyYW5zYWN0aW9uX2lkLFxyXG5cclxuICAgICAgICAgIGN1c3RvbWVyX25hbWU6IGl0ZW0/LmVucm9sbD8uY3VzdG9tZXJfbmFtZSB8fCBcIk4vQVwiLFxyXG5cclxuICAgICAgICAgIHBob25lX251bWJlcjogaXRlbT8uZW5yb2xsPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuXHJcbiAgICAgICAgICBncm91cF9uYW1lOiBpdGVtPy5lbnJvbGw/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuXHJcbiAgICAgICAgICB0cmFuc2FjdGlvbl90eXBlOiBpdGVtLnRyYW5zYWN0aW9uX3R5cGUgfHwgXCItXCIsXHJcblxyXG4gICAgICAgICAgcmVhc29uOiBpdGVtLnJlYXNvbiB8fCBcIi1cIixcclxuXHJcbiAgICAgICAgICBpbnRlcmVzdF9hbW91bnQ6IGl0ZW0uaW50ZXJlc3RfYW1vdW50IHx8IDAsXHJcblxyXG4gICAgICAgICAgc2VydmljZV9jaGFyZ2U6IGl0ZW0uc2VydmljZV9jaGFyZ2UgfHwgMCxcclxuXHJcbiAgICAgICAgICBnc3RfYW1vdW50OiBpdGVtLmdzdF9hbW91bnQgfHwgMCxcclxuXHJcbiAgICAgICAgICByZW1hcmtzOiBpdGVtLnJlbWFya3MgfHwgXCItXCIsXHJcblxyXG4gICAgICAgICAgdHJhbnNhY3Rpb25fZGF0ZTogaXRlbS50cmFuc2FjdGlvbl9kYXRlXHJcbiAgICAgICAgICAgID8gZGF5anMoaXRlbS50cmFuc2FjdGlvbl9kYXRlKS5mb3JtYXQoXCJERC1NTS1ZWVlZXCIpXHJcbiAgICAgICAgICAgIDogXCItXCIsXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIFxyXG5cclxuICAgICAgICBzZXRUYWJsZURhdGEoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0VGFibGVEYXRhKFtdKTtcclxuXHJcbiAgICAgICAgc2V0U3VtbWFyeSh7XHJcbiAgICAgICAgICB0b3RhbF9zZXJ2aWNlX2NoYXJnZTogMCxcclxuICAgICAgICAgIHRvdGFsX2dzdDogMCxcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcmVwb3J0XCIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcmVzZXRGaWx0ZXJzID0gKCkgPT4ge1xyXG4gICAgc2V0RmlsdGVycyh7XHJcbiAgICAgIGZyb21EYXRlOiBudWxsLFxyXG4gICAgICB0b0RhdGU6IG51bGwsXHJcbiAgICAgIHVzZXJJZDogdW5kZWZpbmVkLFxyXG4gICAgICBncm91cElkOiB1bmRlZmluZWQsXHJcbiAgICAgIHR5cGU6IHVuZGVmaW5lZCxcclxuICAgIH0pO1xyXG5cclxuICAgIHNldFN1bW1hcnkoe1xyXG4gICAgICB0b3RhbF9zZXJ2aWNlX2NoYXJnZTogMCxcclxuICAgICAgdG90YWxfZ3N0OiAwLFxyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIGZldGNoUmVwb3J0KCk7XHJcbiAgICB9LCAxMDApO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZpbHRlck9wdGlvbiA9IChkYXRhLCBzZWFyY2gpID0+IHtcclxuICAgIGlmICghc2VhcmNoKSByZXR1cm4gZGF0YTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5maWx0ZXIoKGl0ZW0pID0+XHJcbiAgICAgIEpTT04uc3RyaW5naWZ5KGl0ZW0pLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoLnRvTG93ZXJDYXNlKCkpLFxyXG4gICAgKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBjb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl9pZFwiLCBoZWFkZXI6IFwiVHJhbnNhY3Rpb24gSURcIiB9LFxyXG4gICAgeyBrZXk6IFwiY3VzdG9tZXJfbmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cFwiIH0sXHJcbiAgICB7IGtleTogXCJ0cmFuc2FjdGlvbl90eXBlXCIsIGhlYWRlcjogXCJUcmFuc2FjdGlvbiBUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInJlYXNvblwiLCBoZWFkZXI6IFwiUmVhc29uXCIgfSxcclxuICAgIHsga2V5OiBcInNlcnZpY2VfY2hhcmdlXCIsIGhlYWRlcjogXCJTZXJ2aWNlIENoYXJnZVwiIH0sXHJcbiAgICB7IGtleTogXCJnc3RfYW1vdW50XCIsIGhlYWRlcjogXCJHU1QgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcInJlbWFya3NcIiwgaGVhZGVyOiBcIlJlbWFya3NcIiB9LFxyXG4gICAgeyBrZXk6IFwidHJhbnNhY3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiVHJhbnNhY3Rpb24gRGF0ZVwiIH0sXHJcbiAgXTtcclxuXHJcbiByZXR1cm4gKFxyXG4gIDxDYXJkIHRpdGxlPVwiR1NUICYgU2VydmljZSBDaGFyZ2UgUmVwb3J0XCI+XHJcbiAgICA8Um93IGd1dHRlcj17WzE2LCAxNl19IGFsaWduPVwibWlkZGxlXCI+XHJcbiAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IG1kPXs2fSBsZz17M30+XHJcbiAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgIFN0cmluZyhvcHRpb24/LmNoaWxkcmVuID8/IFwiXCIpXHJcbiAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgVHlwZVwiXHJcbiAgICAgICAgICB2YWx1ZT17ZmlsdGVycy50eXBlfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgc2V0RmlsdGVycyh7XHJcbiAgICAgICAgICAgICAgLi4uZmlsdGVycyxcclxuICAgICAgICAgICAgICB0eXBlOiB2YWx1ZSxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwic2VydmljZV9jaGFyZ2VcIj5TZXJ2aWNlIENoYXJnZTwvT3B0aW9uPlxyXG4gICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cImdzdF9hbW91bnRcIj5HU1Q8L09wdGlvbj5cclxuICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgPC9Db2w+XHJcbiAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IG1kPXs2fSBsZz17NX0+XHJcbiAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgIFN0cmluZyhvcHRpb24/LmNoaWxkcmVuID8/IFwiXCIpXHJcbiAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBcIjEwMCVcIiB9fVxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgdmFsdWU9e2ZpbHRlcnMudXNlcklkfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgc2V0RmlsdGVycyh7XHJcbiAgICAgICAgICAgICAgLi4uZmlsdGVycyxcclxuICAgICAgICAgICAgICB1c2VySWQ6IHZhbHVlLFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHtjdXN0b21lcnMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgIDxPcHRpb24ga2V5PXtpdGVtLl9pZH0gdmFsdWU9e2l0ZW0uX2lkfT5cclxuICAgICAgICAgICAgICB7YCR7aXRlbS5mdWxsX25hbWV9IHwgJHtpdGVtLnBob25lX251bWJlcn1gfVxyXG4gICAgICAgICAgICA8L09wdGlvbj5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICA8L0NvbD5cclxuXHJcbiAgICAgIHsvKiBHcm91cCAqL31cclxuICAgICAgPENvbCB4cz17MjR9IHNtPXsxMn0gbWQ9ezZ9IGxnPXs0fT5cclxuICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgU3RyaW5nKG9wdGlvbj8uY2hpbGRyZW4gPz8gXCJcIilcclxuICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBHcm91cFwiXHJcbiAgICAgICAgICB2YWx1ZT17ZmlsdGVycy5ncm91cElkfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT5cclxuICAgICAgICAgICAgc2V0RmlsdGVycyh7XHJcbiAgICAgICAgICAgICAgLi4uZmlsdGVycyxcclxuICAgICAgICAgICAgICBncm91cElkOiB2YWx1ZSxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7Z3JvdXBzLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICA8T3B0aW9uIGtleT17aXRlbS5faWR9IHZhbHVlPXtpdGVtLl9pZH0+XHJcbiAgICAgICAgICAgICAge2l0ZW0uZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgPC9PcHRpb24+XHJcbiAgICAgICAgICApKX1cclxuICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgPC9Db2w+XHJcblxyXG4gICAgIFxyXG4gICAgICBcclxuXHJcbiAgICAgXHJcbiAgICAgIDxDb2wgeHM9ezI0fSBzbT17MTJ9IG1kPXs4fSBsZz17Nn0+XHJcbiAgICAgICAgPFJhbmdlUGlja2VyXHJcbiAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgZmlsdGVycy5mcm9tRGF0ZVxyXG4gICAgICAgICAgICAgID8gW2RheWpzKGZpbHRlcnMuZnJvbURhdGUpLCBkYXlqcyhmaWx0ZXJzLnRvRGF0ZSldXHJcbiAgICAgICAgICAgICAgOiBudWxsXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGRhdGVzKSA9PiB7XHJcbiAgICAgICAgICAgIGlmICghZGF0ZXMpIHtcclxuICAgICAgICAgICAgICBzZXRGaWx0ZXJzKHtcclxuICAgICAgICAgICAgICAgIC4uLmZpbHRlcnMsXHJcbiAgICAgICAgICAgICAgICBmcm9tRGF0ZTogbnVsbCxcclxuICAgICAgICAgICAgICAgIHRvRGF0ZTogbnVsbCxcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHNldEZpbHRlcnMoe1xyXG4gICAgICAgICAgICAgIC4uLmZpbHRlcnMsXHJcbiAgICAgICAgICAgICAgZnJvbURhdGU6IGRhdGVzWzBdLFxyXG4gICAgICAgICAgICAgIHRvRGF0ZTogZGF0ZXNbMV0sXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAvPlxyXG4gICAgICA8L0NvbD5cclxuXHJcbiAgICAgIHsvKiBTZWFyY2ggKi99XHJcbiAgICAgIDxDb2w+XHJcbiAgICAgICAgPEJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiIG9uQ2xpY2s9e2ZldGNoUmVwb3J0fT5cclxuICAgICAgICAgIFNlYXJjaFxyXG4gICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICA8L0NvbD5cclxuXHJcbiAgICAgIHsvKiBSZXNldCAqL31cclxuICAgICAgPENvbD5cclxuICAgICAgICA8QnV0dG9uIG9uQ2xpY2s9e3Jlc2V0RmlsdGVyc30+UmVzZXQ8L0J1dHRvbj5cclxuICAgICAgPC9Db2w+XHJcbiAgICA8L1Jvdz5cclxuXHJcbiAgICA8Um93IGd1dHRlcj17MTZ9IHN0eWxlPXt7IG1hcmdpblRvcDogMjAsIG1hcmdpbkJvdHRvbTogMjAgfX0+XHJcbiAgICAgIDxDb2wgeHM9ezI0fSBtZD17MTJ9PlxyXG4gICAgICAgIDxDYXJkPlxyXG4gICAgICAgICAgPFN0YXRpc3RpY1xyXG4gICAgICAgICAgICB0aXRsZT1cIlRvdGFsIFNlcnZpY2UgQ2hhcmdlXCJcclxuICAgICAgICAgICAgdmFsdWU9e3N1bW1hcnkudG90YWxfc2VydmljZV9jaGFyZ2V9XHJcbiAgICAgICAgICAgIHByZWNpc2lvbj17Mn1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9DYXJkPlxyXG4gICAgICA8L0NvbD5cclxuXHJcbiAgICAgIDxDb2wgeHM9ezI0fSBtZD17MTJ9PlxyXG4gICAgICAgIDxDYXJkPlxyXG4gICAgICAgICAgPFN0YXRpc3RpY1xyXG4gICAgICAgICAgICB0aXRsZT1cIlRvdGFsIEdTVFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtzdW1tYXJ5LnRvdGFsX2dzdH1cclxuICAgICAgICAgICAgcHJlY2lzaW9uPXsyfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L0NhcmQ+XHJcbiAgICAgIDwvQ29sPlxyXG4gICAgPC9Sb3c+XHJcblxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtYi0yMFwiPlxyXG4gICAgICB7dGFibGVEYXRhPy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbih0YWJsZURhdGEsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkdTVCAmIFNlcnZpY2UgQ2hhcmdlIFJlcG9ydFwiXHJcbiAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiR1NUX1NlcnZpY2VfQ2hhcmdlX1JlcG9ydC5jc3ZcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICBpc0xvYWRpbmc9e2xvYWRpbmd9XHJcbiAgICAgICAgICBmYWlsdXJlPXt0YWJsZURhdGE/Lmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgZGF0YT1cIkdTVCAmIFNlcnZpY2UgQ2hhcmdlIERhdGFcIlxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICA8L0NhcmQ+XHJcbik7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBHU1RTZXJ2aWNlQ2hhcmdlUmVwb3J0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvR1NUU2VydmljZUNoYXJnZVJlcG9ydC5qc3gifQ==