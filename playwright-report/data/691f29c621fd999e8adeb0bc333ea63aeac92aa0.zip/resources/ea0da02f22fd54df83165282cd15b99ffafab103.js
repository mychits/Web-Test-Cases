import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Insurance.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import SettingSidebar from "/src/components/layouts/SettingSidebar.jsx";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
const Insurance = () => {
  _s();
  const [insurance, setInsurance] = useState([]);
  const [insuranceTable, setInsuarnceTable] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  useEffect(() => {
    const fetchInsurance = async () => {
      try {
        setIsLoading(true);
        const response = await api.get("/insurance");
        const enquiry = response.data?.enquire;
        const responseData = Array.isArray(enquiry) ? enquiry : [];
        setInsurance(responseData);
        const formattedData = responseData?.map((group, index) => ({
          _id: group._id,
          id: index + 1,
          insurance_code: group?.insurance_code,
          customerName: group.customer_id?.full_name,
          phoneNumber: group.customer_id?.phone_number,
          insuranceType: group.insurance_type.join(", ") || []
        }));
        setInsuarnceTable(formattedData);
      } catch (error) {
        console.error("failed to load insurance data", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchInsurance();
  }, []);
  const column = [
    { key: "id", header: "SL No" },
    { key: "insurance_code", header: "Insurance Code" },
    { key: "customerName", header: "Customer Name" },
    { key: "phoneNumber", header: "Phone Number" },
    { key: "insuranceType", header: "Insurance Type" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx",
        lineNumber: 68,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(SettingSidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx",
      lineNumber: 72,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(
      CustomAlertDialog,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message,
        onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx",
        lineNumber: 73,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Insurance" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx",
        lineNumber: 84,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx",
        lineNumber: 83,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx",
        lineNumber: 82,
        columnNumber: 13
      }, this),
      insuranceTable && !isLoading ? /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: insuranceTable,
          columns: column,
          exportedFileName: "Insurance.csv",
          exportedPdfName: "Insurance"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx",
          lineNumber: 88,
          columnNumber: 13
        },
        this
      ) : /* @__PURE__ */ jsxDEV(
        CircularLoader,
        {
          isLoading,
          failure: insuranceTable.length <= 0,
          data: "insurance data"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx",
          lineNumber: 93,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx",
      lineNumber: 81,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx",
    lineNumber: 67,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx",
    lineNumber: 66,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx",
    lineNumber: 65,
    columnNumber: 5
  }, this);
};
_s(Insurance, "RWb/qREA4ww3CieqzUwQcU0uKQQ=");
_c = Insurance;
export default Insurance;
var _c;
$RefreshReg$(_c, "Insurance");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Insurance.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0VJLG1CQUdNLGNBSE47MkJBaEVKO0FBQW9CQSxvQkFBZ0IsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMzQyxPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLHVCQUF1QjtBQUU5QixNQUFNQyxZQUFZQSxNQUFNO0FBQUFDLEtBQUE7QUFDdEIsUUFBTSxDQUFDQyxXQUFXQyxZQUFZLElBQUlWLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNXLGdCQUFnQkMsaUJBQWlCLElBQUlaLFNBQVMsRUFBRTtBQUN2RCxRQUFNLENBQUNhLFdBQVdDLFlBQVksSUFBSWQsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2UsWUFBWUMsYUFBYSxJQUFJaEIsU0FBUyxFQUFFO0FBRS9DLFFBQU1pQiw4QkFBOEJBLENBQUNDLE1BQU07QUFDekMsVUFBTSxFQUFFQyxNQUFNLElBQUlELEVBQUVFO0FBQ3BCSixrQkFBY0csS0FBSztBQUFBLEVBQ3JCO0FBRUEsUUFBTSxDQUFDRSxhQUFhQyxjQUFjLElBQUl0QixTQUFTO0FBQUEsSUFDN0N1QixZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFREMsWUFBVSxNQUFNO0FBQ2QsVUFBTUMsaUJBQWlCLFlBQVk7QUFDakMsVUFBSTtBQUNGYixxQkFBYSxJQUFJO0FBQ2pCLGNBQU1jLFdBQVcsTUFBTTNCLElBQUk0QixJQUFJLFlBQVk7QUFFM0MsY0FBTUMsVUFBVUYsU0FBU0csTUFBTUM7QUFFL0IsY0FBTUMsZUFBZUMsTUFBTUMsUUFBUUwsT0FBTyxJQUN0Q0EsVUFDQTtBQUNKcEIscUJBQWF1QixZQUFZO0FBRXpCLGNBQU1HLGdCQUFnQkgsY0FBY0ksSUFBSSxDQUFDQyxPQUFPQyxXQUFXO0FBQUEsVUFDekRDLEtBQUtGLE1BQU1FO0FBQUFBLFVBQ1hDLElBQUlGLFFBQVE7QUFBQSxVQUNaRyxnQkFBZ0JKLE9BQU9JO0FBQUFBLFVBQ3ZCQyxjQUFjTCxNQUFNTSxhQUFhQztBQUFBQSxVQUNqQ0MsYUFBYVIsTUFBTU0sYUFBYUc7QUFBQUEsVUFDaENDLGVBQWVWLE1BQU1XLGVBQWVDLEtBQUssSUFBSSxLQUFLO0FBQUEsUUFDcEQsRUFBRTtBQUNGdEMsMEJBQWtCd0IsYUFBYTtBQUFBLE1BQ2pDLFNBQVNlLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0saUNBQWlDQSxLQUFLO0FBQUEsTUFDdEQsVUFBQztBQUNDckMscUJBQWEsS0FBSztBQUFBLE1BQ3BCO0FBQUEsSUFDRjtBQUNBYSxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUVMLFFBQU0wQixTQUFTO0FBQUEsSUFDYixFQUFFQyxLQUFLLE1BQU1DLFFBQVEsUUFBUTtBQUFBLElBQzFCLEVBQUNELEtBQUssa0JBQWtCQyxRQUFRLGlCQUFnQjtBQUFBLElBQ25ELEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGdCQUFnQjtBQUFBLElBQy9DLEVBQUVELEtBQUssZUFBZUMsUUFBUSxlQUFlO0FBQUEsSUFDN0MsRUFBRUQsS0FBSyxpQkFBaUJDLFFBQVEsaUJBQWlCO0FBQUEsRUFBQztBQUVwRCxTQUNFLG1DQUNFLGlDQUFDLFNBQ0MsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFlBQVk7QUFBQTtBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW1CO0FBQUEsSUFFbkIsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsSUFDZjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTWxDLFlBQVlJO0FBQUFBLFFBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFFBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFFBQ3JCLFNBQVMsTUFDUEYsZUFBZSxDQUFDa0MsVUFBVSxFQUFFLEdBQUdBLE1BQU1qQyxZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsTUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUc7QUFBQSxJQUVILHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSxhQUNiLGlDQUFDLFNBQUksV0FBVSw0Q0FDYixpQ0FBQyxRQUFHLFdBQVUsMEJBQXlCLHlCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdELEtBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE1BQ0NaLGtCQUFrQixDQUFDRSxZQUNwQjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQVUsTUFBTUY7QUFBQUEsVUFBZ0IsU0FBUzBDO0FBQUFBLFVBQ3RDLGtCQUFpQjtBQUFBLFVBQ3JCLGlCQUFnQjtBQUFBO0FBQUEsUUFGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRTJCLElBRzNCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsU0FBUzFDLGVBQWU4QyxVQUFVO0FBQUEsVUFDbEMsTUFBSztBQUFBO0FBQUEsUUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFHdUI7QUFBQSxTQWZ6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0JBO0FBQUEsT0FoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtDQSxLQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUNBLEtBdENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1Q0E7QUFFSjtBQUFFakQsR0FqR0lELFdBQVM7QUFBQW1ELEtBQVRuRDtBQW1HTixlQUFlQTtBQUFVLElBQUFtRDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJhcGkiLCJEYXRhVGFibGUiLCJOYXZiYXIiLCJDaXJjdWxhckxvYWRlciIsIlNldHRpbmdTaWRlYmFyIiwiQ3VzdG9tQWxlcnREaWFsb2ciLCJJbnN1cmFuY2UiLCJfcyIsImluc3VyYW5jZSIsInNldEluc3VyYW5jZSIsImluc3VyYW5jZVRhYmxlIiwic2V0SW5zdWFybmNlVGFibGUiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsIm9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJ1c2VFZmZlY3QiLCJmZXRjaEluc3VyYW5jZSIsInJlc3BvbnNlIiwiZ2V0IiwiZW5xdWlyeSIsImRhdGEiLCJlbnF1aXJlIiwicmVzcG9uc2VEYXRhIiwiQXJyYXkiLCJpc0FycmF5IiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsImdyb3VwIiwiaW5kZXgiLCJfaWQiLCJpZCIsImluc3VyYW5jZV9jb2RlIiwiY3VzdG9tZXJOYW1lIiwiY3VzdG9tZXJfaWQiLCJmdWxsX25hbWUiLCJwaG9uZU51bWJlciIsInBob25lX251bWJlciIsImluc3VyYW5jZVR5cGUiLCJpbnN1cmFuY2VfdHlwZSIsImpvaW4iLCJlcnJvciIsImNvbnNvbGUiLCJjb2x1bW4iLCJrZXkiLCJoZWFkZXIiLCJwcmV2IiwibGVuZ3RoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSW5zdXJhbmNlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBTZXR0aW5nU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NldHRpbmdTaWRlYmFyXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuXHJcbmNvbnN0IEluc3VyYW5jZSA9ICgpID0+IHtcclxuICBjb25zdCBbaW5zdXJhbmNlLCBzZXRJbnN1cmFuY2VdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpbnN1cmFuY2VUYWJsZSwgc2V0SW5zdWFybmNlVGFibGVdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFNlYXJjaFRleHQodmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEluc3VyYW5jZSA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2luc3VyYW5jZVwiKTtcclxuXHJcbiAgICAgICAgY29uc3QgZW5xdWlyeSA9IHJlc3BvbnNlLmRhdGE/LmVucXVpcmVcclxuICAgICAgIFxyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlRGF0YSA9IEFycmF5LmlzQXJyYXkoZW5xdWlyeSlcclxuICAgICAgICAgID8gZW5xdWlyeVxyXG4gICAgICAgICAgOiBbXTtcclxuICAgICAgICBzZXRJbnN1cmFuY2UocmVzcG9uc2VEYXRhKTtcclxuXHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlRGF0YT8ubWFwKChncm91cCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICBfaWQ6IGdyb3VwLl9pZCxcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBpbnN1cmFuY2VfY29kZTogZ3JvdXA/Lmluc3VyYW5jZV9jb2RlLFxyXG4gICAgICAgICAgY3VzdG9tZXJOYW1lOiBncm91cC5jdXN0b21lcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgcGhvbmVOdW1iZXI6IGdyb3VwLmN1c3RvbWVyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICBpbnN1cmFuY2VUeXBlOiBncm91cC5pbnN1cmFuY2VfdHlwZS5qb2luKFwiLCBcIikgfHwgW10sXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldEluc3Vhcm5jZVRhYmxlKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJmYWlsZWQgdG8gbG9hZCBpbnN1cmFuY2UgZGF0YVwiLCBlcnJvcik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoSW5zdXJhbmNlKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBjb2x1bW4gPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wgTm9cIiB9LFxyXG4gICAgICAge2tleTogXCJpbnN1cmFuY2VfY29kZVwiLCBoZWFkZXI6IFwiSW5zdXJhbmNlIENvZGVcIn0sXHJcbiAgICB7IGtleTogXCJjdXN0b21lck5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVOdW1iZXJcIiwgaGVhZGVyOiBcIlBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJpbnN1cmFuY2VUeXBlXCIsIGhlYWRlcjogXCJJbnN1cmFuY2UgVHlwZVwiIH0sXHJcbiAgXTtcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPFNldHRpbmdTaWRlYmFyIC8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5JbnN1cmFuY2U8L2gxPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge2luc3VyYW5jZVRhYmxlICYmICFpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgICAgIDxEYXRhVGFibGUgZGF0YT17aW5zdXJhbmNlVGFibGV9IGNvbHVtbnM9e2NvbHVtbn1cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkRmlsZU5hbWU9XCJJbnN1cmFuY2UuY3N2XCJcclxuICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiSW5zdXJhbmNlXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgIGlzTG9hZGluZz17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgIGZhaWx1cmU9e2luc3VyYW5jZVRhYmxlLmxlbmd0aCA8PSAwfVxyXG4gICAgICAgICAgICAgIGRhdGE9XCJpbnN1cmFuY2UgZGF0YVwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICBcclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICBcclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSW5zdXJhbmNlO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvSW5zdXJhbmNlLmpzeCJ9