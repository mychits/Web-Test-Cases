import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/AuctionFilterReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Dropdown, Modal as AntModal, DatePicker, Tag, Switch, Tooltip, Empty } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { FaGavel, FaEye } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import __vite__cjsImport13_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport13_dayjs.__esModule ? __vite__cjsImport13_dayjs.default : __vite__cjsImport13_dayjs;
const { RangePicker } = DatePicker;
const AuctionPage = () => {
  _s();
  const [auctions, setAuctions] = useState([]);
  const [groups, setGroups] = useState([]);
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [viewLoader, setViewLoader] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [filters, setFilters] = useState({
    groupId: "",
    userId: "",
    auctiontype: "",
    prized: false,
    startDate: "",
    endDate: ""
  });
  const [showModalView, setShowModalView] = useState(false);
  const [currentAuction, setCurrentAuction] = useState(null);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "",
    type: "info"
  });
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "auction_date", header: "Auction Date" },
    { key: "user_name", header: "Winner Name" },
    { key: "group_name", header: "Group Name" },
    { key: "ticket", header: "Ticket" },
    { key: "totalPaidAmount", header: "Total Paid Amount" },
    { key: "totalPayable", header: "Total Payable" },
    { key: "balance", header: "Balance" },
    { key: "win_amount", header: "Winning Amount" },
    { key: "bid_amount", header: "Bid Amount" },
    { key: "dividend", header: "Dividend" },
    { key: "auction_type", header: "Type" },
    { key: "prized", header: "Prized" },
    { key: "action", header: "Action" }
  ];
  const exportColumns = [
    { key: "id", header: "SL. NO" },
    { key: "auction_date", header: "Auction Date" },
    { key: "group_name", header: "Group Name" },
    { key: "user_name", header: "Winner Name" },
    { key: "ticket", header: "Ticket" },
    { key: "totalPayableRaw", header: "Total Payable" },
    { key: "totalPaidAmountRaw", header: "Total Paid Amount" },
    { key: "balanceRaw", header: "Balance" },
    { key: "win_amount_raw", header: "Winning Amount" },
    { key: "bid_amount", header: "Bid Amount" },
    { key: "dividend_raw", header: "Dividend" },
    { key: "auction_type_raw", header: "Type" },
    { key: "prized_raw", header: "Prized" },
    { key: "action", header: "Action" }
  ];
  const fetchInitialData = async () => {
    try {
      const [groupRes, userRes] = await Promise.all(
        [
          api.get("/group/get-group-admin"),
          api.get("user/verified")
        ]
      );
      setGroups(groupRes.data || []);
      setUsers(userRes.data?.data || []);
    } catch (error) {
      console.error("Error fetching initial data", error);
    }
  };
  const fetchFilteredAuctions = async () => {
    setIsLoading(true);
    try {
      const params = {};
      if (filters.groupId) params.groupId = filters.groupId;
      if (filters.userId) params.userId = filters.userId;
      if (filters.auctiontype) params.auctiontype = filters.auctiontype;
      if (filters.prized) params.prized = filters.prized;
      if (filters.startDate) params.startDate = filters.startDate;
      if (filters.endDate) params.endDate = filters.endDate;
      const response = await api.get("/auction", { params });
      if (response.data && response.data?.data) {
        const formattedData = response.data?.data.map((item, index) => {
          const totalPaid = item?.payments?.totalPaidAmount || 0;
          const totalPayable = item?.auctions?.to_be_paid_amount || 0;
          return {
            id: index + 1,
            auction_date: item.auction_date ? dayjs(item?.auction_date).format("YYYY-MM-DD") : "N/A",
            group_name: item.group_id?.group_name || "N/A",
            user_name: item.user_id?.full_name || "N/A",
            ticket: item?.ticket,
            balance: `${item.auctions?.balance?.toLocaleString("en-IN")}`,
            balanceRaw: item.auctions?.balance,
            totalPaidAmount: `${totalPaid?.toLocaleString("en-IN") || 0}`,
            totalPaidAmountRaw: totalPaid || 0,
            totalPayable: `${totalPayable?.toLocaleString("en-IN") || 0}`,
            totalPayableRaw: totalPayable || 0,
            win_amount: `₹${item.win_amount?.toLocaleString()}`,
            win_amount_raw: item?.win_amount,
            dividend: `₹${item?.divident?.toLocaleString()}`,
            dividend_raw: item?.divident,
            auction_type: /* @__PURE__ */ jsxDEV(Tag, { color: item.auction_type === "free" ? "purple" : "violet", children: item.auction_type?.toUpperCase() }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
              lineNumber: 128,
              columnNumber: 27
            }, this),
            auction_type_raw: item?.auction_type,
            prized: /* @__PURE__ */ jsxDEV(Tag, { color: item?.isPrized === "true" ? "green" : "red", children: item?.isPrized ? "Yes" : "No" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
              lineNumber: 130,
              columnNumber: 21
            }, this),
            bid_amount: parseInt(item.divident) + parseInt(item.commission),
            prized_raw: item?.isPrized ? "Yes" : "No",
            action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center", children: /* @__PURE__ */ jsxDEV(Tooltip, { title: "View Details", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => handleViewAuction(item),
                className: "p-2 bg-violet-50 text-violet-600 rounded-full hover:bg-violet-100",
                children: /* @__PURE__ */ jsxDEV(FaEye, {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
                  lineNumber: 140,
                  columnNumber: 21
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
                lineNumber: 136,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
              lineNumber: 135,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
              lineNumber: 134,
              columnNumber: 13
            }, this)
          };
        });
        console.log(formattedData);
        setAuctions(formattedData);
      }
    } catch (error) {
      setAuctions([]);
      console.error("Error fetching auctions:", error);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchInitialData();
  }, []);
  useEffect(() => {
    fetchFilteredAuctions();
  }, [filters]);
  const handleViewAuction = (auction) => {
    setCurrentAuction(auction);
    setShowModalView(true);
  };
  const onDateRangeChange = (dates) => {
    if (dates) {
      setFilters((prev) => ({
        ...prev,
        startDate: dates[0].format("YYYY-MM-DD"),
        endDate: dates[1].format("YYYY-MM-DD")
      }));
    } else {
      setFilters((prev) => ({ ...prev, startDate: "", endDate: "" }));
    }
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
    /* @__PURE__ */ jsxDEV(
      CustomAlert,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
        lineNumber: 189,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 bg-gray-50 min-h-screen", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-6", children: /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-bold flex items-center gap-2", children: [
        /* @__PURE__ */ jsxDEV(FaGavel, { className: "text-violet-900" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
          lineNumber: 198,
          columnNumber: 13
        }, this),
        " Auction Management"
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
        lineNumber: 197,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
        lineNumber: 196,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-xl shadow-sm mb-8 border border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Filter by Group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 206,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              placeholder: "All Groups",
              className: "w-full h-10 mt-1",
              allowClear: true,
              onChange: (val) => setFilters((prev) => ({ ...prev, groupId: val })),
              children: groups.map(
                (g) => /* @__PURE__ */ jsxDEV(Select.Option, { value: g._id, children: g.group_name }, g._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
                  lineNumber: 214,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
              lineNumber: 207,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
          lineNumber: 205,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Filter by Winner" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 220,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              placeholder: "All Users",
              className: "w-full h-10 mt-1",
              allowClear: true,
              showSearch: true,
              filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
              onChange: (val) => setFilters((prev) => ({ ...prev, userId: val })),
              children: users.map(
                (u) => /* @__PURE__ */ jsxDEV(Select.Option, { value: u._id, children: u.full_name }, u._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
                  lineNumber: 230,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
              lineNumber: 221,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
          lineNumber: 219,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Auction Date Range" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 236,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(RangePicker, { className: "w-full h-10 mt-1", onChange: onDateRangeChange }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 237,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
          lineNumber: 235,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-grow", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Auction Type" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
              lineNumber: 243,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                placeholder: "Type",
                className: "w-full h-10 mt-1",
                allowClear: true,
                onChange: (val) => setFilters((prev) => ({ ...prev, auctiontype: val })),
                children: [
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "normal", children: "Normal" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
                    lineNumber: 250,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(Select.Option, { value: "free", children: "Free" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
                    lineNumber: 251,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
                lineNumber: 244,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 242,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "text-xs font-bold text-gray-500 uppercase", children: "Prized" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
              lineNumber: 255,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Switch,
              {
                className: "mt-3",
                onChange: (val) => setFilters((prev) => ({ ...prev, prized: val }))
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
                lineNumber: 256,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 254,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
          lineNumber: 241,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
        lineNumber: 203,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
        lineNumber: 202,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-xl shadow-sm p-4", children: isLoading ? /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true, data: "Auctions" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
        lineNumber: 268,
        columnNumber: 11
      }, this) : auctions.length <= 0 ? /* @__PURE__ */ jsxDEV(Empty, { description: "No Auction Data Found" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
        lineNumber: 269,
        columnNumber: 34
      }, this) : /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          data: auctions,
          columns,
          exportCols: exportColumns,
          exportedPdfName: "Auction_Report",
          exportedFileName: "Auction Filter Report.csv"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
          lineNumber: 270,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
        lineNumber: 266,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
      lineNumber: 195,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      AntModal,
      {
        title: /* @__PURE__ */ jsxDEV("div", { className: "text-xl font-bold border-b pb-2", children: "Auction Detailed Report" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
          lineNumber: 282,
          columnNumber: 16
        }, this),
        open: showModalView,
        onCancel: () => setShowModalView(false),
        footer: null,
        width: 600,
        children: currentAuction && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-y-4 py-4", children: [
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Group Name", value: currentAuction.group_id?.group_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 290,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Winner", value: currentAuction.user_id?.full_name }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 291,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Ticket No", value: currentAuction.ticket }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 292,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Auction Date", value: dayjs(currentAuction.auction_date).format("DD-MM-YYYY") }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 293,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Winning Amount", value: `₹${currentAuction.win_amount}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 294,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Commission", value: `₹${currentAuction.commission}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 295,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Total Dividend", value: `₹${currentAuction.divident}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 296,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Dividend Per Head", value: `₹${currentAuction.divident_head}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 297,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Payable Amount", value: `₹${currentAuction.payable}` }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 298,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(DetailItem, { label: "Next Auction Date", value: currentAuction.next_date }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
            lineNumber: 299,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            DetailItem,
            {
              label: "Prized Status",
              value: /* @__PURE__ */ jsxDEV(Tag, { color: currentAuction.isPrized ? "green" : "red", children: currentAuction.isPrized ? "YES" : "NO" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
                lineNumber: 302,
                columnNumber: 20
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
              lineNumber: 300,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
          lineNumber: 289,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
        lineNumber: 281,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
    lineNumber: 187,
    columnNumber: 5
  }, this);
};
_s(AuctionPage, "VlhVm4HbVuMQ4OAx73N5ydfkHWA=");
_c = AuctionPage;
const DetailItem = ({ label, value }) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col border-b border-gray-50 pb-2 mr-4", children: [
  /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold text-gray-400 uppercase tracking-wider", children: label }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
    lineNumber: 313,
    columnNumber: 5
  }, this),
  /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: value || "N/A" }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
    lineNumber: 314,
    columnNumber: 5
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx",
  lineNumber: 312,
  columnNumber: 1
}, this);
_c2 = DetailItem;
export default AuctionPage;
var _c, _c2;
$RefreshReg$(_c, "AuctionPage");
$RefreshReg$(_c2, "DetailItem");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/AuctionFilterReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0gwQjsyQkEvSDFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxRQUFRQyxVQUFVQyxTQUFTQyxVQUFVQyxZQUFZQyxLQUFLQyxRQUFRQyxTQUFTQyxhQUFhO0FBQzdGLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxTQUFTQyxhQUFhO0FBQy9CLE9BQU9DLFdBQVc7QUFFbEIsTUFBTSxFQUFFQyxZQUFZLElBQUlUO0FBRXhCLE1BQU1VLGNBQWNBLE1BQU07QUFBQUMsS0FBQTtBQUN4QixRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSXhCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUN5QixRQUFRQyxTQUFTLElBQUkxQixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDMkIsT0FBT0MsUUFBUSxJQUFJNUIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzZCLFdBQVdDLFlBQVksSUFBSTlCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMrQixZQUFZQyxhQUFhLElBQUloQyxTQUFTLEtBQUs7QUFDbEQsUUFBTSxDQUFDaUMsWUFBWUMsYUFBYSxJQUFJbEMsU0FBUyxFQUFFO0FBRS9DLFFBQU0sQ0FBQ21DLFNBQVNDLFVBQVUsSUFBSXBDLFNBQVM7QUFBQSxJQUNyQ3FDLFNBQVM7QUFBQSxJQUNUQyxRQUFRO0FBQUEsSUFDUkMsYUFBYTtBQUFBLElBQ2JDLFFBQVE7QUFBQSxJQUNSQyxXQUFXO0FBQUEsSUFDWEMsU0FBUztBQUFBLEVBQ1gsQ0FBQztBQUVELFFBQU0sQ0FBQ0MsZUFBZUMsZ0JBQWdCLElBQUk1QyxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDNkMsZ0JBQWdCQyxpQkFBaUIsSUFBSTlDLFNBQVMsSUFBSTtBQUV6RCxRQUFNLENBQUMrQyxhQUFhQyxjQUFjLElBQUloRCxTQUFTO0FBQUEsSUFDN0NpRCxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNQyxVQUFVO0FBQUEsSUFDZCxFQUFFQyxLQUFLLE1BQU1DLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVELEtBQUssZ0JBQWdCQyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLGFBQWFDLFFBQVEsY0FBYztBQUFBLElBQzFDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFRCxLQUFLLG1CQUFtQkMsUUFBUSxvQkFBb0I7QUFBQSxJQUN0RCxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxnQkFBZ0I7QUFBQSxJQUMvQyxFQUFFRCxLQUFLLFdBQVdDLFFBQVEsVUFBVTtBQUFBLElBQ3BDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxpQkFBaUI7QUFBQSxJQUM5QyxFQUFFRCxLQUFLLGNBQWNDLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVELEtBQUssWUFBWUMsUUFBUSxXQUFXO0FBQUEsSUFDdEMsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsT0FBTztBQUFBLElBQ3RDLEVBQUVELEtBQUssVUFBVUMsUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBRXJDLFFBQU1DLGdCQUFnQjtBQUFBLElBRXBCLEVBQUVGLEtBQUssTUFBTUMsUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUQsS0FBSyxnQkFBZ0JDLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxhQUFhO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxhQUFhQyxRQUFRLGNBQWM7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLFVBQVVDLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVELEtBQUssbUJBQW1CQyxRQUFRLGdCQUFnQjtBQUFBLElBQ2xELEVBQUVELEtBQUssc0JBQXNCQyxRQUFRLG9CQUFvQjtBQUFBLElBQ3pELEVBQUVELEtBQUssY0FBY0MsUUFBUSxVQUFVO0FBQUEsSUFDdkMsRUFBRUQsS0FBSyxrQkFBa0JDLFFBQVEsaUJBQWlCO0FBQUEsSUFDbEQsRUFBRUQsS0FBSyxjQUFjQyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFRCxLQUFLLGdCQUFnQkMsUUFBUSxXQUFXO0FBQUEsSUFFMUMsRUFBRUQsS0FBSyxvQkFBb0JDLFFBQVEsT0FBTztBQUFBLElBQzFDLEVBQUVELEtBQUssY0FBY0MsUUFBUSxTQUFTO0FBQUEsSUFDdEMsRUFBRUQsS0FBSyxVQUFVQyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1FLG1CQUFtQixZQUFZO0FBQ25DLFFBQUk7QUFDRixZQUFNLENBQUNDLFVBQVVDLE9BQU8sSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDNUMxRCxJQUFJMkQsSUFBSSx3QkFBd0I7QUFBQSxVQUNoQzNELElBQUkyRCxJQUFJLGVBQWU7QUFBQSxRQUFDO0FBQUEsTUFDekI7QUFDRG5DLGdCQUFVK0IsU0FBU0ssUUFBUSxFQUFFO0FBQzdCbEMsZUFBUzhCLFFBQVFJLE1BQU1BLFFBQVEsRUFBRTtBQUFBLElBQ25DLFNBQVNDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSwrQkFBK0JBLEtBQUs7QUFBQSxJQUNwRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNRSx3QkFBd0IsWUFBWTtBQUN4Q25DLGlCQUFhLElBQUk7QUFDakIsUUFBSTtBQUNGLFlBQU1vQyxTQUFTLENBQUM7QUFDaEIsVUFBSS9CLFFBQVFFLFFBQVM2QixRQUFPN0IsVUFBVUYsUUFBUUU7QUFDOUMsVUFBSUYsUUFBUUcsT0FBUTRCLFFBQU81QixTQUFTSCxRQUFRRztBQUM1QyxVQUFJSCxRQUFRSSxZQUFhMkIsUUFBTzNCLGNBQWNKLFFBQVFJO0FBQ3RELFVBQUlKLFFBQVFLLE9BQVEwQixRQUFPMUIsU0FBU0wsUUFBUUs7QUFDNUMsVUFBSUwsUUFBUU0sVUFBV3lCLFFBQU96QixZQUFZTixRQUFRTTtBQUNsRCxVQUFJTixRQUFRTyxRQUFTd0IsUUFBT3hCLFVBQVVQLFFBQVFPO0FBRTlDLFlBQU15QixXQUFXLE1BQU1qRSxJQUFJMkQsSUFBSSxZQUFZLEVBQUVLLE9BQU8sQ0FBQztBQUVyRCxVQUFJQyxTQUFTTCxRQUFRSyxTQUFTTCxNQUFNQSxNQUFNO0FBQ3hDLGNBQU1NLGdCQUFnQkQsU0FBU0wsTUFBTUEsS0FBS08sSUFBSSxDQUFDQyxNQUFNQyxVQUFVO0FBRTdELGdCQUFNQyxZQUFZRixNQUFNRyxVQUFVQyxtQkFBbUI7QUFDckQsZ0JBQU1DLGVBQWVMLE1BQU0vQyxVQUFVcUQscUJBQXFCO0FBRzFELGlCQUFRO0FBQUEsWUFHTkMsSUFBSU4sUUFBUTtBQUFBLFlBQ1pPLGNBQWNSLEtBQUtRLGVBQWUzRCxNQUFNbUQsTUFBTVEsWUFBWSxFQUFFQyxPQUFPLFlBQVksSUFBSTtBQUFBLFlBQ25GQyxZQUFZVixLQUFLVyxVQUFVRCxjQUFjO0FBQUEsWUFDekNFLFdBQVdaLEtBQUthLFNBQVNDLGFBQWE7QUFBQSxZQUN0Q0MsUUFBUWYsTUFBTWU7QUFBQUEsWUFDZEMsU0FBUyxHQUFHaEIsS0FBSy9DLFVBQVUrRCxTQUFTQyxlQUFlLE9BQU8sQ0FBQztBQUFBLFlBQzNEQyxZQUFZbEIsS0FBSy9DLFVBQVUrRDtBQUFBQSxZQUMzQlosaUJBQWlCLEdBQUdGLFdBQVdlLGVBQWUsT0FBTyxLQUFLLENBQUM7QUFBQSxZQUMzREUsb0JBQW9CakIsYUFBYTtBQUFBLFlBQ2pDRyxjQUFjLEdBQUdBLGNBQWNZLGVBQWUsT0FBTyxLQUFLLENBQUM7QUFBQSxZQUMzREcsaUJBQWlCZixnQkFBZ0I7QUFBQSxZQUNqQ2dCLFlBQVksSUFBSXJCLEtBQUtxQixZQUFZSixlQUFlLENBQUM7QUFBQSxZQUNqREssZ0JBQWdCdEIsTUFBTXFCO0FBQUFBLFlBQ3RCRSxVQUFVLElBQUl2QixNQUFNd0IsVUFBVVAsZUFBZSxDQUFDO0FBQUEsWUFDOUNRLGNBQWN6QixNQUFNd0I7QUFBQUEsWUFDcEJFLGNBQWMsdUJBQUMsT0FBSSxPQUFPMUIsS0FBSzBCLGlCQUFpQixTQUFTLFdBQVcsVUFBVzFCLGVBQUswQixjQUFjQyxZQUFZLEtBQWhHO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWtHO0FBQUEsWUFDaEhDLGtCQUFrQjVCLE1BQU0wQjtBQUFBQSxZQUN4QnhELFFBQVEsdUJBQUMsT0FBSSxPQUFPOEIsTUFBTTZCLGFBQWEsU0FBUyxVQUFVLE9BQVE3QixnQkFBTTZCLFdBQVcsUUFBUSxRQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF3RjtBQUFBLFlBQ2hHQyxZQUFZQyxTQUFTL0IsS0FBS3dCLFFBQVEsSUFBSU8sU0FBUy9CLEtBQUtnQyxVQUFVO0FBQUEsWUFDOURDLFlBQVlqQyxNQUFNNkIsV0FBVyxRQUFRO0FBQUEsWUFDckNLLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLHVCQUNiLGlDQUFDLFdBQVEsT0FBTSxnQkFDYjtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVMsTUFBTUMsa0JBQWtCbkMsSUFBSTtBQUFBLGdCQUNyQyxXQUFVO0FBQUEsZ0JBRVYsaUNBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFNO0FBQUE7QUFBQSxjQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBU0E7QUFBQSxVQUVKO0FBQUEsUUFJRixDQUFDO0FBQ0ROLGdCQUFRMEMsSUFBSXRDLGFBQWE7QUFDekI1QyxvQkFBWTRDLGFBQWE7QUFBQSxNQUMzQjtBQUFBLElBQ0YsU0FBU0wsT0FBTztBQUNkdkMsa0JBQVksRUFBRTtBQUNkd0MsY0FBUUQsTUFBTSw0QkFBNEJBLEtBQUs7QUFBQSxJQUNqRCxVQUFDO0FBQ0NqQyxtQkFBYSxLQUFLO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEvQixZQUFVLE1BQU07QUFDZHlELHFCQUFpQjtBQUFBLEVBQ25CLEdBQUcsRUFBRTtBQUVMekQsWUFBVSxNQUFNO0FBQ2RrRSwwQkFBc0I7QUFBQSxFQUN4QixHQUFHLENBQUM5QixPQUFPLENBQUM7QUFFWixRQUFNc0Usb0JBQW9CQSxDQUFDRSxZQUFZO0FBQ3JDN0Qsc0JBQWtCNkQsT0FBTztBQUN6Qi9ELHFCQUFpQixJQUFJO0FBQUEsRUFDdkI7QUFFQSxRQUFNZ0Usb0JBQW9CQSxDQUFDQyxVQUFVO0FBQ25DLFFBQUlBLE9BQU87QUFDVHpFLGlCQUFXLENBQUEwRSxVQUFTO0FBQUEsUUFDbEIsR0FBR0E7QUFBQUEsUUFDSHJFLFdBQVdvRSxNQUFNLENBQUMsRUFBRTlCLE9BQU8sWUFBWTtBQUFBLFFBQ3ZDckMsU0FBU21FLE1BQU0sQ0FBQyxFQUFFOUIsT0FBTyxZQUFZO0FBQUEsTUFDdkMsRUFBRTtBQUFBLElBQ0osT0FBTztBQUNMM0MsaUJBQVcsQ0FBQTBFLFVBQVMsRUFBRSxHQUFHQSxNQUFNckUsV0FBVyxJQUFJQyxTQUFTLEdBQUcsRUFBRTtBQUFBLElBQzlEO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFVBRWI7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsTUFBTUssWUFBWUk7QUFBQUEsUUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsUUFDdkIsU0FBU0YsWUFBWUc7QUFBQUE7QUFBQUEsTUFIdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRytCO0FBQUEsSUFHL0IsdUJBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFFBQUcsV0FBVSw4Q0FDWjtBQUFBLCtCQUFDLFdBQVEsV0FBVSxxQkFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQztBQUFBLFFBQUc7QUFBQSxXQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpRUFDYixpQ0FBQyxTQUFJLFdBQVUsd0RBRWI7QUFBQSwrQkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDZDQUE0QywrQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEU7QUFBQSxVQUM1RTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsYUFBWTtBQUFBLGNBQ1osV0FBVTtBQUFBLGNBQ1Y7QUFBQSxjQUNBLFVBQVUsQ0FBQzZELFFBQVEzRSxXQUFXLENBQUEwRSxVQUFTLEVBQUUsR0FBR0EsTUFBTXpFLFNBQVMwRSxJQUFJLEVBQUU7QUFBQSxjQUVoRXRGLGlCQUFPNEM7QUFBQUEsZ0JBQUksQ0FBQTJDLE1BQ1YsdUJBQUMsT0FBTyxRQUFQLEVBQTBCLE9BQU9BLEVBQUVDLEtBQU1ELFlBQUVoQyxjQUF4QmdDLEVBQUVDLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXVEO0FBQUEsY0FDeEQ7QUFBQTtBQUFBLFlBUkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxhQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFFBRUEsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSw2Q0FBNEMsZ0NBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTZFO0FBQUEsVUFDN0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGFBQVk7QUFBQSxjQUNaLFdBQVU7QUFBQSxjQUNWO0FBQUEsY0FDQTtBQUFBLGNBQ0EsY0FBYyxDQUFDQyxPQUFPQyxXQUFXQSxPQUFPQyxTQUFTQyxZQUFZLEVBQUVDLFNBQVNKLE1BQU1HLFlBQVksQ0FBQztBQUFBLGNBQzNGLFVBQVUsQ0FBQ04sUUFBUTNFLFdBQVcsQ0FBQTBFLFVBQVMsRUFBRSxHQUFHQSxNQUFNeEUsUUFBUXlFLElBQUksRUFBRTtBQUFBLGNBRS9EcEYsZ0JBQU0wQztBQUFBQSxnQkFBSSxDQUFBa0QsTUFDVCx1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsRUFBRU4sS0FBTU0sWUFBRW5DLGFBQXhCbUMsRUFBRU4sS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBc0Q7QUFBQSxjQUN2RDtBQUFBO0FBQUEsWUFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFXQTtBQUFBLGFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWNBO0FBQUEsUUFFQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLDZDQUE0QyxrQ0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBK0U7QUFBQSxVQUMvRSx1QkFBQyxlQUFZLFdBQVUsb0JBQW1CLFVBQVVMLHFCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLGFBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLG1DQUFDLFdBQU0sV0FBVSw2Q0FBNEMsNEJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXlFO0FBQUEsWUFDekU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxhQUFZO0FBQUEsZ0JBQ1osV0FBVTtBQUFBLGdCQUNWO0FBQUEsZ0JBQ0EsVUFBVSxDQUFDRyxRQUFRM0UsV0FBVyxDQUFBMEUsVUFBUyxFQUFFLEdBQUdBLE1BQU12RSxhQUFhd0UsSUFBSSxFQUFFO0FBQUEsZ0JBRXJFO0FBQUEseUNBQUMsT0FBTyxRQUFQLEVBQWMsT0FBTSxVQUFTLHNCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFvQztBQUFBLGtCQUNwQyx1QkFBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLFFBQU8sb0JBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUE7QUFBQTtBQUFBLGNBUGxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsZUFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVdBO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQSxtQ0FBQyxXQUFNLFdBQVUsNkNBQTRDLHNCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtRTtBQUFBLFlBQ25FO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLFVBQVUsQ0FBQ0EsUUFBUTNFLFdBQVcsQ0FBQTBFLFVBQVMsRUFBRSxHQUFHQSxNQUFNdEUsUUFBUXVFLElBQUksRUFBRTtBQUFBO0FBQUEsY0FGbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBRW9FO0FBQUEsZUFKdEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNQTtBQUFBLGFBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFvQkE7QUFBQSxXQTFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNERBLEtBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4REE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxxQ0FDWmxGLHNCQUNDLHVCQUFDLGtCQUFlLFdBQVcsTUFBTSxNQUFLLGNBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0QsSUFDOUNOLFNBQVNpRyxVQUFVLElBQUksdUJBQUMsU0FBTSxhQUFZLDJCQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBDLElBQ25FO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNakc7QUFBQUEsVUFDTjtBQUFBLFVBQ0EsWUFBWWdDO0FBQUFBLFVBQ1osaUJBQWdCO0FBQUEsVUFDaEIsa0JBQWlCO0FBQUE7QUFBQSxRQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLOEMsS0FUbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsU0FuRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9GQTtBQUFBLElBRUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLE9BQU8sdUJBQUMsU0FBSSxXQUFVLG1DQUFrQyx1Q0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RTtBQUFBLFFBQy9FLE1BQU1aO0FBQUFBLFFBQ04sVUFBVSxNQUFNQyxpQkFBaUIsS0FBSztBQUFBLFFBQ3RDLFFBQVE7QUFBQSxRQUNSLE9BQU87QUFBQSxRQUVOQyw0QkFDQyx1QkFBQyxTQUFJLFdBQVUsaUNBQ2I7QUFBQSxpQ0FBQyxjQUFXLE9BQU0sY0FBYSxPQUFPQSxlQUFlb0MsVUFBVUQsY0FBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxVQUMxRSx1QkFBQyxjQUFXLE9BQU0sVUFBUyxPQUFPbkMsZUFBZXNDLFNBQVNDLGFBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQW9FO0FBQUEsVUFDcEUsdUJBQUMsY0FBVyxPQUFNLGFBQVksT0FBT3ZDLGVBQWV3QyxVQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEyRDtBQUFBLFVBQzNELHVCQUFDLGNBQVcsT0FBTSxnQkFBZSxPQUFPbEUsTUFBTTBCLGVBQWVpQyxZQUFZLEVBQUVDLE9BQU8sWUFBWSxLQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRztBQUFBLFVBQ2hHLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsT0FBTyxJQUFJbEMsZUFBZThDLFVBQVUsTUFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBMEU7QUFBQSxVQUMxRSx1QkFBQyxjQUFXLE9BQU0sY0FBYSxPQUFPLElBQUk5QyxlQUFleUQsVUFBVSxNQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLFVBQ3RFLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsT0FBTyxJQUFJekQsZUFBZWlELFFBQVEsTUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0U7QUFBQSxVQUN4RSx1QkFBQyxjQUFXLE9BQU0scUJBQW9CLE9BQU8sSUFBSWpELGVBQWU0RSxhQUFhLE1BQTdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWdGO0FBQUEsVUFDaEYsdUJBQUMsY0FBVyxPQUFNLGtCQUFpQixPQUFPLElBQUk1RSxlQUFlNkUsT0FBTyxNQUFwRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RTtBQUFBLFVBQ3ZFLHVCQUFDLGNBQVcsT0FBTSxxQkFBb0IsT0FBTzdFLGVBQWU4RSxhQUE1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFzRTtBQUFBLFVBQ3RFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixPQUFPLHVCQUFDLE9BQUksT0FBTzlFLGVBQWVzRCxXQUFXLFVBQVUsT0FBUXRELHlCQUFlc0QsV0FBVyxRQUFRLFFBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStGO0FBQUE7QUFBQSxZQUZ4RztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFFK0c7QUFBQSxhQWJqSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQTtBQUFBLE1BdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXlCQTtBQUFBLE9BdkhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3SEE7QUFFSjtBQUFFN0UsR0FyU0lELGFBQVc7QUFBQXVHLEtBQVh2RztBQXVTTixNQUFNd0csYUFBYUEsQ0FBQyxFQUFFQyxPQUFPQyxNQUFNLE1BQ2pDLHVCQUFDLFNBQUksV0FBVSxtREFDYjtBQUFBLHlCQUFDLFVBQUssV0FBVSxnRUFBZ0VELG1CQUFoRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNGO0FBQUEsRUFDdEYsdUJBQUMsVUFBSyxXQUFVLHVDQUF1Q0MsbUJBQVMsU0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFzRTtBQUFBLEtBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FHQTtBQUNBQyxNQUxJSDtBQU9OLGVBQWV4RztBQUFZLElBQUF1RyxJQUFBSTtBQUFBQyxhQUFBTCxJQUFBO0FBQUFLLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsIlNpZGViYXIiLCJhcGkiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIkNpcmN1bGFyTG9hZGVyIiwiTmF2YmFyIiwiU2VsZWN0IiwiRHJvcGRvd24iLCJNb2RhbCIsIkFudE1vZGFsIiwiRGF0ZVBpY2tlciIsIlRhZyIsIlN3aXRjaCIsIlRvb2x0aXAiLCJFbXB0eSIsIklvTWRNb3JlIiwiRmFHYXZlbCIsIkZhRXllIiwiZGF5anMiLCJSYW5nZVBpY2tlciIsIkF1Y3Rpb25QYWdlIiwiX3MiLCJhdWN0aW9ucyIsInNldEF1Y3Rpb25zIiwiZ3JvdXBzIiwic2V0R3JvdXBzIiwidXNlcnMiLCJzZXRVc2VycyIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsInZpZXdMb2FkZXIiLCJzZXRWaWV3TG9hZGVyIiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJmaWx0ZXJzIiwic2V0RmlsdGVycyIsImdyb3VwSWQiLCJ1c2VySWQiLCJhdWN0aW9udHlwZSIsInByaXplZCIsInN0YXJ0RGF0ZSIsImVuZERhdGUiLCJzaG93TW9kYWxWaWV3Iiwic2V0U2hvd01vZGFsVmlldyIsImN1cnJlbnRBdWN0aW9uIiwic2V0Q3VycmVudEF1Y3Rpb24iLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsIm1lc3NhZ2UiLCJ0eXBlIiwiY29sdW1ucyIsImtleSIsImhlYWRlciIsImV4cG9ydENvbHVtbnMiLCJmZXRjaEluaXRpYWxEYXRhIiwiZ3JvdXBSZXMiLCJ1c2VyUmVzIiwiUHJvbWlzZSIsImFsbCIsImdldCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaEZpbHRlcmVkQXVjdGlvbnMiLCJwYXJhbXMiLCJyZXNwb25zZSIsImZvcm1hdHRlZERhdGEiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJ0b3RhbFBhaWQiLCJwYXltZW50cyIsInRvdGFsUGFpZEFtb3VudCIsInRvdGFsUGF5YWJsZSIsInRvX2JlX3BhaWRfYW1vdW50IiwiaWQiLCJhdWN0aW9uX2RhdGUiLCJmb3JtYXQiLCJncm91cF9uYW1lIiwiZ3JvdXBfaWQiLCJ1c2VyX25hbWUiLCJ1c2VyX2lkIiwiZnVsbF9uYW1lIiwidGlja2V0IiwiYmFsYW5jZSIsInRvTG9jYWxlU3RyaW5nIiwiYmFsYW5jZVJhdyIsInRvdGFsUGFpZEFtb3VudFJhdyIsInRvdGFsUGF5YWJsZVJhdyIsIndpbl9hbW91bnQiLCJ3aW5fYW1vdW50X3JhdyIsImRpdmlkZW5kIiwiZGl2aWRlbnQiLCJkaXZpZGVuZF9yYXciLCJhdWN0aW9uX3R5cGUiLCJ0b1VwcGVyQ2FzZSIsImF1Y3Rpb25fdHlwZV9yYXciLCJpc1ByaXplZCIsImJpZF9hbW91bnQiLCJwYXJzZUludCIsImNvbW1pc3Npb24iLCJwcml6ZWRfcmF3IiwiYWN0aW9uIiwiaGFuZGxlVmlld0F1Y3Rpb24iLCJsb2ciLCJhdWN0aW9uIiwib25EYXRlUmFuZ2VDaGFuZ2UiLCJkYXRlcyIsInByZXYiLCJ2YWwiLCJnIiwiX2lkIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvTG93ZXJDYXNlIiwiaW5jbHVkZXMiLCJ1IiwibGVuZ3RoIiwiZGl2aWRlbnRfaGVhZCIsInBheWFibGUiLCJuZXh0X2RhdGUiLCJfYyIsIkRldGFpbEl0ZW0iLCJsYWJlbCIsInZhbHVlIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkF1Y3Rpb25GaWx0ZXJSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbIi8qIGVzbGludC1kaXNhYmxlIG5vLXVudXNlZC12YXJzICovXHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNpZGViYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9TaWRlYmFyXCI7XHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBEcm9wZG93biwgTW9kYWwgYXMgQW50TW9kYWwsIERhdGVQaWNrZXIsIFRhZywgU3dpdGNoLCBUb29sdGlwLCBFbXB0eSB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCB7IEZhR2F2ZWwsIEZhRXllIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuXHJcbmNvbnN0IHsgUmFuZ2VQaWNrZXIgfSA9IERhdGVQaWNrZXI7XHJcblxyXG5jb25zdCBBdWN0aW9uUGFnZSA9ICgpID0+IHtcclxuICBjb25zdCBbYXVjdGlvbnMsIHNldEF1Y3Rpb25zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3ZpZXdMb2FkZXIsIHNldFZpZXdMb2FkZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBjb25zdCBbZmlsdGVycywgc2V0RmlsdGVyc10gPSB1c2VTdGF0ZSh7XHJcbiAgICBncm91cElkOiBcIlwiLFxyXG4gICAgdXNlcklkOiBcIlwiLFxyXG4gICAgYXVjdGlvbnR5cGU6IFwiXCIsXHJcbiAgICBwcml6ZWQ6IGZhbHNlLFxyXG4gICAgc3RhcnREYXRlOiBcIlwiLFxyXG4gICAgZW5kRGF0ZTogXCJcIlxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBbc2hvd01vZGFsVmlldywgc2V0U2hvd01vZGFsVmlld10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2N1cnJlbnRBdWN0aW9uLCBzZXRDdXJyZW50QXVjdGlvbl0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYXVjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJBdWN0aW9uIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwidXNlcl9uYW1lXCIsIGhlYWRlcjogXCJXaW5uZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0XCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsUGFpZEFtb3VudFwiLCBoZWFkZXI6IFwiVG90YWwgUGFpZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxQYXlhYmxlXCIsIGhlYWRlcjogXCJUb3RhbCBQYXlhYmxlXCIgfSxcclxuICAgIHsga2V5OiBcImJhbGFuY2VcIiwgaGVhZGVyOiBcIkJhbGFuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwid2luX2Ftb3VudFwiLCBoZWFkZXI6IFwiV2lubmluZyBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmlkX2Ftb3VudFwiLCBoZWFkZXI6IFwiQmlkIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJkaXZpZGVuZFwiLCBoZWFkZXI6IFwiRGl2aWRlbmRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXVjdGlvbl90eXBlXCIsIGhlYWRlcjogXCJUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInByaXplZFwiLCBoZWFkZXI6IFwiUHJpemVkXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG4gIGNvbnN0IGV4cG9ydENvbHVtbnMgPSBbXHJcblxyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJhdWN0aW9uX2RhdGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJncm91cF9uYW1lXCIsIGhlYWRlcjogXCJHcm91cCBOYW1lXCIgfSxcclxuICAgIHsga2V5OiBcInVzZXJfbmFtZVwiLCBoZWFkZXI6IFwiV2lubmVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwidG90YWxQYXlhYmxlUmF3XCIsIGhlYWRlcjogXCJUb3RhbCBQYXlhYmxlXCIgfSxcclxuICAgIHsga2V5OiBcInRvdGFsUGFpZEFtb3VudFJhd1wiLCBoZWFkZXI6IFwiVG90YWwgUGFpZCBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmFsYW5jZVJhd1wiLCBoZWFkZXI6IFwiQmFsYW5jZVwiIH0sXHJcbiAgICB7IGtleTogXCJ3aW5fYW1vdW50X3Jhd1wiLCBoZWFkZXI6IFwiV2lubmluZyBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmlkX2Ftb3VudFwiLCBoZWFkZXI6IFwiQmlkIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJkaXZpZGVuZF9yYXdcIiwgaGVhZGVyOiBcIkRpdmlkZW5kXCIgfSxcclxuXHJcbiAgICB7IGtleTogXCJhdWN0aW9uX3R5cGVfcmF3XCIsIGhlYWRlcjogXCJUeXBlXCIgfSxcclxuICAgIHsga2V5OiBcInByaXplZF9yYXdcIiwgaGVhZGVyOiBcIlByaXplZFwiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgZmV0Y2hJbml0aWFsRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IFtncm91cFJlcywgdXNlclJlc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIiksXHJcbiAgICAgICAgYXBpLmdldChcInVzZXIvdmVyaWZpZWRcIilcclxuICAgICAgXSk7XHJcbiAgICAgIHNldEdyb3Vwcyhncm91cFJlcy5kYXRhIHx8IFtdKTtcclxuICAgICAgc2V0VXNlcnModXNlclJlcy5kYXRhPy5kYXRhIHx8IFtdKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBpbml0aWFsIGRhdGFcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoRmlsdGVyZWRBdWN0aW9ucyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHt9O1xyXG4gICAgICBpZiAoZmlsdGVycy5ncm91cElkKSBwYXJhbXMuZ3JvdXBJZCA9IGZpbHRlcnMuZ3JvdXBJZDtcclxuICAgICAgaWYgKGZpbHRlcnMudXNlcklkKSBwYXJhbXMudXNlcklkID0gZmlsdGVycy51c2VySWQ7XHJcbiAgICAgIGlmIChmaWx0ZXJzLmF1Y3Rpb250eXBlKSBwYXJhbXMuYXVjdGlvbnR5cGUgPSBmaWx0ZXJzLmF1Y3Rpb250eXBlO1xyXG4gICAgICBpZiAoZmlsdGVycy5wcml6ZWQpIHBhcmFtcy5wcml6ZWQgPSBmaWx0ZXJzLnByaXplZDtcclxuICAgICAgaWYgKGZpbHRlcnMuc3RhcnREYXRlKSBwYXJhbXMuc3RhcnREYXRlID0gZmlsdGVycy5zdGFydERhdGU7XHJcbiAgICAgIGlmIChmaWx0ZXJzLmVuZERhdGUpIHBhcmFtcy5lbmREYXRlID0gZmlsdGVycy5lbmREYXRlO1xyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2F1Y3Rpb25cIiwgeyBwYXJhbXMgfSk7XHJcblxyXG4gICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhPy5kYXRhKSB7XHJcbiAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGE/LmRhdGEubWFwKChpdGVtLCBpbmRleCkgPT4ge1xyXG5cclxuICAgICAgICAgIGNvbnN0IHRvdGFsUGFpZCA9IGl0ZW0/LnBheW1lbnRzPy50b3RhbFBhaWRBbW91bnQgfHwgMDtcclxuICAgICAgICAgIGNvbnN0IHRvdGFsUGF5YWJsZSA9IGl0ZW0/LmF1Y3Rpb25zPy50b19iZV9wYWlkX2Ftb3VudCB8fCAwO1xyXG5cclxuXHJcbiAgICAgICAgICByZXR1cm4gKHtcclxuXHJcblxyXG4gICAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICBhdWN0aW9uX2RhdGU6IGl0ZW0uYXVjdGlvbl9kYXRlID8gZGF5anMoaXRlbT8uYXVjdGlvbl9kYXRlKS5mb3JtYXQoXCJZWVlZLU1NLUREXCIpIDogXCJOL0FcIixcclxuICAgICAgICAgICAgZ3JvdXBfbmFtZTogaXRlbS5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgICB1c2VyX25hbWU6IGl0ZW0udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICAgIHRpY2tldDogaXRlbT8udGlja2V0LFxyXG4gICAgICAgICAgICBiYWxhbmNlOiBgJHtpdGVtLmF1Y3Rpb25zPy5iYWxhbmNlPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpfWAsXHJcbiAgICAgICAgICAgIGJhbGFuY2VSYXc6IGl0ZW0uYXVjdGlvbnM/LmJhbGFuY2UsXHJcbiAgICAgICAgICAgIHRvdGFsUGFpZEFtb3VudDogYCR7dG90YWxQYWlkPy50b0xvY2FsZVN0cmluZyhcImVuLUlOXCIpIHx8IDB9YCxcclxuICAgICAgICAgICAgdG90YWxQYWlkQW1vdW50UmF3OiB0b3RhbFBhaWQgfHwgMCxcclxuICAgICAgICAgICAgdG90YWxQYXlhYmxlOiBgJHt0b3RhbFBheWFibGU/LnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIikgfHwgMH1gLFxyXG4gICAgICAgICAgICB0b3RhbFBheWFibGVSYXc6IHRvdGFsUGF5YWJsZSB8fCAwLFxyXG4gICAgICAgICAgICB3aW5fYW1vdW50OiBg4oK5JHtpdGVtLndpbl9hbW91bnQ/LnRvTG9jYWxlU3RyaW5nKCl9YCxcclxuICAgICAgICAgICAgd2luX2Ftb3VudF9yYXc6IGl0ZW0/Lndpbl9hbW91bnQsXHJcbiAgICAgICAgICAgIGRpdmlkZW5kOiBg4oK5JHtpdGVtPy5kaXZpZGVudD8udG9Mb2NhbGVTdHJpbmcoKX1gLFxyXG4gICAgICAgICAgICBkaXZpZGVuZF9yYXc6IGl0ZW0/LmRpdmlkZW50LFxyXG4gICAgICAgICAgICBhdWN0aW9uX3R5cGU6IDxUYWcgY29sb3I9e2l0ZW0uYXVjdGlvbl90eXBlID09PSAnZnJlZScgPyAncHVycGxlJyA6ICd2aW9sZXQnfT57aXRlbS5hdWN0aW9uX3R5cGU/LnRvVXBwZXJDYXNlKCl9PC9UYWc+LFxyXG4gICAgICAgICAgICBhdWN0aW9uX3R5cGVfcmF3OiBpdGVtPy5hdWN0aW9uX3R5cGUsXHJcbiAgICAgICAgICAgIHByaXplZDogPFRhZyBjb2xvcj17aXRlbT8uaXNQcml6ZWQgPT09ICd0cnVlJyA/ICdncmVlbicgOiAncmVkJ30+e2l0ZW0/LmlzUHJpemVkID8gXCJZZXNcIiA6IFwiTm9cIn08L1RhZz4sXHJcbiAgICAgICAgICAgIGJpZF9hbW91bnQ6IHBhcnNlSW50KGl0ZW0uZGl2aWRlbnQpICsgcGFyc2VJbnQoaXRlbS5jb21taXNzaW9uKSxcclxuICAgICAgICAgICAgcHJpemVkX3JhdzogaXRlbT8uaXNQcml6ZWQgPyBcIlllc1wiIDogXCJOb1wiLFxyXG4gICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxUb29sdGlwIHRpdGxlPVwiVmlldyBEZXRhaWxzXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVWaWV3QXVjdGlvbihpdGVtKX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgYmctdmlvbGV0LTUwIHRleHQtdmlvbGV0LTYwMCByb3VuZGVkLWZ1bGwgaG92ZXI6YmctdmlvbGV0LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8RmFFeWUgLz5cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L1Rvb2x0aXA+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICB9KVxyXG5cclxuXHJcblxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGZvcm1hdHRlZERhdGEpXHJcbiAgICAgICAgc2V0QXVjdGlvbnMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEF1Y3Rpb25zKFtdKTtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGF1Y3Rpb25zOlwiLCBlcnJvcik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaEluaXRpYWxEYXRhKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hGaWx0ZXJlZEF1Y3Rpb25zKCk7XHJcbiAgfSwgW2ZpbHRlcnNdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVmlld0F1Y3Rpb24gPSAoYXVjdGlvbikgPT4ge1xyXG4gICAgc2V0Q3VycmVudEF1Y3Rpb24oYXVjdGlvbik7XHJcbiAgICBzZXRTaG93TW9kYWxWaWV3KHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IG9uRGF0ZVJhbmdlQ2hhbmdlID0gKGRhdGVzKSA9PiB7XHJcbiAgICBpZiAoZGF0ZXMpIHtcclxuICAgICAgc2V0RmlsdGVycyhwcmV2ID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICBzdGFydERhdGU6IGRhdGVzWzBdLmZvcm1hdChcIllZWVktTU0tRERcIiksXHJcbiAgICAgICAgZW5kRGF0ZTogZGF0ZXNbMV0uZm9ybWF0KFwiWVlZWS1NTS1ERFwiKVxyXG4gICAgICB9KSk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRGaWx0ZXJzKHByZXYgPT4gKHsgLi4ucHJldiwgc3RhcnREYXRlOiBcIlwiLCBlbmREYXRlOiBcIlwiIH0pKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuXHJcbiAgICAgIDxDdXN0b21BbGVydFxyXG4gICAgICAgIHR5cGU9e2FsZXJ0Q29uZmlnLnR5cGV9XHJcbiAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgIG1lc3NhZ2U9e2FsZXJ0Q29uZmlnLm1lc3NhZ2V9XHJcbiAgICAgIC8+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTcgYmctZ3JheS01MCBtaW4taC1zY3JlZW5cIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi02XCI+XHJcbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgIDxGYUdhdmVsIGNsYXNzTmFtZT1cInRleHQtdmlvbGV0LTkwMFwiIC8+IEF1Y3Rpb24gTWFuYWdlbWVudFxyXG4gICAgICAgICAgPC9oMT5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBwLTYgcm91bmRlZC14bCBzaGFkb3ctc20gbWItOCBib3JkZXIgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTQgZ2FwLTRcIj5cclxuXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlXCI+RmlsdGVyIGJ5IEdyb3VwPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFsbCBHcm91cHNcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTAgbXQtMVwiXHJcbiAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gc2V0RmlsdGVycyhwcmV2ID0+ICh7IC4uLnByZXYsIGdyb3VwSWQ6IHZhbCB9KSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoZyA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Zy5faWR9IHZhbHVlPXtnLl9pZH0+e2cuZ3JvdXBfbmFtZX08L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkZpbHRlciBieSBXaW5uZXI8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWxsIFVzZXJzXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIG10LTFcIlxyXG4gICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4gb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSl9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gc2V0RmlsdGVycyhwcmV2ID0+ICh7IC4uLnByZXYsIHVzZXJJZDogdmFsIH0pKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7dXNlcnMubWFwKHUgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3UuX2lkfSB2YWx1ZT17dS5faWR9Pnt1LmZ1bGxfbmFtZX08L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPkF1Y3Rpb24gRGF0ZSBSYW5nZTwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPFJhbmdlUGlja2VyIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwIG10LTFcIiBvbkNoYW5nZT17b25EYXRlUmFuZ2VDaGFuZ2V9IC8+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93XCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2VcIj5BdWN0aW9uIFR5cGU8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMCBtdC0xXCJcclxuICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gc2V0RmlsdGVycyhwcmV2ID0+ICh7IC4uLnByZXYsIGF1Y3Rpb250eXBlOiB2YWwgfSkpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cIm5vcm1hbFwiPk5vcm1hbDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24gdmFsdWU9XCJmcmVlXCI+RnJlZTwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZVwiPlByaXplZDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U3dpdGNoXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTNcIlxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbCkgPT4gc2V0RmlsdGVycyhwcmV2ID0+ICh7IC4uLnByZXYsIHByaXplZDogdmFsIH0pKX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LXNtIHAtNFwiPlxyXG4gICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gZGF0YT1cIkF1Y3Rpb25zXCIgLz5cclxuICAgICAgICAgICkgOiBhdWN0aW9ucy5sZW5ndGggPD0gMCA/IDxFbXB0eSBkZXNjcmlwdGlvbj1cIk5vIEF1Y3Rpb24gRGF0YSBGb3VuZFwiIC8+IDogKFxyXG4gICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgZGF0YT17YXVjdGlvbnN9XHJcbiAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICBleHBvcnRDb2xzPXtleHBvcnRDb2x1bW5zfVxyXG4gICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkF1Y3Rpb25fUmVwb3J0XCJcclxuICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiQXVjdGlvbiBGaWx0ZXIgUmVwb3J0LmNzdlwiXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIDxBbnRNb2RhbFxyXG4gICAgICAgIHRpdGxlPXs8ZGl2IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIGJvcmRlci1iIHBiLTJcIj5BdWN0aW9uIERldGFpbGVkIFJlcG9ydDwvZGl2Pn1cclxuICAgICAgICBvcGVuPXtzaG93TW9kYWxWaWV3fVxyXG4gICAgICAgIG9uQ2FuY2VsPXsoKSA9PiBzZXRTaG93TW9kYWxWaWV3KGZhbHNlKX1cclxuICAgICAgICBmb290ZXI9e251bGx9XHJcbiAgICAgICAgd2lkdGg9ezYwMH1cclxuICAgICAgPlxyXG4gICAgICAgIHtjdXJyZW50QXVjdGlvbiAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLXktNCBweS00XCI+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtIGxhYmVsPVwiR3JvdXAgTmFtZVwiIHZhbHVlPXtjdXJyZW50QXVjdGlvbi5ncm91cF9pZD8uZ3JvdXBfbmFtZX0gLz5cclxuICAgICAgICAgICAgPERldGFpbEl0ZW0gbGFiZWw9XCJXaW5uZXJcIiB2YWx1ZT17Y3VycmVudEF1Y3Rpb24udXNlcl9pZD8uZnVsbF9uYW1lfSAvPlxyXG4gICAgICAgICAgICA8RGV0YWlsSXRlbSBsYWJlbD1cIlRpY2tldCBOb1wiIHZhbHVlPXtjdXJyZW50QXVjdGlvbi50aWNrZXR9IC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtIGxhYmVsPVwiQXVjdGlvbiBEYXRlXCIgdmFsdWU9e2RheWpzKGN1cnJlbnRBdWN0aW9uLmF1Y3Rpb25fZGF0ZSkuZm9ybWF0KFwiREQtTU0tWVlZWVwiKX0gLz5cclxuICAgICAgICAgICAgPERldGFpbEl0ZW0gbGFiZWw9XCJXaW5uaW5nIEFtb3VudFwiIHZhbHVlPXtg4oK5JHtjdXJyZW50QXVjdGlvbi53aW5fYW1vdW50fWB9IC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtIGxhYmVsPVwiQ29tbWlzc2lvblwiIHZhbHVlPXtg4oK5JHtjdXJyZW50QXVjdGlvbi5jb21taXNzaW9ufWB9IC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtIGxhYmVsPVwiVG90YWwgRGl2aWRlbmRcIiB2YWx1ZT17YOKCuSR7Y3VycmVudEF1Y3Rpb24uZGl2aWRlbnR9YH0gLz5cclxuICAgICAgICAgICAgPERldGFpbEl0ZW0gbGFiZWw9XCJEaXZpZGVuZCBQZXIgSGVhZFwiIHZhbHVlPXtg4oK5JHtjdXJyZW50QXVjdGlvbi5kaXZpZGVudF9oZWFkfWB9IC8+XHJcbiAgICAgICAgICAgIDxEZXRhaWxJdGVtIGxhYmVsPVwiUGF5YWJsZSBBbW91bnRcIiB2YWx1ZT17YOKCuSR7Y3VycmVudEF1Y3Rpb24ucGF5YWJsZX1gfSAvPlxyXG4gICAgICAgICAgICA8RGV0YWlsSXRlbSBsYWJlbD1cIk5leHQgQXVjdGlvbiBEYXRlXCIgdmFsdWU9e2N1cnJlbnRBdWN0aW9uLm5leHRfZGF0ZX0gLz5cclxuICAgICAgICAgICAgPERldGFpbEl0ZW1cclxuICAgICAgICAgICAgICBsYWJlbD1cIlByaXplZCBTdGF0dXNcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXs8VGFnIGNvbG9yPXtjdXJyZW50QXVjdGlvbi5pc1ByaXplZCA/IFwiZ3JlZW5cIiA6IFwicmVkXCJ9PntjdXJyZW50QXVjdGlvbi5pc1ByaXplZCA/IFwiWUVTXCIgOiBcIk5PXCJ9PC9UYWc+fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC9BbnRNb2RhbD5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5jb25zdCBEZXRhaWxJdGVtID0gKHsgbGFiZWwsIHZhbHVlIH0pID0+IChcclxuICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgYm9yZGVyLWIgYm9yZGVyLWdyYXktNTAgcGItMiBtci00XCI+XHJcbiAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1ncmF5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj57bGFiZWx9PC9zcGFuPlxyXG4gICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj57dmFsdWUgfHwgXCJOL0FcIn08L3NwYW4+XHJcbiAgPC9kaXY+XHJcbik7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBdWN0aW9uUGFnZTsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvQXVjdGlvbkZpbHRlclJlcG9ydC5qc3gifQ==