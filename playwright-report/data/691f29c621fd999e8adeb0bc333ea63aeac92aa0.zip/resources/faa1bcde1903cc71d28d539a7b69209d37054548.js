import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Task.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import api from "/src/instance/TokenInstance.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { Dropdown, Select, DatePicker, Input } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore, IoMdSearch } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import __vite__cjsImport14_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport14_dayjs.__esModule ? __vite__cjsImport14_dayjs.default : __vite__cjsImport14_dayjs;
const { Option } = Select;
const { RangePicker } = DatePicker;
const Task = () => {
  _s();
  const [agents, setAgents] = useState([]);
  const [leads, setLeads] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [tableTasks, setTableTasks] = useState([]);
  const [filteredTasks, setFilteredTasks] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [dateRange, setDateRange] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusCards, setStatusCards] = useState({
    total: 0,
    assigned: 0,
    completed: 0,
    pending: 0
  });
  const loggedInUser = JSON.parse(localStorage.getItem("user") || "{}");
  const loggedInAdminId = loggedInUser._id || loggedInUser.id || "";
  const loggedInAdminName = loggedInUser.name;
  const [formData, setFormData] = useState({
    assignedBy: loggedInAdminId || "",
    assignedTo: "",
    taskTitle: "Pending Lead Visit",
    taskDescription: "",
    startDate: (/* @__PURE__ */ new Date()).toISOString().slice(0, 16),
    endDate: "",
    status: "Pending",
    lead: "",
    employee: "",
    referred_type: "",
    approval_status: "",
    customer: "",
    purpose: "",
    customPurpose: ""
  });
  const location = useLocation();
  const { leadId, leadAgentId } = location.state || {};
  const [leadIdState, setLeadIdState] = useState(location.state?.leadId || null);
  const [leadAgentIdState] = useState(location.state?.leadAgentId || null);
  const [modalVisible, setModalVisible] = useState(false);
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [currentTask, setCurrentTask] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [initialLoad, setInitialLoad] = useState(true);
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const fetchAllData = async () => {
    try {
      if (initialLoad) setIsLoading(true);
      const [agentRes, leadRes, taskRes, customerRes, adminRes] = await Promise.all(
        [
          api.get("/agent/get-agent"),
          api.get("/lead/non-converted"),
          api.get("/task/get-tasks"),
          api.get("/user/get-user"),
          api.get("/admin/get-sub-admins")
        ]
      );
      const agentsList = Array.isArray(agentRes.data) ? agentRes.data : agentRes.data?.agent || [];
      const adminsList = Array.isArray(adminRes.data) ? adminRes.data : adminRes.data?.admins || adminRes.data?.data || [];
      setAgents(agentsList);
      setAdmins(adminsList);
      setLeads(leadRes.data || []);
      setCustomers(customerRes.data || []);
      setTasks(taskRes.data || []);
      const allAssigners = [...agentsList, ...adminsList];
      const formatted = (taskRes.data || []).map((task, index) => {
        const assignedByPerson = allAssigners.find(
          (a) => a._id === (task.assignedBy?._id || task.assignedBy)
        );
        const assignedToPerson = agentsList.find(
          (a) => a._id === (task.assignedTo?._id || task.assignedTo)
        );
        const refLead = (leadRes.data || []).find(
          (l) => l._id === (task.lead?._id || task.lead)
        );
        let refCustomer = null;
        let customerName = "N/A";
        let customerPhone = "";
        if (task.customer) {
          if (task.customer._id && (task.customer.full_name || task.customer.name)) {
            refCustomer = task.customer;
            customerName = task.customer.full_name || task.customer.name || "N/A";
            customerPhone = task.customer.phone || task.customer.phone_number || task.customer.mobile || "";
          } else {
            const customerId = task.customer._id || task.customer;
            refCustomer = (customerRes.data || []).find((c) => c._id === customerId);
            if (refCustomer) {
              customerName = refCustomer.full_name || refCustomer.name || "N/A";
              customerPhone = refCustomer.phone || refCustomer.phone_number || refCustomer.mobile || "";
            }
          }
        }
        const typeLower = (task.referred_type || "").toLowerCase();
        let contactName = "N/A";
        let referredDisplay = "N/A";
        if (typeLower.includes("lead")) {
          if (refLead) {
            contactName = refLead.lead_name || "N/A";
            referredDisplay = `${refLead.lead_name} (${refLead.lead_phone})`;
          }
        } else if (typeLower.includes("customer")) {
          contactName = customerName;
          referredDisplay = `${customerName}${customerPhone ? ` (${customerPhone})` : ""}`;
        } else if (typeLower.includes("employee")) {
          if (assignedToPerson) {
            contactName = assignedToPerson.name || "N/A";
            referredDisplay = `${assignedToPerson.name} (${assignedToPerson.phone_number})`;
          }
        } else {
          if (assignedToPerson) {
            contactName = assignedToPerson.name || "N/A";
            referredDisplay = `${assignedToPerson.name} (${assignedToPerson.phone_number})`;
          } else if (refLead) {
            contactName = refLead.lead_name || "N/A";
            referredDisplay = `${refLead.lead_name} (${refLead.lead_phone})`;
          } else if (customerName !== "N/A") {
            contactName = customerName;
            referredDisplay = `${customerName}${customerPhone ? ` (${customerPhone})` : ""}`;
          }
        }
        return {
          _id: task._id,
          id: index + 1,
          task_code: task?.task_code,
          employeeName: assignedByPerson?.name || task.assignedBy?.name || "N/A",
          employeeCode: assignedByPerson?.employeeCode || task.assignedBy?.employeeCode || "N/A",
          taskTitle: task.taskTitle || "N/A",
          status: task.status,
          referredType: task?.referred_type || "N/A",
          referred: referredDisplay,
          customerName: contactName,
          // Now populates for Leads, Customers, and Employees
          approvalStatus: task?.approval_status,
          assignedToId: task.assignedTo?._id || task.assignedTo,
          customerId: task.customer?._id || task.customer,
          leadId: task.lead?._id || task.lead,
          purpose: task.purpose || "N/A",
          // Added purpose field from API
          createdAt: task.createdAt,
          startDate: task.startDate,
          endDate: task.endDate,
          action: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              menu: {
                items: [
                  { key: "1", label: /* @__PURE__ */ jsxDEV("div", { className: "text-green-600", onClick: () => openEdit(task), children: "Edit" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                    lineNumber: 202,
                    columnNumber: 34
                  }, this) },
                  { key: "2", label: /* @__PURE__ */ jsxDEV("div", { className: "text-red-600", onClick: () => handleDelete(task._id), children: "Delete" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                    lineNumber: 203,
                    columnNumber: 34
                  }, this) }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "cursor-pointer" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 208,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 199,
              columnNumber: 11
            },
            this
          )
        };
      });
      setTableTasks(formatted);
      setFilteredTasks(formatted);
      calculateStatusCards(formatted);
    } catch (err) {
      console.error("Error fetching all data", err);
      setAlertConfig({
        visibility: true,
        message: "Failed to fetch data",
        type: "error"
      });
    } finally {
      setIsLoading(false);
      setInitialLoad(false);
    }
  };
  const calculateStatusCards = (tasksData) => {
    const total = tasksData.length;
    const assigned = tasksData.filter((task) => task.status === "Pending" || task.status === "In Progress").length;
    const completed = tasksData.filter((task) => task.status === "Completed").length;
    const pending = tasksData.filter((task) => task.status === "Pending").length;
    setStatusCards({
      total,
      assigned,
      completed,
      pending
    });
  };
  const applyFilters = () => {
    let filtered = [...tableTasks];
    if (selectedAgent) {
      filtered = filtered.filter((task) => task.assignedToId === selectedAgent);
    }
    if (dateRange && dateRange[0] && dateRange[1]) {
      const startDate = dayjs(dateRange[0]).startOf("day");
      const endDate = dayjs(dateRange[1]).endOf("day");
      filtered = filtered.filter((task) => {
        if (!task.createdAt) return false;
        const taskDate = dayjs(task.createdAt);
        return taskDate.isBetween(startDate, endDate, null, "[]");
      });
    }
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      filtered = filtered.filter(
        (task) => task.referred.toLowerCase().includes(query) || task.employeeName.toLowerCase().includes(query) || task.taskTitle.toLowerCase().includes(query)
      );
    }
    setFilteredTasks(filtered);
    calculateStatusCards(filtered);
  };
  useEffect(() => {
    applyFilters();
  }, [selectedAgent, dateRange, searchQuery, tableTasks]);
  const fetchAgents = async () => {
    try {
      const response = await api.get("/agent/get-agent");
      const agentsList = Array.isArray(response.data) ? response.data : response.data?.agent || [];
      setAgents(agentsList);
    } catch (err) {
      console.error("Error fetching agents", err);
    }
  };
  useEffect(() => {
    fetchAgents();
  }, []);
  useEffect(() => {
    fetchAllData();
  }, [reloadTrigger]);
  const handleAntDSelect = (name, value) => {
    setFormData((prev) => {
      const updated = { ...prev, [name]: value };
      if (name === "referred_type") {
        updated.lead = "";
        updated.customer = "";
        if (value === "Lead") {
          updated.taskTitle = "Pending Lead Visit";
        } else if (value === "Employee") {
          updated.taskTitle = "Pending Employee Task";
        } else if (value === "Customer") {
          updated.taskTitle = "Pending Customer";
        } else {
          updated.taskTitle = "Pending Lead Visit";
        }
      }
      return updated;
    });
  };
  useEffect(() => {
    if (formData.referred_type === "Lead") {
      setFormData((prev) => ({
        ...prev,
        taskTitle: "Pending Lead Visit"
      }));
    } else if (formData.referred_type === "Employee") {
      setFormData((prev) => ({
        ...prev,
        taskTitle: "Pending Employee Task"
      }));
    } else if (formData.referred_type === "Customer") {
      setFormData((prev) => ({
        ...prev,
        taskTitle: "Pending Customer"
      }));
    }
  }, [formData.referred_type]);
  const handleInput = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (!formData.referred_type) {
        setAlertConfig({
          visibility: true,
          message: "Please select an Assignee Type",
          type: "error"
        });
        return;
      }
      if (!formData.assignedTo) {
        setAlertConfig({
          visibility: true,
          message: "Please select an agent to assign the task",
          type: "error"
        });
        return;
      }
      if (formData.referred_type === "Lead" && !formData.lead) {
        setAlertConfig({
          visibility: true,
          message: "Please select a Lead",
          type: "error"
        });
        return;
      }
      if (formData.referred_type === "Customer" && !formData.customer) {
        setAlertConfig({
          visibility: true,
          message: "Please select a Customer",
          type: "error"
        });
        return;
      }
      if (!formData.taskDescription?.trim()) {
        setAlertConfig({
          visibility: true,
          message: "Please enter a Task Description",
          type: "error"
        });
        return;
      }
      if (!formData.startDate) {
        setAlertConfig({
          visibility: true,
          message: "Please select a Start Date & Time",
          type: "error"
        });
        return;
      }
      if (!formData.assignedBy) {
        setAlertConfig({
          visibility: true,
          message: "Could not detect logged-in admin. Please log in again.",
          type: "error"
        });
        return;
      }
      const payload = { ...formData };
      delete payload.endDate;
      delete payload.approval_status;
      if (payload.referred_type === "Lead") {
        delete payload.customer;
      } else if (payload.referred_type === "Employee") {
        delete payload.lead;
        delete payload.customer;
      } else if (payload.referred_type === "Customer") {
        delete payload.lead;
      }
      Object.keys(payload).forEach((key) => {
        const protectedKeys = ["assignedBy", "taskTitle", "taskDescription", "startDate"];
        if (!protectedKeys.includes(key) && (payload[key] === "" || payload[key] === null || payload[key] === void 0)) {
          delete payload[key];
        }
      });
      if (currentTask) {
        await api.put(`/task/update-task/${currentTask}`, payload);
        setAlertConfig({
          visibility: true,
          message: "Task updated successfully",
          type: "success"
        });
        setReloadTrigger((prev) => prev + 1);
      } else {
        const res = await api.post("/task/add-new-task", payload);
        console.info(res.data, "test123");
        setAlertConfig({
          visibility: true,
          message: "Task created successfully",
          type: "success"
        });
      }
      setModalVisible(false);
      resetForm();
      setReloadTrigger((prev) => prev + 1);
    } catch (err) {
      console.error("Task creation error:", err.response?.data || err.message);
      setAlertConfig({
        visibility: true,
        message: err.response?.data?.message || "Something went wrong",
        type: "error"
      });
    }
  };
  const resetForm = () => {
    setFormData({
      assignedBy: loggedInAdminId || "",
      assignedTo: "",
      taskTitle: "Pending Lead Visit",
      taskDescription: "",
      startDate: (/* @__PURE__ */ new Date()).toISOString().slice(0, 16),
      endDate: "",
      status: "Pending",
      lead: "",
      referred_type: "",
      // Keep as empty string
      approval_status: "",
      customer: ""
    });
    setCurrentTask(null);
  };
  const openEdit = (task) => {
    setCurrentTask(task._id);
    setFormData({
      assignedBy: task.assignedBy?._id || task.assignedBy || loggedInAdminId,
      assignedTo: task.assignedTo?._id || task.assignedTo || "",
      referred_type: task?.referred_type,
      lead: task.lead?._id || task.lead || "",
      customer: task.customer?._id || task.customer || "",
      employee: task.employee?._id || task.employee || "",
      purpose: task.purpose || "",
      taskTitle: task.taskTitle || "Pending Lead Visit",
      taskDescription: task.taskDescription || "",
      startDate: task.startDate?.slice(0, 16) || "",
      endDate: task.endDate?.slice(0, 16) || "",
      status: task.status || "Pending",
      approval_status: task?.approval_status || "Pending"
    });
    setModalVisible(true);
  };
  const handleDelete = async (id) => {
    try {
      setIsDeleting(true);
      setAlertConfig({
        visibility: true,
        message: "Deleting task...",
        type: "info"
      });
      await api.delete(`/task/delete-task/${id}`);
      setAlertConfig({
        visibility: true,
        message: "Task deleted successfully",
        type: "success"
      });
      setReloadTrigger((prev) => prev + 1);
    } catch (err) {
      setAlertConfig({
        visibility: true,
        message: "Delete failed",
        type: "error"
      });
    } finally {
      setIsDeleting(false);
    }
  };
  const clearFilters = () => {
    setSelectedAgent(null);
    setDateRange(null);
    setSearchQuery("");
  };
  const columns = [
    { key: "id", header: "SL No" },
    { key: "task_code", header: "Task Code" },
    { key: "employeeName", header: "Assigned By" },
    { key: "employeeCode", header: "Employee ID" },
    { key: "taskTitle", header: "Task Name" },
    { key: "referredType", header: "Referred Type" },
    { key: "referred", header: "Assigned To" },
    { key: "customerName", header: "Customer / lead / Employee Name" },
    // New column for customer
    { key: "status", header: "Task Status" },
    // { key: "approvalStatus", header: "Approval Status" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Navbar, { visibility: true }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
        lineNumber: 597,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 598,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
        lineNumber: 606,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Tasks" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 611,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setModalVisible(true);
                resetForm();
              },
              className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
              children: "+ Add Task"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 612,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 610,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 609,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 mb-6", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-6 border-l-4 border-blue-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-600", children: "Total Tasks" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 629,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: statusCards.total }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 630,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 628,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-100 p-3 rounded-full", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-6 h-6 text-blue-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 634,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 633,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 632,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 627,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 626,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-6 border-l-4 border-yellow-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-600", children: "Assigned" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 643,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: statusCards.assigned }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 644,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 642,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-yellow-100 p-3 rounded-full", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-6 h-6 text-yellow-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 648,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 647,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 646,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 641,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 640,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-6 border-l-4 border-green-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-600", children: "Completed" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 657,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: statusCards.completed }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 658,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 656,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-100 p-3 rounded-full", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-6 h-6 text-green-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 662,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 661,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 660,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 655,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 654,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-6 border-l-4 border-red-500", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium text-gray-600", children: "Pending" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 671,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-800", children: statusCards.pending }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 672,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 670,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-red-100 p-3 rounded-full", children: /* @__PURE__ */ jsxDEV("svg", { className: "w-6 h-6 text-red-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 676,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 675,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 674,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 669,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 668,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 625,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-lg shadow p-4 mb-6", children: /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-4 items-end", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Search by Agent" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 687,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Select,
              {
                className: "w-full",
                placeholder: "Select Agent",
                showSearch: true,
                allowClear: true,
                value: selectedAgent,
                onChange: (value) => setSelectedAgent(value),
                optionFilterProp: "children",
                filterOption: (input, option) => {
                  const children = option?.props?.children?.toString() || "";
                  return children.toLowerCase().includes(input.toLowerCase());
                },
                children: agents.map(
                  (agent) => /* @__PURE__ */ jsxDEV(Option, { value: agent._id, children: [
                    agent.name,
                    " | ",
                    agent.phone_number
                  ] }, agent._id, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                    lineNumber: 702,
                    columnNumber: 19
                  }, this)
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 688,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 686,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Date Range" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 710,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              RangePicker,
              {
                className: "w-full",
                onChange: (dates) => setDateRange(dates),
                format: "YYYY-MM-DD"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 711,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 709,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: "Search" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 719,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Input,
              {
                placeholder: "Search by agent name, task title...",
                value: searchQuery,
                onChange: (e) => setSearchQuery(e.target.value),
                prefix: /* @__PURE__ */ jsxDEV(IoMdSearch, { className: "text-gray-400" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 724,
                  columnNumber: 27
                }, this),
                allowClear: true,
                className: "w-full"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 720,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 718,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: clearFilters,
              className: "bg-gray-200 text-gray-700 px-4 py-2 rounded hover:bg-gray-300 transition duration-200",
              children: "Clear Filters"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 731,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 730,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 685,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 684,
          columnNumber: 11
        }, this),
        initialLoad && isLoading ? /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: !isLoading,
            data: "Task Data"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 747,
            columnNumber: 11
          },
          this
        ) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          isDeleting && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50", children: /* @__PURE__ */ jsxDEV("div", { className: "bg-white p-6 rounded-lg shadow-lg", children: [
            /* @__PURE__ */ jsxDEV(
              CircularLoader,
              {
                isLoading: true,
                failure: false,
                data: "Deleting Task..."
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 758,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { className: "text-center mt-2 text-gray-700", children: "Deleting task..." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 763,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 757,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 756,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              updateHandler: (id) => openEdit(tasks.find((t) => t._id === id)),
              data: filteredTasks,
              columns,
              exportedPdfName: "Task",
              exportedFileName: "Tasks.csv"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 767,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 753,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
        lineNumber: 608,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
      lineNumber: 596,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: modalVisible, onClose: () => setModalVisible(false), children: /* @__PURE__ */ jsxDEV("div", { className: "p-5 sm:p-6 max-h-[85vh] overflow-y-auto bg-white rounded-xl", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-6 border-b border-gray-100 pb-4", children: [
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-bold text-gray-800", children: currentTask ? "Update Task" : "Add Task" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 783,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: currentTask ? "Update the task details and assignment information." : "Create and assign a new task." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 786,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
        lineNumber: 782,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "space-y-5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: [
            "Task Assigned By ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 797,
              columnNumber: 34
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 796,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "text",
              value: loggedInAdminName || "Admin",
              disabled: true,
              className: "w-full h-10 px-3 border border-gray-200 rounded-lg bg-gray-50 text-gray-500 text-sm shadow-sm outline-none cursor-not-allowed"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 799,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "hidden",
              name: "assignedBy",
              value: loggedInAdminId
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 805,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 795,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: [
            "Task Assigned To ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 815,
              columnNumber: 34
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 814,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full",
              placeholder: "Select Agent",
              showSearch: true,
              name: "assignedTo",
              optionFilterProp: "children",
              filterOption: (input, option) => {
                const children = option?.props?.children?.toString() || "";
                return children.toLowerCase().includes(input.toLowerCase());
              },
              value: formData.assignedTo || void 0,
              onChange: (value) => handleAntDSelect("assignedTo", value),
              children: agents.length > 0 ? agents.map(
                (agent) => /* @__PURE__ */ jsxDEV(Option, { value: agent._id, children: [
                  agent.name,
                  " | ",
                  agent.phone_number
                ] }, agent._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 832,
                  columnNumber: 17
                }, this)
              ) : /* @__PURE__ */ jsxDEV(Option, { value: "", children: "No agents available" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                lineNumber: 837,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 817,
              columnNumber: 15
            },
            this
          ),
          agents.length === 0 && /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-red-500 mt-1.5", children: "No agents found. Please add agents first." }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 841,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 813,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: [
            "Assignee Type ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 850,
              columnNumber: 31
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 849,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full",
              placeholder: "Select Assignee Type",
              showSearch: true,
              name: "referred_type",
              optionFilterProp: "children",
              filterOption: (input, option) => {
                const children = option?.props?.children?.toString() || "";
                return children.toLowerCase().includes(input.toLowerCase());
              },
              value: formData.referred_type || void 0,
              onChange: (value) => handleAntDSelect("referred_type", value),
              status: !formData.referred_type && formData.referred_type !== "" ? "error" : "",
              children: [
                /* @__PURE__ */ jsxDEV(Option, { value: "Lead", children: "Lead" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 866,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Option, { value: "Employee", children: "Employee" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 867,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Option, { value: "Customer", children: "Customer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 868,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 852,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 848,
          columnNumber: 13
        }, this),
        formData.referred_type === "Lead" && /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Select Lead" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 880,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full",
              showSearch: true,
              popupMatchSelectWidth: false,
              placeholder: "Select Lead",
              name: "lead",
              optionFilterProp: "children",
              filterOption: (input, option) => {
                const children = option?.props?.children?.toString() || "";
                return children.toLowerCase().includes(input.toLowerCase());
              },
              value: formData.lead || void 0,
              onChange: (value) => handleAntDSelect("lead", value),
              children: leads.map(
                (l) => /* @__PURE__ */ jsxDEV(Option, { value: l._id, children: [
                  l.lead_name,
                  " | ",
                  l.lead_phone
                ] }, l._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 898,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 883,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 879,
          columnNumber: 13
        }, this),
        formData.referred_type === "Employee" && /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Select Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 909,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full",
              showSearch: true,
              placeholder: "Select Employee",
              name: "employee",
              optionFilterProp: "children",
              filterOption: (input, option) => {
                const children = option?.props?.children?.toString() || "";
                return children.toLowerCase().includes(input.toLowerCase());
              },
              value: formData.employee || void 0,
              onChange: (value) => handleAntDSelect("employee", value),
              children: agents.map(
                (a) => /* @__PURE__ */ jsxDEV(Option, { value: a._id, children: [
                  a.name,
                  " | ",
                  a.phone_number
                ] }, a._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 926,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 912,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 908,
          columnNumber: 13
        }, this),
        formData.referred_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: "Select Customer" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 937,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full",
              showSearch: true,
              popupMatchSelectWidth: false,
              placeholder: "Select Customer",
              name: "customer",
              optionFilterProp: "children",
              filterOption: (input, option) => {
                const children = option?.props?.children?.toString() || "";
                return children.toLowerCase().includes(input.toLowerCase());
              },
              value: formData.customer || void 0,
              onChange: (value) => handleAntDSelect("customer", value),
              children: customers.map(
                (c) => /* @__PURE__ */ jsxDEV(Option, { value: c._id, children: [
                  c.full_name || c.name || "Unnamed",
                  " | ",
                  c.phone_number || c.phone || c.mobile || "N/A"
                ] }, c._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 955,
                  columnNumber: 17
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 940,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 936,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: [
            "Task Purpose ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 966,
              columnNumber: 30
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 965,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full",
              placeholder: "Select Purpose",
              showSearch: true,
              name: "purpose",
              optionFilterProp: "children",
              filterOption: (input, option) => {
                const children = option?.props?.children?.toString() || "";
                return children.toLowerCase().includes(input.toLowerCase());
              },
              value: formData.purpose || void 0,
              onChange: (value) => handleAntDSelect("purpose", value),
              children: [
                /* @__PURE__ */ jsxDEV(Option, { value: "Customer Visit", children: "Customer Visit" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 981,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Option, { value: "Follow Up", children: "Follow Up" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 982,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Option, { value: "New Business", children: "New Business" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 983,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Option, { value: "Support", children: "Support" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 984,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Option, { value: "Inquiry", children: "Inquiry" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 985,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Option, { value: "Other", children: "Other" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
                  lineNumber: 986,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 968,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 964,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: [
            "Task Description ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 993,
              columnNumber: 34
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 992,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "textarea",
            {
              name: "taskDescription",
              value: formData.taskDescription,
              onChange: handleInput,
              rows: "4",
              placeholder: "Enter task description...",
              className: "w-full px-3 py-2.5 border border-gray-200 rounded-lg bg-white text-sm text-gray-700 placeholder-gray-400 shadow-sm outline-none resize-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition",
              required: true
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 995,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 991,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-700", children: [
            "Start Date & Time ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 1010,
              columnNumber: 37
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 1009,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "datetime-local",
              name: "startDate",
              value: formData.startDate,
              onChange: handleInput,
              className: "w-full h-10 px-3 border border-gray-200 rounded-lg bg-white text-sm text-gray-700 shadow-sm outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100 transition",
              required: true
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
              lineNumber: 1012,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 1008,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 1007,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-3 border-t border-gray-100", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-full sm:w-auto min-w-[120px] bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-sm font-semibold px-5 py-2.5 rounded-lg shadow-md hover:from-blue-700 hover:to-indigo-700 hover:shadow-lg active:scale-[0.98] transition-all duration-200",
            children: "Continue"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
            lineNumber: 1053,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
          lineNumber: 1052,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
        lineNumber: 793,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
      lineNumber: 781,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
      lineNumber: 780,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx",
    lineNumber: 595,
    columnNumber: 5
  }, this);
};
_s(Task, "nNvAEH1v0SYCn1wFxGce5essuyQ=", false, function() {
  return [useLocation];
});
_c = Task;
export default Task;
var _c;
$RefreshReg$(_c, "Task");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Task.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeU1xQyxTQXVpQnpCLFVBdmlCeUI7MkJBek1yQztBQUFvQkEsb0JBQWdCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDM0MsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsZUFBZTtBQUN0QixPQUFPQyxTQUFTO0FBQ2hCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxVQUFVQyxRQUFRQyxZQUFZQyxhQUFhO0FBQ3BELFNBQVNDLFVBQVVDLGtCQUFrQjtBQUNyQyxPQUFPQyx1QkFBdUI7QUFDOUIsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLFdBQVc7QUFFbEIsTUFBTSxFQUFFQyxPQUFPLElBQUlSO0FBQ25CLE1BQU0sRUFBRVMsWUFBWSxJQUFJUjtBQUV4QixNQUFNUyxPQUFPQSxNQUFNO0FBQUFDLEtBQUE7QUFDakIsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUlyQixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDc0IsT0FBT0MsUUFBUSxJQUFJdkIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3dCLFdBQVdDLFlBQVksSUFBSXpCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUMwQixPQUFPQyxRQUFRLElBQUkzQixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDNEIsWUFBWUMsYUFBYSxJQUFJN0IsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQzhCLGVBQWVDLGdCQUFnQixJQUFJL0IsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ2dDLFFBQVFDLFNBQVMsSUFBSWpDLFNBQVMsRUFBRTtBQUd2QyxRQUFNLENBQUNrQyxlQUFlQyxnQkFBZ0IsSUFBSW5DLFNBQVMsSUFBSTtBQUN2RCxRQUFNLENBQUNvQyxXQUFXQyxZQUFZLElBQUlyQyxTQUFTLElBQUk7QUFDL0MsUUFBTSxDQUFDc0MsYUFBYUMsY0FBYyxJQUFJdkMsU0FBUyxFQUFFO0FBR2pELFFBQU0sQ0FBQ3dDLGFBQWFDLGNBQWMsSUFBSXpDLFNBQVM7QUFBQSxJQUM3QzBDLE9BQU87QUFBQSxJQUNQQyxVQUFVO0FBQUEsSUFDVkMsV0FBVztBQUFBLElBQ1hDLFNBQVM7QUFBQSxFQUNYLENBQUM7QUFFRCxRQUFNQyxlQUFlQyxLQUFLQyxNQUFNQyxhQUFhQyxRQUFRLE1BQU0sS0FBSyxJQUFJO0FBRXBFLFFBQU1DLGtCQUFrQkwsYUFBYU0sT0FBT04sYUFBYU8sTUFBTTtBQUMvRCxRQUFNQyxvQkFBb0JSLGFBQWFTO0FBRXZDLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJekQsU0FBUztBQUFBLElBQ3ZDMEQsWUFBWVAsbUJBQW1CO0FBQUEsSUFDL0JRLFlBQVk7QUFBQSxJQUNaQyxXQUFXO0FBQUEsSUFDWEMsaUJBQWlCO0FBQUEsSUFDakJDLFlBQVcsb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRTtBQUFBLElBQy9DQyxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLElBQ1JDLE1BQU07QUFBQSxJQUNOQyxVQUFVO0FBQUEsSUFDVkMsZUFBZTtBQUFBLElBQ2ZDLGlCQUFpQjtBQUFBLElBQ2pCQyxVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RDLGVBQWU7QUFBQSxFQUNqQixDQUFDO0FBRUQsUUFBTUMsV0FBVzdELFlBQVk7QUFDN0IsUUFBTSxFQUFFOEQsUUFBUUMsWUFBWSxJQUFJRixTQUFTRyxTQUFTLENBQUM7QUFDbkQsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUloRixTQUFTMkUsU0FBU0csT0FBT0YsVUFBVSxJQUFJO0FBQzdFLFFBQU0sQ0FBQ0ssZ0JBQWdCLElBQUlqRixTQUFTMkUsU0FBU0csT0FBT0QsZUFBZSxJQUFJO0FBQ3ZFLFFBQU0sQ0FBQ0ssY0FBY0MsZUFBZSxJQUFJbkYsU0FBUyxLQUFLO0FBQ3RELFFBQU0sQ0FBQ29GLGVBQWVDLGdCQUFnQixJQUFJckYsU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQ3NGLGFBQWFDLGNBQWMsSUFBSXZGLFNBQVMsSUFBSTtBQUNuRCxRQUFNLENBQUN3RixXQUFXQyxZQUFZLElBQUl6RixTQUFTLEtBQUs7QUFFaEQsUUFBTSxDQUFDMEYsWUFBWUMsYUFBYSxJQUFJM0YsU0FBUyxLQUFLO0FBSWxELFFBQU0sQ0FBQzRGLGFBQWFDLGNBQWMsSUFBSTdGLFNBQVMsSUFBSTtBQUVuRCxRQUFNLENBQUM4RixhQUFhQyxjQUFjLElBQUkvRixTQUFTO0FBQUEsSUFDN0NnRyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLE1BQU07QUFBQSxFQUNSLENBQUM7QUFFRCxRQUFNQyxlQUFlLFlBQVk7QUFDL0IsUUFBSTtBQUVGLFVBQUlQLFlBQWFILGNBQWEsSUFBSTtBQUVsQyxZQUFNLENBQUNXLFVBQVVDLFNBQVNDLFNBQVNDLGFBQWFDLFFBQVEsSUFBSSxNQUFNQyxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDNUVyRyxJQUFJc0csSUFBSSxrQkFBa0I7QUFBQSxVQUMxQnRHLElBQUlzRyxJQUFJLHFCQUFxQjtBQUFBLFVBQzdCdEcsSUFBSXNHLElBQUksaUJBQWlCO0FBQUEsVUFDekJ0RyxJQUFJc0csSUFBSSxnQkFBZ0I7QUFBQSxVQUN4QnRHLElBQUlzRyxJQUFJLHVCQUF1QjtBQUFBLFFBQUM7QUFBQSxNQUNqQztBQUVELFlBQU1DLGFBQWFDLE1BQU1DLFFBQVFWLFNBQVNXLElBQUksSUFDMUNYLFNBQVNXLE9BQ1RYLFNBQVNXLE1BQU1DLFNBQVM7QUFFNUIsWUFBTUMsYUFBYUosTUFBTUMsUUFBUU4sU0FBU08sSUFBSSxJQUMxQ1AsU0FBU08sT0FDVFAsU0FBU08sTUFBTS9FLFVBQVV3RSxTQUFTTyxNQUFNQSxRQUFRO0FBRXBEMUYsZ0JBQVV1RixVQUFVO0FBQ3BCM0UsZ0JBQVVnRixVQUFVO0FBQ3BCMUYsZUFBUzhFLFFBQVFVLFFBQVEsRUFBRTtBQUMzQnRGLG1CQUFhOEUsWUFBWVEsUUFBUSxFQUFFO0FBQ25DcEYsZUFBUzJFLFFBQVFTLFFBQVEsRUFBRTtBQUUzQixZQUFNRyxlQUFlLENBQUMsR0FBR04sWUFBWSxHQUFHSyxVQUFVO0FBRWxELFlBQU1FLGFBQWFiLFFBQVFTLFFBQVEsSUFBSUssSUFBSSxDQUFDQyxNQUFNQyxVQUFVO0FBRTFELGNBQU1DLG1CQUFtQkwsYUFBYU07QUFBQUEsVUFDcEMsQ0FBQ0MsTUFBTUEsRUFBRXJFLFNBQVNpRSxLQUFLM0QsWUFBWU4sT0FBT2lFLEtBQUszRDtBQUFBQSxRQUNqRDtBQUdBLGNBQU1nRSxtQkFBbUJkLFdBQVdZO0FBQUFBLFVBQ2xDLENBQUNDLE1BQU1BLEVBQUVyRSxTQUFTaUUsS0FBSzFELFlBQVlQLE9BQU9pRSxLQUFLMUQ7QUFBQUEsUUFDakQ7QUFHQSxjQUFNZ0UsV0FBV3RCLFFBQVFVLFFBQVEsSUFBSVM7QUFBQUEsVUFDbkMsQ0FBQ0ksTUFBTUEsRUFBRXhFLFNBQVNpRSxLQUFLakQsTUFBTWhCLE9BQU9pRSxLQUFLakQ7QUFBQUEsUUFDM0M7QUFHQSxZQUFJeUQsY0FBYztBQUNsQixZQUFJQyxlQUFlO0FBQ25CLFlBQUlDLGdCQUFnQjtBQUVwQixZQUFJVixLQUFLN0MsVUFBVTtBQUNqQixjQUFJNkMsS0FBSzdDLFNBQVNwQixRQUFRaUUsS0FBSzdDLFNBQVN3RCxhQUFhWCxLQUFLN0MsU0FBU2pCLE9BQU87QUFDeEVzRSwwQkFBY1IsS0FBSzdDO0FBQ25Cc0QsMkJBQWVULEtBQUs3QyxTQUFTd0QsYUFBYVgsS0FBSzdDLFNBQVNqQixRQUFRO0FBQ2hFd0UsNEJBQWdCVixLQUFLN0MsU0FBU3lELFNBQVNaLEtBQUs3QyxTQUFTMEQsZ0JBQWdCYixLQUFLN0MsU0FBUzJELFVBQVU7QUFBQSxVQUMvRixPQUFPO0FBQ0wsa0JBQU1DLGFBQWFmLEtBQUs3QyxTQUFTcEIsT0FBT2lFLEtBQUs3QztBQUM3Q3FELDJCQUFldEIsWUFBWVEsUUFBUSxJQUFJUyxLQUFLLENBQUFhLE1BQUtBLEVBQUVqRixRQUFRZ0YsVUFBVTtBQUNyRSxnQkFBSVAsYUFBYTtBQUNmQyw2QkFBZUQsWUFBWUcsYUFBYUgsWUFBWXRFLFFBQVE7QUFDNUR3RSw4QkFBZ0JGLFlBQVlJLFNBQVNKLFlBQVlLLGdCQUFnQkwsWUFBWU0sVUFBVTtBQUFBLFlBQ3pGO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFHQSxjQUFNRyxhQUFhakIsS0FBSy9DLGlCQUFpQixJQUFJaUUsWUFBWTtBQUN6RCxZQUFJQyxjQUFjO0FBQ2xCLFlBQUlDLGtCQUFrQjtBQUV0QixZQUFJSCxVQUFVSSxTQUFTLE1BQU0sR0FBRztBQUM5QixjQUFJZixTQUFTO0FBQ1hhLDBCQUFjYixRQUFRZ0IsYUFBYTtBQUNuQ0YsOEJBQWtCLEdBQUdkLFFBQVFnQixTQUFTLEtBQUtoQixRQUFRaUIsVUFBVTtBQUFBLFVBQy9EO0FBQUEsUUFDRixXQUFXTixVQUFVSSxTQUFTLFVBQVUsR0FBRztBQUN6Q0Ysd0JBQWNWO0FBQ2RXLDRCQUFrQixHQUFHWCxZQUFZLEdBQUdDLGdCQUFnQixLQUFLQSxhQUFhLE1BQU0sRUFBRTtBQUFBLFFBQ2hGLFdBQVdPLFVBQVVJLFNBQVMsVUFBVSxHQUFHO0FBQ3pDLGNBQUloQixrQkFBa0I7QUFDcEJjLDBCQUFjZCxpQkFBaUJuRSxRQUFRO0FBQ3ZDa0YsOEJBQWtCLEdBQUdmLGlCQUFpQm5FLElBQUksS0FBS21FLGlCQUFpQlEsWUFBWTtBQUFBLFVBQzlFO0FBQUEsUUFDRixPQUFPO0FBRUwsY0FBSVIsa0JBQWtCO0FBQ3BCYywwQkFBY2QsaUJBQWlCbkUsUUFBUTtBQUN2Q2tGLDhCQUFrQixHQUFHZixpQkFBaUJuRSxJQUFJLEtBQUttRSxpQkFBaUJRLFlBQVk7QUFBQSxVQUM5RSxXQUFXUCxTQUFTO0FBQ2xCYSwwQkFBY2IsUUFBUWdCLGFBQWE7QUFDbkNGLDhCQUFrQixHQUFHZCxRQUFRZ0IsU0FBUyxLQUFLaEIsUUFBUWlCLFVBQVU7QUFBQSxVQUMvRCxXQUFXZCxpQkFBaUIsT0FBTztBQUNqQ1UsMEJBQWNWO0FBQ2RXLDhCQUFrQixHQUFHWCxZQUFZLEdBQUdDLGdCQUFnQixLQUFLQSxhQUFhLE1BQU0sRUFBRTtBQUFBLFVBQ2hGO0FBQUEsUUFDRjtBQUVBLGVBQU87QUFBQSxVQUNMM0UsS0FBS2lFLEtBQUtqRTtBQUFBQSxVQUNWQyxJQUFJaUUsUUFBUTtBQUFBLFVBQ1p1QixXQUFXeEIsTUFBTXdCO0FBQUFBLFVBQ2pCQyxjQUFjdkIsa0JBQWtCaEUsUUFBUThELEtBQUszRCxZQUFZSCxRQUFRO0FBQUEsVUFDakV3RixjQUFjeEIsa0JBQWtCd0IsZ0JBQWdCMUIsS0FBSzNELFlBQVlxRixnQkFBZ0I7QUFBQSxVQUNqRm5GLFdBQVd5RCxLQUFLekQsYUFBYTtBQUFBLFVBQzdCTyxRQUFRa0QsS0FBS2xEO0FBQUFBLFVBQ2I2RSxjQUFjM0IsTUFBTS9DLGlCQUFpQjtBQUFBLFVBQ3JDMkUsVUFBVVI7QUFBQUEsVUFDVlgsY0FBY1U7QUFBQUE7QUFBQUEsVUFDZFUsZ0JBQWdCN0IsTUFBTTlDO0FBQUFBLFVBQ3RCNEUsY0FBYzlCLEtBQUsxRCxZQUFZUCxPQUFPaUUsS0FBSzFEO0FBQUFBLFVBQzNDeUUsWUFBWWYsS0FBSzdDLFVBQVVwQixPQUFPaUUsS0FBSzdDO0FBQUFBLFVBQ3ZDSSxRQUFReUMsS0FBS2pELE1BQU1oQixPQUFPaUUsS0FBS2pEO0FBQUFBLFVBQy9CSyxTQUFTNEMsS0FBSzVDLFdBQVc7QUFBQTtBQUFBLFVBQ3pCMkUsV0FBVy9CLEtBQUsrQjtBQUFBQSxVQUNoQnRGLFdBQVd1RCxLQUFLdkQ7QUFBQUEsVUFDaEJJLFNBQVNtRCxLQUFLbkQ7QUFBQUEsVUFDZG1GLFFBQ0U7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU07QUFBQSxnQkFDSkMsT0FBTztBQUFBLGtCQUNMLEVBQUVDLEtBQUssS0FBS0MsT0FBTyx1QkFBQyxTQUFJLFdBQVUsa0JBQWlCLFNBQVMsTUFBTUMsU0FBU3BDLElBQUksR0FBRyxvQkFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBbUUsRUFBTztBQUFBLGtCQUM3RixFQUFFa0MsS0FBSyxLQUFLQyxPQUFPLHVCQUFDLFNBQUksV0FBVSxnQkFBZSxTQUFTLE1BQU1FLGFBQWFyQyxLQUFLakUsR0FBRyxHQUFHLHNCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEyRSxFQUFPO0FBQUEsZ0JBQUM7QUFBQSxjQUUxRztBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVYsaUNBQUMsWUFBUyxXQUFVLG9CQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBO0FBQUEsWUFUdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBVUE7QUFBQSxRQUVKO0FBQUEsTUFDRixDQUFDO0FBRUR2QixvQkFBY3NGLFNBQVM7QUFDdkJwRix1QkFBaUJvRixTQUFTO0FBQzFCd0MsMkJBQXFCeEMsU0FBUztBQUFBLElBRWhDLFNBQVN5QyxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0sMkJBQTJCRixHQUFHO0FBQzVDN0QscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQ1QsbUJBQWEsS0FBSztBQUNsQkkscUJBQWUsS0FBSztBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUdBLFFBQU04RCx1QkFBdUJBLENBQUNJLGNBQWM7QUFDMUMsVUFBTXJILFFBQVFxSCxVQUFVQztBQUN4QixVQUFNckgsV0FBV29ILFVBQVVFLE9BQU8sQ0FBQTVDLFNBQVFBLEtBQUtsRCxXQUFXLGFBQWFrRCxLQUFLbEQsV0FBVyxhQUFhLEVBQUU2RjtBQUN0RyxVQUFNcEgsWUFBWW1ILFVBQVVFLE9BQU8sQ0FBQTVDLFNBQVFBLEtBQUtsRCxXQUFXLFdBQVcsRUFBRTZGO0FBQ3hFLFVBQU1uSCxVQUFVa0gsVUFBVUUsT0FBTyxDQUFBNUMsU0FBUUEsS0FBS2xELFdBQVcsU0FBUyxFQUFFNkY7QUFFcEV2SCxtQkFBZTtBQUFBLE1BQ2JDO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FDO0FBQUFBLE1BQ0FDO0FBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFHQSxRQUFNcUgsZUFBZUEsTUFBTTtBQUN6QixRQUFJQyxXQUFXLENBQUMsR0FBR3ZJLFVBQVU7QUFHN0IsUUFBSU0sZUFBZTtBQUNqQmlJLGlCQUFXQSxTQUFTRixPQUFPLENBQUE1QyxTQUFRQSxLQUFLOEIsaUJBQWlCakgsYUFBYTtBQUFBLElBQ3hFO0FBR0EsUUFBSUUsYUFBYUEsVUFBVSxDQUFDLEtBQUtBLFVBQVUsQ0FBQyxHQUFHO0FBQzdDLFlBQU0wQixZQUFZL0MsTUFBTXFCLFVBQVUsQ0FBQyxDQUFDLEVBQUVnSSxRQUFRLEtBQUs7QUFDbkQsWUFBTWxHLFVBQVVuRCxNQUFNcUIsVUFBVSxDQUFDLENBQUMsRUFBRWlJLE1BQU0sS0FBSztBQUUvQ0YsaUJBQVdBLFNBQVNGLE9BQU8sQ0FBQTVDLFNBQVE7QUFDakMsWUFBSSxDQUFDQSxLQUFLK0IsVUFBVyxRQUFPO0FBQzVCLGNBQU1rQixXQUFXdkosTUFBTXNHLEtBQUsrQixTQUFTO0FBQ3JDLGVBQU9rQixTQUFTQyxVQUFVekcsV0FBV0ksU0FBUyxNQUFNLElBQUk7QUFBQSxNQUMxRCxDQUFDO0FBQUEsSUFDSDtBQUdBLFFBQUk1QixZQUFZa0ksS0FBSyxHQUFHO0FBQ3RCLFlBQU1DLFFBQVFuSSxZQUFZaUcsWUFBWSxFQUFFaUMsS0FBSztBQUM3Q0wsaUJBQVdBLFNBQVNGO0FBQUFBLFFBQU8sQ0FBQTVDLFNBQ3pCQSxLQUFLNEIsU0FBU1YsWUFBWSxFQUFFRyxTQUFTK0IsS0FBSyxLQUMxQ3BELEtBQUt5QixhQUFhUCxZQUFZLEVBQUVHLFNBQVMrQixLQUFLLEtBQzlDcEQsS0FBS3pELFVBQVUyRSxZQUFZLEVBQUVHLFNBQVMrQixLQUFLO0FBQUEsTUFDN0M7QUFBQSxJQUNGO0FBRUExSSxxQkFBaUJvSSxRQUFRO0FBQ3pCUix5QkFBcUJRLFFBQVE7QUFBQSxFQUMvQjtBQUVBTyxZQUFVLE1BQU07QUFDZFIsaUJBQWE7QUFBQSxFQUNmLEdBQUcsQ0FBQ2hJLGVBQWVFLFdBQVdFLGFBQWFWLFVBQVUsQ0FBQztBQUd0RCxRQUFNK0ksY0FBYyxZQUFZO0FBQzlCLFFBQUk7QUFDRixZQUFNQyxXQUFXLE1BQU12SyxJQUFJc0csSUFBSSxrQkFBa0I7QUFDakQsWUFBTUMsYUFBYUMsTUFBTUMsUUFBUThELFNBQVM3RCxJQUFJLElBQzFDNkQsU0FBUzdELE9BQ1Q2RCxTQUFTN0QsTUFBTUMsU0FBUztBQUM1QjNGLGdCQUFVdUYsVUFBVTtBQUFBLElBQ3RCLFNBQVNnRCxLQUFLO0FBQ1pDLGNBQVFDLE1BQU0seUJBQXlCRixHQUFHO0FBQUEsSUFDNUM7QUFBQSxFQUNGO0FBRUFjLFlBQVUsTUFBTTtBQUNkQyxnQkFBWTtBQUFBLEVBQ2QsR0FBRyxFQUFFO0FBRUxELFlBQVUsTUFBTTtBQUNkdkUsaUJBQWE7QUFBQSxFQUNmLEdBQUcsQ0FBQ2YsYUFBYSxDQUFDO0FBRWxCLFFBQU15RixtQkFBbUJBLENBQUN0SCxNQUFNdUgsVUFBVTtBQUN4Q3JILGdCQUFZLENBQUNzSCxTQUFTO0FBQ3BCLFlBQU1DLFVBQVUsRUFBRSxHQUFHRCxNQUFNLENBQUN4SCxJQUFJLEdBQUd1SCxNQUFNO0FBRXpDLFVBQUl2SCxTQUFTLGlCQUFpQjtBQUU1QnlILGdCQUFRNUcsT0FBTztBQUVmNEcsZ0JBQVF4RyxXQUFXO0FBR25CLFlBQUlzRyxVQUFVLFFBQVE7QUFDcEJFLGtCQUFRcEgsWUFBWTtBQUFBLFFBQ3RCLFdBQVdrSCxVQUFVLFlBQVk7QUFDL0JFLGtCQUFRcEgsWUFBWTtBQUFBLFFBQ3RCLFdBQVdrSCxVQUFVLFlBQVk7QUFDL0JFLGtCQUFRcEgsWUFBWTtBQUFBLFFBQ3RCLE9BQU87QUFDTG9ILGtCQUFRcEgsWUFBWTtBQUFBLFFBQ3RCO0FBQUEsTUFDRjtBQUVBLGFBQU9vSDtBQUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBRUFOLFlBQVUsTUFBTTtBQUNkLFFBQUlsSCxTQUFTYyxrQkFBa0IsUUFBUTtBQUNyQ2Isa0JBQVksQ0FBQXNILFVBQVM7QUFBQSxRQUNuQixHQUFHQTtBQUFBQSxRQUNIbkgsV0FBVztBQUFBLE1BQ2IsRUFBRTtBQUFBLElBQ0osV0FBV0osU0FBU2Msa0JBQWtCLFlBQVk7QUFDaERiLGtCQUFZLENBQUFzSCxVQUFTO0FBQUEsUUFDbkIsR0FBR0E7QUFBQUEsUUFDSG5ILFdBQVc7QUFBQSxNQUNiLEVBQUU7QUFBQSxJQUNKLFdBQVdKLFNBQVNjLGtCQUFrQixZQUFZO0FBQ2hEYixrQkFBWSxDQUFBc0gsVUFBUztBQUFBLFFBQ25CLEdBQUdBO0FBQUFBLFFBQ0huSCxXQUFXO0FBQUEsTUFDYixFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0YsR0FBRyxDQUFDSixTQUFTYyxhQUFhLENBQUM7QUFFM0IsUUFBTTJHLGNBQWNBLENBQUNDLE1BQU07QUFDekIsVUFBTSxFQUFFM0gsTUFBTXVILE1BQU0sSUFBSUksRUFBRUM7QUFDMUIxSCxnQkFBWSxDQUFDc0gsVUFBVSxFQUFFLEdBQUdBLE1BQU0sQ0FBQ3hILElBQUksR0FBR3VILE1BQU0sRUFBRTtBQUFBLEVBQ3BEO0FBRUEsUUFBTU0sZUFBZSxPQUFPRixNQUFNO0FBQ2hDQSxNQUFFRyxlQUFlO0FBRWpCLFFBQUk7QUFFRixVQUFJLENBQUM3SCxTQUFTYyxlQUFlO0FBQzNCeUIsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFDRDtBQUFBLE1BQ0Y7QUFHQSxVQUFJLENBQUMxQyxTQUFTRyxZQUFZO0FBQ3hCb0MsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFDRDtBQUFBLE1BQ0Y7QUFHQSxVQUFJMUMsU0FBU2Msa0JBQWtCLFVBQVUsQ0FBQ2QsU0FBU1ksTUFBTTtBQUN2RDJCLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQ0Q7QUFBQSxNQUNGO0FBR0EsVUFBSTFDLFNBQVNjLGtCQUFrQixjQUFjLENBQUNkLFNBQVNnQixVQUFVO0FBQy9EdUIsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFDRDtBQUFBLE1BQ0Y7QUFHQSxVQUFJLENBQUMxQyxTQUFTSyxpQkFBaUIyRyxLQUFLLEdBQUc7QUFDckN6RSx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUNEO0FBQUEsTUFDRjtBQUdBLFVBQUksQ0FBQzFDLFNBQVNNLFdBQVc7QUFDdkJpQyx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUNEO0FBQUEsTUFDRjtBQUdBLFVBQUksQ0FBQzFDLFNBQVNFLFlBQVk7QUFDeEJxQyx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUNEO0FBQUEsTUFDRjtBQUVBLFlBQU1vRixVQUFVLEVBQUUsR0FBRzlILFNBQVM7QUFHOUIsYUFBTzhILFFBQVFwSDtBQUNmLGFBQU9vSCxRQUFRL0c7QUFHZixVQUFJK0csUUFBUWhILGtCQUFrQixRQUFRO0FBQ3BDLGVBQU9nSCxRQUFROUc7QUFBQUEsTUFDakIsV0FBVzhHLFFBQVFoSCxrQkFBa0IsWUFBWTtBQUMvQyxlQUFPZ0gsUUFBUWxIO0FBQ2YsZUFBT2tILFFBQVE5RztBQUFBQSxNQUNqQixXQUFXOEcsUUFBUWhILGtCQUFrQixZQUFZO0FBQy9DLGVBQU9nSCxRQUFRbEg7QUFBQUEsTUFDakI7QUFJQW1ILGFBQU9DLEtBQUtGLE9BQU8sRUFBRUcsUUFBUSxDQUFBbEMsUUFBTztBQUNsQyxjQUFNbUMsZ0JBQWdCLENBQUMsY0FBYyxhQUFhLG1CQUFtQixXQUFXO0FBQ2hGLFlBQ0UsQ0FBQ0EsY0FBY2hELFNBQVNhLEdBQUcsTUFDMUIrQixRQUFRL0IsR0FBRyxNQUFNLE1BQU0rQixRQUFRL0IsR0FBRyxNQUFNLFFBQVErQixRQUFRL0IsR0FBRyxNQUFNb0MsU0FDbEU7QUFDQSxpQkFBT0wsUUFBUS9CLEdBQUc7QUFBQSxRQUNwQjtBQUFBLE1BQ0YsQ0FBQztBQUdELFVBQUlqRSxhQUFhO0FBQ2YsY0FBTWpGLElBQUl1TCxJQUFJLHFCQUFxQnRHLFdBQVcsSUFBSWdHLE9BQU87QUFDekR2Rix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUNEYix5QkFBaUIsQ0FBQzBGLFNBQVNBLE9BQU8sQ0FBQztBQUFBLE1BQ3JDLE9BQU87QUFDTCxjQUFNYyxNQUFNLE1BQU14TCxJQUFJeUwsS0FBSyxzQkFBc0JSLE9BQU87QUFDeER6QixnQkFBUWtDLEtBQUtGLElBQUk5RSxNQUFNLFNBQVM7QUFDaENoQix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BRUg7QUFFQWYsc0JBQWdCLEtBQUs7QUFDckI2RyxnQkFBVTtBQUNWM0csdUJBQWlCLENBQUMwRixTQUFTQSxPQUFPLENBQUM7QUFBQSxJQUNyQyxTQUFTbkIsS0FBSztBQUNaQyxjQUFRQyxNQUFNLHdCQUF3QkYsSUFBSWdCLFVBQVU3RCxRQUFRNkMsSUFBSTNELE9BQU87QUFDdkVGLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVMyRCxJQUFJZ0IsVUFBVTdELE1BQU1kLFdBQVc7QUFBQSxRQUN4Q0MsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTThGLFlBQVlBLE1BQU07QUFDdEJ2SSxnQkFBWTtBQUFBLE1BQ1ZDLFlBQVlQLG1CQUFtQjtBQUFBLE1BQy9CUSxZQUFZO0FBQUEsTUFDWkMsV0FBVztBQUFBLE1BQ1hDLGlCQUFpQjtBQUFBLE1BQ2pCQyxZQUFXLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUU7QUFBQSxNQUMvQ0MsU0FBUztBQUFBLE1BQ1RDLFFBQVE7QUFBQSxNQUNSQyxNQUFNO0FBQUEsTUFDTkUsZUFBZTtBQUFBO0FBQUEsTUFDZkMsaUJBQWlCO0FBQUEsTUFDakJDLFVBQVU7QUFBQSxJQUNaLENBQUM7QUFDRGUsbUJBQWUsSUFBSTtBQUFBLEVBQ3JCO0FBRUEsUUFBTWtFLFdBQVdBLENBQUNwQyxTQUFTO0FBRXpCOUIsbUJBQWU4QixLQUFLakUsR0FBRztBQU92QkssZ0JBQVk7QUFBQSxNQUNWQyxZQUFZMkQsS0FBSzNELFlBQVlOLE9BQU9pRSxLQUFLM0QsY0FBY1A7QUFBQUEsTUFDdkRRLFlBQVkwRCxLQUFLMUQsWUFBWVAsT0FBT2lFLEtBQUsxRCxjQUFjO0FBQUEsTUFDdkRXLGVBQWUrQyxNQUFNL0M7QUFBQUEsTUFDckJGLE1BQU1pRCxLQUFLakQsTUFBTWhCLE9BQU9pRSxLQUFLakQsUUFBUTtBQUFBLE1BQ3JDSSxVQUFVNkMsS0FBSzdDLFVBQVVwQixPQUFPaUUsS0FBSzdDLFlBQVk7QUFBQSxNQUNqREgsVUFBVWdELEtBQUtoRCxVQUFVakIsT0FBT2lFLEtBQUtoRCxZQUFZO0FBQUEsTUFDakRJLFNBQVM0QyxLQUFLNUMsV0FBVztBQUFBLE1BQ3pCYixXQUFXeUQsS0FBS3pELGFBQWE7QUFBQSxNQUM3QkMsaUJBQWlCd0QsS0FBS3hELG1CQUFtQjtBQUFBLE1BQ3pDQyxXQUFXdUQsS0FBS3ZELFdBQVdHLE1BQU0sR0FBRyxFQUFFLEtBQUs7QUFBQSxNQUMzQ0MsU0FBU21ELEtBQUtuRCxTQUFTRCxNQUFNLEdBQUcsRUFBRSxLQUFLO0FBQUEsTUFDdkNFLFFBQVFrRCxLQUFLbEQsVUFBVTtBQUFBLE1BQ3ZCSSxpQkFBaUI4QyxNQUFNOUMsbUJBQW1CO0FBQUEsSUFDNUMsQ0FBQztBQUVEWSxvQkFBZ0IsSUFBSTtBQUFBLEVBQ3RCO0FBRUEsUUFBTXVFLGVBQWUsT0FBT3JHLE9BQU87QUFDakMsUUFBSTtBQUVGc0Msb0JBQWMsSUFBSTtBQUdsQkkscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFHRCxZQUFNN0YsSUFBSTRMLE9BQU8scUJBQXFCNUksRUFBRSxFQUFFO0FBRzFDMEMscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFHRGIsdUJBQWlCLENBQUMwRixTQUFTQSxPQUFPLENBQUM7QUFBQSxJQUNyQyxTQUFTbkIsS0FBSztBQUNaN0QscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUztBQUFBLFFBQ1RDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFFQ1Asb0JBQWMsS0FBSztBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUdBLFFBQU11RyxlQUFlQSxNQUFNO0FBQ3pCL0oscUJBQWlCLElBQUk7QUFDckJFLGlCQUFhLElBQUk7QUFDakJFLG1CQUFlLEVBQUU7QUFBQSxFQUNuQjtBQUVBLFFBQU00SixVQUFVO0FBQUEsSUFDZCxFQUFFNUMsS0FBSyxNQUFNNkMsUUFBUSxRQUFRO0FBQUEsSUFDN0IsRUFBRTdDLEtBQUssYUFBYTZDLFFBQVEsWUFBWTtBQUFBLElBQ3hDLEVBQUU3QyxLQUFLLGdCQUFnQjZDLFFBQVEsY0FBYztBQUFBLElBQzdDLEVBQUU3QyxLQUFLLGdCQUFnQjZDLFFBQVEsY0FBYztBQUFBLElBQzdDLEVBQUU3QyxLQUFLLGFBQWE2QyxRQUFRLFlBQVk7QUFBQSxJQUV4QyxFQUFFN0MsS0FBSyxnQkFBZ0I2QyxRQUFRLGdCQUFnQjtBQUFBLElBQy9DLEVBQUU3QyxLQUFLLFlBQVk2QyxRQUFRLGNBQWM7QUFBQSxJQUN6QyxFQUFFN0MsS0FBSyxnQkFBZ0I2QyxRQUFRLGtDQUFrQztBQUFBO0FBQUEsSUFDakUsRUFBRTdDLEtBQUssVUFBVTZDLFFBQVEsY0FBYztBQUFBO0FBQUEsSUFFdkMsRUFBRTdDLEtBQUssVUFBVTZDLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsVUFBTyxZQUFZLFFBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUI7QUFBQSxNQUN6QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBTXRHLFlBQVlJO0FBQUFBLFVBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFVBQ3JCLFNBQVMsTUFDUEYsZUFBZSxDQUFDZ0YsVUFBVSxFQUFFLEdBQUdBLE1BQU0vRSxZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUVILHVCQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRO0FBQUEsTUFFUix1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsYUFDYixpQ0FBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEJBQXlCLHFCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QztBQUFBLFVBQzVDO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU07QUFDYmIsZ0NBQWdCLElBQUk7QUFDcEI2RywwQkFBVTtBQUFBLGNBQ1o7QUFBQSxjQUNBLFdBQVU7QUFBQSxjQUFtRztBQUFBO0FBQUEsWUFML0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxhQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQSxLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDZEQUNiLGlDQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxPQUFFLFdBQVUscUNBQW9DLDJCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUE0RDtBQUFBLGNBQzVELHVCQUFDLE9BQUUsV0FBVSxvQ0FBb0N4SixzQkFBWUUsU0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBbUU7QUFBQSxpQkFGckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiLGlDQUFDLFNBQUksV0FBVSx5QkFBd0IsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUMvRSxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLHFJQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUF1TSxLQUR6TTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSwrREFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLHFDQUFvQyx3QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxjQUN6RCx1QkFBQyxPQUFFLFdBQVUsb0NBQW9DRixzQkFBWUcsWUFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBc0U7QUFBQSxpQkFGeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGtDQUNiLGlDQUFDLFNBQUksV0FBVSwyQkFBMEIsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNqRixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLGlEQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtSCxLQURySDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSw4REFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLHFDQUFvQyx5QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEQ7QUFBQSxjQUMxRCx1QkFBQyxPQUFFLFdBQVUsb0NBQW9DSCxzQkFBWUksYUFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBdUU7QUFBQSxpQkFGekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLGlDQUNiLGlDQUFDLFNBQUksV0FBVSwwQkFBeUIsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNoRixpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLG1EQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxSCxLQUR2SDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSw0REFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQSxtQ0FBQyxTQUNDO0FBQUEscUNBQUMsT0FBRSxXQUFVLHFDQUFvQyx1QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0Q7QUFBQSxjQUN4RCx1QkFBQyxPQUFFLFdBQVUsb0NBQW9DSixzQkFBWUssV0FBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcUU7QUFBQSxpQkFGdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLCtCQUNiLGlDQUFDLFNBQUksV0FBVSx3QkFBdUIsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUM5RSxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQVksS0FBSSxHQUFFLGlEQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFtSCxLQURySDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJQTtBQUFBLGVBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWUE7QUFBQSxhQXZERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0RBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsdUNBQ2IsaUNBQUMsU0FBSSxXQUFVLG1EQUNiO0FBQUEsaUNBQUMsU0FDQztBQUFBLG1DQUFDLFdBQU0sV0FBVSxnREFBK0MsK0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStFO0FBQUEsWUFDL0U7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsYUFBWTtBQUFBLGdCQUNaO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQSxPQUFPWDtBQUFBQSxnQkFDUCxVQUFVLENBQUM0SSxVQUFVM0ksaUJBQWlCMkksS0FBSztBQUFBLGdCQUMzQyxrQkFBaUI7QUFBQSxnQkFDakIsY0FBYyxDQUFDdUIsT0FBT0MsV0FBVztBQUMvQix3QkFBTUMsV0FBV0QsUUFBUUUsT0FBT0QsVUFBVUUsU0FBUyxLQUFLO0FBQ3hELHlCQUFPRixTQUFTaEUsWUFBWSxFQUFFRyxTQUFTMkQsTUFBTTlELFlBQVksQ0FBQztBQUFBLGdCQUM1RDtBQUFBLGdCQUVDbkgsaUJBQU9nRztBQUFBQSxrQkFBSSxDQUFDSixVQUNYLHVCQUFDLFVBQXVCLE9BQU9BLE1BQU01RCxLQUNsQzREO0FBQUFBLDBCQUFNekQ7QUFBQUEsb0JBQUs7QUFBQSxvQkFBSXlELE1BQU1rQjtBQUFBQSx1QkFEWGxCLE1BQU01RCxLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsZ0JBQ0Q7QUFBQTtBQUFBLGNBakJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQWtCQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUJBO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQywwQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBMEU7QUFBQSxZQUMxRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixVQUFVLENBQUNzSixVQUFVckssYUFBYXFLLEtBQUs7QUFBQSxnQkFDdkMsUUFBTztBQUFBO0FBQUEsY0FIVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHcUI7QUFBQSxlQUx2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFFQSx1QkFBQyxTQUNDO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQyxzQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBc0U7QUFBQSxZQUN0RTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLGFBQVk7QUFBQSxnQkFDWixPQUFPcEs7QUFBQUEsZ0JBQ1AsVUFBVSxDQUFDNEksTUFBTTNJLGVBQWUySSxFQUFFQyxPQUFPTCxLQUFLO0FBQUEsZ0JBQzlDLFFBQVEsdUJBQUMsY0FBVyxXQUFVLG1CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFxQztBQUFBLGdCQUM3QztBQUFBLGdCQUNBLFdBQVU7QUFBQTtBQUFBLGNBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTW9CO0FBQUEsZUFSdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVNvQjtBQUFBQSxjQUNULFdBQVU7QUFBQSxjQUF1RjtBQUFBO0FBQUEsWUFGbkc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsYUFwREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFEQSxLQXRERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdURBO0FBQUEsUUFPQ3RHLGVBQWVKLFlBQ2Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxTQUFTLENBQUNBO0FBQUFBLFlBQ1YsTUFBSztBQUFBO0FBQUEsVUFIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFHa0IsSUFHbEIsbUNBRUdFO0FBQUFBLHdCQUNDLHVCQUFDLFNBQUksV0FBVSw4RUFDYixpQ0FBQyxTQUFJLFdBQVUscUNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVc7QUFBQSxnQkFDWCxTQUFTO0FBQUEsZ0JBQ1QsTUFBSztBQUFBO0FBQUEsY0FIUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHeUI7QUFBQSxZQUV6Qix1QkFBQyxPQUFFLFdBQVUsa0NBQWlDLGdDQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE4RDtBQUFBLGVBTmhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVNBO0FBQUEsVUFFRjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsZUFBZSxDQUFDckMsT0FBT29HLFNBQVMvSCxNQUFNOEYsS0FBSyxDQUFDbUYsTUFBTUEsRUFBRXZKLFFBQVFDLEVBQUUsQ0FBQztBQUFBLGNBQy9ELE1BQU12QjtBQUFBQSxjQUNOO0FBQUEsY0FDQSxpQkFBZ0I7QUFBQSxjQUNoQixrQkFBaUI7QUFBQTtBQUFBLFlBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUs4QjtBQUFBLGFBbkJoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUJBO0FBQUEsV0F0S0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdLQTtBQUFBLFNBcExGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxTEE7QUFBQSxJQUdBLHVCQUFDLFNBQU0sV0FBV29ELGNBQWMsU0FBUyxNQUFNQyxnQkFBZ0IsS0FBSyxHQUNsRSxpQ0FBQyxTQUFJLFdBQVUsK0RBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsc0NBQ2I7QUFBQSwrQkFBQyxRQUFHLFdBQVUsbUNBQ1hHLHdCQUFjLGdCQUFnQixjQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw4QkFDVkEsd0JBQ0csd0RBQ0EsbUNBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUVBLHVCQUFDLFVBQUssVUFBVThGLGNBQWMsV0FBVSxhQUV0QztBQUFBLCtCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsWUFDL0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLGVBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPOUgscUJBQXFCO0FBQUEsY0FDNUI7QUFBQSxjQUNBLFdBQVU7QUFBQTtBQUFBLFlBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBSTJJO0FBQUEsVUFFM0k7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU9IO0FBQUFBO0FBQUFBLFlBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBR3lCO0FBQUEsYUFiM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLFlBQy9DLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxlQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBLGNBQ1o7QUFBQSxjQUNBLE1BQUs7QUFBQSxjQUNMLGtCQUFpQjtBQUFBLGNBQ2pCLGNBQWMsQ0FBQ2tKLE9BQU9DLFdBQVc7QUFDL0Isc0JBQU1DLFdBQVdELFFBQVFFLE9BQU9ELFVBQVVFLFNBQVMsS0FBSztBQUN4RCx1QkFBT0YsU0FBU2hFLFlBQVksRUFBRUcsU0FBUzJELE1BQU05RCxZQUFZLENBQUM7QUFBQSxjQUM1RDtBQUFBLGNBQ0EsT0FBTy9FLFNBQVNHLGNBQWNnSTtBQUFBQSxjQUM5QixVQUFVLENBQUNiLFVBQVVELGlCQUFpQixjQUFjQyxLQUFLO0FBQUEsY0FFeEQxSixpQkFBTzRJLFNBQVMsSUFDZjVJLE9BQU9nRztBQUFBQSxnQkFBSSxDQUFDSixVQUNWLHVCQUFDLFVBQXVCLE9BQU9BLE1BQU01RCxLQUNsQzREO0FBQUFBLHdCQUFNekQ7QUFBQUEsa0JBQUs7QUFBQSxrQkFBSXlELE1BQU1rQjtBQUFBQSxxQkFEWGxCLE1BQU01RCxLQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRCxJQUVELHVCQUFDLFVBQU8sT0FBTSxJQUFHLG1DQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFvQztBQUFBO0FBQUEsWUFwQnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQXNCQTtBQUFBLFVBQ0NoQyxPQUFPNEksV0FBVyxLQUNqQix1QkFBQyxPQUFFLFdBQVUsK0JBQThCLHlEQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUE5Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdDQTtBQUFBLFFBR0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxZQUNsRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUEsZUFEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaO0FBQUEsY0FDQSxNQUFLO0FBQUEsY0FDTCxrQkFBaUI7QUFBQSxjQUNqQixjQUFjLENBQUNxQyxPQUFPQyxXQUFXO0FBQy9CLHNCQUFNQyxXQUFXRCxRQUFRRSxPQUFPRCxVQUFVRSxTQUFTLEtBQUs7QUFDeEQsdUJBQU9GLFNBQVNoRSxZQUFZLEVBQUVHLFNBQVMyRCxNQUFNOUQsWUFBWSxDQUFDO0FBQUEsY0FDNUQ7QUFBQSxjQUNBLE9BQU8vRSxTQUFTYyxpQkFBaUJxSDtBQUFBQSxjQUNqQyxVQUFVLENBQUNiLFVBQVVELGlCQUFpQixpQkFBaUJDLEtBQUs7QUFBQSxjQUM1RCxRQUFRLENBQUN0SCxTQUFTYyxpQkFBaUJkLFNBQVNjLGtCQUFrQixLQUFLLFVBQVU7QUFBQSxjQUU3RTtBQUFBLHVDQUFDLFVBQU8sT0FBTSxRQUFPLG9CQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF5QjtBQUFBLGdCQUN6Qix1QkFBQyxVQUFPLE9BQU0sWUFBVyx3QkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQSxnQkFDakMsdUJBQUMsVUFBTyxPQUFNLFlBQVcsd0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWlDO0FBQUE7QUFBQTtBQUFBLFlBaEJuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFpQkE7QUFBQSxhQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsUUFHQ2QsU0FBU2Msa0JBQWtCLFVBQzFCLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsa0RBQWlELDJCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1Y7QUFBQSxjQUNBLHVCQUF1QjtBQUFBLGNBQ3ZCLGFBQVk7QUFBQSxjQUNaLE1BQUs7QUFBQSxjQUNMLGtCQUFpQjtBQUFBLGNBQ2pCLGNBQWMsQ0FBQytILE9BQU9DLFdBQVc7QUFDL0Isc0JBQU1DLFdBQVdELFFBQVFFLE9BQU9ELFVBQVVFLFNBQVMsS0FBSztBQUN4RCx1QkFBT0YsU0FBU2hFLFlBQVksRUFBRUcsU0FBUzJELE1BQU05RCxZQUFZLENBQUM7QUFBQSxjQUM1RDtBQUFBLGNBQ0EsT0FBTy9FLFNBQVNZLFFBQVF1SDtBQUFBQSxjQUN4QixVQUFVLENBQUNiLFVBQVVELGlCQUFpQixRQUFRQyxLQUFLO0FBQUEsY0FFbER4SixnQkFBTThGO0FBQUFBLGdCQUFJLENBQUNRLE1BQ1YsdUJBQUMsVUFBbUIsT0FBT0EsRUFBRXhFLEtBQzFCd0U7QUFBQUEsb0JBQUVlO0FBQUFBLGtCQUFVO0FBQUEsa0JBQUlmLEVBQUVnQjtBQUFBQSxxQkFEUmhCLEVBQUV4RSxLQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUE7QUFBQSxZQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFJREksU0FBU2Msa0JBQWtCLGNBQzFCLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsa0RBQWlELCtCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1Y7QUFBQSxjQUNBLGFBQVk7QUFBQSxjQUNaLE1BQUs7QUFBQSxjQUNMLGtCQUFpQjtBQUFBLGNBQ2pCLGNBQWMsQ0FBQytILE9BQU9DLFdBQVc7QUFDL0Isc0JBQU1DLFdBQVdELFFBQVFFLE9BQU9ELFVBQVVFLFNBQVMsS0FBSztBQUN4RCx1QkFBT0YsU0FBU2hFLFlBQVksRUFBRUcsU0FBUzJELE1BQU05RCxZQUFZLENBQUM7QUFBQSxjQUM1RDtBQUFBLGNBQ0EsT0FBTy9FLFNBQVNhLFlBQVlzSDtBQUFBQSxjQUM1QixVQUFVLENBQUNiLFVBQVVELGlCQUFpQixZQUFZQyxLQUFLO0FBQUEsY0FFdEQxSixpQkFBT2dHO0FBQUFBLGdCQUFJLENBQUNLLE1BQ1gsdUJBQUMsVUFBbUIsT0FBT0EsRUFBRXJFLEtBQzFCcUU7QUFBQUEsb0JBQUVsRTtBQUFBQSxrQkFBSztBQUFBLGtCQUFJa0UsRUFBRVM7QUFBQUEscUJBREhULEVBQUVyRSxLQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUE7QUFBQSxZQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFrQkE7QUFBQSxhQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsUUFJREksU0FBU2Msa0JBQWtCLGNBQzFCLHVCQUFDLFNBQ0M7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsa0RBQWlELCtCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1Y7QUFBQSxjQUNBLHVCQUF1QjtBQUFBLGNBQ3ZCLGFBQVk7QUFBQSxjQUNaLE1BQUs7QUFBQSxjQUNMLGtCQUFpQjtBQUFBLGNBQ2pCLGNBQWMsQ0FBQytILE9BQU9DLFdBQVc7QUFDL0Isc0JBQU1DLFdBQVdELFFBQVFFLE9BQU9ELFVBQVVFLFNBQVMsS0FBSztBQUN4RCx1QkFBT0YsU0FBU2hFLFlBQVksRUFBRUcsU0FBUzJELE1BQU05RCxZQUFZLENBQUM7QUFBQSxjQUM1RDtBQUFBLGNBQ0EsT0FBTy9FLFNBQVNnQixZQUFZbUg7QUFBQUEsY0FDNUIsVUFBVSxDQUFDYixVQUFVRCxpQkFBaUIsWUFBWUMsS0FBSztBQUFBLGNBRXREdEosb0JBQVU0RjtBQUFBQSxnQkFBSSxDQUFDaUIsTUFDZCx1QkFBQyxVQUFtQixPQUFPQSxFQUFFakYsS0FDMUJpRjtBQUFBQSxvQkFBRUwsYUFBYUssRUFBRTlFLFFBQVE7QUFBQSxrQkFBVTtBQUFBLGtCQUFJOEUsRUFBRUgsZ0JBQWdCRyxFQUFFSixTQUFTSSxFQUFFRixVQUFVO0FBQUEscUJBRHRFRSxFQUFFakYsS0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBSUYsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxZQUNuRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUEsZUFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaO0FBQUEsY0FDQSxNQUFLO0FBQUEsY0FDTCxrQkFBaUI7QUFBQSxjQUNqQixjQUFjLENBQUNpSixPQUFPQyxXQUFXO0FBQy9CLHNCQUFNQyxXQUFXRCxRQUFRRSxPQUFPRCxVQUFVRSxTQUFTLEtBQUs7QUFDeEQsdUJBQU9GLFNBQVNoRSxZQUFZLEVBQUVHLFNBQVMyRCxNQUFNOUQsWUFBWSxDQUFDO0FBQUEsY0FDNUQ7QUFBQSxjQUNBLE9BQU8vRSxTQUFTaUIsV0FBV2tIO0FBQUFBLGNBQzNCLFVBQVUsQ0FBQ2IsVUFBVUQsaUJBQWlCLFdBQVdDLEtBQUs7QUFBQSxjQUV0RDtBQUFBLHVDQUFDLFVBQU8sT0FBTSxrQkFBaUIsOEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZDO0FBQUEsZ0JBQzdDLHVCQUFDLFVBQU8sT0FBTSxhQUFZLHlCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFtQztBQUFBLGdCQUNuQyx1QkFBQyxVQUFPLE9BQU0sZ0JBQWUsNEJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXlDO0FBQUEsZ0JBQ3pDLHVCQUFDLFVBQU8sT0FBTSxXQUFVLHVCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUErQjtBQUFBLGdCQUMvQix1QkFBQyxVQUFPLE9BQU0sV0FBVSx1QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0I7QUFBQSxnQkFDL0IsdUJBQUMsVUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTJCO0FBQUE7QUFBQTtBQUFBLFlBbEI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFHQSx1QkFBQyxTQUNDO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGtEQUFpRDtBQUFBO0FBQUEsWUFDL0MsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLGVBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxPQUFPdEgsU0FBU0s7QUFBQUEsY0FDaEIsVUFBVW9IO0FBQUFBLGNBQ1YsTUFBSztBQUFBLGNBQ0wsYUFBWTtBQUFBLGNBQ1osV0FBVTtBQUFBLGNBQ1YsVUFBUTtBQUFBO0FBQUEsWUFQVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPVTtBQUFBLGFBWFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2IsaUNBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxpQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxZQUM5Qyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDO0FBQUEsZUFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLE1BQUs7QUFBQSxjQUNMLE9BQU96SCxTQUFTTTtBQUFBQSxjQUNoQixVQUFVbUg7QUFBQUEsY0FDVixXQUFVO0FBQUEsY0FDVixVQUFRO0FBQUE7QUFBQSxZQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1VO0FBQUEsYUFWWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUEsS0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBY0E7QUFBQSxRQStCQSx1QkFBQyxTQUFJLFdBQVUsa0RBQ2I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFdBQVU7QUFBQSxZQUF1UDtBQUFBO0FBQUEsVUFGblE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQTFRRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMlFBO0FBQUEsU0F2UkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdSQSxLQXpSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMFJBO0FBQUEsT0FuZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFkQTtBQUVKO0FBQUU5SixHQXpoQ0lELE1BQUk7QUFBQSxVQTRDU0osV0FBVztBQUFBO0FBQUE4TCxLQTVDeEIxTDtBQTJoQ04sZUFBZUE7QUFBSyxJQUFBMEw7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiU2lkZWJhciIsIk5hdmJhciIsIk1vZGFsIiwiRGF0YVRhYmxlIiwiYXBpIiwiQ2lyY3VsYXJMb2FkZXIiLCJEcm9wZG93biIsIlNlbGVjdCIsIkRhdGVQaWNrZXIiLCJJbnB1dCIsIklvTWRNb3JlIiwiSW9NZFNlYXJjaCIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwidXNlTG9jYXRpb24iLCJkYXlqcyIsIk9wdGlvbiIsIlJhbmdlUGlja2VyIiwiVGFzayIsIl9zIiwiYWdlbnRzIiwic2V0QWdlbnRzIiwibGVhZHMiLCJzZXRMZWFkcyIsImN1c3RvbWVycyIsInNldEN1c3RvbWVycyIsInRhc2tzIiwic2V0VGFza3MiLCJ0YWJsZVRhc2tzIiwic2V0VGFibGVUYXNrcyIsImZpbHRlcmVkVGFza3MiLCJzZXRGaWx0ZXJlZFRhc2tzIiwiYWRtaW5zIiwic2V0QWRtaW5zIiwic2VsZWN0ZWRBZ2VudCIsInNldFNlbGVjdGVkQWdlbnQiLCJkYXRlUmFuZ2UiLCJzZXREYXRlUmFuZ2UiLCJzZWFyY2hRdWVyeSIsInNldFNlYXJjaFF1ZXJ5Iiwic3RhdHVzQ2FyZHMiLCJzZXRTdGF0dXNDYXJkcyIsInRvdGFsIiwiYXNzaWduZWQiLCJjb21wbGV0ZWQiLCJwZW5kaW5nIiwibG9nZ2VkSW5Vc2VyIiwiSlNPTiIsInBhcnNlIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsImxvZ2dlZEluQWRtaW5JZCIsIl9pZCIsImlkIiwibG9nZ2VkSW5BZG1pbk5hbWUiLCJuYW1lIiwiZm9ybURhdGEiLCJzZXRGb3JtRGF0YSIsImFzc2lnbmVkQnkiLCJhc3NpZ25lZFRvIiwidGFza1RpdGxlIiwidGFza0Rlc2NyaXB0aW9uIiwic3RhcnREYXRlIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic2xpY2UiLCJlbmREYXRlIiwic3RhdHVzIiwibGVhZCIsImVtcGxveWVlIiwicmVmZXJyZWRfdHlwZSIsImFwcHJvdmFsX3N0YXR1cyIsImN1c3RvbWVyIiwicHVycG9zZSIsImN1c3RvbVB1cnBvc2UiLCJsb2NhdGlvbiIsImxlYWRJZCIsImxlYWRBZ2VudElkIiwic3RhdGUiLCJsZWFkSWRTdGF0ZSIsInNldExlYWRJZFN0YXRlIiwibGVhZEFnZW50SWRTdGF0ZSIsIm1vZGFsVmlzaWJsZSIsInNldE1vZGFsVmlzaWJsZSIsInJlbG9hZFRyaWdnZXIiLCJzZXRSZWxvYWRUcmlnZ2VyIiwiY3VycmVudFRhc2siLCJzZXRDdXJyZW50VGFzayIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImlzRGVsZXRpbmciLCJzZXRJc0RlbGV0aW5nIiwiaW5pdGlhbExvYWQiLCJzZXRJbml0aWFsTG9hZCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJmZXRjaEFsbERhdGEiLCJhZ2VudFJlcyIsImxlYWRSZXMiLCJ0YXNrUmVzIiwiY3VzdG9tZXJSZXMiLCJhZG1pblJlcyIsIlByb21pc2UiLCJhbGwiLCJnZXQiLCJhZ2VudHNMaXN0IiwiQXJyYXkiLCJpc0FycmF5IiwiZGF0YSIsImFnZW50IiwiYWRtaW5zTGlzdCIsImFsbEFzc2lnbmVycyIsImZvcm1hdHRlZCIsIm1hcCIsInRhc2siLCJpbmRleCIsImFzc2lnbmVkQnlQZXJzb24iLCJmaW5kIiwiYSIsImFzc2lnbmVkVG9QZXJzb24iLCJyZWZMZWFkIiwibCIsInJlZkN1c3RvbWVyIiwiY3VzdG9tZXJOYW1lIiwiY3VzdG9tZXJQaG9uZSIsImZ1bGxfbmFtZSIsInBob25lIiwicGhvbmVfbnVtYmVyIiwibW9iaWxlIiwiY3VzdG9tZXJJZCIsImMiLCJ0eXBlTG93ZXIiLCJ0b0xvd2VyQ2FzZSIsImNvbnRhY3ROYW1lIiwicmVmZXJyZWREaXNwbGF5IiwiaW5jbHVkZXMiLCJsZWFkX25hbWUiLCJsZWFkX3Bob25lIiwidGFza19jb2RlIiwiZW1wbG95ZWVOYW1lIiwiZW1wbG95ZWVDb2RlIiwicmVmZXJyZWRUeXBlIiwicmVmZXJyZWQiLCJhcHByb3ZhbFN0YXR1cyIsImFzc2lnbmVkVG9JZCIsImNyZWF0ZWRBdCIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwibGFiZWwiLCJvcGVuRWRpdCIsImhhbmRsZURlbGV0ZSIsImNhbGN1bGF0ZVN0YXR1c0NhcmRzIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwidGFza3NEYXRhIiwibGVuZ3RoIiwiZmlsdGVyIiwiYXBwbHlGaWx0ZXJzIiwiZmlsdGVyZWQiLCJzdGFydE9mIiwiZW5kT2YiLCJ0YXNrRGF0ZSIsImlzQmV0d2VlbiIsInRyaW0iLCJxdWVyeSIsInVzZUVmZmVjdCIsImZldGNoQWdlbnRzIiwicmVzcG9uc2UiLCJoYW5kbGVBbnREU2VsZWN0IiwidmFsdWUiLCJwcmV2IiwidXBkYXRlZCIsImhhbmRsZUlucHV0IiwiZSIsInRhcmdldCIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwicGF5bG9hZCIsIk9iamVjdCIsImtleXMiLCJmb3JFYWNoIiwicHJvdGVjdGVkS2V5cyIsInVuZGVmaW5lZCIsInB1dCIsInJlcyIsInBvc3QiLCJpbmZvIiwicmVzZXRGb3JtIiwiZGVsZXRlIiwiY2xlYXJGaWx0ZXJzIiwiY29sdW1ucyIsImhlYWRlciIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJwcm9wcyIsInRvU3RyaW5nIiwiZGF0ZXMiLCJ0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiVGFzay5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBEcm9wZG93biwgU2VsZWN0LCBEYXRlUGlja2VyLCBJbnB1dCB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlLCBJb01kU2VhcmNoIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBDdXN0b21BbGVydERpYWxvZyBmcm9tIFwiLi4vY29tcG9uZW50cy9hbGVydHMvQ3VzdG9tQWxlcnREaWFsb2dcIjtcclxuaW1wb3J0IHsgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgZGF5anMgZnJvbSBcImRheWpzXCI7XHJcblxyXG5jb25zdCB7IE9wdGlvbiB9ID0gU2VsZWN0O1xyXG5jb25zdCB7IFJhbmdlUGlja2VyIH0gPSBEYXRlUGlja2VyO1xyXG5cclxuY29uc3QgVGFzayA9ICgpID0+IHtcclxuICBjb25zdCBbYWdlbnRzLCBzZXRBZ2VudHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsZWFkcywgc2V0TGVhZHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjdXN0b21lcnMsIHNldEN1c3RvbWVyc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3Rhc2tzLCBzZXRUYXNrc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3RhYmxlVGFza3MsIHNldFRhYmxlVGFza3NdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFRhc2tzLCBzZXRGaWx0ZXJlZFRhc2tzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWRtaW5zLCBzZXRBZG1pbnNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICAvLyBGaWx0ZXIgc3RhdGVzXHJcbiAgY29uc3QgW3NlbGVjdGVkQWdlbnQsIHNldFNlbGVjdGVkQWdlbnRdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2RhdGVSYW5nZSwgc2V0RGF0ZVJhbmdlXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIC8vIFN0YXR1cyBjYXJkIGRhdGFcclxuICBjb25zdCBbc3RhdHVzQ2FyZHMsIHNldFN0YXR1c0NhcmRzXSA9IHVzZVN0YXRlKHtcclxuICAgIHRvdGFsOiAwLFxyXG4gICAgYXNzaWduZWQ6IDAsXHJcbiAgICBjb21wbGV0ZWQ6IDAsXHJcbiAgICBwZW5kaW5nOiAwXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGxvZ2dlZEluVXNlciA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyXCIpIHx8IFwie31cIik7XHJcbiAgLy8gRklYOiBzb21lIGF1dGggZmxvd3Mgc3RvcmUgdGhlIGFkbWluIGlkIGFzIFwiX2lkXCIsIG90aGVycyBhcyBcImlkXCIg4oCUIHN1cHBvcnQgYm90aFxyXG4gIGNvbnN0IGxvZ2dlZEluQWRtaW5JZCA9IGxvZ2dlZEluVXNlci5faWQgfHwgbG9nZ2VkSW5Vc2VyLmlkIHx8IFwiXCI7XHJcbiAgY29uc3QgbG9nZ2VkSW5BZG1pbk5hbWUgPSBsb2dnZWRJblVzZXIubmFtZTtcclxuXHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBhc3NpZ25lZEJ5OiBsb2dnZWRJbkFkbWluSWQgfHwgXCJcIixcclxuICAgIGFzc2lnbmVkVG86IFwiXCIsXHJcbiAgICB0YXNrVGl0bGU6IFwiUGVuZGluZyBMZWFkIFZpc2l0XCIsXHJcbiAgICB0YXNrRGVzY3JpcHRpb246IFwiXCIsXHJcbiAgICBzdGFydERhdGU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxNiksXHJcbiAgICBlbmREYXRlOiBcIlwiLFxyXG4gICAgc3RhdHVzOiBcIlBlbmRpbmdcIixcclxuICAgIGxlYWQ6IFwiXCIsXHJcbiAgICBlbXBsb3llZTogXCJcIixcclxuICAgIHJlZmVycmVkX3R5cGU6IFwiXCIsXHJcbiAgICBhcHByb3ZhbF9zdGF0dXM6IFwiXCIsXHJcbiAgICBjdXN0b21lcjogXCJcIixcclxuICAgIHB1cnBvc2U6IFwiXCIsXHJcbiAgICBjdXN0b21QdXJwb3NlOiBcIlwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XHJcbiAgY29uc3QgeyBsZWFkSWQsIGxlYWRBZ2VudElkIH0gPSBsb2NhdGlvbi5zdGF0ZSB8fCB7fTtcclxuICBjb25zdCBbbGVhZElkU3RhdGUsIHNldExlYWRJZFN0YXRlXSA9IHVzZVN0YXRlKGxvY2F0aW9uLnN0YXRlPy5sZWFkSWQgfHwgbnVsbCk7XHJcbiAgY29uc3QgW2xlYWRBZ2VudElkU3RhdGVdID0gdXNlU3RhdGUobG9jYXRpb24uc3RhdGU/LmxlYWRBZ2VudElkIHx8IG51bGwpO1xyXG4gIGNvbnN0IFttb2RhbFZpc2libGUsIHNldE1vZGFsVmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3JlbG9hZFRyaWdnZXIsIHNldFJlbG9hZFRyaWdnZXJdID0gdXNlU3RhdGUoMCk7XHJcbiAgY29uc3QgW2N1cnJlbnRUYXNrLCBzZXRDdXJyZW50VGFza10gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIC8vIE5ldyBzdGF0ZSBmb3IgZGVsZXRlIGxvYWRpbmdcclxuICBjb25zdCBbaXNEZWxldGluZywgc2V0SXNEZWxldGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIFRyYWNrcyB3aGV0aGVyIHRoaXMgaXMgdGhlIHZlcnkgZmlyc3QgZGF0YSBmZXRjaCAocGFnZSBvcGVuKS5cclxuICAvLyBPbmx5IHRoYXQgZmlyc3QgZmV0Y2ggaXMgYWxsb3dlZCB0byBzaG93IHRoZSBiaWcgbG9hZGVyLlxyXG4gIGNvbnN0IFtpbml0aWFsTG9hZCwgc2V0SW5pdGlhbExvYWRdID0gdXNlU3RhdGUodHJ1ZSk7XHJcblxyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IGZldGNoQWxsRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIC8vIE9ubHkgc2hvdyBsb2FkZXIgb24gdGhlIHZlcnkgZmlyc3QgcGFnZSBsb2FkLCBub3Qgb24gZXZlcnkgcmVsb2FkVHJpZ2dlciBidW1wXHJcbiAgICAgIGlmIChpbml0aWFsTG9hZCkgc2V0SXNMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgY29uc3QgW2FnZW50UmVzLCBsZWFkUmVzLCB0YXNrUmVzLCBjdXN0b21lclJlcywgYWRtaW5SZXNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgIGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWFnZW50XCIpLFxyXG4gICAgICAgIGFwaS5nZXQoXCIvbGVhZC9ub24tY29udmVydGVkXCIpLFxyXG4gICAgICAgIGFwaS5nZXQoXCIvdGFzay9nZXQtdGFza3NcIiksXHJcbiAgICAgICAgYXBpLmdldChcIi91c2VyL2dldC11c2VyXCIpLFxyXG4gICAgICAgIGFwaS5nZXQoXCIvYWRtaW4vZ2V0LXN1Yi1hZG1pbnNcIiksXHJcbiAgICAgIF0pO1xyXG5cclxuICAgICAgY29uc3QgYWdlbnRzTGlzdCA9IEFycmF5LmlzQXJyYXkoYWdlbnRSZXMuZGF0YSlcclxuICAgICAgICA/IGFnZW50UmVzLmRhdGFcclxuICAgICAgICA6IGFnZW50UmVzLmRhdGE/LmFnZW50IHx8IFtdO1xyXG5cclxuICAgICAgY29uc3QgYWRtaW5zTGlzdCA9IEFycmF5LmlzQXJyYXkoYWRtaW5SZXMuZGF0YSlcclxuICAgICAgICA/IGFkbWluUmVzLmRhdGFcclxuICAgICAgICA6IGFkbWluUmVzLmRhdGE/LmFkbWlucyB8fCBhZG1pblJlcy5kYXRhPy5kYXRhIHx8IFtdO1xyXG5cclxuICAgICAgc2V0QWdlbnRzKGFnZW50c0xpc3QpO1xyXG4gICAgICBzZXRBZG1pbnMoYWRtaW5zTGlzdCk7XHJcbiAgICAgIHNldExlYWRzKGxlYWRSZXMuZGF0YSB8fCBbXSk7XHJcbiAgICAgIHNldEN1c3RvbWVycyhjdXN0b21lclJlcy5kYXRhIHx8IFtdKTtcclxuICAgICAgc2V0VGFza3ModGFza1Jlcy5kYXRhIHx8IFtdKTtcclxuXHJcbiAgICAgIGNvbnN0IGFsbEFzc2lnbmVycyA9IFsuLi5hZ2VudHNMaXN0LCAuLi5hZG1pbnNMaXN0XTtcclxuXHJcbiAgICAgIGNvbnN0IGZvcm1hdHRlZCA9ICh0YXNrUmVzLmRhdGEgfHwgW10pLm1hcCgodGFzaywgaW5kZXgpID0+IHtcclxuICAgICAgICAvLyAxLiBSZXNvbHZlIEFzc2lnbmVkIEJ5XHJcbiAgICAgICAgY29uc3QgYXNzaWduZWRCeVBlcnNvbiA9IGFsbEFzc2lnbmVycy5maW5kKFxyXG4gICAgICAgICAgKGEpID0+IGEuX2lkID09PSAodGFzay5hc3NpZ25lZEJ5Py5faWQgfHwgdGFzay5hc3NpZ25lZEJ5KVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIC8vIDIuIFJlc29sdmUgQXNzaWduZWQgVG9cclxuICAgICAgICBjb25zdCBhc3NpZ25lZFRvUGVyc29uID0gYWdlbnRzTGlzdC5maW5kKFxyXG4gICAgICAgICAgKGEpID0+IGEuX2lkID09PSAodGFzay5hc3NpZ25lZFRvPy5faWQgfHwgdGFzay5hc3NpZ25lZFRvKVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIC8vIDMuIFJlc29sdmUgTGVhZFxyXG4gICAgICAgIGNvbnN0IHJlZkxlYWQgPSAobGVhZFJlcy5kYXRhIHx8IFtdKS5maW5kKFxyXG4gICAgICAgICAgKGwpID0+IGwuX2lkID09PSAodGFzay5sZWFkPy5faWQgfHwgdGFzay5sZWFkKVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIC8vIDQuIFJlc29sdmUgQ3VzdG9tZXJcclxuICAgICAgICBsZXQgcmVmQ3VzdG9tZXIgPSBudWxsO1xyXG4gICAgICAgIGxldCBjdXN0b21lck5hbWUgPSBcIk4vQVwiO1xyXG4gICAgICAgIGxldCBjdXN0b21lclBob25lID0gXCJcIjtcclxuXHJcbiAgICAgICAgaWYgKHRhc2suY3VzdG9tZXIpIHtcclxuICAgICAgICAgIGlmICh0YXNrLmN1c3RvbWVyLl9pZCAmJiAodGFzay5jdXN0b21lci5mdWxsX25hbWUgfHwgdGFzay5jdXN0b21lci5uYW1lKSkge1xyXG4gICAgICAgICAgICByZWZDdXN0b21lciA9IHRhc2suY3VzdG9tZXI7XHJcbiAgICAgICAgICAgIGN1c3RvbWVyTmFtZSA9IHRhc2suY3VzdG9tZXIuZnVsbF9uYW1lIHx8IHRhc2suY3VzdG9tZXIubmFtZSB8fCBcIk4vQVwiO1xyXG4gICAgICAgICAgICBjdXN0b21lclBob25lID0gdGFzay5jdXN0b21lci5waG9uZSB8fCB0YXNrLmN1c3RvbWVyLnBob25lX251bWJlciB8fCB0YXNrLmN1c3RvbWVyLm1vYmlsZSB8fCBcIlwiO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY29uc3QgY3VzdG9tZXJJZCA9IHRhc2suY3VzdG9tZXIuX2lkIHx8IHRhc2suY3VzdG9tZXI7XHJcbiAgICAgICAgICAgIHJlZkN1c3RvbWVyID0gKGN1c3RvbWVyUmVzLmRhdGEgfHwgW10pLmZpbmQoYyA9PiBjLl9pZCA9PT0gY3VzdG9tZXJJZCk7XHJcbiAgICAgICAgICAgIGlmIChyZWZDdXN0b21lcikge1xyXG4gICAgICAgICAgICAgIGN1c3RvbWVyTmFtZSA9IHJlZkN1c3RvbWVyLmZ1bGxfbmFtZSB8fCByZWZDdXN0b21lci5uYW1lIHx8IFwiTi9BXCI7XHJcbiAgICAgICAgICAgICAgY3VzdG9tZXJQaG9uZSA9IHJlZkN1c3RvbWVyLnBob25lIHx8IHJlZkN1c3RvbWVyLnBob25lX251bWJlciB8fCByZWZDdXN0b21lci5tb2JpbGUgfHwgXCJcIjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8gNS4gRGV0ZXJtaW5lIENvbnRhY3QgTmFtZSAmIFJlZmVycmVkIERpc3BsYXkgYmFzZWQgb24gbm9ybWFsaXplZCB0eXBlXHJcbiAgICAgICAgY29uc3QgdHlwZUxvd2VyID0gKHRhc2sucmVmZXJyZWRfdHlwZSB8fCBcIlwiKS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgICAgIGxldCBjb250YWN0TmFtZSA9IFwiTi9BXCI7XHJcbiAgICAgICAgbGV0IHJlZmVycmVkRGlzcGxheSA9IFwiTi9BXCI7XHJcblxyXG4gICAgICAgIGlmICh0eXBlTG93ZXIuaW5jbHVkZXMoXCJsZWFkXCIpKSB7XHJcbiAgICAgICAgICBpZiAocmVmTGVhZCkge1xyXG4gICAgICAgICAgICBjb250YWN0TmFtZSA9IHJlZkxlYWQubGVhZF9uYW1lIHx8IFwiTi9BXCI7XHJcbiAgICAgICAgICAgIHJlZmVycmVkRGlzcGxheSA9IGAke3JlZkxlYWQubGVhZF9uYW1lfSAoJHtyZWZMZWFkLmxlYWRfcGhvbmV9KWA7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlTG93ZXIuaW5jbHVkZXMoXCJjdXN0b21lclwiKSkge1xyXG4gICAgICAgICAgY29udGFjdE5hbWUgPSBjdXN0b21lck5hbWU7XHJcbiAgICAgICAgICByZWZlcnJlZERpc3BsYXkgPSBgJHtjdXN0b21lck5hbWV9JHtjdXN0b21lclBob25lID8gYCAoJHtjdXN0b21lclBob25lfSlgIDogJyd9YDtcclxuICAgICAgICB9IGVsc2UgaWYgKHR5cGVMb3dlci5pbmNsdWRlcyhcImVtcGxveWVlXCIpKSB7XHJcbiAgICAgICAgICBpZiAoYXNzaWduZWRUb1BlcnNvbikge1xyXG4gICAgICAgICAgICBjb250YWN0TmFtZSA9IGFzc2lnbmVkVG9QZXJzb24ubmFtZSB8fCBcIk4vQVwiO1xyXG4gICAgICAgICAgICByZWZlcnJlZERpc3BsYXkgPSBgJHthc3NpZ25lZFRvUGVyc29uLm5hbWV9ICgke2Fzc2lnbmVkVG9QZXJzb24ucGhvbmVfbnVtYmVyfSlgO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAvLyBGYWxsYmFjayBsb2dpY1xyXG4gICAgICAgICAgaWYgKGFzc2lnbmVkVG9QZXJzb24pIHtcclxuICAgICAgICAgICAgY29udGFjdE5hbWUgPSBhc3NpZ25lZFRvUGVyc29uLm5hbWUgfHwgXCJOL0FcIjtcclxuICAgICAgICAgICAgcmVmZXJyZWREaXNwbGF5ID0gYCR7YXNzaWduZWRUb1BlcnNvbi5uYW1lfSAoJHthc3NpZ25lZFRvUGVyc29uLnBob25lX251bWJlcn0pYDtcclxuICAgICAgICAgIH0gZWxzZSBpZiAocmVmTGVhZCkge1xyXG4gICAgICAgICAgICBjb250YWN0TmFtZSA9IHJlZkxlYWQubGVhZF9uYW1lIHx8IFwiTi9BXCI7XHJcbiAgICAgICAgICAgIHJlZmVycmVkRGlzcGxheSA9IGAke3JlZkxlYWQubGVhZF9uYW1lfSAoJHtyZWZMZWFkLmxlYWRfcGhvbmV9KWA7XHJcbiAgICAgICAgICB9IGVsc2UgaWYgKGN1c3RvbWVyTmFtZSAhPT0gXCJOL0FcIikge1xyXG4gICAgICAgICAgICBjb250YWN0TmFtZSA9IGN1c3RvbWVyTmFtZTtcclxuICAgICAgICAgICAgcmVmZXJyZWREaXNwbGF5ID0gYCR7Y3VzdG9tZXJOYW1lfSR7Y3VzdG9tZXJQaG9uZSA/IGAgKCR7Y3VzdG9tZXJQaG9uZX0pYCA6ICcnfWA7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgX2lkOiB0YXNrLl9pZCxcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICB0YXNrX2NvZGU6IHRhc2s/LnRhc2tfY29kZSxcclxuICAgICAgICAgIGVtcGxveWVlTmFtZTogYXNzaWduZWRCeVBlcnNvbj8ubmFtZSB8fCB0YXNrLmFzc2lnbmVkQnk/Lm5hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGVtcGxveWVlQ29kZTogYXNzaWduZWRCeVBlcnNvbj8uZW1wbG95ZWVDb2RlIHx8IHRhc2suYXNzaWduZWRCeT8uZW1wbG95ZWVDb2RlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICB0YXNrVGl0bGU6IHRhc2sudGFza1RpdGxlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICBzdGF0dXM6IHRhc2suc3RhdHVzLFxyXG4gICAgICAgICAgcmVmZXJyZWRUeXBlOiB0YXNrPy5yZWZlcnJlZF90eXBlIHx8IFwiTi9BXCIsXHJcbiAgICAgICAgICByZWZlcnJlZDogcmVmZXJyZWREaXNwbGF5LFxyXG4gICAgICAgICAgY3VzdG9tZXJOYW1lOiBjb250YWN0TmFtZSwgLy8gTm93IHBvcHVsYXRlcyBmb3IgTGVhZHMsIEN1c3RvbWVycywgYW5kIEVtcGxveWVlc1xyXG4gICAgICAgICAgYXBwcm92YWxTdGF0dXM6IHRhc2s/LmFwcHJvdmFsX3N0YXR1cyxcclxuICAgICAgICAgIGFzc2lnbmVkVG9JZDogdGFzay5hc3NpZ25lZFRvPy5faWQgfHwgdGFzay5hc3NpZ25lZFRvLFxyXG4gICAgICAgICAgY3VzdG9tZXJJZDogdGFzay5jdXN0b21lcj8uX2lkIHx8IHRhc2suY3VzdG9tZXIsXHJcbiAgICAgICAgICBsZWFkSWQ6IHRhc2subGVhZD8uX2lkIHx8IHRhc2subGVhZCxcclxuICAgICAgICAgIHB1cnBvc2U6IHRhc2sucHVycG9zZSB8fCBcIk4vQVwiLCAvLyBBZGRlZCBwdXJwb3NlIGZpZWxkIGZyb20gQVBJXHJcbiAgICAgICAgICBjcmVhdGVkQXQ6IHRhc2suY3JlYXRlZEF0LFxyXG4gICAgICAgICAgc3RhcnREYXRlOiB0YXNrLnN0YXJ0RGF0ZSxcclxuICAgICAgICAgIGVuZERhdGU6IHRhc2suZW5kRGF0ZSxcclxuICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICB7IGtleTogXCIxXCIsIGxhYmVsOiA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCIgb25DbGljaz17KCkgPT4gb3BlbkVkaXQodGFzayl9PkVkaXQ8L2Rpdj4gfSxcclxuICAgICAgICAgICAgICAgICAgeyBrZXk6IFwiMlwiLCBsYWJlbDogPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIiBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGUodGFzay5faWQpfT5EZWxldGU8L2Rpdj4gfSxcclxuICAgICAgICAgICAgICAgIF0sXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlclwiIC8+XHJcbiAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgIH07XHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgc2V0VGFibGVUYXNrcyhmb3JtYXR0ZWQpO1xyXG4gICAgICBzZXRGaWx0ZXJlZFRhc2tzKGZvcm1hdHRlZCk7XHJcbiAgICAgIGNhbGN1bGF0ZVN0YXR1c0NhcmRzKGZvcm1hdHRlZCk7XHJcblxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhbGwgZGF0YVwiLCBlcnIpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkZhaWxlZCB0byBmZXRjaCBkYXRhXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIHNldEluaXRpYWxMb2FkKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBDYWxjdWxhdGUgc3RhdHVzIGNhcmRzXHJcbiAgY29uc3QgY2FsY3VsYXRlU3RhdHVzQ2FyZHMgPSAodGFza3NEYXRhKSA9PiB7XHJcbiAgICBjb25zdCB0b3RhbCA9IHRhc2tzRGF0YS5sZW5ndGg7XHJcbiAgICBjb25zdCBhc3NpZ25lZCA9IHRhc2tzRGF0YS5maWx0ZXIodGFzayA9PiB0YXNrLnN0YXR1cyA9PT0gXCJQZW5kaW5nXCIgfHwgdGFzay5zdGF0dXMgPT09IFwiSW4gUHJvZ3Jlc3NcIikubGVuZ3RoO1xyXG4gICAgY29uc3QgY29tcGxldGVkID0gdGFza3NEYXRhLmZpbHRlcih0YXNrID0+IHRhc2suc3RhdHVzID09PSBcIkNvbXBsZXRlZFwiKS5sZW5ndGg7XHJcbiAgICBjb25zdCBwZW5kaW5nID0gdGFza3NEYXRhLmZpbHRlcih0YXNrID0+IHRhc2suc3RhdHVzID09PSBcIlBlbmRpbmdcIikubGVuZ3RoO1xyXG5cclxuICAgIHNldFN0YXR1c0NhcmRzKHtcclxuICAgICAgdG90YWwsXHJcbiAgICAgIGFzc2lnbmVkLFxyXG4gICAgICBjb21wbGV0ZWQsXHJcbiAgICAgIHBlbmRpbmdcclxuICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIC8vIEZpbHRlciB0YXNrcyBiYXNlZCBvbiBhZ2VudCwgZGF0ZSByYW5nZSwgYW5kIHNlYXJjaFxyXG4gIGNvbnN0IGFwcGx5RmlsdGVycyA9ICgpID0+IHtcclxuICAgIGxldCBmaWx0ZXJlZCA9IFsuLi50YWJsZVRhc2tzXTtcclxuXHJcbiAgICAvLyBGaWx0ZXIgYnkgYWdlbnRcclxuICAgIGlmIChzZWxlY3RlZEFnZW50KSB7XHJcbiAgICAgIGZpbHRlcmVkID0gZmlsdGVyZWQuZmlsdGVyKHRhc2sgPT4gdGFzay5hc3NpZ25lZFRvSWQgPT09IHNlbGVjdGVkQWdlbnQpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEZpbHRlciBieSBkYXRlIHJhbmdlXHJcbiAgICBpZiAoZGF0ZVJhbmdlICYmIGRhdGVSYW5nZVswXSAmJiBkYXRlUmFuZ2VbMV0pIHtcclxuICAgICAgY29uc3Qgc3RhcnREYXRlID0gZGF5anMoZGF0ZVJhbmdlWzBdKS5zdGFydE9mKCdkYXknKTtcclxuICAgICAgY29uc3QgZW5kRGF0ZSA9IGRheWpzKGRhdGVSYW5nZVsxXSkuZW5kT2YoJ2RheScpO1xyXG5cclxuICAgICAgZmlsdGVyZWQgPSBmaWx0ZXJlZC5maWx0ZXIodGFzayA9PiB7XHJcbiAgICAgICAgaWYgKCF0YXNrLmNyZWF0ZWRBdCkgcmV0dXJuIGZhbHNlO1xyXG4gICAgICAgIGNvbnN0IHRhc2tEYXRlID0gZGF5anModGFzay5jcmVhdGVkQXQpO1xyXG4gICAgICAgIHJldHVybiB0YXNrRGF0ZS5pc0JldHdlZW4oc3RhcnREYXRlLCBlbmREYXRlLCBudWxsLCAnW10nKTtcclxuICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gRmlsdGVyIGJ5IHNlYXJjaCBxdWVyeSAoYWdlbnQgbmFtZSBzZWFyY2gpXHJcbiAgICBpZiAoc2VhcmNoUXVlcnkudHJpbSgpKSB7XHJcbiAgICAgIGNvbnN0IHF1ZXJ5ID0gc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKS50cmltKCk7XHJcbiAgICAgIGZpbHRlcmVkID0gZmlsdGVyZWQuZmlsdGVyKHRhc2sgPT5cclxuICAgICAgICB0YXNrLnJlZmVycmVkLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocXVlcnkpIHx8XHJcbiAgICAgICAgdGFzay5lbXBsb3llZU5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhxdWVyeSkgfHxcclxuICAgICAgICB0YXNrLnRhc2tUaXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5KVxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIHNldEZpbHRlcmVkVGFza3MoZmlsdGVyZWQpO1xyXG4gICAgY2FsY3VsYXRlU3RhdHVzQ2FyZHMoZmlsdGVyZWQpO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBhcHBseUZpbHRlcnMoKTtcclxuICB9LCBbc2VsZWN0ZWRBZ2VudCwgZGF0ZVJhbmdlLCBzZWFyY2hRdWVyeSwgdGFibGVUYXNrc10pO1xyXG5cclxuICAvLyBGZXRjaCBhZ2VudHMgZm9yIGRyb3Bkb3duXHJcbiAgY29uc3QgZmV0Y2hBZ2VudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXCIvYWdlbnQvZ2V0LWFnZW50XCIpO1xyXG4gICAgICBjb25zdCBhZ2VudHNMaXN0ID0gQXJyYXkuaXNBcnJheShyZXNwb25zZS5kYXRhKVxyXG4gICAgICAgID8gcmVzcG9uc2UuZGF0YVxyXG4gICAgICAgIDogcmVzcG9uc2UuZGF0YT8uYWdlbnQgfHwgW107XHJcbiAgICAgIHNldEFnZW50cyhhZ2VudHNMaXN0KTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWdlbnRzXCIsIGVycik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoQWdlbnRzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2hBbGxEYXRhKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQW50RFNlbGVjdCA9IChuYW1lLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+IHtcclxuICAgICAgY29uc3QgdXBkYXRlZCA9IHsgLi4ucHJldiwgW25hbWVdOiB2YWx1ZSB9O1xyXG5cclxuICAgICAgaWYgKG5hbWUgPT09IFwicmVmZXJyZWRfdHlwZVwiKSB7XHJcbiAgICAgICAgLy8gUmVzZXQgZGVwZW5kZW50IGZpZWxkcyB3aGVuIHJlZmVycmVkX3R5cGUgY2hhbmdlc1xyXG4gICAgICAgIHVwZGF0ZWQubGVhZCA9IFwiXCI7XHJcbiAgICAgICAgLy8gdXBkYXRlZC5hc3NpZ25lZFRvID0gXCJcIjtcclxuICAgICAgICB1cGRhdGVkLmN1c3RvbWVyID0gXCJcIjtcclxuXHJcbiAgICAgICAgLy8gU2V0IHRhc2sgdGl0bGUgYmFzZWQgb24gcmVmZXJyZWRfdHlwZVxyXG4gICAgICAgIGlmICh2YWx1ZSA9PT0gXCJMZWFkXCIpIHtcclxuICAgICAgICAgIHVwZGF0ZWQudGFza1RpdGxlID0gXCJQZW5kaW5nIExlYWQgVmlzaXRcIjtcclxuICAgICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkVtcGxveWVlXCIpIHtcclxuICAgICAgICAgIHVwZGF0ZWQudGFza1RpdGxlID0gXCJQZW5kaW5nIEVtcGxveWVlIFRhc2tcIjtcclxuICAgICAgICB9IGVsc2UgaWYgKHZhbHVlID09PSBcIkN1c3RvbWVyXCIpIHtcclxuICAgICAgICAgIHVwZGF0ZWQudGFza1RpdGxlID0gXCJQZW5kaW5nIEN1c3RvbWVyXCI7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHVwZGF0ZWQudGFza1RpdGxlID0gXCJQZW5kaW5nIExlYWQgVmlzaXRcIjsgLy8gZGVmYXVsdFxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHVwZGF0ZWQ7XHJcbiAgICB9KTtcclxuICB9O1xyXG4gIC8vIFVwZGF0ZSB0YXNrIHRpdGxlIHdoZW4gcmVmZXJyZWRfdHlwZSBjaGFuZ2VzXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChmb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkxlYWRcIikge1xyXG4gICAgICBzZXRGb3JtRGF0YShwcmV2ID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICB0YXNrVGl0bGU6IFwiUGVuZGluZyBMZWFkIFZpc2l0XCJcclxuICAgICAgfSkpO1xyXG4gICAgfSBlbHNlIGlmIChmb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkVtcGxveWVlXCIpIHtcclxuICAgICAgc2V0Rm9ybURhdGEocHJldiA9PiAoe1xyXG4gICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgdGFza1RpdGxlOiBcIlBlbmRpbmcgRW1wbG95ZWUgVGFza1wiXHJcbiAgICAgIH0pKTtcclxuICAgIH0gZWxzZSBpZiAoZm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJDdXN0b21lclwiKSB7XHJcbiAgICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHRhc2tUaXRsZTogXCJQZW5kaW5nIEN1c3RvbWVyXCJcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH0sIFtmb3JtRGF0YS5yZWZlcnJlZF90eXBlXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUlucHV0ID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogdmFsdWUgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgLy8gQXNzaWduZWUgVHlwZSAtIHZpc2libGUgZmllbGRcclxuICAgICAgaWYgKCFmb3JtRGF0YS5yZWZlcnJlZF90eXBlKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBhbiBBc3NpZ25lZSBUeXBlXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBUYXNrIEFzc2lnbmVkIFRvIC0gdmlzaWJsZSBmaWVsZFxyXG4gICAgICBpZiAoIWZvcm1EYXRhLmFzc2lnbmVkVG8pIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGFuIGFnZW50IHRvIGFzc2lnbiB0aGUgdGFza1wiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gU2VsZWN0IExlYWQgLSBvbmx5IHZpc2libGUvcmVxdWlyZWQgd2hlbiByZWZlcnJlZF90eXBlID09PSBcIkxlYWRcIlxyXG4gICAgICBpZiAoZm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJMZWFkXCIgJiYgIWZvcm1EYXRhLmxlYWQpIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IGEgTGVhZFwiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gU2VsZWN0IEN1c3RvbWVyIC0gb25seSB2aXNpYmxlL3JlcXVpcmVkIHdoZW4gcmVmZXJyZWRfdHlwZSA9PT0gXCJDdXN0b21lclwiXHJcbiAgICAgIGlmIChmb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkN1c3RvbWVyXCIgJiYgIWZvcm1EYXRhLmN1c3RvbWVyKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBhIEN1c3RvbWVyXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBUYXNrIERlc2NyaXB0aW9uIC0gdmlzaWJsZSBmaWVsZFxyXG4gICAgICBpZiAoIWZvcm1EYXRhLnRhc2tEZXNjcmlwdGlvbj8udHJpbSgpKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGVudGVyIGEgVGFzayBEZXNjcmlwdGlvblwiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gU3RhcnQgRGF0ZSAmIFRpbWUgLSB2aXNpYmxlIGZpZWxkXHJcbiAgICAgIGlmICghZm9ybURhdGEuc3RhcnREYXRlKSB7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIHNlbGVjdCBhIFN0YXJ0IERhdGUgJiBUaW1lXCIsXHJcbiAgICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBhc3NpZ25lZEJ5IC0gaGlkZGVuIGJ1dCByZXF1aXJlZCBieSBiYWNrZW5kOyBndWFyZCBhZ2FpbnN0IGl0IGJlaW5nIGVtcHR5XHJcbiAgICAgIGlmICghZm9ybURhdGEuYXNzaWduZWRCeSkge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkNvdWxkIG5vdCBkZXRlY3QgbG9nZ2VkLWluIGFkbWluLiBQbGVhc2UgbG9nIGluIGFnYWluLlwiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgcGF5bG9hZCA9IHsgLi4uZm9ybURhdGEgfTtcclxuXHJcbiAgICAgIC8vIEZpZWxkcyBub3QgcHJlc2VudCBpbiB0aGUgdmlzaWJsZSBmb3JtIOKAlCBuZXZlciBzZW5kIHRoZXNlXHJcbiAgICAgIGRlbGV0ZSBwYXlsb2FkLmVuZERhdGU7XHJcbiAgICAgIGRlbGV0ZSBwYXlsb2FkLmFwcHJvdmFsX3N0YXR1cztcclxuXHJcbiAgICAgIC8vIENsZWFuIHVwIHBheWxvYWQgYmFzZWQgb24gcmVmZXJyZWRfdHlwZVxyXG4gICAgICBpZiAocGF5bG9hZC5yZWZlcnJlZF90eXBlID09PSBcIkxlYWRcIikge1xyXG4gICAgICAgIGRlbGV0ZSBwYXlsb2FkLmN1c3RvbWVyO1xyXG4gICAgICB9IGVsc2UgaWYgKHBheWxvYWQucmVmZXJyZWRfdHlwZSA9PT0gXCJFbXBsb3llZVwiKSB7XHJcbiAgICAgICAgZGVsZXRlIHBheWxvYWQubGVhZDtcclxuICAgICAgICBkZWxldGUgcGF5bG9hZC5jdXN0b21lcjtcclxuICAgICAgfSBlbHNlIGlmIChwYXlsb2FkLnJlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIikge1xyXG4gICAgICAgIGRlbGV0ZSBwYXlsb2FkLmxlYWQ7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIFJlbW92ZSBlbXB0eSBmaWVsZHMgRVhDRVBUIGFzc2lnbmVkQnkvdGFza1RpdGxlL3Rhc2tEZXNjcmlwdGlvbi9zdGFydERhdGUsXHJcbiAgICAgIC8vIHdoaWNoIHRoZSBiYWNrZW5kIHN0cmljdGx5IHJlcXVpcmVzIGFuZCB3ZSd2ZSBhbHJlYWR5IHZhbGlkYXRlZCBhYm92ZVxyXG4gICAgICBPYmplY3Qua2V5cyhwYXlsb2FkKS5mb3JFYWNoKGtleSA9PiB7XHJcbiAgICAgICAgY29uc3QgcHJvdGVjdGVkS2V5cyA9IFtcImFzc2lnbmVkQnlcIiwgXCJ0YXNrVGl0bGVcIiwgXCJ0YXNrRGVzY3JpcHRpb25cIiwgXCJzdGFydERhdGVcIl07XHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgIXByb3RlY3RlZEtleXMuaW5jbHVkZXMoa2V5KSAmJlxyXG4gICAgICAgICAgKHBheWxvYWRba2V5XSA9PT0gXCJcIiB8fCBwYXlsb2FkW2tleV0gPT09IG51bGwgfHwgcGF5bG9hZFtrZXldID09PSB1bmRlZmluZWQpXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICBkZWxldGUgcGF5bG9hZFtrZXldO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcblxyXG5cclxuICAgICAgaWYgKGN1cnJlbnRUYXNrKSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLnB1dChgL3Rhc2svdXBkYXRlLXRhc2svJHtjdXJyZW50VGFza31gLCBwYXlsb2FkKTtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJUYXNrIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLnBvc3QoXCIvdGFzay9hZGQtbmV3LXRhc2tcIiwgcGF5bG9hZCk7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKHJlcy5kYXRhLCBcInRlc3QxMjNcIik7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiVGFzayBjcmVhdGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRNb2RhbFZpc2libGUoZmFsc2UpO1xyXG4gICAgICByZXNldEZvcm0oKTtcclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJUYXNrIGNyZWF0aW9uIGVycm9yOlwiLCBlcnIucmVzcG9uc2U/LmRhdGEgfHwgZXJyLm1lc3NhZ2UpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBlcnIucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgXCJTb21ldGhpbmcgd2VudCB3cm9uZ1wiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcmVzZXRGb3JtID0gKCkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICBhc3NpZ25lZEJ5OiBsb2dnZWRJbkFkbWluSWQgfHwgXCJcIixcclxuICAgICAgYXNzaWduZWRUbzogXCJcIixcclxuICAgICAgdGFza1RpdGxlOiBcIlBlbmRpbmcgTGVhZCBWaXNpdFwiLFxyXG4gICAgICB0YXNrRGVzY3JpcHRpb246IFwiXCIsXHJcbiAgICAgIHN0YXJ0RGF0ZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDE2KSxcclxuICAgICAgZW5kRGF0ZTogXCJcIixcclxuICAgICAgc3RhdHVzOiBcIlBlbmRpbmdcIixcclxuICAgICAgbGVhZDogXCJcIixcclxuICAgICAgcmVmZXJyZWRfdHlwZTogXCJcIiwgLy8gS2VlcCBhcyBlbXB0eSBzdHJpbmdcclxuICAgICAgYXBwcm92YWxfc3RhdHVzOiBcIlwiLFxyXG4gICAgICBjdXN0b21lcjogXCJcIixcclxuICAgIH0pO1xyXG4gICAgc2V0Q3VycmVudFRhc2sobnVsbCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb3BlbkVkaXQgPSAodGFzaykgPT4ge1xyXG5cclxuICAgIHNldEN1cnJlbnRUYXNrKHRhc2suX2lkKTtcclxuXHJcbiAgICAvLyBsZXQgcmVmZXJyZWRUeXBlID0gXCJcIjtcclxuICAgIC8vIGlmICh0YXNrLmxlYWQpIHJlZmVycmVkVHlwZSA9IFwiTGVhZFwiO1xyXG4gICAgLy8gZWxzZSBpZiAodGFzay5hc3NpZ25lZFRvKSByZWZlcnJlZFR5cGUgPSBcIkVtcGxveWVlXCI7XHJcbiAgICAvLyBlbHNlIGlmICh0YXNrLmN1c3RvbWVyKSByZWZlcnJlZFR5cGUgPSBcIkN1c3RvbWVyXCI7XHJcblxyXG4gICAgc2V0Rm9ybURhdGEoe1xyXG4gICAgICBhc3NpZ25lZEJ5OiB0YXNrLmFzc2lnbmVkQnk/Ll9pZCB8fCB0YXNrLmFzc2lnbmVkQnkgfHwgbG9nZ2VkSW5BZG1pbklkLFxyXG4gICAgICBhc3NpZ25lZFRvOiB0YXNrLmFzc2lnbmVkVG8/Ll9pZCB8fCB0YXNrLmFzc2lnbmVkVG8gfHwgXCJcIixcclxuICAgICAgcmVmZXJyZWRfdHlwZTogdGFzaz8ucmVmZXJyZWRfdHlwZSxcclxuICAgICAgbGVhZDogdGFzay5sZWFkPy5faWQgfHwgdGFzay5sZWFkIHx8IFwiXCIsXHJcbiAgICAgIGN1c3RvbWVyOiB0YXNrLmN1c3RvbWVyPy5faWQgfHwgdGFzay5jdXN0b21lciB8fCBcIlwiLFxyXG4gICAgICBlbXBsb3llZTogdGFzay5lbXBsb3llZT8uX2lkIHx8IHRhc2suZW1wbG95ZWUgfHwgXCJcIixcclxuICAgICAgcHVycG9zZTogdGFzay5wdXJwb3NlIHx8IFwiXCIsXHJcbiAgICAgIHRhc2tUaXRsZTogdGFzay50YXNrVGl0bGUgfHwgXCJQZW5kaW5nIExlYWQgVmlzaXRcIixcclxuICAgICAgdGFza0Rlc2NyaXB0aW9uOiB0YXNrLnRhc2tEZXNjcmlwdGlvbiB8fCBcIlwiLFxyXG4gICAgICBzdGFydERhdGU6IHRhc2suc3RhcnREYXRlPy5zbGljZSgwLCAxNikgfHwgXCJcIixcclxuICAgICAgZW5kRGF0ZTogdGFzay5lbmREYXRlPy5zbGljZSgwLCAxNikgfHwgXCJcIixcclxuICAgICAgc3RhdHVzOiB0YXNrLnN0YXR1cyB8fCBcIlBlbmRpbmdcIixcclxuICAgICAgYXBwcm92YWxfc3RhdHVzOiB0YXNrPy5hcHByb3ZhbF9zdGF0dXMgfHwgXCJQZW5kaW5nXCIsXHJcbiAgICB9KTtcclxuXHJcbiAgICBzZXRNb2RhbFZpc2libGUodHJ1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGlkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBTaG93IGRlbGV0ZSBsb2FkZXIgaW1tZWRpYXRlbHlcclxuICAgICAgc2V0SXNEZWxldGluZyh0cnVlKTtcclxuXHJcbiAgICAgIC8vIFNob3cgbm90aWZpY2F0aW9uIGltbWVkaWF0ZWx5XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRGVsZXRpbmcgdGFzay4uLlwiLFxyXG4gICAgICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIC8vIFBlcmZvcm0gdGhlIGRlbGV0ZSBvcGVyYXRpb25cclxuICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL3Rhc2svZGVsZXRlLXRhc2svJHtpZH1gKTtcclxuXHJcbiAgICAgIC8vIFVwZGF0ZSBub3RpZmljYXRpb24gdG8gc3VjY2Vzc1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlRhc2sgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBSZWZyZXNoIGRhdGEgc2lsZW50bHkgaW4gYmFja2dyb3VuZCAoaXNMb2FkaW5nIHN0YXlzIGZhbHNlLCB0YWJsZSBzdGF5cyB2aXNpYmxlKVxyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJEZWxldGUgZmFpbGVkXCIsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIC8vIEhpZGUgZGVsZXRlIGxvYWRlclxyXG4gICAgICBzZXRJc0RlbGV0aW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvLyBDbGVhciBmaWx0ZXJzXHJcbiAgY29uc3QgY2xlYXJGaWx0ZXJzID0gKCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRBZ2VudChudWxsKTtcclxuICAgIHNldERhdGVSYW5nZShudWxsKTtcclxuICAgIHNldFNlYXJjaFF1ZXJ5KFwiXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwidGFza19jb2RlXCIsIGhlYWRlcjogXCJUYXNrIENvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW1wbG95ZWVOYW1lXCIsIGhlYWRlcjogXCJBc3NpZ25lZCBCeVwiIH0sXHJcbiAgICB7IGtleTogXCJlbXBsb3llZUNvZGVcIiwgaGVhZGVyOiBcIkVtcGxveWVlIElEXCIgfSxcclxuICAgIHsga2V5OiBcInRhc2tUaXRsZVwiLCBoZWFkZXI6IFwiVGFzayBOYW1lXCIgfSxcclxuXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZFR5cGVcIiwgaGVhZGVyOiBcIlJlZmVycmVkIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRcIiwgaGVhZGVyOiBcIkFzc2lnbmVkIFRvXCIgfSxcclxuICAgIHsga2V5OiBcImN1c3RvbWVyTmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgLyBsZWFkIC8gRW1wbG95ZWUgTmFtZVwiIH0sIC8vIE5ldyBjb2x1bW4gZm9yIGN1c3RvbWVyXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlRhc2sgU3RhdHVzXCIgfSxcclxuICAgIC8vIHsga2V5OiBcImFwcHJvdmFsU3RhdHVzXCIsIGhlYWRlcjogXCJBcHByb3ZhbCBTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICA8TmF2YmFyIHZpc2liaWxpdHk9e3RydWV9IC8+XHJcbiAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICB0eXBlPXthbGVydENvbmZpZy50eXBlfVxyXG4gICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+XHJcbiAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgIH1cclxuICAgICAgICAvPlxyXG4gICAgICAgIDxTaWRlYmFyIC8+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5UYXNrczwvaDE+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBzZXRNb2RhbFZpc2libGUodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIHJlc2V0Rm9ybSgpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctYmx1ZS05NTAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctYmx1ZS04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICsgQWRkIFRhc2tcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogU3RhdHVzIENhcmRzICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdyBwLTYgYm9yZGVyLWwtNCBib3JkZXItYmx1ZS01MDBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+VG90YWwgVGFza3M8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e3N0YXR1c0NhcmRzLnRvdGFsfTwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTEwMCBwLTMgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWJsdWUtNTAwXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNOSA1SDdhMiAyIDAgMDAtMiAydjEyYTIgMiAwIDAwMiAyaDEwYTIgMiAwIDAwMi0yVjdhMiAyIDAgMDAtMi0yaC0yTTkgNWEyIDIgMCAwMDIgMmgyYTIgMiAwIDAwMi0yTTkgNWEyIDIgMCAwMTItMmgyYTIgMiAwIDAxMiAyXCI+PC9wYXRoPlxyXG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cgcC02IGJvcmRlci1sLTQgYm9yZGVyLXllbGxvdy01MDBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+QXNzaWduZWQ8L3A+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwXCI+e3N0YXR1c0NhcmRzLmFzc2lnbmVkfTwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy15ZWxsb3ctMTAwIHAtMyByb3VuZGVkLWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQteWVsbG93LTUwMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTEyIDh2NGwzIDNtNi0zYTkgOSAwIDExLTE4IDAgOSA5IDAgMDExOCAwelwiPjwvcGF0aD5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93IHAtNiBib3JkZXItbC00IGJvcmRlci1ncmVlbi01MDBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+Q29tcGxldGVkPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPntzdGF0dXNDYXJkcy5jb21wbGV0ZWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTEwMCBwLTMgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWdyZWVuLTUwMFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTkgMTJsMiAyIDQtNG02IDJhOSA5IDAgMTEtMTggMCA5IDkgMCAwMTE4IDB6XCI+PC9wYXRoPlxyXG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cgcC02IGJvcmRlci1sLTQgYm9yZGVyLXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNjAwXCI+UGVuZGluZzwvcD5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj57c3RhdHVzQ2FyZHMucGVuZGluZ308L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcmVkLTEwMCBwLTMgcm91bmRlZC1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LXJlZC01MDBcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xMiA4djRsMyAzbTYtM2E5IDkgMCAxMS0xOCAwIDkgOSAwIDAxMTggMHpcIj48L3BhdGg+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIEZpbHRlcnMgU2VjdGlvbiAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3cgcC00IG1iLTZcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy00IGdhcC00IGl0ZW1zLWVuZFwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIG1iLTFcIj5TZWFyY2ggYnkgQWdlbnQ8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBBZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgYWxsb3dDbGVhclxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRBZ2VudH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gc2V0U2VsZWN0ZWRBZ2VudCh2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGlsZHJlbiA9IG9wdGlvbj8ucHJvcHM/LmNoaWxkcmVuPy50b1N0cmluZygpIHx8IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHthZ2VudHMubWFwKChhZ2VudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxPcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9IHwge2FnZW50LnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICA8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPkRhdGUgUmFuZ2U8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFJhbmdlUGlja2VyXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZGF0ZXMpID0+IHNldERhdGVSYW5nZShkYXRlcyl9XHJcbiAgICAgICAgICAgICAgICAgIGZvcm1hdD1cIllZWVktTU0tRERcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgbWItMVwiPlNlYXJjaDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYnkgYWdlbnQgbmFtZSwgdGFzayB0aXRsZS4uLlwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hRdWVyeX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2hRdWVyeShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIHByZWZpeD17PElvTWRTZWFyY2ggY2xhc3NOYW1lPVwidGV4dC1ncmF5LTQwMFwiIC8+fVxyXG4gICAgICAgICAgICAgICAgICBhbGxvd0NsZWFyXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17Y2xlYXJGaWx0ZXJzfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTIwMCB0ZXh0LWdyYXktNzAwIHB4LTQgcHktMiByb3VuZGVkIGhvdmVyOmJnLWdyYXktMzAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ2xlYXIgRmlsdGVyc1xyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qXHJcbiAgICAgICAgICAgIExvYWRlciBpcyBzaG93biBvbmx5IG9uIHRoZSB2ZXJ5IGZpcnN0IHBhZ2UgbG9hZCAoaW5pdGlhbExvYWQgJiYgaXNMb2FkaW5nKS5cclxuICAgICAgICAgICAgQWZ0ZXIgdGhhdCwgdGhlIHRhYmxlIHN0YXlzIG1vdW50ZWQgZm9yIGV2ZXJ5IGFkZC9lZGl0L2RlbGV0ZSByZWZyZXNoIOKAlFxyXG4gICAgICAgICAgICBubyByZWxvYWQgZmxpY2tlci5cclxuICAgICAgICAgICovfVxyXG4gICAgICAgICAge2luaXRpYWxMb2FkICYmIGlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgZmFpbHVyZT17IWlzTG9hZGluZ31cclxuICAgICAgICAgICAgICBkYXRhPVwiVGFzayBEYXRhXCJcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgey8qIFNob3cgZGVsZXRlIGxvYWRlciBvdmVybGF5IHdoZW4gZGVsZXRpbmcgKi99XHJcbiAgICAgICAgICAgICAge2lzRGVsZXRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrIGJnLW9wYWNpdHktNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei01MFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHAtNiByb3VuZGVkLWxnIHNoYWRvdy1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgZmFpbHVyZT17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBkYXRhPVwiRGVsZXRpbmcgVGFzay4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtdC0yIHRleHQtZ3JheS03MDBcIj5EZWxldGluZyB0YXNrLi4uPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgdXBkYXRlSGFuZGxlcj17KGlkKSA9PiBvcGVuRWRpdCh0YXNrcy5maW5kKCh0KSA9PiB0Ll9pZCA9PT0gaWQpKX1cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlcmVkVGFza3N9XHJcbiAgICAgICAgICAgICAgICBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiVGFza1wiXHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPVwiVGFza3MuY3N2XCJcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgey8qIFRhc2sgTW9kYWwgLSBLZWVwIHRoZSBzYW1lIGFzIGJlZm9yZSAqL31cclxuICAgICAgPE1vZGFsIGlzVmlzaWJsZT17bW9kYWxWaXNpYmxlfSBvbkNsb3NlPXsoKSA9PiBzZXRNb2RhbFZpc2libGUoZmFsc2UpfT5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSBzbTpwLTYgbWF4LWgtWzg1dmhdIG92ZXJmbG93LXktYXV0byBiZy13aGl0ZSByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTYgYm9yZGVyLWIgYm9yZGVyLWdyYXktMTAwIHBiLTRcIj5cclxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICB7Y3VycmVudFRhc2sgPyBcIlVwZGF0ZSBUYXNrXCIgOiBcIkFkZCBUYXNrXCJ9XHJcbiAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAge2N1cnJlbnRUYXNrXHJcbiAgICAgICAgICAgICAgICA/IFwiVXBkYXRlIHRoZSB0YXNrIGRldGFpbHMgYW5kIGFzc2lnbm1lbnQgaW5mb3JtYXRpb24uXCJcclxuICAgICAgICAgICAgICAgIDogXCJDcmVhdGUgYW5kIGFzc2lnbiBhIG5ldyB0YXNrLlwifVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTVcIj5cclxuICAgICAgICAgICAgey8qIFRhc2sgQXNzaWduZWQgQnkgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgIFRhc2sgQXNzaWduZWQgQnkgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2xvZ2dlZEluQWRtaW5OYW1lIHx8IFwiQWRtaW5cIn1cclxuICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMCBweC0zIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBiZy1ncmF5LTUwIHRleHQtZ3JheS01MDAgdGV4dC1zbSBzaGFkb3ctc20gb3V0bGluZS1ub25lIGN1cnNvci1ub3QtYWxsb3dlZFwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHR5cGU9XCJoaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgbmFtZT1cImFzc2lnbmVkQnlcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2xvZ2dlZEluQWRtaW5JZH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBUYXNrIEFzc2lnbmVkIFRvICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICBUYXNrIEFzc2lnbmVkIFRvIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgbmFtZT1cImFzc2lnbmVkVG9cIlxyXG4gICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgY2hpbGRyZW4gPSBvcHRpb24/LnByb3BzPy5jaGlsZHJlbj8udG9TdHJpbmcoKSB8fCBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICByZXR1cm4gY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYXNzaWduZWRUbyB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwiYXNzaWduZWRUb1wiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2FnZW50cy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICBhZ2VudHMubWFwKChhZ2VudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxPcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9IHwge2FnZW50LnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICA8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJcIj5ObyBhZ2VudHMgYXZhaWxhYmxlPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIHthZ2VudHMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1yZWQtNTAwIG10LTEuNVwiPlxyXG4gICAgICAgICAgICAgICAgICBObyBhZ2VudHMgZm91bmQuIFBsZWFzZSBhZGQgYWdlbnRzIGZpcnN0LlxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIEFzc2lnbmVlIFR5cGUgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgIEFzc2lnbmVlIFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBBc3NpZ25lZSBUeXBlXCJcclxuICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF90eXBlXCJcclxuICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGNoaWxkcmVuID0gb3B0aW9uPy5wcm9wcz8uY2hpbGRyZW4/LnRvU3RyaW5nKCkgfHwgXCJcIjtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSk7XHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnJlZmVycmVkX3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50RFNlbGVjdChcInJlZmVycmVkX3R5cGVcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgc3RhdHVzPXshZm9ybURhdGEucmVmZXJyZWRfdHlwZSAmJiBmb3JtRGF0YS5yZWZlcnJlZF90eXBlICE9PSBcIlwiID8gXCJlcnJvclwiIDogXCJcIn1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiTGVhZFwiPkxlYWQ8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJFbXBsb3llZVwiPkVtcGxveWVlPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiQ3VzdG9tZXJcIj5DdXN0b21lcjwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIHsvKiB7IWZvcm1EYXRhLnJlZmVycmVkX3R5cGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXJlZC01MDAgbXQtMS41XCI+XHJcbiAgICAgICAgICAgICAgICAgIFBsZWFzZSBzZWxlY3QgYW4gYXNzaWduZWUgdHlwZVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICl9ICovfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBDb25kaXRpb25hbDogTGVhZCAqL31cclxuICAgICAgICAgICAge2Zvcm1EYXRhLnJlZmVycmVkX3R5cGUgPT09IFwiTGVhZFwiICYmIChcclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IExlYWRcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgTGVhZFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJsZWFkXCJcclxuICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNoaWxkcmVuID0gb3B0aW9uPy5wcm9wcz8uY2hpbGRyZW4/LnRvU3RyaW5nKCkgfHwgXCJcIjtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmxlYWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwibGVhZFwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtsZWFkcy5tYXAoKGwpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8T3B0aW9uIGtleT17bC5faWR9IHZhbHVlPXtsLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bC5sZWFkX25hbWV9IHwge2wubGVhZF9waG9uZX1cclxuICAgICAgICAgICAgICAgICAgICA8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBDb25kaXRpb25hbDogRW1wbG95ZWUgKi99XHJcbiAgICAgICAgICAgIHtmb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkVtcGxveWVlXCIgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBTZWxlY3QgRW1wbG95ZWVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiZW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY2hpbGRyZW4gPSBvcHRpb24/LnByb3BzPy5jaGlsZHJlbj8udG9TdHJpbmcoKSB8fCBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZW1wbG95ZWUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwiZW1wbG95ZWVcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxPcHRpb24ga2V5PXthLl9pZH0gdmFsdWU9e2EuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHthLm5hbWV9IHwge2EucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgey8qIENvbmRpdGlvbmFsOiBDdXN0b21lciAqL31cclxuICAgICAgICAgICAge2Zvcm1EYXRhLnJlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIiAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIFNlbGVjdCBDdXN0b21lclxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBDdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJjdXN0b21lclwiXHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zdCBjaGlsZHJlbiA9IG9wdGlvbj8ucHJvcHM/LmNoaWxkcmVuPy50b1N0cmluZygpIHx8IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5jdXN0b21lciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJjdXN0b21lclwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtjdXN0b21lcnMubWFwKChjKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPE9wdGlvbiBrZXk9e2MuX2lkfSB2YWx1ZT17Yy5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge2MuZnVsbF9uYW1lIHx8IGMubmFtZSB8fCBcIlVubmFtZWRcIn0gfCB7Yy5waG9uZV9udW1iZXIgfHwgYy5waG9uZSB8fCBjLm1vYmlsZSB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgIDwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgey8qIFRhc2sgUHVycG9zZSAqL31cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgVGFzayBQdXJwb3NlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUHVycG9zZVwiXHJcbiAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICBuYW1lPVwicHVycG9zZVwiXHJcbiAgICAgICAgICAgICAgICBvcHRpb25GaWx0ZXJQcm9wPVwiY2hpbGRyZW5cIlxyXG4gICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBjaGlsZHJlbiA9IG9wdGlvbj8ucHJvcHM/LmNoaWxkcmVuPy50b1N0cmluZygpIHx8IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjaGlsZHJlbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wdXJwb3NlIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJwdXJwb3NlXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiQ3VzdG9tZXIgVmlzaXRcIj5DdXN0b21lciBWaXNpdDwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIkZvbGxvdyBVcFwiPkZvbGxvdyBVcDwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIk5ldyBCdXNpbmVzc1wiPk5ldyBCdXNpbmVzczwvT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgPE9wdGlvbiB2YWx1ZT1cIlN1cHBvcnRcIj5TdXBwb3J0PC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgICA8T3B0aW9uIHZhbHVlPVwiSW5xdWlyeVwiPklucXVpcnk8L09wdGlvbj5cclxuICAgICAgICAgICAgICAgIDxPcHRpb24gdmFsdWU9XCJPdGhlclwiPk90aGVyPC9PcHRpb24+XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIFRhc2sgRGVzY3JpcHRpb24gKi99XHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgIFRhc2sgRGVzY3JpcHRpb24gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICAgICAgbmFtZT1cInRhc2tEZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudGFza0Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0fVxyXG4gICAgICAgICAgICAgICAgcm93cz1cIjRcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0YXNrIGRlc2NyaXB0aW9uLi4uXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIuNSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHJvdW5kZWQtbGcgYmctd2hpdGUgdGV4dC1zbSB0ZXh0LWdyYXktNzAwIHBsYWNlaG9sZGVyLWdyYXktNDAwIHNoYWRvdy1zbSBvdXRsaW5lLW5vbmUgcmVzaXplLW5vbmUgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtMTAwIHRyYW5zaXRpb25cIlxyXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBEYXRlL1RpbWUgKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBTdGFydCBEYXRlICYgVGltZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZXRpbWUtbG9jYWxcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwic3RhcnREYXRlXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnN0YXJ0RGF0ZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC0xMCBweC0zIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC1sZyBiZy13aGl0ZSB0ZXh0LXNtIHRleHQtZ3JheS03MDAgc2hhZG93LXNtIG91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYmx1ZS01MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctYmx1ZS0xMDAgdHJhbnNpdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBTdGF0dXMgKi99XHJcbiAgICAgICAgICAgIHsvKiA8ZGl2PlxyXG4gICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+VGFzayBTdGF0dXM8L2xhYmVsPlxyXG4gICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgIG5hbWU9XCJzdGF0dXNcIlxyXG4gICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnN0YXR1c31cclxuICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWRcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQZW5kaW5nXCI+UGVuZGluZzwvb3B0aW9uPlxyXG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkluIFByb2dyZXNzXCI+SW4gUHJvZ3Jlc3M8L29wdGlvbj5cclxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDb21wbGV0ZWRcIj5Db21wbGV0ZWQ8L29wdGlvbj5cclxuICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgPC9kaXY+ICovfVxyXG5cclxuICAgICAgICAgICAgey8qIEFwcHJvdmFsIFN0YXR1cyAqL31cclxuICAgICAgICAgICAgey8qIDxkaXY+XHJcbiAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1tZWRpdW1cIj5BcHByb3ZhbCBTdGF0dXM8L2xhYmVsPlxyXG4gICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgIG5hbWU9XCJhcHByb3ZhbF9zdGF0dXNcIlxyXG4gICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLmFwcHJvdmFsX3N0YXR1c31cclxuICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dH1cclxuICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTIgYm9yZGVyIHJvdW5kZWRcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJQZW5kaW5nXCI+UGVuZGluZzwvb3B0aW9uPlxyXG4gICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFwcHJvdmVkXCI+QXBwcm92ZWQ8L29wdGlvbj5cclxuICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgPC9kaXY+ICovfVxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHB0LTMgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwXCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvIG1pbi13LVsxMjBweF0gYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWluZGlnby02MDAgdGV4dC13aGl0ZSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgcHgtNSBweS0yLjUgcm91bmRlZC1sZyBzaGFkb3ctbWQgaG92ZXI6ZnJvbS1ibHVlLTcwMCBob3Zlcjp0by1pbmRpZ28tNzAwIGhvdmVyOnNoYWRvdy1sZyBhY3RpdmU6c2NhbGUtWzAuOThdIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ29udGludWVcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRhc2s7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL1Rhc2suanN4In0=