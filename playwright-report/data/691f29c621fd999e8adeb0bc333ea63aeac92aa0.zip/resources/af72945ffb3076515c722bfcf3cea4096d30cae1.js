import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Auction.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"]; const useRef = __vite__cjsImport3_react["useRef"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import { MdDelete } from "/node_modules/.vite/deps/react-icons_md.js?v=819e0a34";
import { CiEdit } from "/node_modules/.vite/deps/react-icons_ci.js?v=819e0a34";
import Modal from "/src/components/modals/Modal.jsx";
import { BsEye } from "/node_modules/.vite/deps/react-icons_bs.js?v=819e0a34";
import { Button, Dropdown, Input, Spin } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import { EyeIcon } from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Tag, Tooltip } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import { FaUserCheck, FaChevronRight } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { GiMoneyStack } from "/node_modules/.vite/deps/react-icons_gi.js?v=819e0a34";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
import {
  X,
  Search,
  FileText,
  PieChart,
  Receipt,
  List,
  Info,
  Users
} from "/node_modules/.vite/deps/lucide-react.js?v=819e0a34";
import {
  CheckCircleOutlined,
  ClockCircleOutlined,
  WarningOutlined
} from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
const Auction = () => {
  _s();
  const isOnline = navigator.onLine;
  const [groups, setGroups] = useState([]);
  const [TableAuctions, setTableAuctions] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [selectedAuctionGroup, setSelectedAuctionGroup] = useState("");
  const [selectedGroupId, setSelectedGroupId] = useState("");
  const [selectedAuctionGroupId, setSelectedAuctionGroupId] = useState("");
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [filteredAuction, setFilteredAuction] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [showBidDrawer, setShowBidDrawer] = useState(false);
  const [bidRequests, setBidRequests] = useState([]);
  const [bidDrawerSearch, setBidDrawerSearch] = useState("");
  const [loadingBidRequests, setLoadingBidRequests] = useState(false);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [double, setDouble] = useState({});
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [drawerTab, setDrawerTab] = useState("bidrequests");
  const [hasFetched, setHasFetched] = useState(false);
  const hasLoadedRef = useRef(false);
  const hasFetchedGroups = useRef(false);
  const [showTransactionModal, setShowTransactionModal] = useState(false);
  const [transactionData, setTransactionData] = useState([]);
  const [loadingTransaction, setLoadingTransaction] = useState(false);
  const [recentAuctions, setRecentAuctions] = useState([]);
  const [runRecentAuction, setRunRecentAuction] = useState(true);
  const [loadingRecent, setLoadingRecent] = useState(false);
  const [customerOptions, setCustomerOptions] = useState([]);
  const [advancePayouts, setAdvancePayouts] = useState([]);
  const [showAdvancePayoutModal, setShowAdvancePayoutModal] = useState(false);
  const [GroupOverview, setGroupOverview] = useState(false);
  const [GroupOverviewData, setGroupOverviewData] = useState([]);
  const [showGroupOverviewModal, setshowGroupOverviewModal] = useState(false);
  const [loadingGroupOverview, setLoadingGroupOverview] = useState(false);
  const [showPayoutModal, setShowPayoutModal] = useState(false);
  const [payoutData, setPayoutData] = useState([]);
  const [loadingPayout, setLoadingPayout] = useState(false);
  const [isCommencementDone, setIsCommencementDone] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState("auctions");
  const [preAuctionGroups, setPreAuctionGroups] = useState([]);
  const [preAuctionSelectedGroupId, setPreAuctionSelectedGroupId] = useState("");
  const [preAuctionTableData, setPreAuctionTableData] = useState([]);
  const [preAuctionLoading, setPreAuctionLoading] = useState(false);
  const [preAuctionHasFetchedGroups, setPreAuctionHasFetchedGroups] = useState(false);
  const [preAuctionHasFetchedData, setPreAuctionHasFetchedData] = useState(false);
  const [isAuctionCompleted, setIsAuctionCompleted] = useState(false);
  const [auctionStatusLoading, setAuctionStatusLoading] = useState(false);
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [formData, setFormData] = useState({
    auction_code: "",
    group_id: "",
    user_id: "",
    ticket: "",
    bid_amount: "",
    commission: "",
    win_amount: "",
    divident: "",
    divident_head: "",
    payable: "",
    auction_date: "",
    auction_time: "",
    next_date: "",
    next_auction_time: "",
    group_type: "",
    auction_type: "normal",
    bid_request_id: ""
  });
  const [updateFormData, setUpdateFormData] = useState({
    auction_date: "",
    auction_time: "",
    next_date: "",
    next_auction_time: ""
  });
  useEffect(() => {
    if (hasFetchedGroups.current) return;
    const fetchGroups = async () => {
      if (!navigator.onLine) return;
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
    hasFetchedGroups.current = true;
  }, []);
  const fetchPreAuctionGroups = async () => {
    if (!navigator.onLine) return;
    setPreAuctionLoading(true);
    try {
      const response = await api.get("/v1/admin/groups/pre-auction");
      setPreAuctionGroups(response.data?.data || response.data || []);
      setPreAuctionHasFetchedGroups(true);
    } catch (error) {
      console.error("Error fetching pre‑auction groups:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to load pre‑auction groups",
        type: "error"
      });
    } finally {
      setPreAuctionLoading(false);
    }
  };
  const fetchPreAuctionGroupAuctions = async (groupId) => {
    if (!groupId) {
      setPreAuctionTableData([]);
      setPreAuctionHasFetchedData(true);
      return;
    }
    setPreAuctionLoading(true);
    setPreAuctionHasFetchedData(false);
    try {
      const response = await api.get(`/v1/admin/groups/auction/${groupId}`);
      const auctions = response.data?.data || response.data || [];
      if (Array.isArray(auctions) && auctions.length > 0) {
        const formatted = auctions.map((auction, index) => ({
          _id: auction._id,
          id: index + 1,
          auction_code: auction.auction_code || "N/A",
          auction_date: auction.auction_date?.split("T")[0] || auction.auction_date || "N/A",
          next_date: auction.next_date?.split("T")[0] || auction.next_date || "N/A",
          name: auction.user_id?.full_name || "N/A",
          phone_number: auction.user_id?.phone_number || "N/A",
          ticket: auction.ticket || "N/A",
          bid_amount: (parseInt(auction.divident) || 0) + (parseInt(auction.commission) || 0),
          amount: auction.win_amount || "N/A",
          auction_type: auction?.auction_stage_type === "COMMENCEMENT" ? "COMMENCEMENT" : auction.auction_type ? auction.auction_type.charAt(0).toUpperCase() + auction.auction_type.slice(1) : "N/A"
          // action: (
          //   <div className="flex justify-center gap-2">
          //     <Dropdown
          //       menu={{
          //         items: [
          //           {
          //             key: '1',
          //             label: (
          //               <div
          //                 className="text-green-600"
          //                 onClick={() => handleUpdateModalOpen(auction._id, index + 2)}
          //               >
          //                 Edit
          //               </div>
          //             ),
          //           },
          //           {
          //             key: '2',
          //             label: (
          //               <div
          //                 className="text-red-600"
          //                 onClick={() => handleDeleteModalOpen(auction._id)}
          //               >
          //                 Delete
          //               </div>
          //             ),
          //           },
          //         ],
          //       }}
          //       placement="bottomLeft"
          //     >
          //       <IoMdMore className="text-bold" />
          //     </Dropdown>
          //   </div>
          // ),
        }));
        setPreAuctionTableData(formatted);
      } else {
        setPreAuctionTableData([]);
      }
    } catch (error) {
      console.error("Error fetching pre‑auction auctions:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to load auction data",
        type: "error"
      });
      setPreAuctionTableData([]);
    } finally {
      setPreAuctionLoading(false);
      setPreAuctionHasFetchedData(true);
    }
  };
  const handlePreAuctionGroupChange = (groupId) => {
    setPreAuctionSelectedGroupId(groupId);
    fetchPreAuctionGroupAuctions(groupId);
  };
  useEffect(() => {
    if (activeTab === "preAuction" && !preAuctionHasFetchedGroups) {
      fetchPreAuctionGroups();
    }
  }, [activeTab, preAuctionHasFetchedGroups]);
  useEffect(() => {
    const fetchDouble = async () => {
      if (selectedAuctionGroupId && selectedAuctionGroupId !== "recent") {
        try {
          const response = await api.get(
            `/double/get-double/${selectedAuctionGroupId}`
          );
          setDouble(response.data);
        } catch (error) {
          console.error("Error fetching group data:", error);
          setDouble({});
        }
      } else {
        setDouble({});
      }
    };
    fetchDouble();
  }, [selectedAuctionGroupId]);
  useEffect(() => {
    if (hasLoadedRef.current) return;
    const loadDefaultAuctions = async () => {
      setSelectedAuctionGroupId("recent");
      await fetchRecentAuctions();
    };
    loadDefaultAuctions();
    hasLoadedRef.current = true;
  }, []);
  const fetchBidRequestsForAuction = async (groupId) => {
    setLoadingBidRequests(true);
    try {
      const response = await api.get(`/bid-request/get-for-auction/${groupId}`);
      if (response.data?.success && response.data?.data?.length > 0) {
        setBidRequests(response.data.data);
        setTimeout(() => {
          setShowBidDrawer(true);
          setDrawerTab("bidrequests");
        }, 100);
      } else {
        setBidRequests([]);
        setShowBidDrawer(false);
      }
    } catch (error) {
      console.error("Error fetching bid requests for auction:", error);
      setBidRequests([]);
      setShowBidDrawer(false);
    } finally {
      setLoadingBidRequests(false);
    }
  };
  const fetchBidRequests = async (groupId) => {
    try {
      const response = await api.get(
        `/enroll/get-group-enroll-auction-all/${groupId}`
      );
      if (response.data && response.data.length > 0) {
        setFilteredUsers(response.data);
      } else {
        setFilteredUsers([]);
      }
    } catch (error) {
      console.error("Error fetching enrollment data:", error);
      setFilteredUsers([]);
    }
  };
  const validateForm = () => {
    const newErrors = {};
    if (!selectedGroupId) {
      newErrors.group = "Group selection is required";
    }
    if (!formData.auction_date) {
      newErrors.auction_date = "Auction date is required";
    }
    if (!formData.auction_time) {
      newErrors.auction_time = "Auction time is required";
    }
    if (!formData.next_date) {
      newErrors.next_date = "Next date is required";
    } else if (formData.next_date < formData.auction_date) {
      newErrors.next_date = "Next date cannot be in the past";
    }
    if (!formData.next_auction_time) {
      newErrors.next_auction_time = "Next auction time is required";
    }
    if (isCommencementDone) {
      if (groupInfo.group_type === "double" && !formData.auction_type) {
        newErrors.auction_type = "Auction type is required";
      }
      if (!formData.user_id) {
        newErrors.customer = "Customer selection is required";
      }
      if (!formData.bid_amount) {
        newErrors.bid_amount = "Bid amount is required";
      } else if (isNaN(formData.bid_amount) || parseFloat(formData.bid_amount) <= 0) {
        newErrors.bid_amount = "Bid amount must be a positive number";
      } else if (groupInfo.group_value && parseFloat(formData.bid_amount) > parseFloat(groupInfo.group_value)) {
        newErrors.bid_amount = `Bid amount cannot exceed group value of ${groupInfo.group_value}`;
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => {
      const updatedData = {
        ...prevData,
        [name]: value
      };
      if (name === "auction_date" && value) {
        const nextDate = new Date(value);
        nextDate.setDate(nextDate.getDate() + 10);
        updatedData.next_date = nextDate.toISOString().split("T")[0];
      }
      return updatedData;
    });
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: ""
    }));
  };
  const handleChangeUser = (value) => {
    const [user_id, ticket] = value.split("-");
    setFormData((prevData) => ({
      ...prevData,
      user_id,
      ticket
    }));
    setErrors((prevErrors) => ({ ...prevErrors, customer: "" }));
  };
  const handleBidRequestSelect = (bidRequest) => {
    if (bidRequest?.subscriberId && bidRequest?.ticketNumber) {
      const value = `${bidRequest.subscriberId}-${bidRequest.ticketNumber}`;
      handleChangeUser(value);
      setFormData((prevData) => ({
        ...prevData,
        bid_request_id: bidRequest._id
      }));
    }
  };
  const handleGroupChange = async (groupId) => {
    setSelectedGroup(groupId);
    if (groupId) {
      try {
        await fetchBidRequests(groupId);
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
      }
    } else {
      setFilteredUsers([]);
    }
  };
  const fetchAdvancePayouts = async (groupId) => {
    try {
      const response = await api.get(
        `/payment-out/get-advance-payout-before-auction/${groupId}`
      );
      if (response.data?.success && response.data?.data?.length > 0) {
        setAdvancePayouts(response.data.data);
      } else {
        setAdvancePayouts([]);
      }
    } catch (error) {
      console.error("Error fetching advance payouts:", error);
      setAdvancePayouts([]);
    }
  };
  const handleGroup = async (groupId) => {
    setErrors((prevErrors) => ({ ...prevErrors, group: "" }));
    setSelectedGroupId(groupId);
    handleGroupChange(groupId);
    if (groupId) {
      setLoading(true);
      setAuctionStatusLoading(true);
      try {
        const [res1, res2, res3] = await Promise.all(
          [
            api.get(`/group/get-by-id-group/${groupId}`),
            api.get(`/v1/admin/auctions/commencement-status/groups/${groupId}`),
            api.get(`/v1/admin/auctions/groups/${groupId}/status`)
          ]
        );
        setGroupInfo(res1.data || {});
        setIsCommencementDone(res2.data?.data?.is_commencement_done);
        setIsAuctionCompleted(
          res3.data?.data?.is_auction_completed === true
        );
        await Promise.all(
          [
            fetchBidRequestsForAuction(groupId),
            fetchAdvancePayouts(groupId)
          ]
        );
        setShowBidDrawer(true);
        setDrawerTab("bidrequests");
      } catch (error) {
        console.error("Error fetching group data:", error);
        setGroupInfo({});
        setIsAuctionCompleted(false);
        setShowBidDrawer(true);
      } finally {
        setLoading(false);
        setAuctionStatusLoading(false);
      }
    } else {
      setGroupInfo({});
      setBidRequests([]);
      setAdvancePayouts([]);
      setIsAuctionCompleted(false);
      setShowBidDrawer(false);
    }
  };
  const handleGroupAuction = async (value) => {
    if (value === "recent") {
      setSelectedAuctionGroupId("recent");
      await fetchRecentAuctions();
    } else {
      setSelectedAuctionGroupId(value);
      await handleGroupAuctionChange(value);
    }
  };
  const handleGroupAuctionChange = async (groupId) => {
    if (!navigator.onLine) {
      setHasFetched(true);
      setIsLoading(false);
      setLoadingRecent(false);
      return;
    }
    setSelectedAuctionGroup(groupId);
    if (groupId) {
      setTableAuctions([]);
      setIsLoading(true);
      setHasFetched(false);
      try {
        const response = await api.get(`/auction/group-auction/${groupId}`);
        if (response.data && response.data.length > 0) {
          setFilteredAuction(response.data);
          const formattedData = [
            ...response.data.map((group, index) => ({
              _id: group._id,
              id: index + 1,
              auction_code: group?.auction_code,
              auction_date: group?.auction_date,
              next_date: group.next_date,
              name: group.user_id?.full_name,
              phone_number: group.user_id?.phone_number,
              ticket: group?.ticket,
              bid_amount: parseInt(group.divident) + parseInt(group.commission),
              amount: group?.win_amount,
              status: !group?.isPrized ? "Un Prized" : group?.isPrized === "true" ? "Prized" : "Un Prized",
              auction_type: group?.auction_type.charAt(0).toUpperCase() + group?.auction_type.slice(1) + " Auction",
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-green-600",
                            onClick: () => handleUpdateModalOpen(group._id, index + 2),
                            children: "Edit"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                            lineNumber: 602,
                            columnNumber: 21
                          },
                          this
                        )
                      },
                      {
                        key: "2",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-red-600",
                            onClick: () => handleDeleteModalOpen(group._id),
                            children: "Delete"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                            lineNumber: 615,
                            columnNumber: 21
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 627,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 596,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 595,
                columnNumber: 13
              }, this)
            }))
          ];
          setTableAuctions(formattedData);
        } else {
          setFilteredAuction([]);
          setTableAuctions([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredAuction([]);
        setTableAuctions([]);
      } finally {
        setIsLoading(false);
        setHasFetched(true);
      }
    } else {
      setFilteredAuction([]);
      setTableAuctions([]);
      setHasFetched(true);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "auction_code", header: "Auction Code" },
    { key: "auction_date", header: "Auction Date" },
    { key: "next_date", header: "Next Date" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "ticket", header: "Ticket" },
    { key: "bid_amount", header: "Bid Amount" },
    { key: "amount", header: "Win Amount" },
    { key: "auction_type", header: "Auction Type" },
    { key: "status", header: "Status" },
    { key: "action", header: "Action" }
  ];
  const preAuctionColumns = [
    { key: "id", header: "SL. NO" },
    // { key: "auction_code", header: "Auction Code" },
    { key: "auction_date", header: "Auction Date" },
    { key: "next_date", header: "Next Date" },
    // { key: "name", header: "Customer Name" },
    // { key: "phone_number", header: "Customer Phone Number" },
    // { key: "ticket", header: "Ticket" },
    { key: "bid_amount", header: "Bid Amount" },
    { key: "amount", header: "Win Amount" },
    { key: "auction_type", header: "Auction Type" }
    // { key: "status", header: "Status" },
    // { key: "action", header: "Action" },
  ];
  const recentAuctionsColumns = [
    { key: "id", header: "SL. NO" },
    { key: "auction_code", header: "Auction Code" },
    { key: "auction_date", header: "Auction Date" },
    { key: "group_name", header: "Group Name" },
    { key: "group_value", header: "Group Value" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" },
    { key: "ticket", header: "Ticket" },
    { key: "bid_amount", header: "Bid Amount" },
    { key: "amount", header: "Win Amount" },
    { key: "auction_type", header: "Auction Type" },
    { key: "status", header: "Status" },
    { key: "action", header: "Action" }
  ];
  useEffect(() => {
    if (groupInfo && formData.bid_amount) {
      const commission = groupInfo.group_value * groupInfo.group_commission / 100 || 0;
      const win_amount = (groupInfo.group_value || 0) - (formData.bid_amount || 0);
      const divident = (formData.bid_amount || 0) - commission;
      const divident_head = groupInfo.group_members ? divident / groupInfo.group_members : 0;
      const payable = (groupInfo.group_install || 0) - divident_head;
      setFormData((prevData) => ({
        ...prevData,
        group_id: groupInfo._id,
        commission,
        win_amount,
        divident,
        divident_head,
        payable,
        group_type: groupInfo.group_type
      }));
    }
  }, [groupInfo, formData.bid_amount]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSubmitting) return;
    const isValid = validateForm();
    if (!isValid) return;
    try {
      setIsSubmitting(true);
      let payload;
      if (isCommencementDone) {
        payload = formData;
      } else {
        payload = {
          group_id: selectedGroupId,
          auction_date: formData.auction_date,
          next_date: formData.next_date
        };
      }
      const response = await api.post("/auction/add-auction", payload);
      if (response.status === 201) {
        setAlertConfig({
          visibility: true,
          message: "Auction Added Successfully",
          type: "success"
        });
        handleCloseModal();
        if (activeTab === "preAuction") {
          if (preAuctionSelectedGroupId) {
            fetchPreAuctionGroupAuctions(preAuctionSelectedGroupId);
          }
        } else {
          if (selectedAuctionGroupId) {
            handleGroupAuctionChange(selectedAuctionGroupId);
          }
        }
      }
    } catch (error) {
      console.error("Error submitting auction data:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to add auction",
        type: "error"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleDeleteModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/auction/get-auction-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching enroll:", error);
    }
  };
  const handleDeleteAuction = async () => {
    if (currentGroup) {
      try {
        await api.delete(`/auction/delete-auction/${currentGroup._id}`);
        setAlertConfig({
          visibility: true,
          message: "Auction deleted successfully",
          type: "success"
        });
        setShowModalDelete(false);
        setCurrentGroup(null);
        if (selectedAuctionGroupId) {
          handleGroupAuctionChange(selectedAuctionGroupId);
        }
      } catch (error) {
        console.error("Error deleting auction:", error);
      }
    }
  };
  const handleInputChange = async (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevData) => ({
      ...prevData,
      [name]: ""
    }));
  };
  const handleUpdateModalOpen = async (groupId, si) => {
    try {
      const response = await api.get(`/auction/get-auction-by-id/${groupId}`);
      setUpdateFormData({
        auction_date: response.data?.auction_date,
        auction_time: response.data?.auction_time,
        next_date: response.data?.next_date,
        next_auction_time: response.data?.next_auction_time
      });
      setCurrentUpdateGroup({ ...response.data, SI_number: si });
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching auction:", error);
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const response = await api.put(
        `/auction/${currentUpdateGroup?._id}`,
        updateFormData
      );
      setShowModalUpdate(false);
      setAlertConfig({
        visibility: true,
        message: "Auction date Updated Successfully",
        type: "success"
      });
      if (activeTab === "preAuction") {
        if (preAuctionSelectedGroupId) {
          fetchPreAuctionGroupAuctions(preAuctionSelectedGroupId);
        }
      } else {
        if (selectedAuctionGroupId) {
          handleGroupAuctionChange(selectedAuctionGroupId);
        }
      }
    } catch (error) {
      console.error("error in updating auction", error);
      if (error.response && error.response.data && error.response.data.message) {
        setAlertConfig({
          visibility: true,
          message: `${error?.response?.data?.message}`,
          type: "error"
        });
      } else {
        setAlertConfig({
          visibility: true,
          message: "An unexpected error occurred. Please try again.",
          type: "error"
        });
      }
    }
  };
  const filteredBidRequests = bidRequests.filter((user) => {
    if (!bidDrawerSearch) return true;
    const fullName = user?.subscriberDetails?.full_name?.toLowerCase() || user?.subscriberName?.toLowerCase() || "";
    const ticket = user?.ticketNumber?.toString().toLowerCase() || "";
    const phone = user?.subscriberDetails?.phone_number?.toString().toLowerCase() || user?.mobileNumber?.toString().toLowerCase() || "";
    const bidCode = user?.bid_request_code?.toString().toLowerCase() || "";
    return fullName.includes(bidDrawerSearch.toLowerCase()) || ticket.includes(bidDrawerSearch.toLowerCase()) || phone.includes(bidDrawerSearch.toLowerCase()) || bidCode.includes(bidDrawerSearch.toLowerCase());
  });
  const handleCloseModal = () => {
    setShowModal(false);
    setShowBidDrawer(false);
    setErrors({});
    setBidRequests([]);
    setBidDrawerSearch("");
    setSelectedGroupId("");
    setGroupInfo({});
    setFilteredUsers([]);
    setDrawerTab("bidrequests");
    setFormData({
      auction_code: "",
      group_id: "",
      user_id: "",
      ticket: "",
      bid_amount: "",
      commission: "",
      win_amount: "",
      divident: "",
      divident_head: "",
      payable: "",
      auction_date: "",
      next_date: "",
      group_type: "",
      auction_type: "normal",
      bid_request_id: ""
    });
    setIsAuctionCompleted(false);
  };
  const handleCloseBidDrawer = () => {
    setShowBidDrawer(false);
  };
  useEffect(() => {
    if (preAuctionGroups.length > 0 && !preAuctionSelectedGroupId) {
      setPreAuctionSelectedGroupId(preAuctionGroups[0]._id);
      handlePreAuctionGroupChange(preAuctionGroups[0]._id);
    }
  }, [preAuctionGroups]);
  const handleSwitchToEnrolled = () => {
    setDrawerTab("enrolled");
  };
  const handleSwitchToBidRequests = () => {
    setDrawerTab("bidrequests");
  };
  const handleSwitchToAdvancePayouts = () => {
    setDrawerTab("advancePayout");
  };
  const handleViewTransaction = async () => {
    if (!selectedGroupId) {
      alert("Please select a group first");
      return;
    }
    setLoadingTransaction(true);
    try {
      const response = await api.get(
        `/auction/get-user-info-by-group/${selectedGroupId}`
      );
      const data = response.data;
      if (data.status === true) {
        setTransactionData(data);
        setShowTransactionModal(true);
      } else {
        let errorMessage = data.message || "No data found";
        if (data.error && data.error.includes("full_name")) {
          errorMessage = "Some user data is corrupted. Please contact support.";
        }
        setAlertConfig({
          visibility: true,
          message: errorMessage,
          type: "warning"
        });
      }
    } catch (error) {
      console.error("Error fetching user info:", error);
      let errorMessage = "Failed to fetch user information";
      if (error.response?.data?.error) {
        errorMessage = error.response.data.error;
      } else if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      }
      setAlertConfig({
        visibility: true,
        message: errorMessage,
        type: "error"
      });
    } finally {
      setLoadingTransaction(false);
    }
  };
  const fetchRecentAuctions = async () => {
    if (!navigator.onLine) {
      setHasFetched(true);
      setIsLoading(false);
      setLoadingRecent(false);
      return;
    }
    try {
      const response = await api.get("/v1/admin/auctions/recent");
      const auctionsData = response.data?.data || response.data;
      if (auctionsData && Array.isArray(auctionsData) && auctionsData.length > 0) {
        setRecentAuctions(auctionsData);
        const formattedData = auctionsData.map((auction, index) => ({
          _id: auction._id,
          id: index + 1,
          auction_code: auction?.auction_code,
          auction_date: auction?.auction_date?.split("T")[0] || auction?.auction_date,
          group_name: auction.group_id?.group_name || "N/A",
          group_value: auction.group_id?.group_value || "N/A",
          name: auction.user_id?.full_name || "N/A",
          phone_number: auction.user_id?.phone_number || "N/A",
          ticket: auction?.ticket,
          bid_amount: (parseInt(auction.divident) || 0) + (parseInt(auction.commission) || 0),
          amount: auction?.win_amount,
          auction_type: auction?.auction_type?.charAt(0).toUpperCase() + auction?.auction_type?.slice(1) + " Auction",
          status: !auction?.isPrized ? "Un Prized" : auction?.isPrized === "true" ? "Prized" : "Un Prized",
          action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
            Dropdown,
            {
              menu: {
                items: [
                  {
                    key: "1",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-green-600",
                        onClick: () => handleUpdateModalOpen(auction._id, index + 2),
                        children: "Edit"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 1063,
                        columnNumber: 19
                      },
                      this
                    )
                  },
                  {
                    key: "2",
                    label: /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "text-red-600",
                        onClick: () => handleDeleteModalOpen(auction._id),
                        children: "Delete"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 1076,
                        columnNumber: 19
                      },
                      this
                    )
                  }
                ]
              },
              placement: "bottomLeft",
              children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1088,
                columnNumber: 17
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1057,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1056,
            columnNumber: 11
          }, this)
        }));
        setTableAuctions(formattedData);
      } else {
        setRecentAuctions([]);
        setTableAuctions([]);
      }
    } catch (error) {
      console.error("Error fetching recent auctions:", error);
      setAlertConfig({
        visibility: true,
        message: error.response?.data?.message || "Failed to fetch recent auctions",
        type: "error"
      });
      setTableAuctions([]);
      setHasFetched(true);
    } finally {
      setLoadingRecent(false);
      setHasFetched(true);
    }
  };
  const handleGroupOverview = async () => {
    if (!selectedGroupId) {
      alert("Please select a group first");
      return;
    }
    setLoadingGroupOverview(true);
    try {
      const response = await api.get(
        `/auction/get-auction-info/${selectedGroupId}`
      );
      const data = response.data;
      if (data.status === true) {
        setGroupOverviewData(data);
        setshowGroupOverviewModal(true);
      } else {
        let errorMessage = data.message || "No data found";
        if (data.error && data.error.includes("full_name")) {
          errorMessage = "Some user data is corrupted. Please contact support.";
        }
        setAlertConfig({
          visibility: true,
          message: errorMessage,
          type: "warning"
        });
      }
    } catch (error) {
      console.error("Error fetching group overview:", error);
      let errorMessage = "Failed to fetch group overview";
      if (error.response?.data?.error) {
        errorMessage = error.response.data.error;
      } else if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      }
      setAlertConfig({
        visibility: true,
        message: errorMessage,
        type: "error"
      });
    } finally {
      setLoadingGroupOverview(false);
    }
  };
  const handlePayoutInformation = async () => {
    if (!selectedGroupId) {
      alert("Please select a group first");
      return;
    }
    setLoadingPayout(true);
    try {
      const response = await api.get(
        `/auction/get-payout-by-group/${selectedGroupId}`
      );
      const data = response.data;
      if (data.status === true) {
        setPayoutData(data.data || []);
        setShowPayoutModal(true);
      } else {
        let errorMessage = data.message || "No data found";
        setAlertConfig({
          visibility: true,
          message: errorMessage,
          type: "warning"
        });
      }
    } catch (error) {
      console.error("Error fetching payout information:", error);
      let errorMessage = "Failed to fetch payout information";
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      }
      setAlertConfig({
        visibility: true,
        message: errorMessage,
        type: "error"
      });
    } finally {
      setLoadingPayout(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
    /* @__PURE__ */ jsxDEV(
      Navbar,
      {
        onGlobalSearchChangeHandler,
        visibility: true
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 1209,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
      lineNumber: 1213,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(
      CustomAlert,
      {
        type: alertConfig.type,
        isVisible: alertConfig.visibility,
        message: alertConfig.message
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 1215,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: handleCloseModal, children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: "Add Auction" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 1225,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleViewTransaction,
              className: "flex items-center gap-2 border-2 border-green-500 text-green-600 hover:bg-green-500 hover:text-white font-medium rounded-lg text-sm px-4 py-2 transition-all duration-200",
              children: [
                /* @__PURE__ */ jsxDEV(Users, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1231,
                  columnNumber: 21
                }, this),
                "Customer Summary"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1227,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handleGroupOverview,
              className: "flex items-center gap-2 border-2 border-purple-500 text-purple-600 hover:bg-purple-500 hover:text-white font-medium rounded-lg text-sm px-4 py-2 transition-all duration-200",
              children: [
                /* @__PURE__ */ jsxDEV(PieChart, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1239,
                  columnNumber: 21
                }, this),
                "Group Overview"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1235,
              columnNumber: 19
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: handlePayoutInformation,
              className: "flex items-center gap-2 border-2 border-orange-500 text-orange-600 hover:bg-orange-500 hover:text-white font-medium rounded-lg text-sm px-4 py-2 transition-all duration-200",
              children: [
                /* @__PURE__ */ jsxDEV(FileText, { className: "w-4 h-4" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1247,
                  columnNumber: 21
                }, this),
                "Payout Information"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1243,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 1226,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 1224,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-5", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
            "Group ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1257,
              columnNumber: 27
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1256,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full`,
              placeholder: "Select or Search group",
              popupMatchSelectWidth: false,
              showSearch: true,
              name: "group_id",
              value: selectedGroupId || void 0,
              onChange: (value) => handleGroup(value),
              filterOption: (input, option) => option?.children?.toLowerCase().includes(input.toLowerCase()),
              children: groups.map(
                (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1274,
                  columnNumber: 21
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1259,
              columnNumber: 19
            },
            this
          ),
          errors.group && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.group }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1280,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 1255,
          columnNumber: 17
        }, this),
        auctionStatusLoading && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-blue-600", children: "Checking auction status..." }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 1285,
          columnNumber: 17
        }, this),
        isAuctionCompleted ? /* @__PURE__ */ jsxDEV("div", { className: "mt-3 flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 p-4 shadow-sm", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-red-100", children: /* @__PURE__ */ jsxDEV("span", { className: "text-lg", children: "⚠️" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1293,
            columnNumber: 23
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1292,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-red-800", children: "Auction Already Completed" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1297,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs leading-5 text-red-600", children: "This group’s auction has already been completed. New auctions cannot be added to this group." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1300,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1296,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 1291,
          columnNumber: 17
        }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Group Value" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1310,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "number",
                  name: "group_value",
                  value: groupInfo.group_value || 0,
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1313,
                  columnNumber: 25
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(groupInfo?.group_value || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1320,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1309,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Group Installment" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1325,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "group_install",
                  value: groupInfo.group_install || 0,
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1328,
                  columnNumber: 25
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(groupInfo?.group_install || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1335,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1324,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1308,
            columnNumber: 21
          }, this),
          groupInfo.group_type === "double" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
            /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Auction Type" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1343,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                name: "auction_type",
                value: formData.auction_type,
                onChange: handleChange,
                required: true,
                className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: "normal", children: "Normal Auction" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1353,
                    columnNumber: 27
                  }, this),
                  /* @__PURE__ */ jsxDEV("option", { value: "free", children: "Free Auction" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1354,
                    columnNumber: 27
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1346,
                columnNumber: 25
              },
              this
            ),
            errors.auction_type && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.auction_type }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1357,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1342,
            columnNumber: 19
          }, this),
          isCommencementDone && /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(Spin, { spinning: loading, children: /* @__PURE__ */ jsxDEV("div", { className: loading ? "opacity-50 pointer-events-none" : "", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Customers ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1370,
                  columnNumber: 43
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1369,
                columnNumber: 31
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full`,
                  placeholder: "Select or Search Customer",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "user_id",
                  value: formData.user_id && formData.ticket ? `${formData.user_id}-${formData.ticket}` : void 0,
                  onChange: handleChangeUser,
                  filterOption: (input, option) => option?.children?.toLowerCase().includes(input.toLowerCase()),
                  children: filteredUsers.map(
                    (user) => user?.user_id?._id && /* @__PURE__ */ jsxDEV(
                      Select.Option,
                      {
                        value: `${user.user_id._id}-${user.tickets}`,
                        children: `${user.user_id.full_name} | ${user.tickets}`
                      },
                      `${user.user_id._id}-${user.tickets}`,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 1393,
                        columnNumber: 31
                      },
                      this
                    )
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1372,
                  columnNumber: 31
                },
                this
              ),
              errors.customer && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.customer }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1403,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1368,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900 mt-3", children: [
                "Bid Amount ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1411,
                  columnNumber: 44
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1410,
                columnNumber: 31
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  name: "bid_amount",
                  value: formData.bid_amount,
                  onChange: handleChange,
                  placeholder: "Enter the Bid Amount",
                  required: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1413,
                  columnNumber: 31
                },
                this
              ),
              errors.bid_amount && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.bid_amount }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1423,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(formData?.bid_amount || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1427,
                columnNumber: 31
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1409,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Commission" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1434,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "commission",
                    value: formData.commission,
                    readOnly: true,
                    disabled: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1437,
                    columnNumber: 33
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(formData?.commission || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1445,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1433,
                columnNumber: 31
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Winning Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1450,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "win_amount",
                    value: formData.win_amount,
                    readOnly: true,
                    disabled: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1453,
                    columnNumber: 33
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(formData?.win_amount || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1461,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1449,
                columnNumber: 31
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1432,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4 mt-3", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Divident" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1469,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "divident",
                    value: formData.divident,
                    readOnly: true,
                    disabled: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1472,
                    columnNumber: 33
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(formData?.divident || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1480,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1468,
                columnNumber: 31
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Divident per Head" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1485,
                  columnNumber: 33
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "divident_head",
                    value: formData.divident_head,
                    readOnly: true,
                    disabled: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1488,
                    columnNumber: 33
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(formData?.divident_head || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1496,
                  columnNumber: 33
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1484,
                columnNumber: 31
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1467,
              columnNumber: 29
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full mt-2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Next Payable" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1503,
                columnNumber: 31
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  name: "payable",
                  value: formData.payable,
                  readOnly: true,
                  disabled: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1506,
                  columnNumber: 31
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(formData?.payable || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1514,
                columnNumber: 31
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1502,
              columnNumber: 29
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1366,
            columnNumber: 27
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1365,
            columnNumber: 25
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1364,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Auction Date ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1526,
                  columnNumber: 40
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1525,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  name: "auction_date",
                  value: formData.auction_date,
                  onChange: handleChange,
                  required: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1528,
                  columnNumber: 25
                },
                this
              ),
              errors.auction_date && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.auction_date }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1537,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1524,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Auction Time",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1544,
                  columnNumber: 39
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1543,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "time",
                  name: "auction_time",
                  value: formData.auction_time,
                  onChange: handleChange,
                  required: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1546,
                  columnNumber: 25
                },
                this
              ),
              errors.auction_time && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.auction_time }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1555,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1542,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1523,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Next Auction Date ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1564,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1563,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "date",
                  name: "next_date",
                  value: formData.next_date,
                  onChange: handleChange,
                  required: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1566,
                  columnNumber: 25
                },
                this
              ),
              errors.next_date && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.next_date }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1575,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1562,
              columnNumber: 23
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Next Auction Time ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1582,
                  columnNumber: 45
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1581,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "time",
                  name: "next_auction_time",
                  value: formData.next_auction_time,
                  onChange: handleChange,
                  required: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1584,
                  columnNumber: 25
                },
                this
              ),
              errors.next_auction_time && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.next_auction_time }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1593,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1580,
              columnNumber: 23
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1561,
            columnNumber: 21
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
            Button,
            {
              type: "primary",
              htmlType: "submit",
              loading: isSubmitting,
              disabled: isSubmitting,
              className: "w-1/3",
              children: "Save Auction"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1601,
              columnNumber: 23
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1600,
            columnNumber: 21
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 1307,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 1253,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
      lineNumber: 1223,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
      lineNumber: 1222,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        className: `fixed top-0 right-0 h-full w-[420px] bg-white shadow-2xl z-[9999] transition-transform duration-300 ease-in-out flex flex-col border-l border-gray-200 ${showBidDrawer ? "translate-x-0" : "translate-x-full"}`,
        style: { pointerEvents: showBidDrawer ? "auto" : "none" },
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-white", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(FaUserCheck, { className: "text-white text-sm" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1629,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1628,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { children: [
                /* @__PURE__ */ jsxDEV("h4", { className: "text-base font-bold text-gray-900", children: drawerTab === "bidrequests" ? "Bid Requests" : "Advance Payouts" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1633,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500", children: groupInfo.group_name || "Select a group" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1636,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1632,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1627,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleCloseBidDrawer,
                className: "w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors",
                children: /* @__PURE__ */ jsxDEV(X, { size: 18 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1653,
                  columnNumber: 19
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1649,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1626,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1625,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-2 border-b border-gray-100 bg-gray-50", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1 bg-gray-200 rounded-lg p-1", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleSwitchToBidRequests,
                className: `flex-1 py-2 px-3 rounded-md text-sm font-medium transition-all ${drawerTab === "bidrequests" ? "bg-white text-blue-700 shadow-sm" : "text-gray-500 hover:text-gray-700"}`,
                children: [
                  "Bid Requests (",
                  bidRequests.length,
                  ")"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1674,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: handleSwitchToAdvancePayouts,
                className: `flex-1 py-2 px-3 rounded-md text-sm font-medium transition-all ${drawerTab === "advancePayout" ? "bg-white text-blue-700 shadow-sm" : "text-gray-500 hover:text-gray-700"}`,
                children: [
                  "Advance Payouts (",
                  advancePayouts.length,
                  ")"
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1683,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1673,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1672,
            columnNumber: 13
          }, this),
          drawerTab === "bidrequests" && /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3 border-b border-gray-100", children: /* @__PURE__ */ jsxDEV("div", { className: "relative", children: [
            /* @__PURE__ */ jsxDEV(
              Search,
              {
                className: "absolute left-3 top-1/2 -translate-y-1/2 text-gray-400",
                size: 16
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1698,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "input",
              {
                type: "text",
                placeholder: "Search by name, ticket, phone, code...",
                value: bidDrawerSearch,
                onChange: (e) => setBidDrawerSearch(e.target.value),
                className: "w-full pl-9 pr-4 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-50",
                onClick: (e) => e.stopPropagation()
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1702,
                columnNumber: 19
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1697,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1696,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1 overflow-y-auto", children: loadingBidRequests ? /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center h-full", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1717,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1716,
            columnNumber: 15
          }, this) : drawerTab === "bidrequests" ? filteredBidRequests.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-3 space-y-2", children: filteredBidRequests.map((bidRequest, index) => {
            const fullName = bidRequest?.subscriberDetails?.full_name || bidRequest?.subscriberName || "Unknown";
            const phone = bidRequest?.subscriberDetails?.phone_number || bidRequest?.mobileNumber || "N/A";
            const ticket = bidRequest?.ticketNumber || "N/A";
            const bidCode = bidRequest?.bid_request_code || "-";
            const status = bidRequest?.status || "Pending";
            const isSelected = formData.user_id === bidRequest.subscriberId && formData.ticket === bidRequest.ticketNumber;
            const daysAgo = bidRequest?.daysAgo ? Math.floor(bidRequest.daysAgo) : 0;
            const isNew = daysAgo <= 2;
            const isOld = daysAgo > 7;
            return /* @__PURE__ */ jsxDEV(
              "div",
              {
                onClick: () => handleBidRequestSelect(bidRequest),
                className: `p-3 rounded-xl border cursor-pointer transition-all duration-200 group ${isSelected ? "bg-blue-50 border-blue-500 shadow-md ring-1 ring-blue-200" : "bg-white border-gray-200 hover:bg-blue-50 hover:border-blue-300 hover:shadow-sm"}`,
                children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-3", children: [
                  /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      className: `w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-semibold flex-shrink-0 ${isSelected ? "bg-blue-600" : "bg-gray-400 group-hover:bg-blue-500"}`,
                      children: fullName?.charAt(0)?.toUpperCase() || "U"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 1754,
                      columnNumber: 29
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-0", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "font-semibold text-gray-900 text-sm truncate", children: fullName }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 1765,
                        columnNumber: 33
                      }, this),
                      /* @__PURE__ */ jsxDEV(
                        "span",
                        {
                          className: `text-[10px] font-medium px-1.5 py-0.5 rounded ${status === "Accept" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`,
                          children: status
                        },
                        void 0,
                        false,
                        {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                          lineNumber: 1768,
                          columnNumber: 33
                        },
                        this
                      ),
                      isNew ? /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-600 text-white animate-pulse", children: "NEW" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 1777,
                        columnNumber: 29
                      }, this) : isOld ? /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-medium px-1.5 py-0.5 rounded bg-orange-100 text-orange-600", children: [
                        daysAgo,
                        "d ago"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 1781,
                        columnNumber: 29
                      }, this) : /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-medium px-1.5 py-0.5 rounded bg-gray-100 text-gray-500", children: [
                        daysAgo,
                        "d ago"
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 1785,
                        columnNumber: 29
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 1764,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mt-1", children: /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500", children: [
                      "Code:",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-blue-600", children: bidCode }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 1793,
                        columnNumber: 35
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 1791,
                      columnNumber: 33
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 1790,
                      columnNumber: 31
                    }, this),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mt-1", children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500", children: [
                        "Ticket:",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "font-medium text-gray-700", children: ticket }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                          lineNumber: 1801,
                          columnNumber: 35
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 1799,
                        columnNumber: 33
                      }, this),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-500", children: phone }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 1805,
                        columnNumber: 33
                      }, this)
                    ] }, void 0, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 1798,
                      columnNumber: 31
                    }, this)
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1763,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-end gap-1 flex-shrink-0", children: [
                    /* @__PURE__ */ jsxDEV(
                      "span",
                      {
                        className: `text-[10px] font-medium px-2 py-0.5 rounded-full ${isSelected ? "bg-blue-600 text-white" : bidRequest.eligibilityStatus === "eligible" ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"}`,
                        children: isSelected ? "Selected" : bidRequest.eligibilityStatus === "eligible" ? "Eligible" : "Has Due"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 1812,
                        columnNumber: 31
                      },
                      this
                    ),
                    /* @__PURE__ */ jsxDEV(
                      FaChevronRight,
                      {
                        className: `text-xs ${isSelected ? "text-blue-600" : "text-gray-300 group-hover:text-blue-400"}`
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 1827,
                        columnNumber: 31
                      },
                      this
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1811,
                    columnNumber: 29
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1753,
                  columnNumber: 27
                }, this)
              },
              bidRequest._id || index,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1745,
                columnNumber: 21
              },
              this
            );
          }) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1721,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center h-full text-gray-400 p-6", children: [
            /* @__PURE__ */ jsxDEV(
              "svg",
              {
                className: "w-14 h-14 mb-3 text-gray-300",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /* @__PURE__ */ jsxDEV(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "1.5",
                    d: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1844,
                    columnNumber: 23
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1838,
                columnNumber: 21
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-center font-medium", children: "No bid requests found" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1851,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-center mt-1", children: "No customers have requested bids for this group yet" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1852,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1837,
            columnNumber: 15
          }, this) : drawerTab === "advancePayout" ? (
            // Advance Payouts Content
            advancePayouts.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "p-3", children: /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "w-full border-collapse", children: [
              /* @__PURE__ */ jsxDEV("thead", { children: /* @__PURE__ */ jsxDEV("tr", { className: "bg-gray-100 sticky top-0", children: [
                /* @__PURE__ */ jsxDEV("th", { className: "border p-2 text-left text-sm font-medium text-gray-700", children: "Customer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1863,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "border p-2 text-left text-sm font-medium text-gray-700", children: "Ticket" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1864,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "border p-2 text-left text-sm font-medium text-gray-700", children: "Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1865,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "border p-2 text-left text-sm font-medium text-gray-700", children: "Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1866,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1862,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1861,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { children: advancePayouts.map(
                (item) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "border p-2 text-sm text-gray-700", children: item.user_id?.full_name || item.user_id?.name || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1872,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "border p-2 text-sm text-gray-700", children: item.ticket || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1875,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "border p-2 text-sm text-gray-700", children: [
                    "₹",
                    parseInt(item.amount || 0).toLocaleString("en-IN")
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1878,
                    columnNumber: 31
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "border p-2 text-sm text-gray-700", children: item.pay_date ? new Date(item.pay_date).toLocaleDateString() : "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1881,
                    columnNumber: 31
                  }, this)
                ] }, item._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1871,
                  columnNumber: 23
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1869,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1860,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1859,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1858,
              columnNumber: 15
            }, this) : /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center h-full text-gray-400 p-6", children: [
              /* @__PURE__ */ jsxDEV(
                "svg",
                {
                  className: "w-14 h-14 mb-3 text-gray-300",
                  fill: "none",
                  stroke: "currentColor",
                  viewBox: "0 0 24 24",
                  children: /* @__PURE__ */ jsxDEV(
                    "path",
                    {
                      strokeLinecap: "round",
                      strokeLinejoin: "round",
                      strokeWidth: "1.5",
                      d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9h3m-3 4h3m-6-4h.01M9 16h.01"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 1899,
                      columnNumber: 23
                    },
                    this
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1893,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-center font-medium", children: "No advance payouts found" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1906,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-center mt-1", children: "No advance payouts have been made for this group yet" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1907,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1892,
              columnNumber: 15
            }, this)
          ) : null }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1714,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "px-5 py-3 bg-gray-50 border-t border-gray-200", children: /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-gray-500 text-center", children: drawerTab === "bidrequests" ? "Click on a bid request to select them for this auction" : "Advance payouts before auction" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1920,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1919,
            columnNumber: 13
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 1620,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        width: "800px",
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Edit Auction" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1934,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "SI No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1941,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: currentUpdateGroup?.SI_number,
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1944,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1940,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Group" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1952,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: currentUpdateGroup?.group_id?.group_name,
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1955,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1951,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1939,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Group Value" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1967,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: currentUpdateGroup?.group_id?.group_value,
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1970,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(
                  currentUpdateGroup?.group_id?.group_value || 0
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1976,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1966,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Group Installment" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1983,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: currentUpdateGroup?.group_id?.group_install,
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 1986,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(
                  currentUpdateGroup?.group_id?.group_install || 0
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 1992,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 1982,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 1965,
              columnNumber: 17
            }, this),
            currentUpdateGroup?.group_id?.group_type === "double" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Auction Type" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2003,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: currentUpdateGroup?.auction_type.charAt(0).toUpperCase() + currentUpdateGroup?.auction_type.slice(1) + " Auction",
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2006,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2002,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Customer" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2024,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: currentUpdateGroup?.user_id?.full_name,
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2027,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2023,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Ticket" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2035,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: currentUpdateGroup?.ticket,
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2038,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2034,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2022,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Bid Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2049,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: currentUpdateGroup?.group_id?.group_value - currentUpdateGroup?.win_amount,
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2052,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(
                currentUpdateGroup?.group_id?.group_value - currentUpdateGroup?.win_amount || 0
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2061,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2048,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Commission" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2072,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: currentUpdateGroup?.commission,
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2075,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(currentUpdateGroup?.commission || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2081,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2071,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Winning Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2086,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: currentUpdateGroup?.win_amount,
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2089,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(currentUpdateGroup?.win_amount || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2095,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2085,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2070,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Divident" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2104,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: currentUpdateGroup?.divident,
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2107,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(currentUpdateGroup?.divident || 0) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2113,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2103,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Divident per Head" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2118,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    value: currentUpdateGroup?.divident_head,
                    readOnly: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2121,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(
                  currentUpdateGroup?.divident_head || 0
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2127,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2117,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2102,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Next Payable" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2137,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "text",
                  value: currentUpdateGroup?.payable,
                  readOnly: true,
                  className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2140,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV("span", { className: "text-[11px] text-blue-400 mt-1 block", children: numberToIndianWords(currentUpdateGroup?.payable || 0) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2146,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2136,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Auction Date ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2155,
                    columnNumber: 36
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2154,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "auction_date",
                    value: updateFormData?.auction_date?.split("T")[0] || "",
                    onChange: handleInputChange,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2157,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2153,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Auction Time ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2167,
                    columnNumber: 36
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2166,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "time",
                    name: "auction_time",
                    value: updateFormData?.auction_time || "",
                    onChange: handleInputChange,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2169,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2165,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2152,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-row justify-between space-x-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Next Auction Date ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2181,
                    columnNumber: 41
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2180,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "next_date",
                    value: updateFormData?.next_date?.split("T")[0] || "",
                    onChange: handleInputChange,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2183,
                    columnNumber: 21
                  },
                  this
                ),
                errors.next_date && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.next_date }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2191,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2179,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Next Auction Time ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2198,
                    columnNumber: 41
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2197,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "time",
                    name: "next_auction_time",
                    value: updateFormData.next_auction_time,
                    onChange: handleInputChange,
                    required: true,
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2200,
                    columnNumber: 21
                  },
                  this
                ),
                errors.next_auction_time && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-500", children: errors.next_auction_time }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2209,
                  columnNumber: 21
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2196,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2178,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-blue-700 hover:bg-blue-800 border-2 border-black focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2216,
                columnNumber: 19
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2215,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 1937,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 1933,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 1928,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Sure want to delete this Auction ?" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2236,
            columnNumber: 15
          }, this),
          currentGroup && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteAuction();
              },
              className: "space-y-6",
              children: /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "w-full text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                  children: "Delete"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2247,
                  columnNumber: 19
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2240,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 2235,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 2228,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showTransactionModal,
        onClose: () => {
          setShowTransactionModal(false);
          setTransactionData([]);
        },
        width: "1000px",
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: [
            "Transaction Details -",
            " ",
            transactionData?.group?.group_name || "Group"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2268,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2267,
            columnNumber: 15
          }, this),
          transactionData?.group && /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 gap-4 mb-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 rounded-lg p-4 border border-blue-200", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-blue-600 font-medium", children: "Group Name" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2278,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-gray-900", children: transactionData.group.group_name }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2281,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2277,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 rounded-lg p-4 border border-green-200", children: [
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-green-600 font-medium", children: "Group Value" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2286,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-lg font-bold text-gray-900", children: [
                "₹",
                numberToIndianWords(transactionData.group.group_value)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2289,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2285,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2276,
            columnNumber: 15
          }, this),
          loadingTransaction ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2298,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2297,
            columnNumber: 15
          }, this) : transactionData?.users && transactionData.users.length > 0 ? /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto max-h-[500px] overflow-y-auto", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
            /* @__PURE__ */ jsxDEV("thead", { className: "bg-gray-50 sticky top-0", children: /* @__PURE__ */ jsxDEV("tr", { children: [
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "SL No" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2305,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Customer Name" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2308,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Phone Number" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2311,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Ticket" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2314,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Total to be Paid" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2317,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Paid Amount" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2320,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("th", { className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Balance" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2323,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2304,
              columnNumber: 23
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2303,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: transactionData.users.map(
              (user, index) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50", children: [
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-gray-900", children: index + 1 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2334,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900", children: [
                  user.user?.name || "Unknown User",
                  !user.user?.name && user.user?.name === "Unknown User" && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-xs text-yellow-600", children: "(Invalid)" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2341,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2337,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-gray-500", children: user.user?.phone || "N/A" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2346,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-gray-500", children: user.ticket || "N/A" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2349,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-gray-900", children: [
                  "₹",
                  (user.totals?.totalBePaid || 0).toLocaleString()
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2352,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm text-green-600 font-medium", children: [
                  "₹",
                  (user.totals?.paid || 0).toLocaleString()
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2355,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("td", { className: "px-6 py-4 whitespace-nowrap text-sm font-medium", children: /* @__PURE__ */ jsxDEV(
                  "span",
                  {
                    className: (user.totals?.balance || 0) > 0 ? "text-red-600" : "text-green-600",
                    children: [
                      "₹",
                      (user.totals?.balance || 0).toLocaleString()
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2359,
                    columnNumber: 29
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2358,
                  columnNumber: 27
                }, this)
              ] }, index, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2333,
                columnNumber: 21
              }, this)
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2331,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2302,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2301,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
            /* @__PURE__ */ jsxDEV(
              "svg",
              {
                className: "mx-auto h-12 w-12 text-gray-400",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /* @__PURE__ */ jsxDEV(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                    d: "M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2399,
                    columnNumber: 21
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2393,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("h3", { className: "mt-2 text-sm font-medium text-gray-900", children: "No data found" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2406,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500", children: "No users found in this group." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2409,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2392,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 2266,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 2258,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showGroupOverviewModal,
        onClose: () => {
          setshowGroupOverviewModal(false);
          setGroupOverviewData([]);
          setGroupOverview(false);
        },
        width: "1000px",
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: [
            "Group Overview - ",
            groupInfo?.group_name || "Group"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2429,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2428,
            columnNumber: 15
          }, this),
          loadingGroupOverview ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2436,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2435,
            columnNumber: 15
          }, this) : GroupOverviewData?.data ? /* @__PURE__ */ jsxDEV("div", { className: "space-y-6", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 rounded-lg p-4 border border-blue-200", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-blue-600 font-medium", children: "Total Auctions" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2443,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: GroupOverviewData.data.summary?.totalAuctions || 0 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2446,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2442,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 rounded-lg p-4 border border-green-200", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-green-600 font-medium", children: "Normal Auctions" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2451,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: GroupOverviewData.data.summary?.normalAuctions || 0 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2454,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2450,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50 rounded-lg p-4 border border-purple-200", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-purple-600 font-medium", children: "Free Auctions" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2459,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: GroupOverviewData.data.summary?.freeAuctions || 0 }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2462,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2458,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50 rounded-lg p-4 border border-orange-200", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-orange-600 font-medium", children: "Prized Status" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2467,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mt-1", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-green-600", children: [
                    "Prized:",
                    " ",
                    GroupOverviewData.data.summary?.prizedTrue || 0
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2471,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-red-600", children: [
                    "Unprized:",
                    " ",
                    GroupOverviewData.data.summary?.prizedFalse || 0
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2475,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2470,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2466,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2441,
              columnNumber: 19
            }, this),
            GroupOverviewData.data.prizedUsers && GroupOverviewData.data.prizedUsers.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-md font-semibold text-gray-800 mb-3 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-5 bg-green-500 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2488,
                  columnNumber: 27
                }, this),
                "Prized Users (",
                GroupOverviewData.data.prizedUsers.length,
                ")"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2487,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto max-h-[300px] overflow-y-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
                /* @__PURE__ */ jsxDEV("thead", { className: "bg-green-50 sticky top-0", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-green-700 uppercase", children: "SL No" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2496,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-green-700 uppercase", children: "User Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2499,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-green-700 uppercase", children: "Phone Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2502,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-green-700 uppercase", children: "Ticket Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2505,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-green-700 uppercase", children: "Status" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2508,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2495,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2494,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: GroupOverviewData.data.prizedUsers.map(
                  (user, idx) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50", children: [
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-900", children: idx + 1 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2517,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm font-medium text-gray-900", children: user.full_name || "N/A" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2520,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-500", children: user.phone_number || "N/A" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2523,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-500", children: user.ticket || "N/A" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2526,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2", children: /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800", children: "Prized" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2530,
                      columnNumber: 39
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2529,
                      columnNumber: 37
                    }, this)
                  ] }, idx, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2516,
                    columnNumber: 27
                  }, this)
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2513,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2493,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2492,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2486,
              columnNumber: 17
            }, this),
            GroupOverviewData.data.nonPrizedUsers && GroupOverviewData.data.nonPrizedUsers.length > 0 && /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("h4", { className: "text-md font-semibold text-gray-800 mb-3 flex items-center gap-2", children: [
                /* @__PURE__ */ jsxDEV("span", { className: "w-1 h-5 bg-red-500 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2548,
                  columnNumber: 27
                }, this),
                "Non-Prized Users (",
                GroupOverviewData.data.nonPrizedUsers.length,
                ")"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2547,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto max-h-[300px] overflow-y-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
                /* @__PURE__ */ jsxDEV("thead", { className: "bg-red-50 sticky top-0", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-red-700 uppercase", children: "SL No" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2556,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-red-700 uppercase", children: "User Name" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2559,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-red-700 uppercase", children: "Phone Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2562,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-red-700 uppercase", children: "Ticket Number" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2565,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-red-700 uppercase", children: "Auction Code" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2568,
                    columnNumber: 33
                  }, this),
                  /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-red-700 uppercase", children: "Status" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2571,
                    columnNumber: 33
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2555,
                  columnNumber: 31
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2554,
                  columnNumber: 29
                }, this),
                /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: GroupOverviewData.data.nonPrizedUsers.map(
                  (user, idx) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50", children: [
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-900", children: idx + 1 }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2580,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm font-medium text-gray-900", children: user.full_name || "N/A" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2583,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-500", children: user.phone_number || "N/A" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2586,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-500", children: user.ticket || "N/A" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2589,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2 text-sm text-gray-500", children: user.auction_code || "-" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2592,
                      columnNumber: 37
                    }, this),
                    /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-2", children: /* @__PURE__ */ jsxDEV("span", { className: "px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800", children: "Non-Prized" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2596,
                      columnNumber: 39
                    }, this) }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2595,
                      columnNumber: 37
                    }, this)
                  ] }, idx, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2579,
                    columnNumber: 27
                  }, this)
                ) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2576,
                  columnNumber: 29
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2553,
                columnNumber: 27
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2552,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2546,
              columnNumber: 17
            }, this),
            (!GroupOverviewData.data.prizedUsers || GroupOverviewData.data.prizedUsers.length === 0) && (!GroupOverviewData.data.nonPrizedUsers || GroupOverviewData.data.nonPrizedUsers.length === 0) && /* @__PURE__ */ jsxDEV("div", { className: "text-center py-8", children: /* @__PURE__ */ jsxDEV("p", { className: "text-gray-500", children: "No user data available for this group." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2615,
              columnNumber: 25
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2614,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2439,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
            /* @__PURE__ */ jsxDEV(
              "svg",
              {
                className: "mx-auto h-12 w-12 text-gray-400",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /* @__PURE__ */ jsxDEV(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                    d: "M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2629,
                    columnNumber: 21
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2623,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("h3", { className: "mt-2 text-sm font-medium text-gray-900", children: "No data found" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2636,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500", children: "Unable to load group overview data." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2639,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2622,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 2427,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 2418,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showPayoutModal,
        onClose: () => {
          setShowPayoutModal(false);
          setPayoutData([]);
        },
        width: "1000px",
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center mb-4", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: [
            "Payout Information - ",
            groupInfo?.group_name || "Group"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2658,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2657,
            columnNumber: 15
          }, this),
          loadingPayout ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2665,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2664,
            columnNumber: 15
          }, this) : payoutData && payoutData.length > 0 ? /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4 mb-6", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "bg-orange-50 rounded-lg p-4 border border-orange-200", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-orange-600 font-medium", children: "Total Payouts" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2672,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: payoutData.length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2675,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2671,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-green-50 rounded-lg p-4 border border-green-200", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-green-600 font-medium", children: "Total Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2680,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: [
                  "₹",
                  payoutData.reduce(
                    (sum, item) => sum + (parseInt(item.amount) || 0),
                    0
                  ).toLocaleString("en-IN")
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2683,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2679,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-blue-50 rounded-lg p-4 border border-blue-200", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-blue-600 font-medium", children: "Online Payouts" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2694,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: payoutData.filter(
                  (item) => item.pay_type === "online"
                ).length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2697,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2693,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-purple-50 rounded-lg p-4 border border-purple-200", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-purple-600 font-medium", children: "Cash Payouts" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2706,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-2xl font-bold text-gray-900", children: payoutData.filter((item) => item.pay_type === "cash").length }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2709,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2705,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2670,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "overflow-x-auto max-h-[500px] overflow-y-auto border rounded-lg", children: /* @__PURE__ */ jsxDEV("table", { className: "min-w-full divide-y divide-gray-200", children: [
              /* @__PURE__ */ jsxDEV("thead", { className: "bg-orange-50 sticky top-0", children: /* @__PURE__ */ jsxDEV("tr", { children: [
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-orange-700 uppercase", children: "SL No" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2723,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-orange-700 uppercase", children: "Customer Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2726,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-orange-700 uppercase", children: "Phone Number" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2729,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-orange-700 uppercase", children: "Ticket" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2732,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-orange-700 uppercase", children: "Amount" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2735,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-orange-700 uppercase", children: "Pay Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2738,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-orange-700 uppercase", children: "Pay Type" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2741,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-orange-700 uppercase", children: "Disbursement Type" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2744,
                  columnNumber: 27
                }, this),
                /* @__PURE__ */ jsxDEV("th", { className: "px-4 py-3 text-left text-xs font-medium text-orange-700 uppercase", children: "Admin Name" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2747,
                  columnNumber: 27
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2722,
                columnNumber: 25
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2721,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("tbody", { className: "bg-white divide-y divide-gray-200", children: payoutData.map(
                (payout, idx) => /* @__PURE__ */ jsxDEV("tr", { className: "hover:bg-gray-50", children: [
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-900", children: idx + 1 }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2755,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm font-medium text-gray-900", children: payout.full_name || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2758,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-500", children: payout.phone_number || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2761,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-500", children: payout.ticket || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2764,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm font-semibold text-green-600", children: [
                    "₹",
                    (parseInt(payout.amount) || 0).toLocaleString(
                      "en-IN"
                    )
                  ] }, void 0, true, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2767,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-500", children: payout.pay_date ? new Date(payout.pay_date).toLocaleDateString() : "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2773,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3", children: /* @__PURE__ */ jsxDEV(
                    "span",
                    {
                      className: `px-2 py-1 text-xs font-semibold rounded-full ${payout.pay_type === "online" ? "bg-blue-100 text-blue-800" : "bg-purple-100 text-purple-800"}`,
                      children: payout.pay_type || "N/A"
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2779,
                      columnNumber: 31
                    },
                    this
                  ) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2778,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm", children: /* @__PURE__ */ jsxDEV("button", { className: "px-3 py-1 text-xs font-medium rounded-md bg-green-600 text-white hover:bg-gray-800 transition capitalize", children: payout.disbursement_type || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2789,
                    columnNumber: 31
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2788,
                    columnNumber: 29
                  }, this),
                  /* @__PURE__ */ jsxDEV("td", { className: "px-4 py-3 text-sm text-gray-500", children: payout.admin_name || "N/A" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2793,
                    columnNumber: 29
                  }, this)
                ] }, payout._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2754,
                  columnNumber: 23
                }, this)
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2752,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2720,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2719,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2668,
            columnNumber: 15
          }, this) : /* @__PURE__ */ jsxDEV("div", { className: "text-center py-12", children: [
            /* @__PURE__ */ jsxDEV(
              "svg",
              {
                className: "mx-auto h-12 w-12 text-gray-400",
                fill: "none",
                stroke: "currentColor",
                viewBox: "0 0 24 24",
                children: /* @__PURE__ */ jsxDEV(
                  "path",
                  {
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    strokeWidth: "2",
                    d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9h3m-3 4h3m-6-4h.01M9 16h.01"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                    lineNumber: 2810,
                    columnNumber: 21
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2804,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("h3", { className: "mt-2 text-sm font-medium text-gray-900", children: "No data found" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2817,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-gray-500", children: "No payout information available for this group." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2820,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2803,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 2656,
          columnNumber: 13
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 2648,
        columnNumber: 11
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-4 border-b border-gray-200", children: /* @__PURE__ */ jsxDEV("nav", { className: "-mb-px flex space-x-8", "aria-label": "Tabs", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setActiveTab("auctions"),
            className: `${activeTab === "auctions" ? "border-blue-500 text-blue-600" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`,
            children: "Auctions"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2833,
            columnNumber: 17
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => setActiveTab("preAuction"),
            className: `${activeTab === "preAuction" ? "border-blue-500 text-blue-600" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`,
            children: "Pre‑Auction Entries"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2842,
            columnNumber: 17
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 2832,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 2831,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: activeTab === "auctions" ? "Auctions" : "Pre‑Auction Entries" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 2855,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: activeTab === "auctions" ? (
        // ---------- ORIGINAL AUCTIONS TAB (UNCHANGED) ----------
        /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-10", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Select or Search Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2864,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: selectedAuctionGroupId === "recent" ? "recent" : selectedAuctionGroupId || void 0,
                  onChange: handleGroupAuction,
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  className: "w-full max-w-md",
                  filterOption: (input, option) => {
                    if (option.value === "recent") {
                      return "Recent Auctions".toLowerCase().includes(input.toLowerCase());
                    }
                    return option.children?.toString().toLowerCase().includes(input.toLowerCase());
                  },
                  placeholder: "Search or Select Group",
                  children: [
                    /* @__PURE__ */ jsxDEV(Select.Option, { value: "recent", children: "Recent Auctions" }, "recent", false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2890,
                      columnNumber: 25
                    }, this),
                    groups.map(
                      (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                        lineNumber: 2894,
                        columnNumber: 23
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2867,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => {
                    setShowModal(true);
                    setErrors({});
                  },
                  className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
                  children: "+ Add Auction"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2899,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2865,
              columnNumber: 21
            }, this),
            selectedAuctionGroupId && selectedAuctionGroupId !== "recent" && filteredAuction[0]?.group_id?.group_name && /* @__PURE__ */ jsxDEV("p", { className: "mt-5 inline-flex items-center gap-3 px-4 py-2 bg-orange-50 rounded-lg border border-orange-200", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-orange-600 text-sm font-medium", children: "Balance" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2914,
                columnNumber: 27
              }, this),
              /* @__PURE__ */ jsxDEV("span", { className: "text-lg font-bold text-gray-900", children: [
                "₹",
                Number(double.amount || 0).toLocaleString("en-IN")
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2915,
                columnNumber: 27
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2913,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2863,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: [
            selectedAuctionGroupId === "recent" && /* @__PURE__ */ jsxDEV("div", { className: "mb-4", children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold text-gray-800 border-l-4 border-blue-500 pl-3", children: "Recent Auctions" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2925,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-gray-500 mt-1", children: "Latest auction activities across all groups" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2928,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2924,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: !navigator.onLine ? /* @__PURE__ */ jsxDEV("div", { className: "text-center text-red-500 py-6", children: "No Internet Connection" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2936,
              columnNumber: 21
            }, this) : isLoading || loadingRecent ? /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2939,
              columnNumber: 27
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2938,
              columnNumber: 21
            }, this) : TableAuctions?.length > 0 ? /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                updateHandler: handleUpdateModalOpen,
                data: filterOption(TableAuctions, searchText),
                columns: selectedAuctionGroupId === "recent" ? recentAuctionsColumns : columns,
                exportedFileName: selectedAuctionGroupId === "recent" ? "Recent_Auctions.csv" : "Auctions.csv"
              },
              selectedAuctionGroupId,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                lineNumber: 2942,
                columnNumber: 21
              },
              this
            ) : hasFetched ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-6 text-gray-500", children: "No Auction Data Found" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2952,
              columnNumber: 21
            }, this) : null }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2934,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2922,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 2862,
          columnNumber: 15
        }, this)
      ) : (
        // ---------- NEW PRE‑AUCTION ENTRIES TAB ----------
        /* @__PURE__ */ jsxDEV(Fragment, { children: [
          /* @__PURE__ */ jsxDEV("div", { className: "mb-10", children: [
            /* @__PURE__ */ jsxDEV("label", { children: "Select Pre‑Auction Group" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2961,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  value: preAuctionSelectedGroupId || void 0,
                  onChange: handlePreAuctionGroupChange,
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  className: "w-full max-w-md",
                  filterOption: (input, option) => option.children?.toString().toLowerCase().includes(input.toLowerCase()),
                  placeholder: "Search or Select Group",
                  loading: preAuctionLoading && preAuctionGroups.length === 0,
                  children: preAuctionGroups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                      lineNumber: 2976,
                      columnNumber: 23
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2963,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  onClick: () => {
                    setShowModal(true);
                    setErrors({});
                  },
                  className: "ml-4 bg-blue-950 text-white px-4 py-2 rounded shadow-md hover:bg-blue-800 transition duration-200",
                  children: "+ Add Auction"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
                  lineNumber: 2981,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2962,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2960,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { children: !navigator.onLine ? /* @__PURE__ */ jsxDEV("div", { className: "text-center text-red-500 py-6", children: "No Internet Connection" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2995,
            columnNumber: 19
          }, this) : preAuctionLoading ? (
            // Loader appears every time a group is selected
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center py-20", children: /* @__PURE__ */ jsxDEV(CircularLoader, { isLoading: true }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2999,
              columnNumber: 25
            }, this) }, "loader", false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 2998,
              columnNumber: 19
            }, this)
          ) : preAuctionTableData.length > 0 ? /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              updateHandler: handleUpdateModalOpen,
              data: filterOption(preAuctionTableData, searchText),
              columns: preAuctionColumns,
              exportedFileName: `PreAuction_${preAuctionSelectedGroupId || "groups"}.csv`
            },
            preAuctionSelectedGroupId,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
              lineNumber: 3002,
              columnNumber: 19
            },
            this
          ) : preAuctionHasFetchedData ? /* @__PURE__ */ jsxDEV("div", { className: "text-center py-6 text-gray-500", children: "No Auction Data Found for this group" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 3011,
            columnNumber: 19
          }, this) : null }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
            lineNumber: 2993,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
          lineNumber: 2959,
          columnNumber: 15
        }, this)
      ) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
        lineNumber: 2859,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
      lineNumber: 2829,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
    lineNumber: 1208,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
    lineNumber: 1207,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx",
    lineNumber: 1206,
    columnNumber: 5
  }, this);
};
_s(Auction, "MBJqiaElbSkTSnlf7Tcwa6yUYYU=");
_c = Auction;
export default Auction;
var _c;
$RefreshReg$(_c, "Auction");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Auction.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeWxCNEIsU0EwdkJOLFVBMXZCTTsyQkF6bEI1QjtBQUFvQkEsb0JBQWdCLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbkQsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxTQUFTO0FBQ2hCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxRQUFRQyxVQUFVQyxPQUFPQyxZQUFZO0FBQzlDLE9BQU9DLGVBQWU7QUFDdEIsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxRQUFRQyxLQUFLQyxlQUFlO0FBQ3JDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxhQUFhQyxzQkFBc0I7QUFDNUMsU0FBU0Msb0JBQW9CO0FBQzdCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLDJCQUEyQjtBQUNwQztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFFUCxNQUFNQyxVQUFVQSxNQUFNO0FBQUFDLEtBQUE7QUFDcEIsUUFBTUMsV0FBV0MsVUFBVUM7QUFDM0IsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUkzQyxTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDNEMsZUFBZUMsZ0JBQWdCLElBQUk3QyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDOEMsZUFBZUMsZ0JBQWdCLElBQUkvQyxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDZ0Qsc0JBQXNCQyx1QkFBdUIsSUFBSWpELFNBQVMsRUFBRTtBQUNuRSxRQUFNLENBQUNrRCxpQkFBaUJDLGtCQUFrQixJQUFJbkQsU0FBUyxFQUFFO0FBQ3pELFFBQU0sQ0FBQ29ELHdCQUF3QkMseUJBQXlCLElBQUlyRCxTQUFTLEVBQUU7QUFDdkUsUUFBTSxDQUFDc0QsZUFBZUMsZ0JBQWdCLElBQUl2RCxTQUFTLEVBQUU7QUFDckQsUUFBTSxDQUFDd0QsaUJBQWlCQyxrQkFBa0IsSUFBSXpELFNBQVMsRUFBRTtBQUN6RCxRQUFNLENBQUMwRCxXQUFXQyxZQUFZLElBQUkzRCxTQUFTLENBQUMsQ0FBQztBQUM3QyxRQUFNLENBQUM0RCxXQUFXQyxZQUFZLElBQUk3RCxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDOEQsZUFBZUMsZ0JBQWdCLElBQUkvRCxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDZ0UsYUFBYUMsY0FBYyxJQUFJakUsU0FBUyxFQUFFO0FBQ2pELFFBQU0sQ0FBQ2tFLGlCQUFpQkMsa0JBQWtCLElBQUluRSxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDb0Usb0JBQW9CQyxxQkFBcUIsSUFBSXJFLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUNzRSxpQkFBaUJDLGtCQUFrQixJQUFJdkUsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ3dFLGNBQWNDLGVBQWUsSUFBSXpFLFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUMwRSxpQkFBaUJDLGtCQUFrQixJQUFJM0UsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQzRFLG9CQUFvQkMscUJBQXFCLElBQUk3RSxTQUFTLElBQUk7QUFDakUsUUFBTSxDQUFDOEUsUUFBUUMsU0FBUyxJQUFJL0UsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDZ0YsUUFBUUMsU0FBUyxJQUFJakYsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDa0YsV0FBV0MsWUFBWSxJQUFJbkYsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ29GLFlBQVlDLGFBQWEsSUFBSXJGLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNzRixXQUFXQyxZQUFZLElBQUl2RixTQUFTLGFBQWE7QUFFeEQsUUFBTSxDQUFDd0YsWUFBWUMsYUFBYSxJQUFJekYsU0FBUyxLQUFLO0FBQ2xELFFBQU0wRixlQUFlQyxPQUFPLEtBQUs7QUFDakMsUUFBTUMsbUJBQW1CRCxPQUFPLEtBQUs7QUFFckMsUUFBTSxDQUFDRSxzQkFBc0JDLHVCQUF1QixJQUFJOUYsU0FBUyxLQUFLO0FBQ3RFLFFBQU0sQ0FBQytGLGlCQUFpQkMsa0JBQWtCLElBQUloRyxTQUFTLEVBQUU7QUFDekQsUUFBTSxDQUFDaUcsb0JBQW9CQyxxQkFBcUIsSUFBSWxHLFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUNtRyxnQkFBZ0JDLGlCQUFpQixJQUFJcEcsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQ3FHLGtCQUFrQkMsbUJBQW1CLElBQUl0RyxTQUFTLElBQUk7QUFDN0QsUUFBTSxDQUFDdUcsZUFBZUMsZ0JBQWdCLElBQUl4RyxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDeUcsaUJBQWlCQyxrQkFBa0IsSUFBSTFHLFNBQVMsRUFBRTtBQUV6RCxRQUFNLENBQUMyRyxnQkFBZ0JDLGlCQUFpQixJQUFJNUcsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQzZHLHdCQUF3QkMseUJBQXlCLElBQUk5RyxTQUFTLEtBQUs7QUFFMUUsUUFBTSxDQUFDK0csZUFBZUMsZ0JBQWdCLElBQUloSCxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDaUgsbUJBQW1CQyxvQkFBb0IsSUFBSWxILFNBQVMsRUFBRTtBQUM3RCxRQUFNLENBQUNtSCx3QkFBd0JDLHlCQUF5QixJQUFJcEgsU0FBUyxLQUFLO0FBQzFFLFFBQU0sQ0FBQ3FILHNCQUFzQkMsdUJBQXVCLElBQUl0SCxTQUFTLEtBQUs7QUFFdEUsUUFBTSxDQUFDdUgsaUJBQWlCQyxrQkFBa0IsSUFBSXhILFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUN5SCxZQUFZQyxhQUFhLElBQUkxSCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDMkgsZUFBZUMsZ0JBQWdCLElBQUk1SCxTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDNkgsb0JBQW9CQyxxQkFBcUIsSUFBSTlILFNBQVMsS0FBSztBQUNsRSxRQUFNLENBQUMrSCxTQUFTQyxVQUFVLElBQUloSSxTQUFTLEtBQUs7QUFDNUMsUUFBTSxDQUFDaUksY0FBY0MsZUFBZSxJQUFJbEksU0FBUyxLQUFLO0FBR3RELFFBQU0sQ0FBQ21JLFdBQVdDLFlBQVksSUFBSXBJLFNBQVMsVUFBVTtBQUdyRCxRQUFNLENBQUNxSSxrQkFBa0JDLG1CQUFtQixJQUFJdEksU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQ3VJLDJCQUEyQkMsNEJBQTRCLElBQUl4SSxTQUFTLEVBQUU7QUFDN0UsUUFBTSxDQUFDeUkscUJBQXFCQyxzQkFBc0IsSUFBSTFJLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUMySSxtQkFBbUJDLG9CQUFvQixJQUFJNUksU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQzZJLDRCQUE0QkMsNkJBQTZCLElBQUk5SSxTQUFTLEtBQUs7QUFDbEYsUUFBTSxDQUFDK0ksMEJBQTBCQywyQkFBMkIsSUFBSWhKLFNBQVMsS0FBSztBQUU5RSxRQUFNLENBQUNpSixvQkFBb0JDLHFCQUFxQixJQUFJbEosU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQ21KLHNCQUFzQkMsdUJBQXVCLElBQUlwSixTQUFTLEtBQUs7QUFFdEUsUUFBTXFKLDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN6QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJuRSxrQkFBY2tFLEtBQUs7QUFBQSxFQUNyQjtBQUVBLFFBQU0sQ0FBQ0UsYUFBYUMsY0FBYyxJQUFJMUosU0FBUztBQUFBLElBQzdDMkosWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUkvSixTQUFTO0FBQUEsSUFDdkNnSyxjQUFjO0FBQUEsSUFDZEMsVUFBVTtBQUFBLElBQ1ZDLFNBQVM7QUFBQSxJQUNUQyxRQUFRO0FBQUEsSUFDUkMsWUFBWTtBQUFBLElBQ1pDLFlBQVk7QUFBQSxJQUNaQyxZQUFZO0FBQUEsSUFDWkMsVUFBVTtBQUFBLElBQ1ZDLGVBQWU7QUFBQSxJQUNmQyxTQUFTO0FBQUEsSUFDVEMsY0FBYztBQUFBLElBQ2RDLGNBQWM7QUFBQSxJQUNkQyxXQUFXO0FBQUEsSUFDWEMsbUJBQW1CO0FBQUEsSUFDbkJDLFlBQVk7QUFBQSxJQUNaQyxjQUFjO0FBQUEsSUFDZEMsZ0JBQWdCO0FBQUEsRUFDbEIsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsZ0JBQWdCQyxpQkFBaUIsSUFBSWxMLFNBQVM7QUFBQSxJQUNuRDBLLGNBQWM7QUFBQSxJQUNkQyxjQUFjO0FBQUEsSUFDZEMsV0FBVztBQUFBLElBQ1hDLG1CQUFtQjtBQUFBLEVBRXJCLENBQUM7QUFFRE0sWUFBVSxNQUFNO0FBQ2QsUUFBSXZGLGlCQUFpQndGLFFBQVM7QUFFOUIsVUFBTUMsY0FBYyxZQUFZO0FBQzlCLFVBQUksQ0FBQzdJLFVBQVVDLE9BQVE7QUFFdkIsVUFBSTtBQUNGLGNBQU02SSxXQUFXLE1BQU1wTCxJQUFJcUwsSUFBSSx3QkFBd0I7QUFDdkQ1SSxrQkFBVTJJLFNBQVNFLElBQUk7QUFBQSxNQUN6QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUVBSixnQkFBWTtBQUNaekYscUJBQWlCd0YsVUFBVTtBQUFBLEVBQzdCLEdBQUcsRUFBRTtBQUdMLFFBQU1PLHdCQUF3QixZQUFZO0FBQ3hDLFFBQUksQ0FBQ25KLFVBQVVDLE9BQVE7QUFDdkJtRyx5QkFBcUIsSUFBSTtBQUN6QixRQUFJO0FBQ0YsWUFBTTBDLFdBQVcsTUFBTXBMLElBQUlxTCxJQUFJLDhCQUE4QjtBQUM3RGpELDBCQUFvQmdELFNBQVNFLE1BQU1BLFFBQVFGLFNBQVNFLFFBQVEsRUFBRTtBQUM5RDFDLG9DQUE4QixJQUFJO0FBQUEsSUFDcEMsU0FBUzJDLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxzQ0FBc0NBLEtBQUs7QUFDekQvQixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTNkIsTUFBTUgsVUFBVUUsTUFBTTVCLFdBQVc7QUFBQSxRQUMxQ0MsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDakIsMkJBQXFCLEtBQUs7QUFBQSxJQUM1QjtBQUFBLEVBQ0Y7QUFHQSxRQUFNZ0QsK0JBQStCLE9BQU9DLFlBQVk7QUFDdEQsUUFBSSxDQUFDQSxTQUFTO0FBQ1puRCw2QkFBdUIsRUFBRTtBQUN6Qk0sa0NBQTRCLElBQUk7QUFDaEM7QUFBQSxJQUNGO0FBRUFKLHlCQUFxQixJQUFJO0FBQ3pCSSxnQ0FBNEIsS0FBSztBQUNqQyxRQUFJO0FBQ0YsWUFBTXNDLFdBQVcsTUFBTXBMLElBQUlxTCxJQUFJLDRCQUE0Qk0sT0FBTyxFQUFFO0FBQ3BFLFlBQU1DLFdBQVdSLFNBQVNFLE1BQU1BLFFBQVFGLFNBQVNFLFFBQVE7QUFDekQsVUFBSU8sTUFBTUMsUUFBUUYsUUFBUSxLQUFLQSxTQUFTRyxTQUFTLEdBQUc7QUFDbEQsY0FBTUMsWUFBWUosU0FBU0ssSUFBSSxDQUFDQyxTQUFTQyxXQUFXO0FBQUEsVUFDbERDLEtBQUtGLFFBQVFFO0FBQUFBLFVBQ2JDLElBQUlGLFFBQVE7QUFBQSxVQUNackMsY0FBY29DLFFBQVFwQyxnQkFBZ0I7QUFBQSxVQUN0Q1UsY0FBYzBCLFFBQVExQixjQUFjOEIsTUFBTSxHQUFHLEVBQUUsQ0FBQyxLQUFLSixRQUFRMUIsZ0JBQWdCO0FBQUEsVUFDN0VFLFdBQVd3QixRQUFReEIsV0FBVzRCLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBS0osUUFBUXhCLGFBQWE7QUFBQSxVQUNwRTZCLE1BQU1MLFFBQVFsQyxTQUFTd0MsYUFBYTtBQUFBLFVBQ3BDQyxjQUFjUCxRQUFRbEMsU0FBU3lDLGdCQUFnQjtBQUFBLFVBQy9DeEMsUUFBUWlDLFFBQVFqQyxVQUFVO0FBQUEsVUFDMUJDLGFBQWF3QyxTQUFTUixRQUFRN0IsUUFBUSxLQUFLLE1BQU1xQyxTQUFTUixRQUFRL0IsVUFBVSxLQUFLO0FBQUEsVUFDakZ3QyxRQUFRVCxRQUFROUIsY0FBYztBQUFBLFVBQzlCUyxjQUFjcUIsU0FBU1UsdUJBQXVCLGlCQUFpQixpQkFBaUJWLFFBQVFyQixlQUNwRnFCLFFBQVFyQixhQUFhZ0MsT0FBTyxDQUFDLEVBQUVDLFlBQVksSUFBSVosUUFBUXJCLGFBQWFrQyxNQUFNLENBQUMsSUFDM0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFvQ04sRUFBRTtBQUNGdkUsK0JBQXVCd0QsU0FBUztBQUFBLE1BQ2xDLE9BQU87QUFDTHhELCtCQUF1QixFQUFFO0FBQUEsTUFDM0I7QUFBQSxJQUNGLFNBQVMrQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sd0NBQXdDQSxLQUFLO0FBQzNEL0IscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUzZCLE1BQU1ILFVBQVVFLE1BQU01QixXQUFXO0FBQUEsUUFDMUNDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFDRG5CLDZCQUF1QixFQUFFO0FBQUEsSUFDM0IsVUFBQztBQUNDRSwyQkFBcUIsS0FBSztBQUMxQkksa0NBQTRCLElBQUk7QUFBQSxJQUNsQztBQUFBLEVBQ0Y7QUFHQSxRQUFNa0UsOEJBQThCQSxDQUFDckIsWUFBWTtBQUMvQ3JELGlDQUE2QnFELE9BQU87QUFDcENELGlDQUE2QkMsT0FBTztBQUFBLEVBQ3RDO0FBRUFWLFlBQVUsTUFBTTtBQUNkLFFBQUloRCxjQUFjLGdCQUFnQixDQUFDVSw0QkFBNEI7QUFDN0Q4Qyw0QkFBc0I7QUFBQSxJQUN4QjtBQUFBLEVBQ0YsR0FBRyxDQUFDeEQsV0FBV1UsMEJBQTBCLENBQUM7QUFnQjFDc0MsWUFBVSxNQUFNO0FBQ2QsVUFBTWdDLGNBQWMsWUFBWTtBQUU5QixVQUFJL0osMEJBQTBCQSwyQkFBMkIsVUFBVTtBQUNqRSxZQUFJO0FBQ0YsZ0JBQU1rSSxXQUFXLE1BQU1wTCxJQUFJcUw7QUFBQUEsWUFDekIsc0JBQXNCbkksc0JBQXNCO0FBQUEsVUFDOUM7QUFDQTJCLG9CQUFVdUcsU0FBU0UsSUFBSTtBQUFBLFFBQ3pCLFNBQVNDLE9BQU87QUFDZEMsa0JBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQ2pEMUcsb0JBQVUsQ0FBQyxDQUFDO0FBQUEsUUFDZDtBQUFBLE1BQ0YsT0FBTztBQUNMQSxrQkFBVSxDQUFDLENBQUM7QUFBQSxNQUNkO0FBQUEsSUFDRjtBQUNBb0ksZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQy9KLHNCQUFzQixDQUFDO0FBRTNCK0gsWUFBVSxNQUFNO0FBQ2QsUUFBSXpGLGFBQWEwRixRQUFTO0FBRTFCLFVBQU1nQyxzQkFBc0IsWUFBWTtBQUN0Qy9KLGdDQUEwQixRQUFRO0FBQ2xDLFlBQU1nSyxvQkFBb0I7QUFBQSxJQUM1QjtBQUNBRCx3QkFBb0I7QUFDcEIxSCxpQkFBYTBGLFVBQVU7QUFBQSxFQUN6QixHQUFHLEVBQUU7QUFFTCxRQUFNa0MsNkJBQTZCLE9BQU96QixZQUFZO0FBQ3BEeEgsMEJBQXNCLElBQUk7QUFDMUIsUUFBSTtBQUNGLFlBQU1pSCxXQUFXLE1BQU1wTCxJQUFJcUwsSUFBSSxnQ0FBZ0NNLE9BQU8sRUFBRTtBQUN4RSxVQUFJUCxTQUFTRSxNQUFNK0IsV0FBV2pDLFNBQVNFLE1BQU1BLE1BQU1TLFNBQVMsR0FBRztBQUM3RGhJLHVCQUFlcUgsU0FBU0UsS0FBS0EsSUFBSTtBQUNqQ2dDLG1CQUFXLE1BQU07QUFDZnpKLDJCQUFpQixJQUFJO0FBQ3JCd0IsdUJBQWEsYUFBYTtBQUFBLFFBRTVCLEdBQUcsR0FBRztBQUFBLE1BQ1IsT0FBTztBQUNMdEIsdUJBQWUsRUFBRTtBQUNqQkYseUJBQWlCLEtBQUs7QUFBQSxNQUN4QjtBQUFBLElBQ0YsU0FBUzBILE9BQU87QUFDZEMsY0FBUUQsTUFBTSw0Q0FBNENBLEtBQUs7QUFDL0R4SCxxQkFBZSxFQUFFO0FBQ2pCRix1QkFBaUIsS0FBSztBQUFBLElBQ3hCLFVBQUM7QUFDQ00sNEJBQXNCLEtBQUs7QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNb0osbUJBQW1CLE9BQU81QixZQUFZO0FBQzFDLFFBQUk7QUFDRixZQUFNUCxXQUFXLE1BQU1wTCxJQUFJcUw7QUFBQUEsUUFDekIsd0NBQXdDTSxPQUFPO0FBQUEsTUFDakQ7QUFDQSxVQUFJUCxTQUFTRSxRQUFRRixTQUFTRSxLQUFLUyxTQUFTLEdBQUc7QUFDN0MxSSx5QkFBaUIrSCxTQUFTRSxJQUFJO0FBQUEsTUFDaEMsT0FBTztBQUNMakkseUJBQWlCLEVBQUU7QUFBQSxNQUNyQjtBQUFBLElBQ0YsU0FBU2tJLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdERsSSx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU1tSyxlQUFlQSxNQUFNO0FBQ3pCLFVBQU1DLFlBQVksQ0FBQztBQUduQixRQUFJLENBQUN6SyxpQkFBaUI7QUFDcEJ5SyxnQkFBVUMsUUFBUTtBQUFBLElBQ3BCO0FBRUEsUUFBSSxDQUFDOUQsU0FBU1ksY0FBYztBQUMxQmlELGdCQUFVakQsZUFBZTtBQUFBLElBQzNCO0FBQ0EsUUFBSSxDQUFDWixTQUFTYSxjQUFjO0FBQzFCZ0QsZ0JBQVVoRCxlQUFlO0FBQUEsSUFDM0I7QUFFQSxRQUFJLENBQUNiLFNBQVNjLFdBQVc7QUFDdkIrQyxnQkFBVS9DLFlBQVk7QUFBQSxJQUN4QixXQUFXZCxTQUFTYyxZQUFZZCxTQUFTWSxjQUFjO0FBQ3JEaUQsZ0JBQVUvQyxZQUFZO0FBQUEsSUFDeEI7QUFDQSxRQUFJLENBQUNkLFNBQVNlLG1CQUFtQjtBQUMvQjhDLGdCQUFVOUMsb0JBQW9CO0FBQUEsSUFDaEM7QUFHQSxRQUFJaEQsb0JBQW9CO0FBQ3RCLFVBQUluRSxVQUFVb0gsZUFBZSxZQUFZLENBQUNoQixTQUFTaUIsY0FBYztBQUMvRDRDLGtCQUFVNUMsZUFBZTtBQUFBLE1BQzNCO0FBRUEsVUFBSSxDQUFDakIsU0FBU0ksU0FBUztBQUNyQnlELGtCQUFVRSxXQUFXO0FBQUEsTUFDdkI7QUFFQSxVQUFJLENBQUMvRCxTQUFTTSxZQUFZO0FBQ3hCdUQsa0JBQVV2RCxhQUFhO0FBQUEsTUFDekIsV0FDRTBELE1BQU1oRSxTQUFTTSxVQUFVLEtBQ3pCMkQsV0FBV2pFLFNBQVNNLFVBQVUsS0FBSyxHQUNuQztBQUNBdUQsa0JBQVV2RCxhQUFhO0FBQUEsTUFDekIsV0FDRTFHLFVBQVVzSyxlQUNWRCxXQUFXakUsU0FBU00sVUFBVSxJQUFJMkQsV0FBV3JLLFVBQVVzSyxXQUFXLEdBQ2xFO0FBQ0FMLGtCQUFVdkQsYUFBYSwyQ0FBMkMxRyxVQUFVc0ssV0FBVztBQUFBLE1BQ3pGO0FBQUEsSUFDRjtBQUVBL0ksY0FBVTBJLFNBQVM7QUFDbkIsV0FBT00sT0FBT0MsS0FBS1AsU0FBUyxFQUFFMUIsV0FBVztBQUFBLEVBQzNDO0FBRUEsUUFBTWtDLGVBQWVBLENBQUM3RSxNQUFNO0FBQzFCLFVBQU0sRUFBRW1ELE1BQU1sRCxNQUFNLElBQUlELEVBQUVFO0FBRTFCTyxnQkFBWSxDQUFDcUUsYUFBYTtBQUN4QixZQUFNQyxjQUFjO0FBQUEsUUFDbEIsR0FBR0Q7QUFBQUEsUUFDSCxDQUFDM0IsSUFBSSxHQUFHbEQ7QUFBQUEsTUFDVjtBQUdBLFVBQUlrRCxTQUFTLGtCQUFrQmxELE9BQU87QUFDcEMsY0FBTStFLFdBQVcsSUFBSUMsS0FBS2hGLEtBQUs7QUFDL0IrRSxpQkFBU0UsUUFBUUYsU0FBU0csUUFBUSxJQUFJLEVBQUU7QUFFeENKLG9CQUFZekQsWUFBWTBELFNBQVNJLFlBQVksRUFBRWxDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFBQSxNQUM3RDtBQUVBLGFBQU82QjtBQUFBQSxJQUNULENBQUM7QUFFRHBKLGNBQVUsQ0FBQzBKLGdCQUFnQjtBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2xDLElBQUksR0FBRztBQUFBLElBQ1YsRUFBRTtBQUFBLEVBQ0o7QUFFQSxRQUFNbUMsbUJBQW1CQSxDQUFDckYsVUFBVTtBQUNsQyxVQUFNLENBQUNXLFNBQVNDLE1BQU0sSUFBSVosTUFBTWlELE1BQU0sR0FBRztBQUV6Q3pDLGdCQUFZLENBQUNxRSxjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSGxFO0FBQUFBLE1BQ0FDO0FBQUFBLElBQ0YsRUFBRTtBQUVGbEYsY0FBVSxDQUFDMEosZ0JBQWdCLEVBQUUsR0FBR0EsWUFBWWQsVUFBVSxHQUFHLEVBQUU7QUFBQSxFQUM3RDtBQUVBLFFBQU1nQix5QkFBeUJBLENBQUNDLGVBQWU7QUFDN0MsUUFBSUEsWUFBWUMsZ0JBQWdCRCxZQUFZRSxjQUFjO0FBQ3hELFlBQU16RixRQUFRLEdBQUd1RixXQUFXQyxZQUFZLElBQUlELFdBQVdFLFlBQVk7QUFDbkVKLHVCQUFpQnJGLEtBQUs7QUFDdEJRLGtCQUFZLENBQUNxRSxjQUFjO0FBQUEsUUFDekIsR0FBR0E7QUFBQUEsUUFDSHBELGdCQUFnQjhELFdBQVd4QztBQUFBQSxNQUM3QixFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFFQSxRQUFNMkMsb0JBQW9CLE9BQU9wRCxZQUFZO0FBQzNDOUkscUJBQWlCOEksT0FBTztBQUV4QixRQUFJQSxTQUFTO0FBQ1gsVUFBSTtBQUNGLGNBQU00QixpQkFBaUI1QixPQUFPO0FBQUEsTUFDaEMsU0FBU0osT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdERsSSx5QkFBaUIsRUFBRTtBQUFBLE1BQ3JCO0FBQUEsSUFDRixPQUFPO0FBQ0xBLHVCQUFpQixFQUFFO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTTJMLHNCQUFzQixPQUFPckQsWUFBWTtBQUM3QyxRQUFJO0FBQ0YsWUFBTVAsV0FBVyxNQUFNcEwsSUFBSXFMO0FBQUFBLFFBQ3pCLGtEQUFrRE0sT0FBTztBQUFBLE1BQzNEO0FBRUEsVUFBSVAsU0FBU0UsTUFBTStCLFdBQVdqQyxTQUFTRSxNQUFNQSxNQUFNUyxTQUFTLEdBQUc7QUFFN0RyRiwwQkFBa0IwRSxTQUFTRSxLQUFLQSxJQUFJO0FBQUEsTUFDdEMsT0FBTztBQUNMNUUsMEJBQWtCLEVBQUU7QUFBQSxNQUN0QjtBQUFBLElBQ0YsU0FBUzZFLE9BQU87QUFDZEMsY0FBUUQsTUFBTSxtQ0FBbUNBLEtBQUs7QUFDdEQ3RSx3QkFBa0IsRUFBRTtBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUVBLFFBQU11SSxjQUFjLE9BQU90RCxZQUFZO0FBQ3JDNUcsY0FBVSxDQUFDMEosZ0JBQWdCLEVBQUUsR0FBR0EsWUFBWWYsT0FBTyxHQUFHLEVBQUU7QUFDeER6Syx1QkFBbUIwSSxPQUFPO0FBQzFCb0Qsc0JBQWtCcEQsT0FBTztBQUV6QixRQUFJQSxTQUFTO0FBQ1g3RCxpQkFBVyxJQUFJO0FBQ2ZvQiw4QkFBd0IsSUFBSTtBQUU1QixVQUFJO0FBQ0YsY0FBTSxDQUFDZ0csTUFBTUMsTUFBTUMsSUFBSSxJQUFJLE1BQU1DLFFBQVFDO0FBQUFBLFVBQUk7QUFBQSxZQUMzQ3RQLElBQUlxTCxJQUFJLDBCQUEwQk0sT0FBTyxFQUFFO0FBQUEsWUFDM0MzTCxJQUFJcUwsSUFBSSxpREFBaURNLE9BQU8sRUFBRTtBQUFBLFlBQ2xFM0wsSUFBSXFMLElBQUksNkJBQTZCTSxPQUFPLFNBQVM7QUFBQSxVQUFDO0FBQUEsUUFDdkQ7QUFFRGxJLHFCQUFheUwsS0FBSzVELFFBQVEsQ0FBQyxDQUFDO0FBQzVCMUQsOEJBQXNCdUgsS0FBSzdELE1BQU1BLE1BQU1pRSxvQkFBb0I7QUFDM0R2RztBQUFBQSxVQUNFb0csS0FBSzlELE1BQU1BLE1BQU1rRSx5QkFBeUI7QUFBQSxRQUM1QztBQUVBLGNBQU1ILFFBQVFDO0FBQUFBLFVBQUk7QUFBQSxZQUNoQmxDLDJCQUEyQnpCLE9BQU87QUFBQSxZQUNsQ3FELG9CQUFvQnJELE9BQU87QUFBQSxVQUFDO0FBQUEsUUFDN0I7QUFFRDlILHlCQUFpQixJQUFJO0FBQ3JCd0IscUJBQWEsYUFBYTtBQUFBLE1BRzVCLFNBQVNrRyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDhCQUE4QkEsS0FBSztBQUNqRDlILHFCQUFhLENBQUMsQ0FBQztBQUNmdUYsOEJBQXNCLEtBQUs7QUFDM0JuRix5QkFBaUIsSUFBSTtBQUFBLE1BQ3ZCLFVBQUM7QUFFQ2lFLG1CQUFXLEtBQUs7QUFDaEJvQixnQ0FBd0IsS0FBSztBQUFBLE1BQy9CO0FBQUEsSUFDRixPQUFPO0FBQ0x6RixtQkFBYSxDQUFDLENBQUM7QUFDZk0scUJBQWUsRUFBRTtBQUNqQjJDLHdCQUFrQixFQUFFO0FBQ3BCc0MsNEJBQXNCLEtBQUs7QUFDM0JuRix1QkFBaUIsS0FBSztBQUFBLElBQ3hCO0FBQUEsRUFDRjtBQU1BLFFBQU00TCxxQkFBcUIsT0FBT3BHLFVBQVU7QUFDMUMsUUFBSUEsVUFBVSxVQUFVO0FBQ3RCbEcsZ0NBQTBCLFFBQVE7QUFDbEMsWUFBTWdLLG9CQUFvQjtBQUFBLElBQzVCLE9BQU87QUFDTGhLLGdDQUEwQmtHLEtBQUs7QUFDL0IsWUFBTXFHLHlCQUF5QnJHLEtBQUs7QUFBQSxJQUN0QztBQUFBLEVBQ0Y7QUFFQSxRQUFNcUcsMkJBQTJCLE9BQU8vRCxZQUFZO0FBQ2xELFFBQUksQ0FBQ3JKLFVBQVVDLFFBQVE7QUFDckJnRCxvQkFBYyxJQUFJO0FBQ2xCTixtQkFBYSxLQUFLO0FBQ2xCcUIsdUJBQWlCLEtBQUs7QUFDdEI7QUFBQSxJQUNGO0FBQ0F2RCw0QkFBd0I0SSxPQUFPO0FBQy9CLFFBQUlBLFNBQVM7QUFDWGhKLHVCQUFpQixFQUFFO0FBQ25Cc0MsbUJBQWEsSUFBSTtBQUNqQk0sb0JBQWMsS0FBSztBQUNuQixVQUFJO0FBQ0YsY0FBTTZGLFdBQVcsTUFBTXBMLElBQUlxTCxJQUFJLDBCQUEwQk0sT0FBTyxFQUFFO0FBQ2xFLFlBQUlQLFNBQVNFLFFBQVFGLFNBQVNFLEtBQUtTLFNBQVMsR0FBRztBQUM3Q3hJLDZCQUFtQjZILFNBQVNFLElBQUk7QUFDaEMsZ0JBQU1xRSxnQkFBZ0I7QUFBQSxZQUNwQixHQUFHdkUsU0FBU0UsS0FBS1csSUFBSSxDQUFDeUIsT0FBT3ZCLFdBQVc7QUFBQSxjQUN0Q0MsS0FBS3NCLE1BQU10QjtBQUFBQSxjQUNYQyxJQUFJRixRQUFRO0FBQUEsY0FDWnJDLGNBQWM0RCxPQUFPNUQ7QUFBQUEsY0FDckJVLGNBQWNrRCxPQUFPbEQ7QUFBQUEsY0FDckJFLFdBQVdnRCxNQUFNaEQ7QUFBQUEsY0FDakI2QixNQUFNbUIsTUFBTTFELFNBQVN3QztBQUFBQSxjQUNyQkMsY0FBY2lCLE1BQU0xRCxTQUFTeUM7QUFBQUEsY0FDN0J4QyxRQUFReUQsT0FBT3pEO0FBQUFBLGNBQ2ZDLFlBQVl3QyxTQUFTZ0IsTUFBTXJELFFBQVEsSUFBSXFDLFNBQVNnQixNQUFNdkQsVUFBVTtBQUFBLGNBQ2hFd0MsUUFBUWUsT0FBT3REO0FBQUFBLGNBQ2Z3RixRQUFRLENBQUNsQyxPQUFPbUMsV0FDWixjQUNBbkMsT0FBT21DLGFBQWEsU0FDbEIsV0FDQTtBQUFBLGNBQ05oRixjQUNFNkMsT0FBTzdDLGFBQWFnQyxPQUFPLENBQUMsRUFBRUMsWUFBWSxJQUMxQ1ksT0FBTzdDLGFBQWFrQyxNQUFNLENBQUMsSUFDM0I7QUFBQSxjQUNGK0MsUUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTTtBQUFBLG9CQUNKQyxPQUFPO0FBQUEsc0JBQ0w7QUFBQSx3QkFDRUMsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLE1BQ1BDLHNCQUFzQnhDLE1BQU10QixLQUFLRCxRQUFRLENBQUM7QUFBQSw0QkFDM0M7QUFBQTtBQUFBLDBCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFPQTtBQUFBLHNCQUVKO0FBQUEsc0JBQ0E7QUFBQSx3QkFDRTZELEtBQUs7QUFBQSx3QkFDTEMsT0FDRTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFVO0FBQUEsNEJBQ1YsU0FBUyxNQUFNRSxzQkFBc0J6QyxNQUFNdEIsR0FBRztBQUFBLDRCQUFFO0FBQUE7QUFBQSwwQkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsc0JBRUo7QUFBQSxvQkFBQztBQUFBLGtCQUVMO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWLGlDQUFDLFlBQVMsV0FBVSxlQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUErQjtBQUFBO0FBQUEsZ0JBL0JqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FnQ0EsS0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQ0E7QUFBQSxZQUVKLEVBQUU7QUFBQSxVQUFDO0FBRUx6SiwyQkFBaUJnTixhQUFhO0FBQUEsUUFDaEMsT0FBTztBQUNMcE0sNkJBQW1CLEVBQUU7QUFDckJaLDJCQUFpQixFQUFFO0FBQUEsUUFDckI7QUFBQSxNQUNGLFNBQVM0SSxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RGhJLDJCQUFtQixFQUFFO0FBQ3JCWix5QkFBaUIsRUFBRTtBQUFBLE1BQ3JCLFVBQUM7QUFDQ3NDLHFCQUFhLEtBQUs7QUFDbEJNLHNCQUFjLElBQUk7QUFBQSxNQUNwQjtBQUFBLElBQ0YsT0FBTztBQUNMaEMseUJBQW1CLEVBQUU7QUFDckJaLHVCQUFpQixFQUFFO0FBQ25CNEMsb0JBQWMsSUFBSTtBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFFBQU02SyxVQUFVO0FBQUEsSUFDZCxFQUFFSixLQUFLLE1BQU1LLFFBQVEsU0FBUztBQUFBLElBQzlCLEVBQUVMLEtBQUssZ0JBQWdCSyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFTCxLQUFLLGdCQUFnQkssUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUwsS0FBSyxhQUFhSyxRQUFRLFlBQVk7QUFBQSxJQUN4QyxFQUFFTCxLQUFLLFFBQVFLLFFBQVEsZ0JBQWdCO0FBQUEsSUFDdkMsRUFBRUwsS0FBSyxnQkFBZ0JLLFFBQVEsd0JBQXdCO0FBQUEsSUFDdkQsRUFBRUwsS0FBSyxVQUFVSyxRQUFRLFNBQVM7QUFBQSxJQUNsQyxFQUFFTCxLQUFLLGNBQWNLLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVMLEtBQUssVUFBVUssUUFBUSxhQUFhO0FBQUEsSUFDdEMsRUFBRUwsS0FBSyxnQkFBZ0JLLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVMLEtBQUssVUFBVUssUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUwsS0FBSyxVQUFVSyxRQUFRLFNBQVM7QUFBQSxFQUFDO0FBR3JDLFFBQU1DLG9CQUFvQjtBQUFBLElBQ3hCLEVBQUVOLEtBQUssTUFBTUssUUFBUSxTQUFTO0FBQUE7QUFBQSxJQUU5QixFQUFFTCxLQUFLLGdCQUFnQkssUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRUwsS0FBSyxhQUFhSyxRQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUl4QyxFQUFFTCxLQUFLLGNBQWNLLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVMLEtBQUssVUFBVUssUUFBUSxhQUFhO0FBQUEsSUFDdEMsRUFBRUwsS0FBSyxnQkFBZ0JLLFFBQVEsZUFBZTtBQUFBO0FBQUE7QUFBQSxFQUc5QztBQUdGLFFBQU1FLHdCQUF3QjtBQUFBLElBQzVCLEVBQUVQLEtBQUssTUFBTUssUUFBUSxTQUFTO0FBQUEsSUFDOUIsRUFBRUwsS0FBSyxnQkFBZ0JLLFFBQVEsZUFBZTtBQUFBLElBQzlDLEVBQUVMLEtBQUssZ0JBQWdCSyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFTCxLQUFLLGNBQWNLLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUVMLEtBQUssZUFBZUssUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRUwsS0FBSyxRQUFRSyxRQUFRLGdCQUFnQjtBQUFBLElBQ3ZDLEVBQUVMLEtBQUssZ0JBQWdCSyxRQUFRLHdCQUF3QjtBQUFBLElBQ3ZELEVBQUVMLEtBQUssVUFBVUssUUFBUSxTQUFTO0FBQUEsSUFDbEMsRUFBRUwsS0FBSyxjQUFjSyxRQUFRLGFBQWE7QUFBQSxJQUMxQyxFQUFFTCxLQUFLLFVBQVVLLFFBQVEsYUFBYTtBQUFBLElBQ3RDLEVBQUVMLEtBQUssZ0JBQWdCSyxRQUFRLGVBQWU7QUFBQSxJQUM5QyxFQUFFTCxLQUFLLFVBQVVLLFFBQVEsU0FBUztBQUFBLElBQ2xDLEVBQUVMLEtBQUssVUFBVUssUUFBUSxTQUFTO0FBQUEsRUFBQztBQUdyQ3BGLFlBQVUsTUFBTTtBQUNkLFFBQUl6SCxhQUFhb0csU0FBU00sWUFBWTtBQUNwQyxZQUFNQyxhQUNIM0csVUFBVXNLLGNBQWN0SyxVQUFVZ04sbUJBQW9CLE9BQU87QUFDaEUsWUFBTXBHLGNBQ0g1RyxVQUFVc0ssZUFBZSxNQUFNbEUsU0FBU00sY0FBYztBQUN6RCxZQUFNRyxZQUFZVCxTQUFTTSxjQUFjLEtBQUtDO0FBQzlDLFlBQU1HLGdCQUFnQjlHLFVBQVVpTixnQkFDNUJwRyxXQUFXN0csVUFBVWlOLGdCQUNyQjtBQUNKLFlBQU1sRyxXQUFXL0csVUFBVWtOLGlCQUFpQixLQUFLcEc7QUFFakRULGtCQUFZLENBQUNxRSxjQUFjO0FBQUEsUUFDekIsR0FBR0E7QUFBQUEsUUFDSG5FLFVBQVV2RyxVQUFVNEk7QUFBQUEsUUFDcEJqQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBQztBQUFBQSxRQUNBSyxZQUFZcEgsVUFBVW9IO0FBQUFBLE1BQ3hCLEVBQUU7QUFBQSxJQUNKO0FBQUEsRUFDRixHQUFHLENBQUNwSCxXQUFXb0csU0FBU00sVUFBVSxDQUFDO0FBRW5DLFFBQU15RyxlQUFlLE9BQU92SCxNQUFNO0FBQ2hDQSxNQUFFd0gsZUFBZTtBQUdqQixRQUFJN0ksYUFBYztBQUVsQixVQUFNOEksVUFBVXJELGFBQWE7QUFDN0IsUUFBSSxDQUFDcUQsUUFBUztBQUVkLFFBQUk7QUFDRjdJLHNCQUFnQixJQUFJO0FBQ3BCLFVBQUk4STtBQUNKLFVBQUluSixvQkFBb0I7QUFDdEJtSixrQkFBVWxIO0FBQUFBLE1BQ1osT0FBTztBQUVMa0gsa0JBQVU7QUFBQSxVQUNSL0csVUFBVS9HO0FBQUFBLFVBQ1Z3SCxjQUFjWixTQUFTWTtBQUFBQSxVQUN2QkUsV0FBV2QsU0FBU2M7QUFBQUEsUUFDdEI7QUFBQSxNQUNGO0FBRUEsWUFBTVUsV0FBVyxNQUFNcEwsSUFBSStRLEtBQUssd0JBQXdCRCxPQUFPO0FBQy9ELFVBQUkxRixTQUFTd0UsV0FBVyxLQUFLO0FBQzNCcEcsdUJBQWU7QUFBQSxVQUNiQyxZQUFZO0FBQUEsVUFDWkMsU0FBUztBQUFBLFVBQ1RDLE1BQU07QUFBQSxRQUNSLENBQUM7QUFDRHFILHlCQUFpQjtBQUVqQixZQUFJL0ksY0FBYyxjQUFjO0FBQzlCLGNBQUlJLDJCQUEyQjtBQUM3QnFELHlDQUE2QnJELHlCQUF5QjtBQUFBLFVBQ3hEO0FBQUEsUUFDRixPQUFPO0FBQ0wsY0FBSW5GLHdCQUF3QjtBQUMxQndNLHFDQUF5QnhNLHNCQUFzQjtBQUFBLFVBQ2pEO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLFNBQVNxSSxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sa0NBQWtDQSxLQUFLO0FBQ3JEL0IscUJBQWU7QUFBQSxRQUNiQyxZQUFZO0FBQUEsUUFDWkMsU0FBUzZCLE1BQU1ILFVBQVVFLE1BQU01QixXQUFXO0FBQUEsUUFDMUNDLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFFQzNCLHNCQUFnQixLQUFLO0FBQUEsSUFDdkI7QUFBQSxFQUNGO0FBRUEsUUFBTW1JLHdCQUF3QixPQUFPeEUsWUFBWTtBQUMvQyxRQUFJO0FBQ0YsWUFBTVAsV0FBVyxNQUFNcEwsSUFBSXFMLElBQUksOEJBQThCTSxPQUFPLEVBQUU7QUFDdEVwSCxzQkFBZ0I2RyxTQUFTRSxJQUFJO0FBQzdCakgseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTa0gsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUVBLFFBQU0wRixzQkFBc0IsWUFBWTtBQUN0QyxRQUFJM00sY0FBYztBQUNoQixVQUFJO0FBQ0YsY0FBTXRFLElBQUlrUixPQUFPLDJCQUEyQjVNLGFBQWE4SCxHQUFHLEVBQUU7QUFDOUQ1Qyx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTO0FBQUEsVUFDVEMsTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUNEdEYsMkJBQW1CLEtBQUs7QUFDeEJFLHdCQUFnQixJQUFJO0FBQ3BCLFlBQUlyQix3QkFBd0I7QUFDMUJ3TSxtQ0FBeUJ4TSxzQkFBc0I7QUFBQSxRQUNqRDtBQUFBLE1BQ0YsU0FBU3FJLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sMkJBQTJCQSxLQUFLO0FBQUEsTUFDaEQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLFFBQU00RixvQkFBb0IsT0FBTy9ILE1BQU07QUFDckMsVUFBTSxFQUFFbUQsTUFBTWxELE1BQU0sSUFBSUQsRUFBRUU7QUFDMUIwQixzQkFBa0IsQ0FBQ2tELGNBQWM7QUFBQSxNQUMvQixHQUFHQTtBQUFBQSxNQUNILENBQUMzQixJQUFJLEdBQUdsRDtBQUFBQSxJQUNWLEVBQUU7QUFDRnRFLGNBQVUsQ0FBQ21KLGNBQWM7QUFBQSxNQUN2QixHQUFHQTtBQUFBQSxNQUNILENBQUMzQixJQUFJLEdBQUc7QUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTTJELHdCQUF3QixPQUFPdkUsU0FBU3lGLE9BQU87QUFDbkQsUUFBSTtBQUNGLFlBQU1oRyxXQUFXLE1BQU1wTCxJQUFJcUwsSUFBSSw4QkFBOEJNLE9BQU8sRUFBRTtBQUN0RVgsd0JBQWtCO0FBQUEsUUFDaEJSLGNBQWNZLFNBQVNFLE1BQU1kO0FBQUFBLFFBQzdCQyxjQUFjVyxTQUFTRSxNQUFNYjtBQUFBQSxRQUM3QkMsV0FBV1UsU0FBU0UsTUFBTVo7QUFBQUEsUUFDMUJDLG1CQUFtQlMsU0FBU0UsTUFBTVg7QUFBQUEsTUFDcEMsQ0FBQztBQUNEaEcsNEJBQXNCLEVBQUUsR0FBR3lHLFNBQVNFLE1BQU0rRixXQUFXRCxHQUFHLENBQUM7QUFDekQzTSx5QkFBbUIsSUFBSTtBQUFBLElBQ3pCLFNBQVM4RyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sMkJBQTJCQSxLQUFLO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBRUEsUUFBTStGLGVBQWUsT0FBT2xJLE1BQU07QUFDaENBLE1BQUV3SCxlQUFlO0FBQ2pCLFFBQUk7QUFDRixZQUFNeEYsV0FBVyxNQUFNcEwsSUFBSXVSO0FBQUFBLFFBQ3pCLFlBQVk3TSxvQkFBb0IwSCxHQUFHO0FBQUEsUUFDbkNyQjtBQUFBQSxNQUNGO0FBQ0F0Ryx5QkFBbUIsS0FBSztBQUN4QitFLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVM7QUFBQSxRQUNUQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBR0QsVUFBSTFCLGNBQWMsY0FBYztBQUM5QixZQUFJSSwyQkFBMkI7QUFDN0JxRCx1Q0FBNkJyRCx5QkFBeUI7QUFBQSxRQUN4RDtBQUFBLE1BQ0YsT0FBTztBQUNMLFlBQUluRix3QkFBd0I7QUFDMUJ3TSxtQ0FBeUJ4TSxzQkFBc0I7QUFBQSxRQUNqRDtBQUFBLE1BQ0Y7QUFBQSxJQUVGLFNBQVNxSSxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQ2hELFVBQ0VBLE1BQU1ILFlBQ05HLE1BQU1ILFNBQVNFLFFBQ2ZDLE1BQU1ILFNBQVNFLEtBQUs1QixTQUNwQjtBQUNBRix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTLEdBQUc2QixPQUFPSCxVQUFVRSxNQUFNNUIsT0FBTztBQUFBLFVBQzFDQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSCxPQUFPO0FBQ0xILHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTTZILHNCQUFzQjFOLFlBQVkyTixPQUFPLENBQUNDLFNBQVM7QUFDdkQsUUFBSSxDQUFDMU4sZ0JBQWlCLFFBQU87QUFDN0IsVUFBTTJOLFdBQ0pELE1BQU1FLG1CQUFtQnBGLFdBQVdxRixZQUFZLEtBQ2hESCxNQUFNSSxnQkFBZ0JELFlBQVksS0FDbEM7QUFDRixVQUFNNUgsU0FBU3lILE1BQU01QyxjQUFjaUQsU0FBUyxFQUFFRixZQUFZLEtBQUs7QUFDL0QsVUFBTUcsUUFDSk4sTUFBTUUsbUJBQW1CbkYsY0FBY3NGLFNBQVMsRUFBRUYsWUFBWSxLQUM5REgsTUFBTU8sY0FBY0YsU0FBUyxFQUFFRixZQUFZLEtBQzNDO0FBQ0YsVUFBTUssVUFBVVIsTUFBTVMsa0JBQWtCSixTQUFTLEVBQUVGLFlBQVksS0FBSztBQUNwRSxXQUNFRixTQUFTUyxTQUFTcE8sZ0JBQWdCNk4sWUFBWSxDQUFDLEtBQy9DNUgsT0FBT21JLFNBQVNwTyxnQkFBZ0I2TixZQUFZLENBQUMsS0FDN0NHLE1BQU1JLFNBQVNwTyxnQkFBZ0I2TixZQUFZLENBQUMsS0FDNUNLLFFBQVFFLFNBQVNwTyxnQkFBZ0I2TixZQUFZLENBQUM7QUFBQSxFQUVsRCxDQUFDO0FBRUQsUUFBTWIsbUJBQW1CQSxNQUFNO0FBQzdCck4saUJBQWEsS0FBSztBQUNsQkUscUJBQWlCLEtBQUs7QUFDdEJrQixjQUFVLENBQUMsQ0FBQztBQUNaaEIsbUJBQWUsRUFBRTtBQUNqQkUsdUJBQW1CLEVBQUU7QUFDckJoQix1QkFBbUIsRUFBRTtBQUNyQlEsaUJBQWEsQ0FBQyxDQUFDO0FBQ2ZKLHFCQUFpQixFQUFFO0FBQ25CZ0MsaUJBQWEsYUFBYTtBQUMxQndFLGdCQUFZO0FBQUEsTUFDVkMsY0FBYztBQUFBLE1BQ2RDLFVBQVU7QUFBQSxNQUNWQyxTQUFTO0FBQUEsTUFDVEMsUUFBUTtBQUFBLE1BQ1JDLFlBQVk7QUFBQSxNQUNaQyxZQUFZO0FBQUEsTUFDWkMsWUFBWTtBQUFBLE1BQ1pDLFVBQVU7QUFBQSxNQUNWQyxlQUFlO0FBQUEsTUFDZkMsU0FBUztBQUFBLE1BQ1RDLGNBQWM7QUFBQSxNQUNkRSxXQUFXO0FBQUEsTUFDWEUsWUFBWTtBQUFBLE1BQ1pDLGNBQWM7QUFBQSxNQUNkQyxnQkFBZ0I7QUFBQSxJQUNsQixDQUFDO0FBQ0Q5QiwwQkFBc0IsS0FBSztBQUFBLEVBQzdCO0FBRUEsUUFBTXFKLHVCQUF1QkEsTUFBTTtBQUNqQ3hPLHFCQUFpQixLQUFLO0FBQUEsRUFDeEI7QUFFQW9ILFlBQVUsTUFBTTtBQUNkLFFBQ0U5QyxpQkFBaUI0RCxTQUFTLEtBQzFCLENBQUMxRCwyQkFDRDtBQUNBQyxtQ0FBNkJILGlCQUFpQixDQUFDLEVBQUVpRSxHQUFHO0FBQ3BEWSxrQ0FBNEI3RSxpQkFBaUIsQ0FBQyxFQUFFaUUsR0FBRztBQUFBLElBQ3JEO0FBQUEsRUFDRixHQUFHLENBQUNqRSxnQkFBZ0IsQ0FBQztBQUVyQixRQUFNbUsseUJBQXlCQSxNQUFNO0FBQ25Dak4saUJBQWEsVUFBVTtBQUFBLEVBQ3pCO0FBRUEsUUFBTWtOLDRCQUE0QkEsTUFBTTtBQUN0Q2xOLGlCQUFhLGFBQWE7QUFBQSxFQUM1QjtBQUVBLFFBQU1tTiwrQkFBK0JBLE1BQU07QUFDekNuTixpQkFBYSxlQUFlO0FBQUEsRUFDOUI7QUFFQSxRQUFNb04sd0JBQXdCLFlBQVk7QUFDeEMsUUFBSSxDQUFDelAsaUJBQWlCO0FBQ3BCMFAsWUFBTSw2QkFBNkI7QUFDbkM7QUFBQSxJQUNGO0FBRUExTSwwQkFBc0IsSUFBSTtBQUMxQixRQUFJO0FBQ0YsWUFBTW9GLFdBQVcsTUFBTXBMLElBQUlxTDtBQUFBQSxRQUN6QixtQ0FBbUNySSxlQUFlO0FBQUEsTUFDcEQ7QUFDQSxZQUFNc0ksT0FBT0YsU0FBU0U7QUFDdEIsVUFBSUEsS0FBS3NFLFdBQVcsTUFBTTtBQUN4QjlKLDJCQUFtQndGLElBQUk7QUFDdkIxRixnQ0FBd0IsSUFBSTtBQUFBLE1BQzlCLE9BQU87QUFFTCxZQUFJK00sZUFBZXJILEtBQUs1QixXQUFXO0FBRW5DLFlBQUk0QixLQUFLQyxTQUFTRCxLQUFLQyxNQUFNNkcsU0FBUyxXQUFXLEdBQUc7QUFDbERPLHlCQUFlO0FBQUEsUUFDakI7QUFFQW5KLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVNpSjtBQUFBQSxVQUNUaEosTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVM0QixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQ2hELFVBQUlvSCxlQUFlO0FBRW5CLFVBQUlwSCxNQUFNSCxVQUFVRSxNQUFNQyxPQUFPO0FBQy9Cb0gsdUJBQWVwSCxNQUFNSCxTQUFTRSxLQUFLQztBQUFBQSxNQUNyQyxXQUFXQSxNQUFNSCxVQUFVRSxNQUFNNUIsU0FBUztBQUN4Q2lKLHVCQUFlcEgsTUFBTUgsU0FBU0UsS0FBSzVCO0FBQUFBLE1BQ3JDO0FBRUFGLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVNpSjtBQUFBQSxRQUNUaEosTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDM0QsNEJBQXNCLEtBQUs7QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFFQSxRQUFNbUgsc0JBQXNCLFlBQVk7QUFDdEMsUUFBSSxDQUFDN0ssVUFBVUMsUUFBUTtBQUNyQmdELG9CQUFjLElBQUk7QUFDbEJOLG1CQUFhLEtBQUs7QUFDbEJxQix1QkFBaUIsS0FBSztBQUN0QjtBQUFBLElBQ0Y7QUFHQSxRQUFJO0FBQ0YsWUFBTThFLFdBQVcsTUFBTXBMLElBQUlxTCxJQUFJLDJCQUEyQjtBQUcxRCxZQUFNdUgsZUFBZXhILFNBQVNFLE1BQU1BLFFBQVFGLFNBQVNFO0FBRXJELFVBQ0VzSCxnQkFDQS9HLE1BQU1DLFFBQVE4RyxZQUFZLEtBQzFCQSxhQUFhN0csU0FBUyxHQUN0QjtBQUNBN0YsMEJBQWtCME0sWUFBWTtBQUM5QixjQUFNakQsZ0JBQWdCaUQsYUFBYTNHLElBQUksQ0FBQ0MsU0FBU0MsV0FBVztBQUFBLFVBQzFEQyxLQUFLRixRQUFRRTtBQUFBQSxVQUNiQyxJQUFJRixRQUFRO0FBQUEsVUFDWnJDLGNBQWNvQyxTQUFTcEM7QUFBQUEsVUFDdkJVLGNBQ0UwQixTQUFTMUIsY0FBYzhCLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBS0osU0FBUzFCO0FBQUFBLFVBQ25EcUksWUFBWTNHLFFBQVFuQyxVQUFVOEksY0FBYztBQUFBLFVBQzVDL0UsYUFBYTVCLFFBQVFuQyxVQUFVK0QsZUFBZTtBQUFBLFVBQzlDdkIsTUFBTUwsUUFBUWxDLFNBQVN3QyxhQUFhO0FBQUEsVUFDcENDLGNBQWNQLFFBQVFsQyxTQUFTeUMsZ0JBQWdCO0FBQUEsVUFDL0N4QyxRQUFRaUMsU0FBU2pDO0FBQUFBLFVBQ2pCQyxhQUNHd0MsU0FBU1IsUUFBUTdCLFFBQVEsS0FBSyxNQUM5QnFDLFNBQVNSLFFBQVEvQixVQUFVLEtBQUs7QUFBQSxVQUNuQ3dDLFFBQVFULFNBQVM5QjtBQUFBQSxVQUNqQlMsY0FDRXFCLFNBQVNyQixjQUFjZ0MsT0FBTyxDQUFDLEVBQUVDLFlBQVksSUFDN0NaLFNBQVNyQixjQUFja0MsTUFBTSxDQUFDLElBQzlCO0FBQUEsVUFDRjZDLFFBQVEsQ0FBQzFELFNBQVMyRCxXQUNkLGNBQ0EzRCxTQUFTMkQsYUFBYSxTQUNwQixXQUNBO0FBQUEsVUFDTkMsUUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQU07QUFBQSxnQkFDSkMsT0FBTztBQUFBLGtCQUNMO0FBQUEsb0JBQ0VDLEtBQUs7QUFBQSxvQkFDTEMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUNQQyxzQkFBc0JoRSxRQUFRRSxLQUFLRCxRQUFRLENBQUM7QUFBQSx3QkFDN0M7QUFBQTtBQUFBLHNCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFPQTtBQUFBLGtCQUVKO0FBQUEsa0JBQ0E7QUFBQSxvQkFDRTZELEtBQUs7QUFBQSxvQkFDTEMsT0FDRTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFVO0FBQUEsd0JBQ1YsU0FBUyxNQUFNRSxzQkFBc0JqRSxRQUFRRSxHQUFHO0FBQUEsd0JBQUU7QUFBQTtBQUFBLHNCQUZwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBS0E7QUFBQSxrQkFFSjtBQUFBLGdCQUFDO0FBQUEsY0FFTDtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBRVYsaUNBQUMsWUFBUyxXQUFVLGVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQStCO0FBQUE7QUFBQSxZQS9CakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBZ0NBLEtBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0NBO0FBQUEsUUFFSixFQUFFO0FBQ0Z6Six5QkFBaUJnTixhQUFhO0FBQUEsTUFDaEMsT0FBTztBQUNMekosMEJBQWtCLEVBQUU7QUFDcEJ2RCx5QkFBaUIsRUFBRTtBQUFBLE1BQ3JCO0FBQUEsSUFDRixTQUFTNEksT0FBTztBQUNkQyxjQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RC9CLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQ0U2QixNQUFNSCxVQUFVRSxNQUFNNUIsV0FBVztBQUFBLFFBQ25DQyxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQ0RoSCx1QkFBaUIsRUFBRTtBQUNuQjRDLG9CQUFjLElBQUk7QUFBQSxJQUNwQixVQUFDO0FBQ0NlLHVCQUFpQixLQUFLO0FBQ3RCZixvQkFBYyxJQUFJO0FBQUEsSUFDcEI7QUFBQSxFQUNGO0FBRUEsUUFBTXVOLHNCQUFzQixZQUFZO0FBQ3RDLFFBQUksQ0FBQzlQLGlCQUFpQjtBQUNwQjBQLFlBQU0sNkJBQTZCO0FBQ25DO0FBQUEsSUFDRjtBQUVBdEwsNEJBQXdCLElBQUk7QUFDNUIsUUFBSTtBQUNGLFlBQU1nRSxXQUFXLE1BQU1wTCxJQUFJcUw7QUFBQUEsUUFDekIsNkJBQTZCckksZUFBZTtBQUFBLE1BQzlDO0FBQ0EsWUFBTXNJLE9BQU9GLFNBQVNFO0FBQ3RCLFVBQUlBLEtBQUtzRSxXQUFXLE1BQU07QUFDeEI1SSw2QkFBcUJzRSxJQUFJO0FBQ3pCcEUsa0NBQTBCLElBQUk7QUFBQSxNQUNoQyxPQUFPO0FBQ0wsWUFBSXlMLGVBQWVySCxLQUFLNUIsV0FBVztBQUVuQyxZQUFJNEIsS0FBS0MsU0FBU0QsS0FBS0MsTUFBTTZHLFNBQVMsV0FBVyxHQUFHO0FBQ2xETyx5QkFBZTtBQUFBLFFBQ2pCO0FBRUFuSix1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNaQyxTQUFTaUo7QUFBQUEsVUFDVGhKLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixTQUFTNEIsT0FBTztBQUNkQyxjQUFRRCxNQUFNLGtDQUFrQ0EsS0FBSztBQUNyRCxVQUFJb0gsZUFBZTtBQUVuQixVQUFJcEgsTUFBTUgsVUFBVUUsTUFBTUMsT0FBTztBQUMvQm9ILHVCQUFlcEgsTUFBTUgsU0FBU0UsS0FBS0M7QUFBQUEsTUFDckMsV0FBV0EsTUFBTUgsVUFBVUUsTUFBTTVCLFNBQVM7QUFDeENpSix1QkFBZXBILE1BQU1ILFNBQVNFLEtBQUs1QjtBQUFBQSxNQUNyQztBQUVBRixxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTaUo7QUFBQUEsUUFDVGhKLE1BQU07QUFBQSxNQUNSLENBQUM7QUFBQSxJQUNILFVBQUM7QUFDQ3ZDLDhCQUF3QixLQUFLO0FBQUEsSUFDL0I7QUFBQSxFQUNGO0FBRUEsUUFBTTJMLDBCQUEwQixZQUFZO0FBQzFDLFFBQUksQ0FBQy9QLGlCQUFpQjtBQUNwQjBQLFlBQU0sNkJBQTZCO0FBQ25DO0FBQUEsSUFDRjtBQUVBaEwscUJBQWlCLElBQUk7QUFDckIsUUFBSTtBQUNGLFlBQU0wRCxXQUFXLE1BQU1wTCxJQUFJcUw7QUFBQUEsUUFDekIsZ0NBQWdDckksZUFBZTtBQUFBLE1BQ2pEO0FBQ0EsWUFBTXNJLE9BQU9GLFNBQVNFO0FBRXRCLFVBQUlBLEtBQUtzRSxXQUFXLE1BQU07QUFDeEJwSSxzQkFBYzhELEtBQUtBLFFBQVEsRUFBRTtBQUM3QmhFLDJCQUFtQixJQUFJO0FBQUEsTUFDekIsT0FBTztBQUNMLFlBQUlxTCxlQUFlckgsS0FBSzVCLFdBQVc7QUFFbkNGLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVNpSjtBQUFBQSxVQUNUaEosTUFBTTtBQUFBLFFBQ1IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLFNBQVM0QixPQUFPO0FBQ2RDLGNBQVFELE1BQU0sc0NBQXNDQSxLQUFLO0FBQ3pELFVBQUlvSCxlQUFlO0FBRW5CLFVBQUlwSCxNQUFNSCxVQUFVRSxNQUFNNUIsU0FBUztBQUNqQ2lKLHVCQUFlcEgsTUFBTUgsU0FBU0UsS0FBSzVCO0FBQUFBLE1BQ3JDO0FBRUFGLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVNpSjtBQUFBQSxRQUNUaEosTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDakMsdUJBQWlCLEtBQUs7QUFBQSxJQUN4QjtBQUFBLEVBQ0Y7QUFFQSxTQUNFLG1DQUNFLGlDQUFDLFNBQ0MsaUNBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFlBQVk7QUFBQTtBQUFBLE1BRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRW1CO0FBQUEsSUFFbkIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVE7QUFBQSxJQUVSO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxNQUFNNkIsWUFBWUk7QUFBQUEsUUFDbEIsV0FBV0osWUFBWUU7QUFBQUEsUUFDdkIsU0FBU0YsWUFBWUc7QUFBQUE7QUFBQUEsTUFIdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRytCO0FBQUEsSUFJL0IsdUJBQUMsU0FBTSxXQUFXaEcsV0FBVyxTQUFTc04sa0JBQ3BDLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLCtCQUFDLFFBQUcsV0FBVSxtQ0FBa0MsMkJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxRQUMzRCx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTeUI7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQU0sV0FBVSxhQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUEwQjtBQUFBLGdCQUFHO0FBQUE7QUFBQTtBQUFBLFlBSi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU0s7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QjtBQUFBLGdCQUFHO0FBQUE7QUFBQTtBQUFBLFlBSmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsVUFFQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBU0M7QUFBQUEsY0FDVCxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFlBQVMsV0FBVSxhQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2QjtBQUFBLGdCQUFHO0FBQUE7QUFBQTtBQUFBLFlBSmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1BO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFdBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQkE7QUFBQSxNQUVBLHVCQUFDLFVBQUssV0FBVSxhQUFZLFVBQVVwQyxjQUFjLFlBQVUsTUFFNUQ7QUFBQSwrQkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLFlBQ3hELHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWlDO0FBQUEsZUFEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVcscUNBQXFDclAsVUFBVTBSLE1BQU07QUFBQSxjQUNoRSxhQUFZO0FBQUEsY0FDWix1QkFBdUI7QUFBQSxjQUN2QjtBQUFBLGNBQ0EsTUFBSztBQUFBLGNBQ0wsT0FBT2hRLG1CQUFtQmlRO0FBQUFBLGNBQzFCLFVBQVUsQ0FBQzVKLFVBQVU0RixZQUFZNUYsS0FBSztBQUFBLGNBQ3RDLGNBQWMsQ0FBQzZKLE9BQU9DLFdBQ3BCQSxRQUFRQyxVQUNKdkIsWUFBWSxFQUNiTyxTQUFTYyxNQUFNckIsWUFBWSxDQUFDO0FBQUEsY0FHaENyUCxpQkFBT3lKO0FBQUFBLGdCQUFJLENBQUN5QixVQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNdEIsS0FDekNzQixnQkFBTW1GLGNBRFduRixNQUFNdEIsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGNBQ0Q7QUFBQTtBQUFBLFlBbEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQW1CQTtBQUFBLFVBQ0N0SCxPQUFPNEksU0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCNUksaUJBQU80SSxTQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF1RDtBQUFBLGFBekIzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBMkJBO0FBQUEsUUFFQ3pFLHdCQUNDLHVCQUFDLE9BQUUsV0FBVSw4QkFBNkIsMENBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0RGLHFCQUNDLHVCQUFDLFNBQUksV0FBVSx3RkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSw2RUFDYixpQ0FBQyxVQUFLLFdBQVUsV0FBVSxrQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEIsS0FEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsU0FDQztBQUFBLG1DQUFDLE9BQUUsV0FBVSxzQ0FBcUMseUNBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBLHVCQUFDLE9BQUUsV0FBVSx1Q0FBc0MsNEdBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0E7QUFBQSxlQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFjQSxJQUVBLG1DQUNFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDJCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU92RixVQUFVc0ssZUFBZTtBQUFBLGtCQUNoQztBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUt1STtBQUFBLGNBRXZJLHVCQUFDLFVBQUssV0FBVSx3Q0FDYnZNLDhCQUFvQmlDLFdBQVdzSyxlQUFlLENBQUMsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBY0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyxpQ0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPdEssVUFBVWtOLGlCQUFpQjtBQUFBLGtCQUNsQztBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUt1STtBQUFBLGNBRXZJLHVCQUFDLFVBQUssV0FBVSx3Q0FDYm5QLDhCQUFvQmlDLFdBQVdrTixpQkFBaUIsQ0FBQyxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFjQTtBQUFBLGVBOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBK0JBO0FBQUEsVUFFQ2xOLFVBQVVvSCxlQUFlLFlBQ3hCLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsbUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsT0FBT2hCLFNBQVNpQjtBQUFBQSxnQkFDaEIsVUFBVW9EO0FBQUFBLGdCQUNWO0FBQUEsZ0JBQ0EsV0FBVTtBQUFBLGdCQUVWO0FBQUEseUNBQUMsWUFBTyxPQUFNLFVBQVMsOEJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDO0FBQUEsa0JBQ3JDLHVCQUFDLFlBQU8sT0FBTSxRQUFPLDRCQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFpQztBQUFBO0FBQUE7QUFBQSxjQVJuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFTQTtBQUFBLFlBQ0NuSixPQUFPK0YsZ0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWL0YsaUJBQU8rRixnQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkE7QUFBQSxVQUVEbEQsc0JBQ0MsbUNBQ0UsaUNBQUMsUUFBSyxVQUFVRSxTQUNkLGlDQUFDLFNBQUksV0FBV0EsVUFBVSxtQ0FBbUMsSUFFM0Q7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUNwRCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBLG1CQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQ3ZHLFVBQVUwUixNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsT0FDRXBKLFNBQVNJLFdBQVdKLFNBQVNLLFNBQ3pCLEdBQUdMLFNBQVNJLE9BQU8sSUFBSUosU0FBU0ssTUFBTSxLQUN0Q2dKO0FBQUFBLGtCQUVOLFVBQVV2RTtBQUFBQSxrQkFDVixjQUFjLENBQUN3RSxPQUFPQyxXQUNwQkEsUUFBUUMsVUFDSnZCLFlBQVksRUFDYk8sU0FBU2MsTUFBTXJCLFlBQVksQ0FBQztBQUFBLGtCQUdoQ3pPLHdCQUFjNkk7QUFBQUEsb0JBQ2IsQ0FBQ3lGLFNBQ0NBLE1BQU0xSCxTQUFTb0MsT0FDYjtBQUFBLHNCQUFDLE9BQU87QUFBQSxzQkFBUDtBQUFBLHdCQUVDLE9BQU8sR0FBR3NGLEtBQUsxSCxRQUFRb0MsR0FBRyxJQUFJc0YsS0FBSzJCLE9BQU87QUFBQSx3QkFFekMsYUFBRzNCLEtBQUsxSCxRQUFRd0MsU0FBUyxNQUFNa0YsS0FBSzJCLE9BQU87QUFBQTtBQUFBLHNCQUh2QyxHQUFHM0IsS0FBSzFILFFBQVFvQyxHQUFHLElBQUlzRixLQUFLMkIsT0FBTztBQUFBLHNCQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUtBO0FBQUEsa0JBRU47QUFBQTtBQUFBLGdCQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0E2QkE7QUFBQSxjQUNDdk8sT0FBTzZJLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWN0ksaUJBQU82SSxZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFyQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1Q0E7QUFBQSxZQUVBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUscURBQW9EO0FBQUE7QUFBQSxnQkFDeEQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQSxtQkFEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPL0QsU0FBU007QUFBQUEsa0JBQ2hCLFVBQVUrRDtBQUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFQWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPdUk7QUFBQSxjQUV0SW5KLE9BQU9vRixjQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVnBGLGlCQUFPb0YsY0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFRix1QkFBQyxVQUFLLFdBQVUsd0NBQ2IzSSw4QkFBb0JxSSxVQUFVTSxjQUFjLENBQUMsS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXFCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLGdEQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDBCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPTixTQUFTTztBQUFBQSxvQkFDaEI7QUFBQSxvQkFDQTtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNdUk7QUFBQSxnQkFFdkksdUJBQUMsVUFBSyxXQUFVLHdDQUNiNUksOEJBQW9CcUksVUFBVU8sY0FBYyxDQUFDLEtBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsOEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9QLFNBQVNRO0FBQUFBLG9CQUNoQjtBQUFBLG9CQUNBO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU11STtBQUFBLGdCQUV2SSx1QkFBQyxVQUFLLFdBQVUsd0NBQ2I3SSw4QkFBb0JxSSxVQUFVUSxjQUFjLENBQUMsS0FEaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUE7QUFBQSxpQkFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQ0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxnREFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyx3QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT1IsU0FBU1M7QUFBQUEsb0JBQ2hCO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTXVJO0FBQUEsZ0JBRXZJLHVCQUFDLFVBQUssV0FBVSx3Q0FDYjlJLDhCQUFvQnFJLFVBQVVTLFlBQVksQ0FBQyxLQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLGlDQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPVCxTQUFTVTtBQUFBQSxvQkFDaEI7QUFBQSxvQkFDQTtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNdUk7QUFBQSxnQkFFdkksdUJBQUMsVUFBSyxXQUFVLHdDQUNiL0ksOEJBQW9CcUksVUFBVVUsaUJBQWlCLENBQUMsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZUE7QUFBQSxpQkFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQ0E7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEscUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPVixTQUFTVztBQUFBQSxrQkFDaEI7QUFBQSxrQkFDQTtBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQU11STtBQUFBLGNBRXZJLHVCQUFDLFVBQUssV0FBVSx3Q0FDYmhKLDhCQUFvQnFJLFVBQVVXLFdBQVcsQ0FBQyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLGVBdkpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeUpBLEtBMUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkpBLEtBNUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkpBO0FBQUEsVUFFRix1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUNqRCx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBLG1CQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU9YLFNBQVNZO0FBQUFBLGtCQUNoQixVQUFVeUQ7QUFBQUEsa0JBQ1Y7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNdUk7QUFBQSxjQUV0SW5KLE9BQU8wRixnQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1YxRixpQkFBTzBGLGdCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDbEQsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQSxtQkFEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPWixTQUFTYTtBQUFBQSxrQkFDaEIsVUFBVXdEO0FBQUFBLGtCQUNWO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTXVJO0FBQUEsY0FFdEluSixPQUFPMkYsZ0JBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUNWM0YsaUJBQU8yRixnQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpQkE7QUFBQSxlQXBDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFDQTtBQUFBLFVBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDNUMsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBaUM7QUFBQSxtQkFEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPYixTQUFTYztBQUFBQSxrQkFDaEIsVUFBVXVEO0FBQUFBLGtCQUNWO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTXVJO0FBQUEsY0FFdEluSixPQUFPNEYsYUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y1RixpQkFBTzRGLGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUM1Qyx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLGlCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFpQztBQUFBLG1CQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU9kLFNBQVNlO0FBQUFBLGtCQUNoQixVQUFVc0Q7QUFBQUEsa0JBQ1Y7QUFBQSxrQkFDQSxXQUFVO0FBQUE7QUFBQSxnQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FNdUk7QUFBQSxjQUV0SW5KLE9BQU82RixxQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Y3RixpQkFBTzZGLHFCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQTtBQUFBLGVBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcUNBO0FBQUEsVUFFQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLE1BQUs7QUFBQSxjQUNMLFVBQVM7QUFBQSxjQUNULFNBQVM1QztBQUFBQSxjQUNULFVBQVVBO0FBQUFBLGNBQ1YsV0FBVTtBQUFBLGNBQU87QUFBQTtBQUFBLFlBTG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLGFBL1NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnVEE7QUFBQSxXQXRXSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMFdBO0FBQUEsU0F4WUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlZQSxLQTFZRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMllBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVywwSkFBMEpuRSxnQkFBZ0Isa0JBQWtCLGtCQUFrQjtBQUFBLFFBRXpOLE9BQU8sRUFBRTBQLGVBQWUxUCxnQkFBZ0IsU0FBUyxPQUFPO0FBQUEsUUFFeEQ7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsNkVBQ2IsaUNBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG1FQUNiLGlDQUFDLGVBQVksV0FBVSx3QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBRUEsdUJBQUMsU0FDQztBQUFBLHVDQUFDLFFBQUcsV0FBVSxxQ0FDWHdCLHdCQUFjLGdCQUFnQixpQkFBaUIscUJBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUseUJBQ1Y1QixvQkFBVXFQLGNBQWMsb0JBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsaUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBU1I7QUFBQUEsZ0JBQ1QsV0FBVTtBQUFBLGdCQUVWLGlDQUFDLEtBQUUsTUFBTSxNQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQVk7QUFBQTtBQUFBLGNBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxlQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTZCQSxLQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQStCQTtBQUFBLFVBZ0JBLHVCQUFDLFNBQUksV0FBVSxpREFDYixpQ0FBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVNFO0FBQUFBLGdCQUNULFdBQVcsa0VBQWtFbk4sY0FBYyxnQkFDdkYscUNBQ0EsbUNBQW1DO0FBQUEsZ0JBQ2xDO0FBQUE7QUFBQSxrQkFFVXRCLFlBQVlpSTtBQUFBQSxrQkFBTztBQUFBO0FBQUE7QUFBQSxjQVBwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFTeUc7QUFBQUEsZ0JBQ1QsV0FBVyxrRUFBa0VwTixjQUFjLGtCQUN2RixxQ0FDQSxtQ0FBbUM7QUFBQSxnQkFDbEM7QUFBQTtBQUFBLGtCQUVhcUIsZUFBZXNGO0FBQUFBLGtCQUFPO0FBQUE7QUFBQTtBQUFBLGNBUDFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFBO0FBQUEsZUFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFtQkEsS0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxVQUVDM0csY0FBYyxpQkFDYix1QkFBQyxTQUFJLFdBQVUsc0NBQ2IsaUNBQUMsU0FBSSxXQUFVLFlBQ2I7QUFBQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFdBQVU7QUFBQSxnQkFDVixNQUFNO0FBQUE7QUFBQSxjQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUVXO0FBQUEsWUFFWDtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTCxhQUFZO0FBQUEsZ0JBQ1osT0FBT3BCO0FBQUFBLGdCQUNQLFVBQVUsQ0FBQ29GLE1BQU1uRixtQkFBbUJtRixFQUFFRSxPQUFPRCxLQUFLO0FBQUEsZ0JBQ2xELFdBQVU7QUFBQSxnQkFDVixTQUFTLENBQUNELE1BQU1BLEVBQUVtSyxnQkFBZ0I7QUFBQTtBQUFBLGNBTnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQU1zQztBQUFBLGVBWHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBYUEsS0FkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWVBO0FBQUEsVUFHRix1QkFBQyxTQUFJLFdBQVUsMEJBQ1pyUCwrQkFDQyx1QkFBQyxTQUFJLFdBQVUsMkNBQ2IsaUNBQUMsa0JBQWUsV0FBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQyxLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLElBQ0VrQixjQUFjLGdCQUNoQm9NLG9CQUFvQnpGLFNBQVMsSUFDM0IsdUJBQUMsU0FBSSxXQUFVLGlCQUNaeUYsOEJBQW9CdkYsSUFBSSxDQUFDMkMsWUFBWXpDLFVBQVU7QUFDOUMsa0JBQU13RixXQUNKL0MsWUFBWWdELG1CQUFtQnBGLGFBQy9Cb0MsWUFBWWtELGtCQUNaO0FBQ0Ysa0JBQU1FLFFBQ0pwRCxZQUFZZ0QsbUJBQW1CbkYsZ0JBQy9CbUMsWUFBWXFELGdCQUNaO0FBQ0Ysa0JBQU1oSSxTQUFTMkUsWUFBWUUsZ0JBQWdCO0FBQzNDLGtCQUFNb0QsVUFBVXRELFlBQVl1RCxvQkFBb0I7QUFDaEQsa0JBQU12QyxTQUFTaEIsWUFBWWdCLFVBQVU7QUFDckMsa0JBQU00RCxhQUNKNUosU0FBU0ksWUFBWTRFLFdBQVdDLGdCQUNoQ2pGLFNBQVNLLFdBQVcyRSxXQUFXRTtBQUVqQyxrQkFBTTJFLFVBQVU3RSxZQUFZNkUsVUFDeEJDLEtBQUtDLE1BQU0vRSxXQUFXNkUsT0FBTyxJQUM3QjtBQUNKLGtCQUFNRyxRQUFRSCxXQUFXO0FBQ3pCLGtCQUFNSSxRQUFRSixVQUFVO0FBRXhCLG1CQUNFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsU0FBUyxNQUFNOUUsdUJBQXVCQyxVQUFVO0FBQUEsZ0JBQ2hELFdBQVcsMEVBQTBFNEUsYUFDakYsOERBQ0EsaUZBQWlGO0FBQUEsZ0JBR3JGLGlDQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVcsMEdBQTBHQSxhQUNqSCxnQkFDQSxxQ0FBcUM7QUFBQSxzQkFHeEM3QixvQkFBVTlFLE9BQU8sQ0FBQyxHQUFHQyxZQUFZLEtBQUs7QUFBQTtBQUFBLG9CQU56QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBT0E7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSwyQ0FBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSw2Q0FBQyxPQUFFLFdBQVUsZ0RBQ1Y2RSxzQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0E7QUFBQSx3QkFBQztBQUFBO0FBQUEsMEJBQ0MsV0FBVyxpREFBaUQvQixXQUFXLFdBQ25FLGdDQUNBLCtCQUErQjtBQUFBLDBCQUdsQ0E7QUFBQUE7QUFBQUEsd0JBTkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQU9BO0FBQUEsc0JBQ0NnRSxRQUNDLHVCQUFDLFVBQUssV0FBVSxvRkFBbUYsbUJBQW5HO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUEsSUFDRUMsUUFDRix1QkFBQyxVQUFLLFdBQVUsK0VBQ2JKO0FBQUFBO0FBQUFBLHdCQUFRO0FBQUEsMkJBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQSxJQUVBLHVCQUFDLFVBQUssV0FBVSwyRUFDYkE7QUFBQUE7QUFBQUEsd0JBQVE7QUFBQSwyQkFEWDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEseUJBdkJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBeUJBO0FBQUEsb0JBQ0EsdUJBQUMsU0FBSSxXQUFVLGdDQUNiLGlDQUFDLFVBQUssV0FBVSx5QkFBd0I7QUFBQTtBQUFBLHNCQUNoQztBQUFBLHNCQUNOLHVCQUFDLFVBQUssV0FBVSw2QkFDYnZCLHFCQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSx5QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFPQTtBQUFBLG9CQUNBLHVCQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLDZDQUFDLFVBQUssV0FBVSx5QkFBd0I7QUFBQTtBQUFBLHdCQUM5QjtBQUFBLHdCQUNSLHVCQUFDLFVBQUssV0FBVSw2QkFDYmpJLG9CQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSwyQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUtBO0FBQUEsc0JBQ0EsdUJBQUMsVUFBSyxXQUFVLHlCQUNiK0gsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLHlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBVUE7QUFBQSx1QkE3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkE4Q0E7QUFBQSxrQkFFQSx1QkFBQyxTQUFJLFdBQVUsK0NBQ2I7QUFBQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLG9EQUFvRHdCLGFBQzNELDJCQUNBNUUsV0FBV2tGLHNCQUNYLGFBQ0UsZ0NBQ0EsK0JBQStCO0FBQUEsd0JBR3BDTix1QkFDRyxhQUNBNUUsV0FBV2tGLHNCQUFzQixhQUMvQixhQUNBO0FBQUE7QUFBQSxzQkFiUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBY0E7QUFBQSxvQkFDQTtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxXQUFXLFdBQVdOLGFBQWEsa0JBQWtCLHlDQUF5QztBQUFBO0FBQUEsc0JBRGhHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFDbUc7QUFBQSx1QkFqQnJHO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBbUJBO0FBQUEscUJBN0VGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBOEVBO0FBQUE7QUFBQSxjQXJGSzVFLFdBQVd4QyxPQUFPRDtBQUFBQSxjQUR6QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBdUZBO0FBQUEsVUFFSixDQUFDLEtBakhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0hBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFVO0FBQUEsZ0JBQ1YsTUFBSztBQUFBLGdCQUNMLFFBQU87QUFBQSxnQkFDUCxTQUFRO0FBQUEsZ0JBRVI7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsZUFBYztBQUFBLG9CQUNkLGdCQUFlO0FBQUEsb0JBQ2YsYUFBWTtBQUFBLG9CQUNaLEdBQUU7QUFBQTtBQUFBLGtCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJK007QUFBQTtBQUFBLGNBVmpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVlBO0FBQUEsWUFDQSx1QkFBQyxPQUFFLFdBQVUsbUNBQWtDLHFDQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFvRTtBQUFBLFlBQ3BFLHVCQUFDLE9BQUUsV0FBVSw0QkFBMkIsbUVBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQTJGO0FBQUEsZUFmN0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkEsSUFFQS9HLGNBQWM7QUFBQTtBQUFBLFlBRWhCcUIsZUFBZXNGLFNBQVMsSUFDdEIsdUJBQUMsU0FBSSxXQUFVLE9BQ2IsaUNBQUMsU0FBSSxXQUFVLG1CQUNiLGlDQUFDLFdBQU0sV0FBVSwwQkFDZjtBQUFBLHFDQUFDLFdBQ0MsaUNBQUMsUUFBRyxXQUFVLDRCQUNaO0FBQUEsdUNBQUMsUUFBRyxXQUFVLDBEQUF5RCx3QkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBK0U7QUFBQSxnQkFDL0UsdUJBQUMsUUFBRyxXQUFVLDBEQUF5RCxzQkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkU7QUFBQSxnQkFDN0UsdUJBQUMsUUFBRyxXQUFVLDBEQUF5RCxzQkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNkU7QUFBQSxnQkFDN0UsdUJBQUMsUUFBRyxXQUFVLDBEQUF5RCxvQkFBdkU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkU7QUFBQSxtQkFKN0U7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUNBLHVCQUFDLFdBQ0V0Rix5QkFBZXdGO0FBQUFBLGdCQUFJLENBQUM4SCxTQUNuQix1QkFBQyxRQUFrQixXQUFVLG9CQUMzQjtBQUFBLHlDQUFDLFFBQUcsV0FBVSxvQ0FDWEEsZUFBSy9KLFNBQVN3QyxhQUFhdUgsS0FBSy9KLFNBQVN1QyxRQUFRLFNBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsb0NBQ1h3SCxlQUFLOUosVUFBVSxTQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG9DQUFtQztBQUFBO0FBQUEsb0JBQzdDeUMsU0FBU3FILEtBQUtwSCxVQUFVLENBQUMsRUFBRXFILGVBQWUsT0FBTztBQUFBLHVCQURyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG9DQUNYRCxlQUFLRSxXQUFXLElBQUk1RixLQUFLMEYsS0FBS0UsUUFBUSxFQUFFQyxtQkFBbUIsSUFBSSxTQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEscUJBWk9ILEtBQUszSCxLQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYUE7QUFBQSxjQUNELEtBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBa0JBO0FBQUEsaUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBLEtBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOEJBLEtBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0NBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHNFQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLE1BQUs7QUFBQSxrQkFDTCxRQUFPO0FBQUEsa0JBQ1AsU0FBUTtBQUFBLGtCQUVSO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLGVBQWM7QUFBQSxzQkFDZCxnQkFBZTtBQUFBLHNCQUNmLGFBQVk7QUFBQSxzQkFDWixHQUFFO0FBQUE7QUFBQSxvQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBSXFLO0FBQUE7QUFBQSxnQkFWdks7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSxtQ0FBa0Msd0NBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXVFO0FBQUEsY0FDdkUsdUJBQUMsT0FBRSxXQUFVLDRCQUEyQixvRUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNEY7QUFBQSxpQkFmOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxjQUVBLFFBcE1OO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBcU1BO0FBQUEsVUFRQSx1QkFBQyxTQUFJLFdBQVUsaURBQ2IsaUNBQUMsT0FBRSxXQUFVLHlDQUNWaEgsd0JBQWMsZ0JBQ1gsMkRBQ0Esb0NBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTUE7QUFBQTtBQUFBO0FBQUEsTUFqVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBa1RBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV1o7QUFBQUEsUUFDWCxTQUFTLE1BQU1DLG1CQUFtQixLQUFLO0FBQUEsUUFDdkMsT0FBTTtBQUFBLFFBRU4saUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1Qyw0QkFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVTZNLGNBQWMsWUFBVSxNQUU1RDtBQUFBLG1DQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyxxQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPNU0sb0JBQW9CMk07QUFBQUEsb0JBQzNCO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUl1STtBQUFBLG1CQVJ6STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MscUJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBTzNNLG9CQUFvQnFGLFVBQVU4STtBQUFBQSxvQkFDckM7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSXVJO0FBQUEsbUJBUnpJO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxpQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkE7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSwyQ0FDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQywyQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPbk8sb0JBQW9CcUYsVUFBVStEO0FBQUFBLG9CQUNyQztBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJdUk7QUFBQSxnQkFFdkksdUJBQUMsVUFBSyxXQUFVLHdDQUNidk07QUFBQUEsa0JBQ0NtRCxvQkFBb0JxRixVQUFVK0QsZUFBZTtBQUFBLGdCQUMvQyxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsaUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBT3BKLG9CQUFvQnFGLFVBQVUyRztBQUFBQSxvQkFDckM7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSXVJO0FBQUEsZ0JBRXZJLHVCQUFDLFVBQUssV0FBVSx3Q0FDYm5QO0FBQUFBLGtCQUNDbUQsb0JBQW9CcUYsVUFBVTJHLGlCQUFpQjtBQUFBLGdCQUNqRCxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxtQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUEsaUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUNBO0FBQUEsWUFHQ2hNLG9CQUFvQnFGLFVBQVVhLGVBQWUsWUFDNUMsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FDRWxHLG9CQUFvQm1HLGFBQ2pCZ0MsT0FBTyxDQUFDLEVBQ1JDLFlBQVksSUFDZnBJLG9CQUFvQm1HLGFBQWFrQyxNQUFNLENBQUMsSUFDeEM7QUFBQSxrQkFFRjtBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQVZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVV1STtBQUFBLGlCQWR6STtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFlBSUYsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLHdCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE9BQU9ySSxvQkFBb0JzRixTQUFTd0M7QUFBQUEsb0JBQ3BDO0FBQUEsb0JBQ0EsV0FBVTtBQUFBO0FBQUEsa0JBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUl1STtBQUFBLG1CQVJ6STtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVVBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0Msc0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBTzlILG9CQUFvQnVGO0FBQUFBLG9CQUMzQjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJdUk7QUFBQSxtQkFSekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFVQTtBQUFBLGlCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVCQTtBQUFBLFlBR0EsdUJBQUMsU0FDQztBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUNFdkYsb0JBQW9CcUYsVUFBVStELGNBQzlCcEosb0JBQW9CMEY7QUFBQUEsa0JBRXRCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBO0FBQUEsZ0JBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT3VJO0FBQUEsY0FFdkksdUJBQUMsVUFBSyxXQUFVLHdDQUNiN0k7QUFBQUEsZ0JBQ0NtRCxvQkFBb0JxRixVQUFVK0QsY0FDOUJwSixvQkFBb0IwRixjQUFjO0FBQUEsY0FDcEMsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsaUJBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbUJBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsMEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBTzFGLG9CQUFvQnlGO0FBQUFBLG9CQUMzQjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJdUk7QUFBQSxnQkFFdkksdUJBQUMsVUFBSyxXQUFVLHdDQUNiNUksOEJBQW9CbUQsb0JBQW9CeUYsY0FBYyxDQUFDLEtBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsOEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBT3pGLG9CQUFvQjBGO0FBQUFBLG9CQUMzQjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJdUk7QUFBQSxnQkFFdkksdUJBQUMsVUFBSyxXQUFVLHdDQUNiN0ksOEJBQW9CbUQsb0JBQW9CMEYsY0FBYyxDQUFDLEtBRDFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsaUJBNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNkJBO0FBQUEsWUFHQSx1QkFBQyxTQUFJLFdBQVUsMkNBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0Msd0JBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBTzFGLG9CQUFvQjJGO0FBQUFBLG9CQUMzQjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJdUk7QUFBQSxnQkFFdkksdUJBQUMsVUFBSyxXQUFVLHdDQUNiOUksOEJBQW9CbUQsb0JBQW9CMkYsWUFBWSxDQUFDLEtBRHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWFBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsaUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBTzNGLG9CQUFvQjRGO0FBQUFBLG9CQUMzQjtBQUFBLG9CQUNBLFdBQVU7QUFBQTtBQUFBLGtCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFJdUk7QUFBQSxnQkFFdkksdUJBQUMsVUFBSyxXQUFVLHdDQUNiL0k7QUFBQUEsa0JBQ0NtRCxvQkFBb0I0RixpQkFBaUI7QUFBQSxnQkFDdkMsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUlBO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGlCQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQStCQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsT0FBTzVGLG9CQUFvQjZGO0FBQUFBLGtCQUMzQjtBQUFBLGtCQUNBLFdBQVU7QUFBQTtBQUFBLGdCQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUl1STtBQUFBLGNBRXZJLHVCQUFDLFVBQUssV0FBVSx3Q0FDYmhKLDhCQUFvQm1ELG9CQUFvQjZGLFdBQVcsQ0FBQyxLQUR2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFhQTtBQUFBLFlBR0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxrQkFDakQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPUSxnQkFBZ0JQLGNBQWM4QixNQUFNLEdBQUcsRUFBRSxDQUFDLEtBQUs7QUFBQSxvQkFDdEQsVUFBVTZFO0FBQUFBLG9CQUNWLFdBQVU7QUFBQTtBQUFBLGtCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLdUk7QUFBQSxtQkFUekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxrQkFDakQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFnQztBQUFBLHFCQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPcEcsZ0JBQWdCTixnQkFBZ0I7QUFBQSxvQkFDdkMsVUFBVTBHO0FBQUFBLG9CQUNWLFdBQVU7QUFBQTtBQUFBLGtCQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLdUk7QUFBQSxtQkFUekk7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGlCQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXlCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLDJDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxrQkFDNUMsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQSxxQkFEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT3BHLGdCQUFnQkwsV0FBVzRCLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUFBLG9CQUNuRCxVQUFVNkU7QUFBQUEsb0JBQ1YsV0FBVTtBQUFBO0FBQUEsa0JBTFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUt1STtBQUFBLGdCQUV0SXJNLE9BQU80RixhQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjVGLGlCQUFPNEYsYUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFnQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsa0JBQzVDLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWlDO0FBQUEscUJBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9LLGVBQWVKO0FBQUFBLG9CQUN0QixVQUFVd0c7QUFBQUEsb0JBQ1Y7QUFBQSxvQkFDQSxXQUFVO0FBQUE7QUFBQSxrQkFOWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTXVJO0FBQUEsZ0JBRXRJck0sT0FBTzZGLHFCQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFDVjdGLGlCQUFPNkYscUJBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsaUJBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0NBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUFpTDtBQUFBO0FBQUEsY0FGN0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU9BO0FBQUEsZUE3UkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4UkE7QUFBQSxhQWxTRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbVNBO0FBQUE7QUFBQSxNQXhTRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF5U0E7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXdkc7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsNkJBQW1CLEtBQUs7QUFDeEJFLDBCQUFnQixJQUFJO0FBQUEsUUFDdEI7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsa0RBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDRCxnQkFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsVUFBVSxDQUFDOEUsTUFBTTtBQUNmQSxrQkFBRXdILGVBQWU7QUFDakJLLG9DQUFvQjtBQUFBLGNBQ3RCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsV0FBVTtBQUFBLGtCQUEwSjtBQUFBO0FBQUEsZ0JBRnRLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUE7QUFBQSxZQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWFBO0FBQUEsYUFsQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9CQTtBQUFBO0FBQUEsTUEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNEJBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3RMO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLGtDQUF3QixLQUFLO0FBQzdCRSw2QkFBbUIsRUFBRTtBQUFBLFFBQ3ZCO0FBQUEsUUFDQSxPQUFNO0FBQUEsUUFFTixpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsUUFBRyxXQUFVLG1DQUFrQztBQUFBO0FBQUEsWUFDeEI7QUFBQSxZQUNyQkQsaUJBQWlCNkgsT0FBT21GLGNBQWM7QUFBQSxlQUZ6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUdBLEtBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFLQTtBQUFBLFVBR0NoTixpQkFBaUI2SCxTQUNoQix1QkFBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsb0RBQ2I7QUFBQSxxQ0FBQyxPQUFFLFdBQVUscUNBQW9DLDBCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsbUNBQ1Y3SCwwQkFBZ0I2SCxNQUFNbUYsY0FEekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxZQUNBLHVCQUFDLFNBQUksV0FBVSxzREFDYjtBQUFBLHFDQUFDLE9BQUUsV0FBVSxzQ0FBcUMsMkJBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLE9BQUUsV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLGdCQUMzQ3RSLG9CQUFvQnNFLGdCQUFnQjZILE1BQU1JLFdBQVc7QUFBQSxtQkFEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBT0E7QUFBQSxlQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWlCQTtBQUFBLFVBR0QvSCxxQkFDQyx1QkFBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsa0JBQWUsV0FBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQyxLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLElBQ0VGLGlCQUFpQnNPLFNBQVN0TyxnQkFBZ0JzTyxNQUFNcEksU0FBUyxJQUMzRCx1QkFBQyxTQUFJLFdBQVUsaURBQ2IsaUNBQUMsV0FBTSxXQUFVLHVDQUNmO0FBQUEsbUNBQUMsV0FBTSxXQUFVLDJCQUNmLGlDQUFDLFFBQ0M7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsa0ZBQWlGLHFCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLDZCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLDRCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLHNCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLGdDQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLDJCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFHLFdBQVUsa0ZBQWlGLHVCQUEvRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUJBLEtBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkJBO0FBQUEsWUFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ2RsRywwQkFBZ0JzTyxNQUFNbEk7QUFBQUEsY0FBSSxDQUFDeUYsTUFBTXZGLFVBQ2hDLHVCQUFDLFFBQWUsV0FBVSxvQkFDeEI7QUFBQSx1Q0FBQyxRQUFHLFdBQVUscURBQ1hBLGtCQUFRLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUcsV0FBVSxpRUFDWHVGO0FBQUFBLHVCQUFLQSxNQUFNbkYsUUFBUTtBQUFBLGtCQUNuQixDQUFDbUYsS0FBS0EsTUFBTW5GLFFBQ1htRixLQUFLQSxNQUFNbkYsU0FBUyxrQkFDbEIsdUJBQUMsVUFBSyxXQUFVLGdDQUErQix5QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQU5OO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUscURBQ1htRixlQUFLQSxNQUFNTSxTQUFTLFNBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUscURBQ1hOLGVBQUt6SCxVQUFVLFNBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUscURBQW9EO0FBQUE7QUFBQSxtQkFDN0R5SCxLQUFLMEMsUUFBUUMsZUFBZSxHQUFHTCxlQUFlO0FBQUEscUJBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsa0VBQWlFO0FBQUE7QUFBQSxtQkFDMUV0QyxLQUFLMEMsUUFBUUUsUUFBUSxHQUFHTixlQUFlO0FBQUEscUJBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUsbURBQ1o7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsWUFDR3RDLEtBQUswQyxRQUFRRyxXQUFXLEtBQUssSUFDMUIsaUJBQ0E7QUFBQSxvQkFDTDtBQUFBO0FBQUEsdUJBRUU3QyxLQUFLMEMsUUFBUUcsV0FBVyxHQUFHUCxlQUFlO0FBQUE7QUFBQTtBQUFBLGtCQVAvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVVBO0FBQUEsbUJBbkNPN0gsT0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFEQTtBQUFBLFlBQ0QsS0F4REg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5REE7QUFBQSxlQXRGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVGQSxLQXhGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlGQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxRQUFPO0FBQUEsZ0JBQ1AsU0FBUTtBQUFBLGdCQUVSO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLGVBQWM7QUFBQSxvQkFDZCxnQkFBZTtBQUFBLG9CQUNmLGFBQVk7QUFBQSxvQkFDWixHQUFFO0FBQUE7QUFBQSxrQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSXlNO0FBQUE7QUFBQSxjQVYzTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDBDQUF5Qyw2QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2Qiw2Q0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsYUFsSko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQW9KQTtBQUFBO0FBQUEsTUE1SkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNkpBO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV2xGO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLG9DQUEwQixLQUFLO0FBQy9CRiwrQkFBcUIsRUFBRTtBQUN2QkYsMkJBQWlCLEtBQUs7QUFBQSxRQUN4QjtBQUFBLFFBQ0EsT0FBTTtBQUFBLFFBRU4saUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFFBQUcsV0FBVSxtQ0FBa0M7QUFBQTtBQUFBLFlBQzVCdEQsV0FBV3FQLGNBQWM7QUFBQSxlQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJQTtBQUFBLFVBRUMxTCx1QkFDQyx1QkFBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsa0JBQWUsV0FBVyxRQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnQyxLQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBLElBQ0VKLG1CQUFtQnVFLE9BQ3JCLHVCQUFDLFNBQUksV0FBVSxhQUViO0FBQUEsbUNBQUMsU0FBSSxXQUFVLHlDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLG9EQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHFDQUFvQyw4QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSxvQ0FDVnZFLDRCQUFrQnVFLEtBQUtrSixTQUFTQyxpQkFBaUIsS0FEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0E7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxzREFDYjtBQUFBLHVDQUFDLE9BQUUsV0FBVSxzQ0FBcUMsK0JBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsb0NBQ1YxTiw0QkFBa0J1RSxLQUFLa0osU0FBU0Usa0JBQWtCLEtBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsd0RBQ2I7QUFBQSx1Q0FBQyxPQUFFLFdBQVUsdUNBQXNDLDZCQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsT0FBRSxXQUFVLG9DQUNWM04sNEJBQWtCdUUsS0FBS2tKLFNBQVNHLGdCQUFnQixLQURuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHVDQUFzQyw2QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLHlDQUFDLFVBQUssV0FBVSwwQkFBeUI7QUFBQTtBQUFBLG9CQUMvQjtBQUFBLG9CQUNQNU4sa0JBQWtCdUUsS0FBS2tKLFNBQVNJLGNBQWM7QUFBQSx1QkFGakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLGtCQUNBLHVCQUFDLFVBQUssV0FBVSx3QkFBdUI7QUFBQTtBQUFBLG9CQUMzQjtBQUFBLG9CQUNUN04sa0JBQWtCdUUsS0FBS2tKLFNBQVNLLGVBQWU7QUFBQSx1QkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFHQTtBQUFBLHFCQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBU0E7QUFBQSxtQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWNBO0FBQUEsaUJBdkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0NBO0FBQUEsWUFHQzlOLGtCQUFrQnVFLEtBQUt3SixlQUN0Qi9OLGtCQUFrQnVFLEtBQUt3SixZQUFZL0ksU0FBUyxLQUMxQyx1QkFBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLG9FQUNaO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHVDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUFPO0FBQUEsZ0JBRTFEaEYsa0JBQWtCdUUsS0FBS3dKLFlBQVkvSTtBQUFBQSxnQkFBTztBQUFBLG1CQUg3QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2IsaUNBQUMsV0FBTSxXQUFVLHVDQUNmO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDRCQUNmLGlDQUFDLFFBQ0M7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsb0VBQW1FLHFCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG9FQUFtRSx5QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxvRUFBbUUsNEJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsb0VBQW1FLDZCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG9FQUFtRSxzQkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsZ0JBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNkaEYsNEJBQWtCdUUsS0FBS3dKLFlBQVk3STtBQUFBQSxrQkFDbEMsQ0FBQ3lGLE1BQU1xRCxRQUNMLHVCQUFDLFFBQWEsV0FBVSxvQkFDdEI7QUFBQSwyQ0FBQyxRQUFHLFdBQVUsbUNBQ1hBLGdCQUFNLEtBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSwrQ0FDWHJELGVBQUtsRixhQUFhLFNBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsbUNBQ1hrRixlQUFLakYsZ0JBQWdCLFNBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsbUNBQ1hpRixlQUFLekgsVUFBVSxTQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGFBQ1osaUNBQUMsVUFBSyxXQUFVLDRFQUEyRSxzQkFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSUE7QUFBQSx1QkFqQk84SyxLQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBa0JBO0FBQUEsZ0JBRUosS0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkF3QkE7QUFBQSxtQkE1Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE2Q0EsS0E5Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkErQ0E7QUFBQSxpQkFyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFzREE7QUFBQSxZQUlIaE8sa0JBQWtCdUUsS0FBSzBKLGtCQUN0QmpPLGtCQUFrQnVFLEtBQUswSixlQUFlakosU0FBUyxLQUM3Qyx1QkFBQyxTQUNDO0FBQUEscUNBQUMsUUFBRyxXQUFVLG9FQUNaO0FBQUEsdUNBQUMsVUFBSyxXQUFVLHFDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFrRDtBQUFBLGdCQUFPO0FBQUEsZ0JBRXhEaEYsa0JBQWtCdUUsS0FBSzBKLGVBQWVqSjtBQUFBQSxnQkFBTztBQUFBLG1CQUhoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsY0FDQSx1QkFBQyxTQUFJLFdBQVUsbUVBQ2IsaUNBQUMsV0FBTSxXQUFVLHVDQUNmO0FBQUEsdUNBQUMsV0FBTSxXQUFVLDBCQUNmLGlDQUFDLFFBQ0M7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsa0VBQWlFLHFCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGtFQUFpRSx5QkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxrRUFBaUUsNEJBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsa0VBQWlFLDZCQUEvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLGtFQUFpRSw0QkFBL0U7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxrRUFBaUUsc0JBQS9FO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFtQkEsS0FwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFxQkE7QUFBQSxnQkFDQSx1QkFBQyxXQUFNLFdBQVUscUNBQ2RoRiw0QkFBa0J1RSxLQUFLMEosZUFBZS9JO0FBQUFBLGtCQUNyQyxDQUFDeUYsTUFBTXFELFFBQ0wsdUJBQUMsUUFBYSxXQUFVLG9CQUN0QjtBQUFBLDJDQUFDLFFBQUcsV0FBVSxtQ0FDWEEsZ0JBQU0sS0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsUUFBRyxXQUFVLCtDQUNYckQsZUFBS2xGLGFBQWEsU0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSxtQ0FDWGtGLGVBQUtqRixnQkFBZ0IsU0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNBLHVCQUFDLFFBQUcsV0FBVSxtQ0FDWGlGLGVBQUt6SCxVQUFVLFNBRGxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsbUNBQ1h5SCxlQUFLNUgsZ0JBQWdCLE9BRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxvQkFDQSx1QkFBQyxRQUFHLFdBQVUsYUFDWixpQ0FBQyxVQUFLLFdBQVUsd0VBQXVFLDBCQUF2RjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFJQTtBQUFBLHVCQXBCT2lMLEtBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFxQkE7QUFBQSxnQkFFSixLQTFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTJCQTtBQUFBLG1CQWxERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW1EQSxLQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXFEQTtBQUFBLGlCQTNERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTREQTtBQUFBLGFBSUYsQ0FBQ2hPLGtCQUFrQnVFLEtBQUt3SixlQUN4Qi9OLGtCQUFrQnVFLEtBQUt3SixZQUFZL0ksV0FBVyxPQUM3QyxDQUFDaEYsa0JBQWtCdUUsS0FBSzBKLGtCQUN2QmpPLGtCQUFrQnVFLEtBQUswSixlQUFlakosV0FBVyxNQUNqRCx1QkFBQyxTQUFJLFdBQVUsb0JBQ2IsaUNBQUMsT0FBRSxXQUFVLGlCQUFnQixzREFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQW5MTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFMQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxRQUFPO0FBQUEsZ0JBQ1AsU0FBUTtBQUFBLGdCQUVSO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLGVBQWM7QUFBQSxvQkFDZCxnQkFBZTtBQUFBLG9CQUNmLGFBQVk7QUFBQSxvQkFDWixHQUFFO0FBQUE7QUFBQSxrQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSTBNO0FBQUE7QUFBQSxjQVY1TTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDBDQUF5Qyw2QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QixtREFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsYUF2Tko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlOQTtBQUFBO0FBQUEsTUFsT0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBbU9BO0FBQUEsSUFHQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVzFFO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCRSx3QkFBYyxFQUFFO0FBQUEsUUFDbEI7QUFBQSxRQUNBLE9BQU07QUFBQSxRQUVOLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxRQUFHLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSxZQUN4QmhFLFdBQVdxUCxjQUFjO0FBQUEsZUFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSUE7QUFBQSxVQUVDcEwsZ0JBQ0MsdUJBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLGtCQUFlLFdBQVcsUUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBZ0MsS0FEbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQSxJQUNFRixjQUFjQSxXQUFXd0UsU0FBUyxJQUNwQyx1QkFBQyxTQUVDO0FBQUEsbUNBQUMsU0FBSSxXQUFVLDhDQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHVDQUFzQyw2QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSxvQ0FDVnhFLHFCQUFXd0UsVUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHNEQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHNDQUFxQyw0QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSxvQ0FBbUM7QUFBQTtBQUFBLGtCQUU3Q3hFLFdBQ0UwTjtBQUFBQSxvQkFDQyxDQUFDQyxLQUFLbkIsU0FBU21CLE9BQU94SSxTQUFTcUgsS0FBS3BILE1BQU0sS0FBSztBQUFBLG9CQUMvQztBQUFBLGtCQUNGLEVBQ0NxSCxlQUFlLE9BQU87QUFBQSxxQkFQM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFRQTtBQUFBLG1CQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxvREFDYjtBQUFBLHVDQUFDLE9BQUUsV0FBVSxxQ0FBb0MsOEJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsb0NBRVR6TSxxQkFBV2tLO0FBQUFBLGtCQUNULENBQUNzQyxTQUFTQSxLQUFLb0IsYUFBYTtBQUFBLGdCQUM5QixFQUFFcEosVUFKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU1BO0FBQUEsbUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLHVDQUFzQyw0QkFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLE9BQUUsV0FBVSxvQ0FFVHhFLHFCQUFXa0ssT0FBTyxDQUFDc0MsU0FBU0EsS0FBS29CLGFBQWEsTUFBTSxFQUNqRHBKLFVBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFLQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQSxpQkE3Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE4Q0E7QUFBQSxZQUdBLHVCQUFDLFNBQUksV0FBVSxtRUFDYixpQ0FBQyxXQUFNLFdBQVUsdUNBQ2Y7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsNkJBQ2YsaUNBQUMsUUFDQztBQUFBLHVDQUFDLFFBQUcsV0FBVSxxRUFBb0UscUJBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUscUVBQW9FLDZCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHFFQUFvRSw0QkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUcsV0FBVSxxRUFBb0Usc0JBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUscUVBQW9FLHNCQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHFFQUFvRSx3QkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUcsV0FBVSxxRUFBb0Usd0JBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxRQUFHLFdBQVUscUVBQW9FLGlDQUFsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0EsdUJBQUMsUUFBRyxXQUFVLHFFQUFvRSwwQkFBbEY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTRCQSxLQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQThCQTtBQUFBLGNBQ0EsdUJBQUMsV0FBTSxXQUFVLHFDQUNkeEUscUJBQVcwRTtBQUFBQSxnQkFBSSxDQUFDbUosUUFBUUwsUUFDdkIsdUJBQUMsUUFBb0IsV0FBVSxvQkFDN0I7QUFBQSx5Q0FBQyxRQUFHLFdBQVUsbUNBQ1hBLGdCQUFNLEtBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSwrQ0FDWEssaUJBQU81SSxhQUFhLFNBRHZCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsbUNBQ1g0SSxpQkFBTzNJLGdCQUFnQixTQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUVBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG1DQUNYMkksaUJBQU9uTCxVQUFVLFNBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxxQkFFM0R5QyxTQUFTMEksT0FBT3pJLE1BQU0sS0FBSyxHQUFHcUg7QUFBQUEsc0JBQzlCO0FBQUEsb0JBQ0Y7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUtBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBRyxXQUFVLG1DQUNYb0IsaUJBQU9uQixXQUNKLElBQUk1RixLQUFLK0csT0FBT25CLFFBQVEsRUFBRUMsbUJBQW1CLElBQzdDLFNBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFJQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxhQUNaO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLFdBQVcsZ0RBQWdEa0IsT0FBT0QsYUFBYSxXQUMzRSw4QkFDQSwrQkFBK0I7QUFBQSxzQkFHbENDLGlCQUFPRCxZQUFZO0FBQUE7QUFBQSxvQkFOdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFTQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUcsV0FBVSxxQkFDWixpQ0FBQyxZQUFPLFdBQVUsNEdBQ2ZDLGlCQUFPQyxxQkFBcUIsU0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFHLFdBQVUsbUNBQ1hELGlCQUFPRSxjQUFjLFNBRHhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkF6Q09GLE9BQU9oSixLQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTBDQTtBQUFBLGNBQ0QsS0E3Q0g7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE4Q0E7QUFBQSxpQkE5RUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkErRUEsS0FoRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFpRkE7QUFBQSxlQXBJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXFJQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxxQkFDYjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsV0FBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxRQUFPO0FBQUEsZ0JBQ1AsU0FBUTtBQUFBLGdCQUVSO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLGVBQWM7QUFBQSxvQkFDZCxnQkFBZTtBQUFBLG9CQUNmLGFBQVk7QUFBQSxvQkFDWixHQUFFO0FBQUE7QUFBQSxrQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSXFLO0FBQUE7QUFBQSxjQVZ2SztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFZQTtBQUFBLFlBQ0EsdUJBQUMsUUFBRyxXQUFVLDBDQUF5Qyw2QkFBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDhCQUE2QiwrREFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLGVBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBb0JBO0FBQUEsYUF2S0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXlLQTtBQUFBO0FBQUEsTUFqTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBa0xBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsaUNBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUNBQ2IsaUNBQUMsU0FBSSxXQUFVLHlCQUF3QixjQUFXLFFBQ2hEO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTWxFLGFBQWEsVUFBVTtBQUFBLFlBQ3RDLFdBQVcsR0FBR0QsY0FBYyxhQUN4QixrQ0FDQSw0RUFBNEU7QUFBQSxZQUNoQjtBQUFBO0FBQUEsVUFMbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1DLGFBQWEsWUFBWTtBQUFBLFlBQ3hDLFdBQVcsR0FBR0QsY0FBYyxlQUN4QixrQ0FDQSw0RUFBNEU7QUFBQSxZQUNoQjtBQUFBO0FBQUEsVUFMbEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUUE7QUFBQSxXQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBbUJBLEtBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkE7QUFBQSxNQUdBLHVCQUFDLFFBQUcsV0FBVSwwQkFDWEEsd0JBQWMsYUFBYSxhQUFhLHlCQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxhQUNaQSx3QkFBYztBQUFBO0FBQUEsUUFFYixtQ0FDRTtBQUFBLGlDQUFDLFNBQUksV0FBVSxTQUNiO0FBQUEsbUNBQUMsV0FBTSxzQ0FBUDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUE2QjtBQUFBLFlBQzdCLHVCQUFDLFNBQUksV0FBVSw0Q0FFYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE9BQ0UvRSwyQkFBMkIsV0FDdkIsV0FDQUEsMEJBQTBCK1A7QUFBQUEsa0JBRWhDLFVBQVV4RDtBQUFBQSxrQkFDVix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBQ1YsY0FBYyxDQUFDeUQsT0FBT0MsV0FBVztBQUMvQix3QkFBSUEsT0FBTzlKLFVBQVUsVUFBVTtBQUM3Qiw2QkFBTyxrQkFDSndJLFlBQVksRUFDWk8sU0FBU2MsTUFBTXJCLFlBQVksQ0FBQztBQUFBLG9CQUNqQztBQUNBLDJCQUFPc0IsT0FBT0MsVUFDVnJCLFNBQVMsRUFDVkYsWUFBWSxFQUNaTyxTQUFTYyxNQUFNckIsWUFBWSxDQUFDO0FBQUEsa0JBQ2pDO0FBQUEsa0JBQ0EsYUFBWTtBQUFBLGtCQUVaO0FBQUEsMkNBQUMsT0FBTyxRQUFQLEVBQTJCLE9BQU0sVUFBUywrQkFBeEIsVUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLG9CQUNDclAsT0FBT3lKO0FBQUFBLHNCQUFJLENBQUN5QixVQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNdEIsS0FDekNzQixnQkFBTW1GLGNBRFduRixNQUFNdEIsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQTtBQUFBLGdCQTlCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0ErQkE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTTtBQUNiekksaUNBQWEsSUFBSTtBQUNqQm9CLDhCQUFVLENBQUMsQ0FBQztBQUFBLGtCQUNkO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUFtRztBQUFBO0FBQUEsZ0JBTC9HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsaUJBMUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkNBO0FBQUEsWUFFQzdCLDBCQUNDQSwyQkFBMkIsWUFDM0JJLGdCQUFnQixDQUFDLEdBQUd5RyxVQUFVOEksY0FDNUIsdUJBQUMsT0FBRSxXQUFVLGtHQUNYO0FBQUEscUNBQUMsVUFBSyxXQUFVLHVDQUFzQyx1QkFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkQ7QUFBQSxjQUM3RCx1QkFBQyxVQUFLLFdBQVUsbUNBQWtDO0FBQUE7QUFBQSxnQkFDOUMwQyxPQUFPM1EsT0FBTytILFVBQVUsQ0FBQyxFQUFFcUgsZUFBZSxPQUFPO0FBQUEsbUJBRHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsZUF2RE47QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF5REE7QUFBQSxVQUVBLHVCQUFDLFNBQ0U5UTtBQUFBQSx1Q0FBMkIsWUFDMUIsdUJBQUMsU0FBSSxXQUFVLFFBQ2I7QUFBQSxxQ0FBQyxRQUFHLFdBQVUsdUVBQXNFLCtCQUFwRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxPQUFFLFdBQVUsOEJBQTZCLDJEQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsaUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFPQTtBQUFBLFlBR0YsdUJBQUMsU0FDRSxXQUFDWixVQUFVQyxTQUNWLHVCQUFDLFNBQUksV0FBVSxpQ0FBZ0Msc0NBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXFFLElBQ25FeUMsYUFBYXFCLGdCQUNmLHVCQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxrQkFBZSxXQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsSUFDRTNELGVBQWVxSixTQUFTLElBQzFCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBRUMsZUFBZW1FO0FBQUFBLGdCQUNmLE1BQU05TyxhQUFhc0IsZUFBZXdDLFVBQVU7QUFBQSxnQkFDNUMsU0FBU2hDLDJCQUEyQixXQUFXcU4sd0JBQXdCSDtBQUFBQSxnQkFDdkUsa0JBQ0VsTiwyQkFBMkIsV0FBVyx3QkFBd0I7QUFBQTtBQUFBLGNBTDNEQTtBQUFBQSxjQURQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFPRyxJQUVEb0MsYUFDRix1QkFBQyxTQUFJLFdBQVUsa0NBQWlDLHFDQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFxRSxJQUNuRSxRQW5CTjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLGVBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBaUNBO0FBQUEsYUE3RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQThGQTtBQUFBO0FBQUE7QUFBQSxRQUdBLG1DQUNFO0FBQUEsaUNBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSxtQ0FBQyxXQUFNLHdDQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStCO0FBQUEsWUFDL0IsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsT0FBTytDLDZCQUE2QjRLO0FBQUFBLGtCQUNwQyxVQUFVakc7QUFBQUEsa0JBQ1YsdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUNWLGNBQWMsQ0FBQ2tHLE9BQU9DLFdBQ3BCQSxPQUFPQyxVQUFVckIsU0FBUyxFQUFFRixZQUFZLEVBQUVPLFNBQVNjLE1BQU1yQixZQUFZLENBQUM7QUFBQSxrQkFFeEUsYUFBWTtBQUFBLGtCQUNaLFNBQVNwSixxQkFBcUJOLGlCQUFpQjRELFdBQVc7QUFBQSxrQkFFekQ1RCwyQkFBaUI4RDtBQUFBQSxvQkFBSSxDQUFDeUIsVUFDckIsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU10QixLQUN6Q3NCLGdCQUFNbUYsY0FEV25GLE1BQU10QixLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsa0JBQ0Q7QUFBQTtBQUFBLGdCQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpQkE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVMsTUFBTTtBQUNiekksaUNBQWEsSUFBSTtBQUNqQm9CLDhCQUFVLENBQUMsQ0FBQztBQUFBLGtCQUNkO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUFtRztBQUFBO0FBQUEsZ0JBTC9HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVFBO0FBQUEsaUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNEJBO0FBQUEsZUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErQkE7QUFBQSxVQUVBLHVCQUFDLFNBQ0UsV0FBQ3pDLFVBQVVDLFNBQ1YsdUJBQUMsU0FBSSxXQUFVLGlDQUFnQyxzQ0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBcUUsSUFDbkVrRztBQUFBQTtBQUFBQSxZQUVGLHVCQUFDLFNBQUksV0FBVSwwQ0FDYixpQ0FBQyxrQkFBZSxXQUFXLFFBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWdDLEtBRDBCLFVBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxjQUNFRixvQkFBb0J3RCxTQUFTLElBQy9CO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FFQyxlQUFlbUU7QUFBQUEsY0FDZixNQUFNOU8sYUFBYW1ILHFCQUFxQnJELFVBQVU7QUFBQSxjQUVsRCxTQUFTb0w7QUFBQUEsY0FDVCxrQkFBa0IsY0FBY2pJLDZCQUE2QixRQUFRO0FBQUE7QUFBQSxZQUxoRUE7QUFBQUEsWUFEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTThFLElBRTVFUSwyQkFDRix1QkFBQyxTQUFJLFdBQVUsa0NBQWlDLG9EQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFvRixJQUNsRixRQW5CTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW9CQTtBQUFBLGFBdERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF1REE7QUFBQSxXQTNKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBNkpBO0FBQUEsU0EzTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRMQTtBQUFBLE9BanhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa3hEQSxLQW54REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW94REEsS0FyeERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzeERBO0FBRUo7QUFBRXpHLEdBejZGSUQsU0FBTztBQUFBcVQsS0FBUHJUO0FBMjZGTixlQUFlQTtBQUFRLElBQUFxVDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJTaWRlYmFyIiwiYXBpIiwiTWREZWxldGUiLCJDaUVkaXQiLCJNb2RhbCIsIkJzRXllIiwiQnV0dG9uIiwiRHJvcGRvd24iLCJJbnB1dCIsIlNwaW4iLCJEYXRhVGFibGUiLCJFeWVJY29uIiwiQ3VzdG9tQWxlcnQiLCJOYXZiYXIiLCJTZWxlY3QiLCJUYWciLCJUb29sdGlwIiwiSW9NZE1vcmUiLCJGYVVzZXJDaGVjayIsIkZhQ2hldnJvblJpZ2h0IiwiR2lNb25leVN0YWNrIiwiZmlsdGVyT3B0aW9uIiwiQ2lyY3VsYXJMb2FkZXIiLCJmaWVsZFNpemUiLCJudW1iZXJUb0luZGlhbldvcmRzIiwiWCIsIlNlYXJjaCIsIkZpbGVUZXh0IiwiUGllQ2hhcnQiLCJSZWNlaXB0IiwiTGlzdCIsIkluZm8iLCJVc2VycyIsIkNoZWNrQ2lyY2xlT3V0bGluZWQiLCJDbG9ja0NpcmNsZU91dGxpbmVkIiwiV2FybmluZ091dGxpbmVkIiwiQXVjdGlvbiIsIl9zIiwiaXNPbmxpbmUiLCJuYXZpZ2F0b3IiLCJvbkxpbmUiLCJncm91cHMiLCJzZXRHcm91cHMiLCJUYWJsZUF1Y3Rpb25zIiwic2V0VGFibGVBdWN0aW9ucyIsInNlbGVjdGVkR3JvdXAiLCJzZXRTZWxlY3RlZEdyb3VwIiwic2VsZWN0ZWRBdWN0aW9uR3JvdXAiLCJzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cCIsInNlbGVjdGVkR3JvdXBJZCIsInNldFNlbGVjdGVkR3JvdXBJZCIsInNlbGVjdGVkQXVjdGlvbkdyb3VwSWQiLCJzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkIiwiZmlsdGVyZWRVc2VycyIsInNldEZpbHRlcmVkVXNlcnMiLCJmaWx0ZXJlZEF1Y3Rpb24iLCJzZXRGaWx0ZXJlZEF1Y3Rpb24iLCJncm91cEluZm8iLCJzZXRHcm91cEluZm8iLCJzaG93TW9kYWwiLCJzZXRTaG93TW9kYWwiLCJzaG93QmlkRHJhd2VyIiwic2V0U2hvd0JpZERyYXdlciIsImJpZFJlcXVlc3RzIiwic2V0QmlkUmVxdWVzdHMiLCJiaWREcmF3ZXJTZWFyY2giLCJzZXRCaWREcmF3ZXJTZWFyY2giLCJsb2FkaW5nQmlkUmVxdWVzdHMiLCJzZXRMb2FkaW5nQmlkUmVxdWVzdHMiLCJzaG93TW9kYWxEZWxldGUiLCJzZXRTaG93TW9kYWxEZWxldGUiLCJjdXJyZW50R3JvdXAiLCJzZXRDdXJyZW50R3JvdXAiLCJzaG93TW9kYWxVcGRhdGUiLCJzZXRTaG93TW9kYWxVcGRhdGUiLCJjdXJyZW50VXBkYXRlR3JvdXAiLCJzZXRDdXJyZW50VXBkYXRlR3JvdXAiLCJkb3VibGUiLCJzZXREb3VibGUiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsImRyYXdlclRhYiIsInNldERyYXdlclRhYiIsImhhc0ZldGNoZWQiLCJzZXRIYXNGZXRjaGVkIiwiaGFzTG9hZGVkUmVmIiwidXNlUmVmIiwiaGFzRmV0Y2hlZEdyb3VwcyIsInNob3dUcmFuc2FjdGlvbk1vZGFsIiwic2V0U2hvd1RyYW5zYWN0aW9uTW9kYWwiLCJ0cmFuc2FjdGlvbkRhdGEiLCJzZXRUcmFuc2FjdGlvbkRhdGEiLCJsb2FkaW5nVHJhbnNhY3Rpb24iLCJzZXRMb2FkaW5nVHJhbnNhY3Rpb24iLCJyZWNlbnRBdWN0aW9ucyIsInNldFJlY2VudEF1Y3Rpb25zIiwicnVuUmVjZW50QXVjdGlvbiIsInNldFJ1blJlY2VudEF1Y3Rpb24iLCJsb2FkaW5nUmVjZW50Iiwic2V0TG9hZGluZ1JlY2VudCIsImN1c3RvbWVyT3B0aW9ucyIsInNldEN1c3RvbWVyT3B0aW9ucyIsImFkdmFuY2VQYXlvdXRzIiwic2V0QWR2YW5jZVBheW91dHMiLCJzaG93QWR2YW5jZVBheW91dE1vZGFsIiwic2V0U2hvd0FkdmFuY2VQYXlvdXRNb2RhbCIsIkdyb3VwT3ZlcnZpZXciLCJzZXRHcm91cE92ZXJ2aWV3IiwiR3JvdXBPdmVydmlld0RhdGEiLCJzZXRHcm91cE92ZXJ2aWV3RGF0YSIsInNob3dHcm91cE92ZXJ2aWV3TW9kYWwiLCJzZXRzaG93R3JvdXBPdmVydmlld01vZGFsIiwibG9hZGluZ0dyb3VwT3ZlcnZpZXciLCJzZXRMb2FkaW5nR3JvdXBPdmVydmlldyIsInNob3dQYXlvdXRNb2RhbCIsInNldFNob3dQYXlvdXRNb2RhbCIsInBheW91dERhdGEiLCJzZXRQYXlvdXREYXRhIiwibG9hZGluZ1BheW91dCIsInNldExvYWRpbmdQYXlvdXQiLCJpc0NvbW1lbmNlbWVudERvbmUiLCJzZXRJc0NvbW1lbmNlbWVudERvbmUiLCJsb2FkaW5nIiwic2V0TG9hZGluZyIsImlzU3VibWl0dGluZyIsInNldElzU3VibWl0dGluZyIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsInByZUF1Y3Rpb25Hcm91cHMiLCJzZXRQcmVBdWN0aW9uR3JvdXBzIiwicHJlQXVjdGlvblNlbGVjdGVkR3JvdXBJZCIsInNldFByZUF1Y3Rpb25TZWxlY3RlZEdyb3VwSWQiLCJwcmVBdWN0aW9uVGFibGVEYXRhIiwic2V0UHJlQXVjdGlvblRhYmxlRGF0YSIsInByZUF1Y3Rpb25Mb2FkaW5nIiwic2V0UHJlQXVjdGlvbkxvYWRpbmciLCJwcmVBdWN0aW9uSGFzRmV0Y2hlZEdyb3VwcyIsInNldFByZUF1Y3Rpb25IYXNGZXRjaGVkR3JvdXBzIiwicHJlQXVjdGlvbkhhc0ZldGNoZWREYXRhIiwic2V0UHJlQXVjdGlvbkhhc0ZldGNoZWREYXRhIiwiaXNBdWN0aW9uQ29tcGxldGVkIiwic2V0SXNBdWN0aW9uQ29tcGxldGVkIiwiYXVjdGlvblN0YXR1c0xvYWRpbmciLCJzZXRBdWN0aW9uU3RhdHVzTG9hZGluZyIsIm9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwiYXVjdGlvbl9jb2RlIiwiZ3JvdXBfaWQiLCJ1c2VyX2lkIiwidGlja2V0IiwiYmlkX2Ftb3VudCIsImNvbW1pc3Npb24iLCJ3aW5fYW1vdW50IiwiZGl2aWRlbnQiLCJkaXZpZGVudF9oZWFkIiwicGF5YWJsZSIsImF1Y3Rpb25fZGF0ZSIsImF1Y3Rpb25fdGltZSIsIm5leHRfZGF0ZSIsIm5leHRfYXVjdGlvbl90aW1lIiwiZ3JvdXBfdHlwZSIsImF1Y3Rpb25fdHlwZSIsImJpZF9yZXF1ZXN0X2lkIiwidXBkYXRlRm9ybURhdGEiLCJzZXRVcGRhdGVGb3JtRGF0YSIsInVzZUVmZmVjdCIsImN1cnJlbnQiLCJmZXRjaEdyb3VwcyIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsImZldGNoUHJlQXVjdGlvbkdyb3VwcyIsImZldGNoUHJlQXVjdGlvbkdyb3VwQXVjdGlvbnMiLCJncm91cElkIiwiYXVjdGlvbnMiLCJBcnJheSIsImlzQXJyYXkiLCJsZW5ndGgiLCJmb3JtYXR0ZWQiLCJtYXAiLCJhdWN0aW9uIiwiaW5kZXgiLCJfaWQiLCJpZCIsInNwbGl0IiwibmFtZSIsImZ1bGxfbmFtZSIsInBob25lX251bWJlciIsInBhcnNlSW50IiwiYW1vdW50IiwiYXVjdGlvbl9zdGFnZV90eXBlIiwiY2hhckF0IiwidG9VcHBlckNhc2UiLCJzbGljZSIsImhhbmRsZVByZUF1Y3Rpb25Hcm91cENoYW5nZSIsImZldGNoRG91YmxlIiwibG9hZERlZmF1bHRBdWN0aW9ucyIsImZldGNoUmVjZW50QXVjdGlvbnMiLCJmZXRjaEJpZFJlcXVlc3RzRm9yQXVjdGlvbiIsInN1Y2Nlc3MiLCJzZXRUaW1lb3V0IiwiZmV0Y2hCaWRSZXF1ZXN0cyIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsImdyb3VwIiwiY3VzdG9tZXIiLCJpc05hTiIsInBhcnNlRmxvYXQiLCJncm91cF92YWx1ZSIsIk9iamVjdCIsImtleXMiLCJoYW5kbGVDaGFuZ2UiLCJwcmV2RGF0YSIsInVwZGF0ZWREYXRhIiwibmV4dERhdGUiLCJEYXRlIiwic2V0RGF0ZSIsImdldERhdGUiLCJ0b0lTT1N0cmluZyIsInByZXZFcnJvcnMiLCJoYW5kbGVDaGFuZ2VVc2VyIiwiaGFuZGxlQmlkUmVxdWVzdFNlbGVjdCIsImJpZFJlcXVlc3QiLCJzdWJzY3JpYmVySWQiLCJ0aWNrZXROdW1iZXIiLCJoYW5kbGVHcm91cENoYW5nZSIsImZldGNoQWR2YW5jZVBheW91dHMiLCJoYW5kbGVHcm91cCIsInJlczEiLCJyZXMyIiwicmVzMyIsIlByb21pc2UiLCJhbGwiLCJpc19jb21tZW5jZW1lbnRfZG9uZSIsImlzX2F1Y3Rpb25fY29tcGxldGVkIiwiaGFuZGxlR3JvdXBBdWN0aW9uIiwiaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlIiwiZm9ybWF0dGVkRGF0YSIsInN0YXR1cyIsImlzUHJpemVkIiwiYWN0aW9uIiwiaXRlbXMiLCJrZXkiLCJsYWJlbCIsImhhbmRsZVVwZGF0ZU1vZGFsT3BlbiIsImhhbmRsZURlbGV0ZU1vZGFsT3BlbiIsImNvbHVtbnMiLCJoZWFkZXIiLCJwcmVBdWN0aW9uQ29sdW1ucyIsInJlY2VudEF1Y3Rpb25zQ29sdW1ucyIsImdyb3VwX2NvbW1pc3Npb24iLCJncm91cF9tZW1iZXJzIiwiZ3JvdXBfaW5zdGFsbCIsImhhbmRsZVN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiaXNWYWxpZCIsInBheWxvYWQiLCJwb3N0IiwiaGFuZGxlQ2xvc2VNb2RhbCIsImhhbmRsZURlbGV0ZUF1Y3Rpb24iLCJkZWxldGUiLCJoYW5kbGVJbnB1dENoYW5nZSIsInNpIiwiU0lfbnVtYmVyIiwiaGFuZGxlVXBkYXRlIiwicHV0IiwiZmlsdGVyZWRCaWRSZXF1ZXN0cyIsImZpbHRlciIsInVzZXIiLCJmdWxsTmFtZSIsInN1YnNjcmliZXJEZXRhaWxzIiwidG9Mb3dlckNhc2UiLCJzdWJzY3JpYmVyTmFtZSIsInRvU3RyaW5nIiwicGhvbmUiLCJtb2JpbGVOdW1iZXIiLCJiaWRDb2RlIiwiYmlkX3JlcXVlc3RfY29kZSIsImluY2x1ZGVzIiwiaGFuZGxlQ2xvc2VCaWREcmF3ZXIiLCJoYW5kbGVTd2l0Y2hUb0Vucm9sbGVkIiwiaGFuZGxlU3dpdGNoVG9CaWRSZXF1ZXN0cyIsImhhbmRsZVN3aXRjaFRvQWR2YW5jZVBheW91dHMiLCJoYW5kbGVWaWV3VHJhbnNhY3Rpb24iLCJhbGVydCIsImVycm9yTWVzc2FnZSIsImF1Y3Rpb25zRGF0YSIsImdyb3VwX25hbWUiLCJoYW5kbGVHcm91cE92ZXJ2aWV3IiwiaGFuZGxlUGF5b3V0SW5mb3JtYXRpb24iLCJoZWlnaHQiLCJ1bmRlZmluZWQiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidGlja2V0cyIsInBvaW50ZXJFdmVudHMiLCJzdG9wUHJvcGFnYXRpb24iLCJpc1NlbGVjdGVkIiwiZGF5c0FnbyIsIk1hdGgiLCJmbG9vciIsImlzTmV3IiwiaXNPbGQiLCJlbGlnaWJpbGl0eVN0YXR1cyIsIml0ZW0iLCJ0b0xvY2FsZVN0cmluZyIsInBheV9kYXRlIiwidG9Mb2NhbGVEYXRlU3RyaW5nIiwidXNlcnMiLCJ0b3RhbHMiLCJ0b3RhbEJlUGFpZCIsInBhaWQiLCJiYWxhbmNlIiwic3VtbWFyeSIsInRvdGFsQXVjdGlvbnMiLCJub3JtYWxBdWN0aW9ucyIsImZyZWVBdWN0aW9ucyIsInByaXplZFRydWUiLCJwcml6ZWRGYWxzZSIsInByaXplZFVzZXJzIiwiaWR4Iiwibm9uUHJpemVkVXNlcnMiLCJyZWR1Y2UiLCJzdW0iLCJwYXlfdHlwZSIsInBheW91dCIsImRpc2J1cnNlbWVudF90eXBlIiwiYWRtaW5fbmFtZSIsIk51bWJlciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkF1Y3Rpb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIHVzZVJlZiB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgU2lkZWJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL1NpZGViYXJcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBNZERlbGV0ZSB9IGZyb20gXCJyZWFjdC1pY29ucy9tZFwiO1xyXG5pbXBvcnQgeyBDaUVkaXQgfSBmcm9tIFwicmVhY3QtaWNvbnMvY2lcIjtcclxuaW1wb3J0IE1vZGFsIGZyb20gXCIuLi9jb21wb25lbnRzL21vZGFscy9Nb2RhbFwiO1xyXG5pbXBvcnQgeyBCc0V5ZSB9IGZyb20gXCJyZWFjdC1pY29ucy9ic1wiO1xyXG5pbXBvcnQgeyBCdXR0b24sIERyb3Bkb3duLCBJbnB1dCwgU3BpbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IHsgRXllSWNvbiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0IGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydFwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgVGFnLCBUb29sdGlwIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IHsgRmFVc2VyQ2hlY2ssIEZhQ2hldnJvblJpZ2h0IH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IEdpTW9uZXlTdGFjayB9IGZyb20gXCJyZWFjdC1pY29ucy9naVwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuaW1wb3J0IHsgbnVtYmVyVG9JbmRpYW5Xb3JkcyB9IGZyb20gXCIuLi9oZWxwZXJzL251bWJlclRvSW5kaWFuV29yZHNcIjtcclxuaW1wb3J0IHtcclxuICBYLFxyXG4gIFNlYXJjaCxcclxuICBGaWxlVGV4dCxcclxuICBQaWVDaGFydCxcclxuICBSZWNlaXB0LFxyXG4gIExpc3QsXHJcbiAgSW5mbyxcclxuICBVc2VycyxcclxufSBmcm9tIFwibHVjaWRlLXJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgQ2hlY2tDaXJjbGVPdXRsaW5lZCxcclxuICBDbG9ja0NpcmNsZU91dGxpbmVkLFxyXG4gIFdhcm5pbmdPdXRsaW5lZCxcclxufSBmcm9tIFwiQGFudC1kZXNpZ24vaWNvbnNcIjtcclxuXHJcbmNvbnN0IEF1Y3Rpb24gPSAoKSA9PiB7XHJcbiAgY29uc3QgaXNPbmxpbmUgPSBuYXZpZ2F0b3Iub25MaW5lO1xyXG4gIGNvbnN0IFtncm91cHMsIHNldEdyb3Vwc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW1RhYmxlQXVjdGlvbnMsIHNldFRhYmxlQXVjdGlvbnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwLCBzZXRTZWxlY3RlZEdyb3VwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cCwgc2V0U2VsZWN0ZWRBdWN0aW9uR3JvdXBdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3NlbGVjdGVkR3JvdXBJZCwgc2V0U2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkLCBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtmaWx0ZXJlZFVzZXJzLCBzZXRGaWx0ZXJlZFVzZXJzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZmlsdGVyZWRBdWN0aW9uLCBzZXRGaWx0ZXJlZEF1Y3Rpb25dID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtncm91cEluZm8sIHNldEdyb3VwSW5mb10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbCwgc2V0U2hvd01vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2hvd0JpZERyYXdlciwgc2V0U2hvd0JpZERyYXdlcl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2JpZFJlcXVlc3RzLCBzZXRCaWRSZXF1ZXN0c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2JpZERyYXdlclNlYXJjaCwgc2V0QmlkRHJhd2VyU2VhcmNoXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtsb2FkaW5nQmlkUmVxdWVzdHMsIHNldExvYWRpbmdCaWRSZXF1ZXN0c10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbERlbGV0ZSwgc2V0U2hvd01vZGFsRGVsZXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEdyb3VwLCBzZXRDdXJyZW50R3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZUdyb3VwLCBzZXRDdXJyZW50VXBkYXRlR3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2RvdWJsZSwgc2V0RG91YmxlXSA9IHVzZVN0YXRlKHt9KTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3NlYXJjaFRleHQsIHNldFNlYXJjaFRleHRdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2RyYXdlclRhYiwgc2V0RHJhd2VyVGFiXSA9IHVzZVN0YXRlKFwiYmlkcmVxdWVzdHNcIik7XHJcbiAgLy8gY29uc3QgW2RyYXdlclRhYiwgc2V0RHJhd2VyVGFiXSA9IHVzZVN0YXRlKFwiYWR2YW5jZVBheW91dFwiKTtcclxuICBjb25zdCBbaGFzRmV0Y2hlZCwgc2V0SGFzRmV0Y2hlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgaGFzTG9hZGVkUmVmID0gdXNlUmVmKGZhbHNlKTtcclxuICBjb25zdCBoYXNGZXRjaGVkR3JvdXBzID0gdXNlUmVmKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgW3Nob3dUcmFuc2FjdGlvbk1vZGFsLCBzZXRTaG93VHJhbnNhY3Rpb25Nb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3RyYW5zYWN0aW9uRGF0YSwgc2V0VHJhbnNhY3Rpb25EYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbbG9hZGluZ1RyYW5zYWN0aW9uLCBzZXRMb2FkaW5nVHJhbnNhY3Rpb25dID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtyZWNlbnRBdWN0aW9ucywgc2V0UmVjZW50QXVjdGlvbnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtydW5SZWNlbnRBdWN0aW9uLCBzZXRSdW5SZWNlbnRBdWN0aW9uXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtsb2FkaW5nUmVjZW50LCBzZXRMb2FkaW5nUmVjZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VzdG9tZXJPcHRpb25zLCBzZXRDdXN0b21lck9wdGlvbnNdID0gdXNlU3RhdGUoW10pO1xyXG5cclxuICBjb25zdCBbYWR2YW5jZVBheW91dHMsIHNldEFkdmFuY2VQYXlvdXRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd0FkdmFuY2VQYXlvdXRNb2RhbCwgc2V0U2hvd0FkdmFuY2VQYXlvdXRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFtHcm91cE92ZXJ2aWV3LCBzZXRHcm91cE92ZXJ2aWV3XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbR3JvdXBPdmVydmlld0RhdGEsIHNldEdyb3VwT3ZlcnZpZXdEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbc2hvd0dyb3VwT3ZlcnZpZXdNb2RhbCwgc2V0c2hvd0dyb3VwT3ZlcnZpZXdNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2xvYWRpbmdHcm91cE92ZXJ2aWV3LCBzZXRMb2FkaW5nR3JvdXBPdmVydmlld10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFtzaG93UGF5b3V0TW9kYWwsIHNldFNob3dQYXlvdXRNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3BheW91dERhdGEsIHNldFBheW91dERhdGFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nUGF5b3V0LCBzZXRMb2FkaW5nUGF5b3V0XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNDb21tZW5jZW1lbnREb25lLCBzZXRJc0NvbW1lbmNlbWVudERvbmVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyBUYWIgY29udHJvbFxyXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZSgnYXVjdGlvbnMnKTtcclxuXHJcbiAgLy8gUHJl4oCRYXVjdGlvbiB0YWIgc3RhdGVzXHJcbiAgY29uc3QgW3ByZUF1Y3Rpb25Hcm91cHMsIHNldFByZUF1Y3Rpb25Hcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtwcmVBdWN0aW9uU2VsZWN0ZWRHcm91cElkLCBzZXRQcmVBdWN0aW9uU2VsZWN0ZWRHcm91cElkXSA9IHVzZVN0YXRlKCcnKTtcclxuICBjb25zdCBbcHJlQXVjdGlvblRhYmxlRGF0YSwgc2V0UHJlQXVjdGlvblRhYmxlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3ByZUF1Y3Rpb25Mb2FkaW5nLCBzZXRQcmVBdWN0aW9uTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3ByZUF1Y3Rpb25IYXNGZXRjaGVkR3JvdXBzLCBzZXRQcmVBdWN0aW9uSGFzRmV0Y2hlZEdyb3Vwc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3ByZUF1Y3Rpb25IYXNGZXRjaGVkRGF0YSwgc2V0UHJlQXVjdGlvbkhhc0ZldGNoZWREYXRhXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgW2lzQXVjdGlvbkNvbXBsZXRlZCwgc2V0SXNBdWN0aW9uQ29tcGxldGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbYXVjdGlvblN0YXR1c0xvYWRpbmcsIHNldEF1Y3Rpb25TdGF0dXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuICBjb25zdCBbZm9ybURhdGEsIHNldEZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGF1Y3Rpb25fY29kZTogXCJcIixcclxuICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgdXNlcl9pZDogXCJcIixcclxuICAgIHRpY2tldDogXCJcIixcclxuICAgIGJpZF9hbW91bnQ6IFwiXCIsXHJcbiAgICBjb21taXNzaW9uOiBcIlwiLFxyXG4gICAgd2luX2Ftb3VudDogXCJcIixcclxuICAgIGRpdmlkZW50OiBcIlwiLFxyXG4gICAgZGl2aWRlbnRfaGVhZDogXCJcIixcclxuICAgIHBheWFibGU6IFwiXCIsXHJcbiAgICBhdWN0aW9uX2RhdGU6IFwiXCIsXHJcbiAgICBhdWN0aW9uX3RpbWU6IFwiXCIsXHJcbiAgICBuZXh0X2RhdGU6IFwiXCIsXHJcbiAgICBuZXh0X2F1Y3Rpb25fdGltZTogXCJcIixcclxuICAgIGdyb3VwX3R5cGU6IFwiXCIsXHJcbiAgICBhdWN0aW9uX3R5cGU6IFwibm9ybWFsXCIsXHJcbiAgICBiaWRfcmVxdWVzdF9pZDogXCJcIixcclxuICB9KTtcclxuICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGF1Y3Rpb25fZGF0ZTogXCJcIixcclxuICAgIGF1Y3Rpb25fdGltZTogXCJcIixcclxuICAgIG5leHRfZGF0ZTogXCJcIixcclxuICAgIG5leHRfYXVjdGlvbl90aW1lOiBcIlwiLFxyXG5cclxuICB9KTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChoYXNGZXRjaGVkR3JvdXBzLmN1cnJlbnQpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCBmZXRjaEdyb3VwcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgaWYgKCFuYXZpZ2F0b3Iub25MaW5lKSByZXR1cm47XHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9ncm91cC9nZXQtZ3JvdXAtYWRtaW5cIik7XHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgZmV0Y2hHcm91cHMoKTtcclxuICAgIGhhc0ZldGNoZWRHcm91cHMuY3VycmVudCA9IHRydWU7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBGZXRjaCBncm91cHMgZm9yIHByZeKAkWF1Y3Rpb24gZHJvcGRvd25cclxuICBjb25zdCBmZXRjaFByZUF1Y3Rpb25Hcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIW5hdmlnYXRvci5vbkxpbmUpIHJldHVybjtcclxuICAgIHNldFByZUF1Y3Rpb25Mb2FkaW5nKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KCcvdjEvYWRtaW4vZ3JvdXBzL3ByZS1hdWN0aW9uJyk7XHJcbiAgICAgIHNldFByZUF1Y3Rpb25Hcm91cHMocmVzcG9uc2UuZGF0YT8uZGF0YSB8fCByZXNwb25zZS5kYXRhIHx8IFtdKTtcclxuICAgICAgc2V0UHJlQXVjdGlvbkhhc0ZldGNoZWRHcm91cHModHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBmZXRjaGluZyBwcmXigJFhdWN0aW9uIGdyb3VwczonLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8ICdGYWlsZWQgdG8gbG9hZCBwcmXigJFhdWN0aW9uIGdyb3VwcycsXHJcbiAgICAgICAgdHlwZTogJ2Vycm9yJyxcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRQcmVBdWN0aW9uTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gRmV0Y2ggYXVjdGlvbiBkYXRhIGZvciBhIHNwZWNpZmljIGdyb3VwIChwcmXigJFhdWN0aW9uIHRhYilcclxuICBjb25zdCBmZXRjaFByZUF1Y3Rpb25Hcm91cEF1Y3Rpb25zID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIGlmICghZ3JvdXBJZCkge1xyXG4gICAgICBzZXRQcmVBdWN0aW9uVGFibGVEYXRhKFtdKTtcclxuICAgICAgc2V0UHJlQXVjdGlvbkhhc0ZldGNoZWREYXRhKHRydWUpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0UHJlQXVjdGlvbkxvYWRpbmcodHJ1ZSk7XHJcbiAgICBzZXRQcmVBdWN0aW9uSGFzRmV0Y2hlZERhdGEoZmFsc2UpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vZ3JvdXBzL2F1Y3Rpb24vJHtncm91cElkfWApO1xyXG4gICAgICBjb25zdCBhdWN0aW9ucyA9IHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgcmVzcG9uc2UuZGF0YSB8fCBbXTtcclxuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoYXVjdGlvbnMpICYmIGF1Y3Rpb25zLmxlbmd0aCA+IDApIHtcclxuICAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBhdWN0aW9ucy5tYXAoKGF1Y3Rpb24sIGluZGV4KSA9PiAoe1xyXG4gICAgICAgICAgX2lkOiBhdWN0aW9uLl9pZCxcclxuICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICBhdWN0aW9uX2NvZGU6IGF1Y3Rpb24uYXVjdGlvbl9jb2RlIHx8ICdOL0EnLFxyXG4gICAgICAgICAgYXVjdGlvbl9kYXRlOiBhdWN0aW9uLmF1Y3Rpb25fZGF0ZT8uc3BsaXQoJ1QnKVswXSB8fCBhdWN0aW9uLmF1Y3Rpb25fZGF0ZSB8fCAnTi9BJyxcclxuICAgICAgICAgIG5leHRfZGF0ZTogYXVjdGlvbi5uZXh0X2RhdGU/LnNwbGl0KCdUJylbMF0gfHwgYXVjdGlvbi5uZXh0X2RhdGUgfHwgJ04vQScsXHJcbiAgICAgICAgICBuYW1lOiBhdWN0aW9uLnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCAnTi9BJyxcclxuICAgICAgICAgIHBob25lX251bWJlcjogYXVjdGlvbi51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgJ04vQScsXHJcbiAgICAgICAgICB0aWNrZXQ6IGF1Y3Rpb24udGlja2V0IHx8ICdOL0EnLFxyXG4gICAgICAgICAgYmlkX2Ftb3VudDogKHBhcnNlSW50KGF1Y3Rpb24uZGl2aWRlbnQpIHx8IDApICsgKHBhcnNlSW50KGF1Y3Rpb24uY29tbWlzc2lvbikgfHwgMCksXHJcbiAgICAgICAgICBhbW91bnQ6IGF1Y3Rpb24ud2luX2Ftb3VudCB8fCAnTi9BJyxcclxuICAgICAgICAgIGF1Y3Rpb25fdHlwZTogYXVjdGlvbj8uYXVjdGlvbl9zdGFnZV90eXBlID09PSBcIkNPTU1FTkNFTUVOVFwiID8gXCJDT01NRU5DRU1FTlRcIiA6IGF1Y3Rpb24uYXVjdGlvbl90eXBlXHJcbiAgICAgICAgICAgID8gYXVjdGlvbi5hdWN0aW9uX3R5cGUuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgKyBhdWN0aW9uLmF1Y3Rpb25fdHlwZS5zbGljZSgxKVxyXG4gICAgICAgICAgICA6ICdOL0EnLFxyXG4gICAgICAgICAgLy8gYWN0aW9uOiAoXHJcbiAgICAgICAgICAvLyAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgLy8gICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgLy8gICAgICAgbWVudT17e1xyXG4gICAgICAgICAgLy8gICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgLy8gICAgICAgICAgIHtcclxuICAgICAgICAgIC8vICAgICAgICAgICAgIGtleTogJzEnLFxyXG4gICAgICAgICAgLy8gICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgIC8vICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgIC8vICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oYXVjdGlvbi5faWQsIGluZGV4ICsgMil9XHJcbiAgICAgICAgICAvLyAgICAgICAgICAgICAgID5cclxuICAgICAgICAgIC8vICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAvLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgLy8gICAgICAgICAgICAgKSxcclxuICAgICAgICAgIC8vICAgICAgICAgICB9LFxyXG4gICAgICAgICAgLy8gICAgICAgICAgIHtcclxuICAgICAgICAgIC8vICAgICAgICAgICAgIGtleTogJzInLFxyXG4gICAgICAgICAgLy8gICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgIC8vICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAvLyAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlTW9kYWxPcGVuKGF1Y3Rpb24uX2lkKX1cclxuICAgICAgICAgIC8vICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgLy8gICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIC8vICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAvLyAgICAgICAgICAgfSxcclxuICAgICAgICAgIC8vICAgICAgICAgXSxcclxuICAgICAgICAgIC8vICAgICAgIH19XHJcbiAgICAgICAgICAvLyAgICAgICBwbGFjZW1lbnQ9XCJib3R0b21MZWZ0XCJcclxuICAgICAgICAgIC8vICAgICA+XHJcbiAgICAgICAgICAvLyAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgIC8vICAgICA8L0Ryb3Bkb3duPlxyXG4gICAgICAgICAgLy8gICA8L2Rpdj5cclxuICAgICAgICAgIC8vICksXHJcbiAgICAgICAgfSkpO1xyXG4gICAgICAgIHNldFByZUF1Y3Rpb25UYWJsZURhdGEoZm9ybWF0dGVkKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRQcmVBdWN0aW9uVGFibGVEYXRhKFtdKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZmV0Y2hpbmcgcHJl4oCRYXVjdGlvbiBhdWN0aW9uczonLCBlcnJvcik7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8ICdGYWlsZWQgdG8gbG9hZCBhdWN0aW9uIGRhdGEnLFxyXG4gICAgICAgIHR5cGU6ICdlcnJvcicsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRQcmVBdWN0aW9uVGFibGVEYXRhKFtdKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldFByZUF1Y3Rpb25Mb2FkaW5nKGZhbHNlKTtcclxuICAgICAgc2V0UHJlQXVjdGlvbkhhc0ZldGNoZWREYXRhKHRydWUpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIEhhbmRsZXIgd2hlbiB1c2VyIHNlbGVjdHMgYSBncm91cCBpbiB0aGUgcHJl4oCRYXVjdGlvbiBkcm9wZG93blxyXG4gIGNvbnN0IGhhbmRsZVByZUF1Y3Rpb25Hcm91cENoYW5nZSA9IChncm91cElkKSA9PiB7XHJcbiAgICBzZXRQcmVBdWN0aW9uU2VsZWN0ZWRHcm91cElkKGdyb3VwSWQpO1xyXG4gICAgZmV0Y2hQcmVBdWN0aW9uR3JvdXBBdWN0aW9ucyhncm91cElkKTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKGFjdGl2ZVRhYiA9PT0gJ3ByZUF1Y3Rpb24nICYmICFwcmVBdWN0aW9uSGFzRmV0Y2hlZEdyb3Vwcykge1xyXG4gICAgICBmZXRjaFByZUF1Y3Rpb25Hcm91cHMoKTtcclxuICAgIH1cclxuICB9LCBbYWN0aXZlVGFiLCBwcmVBdWN0aW9uSGFzRmV0Y2hlZEdyb3Vwc10pO1xyXG5cclxuICAvLyB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gIC8vICAgY29uc3QgZmV0Y2hEb3VibGUgPSBhc3luYyAoKSA9PiB7XHJcbiAgLy8gICAgIHRyeSB7XHJcbiAgLy8gICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gIC8vICAgICAgICAgYC9kb3VibGUvZ2V0LWRvdWJsZS8ke3NlbGVjdGVkQXVjdGlvbkdyb3VwSWR9YCxcclxuICAvLyAgICAgICApO1xyXG4gIC8vICAgICAgIHNldERvdWJsZShyZXNwb25zZS5kYXRhKTtcclxuICAvLyAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAvLyAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gIC8vICAgICB9XHJcbiAgLy8gICB9O1xyXG4gIC8vICAgZmV0Y2hEb3VibGUoKTtcclxuICAvLyB9LCBbc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZF0pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hEb3VibGUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIC8vIE9ubHkgZmV0Y2ggaWYgc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCBpcyBhIHZhbGlkIGdyb3VwIElEIChub3QgXCJyZWNlbnRcIilcclxuICAgICAgaWYgKHNlbGVjdGVkQXVjdGlvbkdyb3VwSWQgJiYgc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCAhPT0gXCJyZWNlbnRcIikge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICAgIGAvZG91YmxlL2dldC1kb3VibGUvJHtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkfWAsXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgICAgc2V0RG91YmxlKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZ3JvdXAgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICAgICAgc2V0RG91YmxlKHt9KTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0RG91YmxlKHt9KTsgLy8gUmVzZXQgZG91YmxlIHdoZW4gcmVjZW50IGF1Y3Rpb25zIGlzIHNlbGVjdGVkXHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaERvdWJsZSgpO1xyXG4gIH0sIFtzZWxlY3RlZEF1Y3Rpb25Hcm91cElkXSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoaGFzTG9hZGVkUmVmLmN1cnJlbnQpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCBsb2FkRGVmYXVsdEF1Y3Rpb25zID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkKFwicmVjZW50XCIpO1xyXG4gICAgICBhd2FpdCBmZXRjaFJlY2VudEF1Y3Rpb25zKCk7XHJcbiAgICB9O1xyXG4gICAgbG9hZERlZmF1bHRBdWN0aW9ucygpO1xyXG4gICAgaGFzTG9hZGVkUmVmLmN1cnJlbnQgPSB0cnVlO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hCaWRSZXF1ZXN0c0ZvckF1Y3Rpb24gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgc2V0TG9hZGluZ0JpZFJlcXVlc3RzKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYmlkLXJlcXVlc3QvZ2V0LWZvci1hdWN0aW9uLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgaWYgKHJlc3BvbnNlLmRhdGE/LnN1Y2Nlc3MgJiYgcmVzcG9uc2UuZGF0YT8uZGF0YT8ubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHNldEJpZFJlcXVlc3RzKHJlc3BvbnNlLmRhdGEuZGF0YSk7XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICBzZXRTaG93QmlkRHJhd2VyKHRydWUpO1xyXG4gICAgICAgICAgc2V0RHJhd2VyVGFiKFwiYmlkcmVxdWVzdHNcIik7XHJcbiAgICAgICAgICAvLyBzZXREcmF3ZXJUYWIoXCJhZHZhbmNlUGF5b3V0XCIpO1xyXG4gICAgICAgIH0sIDEwMCk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0QmlkUmVxdWVzdHMoW10pO1xyXG4gICAgICAgIHNldFNob3dCaWREcmF3ZXIoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYmlkIHJlcXVlc3RzIGZvciBhdWN0aW9uOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEJpZFJlcXVlc3RzKFtdKTtcclxuICAgICAgc2V0U2hvd0JpZERyYXdlcihmYWxzZSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nQmlkUmVxdWVzdHMoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoQmlkUmVxdWVzdHMgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvZW5yb2xsL2dldC1ncm91cC1lbnJvbGwtYXVjdGlvbi1hbGwvJHtncm91cElkfWAsXHJcbiAgICAgICk7XHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEubGVuZ3RoID4gMCkge1xyXG4gICAgICAgIHNldEZpbHRlcmVkVXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVGb3JtID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbmV3RXJyb3JzID0ge307XHJcblxyXG4gICAgLy8gQWx3YXlzIHJlcXVpcmVkXHJcbiAgICBpZiAoIXNlbGVjdGVkR3JvdXBJZCkge1xyXG4gICAgICBuZXdFcnJvcnMuZ3JvdXAgPSBcIkdyb3VwIHNlbGVjdGlvbiBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghZm9ybURhdGEuYXVjdGlvbl9kYXRlKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hdWN0aW9uX2RhdGUgPSBcIkF1Y3Rpb24gZGF0ZSBpcyByZXF1aXJlZFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFmb3JtRGF0YS5hdWN0aW9uX3RpbWUpIHtcclxuICAgICAgbmV3RXJyb3JzLmF1Y3Rpb25fdGltZSA9IFwiQXVjdGlvbiB0aW1lIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFmb3JtRGF0YS5uZXh0X2RhdGUpIHtcclxuICAgICAgbmV3RXJyb3JzLm5leHRfZGF0ZSA9IFwiTmV4dCBkYXRlIGlzIHJlcXVpcmVkXCI7XHJcbiAgICB9IGVsc2UgaWYgKGZvcm1EYXRhLm5leHRfZGF0ZSA8IGZvcm1EYXRhLmF1Y3Rpb25fZGF0ZSkge1xyXG4gICAgICBuZXdFcnJvcnMubmV4dF9kYXRlID0gXCJOZXh0IGRhdGUgY2Fubm90IGJlIGluIHRoZSBwYXN0XCI7XHJcbiAgICB9XHJcbiAgICBpZiAoIWZvcm1EYXRhLm5leHRfYXVjdGlvbl90aW1lKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5uZXh0X2F1Y3Rpb25fdGltZSA9IFwiTmV4dCBhdWN0aW9uIHRpbWUgaXMgcmVxdWlyZWRcIjtcclxuICAgIH1cclxuXHJcbiAgICAvLyBBZGRpdGlvbmFsIHZhbGlkYXRpb25zIG9ubHkgaWYgY29tbWVuY2VtZW50IGlzIGRvbmVcclxuICAgIGlmIChpc0NvbW1lbmNlbWVudERvbmUpIHtcclxuICAgICAgaWYgKGdyb3VwSW5mby5ncm91cF90eXBlID09PSBcImRvdWJsZVwiICYmICFmb3JtRGF0YS5hdWN0aW9uX3R5cGUpIHtcclxuICAgICAgICBuZXdFcnJvcnMuYXVjdGlvbl90eXBlID0gXCJBdWN0aW9uIHR5cGUgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKCFmb3JtRGF0YS51c2VyX2lkKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzLmN1c3RvbWVyID0gXCJDdXN0b21lciBzZWxlY3Rpb24gaXMgcmVxdWlyZWRcIjtcclxuICAgICAgfVxyXG5cclxuICAgICAgaWYgKCFmb3JtRGF0YS5iaWRfYW1vdW50KSB7XHJcbiAgICAgICAgbmV3RXJyb3JzLmJpZF9hbW91bnQgPSBcIkJpZCBhbW91bnQgaXMgcmVxdWlyZWRcIjtcclxuICAgICAgfSBlbHNlIGlmIChcclxuICAgICAgICBpc05hTihmb3JtRGF0YS5iaWRfYW1vdW50KSB8fFxyXG4gICAgICAgIHBhcnNlRmxvYXQoZm9ybURhdGEuYmlkX2Ftb3VudCkgPD0gMFxyXG4gICAgICApIHtcclxuICAgICAgICBuZXdFcnJvcnMuYmlkX2Ftb3VudCA9IFwiQmlkIGFtb3VudCBtdXN0IGJlIGEgcG9zaXRpdmUgbnVtYmVyXCI7XHJcbiAgICAgIH0gZWxzZSBpZiAoXHJcbiAgICAgICAgZ3JvdXBJbmZvLmdyb3VwX3ZhbHVlICYmXHJcbiAgICAgICAgcGFyc2VGbG9hdChmb3JtRGF0YS5iaWRfYW1vdW50KSA+IHBhcnNlRmxvYXQoZ3JvdXBJbmZvLmdyb3VwX3ZhbHVlKVxyXG4gICAgICApIHtcclxuICAgICAgICBuZXdFcnJvcnMuYmlkX2Ftb3VudCA9IGBCaWQgYW1vdW50IGNhbm5vdCBleGNlZWQgZ3JvdXAgdmFsdWUgb2YgJHtncm91cEluZm8uZ3JvdXBfdmFsdWV9YDtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuXHJcbiAgICBzZXRGb3JtRGF0YSgocHJldkRhdGEpID0+IHtcclxuICAgICAgY29uc3QgdXBkYXRlZERhdGEgPSB7XHJcbiAgICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgICAgW25hbWVdOiB2YWx1ZSxcclxuICAgICAgfTtcclxuXHJcbiAgICAgIC8vIEF1dG8tc2V0IE5leHQgQXVjdGlvbiBEYXRlID0gQXVjdGlvbiBEYXRlICsgMTAgZGF5c1xyXG4gICAgICBpZiAobmFtZSA9PT0gXCJhdWN0aW9uX2RhdGVcIiAmJiB2YWx1ZSkge1xyXG4gICAgICAgIGNvbnN0IG5leHREYXRlID0gbmV3IERhdGUodmFsdWUpO1xyXG4gICAgICAgIG5leHREYXRlLnNldERhdGUobmV4dERhdGUuZ2V0RGF0ZSgpICsgMTApO1xyXG5cclxuICAgICAgICB1cGRhdGVkRGF0YS5uZXh0X2RhdGUgPSBuZXh0RGF0ZS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIHVwZGF0ZWREYXRhO1xyXG4gICAgfSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RXJyb3JzLFxyXG4gICAgICBbbmFtZV06IFwiXCIsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlVXNlciA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgY29uc3QgW3VzZXJfaWQsIHRpY2tldF0gPSB2YWx1ZS5zcGxpdChcIi1cIik7XHJcblxyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgdXNlcl9pZCxcclxuICAgICAgdGlja2V0LFxyXG4gICAgfSkpO1xyXG5cclxuICAgIHNldEVycm9ycygocHJldkVycm9ycykgPT4gKHsgLi4ucHJldkVycm9ycywgY3VzdG9tZXI6IFwiXCIgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUJpZFJlcXVlc3RTZWxlY3QgPSAoYmlkUmVxdWVzdCkgPT4ge1xyXG4gICAgaWYgKGJpZFJlcXVlc3Q/LnN1YnNjcmliZXJJZCAmJiBiaWRSZXF1ZXN0Py50aWNrZXROdW1iZXIpIHtcclxuICAgICAgY29uc3QgdmFsdWUgPSBgJHtiaWRSZXF1ZXN0LnN1YnNjcmliZXJJZH0tJHtiaWRSZXF1ZXN0LnRpY2tldE51bWJlcn1gO1xyXG4gICAgICBoYW5kbGVDaGFuZ2VVc2VyKHZhbHVlKTtcclxuICAgICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICAgIGJpZF9yZXF1ZXN0X2lkOiBiaWRSZXF1ZXN0Ll9pZCxcclxuICAgICAgfSkpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwQ2hhbmdlID0gYXN5bmMgKGdyb3VwSWQpID0+IHtcclxuICAgIHNldFNlbGVjdGVkR3JvdXAoZ3JvdXBJZCk7XHJcblxyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBmZXRjaEJpZFJlcXVlc3RzKGdyb3VwSWQpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hBZHZhbmNlUGF5b3V0cyA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9wYXltZW50LW91dC9nZXQtYWR2YW5jZS1wYXlvdXQtYmVmb3JlLWF1Y3Rpb24vJHtncm91cElkfWBcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhPy5zdWNjZXNzICYmIHJlc3BvbnNlLmRhdGE/LmRhdGE/Lmxlbmd0aCA+IDApIHtcclxuICAgICAgICAvLyBCYWNrZW5kIGFscmVhZHkgcG9wdWxhdGVzIHVzZXJfaWQsIHNvIHVzZSBpdCBkaXJlY3RseVxyXG4gICAgICAgIHNldEFkdmFuY2VQYXlvdXRzKHJlc3BvbnNlLmRhdGEuZGF0YSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0QWR2YW5jZVBheW91dHMoW10pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYWR2YW5jZSBwYXlvdXRzOlwiLCBlcnJvcik7XHJcbiAgICAgIHNldEFkdmFuY2VQYXlvdXRzKFtdKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVHcm91cCA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7IC4uLnByZXZFcnJvcnMsIGdyb3VwOiBcIlwiIH0pKTtcclxuICAgIHNldFNlbGVjdGVkR3JvdXBJZChncm91cElkKTtcclxuICAgIGhhbmRsZUdyb3VwQ2hhbmdlKGdyb3VwSWQpO1xyXG5cclxuICAgIGlmIChncm91cElkKSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIHNldEF1Y3Rpb25TdGF0dXNMb2FkaW5nKHRydWUpO1xyXG5cclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCBbcmVzMSwgcmVzMiwgcmVzM10gPSBhd2FpdCBQcm9taXNlLmFsbChbXHJcbiAgICAgICAgICBhcGkuZ2V0KGAvZ3JvdXAvZ2V0LWJ5LWlkLWdyb3VwLyR7Z3JvdXBJZH1gKSxcclxuICAgICAgICAgIGFwaS5nZXQoYC92MS9hZG1pbi9hdWN0aW9ucy9jb21tZW5jZW1lbnQtc3RhdHVzL2dyb3Vwcy8ke2dyb3VwSWR9YCksXHJcbiAgICAgICAgICBhcGkuZ2V0KGAvdjEvYWRtaW4vYXVjdGlvbnMvZ3JvdXBzLyR7Z3JvdXBJZH0vc3RhdHVzYClcclxuICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgc2V0R3JvdXBJbmZvKHJlczEuZGF0YSB8fCB7fSk7XHJcbiAgICAgICAgc2V0SXNDb21tZW5jZW1lbnREb25lKHJlczIuZGF0YT8uZGF0YT8uaXNfY29tbWVuY2VtZW50X2RvbmUpXHJcbiAgICAgICAgc2V0SXNBdWN0aW9uQ29tcGxldGVkKFxyXG4gICAgICAgICAgcmVzMy5kYXRhPy5kYXRhPy5pc19hdWN0aW9uX2NvbXBsZXRlZCA9PT0gdHJ1ZVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgIGZldGNoQmlkUmVxdWVzdHNGb3JBdWN0aW9uKGdyb3VwSWQpLFxyXG4gICAgICAgICAgZmV0Y2hBZHZhbmNlUGF5b3V0cyhncm91cElkKSxcclxuICAgICAgICBdKTtcclxuXHJcbiAgICAgICAgc2V0U2hvd0JpZERyYXdlcih0cnVlKTtcclxuICAgICAgICBzZXREcmF3ZXJUYWIoXCJiaWRyZXF1ZXN0c1wiKTtcclxuXHJcbiAgICAgICAgLy8gYXdhaXQgZmV0Y2hCaWRSZXF1ZXN0c0ZvckF1Y3Rpb24oZ3JvdXBJZCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGdyb3VwIGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgICAgIHNldElzQXVjdGlvbkNvbXBsZXRlZChmYWxzZSk7XHJcbiAgICAgICAgc2V0U2hvd0JpZERyYXdlcih0cnVlKTtcclxuICAgICAgfVxyXG4gICAgICBmaW5hbGx5IHtcclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgICBzZXRBdWN0aW9uU3RhdHVzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEdyb3VwSW5mbyh7fSk7XHJcbiAgICAgIHNldEJpZFJlcXVlc3RzKFtdKTtcclxuICAgICAgc2V0QWR2YW5jZVBheW91dHMoW10pO1xyXG4gICAgICBzZXRJc0F1Y3Rpb25Db21wbGV0ZWQoZmFsc2UpO1xyXG4gICAgICBzZXRTaG93QmlkRHJhd2VyKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG4gIC8vIGNvbnN0IGhhbmRsZUdyb3VwQXVjdGlvbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgLy8gICBzZXRTZWxlY3RlZEF1Y3Rpb25Hcm91cElkKGdyb3VwSWQpO1xyXG4gIC8vICAgaGFuZGxlR3JvdXBBdWN0aW9uQ2hhbmdlKGdyb3VwSWQpO1xyXG4gIC8vIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwQXVjdGlvbiA9IGFzeW5jICh2YWx1ZSkgPT4ge1xyXG4gICAgaWYgKHZhbHVlID09PSBcInJlY2VudFwiKSB7XHJcbiAgICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQoXCJyZWNlbnRcIik7XHJcbiAgICAgIGF3YWl0IGZldGNoUmVjZW50QXVjdGlvbnMoKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwSWQodmFsdWUpO1xyXG4gICAgICBhd2FpdCBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2UodmFsdWUpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZSA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICBpZiAoIW5hdmlnYXRvci5vbkxpbmUpIHtcclxuICAgICAgc2V0SGFzRmV0Y2hlZCh0cnVlKTtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgc2V0TG9hZGluZ1JlY2VudChmYWxzZSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIHNldFNlbGVjdGVkQXVjdGlvbkdyb3VwKGdyb3VwSWQpO1xyXG4gICAgaWYgKGdyb3VwSWQpIHtcclxuICAgICAgc2V0VGFibGVBdWN0aW9ucyhbXSk7XHJcbiAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgc2V0SGFzRmV0Y2hlZChmYWxzZSk7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYXVjdGlvbi9ncm91cC1hdWN0aW9uLyR7Z3JvdXBJZH1gKTtcclxuICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkQXVjdGlvbihyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSBbXHJcbiAgICAgICAgICAgIC4uLnJlc3BvbnNlLmRhdGEubWFwKChncm91cCwgaW5kZXgpID0+ICh7XHJcbiAgICAgICAgICAgICAgX2lkOiBncm91cC5faWQsXHJcbiAgICAgICAgICAgICAgaWQ6IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBhdWN0aW9uX2NvZGU6IGdyb3VwPy5hdWN0aW9uX2NvZGUsXHJcbiAgICAgICAgICAgICAgYXVjdGlvbl9kYXRlOiBncm91cD8uYXVjdGlvbl9kYXRlLFxyXG4gICAgICAgICAgICAgIG5leHRfZGF0ZTogZ3JvdXAubmV4dF9kYXRlLFxyXG4gICAgICAgICAgICAgIG5hbWU6IGdyb3VwLnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwLnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICB0aWNrZXQ6IGdyb3VwPy50aWNrZXQsXHJcbiAgICAgICAgICAgICAgYmlkX2Ftb3VudDogcGFyc2VJbnQoZ3JvdXAuZGl2aWRlbnQpICsgcGFyc2VJbnQoZ3JvdXAuY29tbWlzc2lvbiksXHJcbiAgICAgICAgICAgICAgYW1vdW50OiBncm91cD8ud2luX2Ftb3VudCxcclxuICAgICAgICAgICAgICBzdGF0dXM6ICFncm91cD8uaXNQcml6ZWRcclxuICAgICAgICAgICAgICAgID8gXCJVbiBQcml6ZWRcIlxyXG4gICAgICAgICAgICAgICAgOiBncm91cD8uaXNQcml6ZWQgPT09IFwidHJ1ZVwiXHJcbiAgICAgICAgICAgICAgICAgID8gXCJQcml6ZWRcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiVW4gUHJpemVkXCIsXHJcbiAgICAgICAgICAgICAgYXVjdGlvbl90eXBlOlxyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LmF1Y3Rpb25fdHlwZS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArXHJcbiAgICAgICAgICAgICAgICBncm91cD8uYXVjdGlvbl90eXBlLnNsaWNlKDEpICtcclxuICAgICAgICAgICAgICAgIFwiIEF1Y3Rpb25cIixcclxuICAgICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGdyb3VwLl9pZCwgaW5kZXggKyAyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZU1vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIH0pKSxcclxuICAgICAgICAgIF07XHJcbiAgICAgICAgICBzZXRUYWJsZUF1Y3Rpb25zKGZvcm1hdHRlZERhdGEpO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgICAgc2V0VGFibGVBdWN0aW9ucyhbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZEF1Y3Rpb24oW10pO1xyXG4gICAgICAgIHNldFRhYmxlQXVjdGlvbnMoW10pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgICAgc2V0SGFzRmV0Y2hlZCh0cnVlKTtcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RmlsdGVyZWRBdWN0aW9uKFtdKTtcclxuICAgICAgc2V0VGFibGVBdWN0aW9ucyhbXSk7XHJcbiAgICAgIHNldEhhc0ZldGNoZWQodHJ1ZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYXVjdGlvbl9jb2RlXCIsIGhlYWRlcjogXCJBdWN0aW9uIENvZGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXVjdGlvbl9kYXRlXCIsIGhlYWRlcjogXCJBdWN0aW9uIERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibmV4dF9kYXRlXCIsIGhlYWRlcjogXCJOZXh0IERhdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwibmFtZVwiLCBoZWFkZXI6IFwiQ3VzdG9tZXIgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaG9uZV9udW1iZXJcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIFBob25lIE51bWJlclwiIH0sXHJcbiAgICB7IGtleTogXCJ0aWNrZXRcIiwgaGVhZGVyOiBcIlRpY2tldFwiIH0sXHJcbiAgICB7IGtleTogXCJiaWRfYW1vdW50XCIsIGhlYWRlcjogXCJCaWQgQW1vdW50XCIgfSxcclxuICAgIHsga2V5OiBcImFtb3VudFwiLCBoZWFkZXI6IFwiV2luIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJhdWN0aW9uX3R5cGVcIiwgaGVhZGVyOiBcIkF1Y3Rpb24gVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJzdGF0dXNcIiwgaGVhZGVyOiBcIlN0YXR1c1wiIH0sXHJcbiAgICB7IGtleTogXCJhY3Rpb25cIiwgaGVhZGVyOiBcIkFjdGlvblwiIH0sXHJcbiAgXTtcclxuXHJcbiAgY29uc3QgcHJlQXVjdGlvbkNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIC8vIHsga2V5OiBcImF1Y3Rpb25fY29kZVwiLCBoZWFkZXI6IFwiQXVjdGlvbiBDb2RlXCIgfSxcclxuICAgIHsga2V5OiBcImF1Y3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiQXVjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcIm5leHRfZGF0ZVwiLCBoZWFkZXI6IFwiTmV4dCBEYXRlXCIgfSxcclxuICAgIC8vIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgLy8geyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJDdXN0b21lciBQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgLy8geyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmlkX2Ftb3VudFwiLCBoZWFkZXI6IFwiQmlkIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIldpbiBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXVjdGlvbl90eXBlXCIsIGhlYWRlcjogXCJBdWN0aW9uIFR5cGVcIiB9LFxyXG5cclxuICAgIC8vIHsga2V5OiBcInN0YXR1c1wiLCBoZWFkZXI6IFwiU3RhdHVzXCIgfSxcclxuICAgIC8vIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCByZWNlbnRBdWN0aW9uc0NvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcImF1Y3Rpb25fY29kZVwiLCBoZWFkZXI6IFwiQXVjdGlvbiBDb2RlXCIgfSxcclxuICAgIHsga2V5OiBcImF1Y3Rpb25fZGF0ZVwiLCBoZWFkZXI6IFwiQXVjdGlvbiBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkdyb3VwIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZ3JvdXBfdmFsdWVcIiwgaGVhZGVyOiBcIkdyb3VwIFZhbHVlXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJDdXN0b21lciBQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwidGlja2V0XCIsIGhlYWRlcjogXCJUaWNrZXRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYmlkX2Ftb3VudFwiLCBoZWFkZXI6IFwiQmlkIEFtb3VudFwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIldpbiBBbW91bnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiYXVjdGlvbl90eXBlXCIsIGhlYWRlcjogXCJBdWN0aW9uIFR5cGVcIiB9LFxyXG4gICAgeyBrZXk6IFwic3RhdHVzXCIsIGhlYWRlcjogXCJTdGF0dXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9LFxyXG4gIF07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoZ3JvdXBJbmZvICYmIGZvcm1EYXRhLmJpZF9hbW91bnQpIHtcclxuICAgICAgY29uc3QgY29tbWlzc2lvbiA9XHJcbiAgICAgICAgKGdyb3VwSW5mby5ncm91cF92YWx1ZSAqIGdyb3VwSW5mby5ncm91cF9jb21taXNzaW9uKSAvIDEwMCB8fCAwO1xyXG4gICAgICBjb25zdCB3aW5fYW1vdW50ID1cclxuICAgICAgICAoZ3JvdXBJbmZvLmdyb3VwX3ZhbHVlIHx8IDApIC0gKGZvcm1EYXRhLmJpZF9hbW91bnQgfHwgMCk7XHJcbiAgICAgIGNvbnN0IGRpdmlkZW50ID0gKGZvcm1EYXRhLmJpZF9hbW91bnQgfHwgMCkgLSBjb21taXNzaW9uO1xyXG4gICAgICBjb25zdCBkaXZpZGVudF9oZWFkID0gZ3JvdXBJbmZvLmdyb3VwX21lbWJlcnNcclxuICAgICAgICA/IGRpdmlkZW50IC8gZ3JvdXBJbmZvLmdyb3VwX21lbWJlcnNcclxuICAgICAgICA6IDA7XHJcbiAgICAgIGNvbnN0IHBheWFibGUgPSAoZ3JvdXBJbmZvLmdyb3VwX2luc3RhbGwgfHwgMCkgLSBkaXZpZGVudF9oZWFkO1xyXG5cclxuICAgICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICAgIGdyb3VwX2lkOiBncm91cEluZm8uX2lkLFxyXG4gICAgICAgIGNvbW1pc3Npb24sXHJcbiAgICAgICAgd2luX2Ftb3VudCxcclxuICAgICAgICBkaXZpZGVudCxcclxuICAgICAgICBkaXZpZGVudF9oZWFkLFxyXG4gICAgICAgIHBheWFibGUsXHJcbiAgICAgICAgZ3JvdXBfdHlwZTogZ3JvdXBJbmZvLmdyb3VwX3R5cGUsXHJcbiAgICAgIH0pKTtcclxuICAgIH1cclxuICB9LCBbZ3JvdXBJbmZvLCBmb3JtRGF0YS5iaWRfYW1vdW50XSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgLy8gUHJldmVudCBkb3VibGUgY2xpY2tcclxuICAgIGlmIChpc1N1Ym1pdHRpbmcpIHJldHVybjtcclxuXHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVGb3JtKCk7XHJcbiAgICBpZiAoIWlzVmFsaWQpIHJldHVybjtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBzZXRJc1N1Ym1pdHRpbmcodHJ1ZSk7XHJcbiAgICAgIGxldCBwYXlsb2FkO1xyXG4gICAgICBpZiAoaXNDb21tZW5jZW1lbnREb25lKSB7XHJcbiAgICAgICAgcGF5bG9hZCA9IGZvcm1EYXRhO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIFNlbmQgb25seSBncm91cCwgYXVjdGlvbl9kYXRlLCBuZXh0X2RhdGVcclxuICAgICAgICBwYXlsb2FkID0ge1xyXG4gICAgICAgICAgZ3JvdXBfaWQ6IHNlbGVjdGVkR3JvdXBJZCxcclxuICAgICAgICAgIGF1Y3Rpb25fZGF0ZTogZm9ybURhdGEuYXVjdGlvbl9kYXRlLFxyXG4gICAgICAgICAgbmV4dF9kYXRlOiBmb3JtRGF0YS5uZXh0X2RhdGUsXHJcbiAgICAgICAgfTtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdChcIi9hdWN0aW9uL2FkZC1hdWN0aW9uXCIsIHBheWxvYWQpO1xyXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSAyMDEpIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBdWN0aW9uIEFkZGVkIFN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaGFuZGxlQ2xvc2VNb2RhbCgpO1xyXG4gICAgICAgIC8vIFJlZnJlc2ggdGhlIGFwcHJvcHJpYXRlIHRhYmxlIGJhc2VkIG9uIGFjdGl2ZSB0YWJcclxuICAgICAgICBpZiAoYWN0aXZlVGFiID09PSAncHJlQXVjdGlvbicpIHtcclxuICAgICAgICAgIGlmIChwcmVBdWN0aW9uU2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgICAgICAgIGZldGNoUHJlQXVjdGlvbkdyb3VwQXVjdGlvbnMocHJlQXVjdGlvblNlbGVjdGVkR3JvdXBJZCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGlmIChzZWxlY3RlZEF1Y3Rpb25Hcm91cElkKSB7XHJcbiAgICAgICAgICAgIGhhbmRsZUdyb3VwQXVjdGlvbkNoYW5nZShzZWxlY3RlZEF1Y3Rpb25Hcm91cElkKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBzdWJtaXR0aW5nIGF1Y3Rpb24gZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIkZhaWxlZCB0byBhZGQgYXVjdGlvblwiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNTdWJtaXR0aW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYXVjdGlvbi9nZXQtYXVjdGlvbi1ieS1pZC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRHcm91cChyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKHRydWUpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGVucm9sbDpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUF1Y3Rpb24gPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoY3VycmVudEdyb3VwKSB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgYXdhaXQgYXBpLmRlbGV0ZShgL2F1Y3Rpb24vZGVsZXRlLWF1Y3Rpb24vJHtjdXJyZW50R3JvdXAuX2lkfWApO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkF1Y3Rpb24gZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4gICAgICAgIGlmIChzZWxlY3RlZEF1Y3Rpb25Hcm91cElkKSB7XHJcbiAgICAgICAgICBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2Uoc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBhdWN0aW9uOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVJbnB1dENoYW5nZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW25hbWVdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZU1vZGFsT3BlbiA9IGFzeW5jIChncm91cElkLCBzaSkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvYXVjdGlvbi9nZXQtYXVjdGlvbi1ieS1pZC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICBhdWN0aW9uX2RhdGU6IHJlc3BvbnNlLmRhdGE/LmF1Y3Rpb25fZGF0ZSxcclxuICAgICAgICBhdWN0aW9uX3RpbWU6IHJlc3BvbnNlLmRhdGE/LmF1Y3Rpb25fdGltZSxcclxuICAgICAgICBuZXh0X2RhdGU6IHJlc3BvbnNlLmRhdGE/Lm5leHRfZGF0ZSxcclxuICAgICAgICBuZXh0X2F1Y3Rpb25fdGltZTogcmVzcG9uc2UuZGF0YT8ubmV4dF9hdWN0aW9uX3RpbWUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlR3JvdXAoeyAuLi5yZXNwb25zZS5kYXRhLCBTSV9udW1iZXI6IHNpIH0pO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUodHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYXVjdGlvbjpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgYC9hdWN0aW9uLyR7Y3VycmVudFVwZGF0ZUdyb3VwPy5faWR9YCxcclxuICAgICAgICB1cGRhdGVGb3JtRGF0YSxcclxuICAgICAgKTtcclxuICAgICAgc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogXCJBdWN0aW9uIGRhdGUgVXBkYXRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyAtLS0tLSBSZWZyZXNoIHRoZSBjb3JyZWN0IHRhYmxlIGJhc2VkIG9uIGFjdGl2ZSB0YWIgLS0tLS1cclxuICAgICAgaWYgKGFjdGl2ZVRhYiA9PT0gJ3ByZUF1Y3Rpb24nKSB7XHJcbiAgICAgICAgaWYgKHByZUF1Y3Rpb25TZWxlY3RlZEdyb3VwSWQpIHtcclxuICAgICAgICAgIGZldGNoUHJlQXVjdGlvbkdyb3VwQXVjdGlvbnMocHJlQXVjdGlvblNlbGVjdGVkR3JvdXBJZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGlmIChzZWxlY3RlZEF1Y3Rpb25Hcm91cElkKSB7XHJcbiAgICAgICAgICBoYW5kbGVHcm91cEF1Y3Rpb25DaGFuZ2Uoc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcImVycm9yIGluIHVwZGF0aW5nIGF1Y3Rpb25cIiwgZXJyb3IpO1xyXG4gICAgICBpZiAoXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UgJiZcclxuICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhICYmXHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlXHJcbiAgICAgICkge1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBgJHtlcnJvcj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2V9YCxcclxuICAgICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgICB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkLiBQbGVhc2UgdHJ5IGFnYWluLlwiLFxyXG4gICAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmlsdGVyZWRCaWRSZXF1ZXN0cyA9IGJpZFJlcXVlc3RzLmZpbHRlcigodXNlcikgPT4ge1xyXG4gICAgaWYgKCFiaWREcmF3ZXJTZWFyY2gpIHJldHVybiB0cnVlO1xyXG4gICAgY29uc3QgZnVsbE5hbWUgPVxyXG4gICAgICB1c2VyPy5zdWJzY3JpYmVyRGV0YWlscz8uZnVsbF9uYW1lPy50b0xvd2VyQ2FzZSgpIHx8XHJcbiAgICAgIHVzZXI/LnN1YnNjcmliZXJOYW1lPy50b0xvd2VyQ2FzZSgpIHx8XHJcbiAgICAgIFwiXCI7XHJcbiAgICBjb25zdCB0aWNrZXQgPSB1c2VyPy50aWNrZXROdW1iZXI/LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKSB8fCBcIlwiO1xyXG4gICAgY29uc3QgcGhvbmUgPVxyXG4gICAgICB1c2VyPy5zdWJzY3JpYmVyRGV0YWlscz8ucGhvbmVfbnVtYmVyPy50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkgfHxcclxuICAgICAgdXNlcj8ubW9iaWxlTnVtYmVyPy50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkgfHxcclxuICAgICAgXCJcIjtcclxuICAgIGNvbnN0IGJpZENvZGUgPSB1c2VyPy5iaWRfcmVxdWVzdF9jb2RlPy50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkgfHwgXCJcIjtcclxuICAgIHJldHVybiAoXHJcbiAgICAgIGZ1bGxOYW1lLmluY2x1ZGVzKGJpZERyYXdlclNlYXJjaC50b0xvd2VyQ2FzZSgpKSB8fFxyXG4gICAgICB0aWNrZXQuaW5jbHVkZXMoYmlkRHJhd2VyU2VhcmNoLnRvTG93ZXJDYXNlKCkpIHx8XHJcbiAgICAgIHBob25lLmluY2x1ZGVzKGJpZERyYXdlclNlYXJjaC50b0xvd2VyQ2FzZSgpKSB8fFxyXG4gICAgICBiaWRDb2RlLmluY2x1ZGVzKGJpZERyYXdlclNlYXJjaC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgKTtcclxuICB9KTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xvc2VNb2RhbCA9ICgpID0+IHtcclxuICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICBzZXRTaG93QmlkRHJhd2VyKGZhbHNlKTtcclxuICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICBzZXRCaWRSZXF1ZXN0cyhbXSk7XHJcbiAgICBzZXRCaWREcmF3ZXJTZWFyY2goXCJcIik7XHJcbiAgICBzZXRTZWxlY3RlZEdyb3VwSWQoXCJcIik7XHJcbiAgICBzZXRHcm91cEluZm8oe30pO1xyXG4gICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICBzZXREcmF3ZXJUYWIoXCJiaWRyZXF1ZXN0c1wiKTtcclxuICAgIHNldEZvcm1EYXRhKHtcclxuICAgICAgYXVjdGlvbl9jb2RlOiBcIlwiLFxyXG4gICAgICBncm91cF9pZDogXCJcIixcclxuICAgICAgdXNlcl9pZDogXCJcIixcclxuICAgICAgdGlja2V0OiBcIlwiLFxyXG4gICAgICBiaWRfYW1vdW50OiBcIlwiLFxyXG4gICAgICBjb21taXNzaW9uOiBcIlwiLFxyXG4gICAgICB3aW5fYW1vdW50OiBcIlwiLFxyXG4gICAgICBkaXZpZGVudDogXCJcIixcclxuICAgICAgZGl2aWRlbnRfaGVhZDogXCJcIixcclxuICAgICAgcGF5YWJsZTogXCJcIixcclxuICAgICAgYXVjdGlvbl9kYXRlOiBcIlwiLFxyXG4gICAgICBuZXh0X2RhdGU6IFwiXCIsXHJcbiAgICAgIGdyb3VwX3R5cGU6IFwiXCIsXHJcbiAgICAgIGF1Y3Rpb25fdHlwZTogXCJub3JtYWxcIixcclxuICAgICAgYmlkX3JlcXVlc3RfaWQ6IFwiXCIsXHJcbiAgICB9KTtcclxuICAgIHNldElzQXVjdGlvbkNvbXBsZXRlZChmYWxzZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xvc2VCaWREcmF3ZXIgPSAoKSA9PiB7XHJcbiAgICBzZXRTaG93QmlkRHJhd2VyKGZhbHNlKTtcclxuICB9O1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKFxyXG4gICAgICBwcmVBdWN0aW9uR3JvdXBzLmxlbmd0aCA+IDAgJiZcclxuICAgICAgIXByZUF1Y3Rpb25TZWxlY3RlZEdyb3VwSWRcclxuICAgICkge1xyXG4gICAgICBzZXRQcmVBdWN0aW9uU2VsZWN0ZWRHcm91cElkKHByZUF1Y3Rpb25Hcm91cHNbMF0uX2lkKTtcclxuICAgICAgaGFuZGxlUHJlQXVjdGlvbkdyb3VwQ2hhbmdlKHByZUF1Y3Rpb25Hcm91cHNbMF0uX2lkKTtcclxuICAgIH1cclxuICB9LCBbcHJlQXVjdGlvbkdyb3Vwc10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVTd2l0Y2hUb0Vucm9sbGVkID0gKCkgPT4ge1xyXG4gICAgc2V0RHJhd2VyVGFiKFwiZW5yb2xsZWRcIik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlU3dpdGNoVG9CaWRSZXF1ZXN0cyA9ICgpID0+IHtcclxuICAgIHNldERyYXdlclRhYihcImJpZHJlcXVlc3RzXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN3aXRjaFRvQWR2YW5jZVBheW91dHMgPSAoKSA9PiB7XHJcbiAgICBzZXREcmF3ZXJUYWIoXCJhZHZhbmNlUGF5b3V0XCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVZpZXdUcmFuc2FjdGlvbiA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBhIGdyb3VwIGZpcnN0XCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0TG9hZGluZ1RyYW5zYWN0aW9uKHRydWUpO1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvYXVjdGlvbi9nZXQtdXNlci1pbmZvLWJ5LWdyb3VwLyR7c2VsZWN0ZWRHcm91cElkfWAsXHJcbiAgICAgICk7XHJcbiAgICAgIGNvbnN0IGRhdGEgPSByZXNwb25zZS5kYXRhO1xyXG4gICAgICBpZiAoZGF0YS5zdGF0dXMgPT09IHRydWUpIHtcclxuICAgICAgICBzZXRUcmFuc2FjdGlvbkRhdGEoZGF0YSk7XHJcbiAgICAgICAgc2V0U2hvd1RyYW5zYWN0aW9uTW9kYWwodHJ1ZSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gSGFuZGxlIGRpZmZlcmVudCBlcnJvciBjYXNlc1xyXG4gICAgICAgIGxldCBlcnJvck1lc3NhZ2UgPSBkYXRhLm1lc3NhZ2UgfHwgXCJObyBkYXRhIGZvdW5kXCI7XHJcblxyXG4gICAgICAgIGlmIChkYXRhLmVycm9yICYmIGRhdGEuZXJyb3IuaW5jbHVkZXMoXCJmdWxsX25hbWVcIikpIHtcclxuICAgICAgICAgIGVycm9yTWVzc2FnZSA9IFwiU29tZSB1c2VyIGRhdGEgaXMgY29ycnVwdGVkLiBQbGVhc2UgY29udGFjdCBzdXBwb3J0LlwiO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IGVycm9yTWVzc2FnZSxcclxuICAgICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlciBpbmZvOlwiLCBlcnJvcik7XHJcbiAgICAgIGxldCBlcnJvck1lc3NhZ2UgPSBcIkZhaWxlZCB0byBmZXRjaCB1c2VyIGluZm9ybWF0aW9uXCI7XHJcblxyXG4gICAgICBpZiAoZXJyb3IucmVzcG9uc2U/LmRhdGE/LmVycm9yKSB7XHJcbiAgICAgICAgZXJyb3JNZXNzYWdlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5lcnJvcjtcclxuICAgICAgfSBlbHNlIGlmIChlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSkge1xyXG4gICAgICAgIGVycm9yTWVzc2FnZSA9IGVycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZTtcclxuICAgICAgfVxyXG5cclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogZXJyb3JNZXNzYWdlLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nVHJhbnNhY3Rpb24oZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGZldGNoUmVjZW50QXVjdGlvbnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIW5hdmlnYXRvci5vbkxpbmUpIHtcclxuICAgICAgc2V0SGFzRmV0Y2hlZCh0cnVlKTtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgc2V0TG9hZGluZ1JlY2VudChmYWxzZSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIC8vIHNldExvYWRpbmdSZWNlbnQodHJ1ZSk7XHJcbiAgICAvLyBzZXRIYXNGZXRjaGVkKGZhbHNlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi92MS9hZG1pbi9hdWN0aW9ucy9yZWNlbnRcIik7XHJcbiAgICAgIC8vIGNvbnNvbGUubG9nKFwiUmVjZW50IGF1Y3Rpb25zIHJlc3BvbnNlOlwiLCByZXNwb25zZS5kYXRhKTtcclxuXHJcbiAgICAgIGNvbnN0IGF1Y3Rpb25zRGF0YSA9IHJlc3BvbnNlLmRhdGE/LmRhdGEgfHwgcmVzcG9uc2UuZGF0YTtcclxuXHJcbiAgICAgIGlmIChcclxuICAgICAgICBhdWN0aW9uc0RhdGEgJiZcclxuICAgICAgICBBcnJheS5pc0FycmF5KGF1Y3Rpb25zRGF0YSkgJiZcclxuICAgICAgICBhdWN0aW9uc0RhdGEubGVuZ3RoID4gMFxyXG4gICAgICApIHtcclxuICAgICAgICBzZXRSZWNlbnRBdWN0aW9ucyhhdWN0aW9uc0RhdGEpO1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSBhdWN0aW9uc0RhdGEubWFwKChhdWN0aW9uLCBpbmRleCkgPT4gKHtcclxuICAgICAgICAgIF9pZDogYXVjdGlvbi5faWQsXHJcbiAgICAgICAgICBpZDogaW5kZXggKyAxLFxyXG4gICAgICAgICAgYXVjdGlvbl9jb2RlOiBhdWN0aW9uPy5hdWN0aW9uX2NvZGUsXHJcbiAgICAgICAgICBhdWN0aW9uX2RhdGU6XHJcbiAgICAgICAgICAgIGF1Y3Rpb24/LmF1Y3Rpb25fZGF0ZT8uc3BsaXQoXCJUXCIpWzBdIHx8IGF1Y3Rpb24/LmF1Y3Rpb25fZGF0ZSxcclxuICAgICAgICAgIGdyb3VwX25hbWU6IGF1Y3Rpb24uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIGdyb3VwX3ZhbHVlOiBhdWN0aW9uLmdyb3VwX2lkPy5ncm91cF92YWx1ZSB8fCBcIk4vQVwiLFxyXG4gICAgICAgICAgbmFtZTogYXVjdGlvbi51c2VyX2lkPy5mdWxsX25hbWUgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHBob25lX251bWJlcjogYXVjdGlvbi51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCJOL0FcIixcclxuICAgICAgICAgIHRpY2tldDogYXVjdGlvbj8udGlja2V0LFxyXG4gICAgICAgICAgYmlkX2Ftb3VudDpcclxuICAgICAgICAgICAgKHBhcnNlSW50KGF1Y3Rpb24uZGl2aWRlbnQpIHx8IDApICtcclxuICAgICAgICAgICAgKHBhcnNlSW50KGF1Y3Rpb24uY29tbWlzc2lvbikgfHwgMCksXHJcbiAgICAgICAgICBhbW91bnQ6IGF1Y3Rpb24/Lndpbl9hbW91bnQsXHJcbiAgICAgICAgICBhdWN0aW9uX3R5cGU6XHJcbiAgICAgICAgICAgIGF1Y3Rpb24/LmF1Y3Rpb25fdHlwZT8uY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgK1xyXG4gICAgICAgICAgICBhdWN0aW9uPy5hdWN0aW9uX3R5cGU/LnNsaWNlKDEpICtcclxuICAgICAgICAgICAgXCIgQXVjdGlvblwiLFxyXG4gICAgICAgICAgc3RhdHVzOiAhYXVjdGlvbj8uaXNQcml6ZWRcclxuICAgICAgICAgICAgPyBcIlVuIFByaXplZFwiXHJcbiAgICAgICAgICAgIDogYXVjdGlvbj8uaXNQcml6ZWQgPT09IFwidHJ1ZVwiXHJcbiAgICAgICAgICAgICAgPyBcIlByaXplZFwiXHJcbiAgICAgICAgICAgICAgOiBcIlVuIFByaXplZFwiLFxyXG4gICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgbWVudT17e1xyXG4gICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIxXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVVcGRhdGVNb2RhbE9wZW4oYXVjdGlvbi5faWQsIGluZGV4ICsgMilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVNb2RhbE9wZW4oYXVjdGlvbi5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIHBsYWNlbWVudD1cImJvdHRvbUxlZnRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxJb01kTW9yZSBjbGFzc05hbWU9XCJ0ZXh0LWJvbGRcIiAvPlxyXG4gICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICB9KSk7XHJcbiAgICAgICAgc2V0VGFibGVBdWN0aW9ucyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBzZXRSZWNlbnRBdWN0aW9ucyhbXSk7XHJcbiAgICAgICAgc2V0VGFibGVBdWN0aW9ucyhbXSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyByZWNlbnQgYXVjdGlvbnM6XCIsIGVycm9yKTtcclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTpcclxuICAgICAgICAgIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IFwiRmFpbGVkIHRvIGZldGNoIHJlY2VudCBhdWN0aW9uc1wiLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFRhYmxlQXVjdGlvbnMoW10pO1xyXG4gICAgICBzZXRIYXNGZXRjaGVkKHRydWUpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZ1JlY2VudChmYWxzZSk7XHJcbiAgICAgIHNldEhhc0ZldGNoZWQodHJ1ZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBPdmVydmlldyA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBhIGdyb3VwIGZpcnN0XCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0TG9hZGluZ0dyb3VwT3ZlcnZpZXcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9hdWN0aW9uL2dldC1hdWN0aW9uLWluZm8vJHtzZWxlY3RlZEdyb3VwSWR9YCxcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgZGF0YSA9IHJlc3BvbnNlLmRhdGE7XHJcbiAgICAgIGlmIChkYXRhLnN0YXR1cyA9PT0gdHJ1ZSkge1xyXG4gICAgICAgIHNldEdyb3VwT3ZlcnZpZXdEYXRhKGRhdGEpO1xyXG4gICAgICAgIHNldHNob3dHcm91cE92ZXJ2aWV3TW9kYWwodHJ1ZSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgbGV0IGVycm9yTWVzc2FnZSA9IGRhdGEubWVzc2FnZSB8fCBcIk5vIGRhdGEgZm91bmRcIjtcclxuXHJcbiAgICAgICAgaWYgKGRhdGEuZXJyb3IgJiYgZGF0YS5lcnJvci5pbmNsdWRlcyhcImZ1bGxfbmFtZVwiKSkge1xyXG4gICAgICAgICAgZXJyb3JNZXNzYWdlID0gXCJTb21lIHVzZXIgZGF0YSBpcyBjb3JydXB0ZWQuIFBsZWFzZSBjb250YWN0IHN1cHBvcnQuXCI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgICAgbWVzc2FnZTogZXJyb3JNZXNzYWdlLFxyXG4gICAgICAgICAgdHlwZTogXCJ3YXJuaW5nXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBvdmVydmlldzpcIiwgZXJyb3IpO1xyXG4gICAgICBsZXQgZXJyb3JNZXNzYWdlID0gXCJGYWlsZWQgdG8gZmV0Y2ggZ3JvdXAgb3ZlcnZpZXdcIjtcclxuXHJcbiAgICAgIGlmIChlcnJvci5yZXNwb25zZT8uZGF0YT8uZXJyb3IpIHtcclxuICAgICAgICBlcnJvck1lc3NhZ2UgPSBlcnJvci5yZXNwb25zZS5kYXRhLmVycm9yO1xyXG4gICAgICB9IGVsc2UgaWYgKGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlKSB7XHJcbiAgICAgICAgZXJyb3JNZXNzYWdlID0gZXJyb3IucmVzcG9uc2UuZGF0YS5tZXNzYWdlO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBlcnJvck1lc3NhZ2UsXHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmdHcm91cE92ZXJ2aWV3KGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVQYXlvdXRJbmZvcm1hdGlvbiA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWRHcm91cElkKSB7XHJcbiAgICAgIGFsZXJ0KFwiUGxlYXNlIHNlbGVjdCBhIGdyb3VwIGZpcnN0XCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgc2V0TG9hZGluZ1BheW91dCh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcclxuICAgICAgICBgL2F1Y3Rpb24vZ2V0LXBheW91dC1ieS1ncm91cC8ke3NlbGVjdGVkR3JvdXBJZH1gLFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCBkYXRhID0gcmVzcG9uc2UuZGF0YTtcclxuXHJcbiAgICAgIGlmIChkYXRhLnN0YXR1cyA9PT0gdHJ1ZSkge1xyXG4gICAgICAgIHNldFBheW91dERhdGEoZGF0YS5kYXRhIHx8IFtdKTtcclxuICAgICAgICBzZXRTaG93UGF5b3V0TW9kYWwodHJ1ZSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgbGV0IGVycm9yTWVzc2FnZSA9IGRhdGEubWVzc2FnZSB8fCBcIk5vIGRhdGEgZm91bmRcIjtcclxuXHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IGVycm9yTWVzc2FnZSxcclxuICAgICAgICAgIHR5cGU6IFwid2FybmluZ1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgcGF5b3V0IGluZm9ybWF0aW9uOlwiLCBlcnJvcik7XHJcbiAgICAgIGxldCBlcnJvck1lc3NhZ2UgPSBcIkZhaWxlZCB0byBmZXRjaCBwYXlvdXQgaW5mb3JtYXRpb25cIjtcclxuXHJcbiAgICAgIGlmIChlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSkge1xyXG4gICAgICAgIGVycm9yTWVzc2FnZSA9IGVycm9yLnJlc3BvbnNlLmRhdGEubWVzc2FnZTtcclxuICAgICAgfVxyXG5cclxuICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgbWVzc2FnZTogZXJyb3JNZXNzYWdlLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nUGF5b3V0KGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyPXtvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgIHZpc2liaWxpdHk9e3RydWV9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgPFNpZGViYXIgLz5cclxuXHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnRcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICB7LyogQWRkIEF1Y3Rpb24gTW9kYWwgLSBDZW50ZXIgKi99XHJcbiAgICAgICAgICA8TW9kYWwgaXNWaXNpYmxlPXtzaG93TW9kYWx9IG9uQ2xvc2U9e2hhbmRsZUNsb3NlTW9kYWx9PlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIG1iLTRcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+QWRkIEF1Y3Rpb248L2gzPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVWaWV3VHJhbnNhY3Rpb259XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYm9yZGVyLTIgYm9yZGVyLWdyZWVuLTUwMCB0ZXh0LWdyZWVuLTYwMCBob3ZlcjpiZy1ncmVlbi01MDAgaG92ZXI6dGV4dC13aGl0ZSBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNCBweS0yIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8VXNlcnMgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgQ3VzdG9tZXIgU3VtbWFyeVxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVHcm91cE92ZXJ2aWV3fVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlci0yIGJvcmRlci1wdXJwbGUtNTAwIHRleHQtcHVycGxlLTYwMCBob3ZlcjpiZy1wdXJwbGUtNTAwIGhvdmVyOnRleHQtd2hpdGUgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTQgcHktMiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBpZUNoYXJ0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIEdyb3VwIE92ZXJ2aWV3XHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVBheW91dEluZm9ybWF0aW9ufVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJvcmRlci0yIGJvcmRlci1vcmFuZ2UtNTAwIHRleHQtb3JhbmdlLTYwMCBob3ZlcjpiZy1vcmFuZ2UtNTAwIGhvdmVyOnRleHQtd2hpdGUgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTQgcHktMiB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZpbGVUZXh0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIFBheW91dCBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTVcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgICAgey8qIFJlc3Qgb2YgeW91ciBmb3JtIHJlbWFpbnMgdGhlIHNhbWUgKi99XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBHcm91cCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsYH1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBTZWFyY2ggZ3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkR3JvdXBJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlR3JvdXAodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgID8udG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+e2Vycm9ycy5ncm91cH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7YXVjdGlvblN0YXR1c0xvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1ibHVlLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIENoZWNraW5nIGF1Y3Rpb24gc3RhdHVzLi4uXHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAge2lzQXVjdGlvbkNvbXBsZXRlZCA/IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXJlZC0yMDAgYmctcmVkLTUwIHAtNCBzaGFkb3ctc21cIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaC05IHctOSBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLXJlZC0xMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGdcIj7imqDvuI88L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEF1Y3Rpb24gQWxyZWFkeSBDb21wbGV0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyBsZWFkaW5nLTUgdGV4dC1yZWQtNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRoaXMgZ3JvdXDigJlzIGF1Y3Rpb24gaGFzIGFscmVhZHkgYmVlbiBjb21wbGV0ZWQuIE5ldyBhdWN0aW9ucyBjYW5ub3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmUgYWRkZWQgdG8gdGhpcyBncm91cC5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIFZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF92YWx1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2dyb3VwSW5mby5ncm91cF92YWx1ZSB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYmx1ZS00MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGdyb3VwSW5mbz8uZ3JvdXBfdmFsdWUgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBHcm91cCBJbnN0YWxsbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2luc3RhbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtncm91cEluZm8uZ3JvdXBfaW5zdGFsbCB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYmx1ZS00MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGdyb3VwSW5mbz8uZ3JvdXBfaW5zdGFsbCB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIHtncm91cEluZm8uZ3JvdXBfdHlwZSA9PT0gXCJkb3VibGVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIFR5cGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhdWN0aW9uX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5hdWN0aW9uX3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIm5vcm1hbFwiPk5vcm1hbCBBdWN0aW9uPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImZyZWVcIj5GcmVlIEF1Y3Rpb248L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYXVjdGlvbl90eXBlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0xIHRleHQtc20gdGV4dC1yZWQtNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmF1Y3Rpb25fdHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHtpc0NvbW1lbmNlbWVudERvbmUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNwaW4gc3Bpbm5pbmc9e2xvYWRpbmd9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtsb2FkaW5nID8gXCJvcGFjaXR5LTUwIHBvaW50ZXItZXZlbnRzLW5vbmVcIiA6IFwiXCJ9PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVycyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsYH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBTZWFyY2ggQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ1c2VyX2lkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS51c2VyX2lkICYmIGZvcm1EYXRhLnRpY2tldFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGAke2Zvcm1EYXRhLnVzZXJfaWR9LSR7Zm9ybURhdGEudGlja2V0fWBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZVVzZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbj8uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPy50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFVzZXJzLm1hcChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICh1c2VyKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyPy51c2VyX2lkPy5faWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2Ake3VzZXIudXNlcl9pZC5faWR9LSR7dXNlci50aWNrZXRzfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17YCR7dXNlci51c2VyX2lkLl9pZH0tJHt1c2VyLnRpY2tldHN9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YCR7dXNlci51c2VyX2lkLmZ1bGxfbmFtZX0gfCAke3VzZXIudGlja2V0c31gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jdXN0b21lciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jdXN0b21lcn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgbXQtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJpZCBBbW91bnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJiaWRfYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYmlkX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgdGhlIEJpZCBBbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYmlkX2Ftb3VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5iaWRfYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ibHVlLTQwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGE/LmJpZF9hbW91bnQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29tbWlzc2lvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY29tbWlzc2lvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuY29tbWlzc2lvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWJsdWUtNDAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhPy5jb21taXNzaW9uIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFdpbm5pbmcgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJ3aW5fYW1vdW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS53aW5fYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYmx1ZS00MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGE/Lndpbl9hbW91bnQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00IG10LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGl2aWRlbnRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImRpdmlkZW50XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5kaXZpZGVudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWJsdWUtNDAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhPy5kaXZpZGVudCB8fCAwKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEaXZpZGVudCBwZXIgSGVhZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZGl2aWRlbnRfaGVhZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuZGl2aWRlbnRfaGVhZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWJsdWUtNDAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGZvcm1EYXRhPy5kaXZpZGVudF9oZWFkIHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtdC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5leHQgUGF5YWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBheWFibGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5wYXlhYmxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ibHVlLTQwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoZm9ybURhdGE/LnBheWFibGUgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TcGluPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXgtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYXVjdGlvbl9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYXVjdGlvbl9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hdWN0aW9uX2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMuYXVjdGlvbl9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIFRpbWU8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRpbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhdWN0aW9uX3RpbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5hdWN0aW9uX3RpbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmF1Y3Rpb25fdGltZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hdWN0aW9uX3RpbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTmV4dCBBdWN0aW9uIERhdGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibmV4dF9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubmV4dF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5uZXh0X2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtlcnJvcnMubmV4dF9kYXRlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBOZXh0IEF1Y3Rpb24gVGltZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRpbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJuZXh0X2F1Y3Rpb25fdGltZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5leHRfYXVjdGlvbl90aW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5uZXh0X2F1Y3Rpb25fdGltZSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5uZXh0X2F1Y3Rpb25fdGltZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGh0bWxUeXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbG9hZGluZz17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvM1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFNhdmUgQXVjdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcblxyXG4gICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICAgIHsvKiBCaWQgUmVxdWVzdHMgRHJhd2VyICovfVxyXG4gICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2BmaXhlZCB0b3AtMCByaWdodC0wIGgtZnVsbCB3LVs0MjBweF0gYmctd2hpdGUgc2hhZG93LTJ4bCB6LVs5OTk5XSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXQgZmxleCBmbGV4LWNvbCBib3JkZXItbCBib3JkZXItZ3JheS0yMDAgJHtzaG93QmlkRHJhd2VyID8gXCJ0cmFuc2xhdGUteC0wXCIgOiBcInRyYW5zbGF0ZS14LWZ1bGxcIlxyXG4gICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICBzdHlsZT17eyBwb2ludGVyRXZlbnRzOiBzaG93QmlkRHJhd2VyID8gXCJhdXRvXCIgOiBcIm5vbmVcIiB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcHktNCBib3JkZXItYiBib3JkZXItZ3JheS0yMDAgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNTAgdG8td2hpdGVcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggYmctYmx1ZS02MDAgcm91bmRlZC1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGYVVzZXJDaGVjayBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQtc21cIiAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2RyYXdlclRhYiA9PT0gXCJiaWRyZXF1ZXN0c1wiID8gXCJCaWQgUmVxdWVzdHNcIiA6IFwiQWR2YW5jZSBQYXlvdXRzXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cEluZm8uZ3JvdXBfbmFtZSB8fCBcIlNlbGVjdCBhIGdyb3VwXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgey8qIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQmlkIFJlcXVlc3RzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9oND5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cEluZm8uZ3JvdXBfbmFtZSB8fCBcIlNlbGVjdCBhIGdyb3VwXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xvc2VCaWREcmF3ZXJ9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOCBoLTggZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGhvdmVyOmJnLWdyYXktMTAwIHRleHQtZ3JheS00MDAgaG92ZXI6dGV4dC1ncmF5LTYwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIDxYIHNpemU9ezE4fSAvPlxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0yIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xIGJnLWdyYXktMjAwIHJvdW5kZWQtbGcgcC0xXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVN3aXRjaFRvQmlkUmVxdWVzdHN9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBweS0yIHB4LTMgcm91bmRlZC1tZCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsICR7ZHJhd2VyVGFiID09PSBcImJpZHJlcXVlc3RzXCJcclxuICAgICAgICAgICAgICAgICAgICA/IFwiYmctd2hpdGUgdGV4dC1ibHVlLTcwMCBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBCaWQgUmVxdWVzdHMgKHtiaWRSZXF1ZXN0cy5sZW5ndGh9KVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PiAqL31cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0yIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMCBiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0xIGJnLWdyYXktMjAwIHJvdW5kZWQtbGcgcC0xXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVN3aXRjaFRvQmlkUmVxdWVzdHN9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBweS0yIHB4LTMgcm91bmRlZC1tZCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsICR7ZHJhd2VyVGFiID09PSBcImJpZHJlcXVlc3RzXCJcclxuICAgICAgICAgICAgICAgICAgICA/IFwiYmctd2hpdGUgdGV4dC1ibHVlLTcwMCBzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJ0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBCaWQgUmVxdWVzdHMgKHtiaWRSZXF1ZXN0cy5sZW5ndGh9KVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVN3aXRjaFRvQWR2YW5jZVBheW91dHN9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBweS0yIHB4LTMgcm91bmRlZC1tZCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsICR7ZHJhd2VyVGFiID09PSBcImFkdmFuY2VQYXlvdXRcIlxyXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy13aGl0ZSB0ZXh0LWJsdWUtNzAwIHNoYWRvdy1zbVwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcInRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIEFkdmFuY2UgUGF5b3V0cyAoe2FkdmFuY2VQYXlvdXRzLmxlbmd0aH0pXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7ZHJhd2VyVGFiID09PSBcImJpZHJlcXVlc3RzXCIgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0zIGJvcmRlci1iIGJvcmRlci1ncmF5LTEwMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxyXG4gICAgICAgICAgICAgICAgICA8U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0zIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMiB0ZXh0LWdyYXktNDAwXCJcclxuICAgICAgICAgICAgICAgICAgICBzaXplPXsxNn1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGJ5IG5hbWUsIHRpY2tldCwgcGhvbmUsIGNvZGUuLi5cIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtiaWREcmF3ZXJTZWFyY2h9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRCaWREcmF3ZXJTZWFyY2goZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC05IHByLTQgcHktMiB0ZXh0LXNtIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgYmctZ3JheS01MFwiXHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IGUuc3RvcFByb3BhZ2F0aW9uKCl9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0b1wiPlxyXG4gICAgICAgICAgICAgIHtsb2FkaW5nQmlkUmVxdWVzdHMgPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGgtZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IGRyYXdlclRhYiA9PT0gXCJiaWRyZXF1ZXN0c1wiID8gKFxyXG4gICAgICAgICAgICAgICAgZmlsdGVyZWRCaWRSZXF1ZXN0cy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBzcGFjZS15LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRCaWRSZXF1ZXN0cy5tYXAoKGJpZFJlcXVlc3QsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmdWxsTmFtZSA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJpZFJlcXVlc3Q/LnN1YnNjcmliZXJEZXRhaWxzPy5mdWxsX25hbWUgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmlkUmVxdWVzdD8uc3Vic2NyaWJlck5hbWUgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgXCJVbmtub3duXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwaG9uZSA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJpZFJlcXVlc3Q/LnN1YnNjcmliZXJEZXRhaWxzPy5waG9uZV9udW1iZXIgfHxcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmlkUmVxdWVzdD8ubW9iaWxlTnVtYmVyIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiTi9BXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCB0aWNrZXQgPSBiaWRSZXF1ZXN0Py50aWNrZXROdW1iZXIgfHwgXCJOL0FcIjtcclxuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGJpZENvZGUgPSBiaWRSZXF1ZXN0Py5iaWRfcmVxdWVzdF9jb2RlIHx8IFwiLVwiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3RhdHVzID0gYmlkUmVxdWVzdD8uc3RhdHVzIHx8IFwiUGVuZGluZ1wiO1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNTZWxlY3RlZCA9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLnVzZXJfaWQgPT09IGJpZFJlcXVlc3Quc3Vic2NyaWJlcklkICYmXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLnRpY2tldCA9PT0gYmlkUmVxdWVzdC50aWNrZXROdW1iZXI7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgZGF5c0FnbyA9IGJpZFJlcXVlc3Q/LmRheXNBZ29cclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBNYXRoLmZsb29yKGJpZFJlcXVlc3QuZGF5c0FnbylcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNOZXcgPSBkYXlzQWdvIDw9IDI7XHJcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpc09sZCA9IGRheXNBZ28gPiA3O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2JpZFJlcXVlc3QuX2lkIHx8IGluZGV4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUJpZFJlcXVlc3RTZWxlY3QoYmlkUmVxdWVzdCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBncm91cCAke2lzU2VsZWN0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTUwIGJvcmRlci1ibHVlLTUwMCBzaGFkb3ctbWQgcmluZy0xIHJpbmctYmx1ZS0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXdoaXRlIGJvcmRlci1ncmF5LTIwMCBob3ZlcjpiZy1ibHVlLTUwIGhvdmVyOmJvcmRlci1ibHVlLTMwMCBob3ZlcjpzaGFkb3ctc21cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy0xMCBoLTEwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXdoaXRlIHRleHQtc20gZm9udC1zZW1pYm9sZCBmbGV4LXNocmluay0wICR7aXNTZWxlY3RlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLWdyYXktNDAwIGdyb3VwLWhvdmVyOmJnLWJsdWUtNTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Z1bGxOYW1lPy5jaGFyQXQoMCk/LnRvVXBwZXJDYXNlKCkgfHwgXCJVXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtZ3JheS05MDAgdGV4dC1zbSB0cnVuY2F0ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Z1bGxOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1bMTBweF0gZm9udC1tZWRpdW0gcHgtMS41IHB5LTAuNSByb3VuZGVkICR7c3RhdHVzID09PSBcIkFjY2VwdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c3RhdHVzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXNOZXcgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgcHgtMS41IHB5LTAuNSByb3VuZGVkIGJnLWJsdWUtNjAwIHRleHQtd2hpdGUgYW5pbWF0ZS1wdWxzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBORVdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogaXNPbGQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1lZGl1bSBweC0xLjUgcHktMC41IHJvdW5kZWQgYmctb3JhbmdlLTEwMCB0ZXh0LW9yYW5nZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2RheXNBZ299ZCBhZ29cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tZWRpdW0gcHgtMS41IHB5LTAuNSByb3VuZGVkIGJnLWdyYXktMTAwIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2RheXNBZ299ZCBhZ29cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDb2RlOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2JpZENvZGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaWNrZXQ6e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwaG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWVuZCBnYXAtMSBmbGV4LXNocmluay0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdGV4dC1bMTBweF0gZm9udC1tZWRpdW0gcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsICR7aXNTZWxlY3RlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWJsdWUtNjAwIHRleHQtd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBiaWRSZXF1ZXN0LmVsaWdpYmlsaXR5U3RhdHVzID09PVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImVsaWdpYmxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1vcmFuZ2UtMTAwIHRleHQtb3JhbmdlLTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpc1NlbGVjdGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiU2VsZWN0ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBiaWRSZXF1ZXN0LmVsaWdpYmlsaXR5U3RhdHVzID09PSBcImVsaWdpYmxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkVsaWdpYmxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIkhhcyBEdWVcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmFDaGV2cm9uUmlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LXhzICR7aXNTZWxlY3RlZCA/IFwidGV4dC1ibHVlLTYwMFwiIDogXCJ0ZXh0LWdyYXktMzAwIGdyb3VwLWhvdmVyOnRleHQtYmx1ZS00MDBcIn1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICAgICAgICB9KX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGgtZnVsbCB0ZXh0LWdyYXktNDAwIHAtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdmdcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTQgaC0xNCBtYi0zIHRleHQtZ3JheS0zMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjEuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNMTcgMjBoNXYtMmEzIDMgMCAwMC01LjM1Ni0xLjg1N00xNyAyMEg3bTEwIDB2LTJjMC0uNjU2LS4xMjYtMS4yODMtLjM1Ni0xLjg1N003IDIwSDJ2LTJhMyAzIDAgMDE1LjM1Ni0xLjg1N003IDIwdi0yYzAtLjY1Ni4xMjYtMS4yODMuMzU2LTEuODU3bTAgMGE1LjAwMiA1LjAwMiAwIDAxOS4yODggME0xNSA3YTMgMyAwIDExLTYgMCAzIDMgMCAwMTYgMHpcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtY2VudGVyIGZvbnQtbWVkaXVtXCI+Tm8gYmlkIHJlcXVlc3RzIGZvdW5kPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1jZW50ZXIgbXQtMVwiPk5vIGN1c3RvbWVycyBoYXZlIHJlcXVlc3RlZCBiaWRzIGZvciB0aGlzIGdyb3VwIHlldDwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgKSA6IGRyYXdlclRhYiA9PT0gXCJhZHZhbmNlUGF5b3V0XCIgPyAoXHJcbiAgICAgICAgICAgICAgICAvLyBBZHZhbmNlIFBheW91dHMgQ29udGVudFxyXG4gICAgICAgICAgICAgICAgYWR2YW5jZVBheW91dHMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXItY29sbGFwc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBzdGlja3kgdG9wLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5DdXN0b21lcjwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiB0ZXh0LWxlZnQgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwXCI+VGlja2V0PC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHRleHQtbGVmdCB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDBcIj5BbW91bnQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgdGV4dC1sZWZ0IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiPkRhdGU8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7YWR2YW5jZVBheW91dHMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtpdGVtLl9pZH0gY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS51c2VyX2lkPy5mdWxsX25hbWUgfHwgaXRlbS51c2VyX2lkPy5uYW1lIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJib3JkZXIgcC0yIHRleHQtc20gdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRpY2tldCB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwiYm9yZGVyIHAtMiB0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7cGFyc2VJbnQoaXRlbS5hbW91bnQgfHwgMCkudG9Mb2NhbGVTdHJpbmcoXCJlbi1JTlwiKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cImJvcmRlciBwLTIgdGV4dC1zbSB0ZXh0LWdyYXktNzAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucGF5X2RhdGUgPyBuZXcgRGF0ZShpdGVtLnBheV9kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoKSA6IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLWZ1bGwgdGV4dC1ncmF5LTQwMCBwLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgbWItMyB0ZXh0LWdyYXktMzAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIxLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkPVwiTTkgNUg3YTIgMiAwIDAwLTIgMnYxMmEyIDIgMCAwMDIgMmgxMGEyIDIgMCAwMDItMlY3YTIgMiAwIDAwLTItMmgtMk05IDVhMiAyIDAgMDAyIDJoMmEyIDIgMCAwMDItMk05IDVhMiAyIDAgMDEyLTJoMmEyIDIgMCAwMTIgMm0tNiA5aDNtLTMgNGgzbS02LTRoLjAxTTkgMTZoLjAxXCJcclxuICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWNlbnRlciBmb250LW1lZGl1bVwiPk5vIGFkdmFuY2UgcGF5b3V0cyBmb3VuZDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtY2VudGVyIG10LTFcIj5ObyBhZHZhbmNlIHBheW91dHMgaGF2ZSBiZWVuIG1hZGUgZm9yIHRoaXMgZ3JvdXAgeWV0PC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICApIDogbnVsbH1cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0zIGJnLWdyYXktNTAgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTUwMCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgQ2xpY2sgb24gYSBiaWQgcmVxdWVzdCB0byBzZWxlY3QgdGhlbSBmb3IgdGhpcyBhdWN0aW9uXHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNSBweS0zIGJnLWdyYXktNTAgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ncmF5LTUwMCB0ZXh0LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAge2RyYXdlclRhYiA9PT0gXCJiaWRyZXF1ZXN0c1wiXHJcbiAgICAgICAgICAgICAgICAgID8gXCJDbGljayBvbiBhIGJpZCByZXF1ZXN0IHRvIHNlbGVjdCB0aGVtIGZvciB0aGlzIGF1Y3Rpb25cIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiQWR2YW5jZSBwYXlvdXRzIGJlZm9yZSBhdWN0aW9uXCJ9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFVwZGF0ZX1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKX1cclxuICAgICAgICAgICAgd2lkdGg9XCI4MDBweFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgRWRpdCBBdWN0aW9uXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgICAgey8qIFNJIE5vIGFuZCBHcm91cCAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIFNJIE5vXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50VXBkYXRlR3JvdXA/LlNJX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgR3JvdXBcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRVcGRhdGVHcm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogR3JvdXAgVmFsdWUgYW5kIEluc3RhbGxtZW50ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgR3JvdXAgVmFsdWVcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRVcGRhdGVHcm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX3ZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ibHVlLTQwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFVwZGF0ZUdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWUgfHwgMCxcclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgR3JvdXAgSW5zdGFsbG1lbnRcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRVcGRhdGVHcm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX2luc3RhbGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWJsdWUtNDAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50VXBkYXRlR3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9pbnN0YWxsIHx8IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQXVjdGlvbiBUeXBlIChpZiBkb3VibGUgZ3JvdXApICovfVxyXG4gICAgICAgICAgICAgICAge2N1cnJlbnRVcGRhdGVHcm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX3R5cGUgPT09IFwiZG91YmxlXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQXVjdGlvbiBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFVwZGF0ZUdyb3VwPy5hdWN0aW9uX3R5cGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAuY2hhckF0KDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvVXBwZXJDYXNlKCkgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50VXBkYXRlR3JvdXA/LmF1Y3Rpb25fdHlwZS5zbGljZSgxKSArXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiIEF1Y3Rpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogQ3VzdG9tZXIgYW5kIFRpY2tldCAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50VXBkYXRlR3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVGlja2V0XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXJyZW50VXBkYXRlR3JvdXA/LnRpY2tldH1cclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBCaWQgQW1vdW50ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgQmlkIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgY3VycmVudFVwZGF0ZUdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWUgLVxyXG4gICAgICAgICAgICAgICAgICAgICAgY3VycmVudFVwZGF0ZUdyb3VwPy53aW5fYW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYmx1ZS00MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKFxyXG4gICAgICAgICAgICAgICAgICAgICAgY3VycmVudFVwZGF0ZUdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfdmFsdWUgLVxyXG4gICAgICAgICAgICAgICAgICAgICAgY3VycmVudFVwZGF0ZUdyb3VwPy53aW5fYW1vdW50IHx8IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIENvbW1pc3Npb24gYW5kIFdpbm5pbmcgQW1vdW50ICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgQ29tbWlzc2lvblxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y3VycmVudFVwZGF0ZUdyb3VwPy5jb21taXNzaW9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgcmVhZE9ubHlcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1ibHVlLTQwMCBtdC0xIGJsb2NrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhjdXJyZW50VXBkYXRlR3JvdXA/LmNvbW1pc3Npb24gfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgV2lubmluZyBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRVcGRhdGVHcm91cD8ud2luX2Ftb3VudH1cclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYmx1ZS00MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoY3VycmVudFVwZGF0ZUdyb3VwPy53aW5fYW1vdW50IHx8IDApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogRGl2aWRlbnQgYW5kIERpdmlkZW50IHBlciBIZWFkICovfVxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBzcGFjZS14LTRcIj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRGl2aWRlbnRcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRVcGRhdGVHcm91cD8uZGl2aWRlbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWJsdWUtNDAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKGN1cnJlbnRVcGRhdGVHcm91cD8uZGl2aWRlbnQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRGl2aWRlbnQgcGVyIEhlYWRcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRVcGRhdGVHcm91cD8uZGl2aWRlbnRfaGVhZH1cclxuICAgICAgICAgICAgICAgICAgICAgIHJlYWRPbmx5XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIHAtMi41XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYmx1ZS00MDAgbXQtMSBibG9ja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRVcGRhdGVHcm91cD8uZGl2aWRlbnRfaGVhZCB8fCAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgey8qIE5leHQgUGF5YWJsZSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIE5leHQgUGF5YWJsZVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRVcGRhdGVHcm91cD8ucGF5YWJsZX1cclxuICAgICAgICAgICAgICAgICAgICByZWFkT25seVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LWJsdWUtNDAwIG10LTEgYmxvY2tcIj5cclxuICAgICAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhjdXJyZW50VXBkYXRlR3JvdXA/LnBheWFibGUgfHwgMCl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBFZGl0YWJsZSBEYXRlcyAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEF1Y3Rpb24gRGF0ZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYXVjdGlvbl9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uYXVjdGlvbl9kYXRlPy5zcGxpdChcIlRcIilbMF0gfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBdWN0aW9uIFRpbWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRpbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImF1Y3Rpb25fdGltZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LmF1Y3Rpb25fdGltZSB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIE5leHQgQXVjdGlvbiBEYXRlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwibmV4dF9kYXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ubmV4dF9kYXRlPy5zcGxpdChcIlRcIilbMF0gfHwgXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgcC0yLjVcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5uZXh0X2RhdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm5leHRfZGF0ZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgTmV4dCBBdWN0aW9uIFRpbWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0aW1lXCJcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJuZXh0X2F1Y3Rpb25fdGltZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEubmV4dF9hdWN0aW9uX3RpbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlSW5wdXRDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBwLTIuNVwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLm5leHRfYXVjdGlvbl90aW1lICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5uZXh0X2F1Y3Rpb25fdGltZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy1ibHVlLTcwMCBob3ZlcjpiZy1ibHVlLTgwMCBib3JkZXItMiBib3JkZXItYmxhY2sgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLWJsdWUtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBVcGRhdGVcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgICB7LyogRGVsZXRlIE1vZGFsICovfVxyXG4gICAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsRGVsZXRlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgU3VyZSB3YW50IHRvIGRlbGV0ZSB0aGlzIEF1Y3Rpb24gP1xyXG4gICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAge2N1cnJlbnRHcm91cCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgICBvblN1Ym1pdD17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlQXVjdGlvbigpO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTZcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1ibHVlLTMwMCBmb250LW1lZGl1bSByb3VuZGVkLWxnIHRleHQtc20gcHgtNSBweS0yLjUgdGV4dC1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgRGVsZXRlXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgICA8TW9kYWxcclxuICAgICAgICAgICAgaXNWaXNpYmxlPXtzaG93VHJhbnNhY3Rpb25Nb2RhbH1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldFNob3dUcmFuc2FjdGlvbk1vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICBzZXRUcmFuc2FjdGlvbkRhdGEoW10pO1xyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICB3aWR0aD1cIjEwMDBweFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgVHJhbnNhY3Rpb24gRGV0YWlscyAte1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICB7dHJhbnNhY3Rpb25EYXRhPy5ncm91cD8uZ3JvdXBfbmFtZSB8fCBcIkdyb3VwXCJ9XHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogR3JvdXAgU3VtbWFyeSBDYXJkcyAqL31cclxuICAgICAgICAgICAgICB7dHJhbnNhY3Rpb25EYXRhPy5ncm91cCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTQgbWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWJsdWUtNTAgcm91bmRlZC1sZyBwLTQgYm9yZGVyIGJvcmRlci1ibHVlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ibHVlLTYwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgR3JvdXAgTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNhY3Rpb25EYXRhLmdyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi01MCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmVlbi02MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIFZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIOKCuXtudW1iZXJUb0luZGlhbldvcmRzKHRyYW5zYWN0aW9uRGF0YS5ncm91cC5ncm91cF92YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHtsb2FkaW5nVHJhbnNhY3Rpb24gPyAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHB5LTIwXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogdHJhbnNhY3Rpb25EYXRhPy51c2VycyAmJiB0cmFuc2FjdGlvbkRhdGEudXNlcnMubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIG1heC1oLVs1MDBweF0gb3ZlcmZsb3cteS1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHN0aWNreSB0b3AtMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgU0wgTm9cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgVGlja2V0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCB0byBiZSBQYWlkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBQYWlkIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgQmFsYW5jZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7LyogPHRoIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3RyYW5zYWN0aW9uRGF0YS51c2Vycy5tYXAoKHVzZXIsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpbmRleCArIDF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIudXNlcj8ubmFtZSB8fCBcIlVua25vd24gVXNlclwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyF1c2VyLnVzZXI/Lm5hbWUgJiZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlci51c2VyPy5uYW1lID09PSBcIlVua25vd24gVXNlclwiICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIHRleHQteHMgdGV4dC15ZWxsb3ctNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoSW52YWxpZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIudXNlcj8ucGhvbmUgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci50aWNrZXQgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7KHVzZXIudG90YWxzPy50b3RhbEJlUGFpZCB8fCAwKS50b0xvY2FsZVN0cmluZygpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCB0ZXh0LXNtIHRleHQtZ3JlZW4tNjAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7KHVzZXIudG90YWxzPy5wYWlkIHx8IDApLnRvTG9jYWxlU3RyaW5nKCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIHRleHQtc20gZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHVzZXIudG90YWxzPy5iYWxhbmNlIHx8IDApID4gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1ncmVlbi02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXsodXNlci50b3RhbHM/LmJhbGFuY2UgfHwgMCkudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMiBpbmxpbmUtZmxleCB0ZXh0LXhzIGxlYWRpbmctNSBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHVzZXIudG90YWxzPy5iYWxhbmNlIHx8IDApID09PSAwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICh1c2VyLnRvdGFscz8uYmFsYW5jZSB8fCAwKSA+IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiYmcteWVsbG93LTEwMCB0ZXh0LXllbGxvdy04MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJiZy1ibHVlLTEwMCB0ZXh0LWJsdWUtODAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsodXNlci50b3RhbHM/LmJhbGFuY2UgfHwgMCkgPT09IDBcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gXCJQYWlkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogKHVzZXIudG90YWxzPy5iYWxhbmNlIHx8IDApID4gMFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwiUGVuZGluZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCJBZHZhbmNlZFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPiAqL31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXgtYXV0byBoLTEyIHctMTIgdGV4dC1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNMjAgMTNWNmEyIDIgMCAwMC0yLTJINmEyIDIgMCAwMC0yIDJ2N20xNiAwdjVhMiAyIDAgMDEtMiAySDZhMiAyIDAgMDEtMi0ydi01bTE2IDBoLTIuNTg2YTEgMSAwIDAwLS43MDcuMjkzbC0yLjQxNCAyLjQxNGExIDEgMCAwMS0uNzA3LjI5M2gtMy4xNzJhMSAxIDAgMDEtLjcwNy0uMjkzbC0yLjQxNC0yLjQxNEExIDEgMCAwMDYuNTg2IDEzSDRcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBObyBkYXRhIGZvdW5kXHJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTm8gdXNlcnMgZm91bmQgaW4gdGhpcyBncm91cC5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L01vZGFsPlxyXG5cclxuICAgICAgICAgIHsvKiBHcm91cCBPdmVydmlldyBNb2RhbCAqL31cclxuICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dHcm91cE92ZXJ2aWV3TW9kYWx9XHJcbiAgICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgICBzZXRzaG93R3JvdXBPdmVydmlld01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgICBzZXRHcm91cE92ZXJ2aWV3RGF0YShbXSk7XHJcbiAgICAgICAgICAgICAgc2V0R3JvdXBPdmVydmlldyhmYWxzZSk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIHdpZHRoPVwiMTAwMHB4XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBHcm91cCBPdmVydmlldyAtIHtncm91cEluZm8/Lmdyb3VwX25hbWUgfHwgXCJHcm91cFwifVxyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAge2xvYWRpbmdHcm91cE92ZXJ2aWV3ID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBweS0yMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IEdyb3VwT3ZlcnZpZXdEYXRhPy5kYXRhID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICAgICAgICAgICAgey8qIFN1bW1hcnkgQ2FyZHMgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtNCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYmx1ZS01MCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLWJsdWUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtYmx1ZS02MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgQXVjdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtHcm91cE92ZXJ2aWV3RGF0YS5kYXRhLnN1bW1hcnk/LnRvdGFsQXVjdGlvbnMgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItZ3JlZW4tMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JlZW4tNjAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIE5vcm1hbCBBdWN0aW9uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge0dyb3VwT3ZlcnZpZXdEYXRhLmRhdGEuc3VtbWFyeT8ubm9ybWFsQXVjdGlvbnMgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXB1cnBsZS01MCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1wdXJwbGUtNjAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEZyZWUgQXVjdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtHcm91cE92ZXJ2aWV3RGF0YS5kYXRhLnN1bW1hcnk/LmZyZWVBdWN0aW9ucyB8fCAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctb3JhbmdlLTUwIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItb3JhbmdlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LW9yYW5nZS02MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUHJpemVkIFN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JlZW4tNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUHJpemVkOntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7R3JvdXBPdmVydmlld0RhdGEuZGF0YS5zdW1tYXJ5Py5wcml6ZWRUcnVlIHx8IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXJlZC02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBVbnByaXplZDp7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge0dyb3VwT3ZlcnZpZXdEYXRhLmRhdGEuc3VtbWFyeT8ucHJpemVkRmFsc2UgfHwgMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFByaXplZCBVc2VycyBUYWJsZSAqL31cclxuICAgICAgICAgICAgICAgICAge0dyb3VwT3ZlcnZpZXdEYXRhLmRhdGEucHJpemVkVXNlcnMgJiZcclxuICAgICAgICAgICAgICAgICAgICBHcm91cE92ZXJ2aWV3RGF0YS5kYXRhLnByaXplZFVzZXJzLmxlbmd0aCA+IDAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtbWQgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG1iLTMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC01IGJnLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGxcIj48L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUHJpemVkIFVzZXJzIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7R3JvdXBPdmVydmlld0RhdGEuZGF0YS5wcml6ZWRVc2Vycy5sZW5ndGh9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byBtYXgtaC1bMzAwcHhdIG92ZXJmbG93LXktYXV0byBib3JkZXIgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwIHN0aWNreSB0b3AtMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyZWVuLTcwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNMIE5vXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JlZW4tNzAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVXNlciBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JlZW4tNzAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGhvbmUgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JlZW4tNzAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGlja2V0IE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyZWVuLTcwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7R3JvdXBPdmVydmlld0RhdGEuZGF0YS5wcml6ZWRVc2Vycy5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKHVzZXIsIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17aWR4fSBjbGFzc05hbWU9XCJob3ZlcjpiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lkeCArIDF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIucGhvbmVfbnVtYmVyIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3VzZXIudGlja2V0IHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCBiZy1ncmVlbi0xMDAgdGV4dC1ncmVlbi04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByaXplZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIE5vbi1Qcml6ZWQgVXNlcnMgVGFibGUgKi99XHJcbiAgICAgICAgICAgICAgICAgIHtHcm91cE92ZXJ2aWV3RGF0YS5kYXRhLm5vblByaXplZFVzZXJzICYmXHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXBPdmVydmlld0RhdGEuZGF0YS5ub25Qcml6ZWRVc2Vycy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LW1kIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0zIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0xIGgtNSBiZy1yZWQtNTAwIHJvdW5kZWQtZnVsbFwiPjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBOb24tUHJpemVkIFVzZXJzIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7R3JvdXBPdmVydmlld0RhdGEuZGF0YS5ub25Qcml6ZWRVc2Vycy5sZW5ndGh9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0byBtYXgtaC1bMzAwcHhdIG92ZXJmbG93LXktYXV0byBib3JkZXIgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLXJlZC01MCBzdGlja3kgdG9wLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1yZWQtNzAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU0wgTm9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1yZWQtNzAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVXNlciBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtcmVkLTcwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXJlZC03MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaWNrZXQgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtcmVkLTcwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEF1Y3Rpb24gQ29kZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXJlZC03MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTdGF0dXNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge0dyb3VwT3ZlcnZpZXdEYXRhLmRhdGEubm9uUHJpemVkVXNlcnMubWFwKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICh1c2VyLCBpZHgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e2lkeH0gY2xhc3NOYW1lPVwiaG92ZXI6YmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpZHggKyAxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZSB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLnBob25lX251bWJlciB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLnRpY2tldCB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0yIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmF1Y3Rpb25fY29kZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1mdWxsIGJnLXJlZC0xMDAgdGV4dC1yZWQtODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOb24tUHJpemVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICB7LyogTm8gRGF0YSBNZXNzYWdlICovfVxyXG4gICAgICAgICAgICAgICAgICB7KCFHcm91cE92ZXJ2aWV3RGF0YS5kYXRhLnByaXplZFVzZXJzIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgR3JvdXBPdmVydmlld0RhdGEuZGF0YS5wcml6ZWRVc2Vycy5sZW5ndGggPT09IDApICYmXHJcbiAgICAgICAgICAgICAgICAgICAgKCFHcm91cE92ZXJ2aWV3RGF0YS5kYXRhLm5vblByaXplZFVzZXJzIHx8XHJcbiAgICAgICAgICAgICAgICAgICAgICBHcm91cE92ZXJ2aWV3RGF0YS5kYXRhLm5vblByaXplZFVzZXJzLmxlbmd0aCA9PT0gMCkgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS04XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBObyB1c2VyIGRhdGEgYXZhaWxhYmxlIGZvciB0aGlzIGdyb3VwLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcHktMTJcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm14LWF1dG8gaC0xMiB3LTEyIHRleHQtZ3JheS00MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBkPVwiTTkgMTl2LTZhMiAyIDAgMDAtMi0ySDVhMiAyIDAgMDAtMiAydjZhMiAyIDAgMDAyIDJoMmEyIDIgMCAwMDItMnptMCAwVjlhMiAyIDAgMDEyLTJoMmEyIDIgMCAwMTIgMnYxMG0tNiAwYTIgMiAwIDAwMiAyaDJhMiAyIDAgMDAyLTJtMCAwVjVhMiAyIDAgMDEyLTJoMmEyIDIgMCAwMTIgMnYxNGEyIDIgMCAwMS0yIDJoLTJhMiAyIDAgMDEtMi0yelwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIE5vIGRhdGEgZm91bmRcclxuICAgICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBVbmFibGUgdG8gbG9hZCBncm91cCBvdmVydmlldyBkYXRhLlxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgICAgey8qIFBheW91dCBJbmZvcm1hdGlvbiBNb2RhbCAqL31cclxuICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dQYXlvdXRNb2RhbH1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICAgIHNldFNob3dQYXlvdXRNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgICAgICAgc2V0UGF5b3V0RGF0YShbXSk7XHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIHdpZHRoPVwiMTAwMHB4XCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBQYXlvdXQgSW5mb3JtYXRpb24gLSB7Z3JvdXBJbmZvPy5ncm91cF9uYW1lIHx8IFwiR3JvdXBcIn1cclxuICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHtsb2FkaW5nUGF5b3V0ID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBweS0yMFwiPlxyXG4gICAgICAgICAgICAgICAgICA8Q2lyY3VsYXJMb2FkZXIgaXNMb2FkaW5nPXt0cnVlfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKSA6IHBheW91dERhdGEgJiYgcGF5b3V0RGF0YS5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgey8qIFN1bW1hcnkgQ2FyZHMgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtNCBnYXAtNCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1vcmFuZ2UtNTAgcm91bmRlZC1sZyBwLTQgYm9yZGVyIGJvcmRlci1vcmFuZ2UtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtb3JhbmdlLTYwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBQYXlvdXRzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cGF5b3V0RGF0YS5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmVlbi01MCByb3VuZGVkLWxnIHAtNCBib3JkZXIgYm9yZGVyLWdyZWVuLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyZWVuLTYwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBBbW91bnRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cGF5b3V0RGF0YVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5yZWR1Y2UoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoc3VtLCBpdGVtKSA9PiBzdW0gKyAocGFyc2VJbnQoaXRlbS5hbW91bnQpIHx8IDApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgMCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG9jYWxlU3RyaW5nKFwiZW4tSU5cIil9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItYmx1ZS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ibHVlLTYwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBPbmxpbmUgUGF5b3V0c1xyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBheW91dERhdGEuZmlsdGVyKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGl0ZW0pID0+IGl0ZW0ucGF5X3R5cGUgPT09IFwib25saW5lXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKS5sZW5ndGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctcHVycGxlLTUwIHJvdW5kZWQtbGcgcC00IGJvcmRlciBib3JkZXItcHVycGxlLTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXB1cnBsZS02MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ2FzaCBQYXlvdXRzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgcGF5b3V0RGF0YS5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0ucGF5X3R5cGUgPT09IFwiY2FzaFwiKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmxlbmd0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgey8qIFBheW91dHMgVGFibGUgKi99XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIG1heC1oLVs1MDBweF0gb3ZlcmZsb3cteS1hdXRvIGJvcmRlciByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctb3JhbmdlLTUwIHN0aWNreSB0b3AtMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LW9yYW5nZS03MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTTCBOb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LW9yYW5nZS03MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtb3JhbmdlLTcwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LW9yYW5nZS03MDAgdXBwZXJjYXNlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaWNrZXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1vcmFuZ2UtNzAwIHVwcGVyY2FzZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQW1vdW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtb3JhbmdlLTcwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBheSBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtb3JhbmdlLTcwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBheSBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtb3JhbmdlLTcwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIERpc2J1cnNlbWVudCBUeXBlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtb3JhbmdlLTcwMCB1cHBlcmNhc2VcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkbWluIE5hbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge3BheW91dERhdGEubWFwKChwYXlvdXQsIGlkeCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3BheW91dC5faWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1zbSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpZHggKyAxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXlvdXQuZnVsbF9uYW1lIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LXNtIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW91dC5waG9uZV9udW1iZXIgfHwgXCJOL0FcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5b3V0LnRpY2tldCB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JlZW4tNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7KHBhcnNlSW50KHBheW91dC5hbW91bnQpIHx8IDApLnRvTG9jYWxlU3RyaW5nKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZW4tSU5cIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNCBweS0zIHRleHQtc20gdGV4dC1ncmF5LTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5b3V0LnBheV9kYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBuZXcgRGF0ZShwYXlvdXQucGF5X2RhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtZnVsbCAke3BheW91dC5wYXlfdHlwZSA9PT0gXCJvbmxpbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWJsdWUtMTAwIHRleHQtYmx1ZS04MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImJnLXB1cnBsZS0xMDAgdGV4dC1wdXJwbGUtODAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3BheW91dC5wYXlfdHlwZSB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTQgcHktMyB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwicHgtMyBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gcm91bmRlZC1tZCBiZy1ncmVlbi02MDAgdGV4dC13aGl0ZSBob3ZlcjpiZy1ncmF5LTgwMCB0cmFuc2l0aW9uIGNhcGl0YWxpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7cGF5b3V0LmRpc2J1cnNlbWVudF90eXBlIHx8IFwiTi9BXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC00IHB5LTMgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtwYXlvdXQuYWRtaW5fbmFtZSB8fCBcIk4vQVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS0xMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXgtYXV0byBoLTEyIHctMTIgdGV4dC1ncmF5LTQwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNOSA1SDdhMiAyIDAgMDAtMiAydjEyYTIgMiAwIDAwMiAyaDEwYTIgMiAwIDAwMi0yVjdhMiAyIDAgMDAtMi0yaC0yTTkgNWEyIDIgMCAwMDIgMmgyYTIgMiAwIDAwMi0yTTkgNWEyIDIgMCAwMTItMmgyYTIgMiAwIDAxMiAybS02IDloM20tMyA0aDNtLTYtNGguMDFNOSAxNmguMDFcIlxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBObyBkYXRhIGZvdW5kXHJcbiAgICAgICAgICAgICAgICAgIDwvaDM+XHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTm8gcGF5b3V0IGluZm9ybWF0aW9uIGF2YWlsYWJsZSBmb3IgdGhpcyBncm91cC5cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L01vZGFsPlxyXG5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTcgb3ZlcmZsb3ctaGlkZGVuXCI+XHJcbiAgICAgICAgICAgIHsvKiBUYWIgQmFyICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTQgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgPG5hdiBjbGFzc05hbWU9XCItbWItcHggZmxleCBzcGFjZS14LThcIiBhcmlhLWxhYmVsPVwiVGFic1wiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2F1Y3Rpb25zJyl9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YCR7YWN0aXZlVGFiID09PSAnYXVjdGlvbnMnXHJcbiAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLWJsdWUtNTAwIHRleHQtYmx1ZS02MDAnXHJcbiAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTcwMCBob3Zlcjpib3JkZXItZ3JheS0zMDAnXHJcbiAgICAgICAgICAgICAgICAgICAgfSB3aGl0ZXNwYWNlLW5vd3JhcCBweS00IHB4LTEgYm9yZGVyLWItMiBmb250LW1lZGl1bSB0ZXh0LXNtYH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQXVjdGlvbnNcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ3ByZUF1Y3Rpb24nKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgJHthY3RpdmVUYWIgPT09ICdwcmVBdWN0aW9uJ1xyXG4gICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1ibHVlLTUwMCB0ZXh0LWJsdWUtNjAwJ1xyXG4gICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci10cmFuc3BhcmVudCB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtZ3JheS03MDAgaG92ZXI6Ym9yZGVyLWdyYXktMzAwJ1xyXG4gICAgICAgICAgICAgICAgICAgIH0gd2hpdGVzcGFjZS1ub3dyYXAgcHktNCBweC0xIGJvcmRlci1iLTIgZm9udC1tZWRpdW0gdGV4dC1zbWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFByZeKAkUF1Y3Rpb24gRW50cmllc1xyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9uYXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIER5bmFtaWMgSGVhZGluZyAqL31cclxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSAnYXVjdGlvbnMnID8gJ0F1Y3Rpb25zJyA6ICdQcmXigJFBdWN0aW9uIEVudHJpZXMnfVxyXG4gICAgICAgICAgICA8L2gxPlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IG1iLThcIj5cclxuICAgICAgICAgICAgICB7YWN0aXZlVGFiID09PSAnYXVjdGlvbnMnID8gKFxyXG4gICAgICAgICAgICAgICAgLy8gLS0tLS0tLS0tLSBPUklHSU5BTCBBVUNUSU9OUyBUQUIgKFVOQ0hBTkdFRCkgLS0tLS0tLS0tLVxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbD5TZWxlY3Qgb3IgU2VhcmNoIEdyb3VwPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBPcmlnaW5hbCBkcm9wZG93biDigJMga2VlcCBleGFjdGx5IGFzIGJlZm9yZSAqL31cclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkQXVjdGlvbkdyb3VwSWQgPT09ICdyZWNlbnQnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdyZWNlbnQnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHNlbGVjdGVkQXVjdGlvbkdyb3VwSWQgfHwgdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdyb3VwQXVjdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgbWF4LXctbWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9wdGlvbi52YWx1ZSA9PT0gJ3JlY2VudCcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAnUmVjZW50IEF1Y3Rpb25zJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8udG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggb3IgU2VsZWN0IEdyb3VwXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PVwicmVjZW50XCIgdmFsdWU9XCJyZWNlbnRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBSZWNlbnQgQXVjdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy1ibHVlLTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy1ibHVlLTgwMCB0cmFuc2l0aW9uIGR1cmF0aW9uLTIwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICsgQWRkIEF1Y3Rpb25cclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCAhPT0gJ3JlY2VudCcgJiZcclxuICAgICAgICAgICAgICAgICAgICAgIGZpbHRlcmVkQXVjdGlvblswXT8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC01IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC00IHB5LTIgYmctb3JhbmdlLTUwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1vcmFuZ2UtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1vcmFuZ2UtNjAwIHRleHQtc20gZm9udC1tZWRpdW1cIj5CYWxhbmNlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtOdW1iZXIoZG91YmxlLmFtb3VudCB8fCAwKS50b0xvY2FsZVN0cmluZygnZW4tSU4nKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRBdWN0aW9uR3JvdXBJZCA9PT0gJ3JlY2VudCcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBib3JkZXItbC00IGJvcmRlci1ibHVlLTUwMCBwbC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgUmVjZW50IEF1Y3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgTGF0ZXN0IGF1Y3Rpb24gYWN0aXZpdGllcyBhY3Jvc3MgYWxsIGdyb3Vwc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgeyFuYXZpZ2F0b3Iub25MaW5lID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtcmVkLTUwMCBweS02XCI+Tm8gSW50ZXJuZXQgQ29ubmVjdGlvbjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSA6IGlzTG9hZGluZyB8fCBsb2FkaW5nUmVjZW50ID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHB5LTIwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyIGlzTG9hZGluZz17dHJ1ZX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICApIDogVGFibGVBdWN0aW9ucz8ubGVuZ3RoID4gMCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17c2VsZWN0ZWRBdWN0aW9uR3JvdXBJZH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVIYW5kbGVyPXtoYW5kbGVVcGRhdGVNb2RhbE9wZW59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlQXVjdGlvbnMsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnM9e3NlbGVjdGVkQXVjdGlvbkdyb3VwSWQgPT09ICdyZWNlbnQnID8gcmVjZW50QXVjdGlvbnNDb2x1bW5zIDogY29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkQXVjdGlvbkdyb3VwSWQgPT09ICdyZWNlbnQnID8gJ1JlY2VudF9BdWN0aW9ucy5jc3YnIDogJ0F1Y3Rpb25zLmNzdidcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICApIDogaGFzRmV0Y2hlZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS02IHRleHQtZ3JheS01MDBcIj5ObyBBdWN0aW9uIERhdGEgRm91bmQ8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAvLyAtLS0tLS0tLS0tIE5FVyBQUkXigJFBVUNUSU9OIEVOVFJJRVMgVEFCIC0tLS0tLS0tLS1cclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWw+U2VsZWN0IFByZeKAkUF1Y3Rpb24gR3JvdXA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cHJlQXVjdGlvblNlbGVjdGVkR3JvdXBJZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQcmVBdWN0aW9uR3JvdXBDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LW1kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4/LnRvU3RyaW5nKCkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIG9yIFNlbGVjdCBHcm91cFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9e3ByZUF1Y3Rpb25Mb2FkaW5nICYmIHByZUF1Y3Rpb25Hcm91cHMubGVuZ3RoID09PSAwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cHJlQXVjdGlvbkdyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtncm91cC5faWR9IHZhbHVlPXtncm91cC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2dyb3VwLmdyb3VwX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsKHRydWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctYmx1ZS05NTAgdGV4dC13aGl0ZSBweC00IHB5LTIgcm91bmRlZCBzaGFkb3ctbWQgaG92ZXI6YmctYmx1ZS04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICArIEFkZCBBdWN0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIHshbmF2aWdhdG9yLm9uTGluZSA/IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1yZWQtNTAwIHB5LTZcIj5ObyBJbnRlcm5ldCBDb25uZWN0aW9uPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IHByZUF1Y3Rpb25Mb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgLy8gTG9hZGVyIGFwcGVhcnMgZXZlcnkgdGltZSBhIGdyb3VwIGlzIHNlbGVjdGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHB5LTIwXCIga2V5PVwibG9hZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaXJjdWxhckxvYWRlciBpc0xvYWRpbmc9e3RydWV9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApIDogcHJlQXVjdGlvblRhYmxlRGF0YS5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3ByZUF1Y3Rpb25TZWxlY3RlZEdyb3VwSWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9e2hhbmRsZVVwZGF0ZU1vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKHByZUF1Y3Rpb25UYWJsZURhdGEsIHNlYXJjaFRleHQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjb2x1bW5zPXtjb2x1bW5zfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zPXtwcmVBdWN0aW9uQ29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YFByZUF1Y3Rpb25fJHtwcmVBdWN0aW9uU2VsZWN0ZWRHcm91cElkIHx8ICdncm91cHMnfS5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICApIDogcHJlQXVjdGlvbkhhc0ZldGNoZWREYXRhID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBweS02IHRleHQtZ3JheS01MDBcIj5ObyBBdWN0aW9uIERhdGEgRm91bmQgZm9yIHRoaXMgZ3JvdXA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBdWN0aW9uOyBcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0F1Y3Rpb24uanN4In0=