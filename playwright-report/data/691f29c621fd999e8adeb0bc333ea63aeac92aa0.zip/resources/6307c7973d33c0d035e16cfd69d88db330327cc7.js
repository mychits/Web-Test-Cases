import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/Enroll.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import api from "/src/instance/TokenInstance.js";
import { fieldSize } from "/src/data/fieldSize.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import { FaWhatsappSquare } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { FaWhatsapp } from "/node_modules/.vite/deps/react-icons_fa.js?v=819e0a34";
import { FiLink } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { Select, Dropdown, notification, Tooltip, Popconfirm, message, Tag } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import Navbar from "/src/components/layouts/Navbar.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import { FiMail } from "/node_modules/.vite/deps/react-icons_fi.js?v=819e0a34";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=819e0a34";
import GroupReport from "/src/pages/GroupReport.jsx";
import __vite__cjsImport21_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=819e0a34"; const ReactDOM = __vite__cjsImport21_reactDom_client.__esModule ? __vite__cjsImport21_reactDom_client.default : __vite__cjsImport21_reactDom_client;
import CustomerGroupEnrollPrint from "/src/components/printFormats/CustomerGroupEnrollPrint.jsx";
const Enroll = () => {
  _s();
  const [groups, setGroups] = useState([]);
  const [users, setUsers] = useState([]);
  const [TableEnrolls, setTableEnrolls] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [selectedGroup, setSelectedGroup] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [currentUpdateGroup, setCurrentUpdateGroup] = useState(null);
  const [availableTickets, setAvailableTickets] = useState([]);
  const [showModalRemove, setShowModalRemove] = useState(false);
  const [showModelOnHold, setShowModelOnHold] = useState(false);
  const [currentGroup, setCurrentGroup] = useState(null);
  const [availableTicketsAdd, setAvailableTicketsAdd] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isDataTableLoading, setIsDataTableLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [allEnrollUrl, setAllEnrollUrl] = useState(true);
  const [leads, setLeads] = useState([]);
  const [agents, setAgents] = useState([]);
  const [removalReason, setRemovalReason] = useState("");
  const date = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const [employees, setEmployees] = useState([]);
  const [thirdPartyEnable, setThirdPartyEnable] = useState({
    email: true,
    whatsapp: true,
    paymentLink: true
  });
  const [email, setEmail] = useState([]);
  const [enrollmentStep, setEnrollmentStep] = useState("verify");
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [isExistingEnrollment, setIsExistingEnrollment] = useState(false);
  const [admin, setAdmin] = useState("");
  const [activeTab, setActiveTab] = useState("enrollments");
  const [formData, setFormData] = useState({
    group_id: "",
    user_id: "",
    no_of_tickets: "",
    referred_type: "",
    payment_type: "",
    referred_customer: "",
    agent: "",
    referred_lead: "",
    email_id: "",
    chit_asking_month: "",
    created_by: "",
    ignoreIncentive: true
  });
  const [isVerified, setIsVerified] = useState(false);
  const [updateFormData, setUpdateFormData] = useState({
    group_id: "",
    user_id: "",
    tickets: "",
    payment_type: "",
    referred_type: "",
    referred_customer: "",
    agent: "",
    referred_lead: "",
    chit_asking_month: "",
    blocked_referral: false,
    blocked_referral_type: "",
    blocked_referred_customer: "",
    blocked_referred_lead: "",
    blocked_referred_agent: "",
    ignoreIncentive: true
  });
  const [searchText, setSearchText] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState([]);
  const [activateModelOpen, setActivateModelOpen] = useState(false);
  const today = /* @__PURE__ */ new Date();
  const currentYear = today.getFullYear();
  const currentMonth = String(today.getMonth() + 1).padStart(2, "0");
  const currentYearMonth = `${currentYear}-${currentMonth}`;
  function formatDate(date2) {
    const year = date2.getFullYear();
    const month = `0${date2.getMonth() + 1}`.slice(-2);
    const day = `0${date2.getDate()}`.slice(-2);
    return `${year}-${month}-${day}`;
  }
  const [selectedDate, setSelectedDate] = useState("");
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [modifyPayment, setModifyPayment] = useState(false);
  const [modifyMinMaxPaymentDate, setModifyMinMaxPaymentDate] = useState(false);
  const [customerEnrollments, setCustomerEnrollments] = useState([]);
  const [customerPigmy, setCustomerPigmy] = useState([]);
  const [customerLoans, setCustomerLoans] = useState([]);
  const [customerDetailsLoading, setCustomerDetailsLoading] = useState(false);
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];
  const [monthValues, setMonthValues] = useState({
    January: 0,
    February: 0,
    March: 0,
    April: 0,
    May: 0,
    June: 0,
    July: 0,
    August: 0,
    September: 0,
    October: 0,
    November: 0,
    December: 0
  });
  const onGlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    const adminId = userObj?._id;
    if (adminId) {
      setAdmin(userObj._id);
      setFormData((prev) => ({ ...prev, created_by: adminId }));
    } else {
      setAdmin("");
    }
  }, []);
  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await api.get("/group/get-group-admin");
        setGroups(response.data);
      } catch (error) {
        console.error("Error fetching group data:", error);
      }
    };
    fetchGroups();
  }, []);
  const fetchCustomerEnrollments = async (userId) => {
    try {
      const res = await api.get(`/v1/admin/enrolls/users/${userId}`);
      setCustomerEnrollments(res.data?.data);
    } catch (err) {
      console.error("Failed to fetch customer enrollments", err);
      setCustomerEnrollments([]);
    }
  };
  const fetchCustomerPigmy = async (userId) => {
    try {
      const res = await api.get(`/v1/admin/pigmes/get-pigme-customer-details/${userId}`);
      setCustomerPigmy(res.data?.data);
    } catch (err) {
      console.error("Failed to fetch customer pigmy", err);
      setCustomerPigmy([]);
    }
  };
  const fetchCustomerLoans = async (userId) => {
    try {
      const res = await api.get(`/v1/admin/loans/get-borrower-details/${userId}`);
      setCustomerLoans(res.data?.data);
    } catch (err) {
      console.error("Failed to fetch customer loans", err);
      setCustomerLoans([]);
    }
  };
  const parseDate = (dateString) => {
    const [year, month] = dateString.split("-");
    return {
      year,
      month: String(parseInt(month)).padStart(2, "0"),
      monthName: monthNames[parseInt(month) - 1]
    };
  };
  const formatToYearMonth = (year, month) => {
    return `${year}-${String(month).padStart(2, "0")}`;
  };
  const getMonthDateRange = (dateString) => {
    const { year, month } = parseDate(dateString);
    const startDate = new Date(year, parseInt(month) - 1, 1);
    const endDate = new Date(year, parseInt(month), 0);
    return {
      from_date: formatDate(startDate),
      to_date: formatDate(endDate)
    };
  };
  const handleActivateModelOpen = async (groupId) => {
    try {
      const response = await api.get(`/enroll/get-enroll-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setActivateModelOpen(true);
    } catch (error) {
      console.error("Error fetching on hold enrollment");
    }
  };
  const handlePrint = async (enrollId) => {
    try {
      const response = await api.get(`/v1/admin/enrolls/enroll-user-print/${enrollId}`);
      const enrollment = response.data?.data?.enrollment;
      const printWindow = window.open("", "_blank", "width=900,height=750");
      if (!printWindow) {
        message.error("Please allow pop-ups to print the enrollment details.");
        return;
      }
      printWindow.document.write(
        `<!DOCTYPE html>
          <html>
            <head>
              <title>Enrollment Receipt - ${enrollment?.enroll_code || "Enrollment"}</title>
            </head>
            <body>
              <div id="enrollment-print-root"></div>
            </body>
          </html>`
      );
      printWindow.document.close();
      printWindow.focus();
      const root = ReactDOM.createRoot(
        printWindow.document.getElementById("enrollment-print-root")
      );
      root.render(/* @__PURE__ */ jsxDEV(CustomerGroupEnrollPrint, { enrollment }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
        lineNumber: 269,
        columnNumber: 19
      }, this));
      setTimeout(() => {
        printWindow.focus();
        printWindow.print();
      }, 800);
    } catch (error) {
      console.error("Error printing enrollment:", error);
      message.error("Failed to load enrollment details for printing.");
    }
  };
  const handleActivateEnrollment = async (e) => {
    e.preventDefault();
    if (currentGroup) {
      const user_id = currentGroup.user_id?._id;
      try {
        await api.put(`/v1/admin/enrolls/activate/${currentGroup?._id}`, {
          user_id,
          customer_status: "Activate"
        });
        setActivateModelOpen("");
        setCurrentGroup(null);
        setAlertConfig({
          visibility: true,
          message: "Enroll holded successfully",
          type: "success"
        });
      } catch (error) {
        console.error("Error deleting group:", error);
      }
    }
  };
  useEffect(() => {
    async function fetchAllEnrollmentData() {
      setAllEnrollUrl(true);
      let url = `/enroll-report/get-enroll-report?from_date=${date}&to_date=${date}`;
      try {
        setTableEnrolls([]);
        setIsDataTableLoading(true);
        const response = await api.get(url);
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id || !group?.user_id) return {};
            return {
              _id: group?._id,
              id: index + 1,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              unlink_branch: group?.unlink_branch,
              payment_type: group?.payment_type,
              enrollment_date: group?.createdAt ? group?.createdAt?.split("T")[0] : "",
              chit_asking_month: group?.chit_asking_month,
              referred_type: group?.referred_type,
              ignoreIncentive: group?.ignore_incentive,
              referred_by: group?.agent?.name && group?.agent?.phone_number ? `${group.agent.name} | ${group.agent.phone_number}` : group?.referred_customer?.full_name && group?.referred_customer?.phone_number ? `${group.referred_customer.full_name} | ${group?.referred_customer?.phone_number}` : group?.referred_lead?.lead_name && group?.referred_lead?.agent_number ? `${group.referred_lead.lead_name} | ${group.referred_lead.agent_number}` : "N/A",
              ticket: group.tickets,
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-green-600",
                            onClick: () => handleUpdateModalOpen(group._id),
                            children: "Edit"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                            lineNumber: 350,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      // !group?.unlink_branch
                      //   ? {
                      //     key: "5",
                      //     label: (
                      //       <Popconfirm
                      //         title="Unlink Branch"
                      //         description="Are you sure you want to unlink this branch from the customer?"
                      //         okText="Yes"
                      //         cancelText="No"
                      //         onConfirm={() => handleUnlinkBranch(group._id)}
                      //       >
                      //         <Tooltip title="Unlink this customer's branch">
                      //           <div className="text-blue-600 cursor-pointer">
                      //             Unlink Branch
                      //           </div>
                      //         </Tooltip>
                      //       </Popconfirm>
                      //     ),
                      //   }
                      //   : {
                      //     key: "6",
                      //     label: (
                      //       <Popconfirm
                      //         title="link Branch"
                      //         description="Are you sure you want to link this branch to the customer?"
                      //         okText="Yes"
                      //         cancelText="No"
                      //         onConfirm={() => handlelinkBranch(group._id)}
                      //       >
                      //         <Tooltip title="link this customer's branch">
                      //           <div className="text-blue-600 cursor-pointer">
                      //             Link Branch
                      //           </div>
                      //         </Tooltip>
                      //       </Popconfirm>
                      //     ),
                      //   },
                      {
                        key: "2",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-red-600",
                            onClick: () => handleRemoveModalOpen(group._id),
                            children: "Remove"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                            lineNumber: 399,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      group?.customer_status === "Active" ? {
                        key: "3",
                        label: /* @__PURE__ */ jsxDEV(Tooltip, { title: "Do you want to make this customer On Hold?", children: /* @__PURE__ */ jsxDEV(
                          Popconfirm,
                          {
                            title: "Put customer On Hold",
                            description: "Are you sure you want to put this customer on hold?",
                            okText: "Yes",
                            cancelText: "No",
                            onConfirm: () => handleOnHoldModelOpen(group._id),
                            children: /* @__PURE__ */ jsxDEV("div", { className: "text-orange-500 cursor-pointer", children: "On Hold" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                              lineNumber: 419,
                              columnNumber: 35
                            }, this)
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                            lineNumber: 412,
                            columnNumber: 33
                          },
                          this
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                          lineNumber: 411,
                          columnNumber: 23
                        }, this)
                      } : group?.customer_status === "On Hold" ? {
                        key: "4",
                        label: /* @__PURE__ */ jsxDEV(Tooltip, { title: "Do you want to activate this customer?", children: /* @__PURE__ */ jsxDEV(
                          Popconfirm,
                          {
                            title: "Activate Customer",
                            description: "Are you sure you want to activate this customer?",
                            okText: "Yes",
                            cancelText: "No",
                            onConfirm: () => handleActivateModelOpen(group._id),
                            children: /* @__PURE__ */ jsxDEV("div", { className: "text-green-500 cursor-pointer", children: "Activate" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                              lineNumber: 438,
                              columnNumber: 37
                            }, this)
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                            lineNumber: 431,
                            columnNumber: 35
                          },
                          this
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                          lineNumber: 430,
                          columnNumber: 23
                        }, this)
                      } : null,
                      {
                        key: "print",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-blue-600",
                            onClick: () => handlePrint(group._id),
                            children: "Print"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                            lineNumber: 449,
                            columnNumber: 23
                          },
                          this
                        )
                      }
                    ].filter(Boolean)
                  },
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold cursor-pointer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 461,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 344,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 343,
                columnNumber: 15
              }, this)
            };
          });
          setTableEnrolls(formattedData);
        } else {
          setFilteredUsers([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
        setTableEnrolls([]);
      } finally {
        setIsDataTableLoading(false);
      }
    }
    fetchAllEnrollmentData();
  }, [reloadTrigger]);
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await api.get("/user/get-user");
        setUsers(response.data);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };
    fetchUsers();
  }, []);
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await api.get("/agent/get");
        setAgents(response.data?.agent);
      } catch (err) {
        console.error("Failed to fetch Leads", err);
      }
    };
    fetchAgents();
  }, []);
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const response = await api.get("/employee");
        setEmployees(response?.data?.employee);
      } catch (error) {
        console.error("failed to fetch employees", error);
      }
    };
    fetchEmployees();
  }, []);
  useEffect(() => {
    const fetchLeads = async () => {
      try {
        const response = await api.get("/lead/get-lead");
        setLeads(response.data);
      } catch (err) {
        console.error("Failed to fetch Leads", err);
      }
    };
    fetchLeads();
  }, []);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    if (userObj) {
      const adminAccessPermissions = userObj.admin_access_right_id?.access_permissions;
      if (adminAccessPermissions?.edit_payment === "true") {
        setModifyPayment(true);
      }
      if (adminAccessPermissions?.edit_limited_payment === "true") {
        setModifyPayment(true);
        setModifyMinMaxPaymentDate(true);
      }
    }
  }, []);
  const handleAntDSelect = async (field, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [field]: value
    }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [field]: ""
    }));
    if (field === "group_id") {
      try {
        const response = await api.post(`/enroll/get-next-tickets/${value}`);
        setAvailableTicketsAdd(response.data.availableTickets || []);
      } catch (error) {
        console.error("Error fetching next tickets:", error);
      }
    }
    if (field === "user_id") {
      setCustomerDetailsLoading(true);
      setCustomerEnrollments([]);
      setCustomerPigmy([]);
      setCustomerLoans([]);
      await Promise.all(
        [
          fetchCustomerEnrollments(value),
          fetchCustomerPigmy(value),
          fetchCustomerLoans(value)
        ]
      );
      setCustomerDetailsLoading(false);
      const selectedUser = users.find((user) => user._id === value);
      if (selectedUser) {
        const refType = selectedUser.referral_type || "Self Joining";
        setFormData((prev) => ({
          ...prev,
          referred_type: refType,
          // Reset referral specific fields
          referred_employee: "",
          agent: "",
          referred_customer: ""
        }));
        if (refType === "Employee" && selectedUser.referred_employee?._id) {
          setFormData((prev) => ({
            ...prev,
            agent: selectedUser.referred_employee._id
          }));
        } else if (refType === "Agent" && selectedUser.referred_agent?._id) {
          setFormData((prev) => ({
            ...prev,
            referred_agent: selectedUser.referred_agent._id
          }));
        } else if (refType === "Customer" && selectedUser.referred_customer?._id) {
          setFormData((prev) => ({
            ...prev,
            referred_customer: selectedUser.referred_customer._id
          }));
        }
      }
    }
  };
  function setRefferedType(referralArray) {
    const found = referralArray.find((referee) => referee.data);
    return found ? found.value : null;
  }
  const handleAntInputDSelect = (field, value) => {
    if (field === "referred_type") {
      setUpdateFormData((prevData) => ({
        ...prevData,
        referred_type: value,
        // ✔ FIXED
        blocked_referral: true,
        referred_customer: "",
        referred_lead: "",
        agent: "",
        blocked_referral_type: setRefferedType(
          [
            { data: prevData?.referred_customer, value: "Customer" },
            { data: prevData?.referred_lead, value: "Lead" },
            { data: prevData?.agent, value: "Agent" }
          ]
        ),
        blocked_referred_customer: prevData?.referred_customer?._id,
        blocked_referred_lead: prevData?.referred_lead?._id,
        blocked_referred_agent: prevData?.agent?._id
      }));
      return;
    }
    setUpdateFormData((prevData) => ({
      ...prevData,
      blocked_referral_type: false,
      blocked_referred_customer: "",
      blocked_referred_lead: "",
      blocked_referred_agent: "",
      [field]: value
    }));
    setErrors({ ...errors, [field]: "" });
  };
  const handleUnlinkBranch = async (enrollId) => {
    try {
      await api.patch(`/v1/admin/enrolls/unlink-branch/${enrollId}`);
      message.success("Branch unlinked successfully");
      setCurrentUpdateGroup((prev) => ({
        ...prev,
        unlink_branch: true
      }));
    } catch (error) {
      console.error(error);
      message.error("Failed to unlink branch");
    }
  };
  const handlelinkBranch = async (enrollId) => {
    try {
      await api.patch(`/v1/admin/enrolls/link-branch/${enrollId}`);
      message.success("Branch linked successfully");
      setCurrentUpdateGroup((prev) => ({
        ...prev,
        unlink_branch: false
      }));
    } catch (error) {
      console.error(error);
      message.error("Failed to link branch");
    }
  };
  const handleGroupChange = async (groupId) => {
    setSelectedGroup(groupId);
    if (groupId) {
      let url;
      if (groupId === "recent") {
        url = `/enroll-report/get-dashboard-enrollment`;
        setAllEnrollUrl(true);
      } else if (groupId === "today") {
        url = `/enroll-report/get-enroll-report?from_date=${date}&to_date=${date}`;
        setAllEnrollUrl(true);
      } else {
        url = `/enroll/get-group-enroll/${groupId}`;
        setAllEnrollUrl(false);
      }
      try {
        setTableEnrolls([]);
        setIsDataTableLoading(true);
        const response = await api.get(url);
        console.info(response, "enrollment");
        if (response.data && response.data.length > 0) {
          setFilteredUsers(response.data);
          const formattedData = response.data.map((group, index) => {
            if (!group?.group_id || !group?.user_id) return {};
            return {
              _id: group?._id,
              id: index + 1,
              enroll_code: group?.enroll_code,
              name: group?.user_id?.full_name,
              phone_number: group?.user_id?.phone_number,
              group_name: group?.group_id?.group_name,
              unlink_branch: group?.unlink_branch ? "Yes" : "No",
              payment_type: group?.payment_type,
              enrollment_date: group?.createdAt.split("T")[0],
              chit_asking_month: group?.chit_asking_month,
              referred_type: group?.referred_type,
              ignoreIncentive: group?.ignore_incentive,
              referred_by: group?.agent?.name && group?.agent?.phone_number ? `${group.agent.name} | ${group.agent.phone_number}` : group?.referred_customer?.full_name && group?.referred_customer?.phone_number ? `${group.referred_customer.full_name} | ${group?.referred_customer?.phone_number}` : group?.referred_lead?.lead_name && group?.referred_lead?.agent_number ? `${group.referred_lead.lead_name} | ${group.referred_lead.agent_number}` : "N/A",
              ticket: group.tickets,
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center items-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-green-600",
                            onClick: () => handleUpdateModalOpen(group._id),
                            children: "Edit"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                            lineNumber: 783,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      {
                        key: "print",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-blue-600",
                            onClick: () => handlePrint(group._id),
                            children: "Print"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                            lineNumber: 794,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      {
                        key: "2",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-red-600",
                            onClick: () => handleRemoveModalOpen(group._id),
                            children: "Remove"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                            lineNumber: 805,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      // !group?.unlink_branch
                      //   ? {
                      //     key: "5",
                      //     label: (
                      //       <Popconfirm
                      //         title="Unlink Branch"
                      //         description="Are you sure you want to unlink this branch from the customer?"
                      //         okText="Yes"
                      //         cancelText="No"
                      //         onConfirm={() => handleUnlinkBranch(group._id)}
                      //       >
                      //         <Tooltip title="Unlink this customer's branch">
                      //           <div className="text-blue-600 cursor-pointer">
                      //             Unlink Branch
                      //           </div>
                      //         </Tooltip>
                      //       </Popconfirm>
                      //     ),
                      //   }
                      //   : {
                      //     key: "6",
                      //     label: (
                      //       <Popconfirm
                      //         title="link Branch"
                      //         description="Are you sure you want to link this branch to the customer?"
                      //         okText="Yes"
                      //         cancelText="No"
                      //         onConfirm={() => handlelinkBranch(group._id)}
                      //       >
                      //         <Tooltip title="link this customer's branch">
                      //           <div className="text-blue-600 cursor-pointer">
                      //             Link Branch
                      //           </div>
                      //         </Tooltip>
                      //       </Popconfirm>
                      //     ),
                      //   },
                      group?.customer_status === "Active" ? {
                        key: "3",
                        label: /* @__PURE__ */ jsxDEV(Tooltip, { title: "Do you want to make this customer On Hold?", children: /* @__PURE__ */ jsxDEV(
                          Popconfirm,
                          {
                            title: "Put customer On Hold",
                            description: "Are you sure you want to put this customer on hold?",
                            okText: "Yes",
                            cancelText: "No",
                            onConfirm: () => handleOnHoldModelOpen(group._id),
                            children: /* @__PURE__ */ jsxDEV("div", { className: "text-orange-500 cursor-pointer", children: "On Hold" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                              lineNumber: 862,
                              columnNumber: 35
                            }, this)
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                            lineNumber: 855,
                            columnNumber: 33
                          },
                          this
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                          lineNumber: 854,
                          columnNumber: 23
                        }, this)
                      } : group?.customer_status === "On Hold" ? {
                        key: "4",
                        label: /* @__PURE__ */ jsxDEV(Tooltip, { title: "Do you want to activate this customer?", children: /* @__PURE__ */ jsxDEV(
                          Popconfirm,
                          {
                            title: "Activate Customer",
                            description: "Are you sure you want to activate this customer?",
                            okText: "Yes",
                            cancelText: "No",
                            onConfirm: () => handleActivateModelOpen(group._id),
                            children: /* @__PURE__ */ jsxDEV("div", { className: "text-green-500 cursor-pointer", children: "Activate" }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                              lineNumber: 881,
                              columnNumber: 37
                            }, this)
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                            lineNumber: 874,
                            columnNumber: 35
                          },
                          this
                        ) }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                          lineNumber: 873,
                          columnNumber: 23
                        }, this)
                      } : null
                    ].filter(Boolean)
                  },
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold cursor-pointer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 892,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 777,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 776,
                columnNumber: 15
              }, this)
            };
          });
          setTableEnrolls(formattedData);
        } else {
          setFilteredUsers([]);
        }
      } catch (error) {
        console.error("Error fetching enrollment data:", error);
        setFilteredUsers([]);
        setTableEnrolls([]);
      } finally {
        setIsDataTableLoading(false);
      }
    } else {
      setFilteredUsers([]);
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "name", header: "Customer Name" },
    { key: "phone_number", header: "Customer Phone Number" }
  ];
  if (allEnrollUrl) {
    columns.push({ key: "group_name", header: "Enrolled Group" });
  }
  columns.push(
    { key: "enroll_code", header: "Enroll Code", width: 180 },
    { key: "unlink_branch", header: "unlink branch" },
    { key: "ticket", header: "Ticket Number" },
    // { key: "ignoreIncentive", header: "ignoreIncentive" },
    { key: "payment_type", header: "Payment Type" },
    { key: "enrollment_date", header: "Enrollment Date" },
    { key: "chit_asking_month", header: "Chit Asking Month" },
    { key: "referred_type", header: "Referred Type" },
    { key: "referred_by", header: "Referred By" },
    { key: "action", header: "Action" }
  );
  const handleChange = async (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
    setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
    if (name === "group_id") {
      try {
        const response = await api.post(`/enroll/get-next-tickets/${value}`);
        setAvailableTicketsAdd(response.data.availableTickets || []);
      } catch (error) {
        console.error("Error fetching next tickets:", error);
      }
    }
  };
  const validate = (type) => {
    const newErrors = {};
    const data = type === "addEnrollment" ? formData : updateFormData;
    const noOfTickets = type === "addEnrollment" ? "no_of_tickets" : "tickets";
    const regex = { email_id: /^[^\s@]+@[^\s@]+\.[^\s@]+$/ };
    if (!data.group_id.trim()) {
      newErrors.group_id = "Please select a group";
    }
    if (!data.user_id) {
      newErrors.user_id = "Please select a customer";
    }
    if (data.email_id && !regex.email_id.test(data.email_id)) {
      newErrors.email_id = "Invalid email format";
    }
    if (availableTicketsAdd.length > 0) {
      if (!data[noOfTickets] || data[noOfTickets] <= 0 || isNaN(data[noOfTickets])) {
        newErrors[noOfTickets] = "Please enter number of tickets";
      } else if (data[noOfTickets] > availableTicketsAdd.length) {
        newErrors[noOfTickets] = `Maximum ${availableTicketsAdd.length} tickets allowed`;
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const isvalid = validate("addEnrollment");
    if (isvalid) {
      setLoading(true);
      const {
        no_of_tickets,
        group_id,
        user_id,
        payment_type,
        referred_customer,
        referred_type,
        ignoreIncentive,
        agent,
        referred_lead,
        chit_asking_month,
        email_id,
        created_by
      } = formData;
      const ticketsCount = parseInt(no_of_tickets, 10);
      const ticketEntries = availableTicketsAdd.slice(0, ticketsCount).map((ticketNumber) => ({
        group_id,
        user_id,
        no_of_tickets,
        payment_type,
        referred_customer,
        agent,
        referred_lead,
        referred_type,
        ignore_incentive: ignoreIncentive,
        chit_asking_month: formData.chit_asking_month,
        tickets: ticketNumber,
        email_id,
        created_by
      }));
      try {
        for (const ticketEntry of ticketEntries) {
          await api.post(
            "/enroll/add-enroll",
            {
              ...ticketEntry,
              ...thirdPartyEnable
            },
            {
              headers: {
                "Content-Type": "application/json"
              }
            }
          );
        }
        setShowModal(false);
        setFormData({
          group_id: "",
          user_id: "",
          no_of_tickets: "",
          referred_type: "",
          ignoreIncentive: true,
          payment_type: "",
          referred_customer: "",
          agent: "",
          referred_lead: "",
          email_id
        });
        setAlertConfig({
          visibility: true,
          message: "User Enrolled Successfully",
          type: "success"
        });
      } catch (error) {
        console.error("Error enrolling user:", error);
      } finally {
        setLoading(false);
      }
    }
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdateFormData((prevState) => ({
      ...prevState,
      [name]: value
    }));
  };
  const handleUpdateModalOpen = async (enrollId) => {
    try {
      const response = await api.get(`/enroll/get-enroll-by-id/${enrollId}`);
      setCurrentUpdateGroup(response.data);
      setUpdateFormData({
        group_id: response.data?.group_id?._id || response.data?.group_id || "",
        user_id: response.data?.user_id?._id || response.data?.user_id || "",
        tickets: response.data?.tickets || "",
        payment_type: response.data?.payment_type || "",
        referred_type: response.data?.referred_type || "",
        ignoreIncentive: response.data?.ignore_incentive,
        agent: response.data?.agent?._id || response.data?.agent || "",
        referred_customer: response.data?.referred_customer?._id || response.data?.referred_customer || "",
        referred_lead: response.data?.referred_lead?._id || response.data?.referred_lead || "",
        chit_asking_month: response.data?.chit_asking_month || "",
        blocked_referral: response.data?.blocked_referral || false,
        blocked_referral_type: response.data?.blocked_referral_type || "",
        blocked_referral_customer: response.data?.blocked_referral_customer || "",
        blocked_referral_lead: response.data?.blocked_referral_lead || "",
        blocked_referral_agent: response.data?.blocked_referral_agent || ""
      });
      const userId = response.data?.user_id?._id || response.data?.user_id;
      if (userId) {
        setCustomerDetailsLoading(true);
        await Promise.all(
          [
            fetchCustomerEnrollments(userId),
            fetchCustomerPigmy(userId),
            fetchCustomerLoans(userId)
          ]
        );
        setCustomerDetailsLoading(false);
      }
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching enrollment:", error);
    }
  };
  const getCustomerTicketDetails = (enrollments, pigmyList, loansList) => {
    const items = [];
    enrollments?.forEach((enrollment) => {
      const group = enrollment.group_id;
      const ticket = enrollment.tickets;
      if (group && ticket) {
        items.push({
          id: `chit-${group._id}|${ticket}`,
          type: "chit",
          name: group.group_name,
          ticket,
          group_value: group.group_value || "-",
          group_install: group.group_install || "-",
          payable: enrollment.total_payable || 0,
          paid: enrollment.total_investment || 0,
          totalPaid: enrollment.total_investment || 0,
          totalPenalty: enrollment.total_penalty || 0,
          totalLateFee: enrollment.total_late_fee || 0,
          balance: enrollment.total_balance
        });
      }
    });
    pigmyList.forEach((pigmy) => {
      items.push({
        id: `pigme-${pigmy._id}`,
        type: "pigmy",
        name: pigmy.pigme_id || "Pigmy Scheme",
        payableAmount: pigmy.payable_amount || 0,
        startDate: pigmy.start_date,
        duration: pigmy.duration,
        totalPaid: pigmy.total_paid_amount || 0,
        balance: (pigmy.payable_amount || 0) - (pigmy.paid_amount || 0)
      });
    });
    loansList.forEach((loan) => {
      items.push({
        id: `loan-${loan._id}`,
        type: "loan",
        name: loan.loan_id || "Loan",
        loanAmount: loan.loan_amount || 0,
        startDate: loan.start_date,
        endDate: loan.end_date,
        dailyPayment: loan.daily_payment_amount || 0,
        totalPaid: loan.total_payments || 0,
        balance: loan.remaining_loan || 0
      });
    });
    return items;
  };
  const handleRemoveModalOpen = async (groupId) => {
    try {
      const response = await api.get(`/enroll/get-enroll-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setShowModalRemove(true);
    } catch (error) {
      console.error("Error fetching enroll:", error);
    }
  };
  const handleOnHoldModelOpen = async (groupId) => {
    try {
      const response = await api.get(`/enroll/get-enroll-by-id/${groupId}`);
      setCurrentGroup(response.data);
      setShowModelOnHold(true);
    } catch (error) {
      console.error("Error fetching on hold enrollment");
    }
  };
  const handleRemoveGroup = async (e) => {
    e.preventDefault();
    if (currentGroup) {
      const user_id = currentGroup.user_id?._id;
      if (user_id) {
        try {
          await api.put(`/enroll/remove/${currentGroup?._id}`, {
            user_id,
            deleted_by: admin,
            deleted_at: /* @__PURE__ */ new Date(),
            removalReason
          });
          setRemovalReason("");
          setShowModalRemove(false);
          setCurrentGroup(null);
          setAlertConfig({
            visibility: true,
            message: "Enroll deleted successfully",
            type: "success"
          });
        } catch (error) {
          setRemovalReason("");
          console.error("Error deleting group:", error);
        }
      }
    }
  };
  const handleOnHoldGroup = async (e) => {
    e.preventDefault();
    if (currentGroup) {
      const user_id = currentGroup?.user_id?._id;
      if (user_id) {
        try {
          await api.put(
            `/v1/admin/enrolls/on-hold/${currentGroup?._id}`,
            {
              user_id,
              holded_on: /* @__PURE__ */ new Date(),
              deleted_by: admin,
              removal_reason: "On Hold"
            }
          );
          setShowModelOnHold("");
          setCurrentGroup(null);
          setAlertConfig({
            visibility: true,
            message: "Enroll holded successfully",
            type: "success"
          });
        } catch (error) {
          console.error("error on holding enrollments");
        }
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    const payload = {
      ...updateFormData,
      ignore_incentive: updateFormData.ignoreIncentive
    };
    try {
      await api.put(
        `/enroll/update-enroll/${currentUpdateGroup._id}`,
        payload
      );
      setShowModalUpdate(false);
      setAlertConfig({
        visibility: true,
        message: "Enrollment Updated Successfully",
        type: "success"
      });
    } catch (error) {
      console.error("Error updating enroll:", error);
    }
  };
  useEffect(() => {
    if (selectedGroup) {
      api.post(`/enroll/get-next-tickets/${selectedGroup}`).then((response) => {
        setAvailableTickets(response.data.availableTickets || []);
      }).catch((error) => {
        console.error("Error fetching available tickets:", error);
      });
    } else {
      setAvailableTickets([]);
    }
  }, [selectedGroup]);
  const handleVerify = async () => {
    const {
      user_id,
      group_id,
      agent,
      referred_customer,
      referred_lead,
      referred_type
    } = formData;
    if (!user_id || !group_id) {
      notification.warning({
        message: "Please select both Group and Customer before verifying."
      });
      return;
    }
    try {
      const response = await api.get(`/enroll/get-enroll-check`, {
        params: { user_id, group_id }
      });
      const selectedUser = users.find((u) => u._id === user_id);
      const selectedGroup2 = groups.find((g) => g._id === group_id);
      const selectedAgent = agents.find((a) => a._id === agent);
      const selectedReferredCustomer = users.find(
        (u) => u._id === referred_customer
      );
      const selectedReferredLead = leads?.find?.(
        (l) => l._id === referred_lead
      );
      if (response?.data) {
        const agentName = typeof response.data.agent === "object" ? response.data.agent?.name : null;
        const referredCustomerName = typeof response.data.referred_customer === "object" ? response.data.referred_customer?.full_name : null;
        const referredLeadName = typeof response.data.referred_lead === "object" ? response.data.referred_lead?.lead_name : null;
        const referredInfoParts = [];
        if (agentName)
          referredInfoParts.push(
            ` Already referred by Agent Name: ${agentName}`
          );
        if (referredCustomerName)
          referredInfoParts.push(
            `Already referred by Customer Name: ${referredCustomerName}`
          );
        if (referredLeadName)
          referredInfoParts.push(
            ` Already referred by Lead Name: ${referredLeadName}`
          );
        if (referredInfoParts.length === 0)
          referredInfoParts.push("Enrollment exists with no referral info.");
        setFormData((prev) => ({
          ...prev,
          no_of_tickets: response?.data?.no_of_tickets ?? prev.no_of_tickets,
          payment_type: response?.data?.payment_type ?? prev.payment_type,
          referred_customer: response?.data?.referred_customer ?? prev.referred_customer,
          referred_lead: response?.data?.referred_lead ?? prev.referred_lead,
          referred_type: prev.referred_type || response?.data?.referred_type || (response.data?.agent ? "Agent" : response.data?.referred_customer ? "Customer" : response.data?.referred_lead ? "Leads" : "")
        }));
        let selectedBy = "Unknown";
        if (referred_type === "Agent")
          selectedBy = selectedAgent?.name || "Unknown Agent";
        else if (referred_type === "Customer")
          selectedBy = selectedReferredCustomer?.full_name || "Unknown Customer";
        else if (referred_type === "Leads")
          selectedBy = selectedReferredLead?.lead_name || "Unknown Lead";
        setIsExistingEnrollment(true);
        setEnrollmentStep("continue");
        notification.warning({
          message: /* @__PURE__ */ jsxDEV(
            "span",
            {
              style: {
                fontWeight: "bold",
                fontSize: "1.25rem",
                marginBottom: "10px"
              },
              children: [
                'Customer Name: "',
                selectedUser?.full_name,
                '"',
                /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1401,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("hr", { style: { margin: "10px 0", borderTop: "1px solid #ccc" } }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1402,
                  columnNumber: 15
                }, this),
                'Group Name: "',
                selectedGroup2?.group_name,
                '"',
                /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1404,
                  columnNumber: 15
                }, this),
                /* @__PURE__ */ jsxDEV("hr", { style: { margin: "10px 0", borderTop: "1px solid #ccc" } }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1405,
                  columnNumber: 15
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 1393,
              columnNumber: 11
            },
            this
          ),
          description: /* @__PURE__ */ jsxDEV("div", { style: { fontWeight: "bold", fontSize: "1.25rem" }, children: referredInfoParts.map(
            (part, index) => /* @__PURE__ */ jsxDEV("span", { children: [
              part,
              /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1413,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "hr",
                {
                  style: { margin: "10px 0", borderTop: "1px solid #ccc" }
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1414,
                  columnNumber: 19
                },
                this
              )
            ] }, index, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 1411,
              columnNumber: 13
            }, this)
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 1409,
            columnNumber: 11
          }, this),
          duration: 30
        });
        setIsExistingEnrollment(true);
        setIsVerified(true);
        setEnrollmentStep("continue");
      } else {
        setIsExistingEnrollment(false);
        setIsVerified(true);
        setEnrollmentStep("continue");
        notification.success({
          message: `Eligible for Enrollment`,
          description: `User "${selectedUser?.full_name}" can be enrolled in "${selectedGroup2?.group_name}".`,
          duration: 6
        });
      }
    } catch (err) {
      console.error("Verification error:", err);
      notification.error({
        message: "Error checking enrollment",
        description: err.response?.data?.message || "Something went wrong"
      });
    }
  };
  const handleMultiStep = async (e) => {
    e.preventDefault();
    if (enrollmentStep === "verify") {
      await handleVerify();
    } else if (enrollmentStep === "continue") {
      setEnrollmentStep("submit");
    } else if (enrollmentStep === "submit") {
      handleSubmit(e);
    }
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
          lineNumber: 1462,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
        lineNumber: 1466,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        CustomAlert,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
          lineNumber: 1467,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 overflow-hidden", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex border-b border-gray-200 mb-6", children: [
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: `py-2 px-4 text-sm font-medium ${activeTab === "enrollments" ? "border-b-2 border-violet-950 text-violet-950" : "text-gray-500 hover:text-gray-700"}`,
              onClick: () => setActiveTab("enrollments"),
              children: "Enrollments"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 1474,
              columnNumber: 15
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              className: `py-2 px-4 text-sm font-medium ${activeTab === "groupReport" ? "border-b-2 border-violet-950 text-violet-950" : "text-gray-500 hover:text-gray-700"}`,
              onClick: () => setActiveTab("groupReport"),
              children: "Group Report"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 1483,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
          lineNumber: 1473,
          columnNumber: 13
        }, this),
        activeTab === "enrollments" ? (
          // ---------- EXISTING ENROLLMENTS CONTENT ----------
          /* @__PURE__ */ jsxDEV(Fragment, { children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Enrollments" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 1496,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: /* @__PURE__ */ jsxDEV("label", { children: "Search or Select Group" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1499,
                columnNumber: 21
              }, this) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1498,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex  justify-between items-center w-full", children: [
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    showSearch: true,
                    popupMatchSelectWidth: false,
                    value: selectedGroup || "recent",
                    filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                    placeholder: "Search or Select Group",
                    onChange: handleGroupChange,
                    className: "border  h-14 w-full max-w-md",
                    children: [
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "recent", children: "Recent Enrollment" }, "$1", false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 1516,
                        columnNumber: 23
                      }, this),
                      /* @__PURE__ */ jsxDEV(Select.Option, { value: "today", children: "Today's Enrollment" }, "$2", false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 1520,
                        columnNumber: 23
                      }, this),
                      groups.map(
                        (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                          lineNumber: 1524,
                          columnNumber: 21
                        }, this)
                      )
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 1502,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    onClick: () => setShowModal(true),
                    className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
                    children: "+ Add Enrollment"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 1529,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1501,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 1497,
              columnNumber: 17
            }, this),
            TableEnrolls?.length > 0 ? /* @__PURE__ */ jsxDEV(
              DataTable,
              {
                updateHandler: handleUpdateModalOpen,
                data: filterOption(TableEnrolls, searchText),
                columns,
                exportedPdfName: "Enrollments",
                exportedFileName: `Enrollments-${TableEnrolls.length > 0 ? TableEnrolls[0].name + " to " + TableEnrolls[TableEnrolls.length - 1].name : "empty"}.csv`
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1538,
                columnNumber: 15
              },
              this
            ) : /* @__PURE__ */ jsxDEV(
              CircularLoader,
              {
                isLoading: isDataTableLoading,
                failure: TableEnrolls?.length <= 0 && selectedGroup,
                data: "Enrollment Data"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1551,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 1495,
            columnNumber: 13
          }, this)
        ) : (
          // ---------- GROUP REPORT TAB ----------
          /* @__PURE__ */ jsxDEV(GroupReport, {}, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 1561,
            columnNumber: 13
          }, this)
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
        lineNumber: 1472,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
      lineNumber: 1461,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModal,
        onClose: () => {
          setShowModal(false);
          setErrors({});
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left bg-white rounded-lg", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-6 text-2xl font-bold text-gray-900 border-b pb-3", children: "Add Enrollment" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 1573,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: [
                "Group ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1580,
                  columnNumber: 25
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1579,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full`,
                  placeholder: "Select or Search Group",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "group_id",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: formData?.group_id || void 0,
                  onChange: (value) => handleAntDSelect("group_id", value),
                  children: groups.map(
                    (group) => /* @__PURE__ */ jsxDEV(Select.Option, { value: group._id, children: group.group_name }, group._id, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 1598,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1582,
                  columnNumber: 17
                },
                this
              ),
              errors.group_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-600", children: errors.group_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1604,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 1578,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: [
                "Customer ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1610,
                  columnNumber: 28
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1609,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full`,
                  placeholder: "Select or Search Customer",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "user_id",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: formData?.user_id || void 0,
                  onChange: (value) => {
                    handleAntDSelect("user_id", value);
                    const selectedUser = users.find((u) => u._id === value);
                    if (selectedUser) {
                      setEmail(selectedUser.email || "");
                      setFormData((prev) => ({
                        ...prev,
                        email_id: selectedUser.email
                      }));
                    }
                  },
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                      user.full_name,
                      " | ",
                      user.phone_number || "No Number"
                    ] }, user._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 1641,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1612,
                  columnNumber: 17
                },
                this
              ),
              formData.user_id && /* @__PURE__ */ jsxDEV("div", { className: "mt-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "mb-2 text-sm font-semibold text-gray-700", children: [
                  "Customer Existing Details",
                  customerDetailsLoading && /* @__PURE__ */ jsxDEV("span", { className: "ml-2 text-gray-400", children: "Loading..." }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 1651,
                    columnNumber: 50
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1649,
                  columnNumber: 21
                }, this),
                !customerDetailsLoading && /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4 max-h-[240px] overflow-y-auto pr-2", children: (() => {
                  const details = getCustomerTicketDetails(
                    customerEnrollments,
                    customerPigmy,
                    customerLoans
                  );
                  if (details.length === 0) {
                    return /* @__PURE__ */ jsxDEV("div", { className: "text-sm text-gray-500 italic", children: "No existing enrollments, pigmy, or loans found." }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 1664,
                      columnNumber: 27
                    }, this);
                  }
                  return details.map(
                    (item) => /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: `border rounded-lg p-4 shadow-sm bg-white ${item.balance > 0 ? "border-red-200" : "border-green-200"}`,
                        children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-start gap-3 mb-3", children: [
                            /* @__PURE__ */ jsxDEV(Tag, { className: "text-[10px] font-bold uppercase m-0 px-2 py-0.5", children: item.type }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                              lineNumber: 1677,
                              columnNumber: 33
                            }, this),
                            /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: item.name }, void 0, false, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                              lineNumber: 1680,
                              columnNumber: 33
                            }, this),
                            item.type === "chit" && item.ticket && /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-blue-600 font-medium", children: [
                              "Ticket: ",
                              item.ticket
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                              lineNumber: 1684,
                              columnNumber: 27
                            }, this),
                            item.type === "chit" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                              /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-600", children: [
                                "Group Value: ",
                                item.group_value
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1690,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("span", { className: "text-xs text-gray-600", children: [
                                "Group Installment: ",
                                item.group_install
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1693,
                                columnNumber: 37
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                              lineNumber: 1689,
                              columnNumber: 27
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                            lineNumber: 1676,
                            columnNumber: 31
                          }, this),
                          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-x-6 gap-y-2", children: [
                            item.type === "chit" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Total Payable" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1705,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: [
                                  "₹",
                                  item.payable?.toLocaleString("en-IN")
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1708,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1704,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Total Paid" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1713,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: [
                                  "₹",
                                  item.totalPaid?.toLocaleString("en-IN")
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1716,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1712,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Penalty" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1721,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: [
                                  "₹",
                                  item.totalPenalty?.toLocaleString("en-IN")
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1724,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1720,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Late Fee" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1729,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: [
                                  "₹",
                                  item.totalLateFee?.toLocaleString("en-IN")
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1732,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1728,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Balance Due" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1737,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-semibold ${item.balance > 0 ? "text-red-600" : "text-green-600"}`, children: [
                                  "₹",
                                  item.balance?.toLocaleString("en-IN")
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1740,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1736,
                                columnNumber: 37
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                              lineNumber: 1703,
                              columnNumber: 27
                            }, this),
                            item.type === "loan" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Loan Amount" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1750,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: [
                                  "₹",
                                  item.loanAmount?.toLocaleString("en-IN")
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1753,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1749,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Start Date" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1758,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: item.startDate?.split("T")[0].split("-").reverse().join("-") }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1761,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1757,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "End Date" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1766,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: item.endDate?.split("T")[0].split("-").reverse().join("-") }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1769,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1765,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Daily Payment" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1774,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: [
                                  "₹",
                                  item.dailyPayment?.toLocaleString("en-IN")
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1777,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1773,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Total Paid" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1782,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: [
                                  "₹",
                                  item.totalPaid?.toLocaleString("en-IN")
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1785,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1781,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Balance" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1790,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-semibold ${item.balance > 0 ? "text-red-600" : "text-green-600"}`, children: [
                                  "₹",
                                  item.balance?.toLocaleString("en-IN")
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1793,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1789,
                                columnNumber: 37
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                              lineNumber: 1748,
                              columnNumber: 27
                            }, this),
                            item.type === "pigmy" && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Daily Amount" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1803,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: [
                                  "₹",
                                  item.payableAmount?.toLocaleString("en-IN")
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1806,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1802,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Start Date" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1811,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: item.startDate?.split("T")[0].split("-").reverse().join("-") }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1814,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1810,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Duration" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1819,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-gray-800", children: [
                                  item.duration,
                                  " months"
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1822,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1818,
                                columnNumber: 37
                              }, this),
                              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
                                /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] uppercase tracking-wider text-gray-400 font-medium", children: "Total Paid" }, void 0, false, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1827,
                                  columnNumber: 39
                                }, this),
                                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold text-green-600", children: [
                                  "₹",
                                  item.totalPaid?.toLocaleString("en-IN")
                                ] }, void 0, true, {
                                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                  lineNumber: 1830,
                                  columnNumber: 39
                                }, this)
                              ] }, void 0, true, {
                                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                                lineNumber: 1826,
                                columnNumber: 37
                              }, this)
                            ] }, void 0, true, {
                              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                              lineNumber: 1801,
                              columnNumber: 27
                            }, this)
                          ] }, void 0, true, {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                            lineNumber: 1701,
                            columnNumber: 31
                          }, this)
                        ]
                      },
                      item.id,
                      true,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 1670,
                        columnNumber: 23
                      },
                      this
                    )
                  );
                })() }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1655,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1648,
                columnNumber: 17
              }, this),
              formData?.user_id && /* @__PURE__ */ jsxDEV("div", { className: "mt-3", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    title: "Email ID For Payment Link Submission",
                    children: "Email"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 1846,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    title: "Email ID For Payment Link Submission",
                    type: "email",
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg w-full p-2",
                    value: email || "",
                    onChange: (e) => {
                      setEmail(e.target.value);
                      setFormData((prev) => ({
                        ...prev,
                        email_id: e.target.value
                      }));
                    }
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 1852,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1845,
                columnNumber: 17
              }, this),
              errors.email_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-600", children: errors.email_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1868,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 1608,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end mt-0 items-center gap-1", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "text-sm text-blue-600", children: "Not a customer?" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1875,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "a",
                {
                  href: "/customer-menu/user?openModal=true",
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "inline-flex items-center px-2 py-1 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 transition",
                  children: "+ Add Customer"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1879,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 1874,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex w-full gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: [
                  "Payment Type ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 1891,
                    columnNumber: 34
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1890,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full`,
                    placeholder: "Select Payment Type",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "payment_type",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: formData?.payment_type || void 0,
                    onChange: (value) => handleAntDSelect("payment_type", value),
                    children: ["Daily", "Weekly", "Monthly"].map(
                      (pType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: pType, children: pType }, pType, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 1906,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 1893,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1889,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: "Chit Asking Month" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1915,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "month",
                    className: "p-2 border rounded w-full",
                    value: selectedDate,
                    onChange: (e) => {
                      setSelectedDate(e.target.value);
                      setFormData((prev) => ({
                        ...prev,
                        chit_asking_month: e.target.value
                        // <-- FIX
                      }));
                    },
                    min: formatToYearMonth(currentYear, currentMonth)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 1918,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1914,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 1888,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex w-full gap-4", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: [
                  "Referred Type ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 1936,
                    columnNumber: 35
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 1935,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full`,
                    placeholder: "Select Referred Type",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "referred_type",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: formData?.referred_type || void 0,
                    onChange: (value) => handleAntDSelect("referred_type", value),
                    children: [
                      "Self Joining",
                      "Customer",
                      "Employee",
                      "Agent",
                      "Leads",
                      "Others"
                    ].map(
                      (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 1959,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 1938,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1934,
                columnNumber: 17
              }, this),
              formData.referred_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Select Referred Customer",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 1972,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 1967,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                    placeholder: "Select Or Search Referred Customer",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "referred_customer",
                    filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                    value: formData?.referred_customer || void 0,
                    onChange: (value) => handleAntDSelect("referred_customer", value),
                    children: users.map(
                      (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                        user.full_name,
                        " |",
                        " ",
                        user.phone_number ? user.phone_number : "No Number"
                      ] }, user._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 1993,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 1975,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 1966,
                columnNumber: 17
              }, this),
              formData.referred_type === "Leads" && /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Select Referred Leads",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2008,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2003,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                    placeholder: "Select Or Search Referred Leads",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "referred_lead",
                    filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                    value: formData?.referred_lead || void 0,
                    onChange: (value) => handleAntDSelect("referred_lead", value),
                    children: leads.map(
                      (lead) => /* @__PURE__ */ jsxDEV(Select.Option, { value: lead._id, children: [
                        lead.lead_name,
                        " | ",
                        lead.lead_phone
                      ] }, lead._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2029,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2011,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2002,
                columnNumber: 17
              }, this),
              formData.referred_type === "Agent" && /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Select Referred Agent",
                  " ",
                  " ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2038,
                    columnNumber: 112
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2038,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                    placeholder: "Select or Search Referred Agent",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "agent",
                    filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                    value: formData.agent || void 0,
                    onChange: (value) => handleAntDSelect("agent", value),
                    children: agents.map(
                      (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: [
                        agent.name,
                        " | ",
                        agent.phone_number
                      ] }, agent._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2052,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2039,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2037,
                columnNumber: 17
              }, this),
              formData.referred_type === "Employee" && /* @__PURE__ */ jsxDEV("div", { className: "w-1/2", children: [
                /* @__PURE__ */ jsxDEV(
                  "label",
                  {
                    className: "block mb-2 text-sm font-medium text-gray-900",
                    htmlFor: "category",
                    children: [
                      "Select Referred Employee",
                      " ",
                      /* @__PURE__ */ jsxDEV("span", { className: "text-red-500 ", children: "*" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2069,
                        columnNumber: 23
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2064,
                    columnNumber: 21
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full `,
                    placeholder: "Select Or Search Referred Employee",
                    popupMatchSelectWidth: false,
                    showSearch: true,
                    name: "agent",
                    filterOption: (input, option) => {
                      if (!option || !option.children) return false;
                      return option.children.toString().toLowerCase().includes(input.toLowerCase());
                    },
                    value: formData?.agent || void 0,
                    onChange: (value) => handleAntDSelect("agent", value),
                    children: employees.map(
                      (employee) => /* @__PURE__ */ jsxDEV(Select.Option, { value: employee._id, children: [
                        employee.name,
                        " | ",
                        employee.phone_number
                      ] }, employee._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2090,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2072,
                    columnNumber: 21
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2063,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 1933,
              columnNumber: 15
            }, this),
            formData.group_id && availableTicketsAdd.length === 0 ? /* @__PURE__ */ jsxDEV("p", { className: "text-center text-red-600 font-medium", children: "Group is Full" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2100,
              columnNumber: 15
            }, this) : formData.group_id && availableTicketsAdd.length !== 0 ? /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-semibold text-gray-800", children: [
                "Number of Tickets ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2107,
                  columnNumber: 39
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2106,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "number",
                  name: "no_of_tickets",
                  value: formData?.no_of_tickets,
                  id: "name",
                  onChange: handleChange,
                  placeholder: "Enter the Number of Tickets",
                  required: true,
                  max: availableTicketsAdd.length,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2109,
                  columnNumber: 19
                },
                this
              ),
              errors.no_of_tickets && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-red-600", children: errors.no_of_tickets }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2121,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-xs text-blue-800 text-center", children: [
                "Only ",
                availableTicketsAdd.length,
                " tickets left"
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2125,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2105,
              columnNumber: 15
            }, this) : null,
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  id: "ignoreIncentive",
                  name: "ignoreIncentive",
                  checked: formData?.ignoreIncentive || false,
                  onChange: (e) => setFormData((prev) => ({
                    ...prev,
                    ignoreIncentive: e.target.checked
                  })),
                  className: "h-4 w-4 cursor-pointer rounded border-slate-300 text-indigo-600 focus:ring-2 focus:ring-indigo-500"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2132,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "ignoreIncentive",
                  className: "cursor-pointer select-none text-sm font-medium text-slate-700",
                  children: "Ignore Incentive"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2146,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2131,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "border-t pt-4 space-y-4", children: [
              /* @__PURE__ */ jsxDEV("h2", { className: "text-base font-semibold text-gray-900", children: "Actions" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2155,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
                  /* @__PURE__ */ jsxDEV(FaWhatsapp, { className: "text-green-600 w-5 h-5" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2160,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: "Enable WhatsApp Sending" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2161,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2159,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: thirdPartyEnable.whatsapp,
                    onChange: () => setThirdPartyEnable((prev) => ({
                      ...prev,
                      whatsapp: !prev.whatsapp
                    })),
                    className: "w-5 h-5 accent-green-600 cursor-pointer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2165,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2158,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
                  /* @__PURE__ */ jsxDEV(FiLink, { className: "text-green-600 w-5 h-5" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2179,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: "Enable Registration Payment Link" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2180,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2178,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: thirdPartyEnable.paymentLink,
                    onChange: () => setThirdPartyEnable((prev) => ({
                      ...prev,
                      paymentLink: !prev.paymentLink
                    })),
                    className: "w-5 h-5 accent-green-600 cursor-pointer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2184,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2177,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center space-x-3", children: [
                  /* @__PURE__ */ jsxDEV(FiMail, { className: "w-5 h-5", "aria-hidden": "true" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2198,
                    columnNumber: 21
                  }, this),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-gray-800", children: "Enable Email" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2199,
                    columnNumber: 21
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2197,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "checkbox",
                    checked: thirdPartyEnable.email,
                    onChange: () => setThirdPartyEnable((prev) => ({
                      ...prev,
                      email: !prev.email
                    })),
                    className: "w-5 h-5 accent-green-600 cursor-pointer"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2201,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2196,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2154,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end pt-4", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "button",
                disabled: loading || enrollmentStep === "submit" && (!isVerified || availableTicketsAdd.length === 0),
                onClick: handleMultiStep,
                className: `w-1/4 text-white font-medium rounded-lg text-sm px-5 py-2.5 transition-colors ${loading ? "bg-gray-400 cursor-not-allowed" : enrollmentStep === "verify" ? "bg-gray-600 hover:bg-gray-700" : enrollmentStep === "continue" ? "bg-green-600 hover:bg-green-700" : "bg-violet-700 hover:bg-violet-800"}`,
                children: loading ? "Processing..." : enrollmentStep === "verify" ? "Verify" : enrollmentStep === "continue" ? "Continue" : "Submit"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2216,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2215,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 1577,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
          lineNumber: 1572,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
        lineNumber: 1565,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => {
          setShowModalUpdate(false);
          setErrors({});
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-6 border-b pb-3", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV("span", { className: "bg-gradient-to-r from-violet-600 to-indigo-600 w-1 h-6 rounded-full" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2256,
                columnNumber: 17
              }, this),
              "Update Enrollment"
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2255,
              columnNumber: 15
            }, this),
            currentUpdateGroup?.unlink_branch ? /* @__PURE__ */ jsxDEV(
              Popconfirm,
              {
                title: "Link Branch",
                description: "Are you sure you want to link this branch to the customer?",
                okText: "Yes",
                cancelText: "No",
                onConfirm: () => {
                  handlelinkBranch(currentUpdateGroup?._id);
                },
                children: modifyPayment && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    className: "px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg text-sm font-medium transition-all duration-200 shadow-md hover:shadow-lg flex items-center gap-2",
                    children: [
                      /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2281,
                        columnNumber: 25
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2280,
                        columnNumber: 23
                      }, this),
                      "Link Branch"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2276,
                    columnNumber: 17
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2262,
                columnNumber: 15
              },
              this
            ) : /* @__PURE__ */ jsxDEV(
              Popconfirm,
              {
                title: "Unlink Branch",
                description: "Are you sure you want to unlink this branch from the customer?",
                okText: "Yes",
                cancelText: "No",
                onConfirm: () => {
                  handleUnlinkBranch(currentUpdateGroup?._id);
                },
                children: modifyPayment && /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    className: "px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg text-sm font-medium transition-all duration-200 shadow-md hover:shadow-lg flex items-center gap-2",
                    children: [
                      /* @__PURE__ */ jsxDEV("svg", { className: "w-4 h-4", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2308,
                        columnNumber: 25
                      }, this) }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2307,
                        columnNumber: 23
                      }, this),
                      "Unlink Branch"
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2303,
                    columnNumber: 17
                  },
                  this
                )
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2289,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 2254,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, children: [
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "group_id",
                  children: [
                    "Group ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2324,
                      columnNumber: 25
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2320,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  name: "group_id",
                  id: "group_id",
                  value: updateFormData.group_id,
                  onChange: handleInputChange,
                  required: true,
                  disabled: true,
                  className: "bg-gray-100 border h-14 border-gray-300 text-gray-600 text-sm rounded-lg w-full px-4 cursor-not-allowed",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Group" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2335,
                      columnNumber: 19
                    }, this),
                    groups.map(
                      (group) => /* @__PURE__ */ jsxDEV("option", { value: group._id, children: group.group_name }, group._id, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2337,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2326,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2319,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "user_id",
                  children: [
                    "Customer ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2349,
                      columnNumber: 28
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2345,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  name: "user_id",
                  id: "user_id",
                  value: updateFormData.user_id,
                  onChange: handleInputChange,
                  required: true,
                  disabled: true,
                  className: "bg-gray-100 border h-14 border-gray-300 text-gray-600 text-sm rounded-lg w-full px-4 cursor-not-allowed",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Customer" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2360,
                      columnNumber: 19
                    }, this),
                    users.map(
                      (user) => /* @__PURE__ */ jsxDEV("option", { value: user._id, children: [
                        user.full_name,
                        " | ",
                        user.phone_number
                      ] }, user._id, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2362,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2351,
                  columnNumber: 17
                },
                this
              ),
              errors.user_id && /* @__PURE__ */ jsxDEV("p", { className: "mt-1 text-sm text-red-600", children: errors.user_id }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2368,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2344,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "payment_type",
                  children: [
                    "Payment Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2377,
                      columnNumber: 32
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2373,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full hover:border-violet-400 focus:border-violet-500 transition-colors",
                  placeholder: "Select Payment Type",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "payment_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.payment_type || void 0,
                  onChange: (value) => handleAntInputDSelect("payment_type", value),
                  children: ["Daily", "Weekly", "Monthly"].map(
                    (pType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: pType, children: pType }, pType.toLowerCase(), false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2392,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2379,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2372,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Chit Asking Month" }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2400,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "month",
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full px-4 focus:ring-2 focus:ring-violet-500 focus:border-violet-500 outline-none transition-colors",
                  value: updateFormData.chit_asking_month,
                  onChange: (e) => setUpdateFormData((prev) => ({
                    ...prev,
                    chit_asking_month: e.target.value
                  }))
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2403,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2399,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "referred_type",
                  children: [
                    "Referred Type ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2421,
                      columnNumber: 33
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2417,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full hover:border-violet-400 focus:border-violet-500 transition-colors",
                  placeholder: "Select Referred Type",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "referred_type",
                  filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.referred_type || void 0,
                  onChange: (value) => handleAntInputDSelect("referred_type", value),
                  children: [
                    "Self Joining",
                    "Customer",
                    "Employee",
                    "Agent",
                    "Leads",
                    "Blocked Referral",
                    "Others"
                  ].map(
                    (refType) => /* @__PURE__ */ jsxDEV(Select.Option, { value: refType, children: refType }, refType, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2444,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2423,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2416,
              columnNumber: 15
            }, this),
            updateFormData.referred_type === "Customer" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Referred Customer ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2454,
                  columnNumber: 39
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2453,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full hover:border-violet-400 focus:border-violet-500 transition-colors",
                  placeholder: "Select Or Search Referred Customer",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "referred_customer",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.referred_customer || void 0,
                  onChange: (value) => handleAntInputDSelect("referred_customer", value),
                  children: users.map(
                    (user) => /* @__PURE__ */ jsxDEV(Select.Option, { value: user._id, children: [
                      user.full_name,
                      " | ",
                      user.phone_number
                    ] }, user._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2469,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2456,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2452,
              columnNumber: 15
            }, this),
            updateFormData.referred_type === "Agent" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Referred Agent ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2480,
                  columnNumber: 36
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2479,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full hover:border-violet-400 focus:border-violet-500 transition-colors",
                  placeholder: "Select or Search Referred Agent",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "agent",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData.agent || void 0,
                  onChange: (value) => handleAntInputDSelect("agent", value),
                  children: agents.map(
                    (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: [
                      agent.name,
                      " | ",
                      agent.phone_number
                    ] }, agent._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2495,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2482,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2478,
              columnNumber: 15
            }, this),
            updateFormData.referred_type === "Leads" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Referred Leads ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2506,
                  columnNumber: 36
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2505,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full hover:border-violet-400 focus:border-violet-500 transition-colors",
                  placeholder: "Select Or Search Referred Lead",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "referred_lead",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.referred_lead || void 0,
                  onChange: (value) => handleAntInputDSelect("referred_lead", value),
                  children: leads.map(
                    (lead) => /* @__PURE__ */ jsxDEV(Select.Option, { value: lead._id, children: [
                      lead.lead_name,
                      " | ",
                      lead.lead_phone
                    ] }, lead._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2521,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2508,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2504,
              columnNumber: 15
            }, this),
            updateFormData.referred_type === "Employee" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
              /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                "Referred Employee ",
                /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2532,
                  columnNumber: 39
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2531,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full hover:border-violet-400 focus:border-violet-500 transition-colors",
                  placeholder: "Select Or Search Referred Employee",
                  popupMatchSelectWidth: false,
                  showSearch: true,
                  name: "agent",
                  filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
                  value: updateFormData?.agent || void 0,
                  onChange: (value) => handleAntInputDSelect("agent", value),
                  children: employees.map(
                    (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: [
                      agent.name,
                      " | ",
                      agent.phone_number
                    ] }, agent._id, true, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2547,
                      columnNumber: 19
                    }, this)
                  )
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2534,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2530,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxDEV(
                "input",
                {
                  type: "checkbox",
                  id: "ignoreIncentive",
                  name: "ignoreIncentive",
                  checked: updateFormData?.ignoreIncentive || false,
                  onChange: (e) => setUpdateFormData((prev) => ({
                    ...prev,
                    ignoreIncentive: e.target.checked
                  })),
                  className: "h-4 w-4 cursor-pointer rounded border-slate-300 text-indigo-600 focus:ring-2 focus:ring-indigo-500"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2555,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "ignoreIncentive",
                  className: "cursor-pointer select-none text-sm font-medium text-slate-700",
                  children: "Ignore Incentive"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2569,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2554,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "no_of_tickets",
                  children: [
                    "Ticket ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2581,
                      columnNumber: 26
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2577,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  name: "tickets",
                  value: updateFormData.tickets,
                  onChange: handleInputChange,
                  id: "no_of_tickets",
                  disabled: true,
                  required: true,
                  className: "bg-gray-100 border h-14 border-gray-300 text-gray-600 text-sm rounded-lg w-full px-4 cursor-not-allowed",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "Select Ticket" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2592,
                      columnNumber: 19
                    }, this),
                    availableTickets.concat([updateFormData.tickets]).map(
                      (ticket, index) => /* @__PURE__ */ jsxDEV("option", { value: ticket, children: ticket }, index, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2596,
                        columnNumber: 19
                      }, this)
                    )
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2583,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2576,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-full text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-3 text-center transition-all duration-200 shadow-md hover:shadow-lg",
                children: /* @__PURE__ */ jsxDEV("span", { className: "flex items-center justify-center gap-2", children: [
                  /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ jsxDEV("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2609,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2608,
                    columnNumber: 19
                  }, this),
                  "Update Enrollment"
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2607,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2603,
                columnNumber: 15
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 2318,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
          lineNumber: 2253,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
        lineNumber: 2246,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalRemove,
        onClose: () => {
          setShowModalRemove(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Please Select a Reason for Removal" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 2625,
            columnNumber: 13
          }, this),
          currentGroup && /* @__PURE__ */ jsxDEV("form", { onSubmit: handleRemoveGroup, className: "space-y-6", children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  htmlFor: "removalReason",
                  className: "block mb-2 text-sm font-medium text-gray-700",
                  children: [
                    "Removal Reason ",
                    /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2636,
                      columnNumber: 36
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2632,
                  columnNumber: 19
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "select",
                {
                  id: "removalReason",
                  name: "removalReason",
                  value: removalReason,
                  onChange: (e) => setRemovalReason(e.target.value),
                  required: true,
                  className: "block w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-500 focus:border-red-500",
                  children: [
                    /* @__PURE__ */ jsxDEV("option", { value: "", children: "-- Select Reason --" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2646,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Suspend", children: "Suspend" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2650,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "In Active Customer", children: "InActive Customer" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2651,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Legal", children: "Legal" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2654,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("option", { value: "Others", children: "Others" }, void 0, false, {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                      lineNumber: 2655,
                      columnNumber: 21
                    }, this)
                  ]
                },
                void 0,
                true,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2638,
                  columnNumber: 19
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2631,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-full text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5",
                children: "Remove"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2659,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 2630,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
          lineNumber: 2624,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
        lineNumber: 2617,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModelOnHold,
        onClose: () => {
          setShowModelOnHold(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-gray-50 rounded-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 shadow-lg", children: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "h-8 w-8 text-white",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              strokeWidth: 2,
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  d: "M12 9v4m0 4h.01M10.29 3.86l-7.5 13A1 1 0 003.66 18h16.68a1 1 0 00.87-1.5l-7.5-13a1 1 0 00-1.74 0z"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2689,
                  columnNumber: 21
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2682,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 2681,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 2680,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: "Confirm Enrollment Hold?" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2699,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-gray-600 leading-relaxed", children: "Are you sure you want to place this enrollment on hold? The customer will be temporarily excluded from participation until the enrollment is reactivated." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2702,
              columnNumber: 17
            }, this),
            currentGroup && /* @__PURE__ */ jsxDEV("div", { className: "mt-5 bg-white rounded-xl border border-gray-200 p-5 shadow-sm", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "h-8 w-1 bg-yellow-500 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2709,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-700", children: "Customer Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2710,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2708,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-3", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Customer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2715,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-1", children: currentGroup?.user_id?.full_name || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2716,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2714,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-3", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Group" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2721,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-1", children: currentGroup?.group_id?.group_name || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2722,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2720,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-3", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Phone" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2727,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-1", children: currentGroup?.user_id?.phone_number || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2728,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2726,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-3", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Ticket" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2733,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-1", children: currentGroup?.tickets || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2734,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2732,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2713,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex items-start gap-2 bg-red-50 rounded-lg p-3 border-l-4 border-red-500", children: [
                /* @__PURE__ */ jsxDEV("svg", { className: "w-5 h-5 text-red-500 flex-shrink-0", fill: "currentColor", viewBox: "0 0 20 20", children: /* @__PURE__ */ jsxDEV("path", { fillRule: "evenodd", d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9a1 1 0 00-1-1z", clipRule: "evenodd" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2742,
                  columnNumber: 25
                }, this) }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2741,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-700", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Important:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2745,
                    columnNumber: 25
                  }, this),
                  " Verify customer details before proceeding."
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2744,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2740,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2707,
              columnNumber: 17
            }, this),
            currentGroup && /* @__PURE__ */ jsxDEV("form", { onSubmit: handleOnHoldGroup, className: "mt-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col-reverse sm:flex-row justify-end gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    setShowModelOnHold(false);
                    setCurrentGroup(null);
                  },
                  className: "inline-flex justify-center items-center px-6 py-2.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 hover:border-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-300 transition-all",
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2754,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "inline-flex justify-center items-center px-6 py-2.5 text-sm font-medium text-white bg-yellow-500 rounded-lg hover:bg-yellow-600 focus:outline-none focus:ring-4 focus:ring-yellow-300 shadow-md hover:shadow-lg transition-all",
                  children: "Confirm Hold"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2764,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2753,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2752,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 2698,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
          lineNumber: 2679,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
          lineNumber: 2678,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
        lineNumber: 2671,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: activateModelOpen,
        onClose: () => {
          setActivateModelOpen(false);
          setCurrentGroup(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "p-6 bg-gray-50 rounded-xl", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-start gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxDEV("div", { className: "flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-green-400 to-green-600 shadow-lg", children: /* @__PURE__ */ jsxDEV(
            "svg",
            {
              className: "h-8 w-8 text-white",
              fill: "none",
              stroke: "currentColor",
              viewBox: "0 0 24 24",
              strokeWidth: 2,
              children: /* @__PURE__ */ jsxDEV(
                "path",
                {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  d: "M5 13l4 4L19 7"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2795,
                  columnNumber: 21
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2788,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 2787,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 2786,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-gray-900", children: "Confirm Enrollment Activation?" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2805,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "mt-2 text-sm text-gray-600 leading-relaxed", children: "Are you sure you want to reactivate this enrollment? The customer will be eligible to participate in all future activities and draws." }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2809,
              columnNumber: 17
            }, this),
            currentGroup && /* @__PURE__ */ jsxDEV("div", { className: "mt-5 bg-white rounded-xl border border-gray-200 p-5 shadow-sm", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "h-8 w-1 bg-green-500 rounded-full" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2817,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-semibold text-gray-700", children: "Customer Details" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2818,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2816,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-3", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-3", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Customer" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2825,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-1", children: currentGroup?.user_id?.full_name || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2826,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2824,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-3", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Group" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2832,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-1", children: currentGroup?.group_id?.group_name || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2833,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2831,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-3", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Phone" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2839,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-1", children: currentGroup?.user_id?.phone_number || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2840,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2838,
                  columnNumber: 23
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "bg-gray-50 rounded-lg p-3", children: [
                  /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-medium text-gray-500", children: "Tickets" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2846,
                    columnNumber: 25
                  }, this),
                  /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-semibold text-gray-800 mt-1", children: currentGroup?.tickets || "-" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2847,
                    columnNumber: 25
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2845,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2823,
                columnNumber: 21
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "mt-4 flex items-start gap-2 bg-green-50 rounded-lg p-3 border-l-4 border-green-500", children: [
                /* @__PURE__ */ jsxDEV(
                  "svg",
                  {
                    className: "w-5 h-5 text-green-500 flex-shrink-0",
                    fill: "currentColor",
                    viewBox: "0 0 20 20",
                    children: /* @__PURE__ */ jsxDEV(
                      "path",
                      {
                        fillRule: "evenodd",
                        d: "M18 10A8 8 0 114 10a8 8 0 0116 0zm-9 1l2 2 4-4",
                        clipRule: "evenodd"
                      },
                      void 0,
                      false,
                      {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                        lineNumber: 2859,
                        columnNumber: 25
                      },
                      this
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2854,
                    columnNumber: 23
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-green-700", children: [
                  /* @__PURE__ */ jsxDEV("span", { className: "font-semibold", children: "Activation Notice:" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                    lineNumber: 2867,
                    columnNumber: 25
                  }, this),
                  "This customer will be restored to active status immediately."
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2866,
                  columnNumber: 23
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                lineNumber: 2853,
                columnNumber: 21
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2815,
              columnNumber: 17
            }, this),
            currentGroup && /* @__PURE__ */ jsxDEV("form", { onSubmit: handleActivateEnrollment, className: "mt-6", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col-reverse sm:flex-row justify-end gap-3", children: [
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "button",
                  onClick: () => {
                    setActivateModelOpen(false);
                    setCurrentGroup(null);
                  },
                  className: "inline-flex justify-center items-center px-6 py-2.5 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50",
                  children: "Cancel"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2877,
                  columnNumber: 23
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                "button",
                {
                  type: "submit",
                  className: "inline-flex justify-center items-center px-6 py-2.5 text-sm font-medium text-white bg-green-600 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-4 focus:ring-green-300 shadow-md",
                  children: "Confirm Activation"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
                  lineNumber: 2888,
                  columnNumber: 23
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2876,
              columnNumber: 21
            }, this) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
              lineNumber: 2875,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
            lineNumber: 2804,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
          lineNumber: 2785,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
          lineNumber: 2784,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
        lineNumber: 2777,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
    lineNumber: 1460,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx",
    lineNumber: 1459,
    columnNumber: 5
  }, this);
};
_s(Enroll, "iTuv0O56nLwQ60hR7XShc/7J7SA=");
_c = Enroll;
export default Enroll;
var _c;
$RefreshReg$(_c, "Enroll");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/Enroll.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNFFrQixTQTBzQ0osVUExc0NJOzJCQTVRbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQSxTQUFTQSxXQUFXQyxnQkFBZ0I7QUFDcEMsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxTQUFTO0FBQ2hCLFNBQVNDLGlCQUFpQjtBQUMxQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxRQUFRQyxVQUFVQyxjQUFjQyxTQUFTQyxZQUFZQyxTQUFTQyxXQUFXO0FBQ2xGLFNBQVNDLGdCQUFnQjtBQUN6QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxvQkFBb0I7QUFDM0IsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxZQUFZO0FBQ3JCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLDhCQUE4QjtBQUNyQyxNQUFNQyxTQUFTQSxNQUFNO0FBQUFDLEtBQUE7QUFDbkIsUUFBTSxDQUFDQyxRQUFRQyxTQUFTLElBQUk3QixTQUFTLEVBQUU7QUFDdkMsUUFBTSxDQUFDOEIsT0FBT0MsUUFBUSxJQUFJL0IsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2dDLGNBQWNDLGVBQWUsSUFBSWpDLFNBQVMsRUFBRTtBQUNuRCxRQUFNLENBQUNrQyxlQUFlQyxnQkFBZ0IsSUFBSW5DLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNvQyxlQUFlQyxnQkFBZ0IsSUFBSXJDLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNzQyxXQUFXQyxZQUFZLElBQUl2QyxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDd0MsaUJBQWlCQyxrQkFBa0IsSUFBSXpDLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUMwQyxvQkFBb0JDLHFCQUFxQixJQUFJM0MsU0FBUyxJQUFJO0FBQ2pFLFFBQU0sQ0FBQzRDLGtCQUFrQkMsbUJBQW1CLElBQUk3QyxTQUFTLEVBQUU7QUFDM0QsUUFBTSxDQUFDOEMsaUJBQWlCQyxrQkFBa0IsSUFBSS9DLFNBQVMsS0FBSztBQUM1RCxRQUFNLENBQUNnRCxpQkFBaUJDLGtCQUFrQixJQUFJakQsU0FBUyxLQUFLO0FBQzVELFFBQU0sQ0FBQ2tELGNBQWNDLGVBQWUsSUFBSW5ELFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUNvRCxxQkFBcUJDLHNCQUFzQixJQUFJckQsU0FBUyxFQUFFO0FBQ2pFLFFBQU0sQ0FBQ3NELFNBQVNDLFVBQVUsSUFBSXZELFNBQVMsS0FBSztBQUM1QyxRQUFNLENBQUN3RCxvQkFBb0JDLHFCQUFxQixJQUFJekQsU0FBUyxLQUFLO0FBQ2xFLFFBQU0sQ0FBQzBELFFBQVFDLFNBQVMsSUFBSTNELFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLFFBQU0sQ0FBQzRELGNBQWNDLGVBQWUsSUFBSTdELFNBQVMsSUFBSTtBQUNyRCxRQUFNLENBQUM4RCxPQUFPQyxRQUFRLElBQUkvRCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZ0UsUUFBUUMsU0FBUyxJQUFJakUsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ2tFLGVBQWVDLGdCQUFnQixJQUFJbkUsU0FBUyxFQUFFO0FBQ3JELFFBQU1vRSxRQUFPLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNsRCxRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSXpFLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUMwRSxrQkFBa0JDLG1CQUFtQixJQUFJM0UsU0FBUztBQUFBLElBQ3ZENEUsT0FBTztBQUFBLElBQ1BDLFVBQVU7QUFBQSxJQUNWQyxhQUFhO0FBQUEsRUFDZixDQUFDO0FBQ0QsUUFBTSxDQUFDRixPQUFPRyxRQUFRLElBQUkvRSxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDZ0YsZ0JBQWdCQyxpQkFBaUIsSUFBSWpGLFNBQVMsUUFBUTtBQUM3RCxRQUFNLENBQUNrRixhQUFhQyxjQUFjLElBQUluRixTQUFTO0FBQUEsSUFDN0NvRixZQUFZO0FBQUEsSUFDWnJFLFNBQVM7QUFBQSxJQUNUc0UsTUFBTTtBQUFBLEVBQ1IsQ0FBQztBQUNELFFBQU0sQ0FBQ0Msc0JBQXNCQyx1QkFBdUIsSUFBSXZGLFNBQVMsS0FBSztBQUN0RSxRQUFNLENBQUN3RixPQUFPQyxRQUFRLElBQUl6RixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDMEYsV0FBV0MsWUFBWSxJQUFJM0YsU0FBUyxhQUFhO0FBQ3hELFFBQU0sQ0FBQzRGLFVBQVVDLFdBQVcsSUFBSTdGLFNBQVM7QUFBQSxJQUN2QzhGLFVBQVU7QUFBQSxJQUNWQyxTQUFTO0FBQUEsSUFDVEMsZUFBZTtBQUFBLElBQ2ZDLGVBQWU7QUFBQSxJQUNmQyxjQUFjO0FBQUEsSUFDZEMsbUJBQW1CO0FBQUEsSUFDbkJDLE9BQU87QUFBQSxJQUNQQyxlQUFlO0FBQUEsSUFDZkMsVUFBVTtBQUFBLElBQ1ZDLG1CQUFtQjtBQUFBLElBQ25CQyxZQUFZO0FBQUEsSUFDWkMsaUJBQWlCO0FBQUEsRUFDbkIsQ0FBQztBQUNELFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJM0csU0FBUyxLQUFLO0FBQ2xELFFBQU0sQ0FBQzRHLGdCQUFnQkMsaUJBQWlCLElBQUk3RyxTQUFTO0FBQUEsSUFDbkQ4RixVQUFVO0FBQUEsSUFDVkMsU0FBUztBQUFBLElBQ1RlLFNBQVM7QUFBQSxJQUNUWixjQUFjO0FBQUEsSUFDZEQsZUFBZTtBQUFBLElBQ2ZFLG1CQUFtQjtBQUFBLElBQ25CQyxPQUFPO0FBQUEsSUFDUEMsZUFBZTtBQUFBLElBQ2ZFLG1CQUFtQjtBQUFBLElBQ25CUSxrQkFBa0I7QUFBQSxJQUNsQkMsdUJBQXVCO0FBQUEsSUFDdkJDLDJCQUEyQjtBQUFBLElBQzNCQyx1QkFBdUI7QUFBQSxJQUN2QkMsd0JBQXdCO0FBQUEsSUFDeEJWLGlCQUFpQjtBQUFBLEVBQ25CLENBQUM7QUFFRCxRQUFNLENBQUNXLFlBQVlDLGFBQWEsSUFBSXJILFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUNzSCxrQkFBa0JDLG1CQUFtQixJQUFJdkgsU0FBUyxFQUFFO0FBQzNELFFBQU0sQ0FBQ3dILG1CQUFtQkMsb0JBQW9CLElBQUl6SCxTQUFTLEtBQUs7QUFFaEUsUUFBTTBILFFBQVEsb0JBQUlyRCxLQUFLO0FBQ3ZCLFFBQU1zRCxjQUFjRCxNQUFNRSxZQUFZO0FBQ3RDLFFBQU1DLGVBQWVDLE9BQU9KLE1BQU1LLFNBQVMsSUFBSSxDQUFDLEVBQUVDLFNBQVMsR0FBRyxHQUFHO0FBQ2pFLFFBQU1DLG1CQUFtQixHQUFHTixXQUFXLElBQUlFLFlBQVk7QUFDdkQsV0FBU0ssV0FBVzlELE9BQU07QUFDeEIsVUFBTStELE9BQU8vRCxNQUFLd0QsWUFBWTtBQUM5QixVQUFNUSxRQUFRLElBQUloRSxNQUFLMkQsU0FBUyxJQUFJLENBQUMsR0FBR00sTUFBTSxFQUFFO0FBQ2hELFVBQU1DLE1BQU0sSUFBSWxFLE1BQUttRSxRQUFRLENBQUMsR0FBR0YsTUFBTSxFQUFFO0FBQ3pDLFdBQU8sR0FBR0YsSUFBSSxJQUFJQyxLQUFLLElBQUlFLEdBQUc7QUFBQSxFQUNoQztBQUVBLFFBQU0sQ0FBQ0UsY0FBY0MsZUFBZSxJQUFJekksU0FBUyxFQUFFO0FBQ25ELFFBQU0sQ0FBQzBJLGVBQWVDLGdCQUFnQixJQUFJM0ksU0FBUyxDQUFDO0FBQ3BELFFBQU0sQ0FBQzRJLGVBQWVDLGdCQUFnQixJQUFJN0ksU0FBUyxLQUFLO0FBQ3hELFFBQU0sQ0FBQzhJLHlCQUF5QkMsMEJBQTBCLElBQUkvSSxTQUFTLEtBQUs7QUFFNUUsUUFBTSxDQUFDZ0oscUJBQXFCQyxzQkFBc0IsSUFBSWpKLFNBQVMsRUFBRTtBQUNqRSxRQUFNLENBQUNrSixlQUFlQyxnQkFBZ0IsSUFBSW5KLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNvSixlQUFlQyxnQkFBZ0IsSUFBSXJKLFNBQVMsRUFBRTtBQUNyRCxRQUFNLENBQUNzSix3QkFBd0JDLHlCQUF5QixJQUFJdkosU0FBUyxLQUFLO0FBRTFFLFFBQU13SixhQUFhO0FBQUEsSUFDakI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQVU7QUFHWixRQUFNLENBQUNDLGFBQWFDLGNBQWMsSUFBSTFKLFNBQVM7QUFBQSxJQUM3QzJKLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsSUFDVkMsT0FBTztBQUFBLElBQ1BDLE9BQU87QUFBQSxJQUNQQyxLQUFLO0FBQUEsSUFDTEMsTUFBTTtBQUFBLElBQ05DLE1BQU07QUFBQSxJQUNOQyxRQUFRO0FBQUEsSUFDUkMsV0FBVztBQUFBLElBQ1hDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsSUFDVkMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUdELFFBQU1DLDhCQUE4QkEsQ0FBQ0MsTUFBTTtBQUN6QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJyRCxrQkFBY29ELEtBQUs7QUFBQSxFQUNyQjtBQUNBMUssWUFBVSxNQUFNO0FBQ2QsVUFBTTRLLE9BQU9DLGFBQWFDLFFBQVEsTUFBTTtBQUN4QyxVQUFNQyxVQUFVQyxLQUFLQyxNQUFNTCxJQUFJO0FBQy9CLFVBQU1NLFVBQVVILFNBQVNJO0FBQ3pCLFFBQUlELFNBQVM7QUFDWHhGLGVBQVNxRixRQUFRSSxHQUFHO0FBRXBCckYsa0JBQVksQ0FBQ3NGLFVBQVUsRUFBRSxHQUFHQSxNQUFNM0UsWUFBWXlFLFFBQVEsRUFBRTtBQUFBLElBQzFELE9BQU87QUFDTHhGLGVBQVMsRUFBRTtBQUFBLElBQ2I7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUNMMUYsWUFBVSxNQUFNO0FBQ2QsVUFBTXFMLGNBQWMsWUFBWTtBQUM5QixVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNbkwsSUFBSW9MLElBQUksd0JBQXdCO0FBRXZEekosa0JBQVV3SixTQUFTRSxJQUFJO0FBQUEsTUFDekIsU0FBU0MsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFDQUosZ0JBQVk7QUFBQSxFQUNkLEdBQUcsRUFBRTtBQUVMLFFBQU1NLDJCQUEyQixPQUFPQyxXQUFXO0FBQ2pELFFBQUk7QUFDRixZQUFNQyxNQUFNLE1BQU0xTCxJQUFJb0wsSUFBSSwyQkFBMkJLLE1BQU0sRUFBRTtBQUM3RDFDLDZCQUF1QjJDLElBQUlMLE1BQU1BLElBQUk7QUFBQSxJQUN2QyxTQUFTTSxLQUFLO0FBQ1pKLGNBQVFELE1BQU0sd0NBQXdDSyxHQUFHO0FBQ3pENUMsNkJBQXVCLEVBQUU7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNkMscUJBQXFCLE9BQU9ILFdBQVc7QUFDM0MsUUFBSTtBQUNGLFlBQU1DLE1BQU0sTUFBTTFMLElBQUlvTCxJQUFJLCtDQUErQ0ssTUFBTSxFQUFFO0FBQ2pGeEMsdUJBQWlCeUMsSUFBSUwsTUFBTUEsSUFBSTtBQUFBLElBQ2pDLFNBQVNNLEtBQUs7QUFDWkosY0FBUUQsTUFBTSxrQ0FBa0NLLEdBQUc7QUFDbkQxQyx1QkFBaUIsRUFBRTtBQUFBLElBQ3JCO0FBQUEsRUFDRjtBQUVBLFFBQU00QyxxQkFBcUIsT0FBT0osV0FBVztBQUMzQyxRQUFJO0FBQ0YsWUFBTUMsTUFBTSxNQUFNMUwsSUFBSW9MLElBQUksd0NBQXdDSyxNQUFNLEVBQUU7QUFDMUV0Qyx1QkFBaUJ1QyxJQUFJTCxNQUFNQSxJQUFJO0FBQUEsSUFDakMsU0FBU00sS0FBSztBQUNaSixjQUFRRCxNQUFNLGtDQUFrQ0ssR0FBRztBQUNuRHhDLHVCQUFpQixFQUFFO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTTJDLFlBQVlBLENBQUNDLGVBQWU7QUFDaEMsVUFBTSxDQUFDOUQsTUFBTUMsS0FBSyxJQUFJNkQsV0FBVzFILE1BQU0sR0FBRztBQUMxQyxXQUFPO0FBQUEsTUFDTDREO0FBQUFBLE1BQ0FDLE9BQU9OLE9BQU9vRSxTQUFTOUQsS0FBSyxDQUFDLEVBQUVKLFNBQVMsR0FBRyxHQUFHO0FBQUEsTUFDOUNtRSxXQUFXM0MsV0FBVzBDLFNBQVM5RCxLQUFLLElBQUksQ0FBQztBQUFBLElBQzNDO0FBQUEsRUFDRjtBQUVBLFFBQU1nRSxvQkFBb0JBLENBQUNqRSxNQUFNQyxVQUFVO0FBQ3pDLFdBQU8sR0FBR0QsSUFBSSxJQUFJTCxPQUFPTSxLQUFLLEVBQUVKLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFBQSxFQUNsRDtBQUVBLFFBQU1xRSxvQkFBb0JBLENBQUNKLGVBQWU7QUFDeEMsVUFBTSxFQUFFOUQsTUFBTUMsTUFBTSxJQUFJNEQsVUFBVUMsVUFBVTtBQUM1QyxVQUFNSyxZQUFZLElBQUlqSSxLQUFLOEQsTUFBTStELFNBQVM5RCxLQUFLLElBQUksR0FBRyxDQUFDO0FBQ3ZELFVBQU1tRSxVQUFVLElBQUlsSSxLQUFLOEQsTUFBTStELFNBQVM5RCxLQUFLLEdBQUcsQ0FBQztBQUVqRCxXQUFPO0FBQUEsTUFDTG9FLFdBQVd0RSxXQUFXb0UsU0FBUztBQUFBLE1BQy9CRyxTQUFTdkUsV0FBV3FFLE9BQU87QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFDQSxRQUFNRywwQkFBMEIsT0FBT0MsWUFBWTtBQUNqRCxRQUFJO0FBQ0YsWUFBTXRCLFdBQVcsTUFBTW5MLElBQUlvTCxJQUFJLDRCQUE0QnFCLE9BQU8sRUFBRTtBQUNwRXhKLHNCQUFnQmtJLFNBQVNFLElBQUk7QUFDN0I5RCwyQkFBcUIsSUFBSTtBQUFBLElBQzNCLFNBQVMrRCxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sbUNBQW1DO0FBQUEsSUFDbkQ7QUFBQSxFQUNGO0FBRUEsUUFBTW9CLGNBQWMsT0FBT0MsYUFBYTtBQUN0QyxRQUFJO0FBQ0YsWUFBTXhCLFdBQVcsTUFBTW5MLElBQUlvTCxJQUFJLHVDQUF1Q3VCLFFBQVEsRUFBRTtBQUNoRixZQUFNQyxhQUFhekIsU0FBU0UsTUFBTUEsTUFBTXVCO0FBRXhDLFlBQU1DLGNBQWNDLE9BQU9DLEtBQUssSUFBSSxVQUFVLHNCQUFzQjtBQUNwRSxVQUFJLENBQUNGLGFBQWE7QUFDaEJoTSxnQkFBUXlLLE1BQU0sdURBQXVEO0FBQ3JFO0FBQUEsTUFDRjtBQUVBdUIsa0JBQVlHLFNBQVNDO0FBQUFBLFFBQ25CO0FBQUE7QUFBQTtBQUFBLDRDQUdvQ0wsWUFBWU0sZUFBZSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTTdFO0FBQ0FMLGtCQUFZRyxTQUFTRyxNQUFNO0FBQzNCTixrQkFBWU8sTUFBTTtBQUVsQixZQUFNQyxPQUFPL0wsU0FBU2dNO0FBQUFBLFFBQ3BCVCxZQUFZRyxTQUFTTyxlQUFlLHVCQUF1QjtBQUFBLE1BQzdEO0FBQ0FGLFdBQUtHLE9BQU8sdUJBQUMsNEJBQXlCLGNBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQsQ0FBRztBQUVoRUMsaUJBQVcsTUFBTTtBQUNmWixvQkFBWU8sTUFBTTtBQUNsQlAsb0JBQVlhLE1BQU07QUFBQSxNQUNwQixHQUFHLEdBQUc7QUFBQSxJQUNSLFNBQVNwQyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sOEJBQThCQSxLQUFLO0FBQ2pEekssY0FBUXlLLE1BQU0saURBQWlEO0FBQUEsSUFDakU7QUFBQSxFQUNGO0FBRUEsUUFBTXFDLDJCQUEyQixPQUFPckQsTUFBTTtBQUM1Q0EsTUFBRXNELGVBQWU7QUFDakIsUUFBSTVLLGNBQWM7QUFDaEIsWUFBTTZDLFVBQVU3QyxhQUFhNkMsU0FBU21GO0FBQ3RDLFVBQUk7QUFDRixjQUFNaEwsSUFBSTZOLElBQUksOEJBQThCN0ssY0FBY2dJLEdBQUcsSUFBSTtBQUFBLFVBQy9EbkY7QUFBQUEsVUFDQWlJLGlCQUFpQjtBQUFBLFFBQ25CLENBQUM7QUFDRHZHLDZCQUFxQixFQUFFO0FBQ3ZCdEUsd0JBQWdCLElBQUk7QUFDcEJnQyx1QkFBZTtBQUFBLFVBQ2JDLFlBQVk7QUFBQSxVQUNackUsU0FBUztBQUFBLFVBQ1RzRSxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQUEsTUFFSCxTQUFTbUcsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFBQSxNQUM5QztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBR0F6TCxZQUFVLE1BQU07QUFDZCxtQkFBZWtPLHlCQUF5QjtBQUN0Q3BLLHNCQUFnQixJQUFJO0FBQ3BCLFVBQUlxSyxNQUFNLDhDQUE4QzlKLElBQUksWUFBWUEsSUFBSTtBQUM1RSxVQUFJO0FBQ0ZuQyx3QkFBZ0IsRUFBRTtBQUNsQndCLDhCQUFzQixJQUFJO0FBQzFCLGNBQU00SCxXQUFXLE1BQU1uTCxJQUFJb0wsSUFBSTRDLEdBQUc7QUFDbEMsWUFBSTdDLFNBQVNFLFFBQVFGLFNBQVNFLEtBQUs0QyxTQUFTLEdBQUc7QUFDN0NoTSwyQkFBaUJrSixTQUFTRSxJQUFJO0FBQzlCLGdCQUFNNkMsZ0JBQWdCL0MsU0FBU0UsS0FBSzhDLElBQUksQ0FBQ0MsT0FBT0MsVUFBVTtBQUN4RCxnQkFBSSxDQUFDRCxPQUFPeEksWUFBWSxDQUFDd0ksT0FBT3ZJLFFBQVMsUUFBTyxDQUFDO0FBQ2pELG1CQUFPO0FBQUEsY0FDTG1GLEtBQUtvRCxPQUFPcEQ7QUFBQUEsY0FDWnNELElBQUlELFFBQVE7QUFBQSxjQUNaRSxNQUFNSCxPQUFPdkksU0FBUzJJO0FBQUFBLGNBQ3RCQyxjQUFjTCxPQUFPdkksU0FBUzRJO0FBQUFBLGNBQzlCQyxZQUFZTixPQUFPeEksVUFBVThJO0FBQUFBLGNBQzdCQyxlQUFlUCxPQUFPTztBQUFBQSxjQUN0QjNJLGNBQWNvSSxPQUFPcEk7QUFBQUEsY0FDckI0SSxpQkFBaUJSLE9BQU9TLFlBQ3BCVCxPQUFPUyxXQUFXeEssTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUM5QjtBQUFBLGNBQ0pnQyxtQkFBbUIrSCxPQUFPL0g7QUFBQUEsY0FDMUJOLGVBQWVxSSxPQUFPckk7QUFBQUEsY0FDdEJRLGlCQUFpQjZILE9BQU9VO0FBQUFBLGNBQ3hCQyxhQUNFWCxPQUFPbEksT0FBT3FJLFFBQVFILE9BQU9sSSxPQUFPdUksZUFDaEMsR0FBR0wsTUFBTWxJLE1BQU1xSSxJQUFJLE1BQU1ILE1BQU1sSSxNQUFNdUksWUFBWSxLQUNqREwsT0FBT25JLG1CQUFtQnVJLGFBQzFCSixPQUFPbkksbUJBQW1Cd0ksZUFDeEIsR0FBR0wsTUFBTW5JLGtCQUFrQnVJLFNBQVMsTUFBTUosT0FBT25JLG1CQUFtQndJLFlBQVksS0FDaEZMLE9BQU9qSSxlQUFlNkksYUFDdEJaLE9BQU9qSSxlQUFlOEksZUFDcEIsR0FBR2IsTUFBTWpJLGNBQWM2SSxTQUFTLE1BQU1aLE1BQU1qSSxjQUFjOEksWUFBWSxLQUN0RTtBQUFBLGNBQ1ZDLFFBQVFkLE1BQU14SDtBQUFBQSxjQUNkdUksUUFDRSx1QkFBQyxTQUFJLFdBQVUsMENBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBTTtBQUFBLG9CQUNKQyxPQUFPO0FBQUEsc0JBQ0w7QUFBQSx3QkFDRUMsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLE1BQU1DLHNCQUFzQm5CLE1BQU1wRCxHQUFHO0FBQUEsNEJBQUU7QUFBQTtBQUFBLDBCQUZsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBS0E7QUFBQSxzQkFFSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBdUNBO0FBQUEsd0JBQ0VxRSxLQUFLO0FBQUEsd0JBQ0xDLE9BQ0U7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsV0FBVTtBQUFBLDRCQUNWLFNBQVMsTUFBTUUsc0JBQXNCcEIsTUFBTXBELEdBQUc7QUFBQSw0QkFBRTtBQUFBO0FBQUEsMEJBRmxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQUEsc0JBQ0FvRCxPQUFPTixvQkFBb0IsV0FDdkI7QUFBQSx3QkFDQXVCLEtBQUs7QUFBQSx3QkFDTEMsT0FDRSx1QkFBQyxXQUFRLE9BQU0sOENBQ2I7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsT0FBTTtBQUFBLDRCQUNOLGFBQVk7QUFBQSw0QkFDWixRQUFPO0FBQUEsNEJBQ1AsWUFBVztBQUFBLDRCQUNYLFdBQVcsTUFBTUcsc0JBQXNCckIsTUFBTXBELEdBQUc7QUFBQSw0QkFFaEQsaUNBQUMsU0FBSSxXQUFVLGtDQUFpQyx1QkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBO0FBQUEsMEJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFZQTtBQUFBLHNCQUVKLElBQ0VvRCxPQUFPTixvQkFBb0IsWUFDekI7QUFBQSx3QkFDQXVCLEtBQUs7QUFBQSx3QkFDTEMsT0FDRSx1QkFBQyxXQUFRLE9BQU0sMENBQ2I7QUFBQSwwQkFBQztBQUFBO0FBQUEsNEJBQ0MsT0FBTTtBQUFBLDRCQUNOLGFBQVk7QUFBQSw0QkFDWixRQUFPO0FBQUEsNEJBQ1AsWUFBVztBQUFBLDRCQUNYLFdBQVcsTUFBTTlDLHdCQUF3QjRCLE1BQU1wRCxHQUFHO0FBQUEsNEJBRWxELGlDQUFDLFNBQUksV0FBVSxpQ0FBZ0Msd0JBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQTtBQUFBLDBCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBWUE7QUFBQSxzQkFFSixJQUNFO0FBQUEsc0JBQ047QUFBQSx3QkFDRXFFLEtBQUs7QUFBQSx3QkFDTEMsT0FDRTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFVO0FBQUEsNEJBQ1YsU0FBUyxNQUFNNUMsWUFBWTBCLE1BQU1wRCxHQUFHO0FBQUEsNEJBQUU7QUFBQTtBQUFBLDBCQUZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBS0E7QUFBQSxzQkFFSjtBQUFBLG9CQUFDLEVBQ0QwRSxPQUFPQyxPQUFPO0FBQUEsa0JBRWxCO0FBQUEsa0JBRUEsaUNBQUMsWUFBUyxXQUFVLDhCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4QztBQUFBO0FBQUEsZ0JBckhoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FzSEEsS0F2SEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF3SEE7QUFBQSxZQUVKO0FBQUEsVUFDRixDQUFDO0FBQ0Q1TiwwQkFBZ0JtTSxhQUFhO0FBQUEsUUFDL0IsT0FBTztBQUNMak0sMkJBQWlCLEVBQUU7QUFBQSxRQUNyQjtBQUFBLE1BQ0YsU0FBU3FKLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sbUNBQW1DQSxLQUFLO0FBQ3REckoseUJBQWlCLEVBQUU7QUFDbkJGLHdCQUFnQixFQUFFO0FBQUEsTUFDcEIsVUFBQztBQUNDd0IsOEJBQXNCLEtBQUs7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFDQXdLLDJCQUF1QjtBQUFBLEVBQ3pCLEdBQUcsQ0FBQ3ZGLGFBQWEsQ0FBQztBQUVsQjNJLFlBQVUsTUFBTTtBQUNkLFVBQU0rUCxhQUFhLFlBQVk7QUFDN0IsVUFBSTtBQUNGLGNBQU16RSxXQUFXLE1BQU1uTCxJQUFJb0wsSUFBSSxnQkFBZ0I7QUFDL0N2SixpQkFBU3NKLFNBQVNFLElBQUk7QUFBQSxNQUN4QixTQUFTQyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLDZCQUE2QkEsS0FBSztBQUFBLE1BQ2xEO0FBQUEsSUFDRjtBQUNBc0UsZUFBVztBQUFBLEVBQ2IsR0FBRyxFQUFFO0FBQ0wvUCxZQUFVLE1BQU07QUFDZCxVQUFNZ1EsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNMUUsV0FBVyxNQUFNbkwsSUFBSW9MLElBQUksWUFBWTtBQUMzQ3JILGtCQUFVb0gsU0FBU0UsTUFBTW5GLEtBQUs7QUFBQSxNQUNoQyxTQUFTeUYsS0FBSztBQUNaSixnQkFBUUQsTUFBTSx5QkFBeUJLLEdBQUc7QUFBQSxNQUM1QztBQUFBLElBQ0Y7QUFDQWtFLGdCQUFZO0FBQUEsRUFDZCxHQUFHLEVBQUU7QUFDTGhRLFlBQVUsTUFBTTtBQUNkLFVBQU1pUSxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YsY0FBTTNFLFdBQVcsTUFBTW5MLElBQUlvTCxJQUFJLFdBQVc7QUFDMUM3RyxxQkFBYTRHLFVBQVVFLE1BQU0wRSxRQUFRO0FBQUEsTUFFdkMsU0FBU3pFLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQUEsTUFDbEQ7QUFBQSxJQUNGO0FBQ0F3RSxtQkFBZTtBQUFBLEVBQ2pCLEdBQUcsRUFBRTtBQUNMalEsWUFBVSxNQUFNO0FBQ2QsVUFBTW1RLGFBQWEsWUFBWTtBQUM3QixVQUFJO0FBQ0YsY0FBTTdFLFdBQVcsTUFBTW5MLElBQUlvTCxJQUFJLGdCQUFnQjtBQUMvQ3ZILGlCQUFTc0gsU0FBU0UsSUFBSTtBQUFBLE1BQ3hCLFNBQVNNLEtBQUs7QUFDWkosZ0JBQVFELE1BQU0seUJBQXlCSyxHQUFHO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQ0FxRSxlQUFXO0FBQUEsRUFDYixHQUFHLEVBQUU7QUFFTG5RLFlBQVUsTUFBTTtBQUNkLFVBQU00SyxPQUFPQyxhQUFhQyxRQUFRLE1BQU07QUFDeEMsVUFBTUMsVUFBVUMsS0FBS0MsTUFBTUwsSUFBSTtBQUUvQixRQUFJRyxTQUFTO0FBQ1gsWUFBTXFGLHlCQUNKckYsUUFBUXNGLHVCQUF1QkM7QUFFakMsVUFBSUYsd0JBQXdCRyxpQkFBaUIsUUFBUTtBQUNuRHpILHlCQUFpQixJQUFJO0FBQUEsTUFDdkI7QUFFQSxVQUFJc0gsd0JBQXdCSSx5QkFBeUIsUUFBUTtBQUMzRDFILHlCQUFpQixJQUFJO0FBQ3JCRSxtQ0FBMkIsSUFBSTtBQUFBLE1BQ2pDO0FBQUEsSUFDRjtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTXlILG1CQUFtQixPQUFPQyxPQUFPaEcsVUFBVTtBQUMvQzVFLGdCQUFZLENBQUM2SyxjQUFjO0FBQUEsTUFDekIsR0FBR0E7QUFBQUEsTUFDSCxDQUFDRCxLQUFLLEdBQUdoRztBQUFBQSxJQUNYLEVBQUU7QUFFRjlHLGNBQVUsQ0FBQ2dOLGdCQUFnQjtBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ0YsS0FBSyxHQUFHO0FBQUEsSUFDWCxFQUFFO0FBQ0YsUUFBSUEsVUFBVSxZQUFZO0FBQ3hCLFVBQUk7QUFDRixjQUFNcEYsV0FBVyxNQUFNbkwsSUFBSTBRLEtBQUssNEJBQTRCbkcsS0FBSyxFQUFFO0FBQ25FcEgsK0JBQXVCZ0ksU0FBU0UsS0FBSzNJLG9CQUFvQixFQUFFO0FBQUEsTUFDN0QsU0FBUzRJLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sZ0NBQWdDQSxLQUFLO0FBQUEsTUFDckQ7QUFBQSxJQUNGO0FBQ0EsUUFBSWlGLFVBQVUsV0FBVztBQUN2QmxILGdDQUEwQixJQUFJO0FBRTlCTiw2QkFBdUIsRUFBRTtBQUN6QkUsdUJBQWlCLEVBQUU7QUFDbkJFLHVCQUFpQixFQUFFO0FBR25CLFlBQU13SCxRQUFRQztBQUFBQSxRQUFJO0FBQUEsVUFDaEJwRix5QkFBeUJqQixLQUFLO0FBQUEsVUFDOUJxQixtQkFBbUJyQixLQUFLO0FBQUEsVUFDeEJzQixtQkFBbUJ0QixLQUFLO0FBQUEsUUFBQztBQUFBLE1BQzFCO0FBQ0RsQixnQ0FBMEIsS0FBSztBQUMvQixZQUFNd0gsZUFBZWpQLE1BQU1rUCxLQUFLLENBQUNyRyxTQUFTQSxLQUFLTyxRQUFRVCxLQUFLO0FBQzVELFVBQUlzRyxjQUFjO0FBQ2hCLGNBQU1FLFVBQVVGLGFBQWFHLGlCQUFpQjtBQUU5Q3JMLG9CQUFZLENBQUNzRixVQUFVO0FBQUEsVUFDckIsR0FBR0E7QUFBQUEsVUFDSGxGLGVBQWVnTDtBQUFBQTtBQUFBQSxVQUVmRSxtQkFBbUI7QUFBQSxVQUNuQi9LLE9BQU87QUFBQSxVQUNQRCxtQkFBbUI7QUFBQSxRQUNyQixFQUFFO0FBR0YsWUFBSThLLFlBQVksY0FBY0YsYUFBYUksbUJBQW1CakcsS0FBSztBQUNqRXJGLHNCQUFZLENBQUNzRixVQUFVO0FBQUEsWUFDckIsR0FBR0E7QUFBQUEsWUFDSC9FLE9BQU8ySyxhQUFhSSxrQkFBa0JqRztBQUFBQSxVQUN4QyxFQUFFO0FBQUEsUUFDSixXQUFXK0YsWUFBWSxXQUFXRixhQUFhSyxnQkFBZ0JsRyxLQUFLO0FBQ2xFckYsc0JBQVksQ0FBQ3NGLFVBQVU7QUFBQSxZQUNyQixHQUFHQTtBQUFBQSxZQUNIaUcsZ0JBQWdCTCxhQUFhSyxlQUFlbEc7QUFBQUEsVUFDOUMsRUFBRTtBQUFBLFFBQ0osV0FBVytGLFlBQVksY0FBY0YsYUFBYTVLLG1CQUFtQitFLEtBQUs7QUFDeEVyRixzQkFBWSxDQUFDc0YsVUFBVTtBQUFBLFlBQ3JCLEdBQUdBO0FBQUFBLFlBQ0hoRixtQkFBbUI0SyxhQUFhNUssa0JBQWtCK0U7QUFBQUEsVUFDcEQsRUFBRTtBQUFBLFFBQ0o7QUFBQSxNQUVGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDQSxXQUFTbUcsZ0JBQWdCQyxlQUFlO0FBQ3RDLFVBQU1DLFFBQVFELGNBQWNOLEtBQUssQ0FBQ1EsWUFBWUEsUUFBUWpHLElBQUk7QUFDMUQsV0FBT2dHLFFBQVFBLE1BQU05RyxRQUFRO0FBQUEsRUFDL0I7QUFtQ0EsUUFBTWdILHdCQUF3QkEsQ0FBQ2hCLE9BQU9oRyxVQUFVO0FBQzlDLFFBQUlnRyxVQUFVLGlCQUFpQjtBQUM3QjVKLHdCQUFrQixDQUFDNkosY0FBYztBQUFBLFFBQy9CLEdBQUdBO0FBQUFBLFFBQ0h6SyxlQUFld0U7QUFBQUE7QUFBQUEsUUFDZjFELGtCQUFrQjtBQUFBLFFBQ2xCWixtQkFBbUI7QUFBQSxRQUNuQkUsZUFBZTtBQUFBLFFBQ2ZELE9BQU87QUFBQSxRQUNQWSx1QkFBdUJxSztBQUFBQSxVQUFnQjtBQUFBLFlBQ3JDLEVBQUU5RixNQUFNbUYsVUFBVXZLLG1CQUFtQnNFLE9BQU8sV0FBVztBQUFBLFlBQ3ZELEVBQUVjLE1BQU1tRixVQUFVckssZUFBZW9FLE9BQU8sT0FBTztBQUFBLFlBQy9DLEVBQUVjLE1BQU1tRixVQUFVdEssT0FBT3FFLE9BQU8sUUFBUTtBQUFBLFVBQUM7QUFBQSxRQUMxQztBQUFBLFFBQ0R4RCwyQkFBMkJ5SixVQUFVdkssbUJBQW1CK0U7QUFBQUEsUUFDeERoRSx1QkFBdUJ3SixVQUFVckssZUFBZTZFO0FBQUFBLFFBQ2hEL0Qsd0JBQXdCdUosVUFBVXRLLE9BQU84RTtBQUFBQSxNQUMzQyxFQUFFO0FBQ0Y7QUFBQSxJQUNGO0FBR0FyRSxzQkFBa0IsQ0FBQzZKLGNBQWM7QUFBQSxNQUMvQixHQUFHQTtBQUFBQSxNQUNIMUosdUJBQXVCO0FBQUEsTUFDdkJDLDJCQUEyQjtBQUFBLE1BQzNCQyx1QkFBdUI7QUFBQSxNQUN2QkMsd0JBQXdCO0FBQUEsTUFDeEIsQ0FBQ3NKLEtBQUssR0FBR2hHO0FBQUFBLElBQ1gsRUFBRTtBQUVGOUcsY0FBVSxFQUFFLEdBQUdELFFBQVEsQ0FBQytNLEtBQUssR0FBRyxHQUFHLENBQUM7QUFBQSxFQUN0QztBQUVBLFFBQU1pQixxQkFBcUIsT0FBTzdFLGFBQWE7QUFDN0MsUUFBSTtBQUNGLFlBQU0zTSxJQUFJeVIsTUFBTSxtQ0FBbUM5RSxRQUFRLEVBQUU7QUFFN0Q5TCxjQUFRNlEsUUFBUSw4QkFBOEI7QUFHOUNqUCw0QkFBc0IsQ0FBQ3dJLFVBQVU7QUFBQSxRQUMvQixHQUFHQTtBQUFBQSxRQUNIMEQsZUFBZTtBQUFBLE1BQ2pCLEVBQUU7QUFBQSxJQUtKLFNBQVNyRCxPQUFPO0FBQ2RDLGNBQVFELE1BQU1BLEtBQUs7QUFDbkJ6SyxjQUFReUssTUFBTSx5QkFBeUI7QUFBQSxJQUN6QztBQUFBLEVBQ0Y7QUFFQSxRQUFNcUcsbUJBQW1CLE9BQU9oRixhQUFhO0FBQzNDLFFBQUk7QUFDRixZQUFNM00sSUFBSXlSLE1BQU0saUNBQWlDOUUsUUFBUSxFQUFFO0FBRTNEOUwsY0FBUTZRLFFBQVEsNEJBQTRCO0FBRzVDalAsNEJBQXNCLENBQUN3SSxVQUFVO0FBQUEsUUFDL0IsR0FBR0E7QUFBQUEsUUFDSDBELGVBQWU7QUFBQSxNQUNqQixFQUFFO0FBQUEsSUFLSixTQUFTckQsT0FBTztBQUNkQyxjQUFRRCxNQUFNQSxLQUFLO0FBQ25CekssY0FBUXlLLE1BQU0sdUJBQXVCO0FBQUEsSUFDdkM7QUFBQSxFQUNGO0FBRUEsUUFBTXNHLG9CQUFvQixPQUFPbkYsWUFBWTtBQUMzQ3RLLHFCQUFpQnNLLE9BQU87QUFFeEIsUUFBSUEsU0FBUztBQUNYLFVBQUl1QjtBQUNKLFVBQUl2QixZQUFZLFVBQVU7QUFDeEJ1QixjQUFNO0FBQ05ySyx3QkFBZ0IsSUFBSTtBQUFBLE1BQ3RCLFdBQVc4SSxZQUFZLFNBQVM7QUFDOUJ1QixjQUFNLDhDQUE4QzlKLElBQUksWUFBWUEsSUFBSTtBQUN4RVAsd0JBQWdCLElBQUk7QUFBQSxNQUN0QixPQUFPO0FBQ0xxSyxjQUFNLDRCQUE0QnZCLE9BQU87QUFDekM5SSx3QkFBZ0IsS0FBSztBQUFBLE1BQ3ZCO0FBQ0EsVUFBSTtBQUNGNUIsd0JBQWdCLEVBQUU7QUFDbEJ3Qiw4QkFBc0IsSUFBSTtBQUMxQixjQUFNNEgsV0FBVyxNQUFNbkwsSUFBSW9MLElBQUk0QyxHQUFHO0FBQ2xDekMsZ0JBQVFzRyxLQUFLMUcsVUFBVSxZQUFZO0FBQ25DLFlBQUlBLFNBQVNFLFFBQVFGLFNBQVNFLEtBQUs0QyxTQUFTLEdBQUc7QUFDN0NoTSwyQkFBaUJrSixTQUFTRSxJQUFJO0FBQzlCLGdCQUFNNkMsZ0JBQWdCL0MsU0FBU0UsS0FBSzhDLElBQUksQ0FBQ0MsT0FBT0MsVUFBVTtBQUN4RCxnQkFBSSxDQUFDRCxPQUFPeEksWUFBWSxDQUFDd0ksT0FBT3ZJLFFBQVMsUUFBTyxDQUFDO0FBQ2pELG1CQUFPO0FBQUEsY0FDTG1GLEtBQUtvRCxPQUFPcEQ7QUFBQUEsY0FDWnNELElBQUlELFFBQVE7QUFBQSxjQUNabkIsYUFBYWtCLE9BQU9sQjtBQUFBQSxjQUNwQnFCLE1BQU1ILE9BQU92SSxTQUFTMkk7QUFBQUEsY0FDdEJDLGNBQWNMLE9BQU92SSxTQUFTNEk7QUFBQUEsY0FDOUJDLFlBQVlOLE9BQU94SSxVQUFVOEk7QUFBQUEsY0FDN0JDLGVBQWVQLE9BQU9PLGdCQUFnQixRQUFRO0FBQUEsY0FDOUMzSSxjQUFjb0ksT0FBT3BJO0FBQUFBLGNBQ3JCNEksaUJBQWlCUixPQUFPUyxVQUFVeEssTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLGNBQzlDZ0MsbUJBQW1CK0gsT0FBTy9IO0FBQUFBLGNBQzFCTixlQUFlcUksT0FBT3JJO0FBQUFBLGNBQ3RCUSxpQkFBaUI2SCxPQUFPVTtBQUFBQSxjQUN4QkMsYUFDRVgsT0FBT2xJLE9BQU9xSSxRQUFRSCxPQUFPbEksT0FBT3VJLGVBQ2hDLEdBQUdMLE1BQU1sSSxNQUFNcUksSUFBSSxNQUFNSCxNQUFNbEksTUFBTXVJLFlBQVksS0FDakRMLE9BQU9uSSxtQkFBbUJ1SSxhQUMxQkosT0FBT25JLG1CQUFtQndJLGVBQ3hCLEdBQUdMLE1BQU1uSSxrQkFBa0J1SSxTQUFTLE1BQU1KLE9BQU9uSSxtQkFBbUJ3SSxZQUFZLEtBQ2hGTCxPQUFPakksZUFBZTZJLGFBQ3RCWixPQUFPakksZUFBZThJLGVBQ3BCLEdBQUdiLE1BQU1qSSxjQUFjNkksU0FBUyxNQUFNWixNQUFNakksY0FBYzhJLFlBQVksS0FDdEU7QUFBQSxjQUNWQyxRQUFRZCxNQUFNeEg7QUFBQUEsY0FDZHVJLFFBQ0UsdUJBQUMsU0FBSSxXQUFVLDBDQUNiO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQU07QUFBQSxvQkFDSkMsT0FBTztBQUFBLHNCQUNMO0FBQUEsd0JBQ0VDLEtBQUs7QUFBQSx3QkFDTEMsT0FDRTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFVO0FBQUEsNEJBQ1YsU0FBUyxNQUFNQyxzQkFBc0JuQixNQUFNcEQsR0FBRztBQUFBLDRCQUFFO0FBQUE7QUFBQSwwQkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsc0JBRUo7QUFBQSxzQkFDQTtBQUFBLHdCQUNFcUUsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLE1BQU01QyxZQUFZMEIsTUFBTXBELEdBQUc7QUFBQSw0QkFBRTtBQUFBO0FBQUEsMEJBRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFLQTtBQUFBLHNCQUVKO0FBQUEsc0JBQ0E7QUFBQSx3QkFDRXFFLEtBQUs7QUFBQSx3QkFDTEMsT0FDRTtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxXQUFVO0FBQUEsNEJBQ1YsU0FBUyxNQUFNRSxzQkFBc0JwQixNQUFNcEQsR0FBRztBQUFBLDRCQUFFO0FBQUE7QUFBQSwwQkFGbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUtBO0FBQUEsc0JBRUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQXNDQW9ELE9BQU9OLG9CQUFvQixXQUN2QjtBQUFBLHdCQUNBdUIsS0FBSztBQUFBLHdCQUNMQyxPQUNFLHVCQUFDLFdBQVEsT0FBTSw4Q0FDYjtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxPQUFNO0FBQUEsNEJBQ04sYUFBWTtBQUFBLDRCQUNaLFFBQU87QUFBQSw0QkFDUCxZQUFXO0FBQUEsNEJBQ1gsV0FBVyxNQUFNRyxzQkFBc0JyQixNQUFNcEQsR0FBRztBQUFBLDRCQUVoRCxpQ0FBQyxTQUFJLFdBQVUsa0NBQWlDLHVCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUE7QUFBQSwwQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVlBO0FBQUEsc0JBRUosSUFDRW9ELE9BQU9OLG9CQUFvQixZQUN6QjtBQUFBLHdCQUNBdUIsS0FBSztBQUFBLHdCQUNMQyxPQUNFLHVCQUFDLFdBQVEsT0FBTSwwQ0FDYjtBQUFBLDBCQUFDO0FBQUE7QUFBQSw0QkFDQyxPQUFNO0FBQUEsNEJBQ04sYUFBWTtBQUFBLDRCQUNaLFFBQU87QUFBQSw0QkFDUCxZQUFXO0FBQUEsNEJBQ1gsV0FBVyxNQUFNOUMsd0JBQXdCNEIsTUFBTXBELEdBQUc7QUFBQSw0QkFFbEQsaUNBQUMsU0FBSSxXQUFVLGlDQUFnQyx3QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBO0FBQUEsMEJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFZQTtBQUFBLHNCQUVKLElBQ0U7QUFBQSxvQkFBSSxFQUNWMEUsT0FBT0MsT0FBTztBQUFBLGtCQUNsQjtBQUFBLGtCQUVBLGlDQUFDLFlBQVMsV0FBVSw4QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEM7QUFBQTtBQUFBLGdCQW5IaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBb0hBLEtBckhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0hBO0FBQUEsWUFFSjtBQUFBLFVBQ0YsQ0FBQztBQUNENU4sMEJBQWdCbU0sYUFBYTtBQUFBLFFBQy9CLE9BQU87QUFDTGpNLDJCQUFpQixFQUFFO0FBQUEsUUFDckI7QUFBQSxNQUNGLFNBQVNxSixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RHJKLHlCQUFpQixFQUFFO0FBQ25CRix3QkFBZ0IsRUFBRTtBQUFBLE1BQ3BCLFVBQUM7QUFDQ3dCLDhCQUFzQixLQUFLO0FBQUEsTUFDN0I7QUFBQSxJQUNGLE9BQU87QUFDTHRCLHVCQUFpQixFQUFFO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBRUEsUUFBTTZQLFVBQVU7QUFBQSxJQUNkLEVBQUV6QyxLQUFLLE1BQU0wQyxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFMUMsS0FBSyxRQUFRMEMsUUFBUSxnQkFBZ0I7QUFBQSxJQUN2QyxFQUFFMUMsS0FBSyxnQkFBZ0IwQyxRQUFRLHdCQUF3QjtBQUFBLEVBQUM7QUFFMUQsTUFBSXJPLGNBQWM7QUFDaEJvTyxZQUFRRSxLQUFLLEVBQUUzQyxLQUFLLGNBQWMwQyxRQUFRLGlCQUFpQixDQUFDO0FBQUEsRUFDOUQ7QUFDQUQsVUFBUUU7QUFBQUEsSUFDTixFQUFFM0MsS0FBSyxlQUFlMEMsUUFBUSxlQUFlRSxPQUFPLElBQUk7QUFBQSxJQUN4RCxFQUFFNUMsS0FBSyxpQkFBaUIwQyxRQUFRLGdCQUFnQjtBQUFBLElBQ2hELEVBQUUxQyxLQUFLLFVBQVUwQyxRQUFRLGdCQUFnQjtBQUFBO0FBQUEsSUFFekMsRUFBRTFDLEtBQUssZ0JBQWdCMEMsUUFBUSxlQUFlO0FBQUEsSUFDOUMsRUFBRTFDLEtBQUssbUJBQW1CMEMsUUFBUSxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFMUMsS0FBSyxxQkFBcUIwQyxRQUFRLG9CQUFvQjtBQUFBLElBQ3hELEVBQUUxQyxLQUFLLGlCQUFpQjBDLFFBQVEsZ0JBQWdCO0FBQUEsSUFDaEQsRUFBRTFDLEtBQUssZUFBZTBDLFFBQVEsY0FBYztBQUFBLElBQzVDLEVBQUUxQyxLQUFLLFVBQVUwQyxRQUFRLFNBQVM7QUFBQSxFQUNwQztBQUVBLFFBQU1HLGVBQWUsT0FBTzVILE1BQU07QUFDaEMsVUFBTSxFQUFFaUUsTUFBTWhFLE1BQU0sSUFBSUQsRUFBRUU7QUFFMUI3RSxnQkFBWSxDQUFDNkssY0FBYztBQUFBLE1BQ3pCLEdBQUdBO0FBQUFBLE1BQ0gsQ0FBQ2pDLElBQUksR0FBR2hFO0FBQUFBLElBQ1YsRUFBRTtBQUNGOUcsY0FBVSxDQUFDZ04sZ0JBQWdCLEVBQUUsR0FBR0EsWUFBWSxDQUFDbEMsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUV6RCxRQUFJQSxTQUFTLFlBQVk7QUFDdkIsVUFBSTtBQUNGLGNBQU1wRCxXQUFXLE1BQU1uTCxJQUFJMFEsS0FBSyw0QkFBNEJuRyxLQUFLLEVBQUU7QUFDbkVwSCwrQkFBdUJnSSxTQUFTRSxLQUFLM0ksb0JBQW9CLEVBQUU7QUFBQSxNQUM3RCxTQUFTNEksT0FBTztBQUNkQyxnQkFBUUQsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFBQSxNQUNyRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsUUFBTTZHLFdBQVdBLENBQUNoTixTQUFTO0FBQ3pCLFVBQU1pTixZQUFZLENBQUM7QUFDbkIsVUFBTS9HLE9BQU9sRyxTQUFTLGtCQUFrQk8sV0FBV2dCO0FBQ25ELFVBQU0yTCxjQUFjbE4sU0FBUyxrQkFBa0Isa0JBQWtCO0FBQ2pFLFVBQU1tTixRQUFRLEVBQUVsTSxVQUFVLDZCQUE2QjtBQUN2RCxRQUFJLENBQUNpRixLQUFLekYsU0FBUzJNLEtBQUssR0FBRztBQUN6QkgsZ0JBQVV4TSxXQUFXO0FBQUEsSUFDdkI7QUFDQSxRQUFJLENBQUN5RixLQUFLeEYsU0FBUztBQUNqQnVNLGdCQUFVdk0sVUFBVTtBQUFBLElBQ3RCO0FBQ0EsUUFBSXdGLEtBQUtqRixZQUFZLENBQUNrTSxNQUFNbE0sU0FBU29NLEtBQUtuSCxLQUFLakYsUUFBUSxHQUFHO0FBQ3hEZ00sZ0JBQVVoTSxXQUFXO0FBQUEsSUFDdkI7QUFFQSxRQUFJbEQsb0JBQW9CK0ssU0FBUyxHQUFHO0FBQ2xDLFVBQ0UsQ0FBQzVDLEtBQUtnSCxXQUFXLEtBQ2pCaEgsS0FBS2dILFdBQVcsS0FBSyxLQUNyQkksTUFBTXBILEtBQUtnSCxXQUFXLENBQUMsR0FDdkI7QUFDQUQsa0JBQVVDLFdBQVcsSUFBSTtBQUFBLE1BQzNCLFdBQVdoSCxLQUFLZ0gsV0FBVyxJQUFJblAsb0JBQW9CK0ssUUFBUTtBQUN6RG1FLGtCQUNFQyxXQUFXLElBQ1QsV0FBV25QLG9CQUFvQitLLE1BQU07QUFBQSxNQUMzQztBQUFBLElBQ0Y7QUFFQXhLLGNBQVUyTyxTQUFTO0FBQ25CLFdBQU9NLE9BQU9DLEtBQUtQLFNBQVMsRUFBRW5FLFdBQVc7QUFBQSxFQUMzQztBQUVBLFFBQU0yRSxlQUFlLE9BQU90SSxNQUFNO0FBQ2hDQSxNQUFFc0QsZUFBZTtBQUNqQixVQUFNaUYsVUFBVVYsU0FBUyxlQUFlO0FBQ3hDLFFBQUlVLFNBQVM7QUFDWHhQLGlCQUFXLElBQUk7QUFDZixZQUFNO0FBQUEsUUFDSnlDO0FBQUFBLFFBQ0FGO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FHO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FGO0FBQUFBLFFBQ0FRO0FBQUFBLFFBQ0FMO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FFO0FBQUFBLFFBQ0FEO0FBQUFBLFFBQ0FFO0FBQUFBLE1BQ0YsSUFBSVo7QUFDSixZQUFNb04sZUFBZTlHLFNBQVNsRyxlQUFlLEVBQUU7QUFDL0MsWUFBTWlOLGdCQUFnQjdQLG9CQUNuQmlGLE1BQU0sR0FBRzJLLFlBQVksRUFDckIzRSxJQUFJLENBQUM2RSxrQkFBa0I7QUFBQSxRQUN0QnBOO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FFO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FDO0FBQUFBLFFBQ0FKO0FBQUFBLFFBQ0ErSSxrQkFBa0J2STtBQUFBQSxRQUNsQkYsbUJBQW1CWCxTQUFTVztBQUFBQSxRQUM1Qk8sU0FBU29NO0FBQUFBLFFBQ1Q1TTtBQUFBQSxRQUNBRTtBQUFBQSxNQUNGLEVBQUU7QUFFSixVQUFJO0FBQ0YsbUJBQVcyTSxlQUFlRixlQUFlO0FBQ3ZDLGdCQUFNL1MsSUFBSTBRO0FBQUFBLFlBQ1I7QUFBQSxZQUNBO0FBQUEsY0FDRSxHQUFHdUM7QUFBQUEsY0FDSCxHQUFHek87QUFBQUEsWUFDTDtBQUFBLFlBQ0E7QUFBQSxjQUNFME8sU0FBUztBQUFBLGdCQUNQLGdCQUFnQjtBQUFBLGNBQ2xCO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBRUE3USxxQkFBYSxLQUFLO0FBQ2xCc0Qsb0JBQVk7QUFBQSxVQUNWQyxVQUFVO0FBQUEsVUFDVkMsU0FBUztBQUFBLFVBQ1RDLGVBQWU7QUFBQSxVQUNmQyxlQUFlO0FBQUEsVUFDZlEsaUJBQWlCO0FBQUEsVUFDakJQLGNBQWM7QUFBQSxVQUNkQyxtQkFBbUI7QUFBQSxVQUNuQkMsT0FBTztBQUFBLFVBQ1BDLGVBQWU7QUFBQSxVQUNmQztBQUFBQSxRQUNGLENBQUM7QUFDRG5CLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pyRSxTQUFTO0FBQUEsVUFDVHNFLE1BQU07QUFBQSxRQUNSLENBQUM7QUFBQSxNQUNILFNBQVNtRyxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLE1BQzlDLFVBQUM7QUFDQ2pJLG1CQUFXLEtBQUs7QUFBQSxNQUNsQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTThQLG9CQUFvQkEsQ0FBQzdJLE1BQU07QUFDL0IsVUFBTSxFQUFFaUUsTUFBTWhFLE1BQU0sSUFBSUQsRUFBRUU7QUFDMUI3RCxzQkFBa0IsQ0FBQ3lNLGVBQWU7QUFBQSxNQUNoQyxHQUFHQTtBQUFBQSxNQUNILENBQUM3RSxJQUFJLEdBQUdoRTtBQUFBQSxJQUNWLEVBQUU7QUFBQSxFQUNKO0FBRUEsUUFBTWdGLHdCQUF3QixPQUFPNUMsYUFBYTtBQUNoRCxRQUFJO0FBQ0YsWUFBTXhCLFdBQVcsTUFBTW5MLElBQUlvTCxJQUFJLDRCQUE0QnVCLFFBQVEsRUFBRTtBQUNyRWxLLDRCQUFzQjBJLFNBQVNFLElBQUk7QUFDbkMxRSx3QkFBa0I7QUFBQSxRQUNoQmYsVUFBVXVGLFNBQVNFLE1BQU16RixVQUFVb0YsT0FBT0csU0FBU0UsTUFBTXpGLFlBQVk7QUFBQSxRQUNyRUMsU0FBU3NGLFNBQVNFLE1BQU14RixTQUFTbUYsT0FBT0csU0FBU0UsTUFBTXhGLFdBQVc7QUFBQSxRQUNsRWUsU0FBU3VFLFNBQVNFLE1BQU16RSxXQUFXO0FBQUEsUUFDbkNaLGNBQWNtRixTQUFTRSxNQUFNckYsZ0JBQWdCO0FBQUEsUUFDN0NELGVBQWVvRixTQUFTRSxNQUFNdEYsaUJBQWlCO0FBQUEsUUFDL0NRLGlCQUFpQjRFLFNBQVNFLE1BQU15RDtBQUFBQSxRQUNoQzVJLE9BQ0VpRixTQUFTRSxNQUFNbkYsT0FBTzhFLE9BQU9HLFNBQVNFLE1BQU1uRixTQUFTO0FBQUEsUUFFdkRELG1CQUNFa0YsU0FBU0UsTUFBTXBGLG1CQUFtQitFLE9BQ2xDRyxTQUFTRSxNQUFNcEYscUJBQ2Y7QUFBQSxRQUVGRSxlQUNFZ0YsU0FBU0UsTUFBTWxGLGVBQWU2RSxPQUM5QkcsU0FBU0UsTUFBTWxGLGlCQUNmO0FBQUEsUUFFRkUsbUJBQW1COEUsU0FBU0UsTUFBTWhGLHFCQUFxQjtBQUFBLFFBQ3ZEUSxrQkFBa0JzRSxTQUFTRSxNQUFNeEUsb0JBQW9CO0FBQUEsUUFDckRDLHVCQUF1QnFFLFNBQVNFLE1BQU12RSx5QkFBeUI7QUFBQSxRQUMvRHVNLDJCQUNFbEksU0FBU0UsTUFBTWdJLDZCQUE2QjtBQUFBLFFBQzlDQyx1QkFBdUJuSSxTQUFTRSxNQUFNaUkseUJBQXlCO0FBQUEsUUFDL0RDLHdCQUF3QnBJLFNBQVNFLE1BQU1rSSwwQkFBMEI7QUFBQSxNQUNuRSxDQUFDO0FBRUQsWUFBTTlILFNBQVNOLFNBQVNFLE1BQU14RixTQUFTbUYsT0FBT0csU0FBU0UsTUFBTXhGO0FBQzdELFVBQUk0RixRQUFRO0FBQ1ZwQyxrQ0FBMEIsSUFBSTtBQUM5QixjQUFNc0gsUUFBUUM7QUFBQUEsVUFBSTtBQUFBLFlBQ2hCcEYseUJBQXlCQyxNQUFNO0FBQUEsWUFDL0JHLG1CQUFtQkgsTUFBTTtBQUFBLFlBQ3pCSSxtQkFBbUJKLE1BQU07QUFBQSxVQUFDO0FBQUEsUUFDM0I7QUFDRHBDLGtDQUEwQixLQUFLO0FBQUEsTUFDakM7QUFDQTlHLHlCQUFtQixJQUFJO0FBQUEsSUFDekIsU0FBUytJLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw4QkFBOEJBLEtBQUs7QUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFFQSxRQUFNa0ksMkJBQTJCQSxDQUFDQyxhQUFhQyxXQUFXQyxjQUFjO0FBQ3RFLFVBQU12RSxRQUFRO0FBR2RxRSxpQkFBYUcsUUFBUSxDQUFBaEgsZUFBYztBQUNqQyxZQUFNd0IsUUFBUXhCLFdBQVdoSDtBQUN6QixZQUFNc0osU0FBU3RDLFdBQVdoRztBQUMxQixVQUFJd0gsU0FBU2MsUUFBUTtBQUNuQkUsY0FBTTRDLEtBQUs7QUFBQSxVQUNUMUQsSUFBSSxRQUFRRixNQUFNcEQsR0FBRyxJQUFJa0UsTUFBTTtBQUFBLFVBQy9CL0osTUFBTTtBQUFBLFVBQ05vSixNQUFNSCxNQUFNTTtBQUFBQSxVQUNaUTtBQUFBQSxVQUNBMkUsYUFBYXpGLE1BQU15RixlQUFlO0FBQUEsVUFDbENDLGVBQWUxRixNQUFNMEYsaUJBQWlCO0FBQUEsVUFDdENDLFNBQVNuSCxXQUFXb0gsaUJBQWlCO0FBQUEsVUFDckNDLE1BQU1ySCxXQUFXc0gsb0JBQW9CO0FBQUEsVUFDckNDLFdBQVd2SCxXQUFXc0gsb0JBQW9CO0FBQUEsVUFDMUNFLGNBQWN4SCxXQUFXeUgsaUJBQWlCO0FBQUEsVUFDMUNDLGNBQWMxSCxXQUFXMkgsa0JBQWtCO0FBQUEsVUFDM0NDLFNBQVU1SCxXQUFXNkg7QUFBQUEsUUFDdkIsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGLENBQUM7QUFHRGYsY0FBVUUsUUFBUSxDQUFBYyxVQUFTO0FBQ3pCdEYsWUFBTTRDLEtBQUs7QUFBQSxRQUNUMUQsSUFBSSxTQUFTb0csTUFBTTFKLEdBQUc7QUFBQSxRQUN0QjdGLE1BQU07QUFBQSxRQUNOb0osTUFBTW1HLE1BQU1DLFlBQVk7QUFBQSxRQUN4QkMsZUFBZUYsTUFBTUcsa0JBQWtCO0FBQUEsUUFDdkN6SSxXQUFXc0ksTUFBTUk7QUFBQUEsUUFDakJDLFVBQVVMLE1BQU1LO0FBQUFBLFFBQ2hCWixXQUFXTyxNQUFNTSxxQkFBcUI7QUFBQSxRQUN0Q1IsVUFBVUUsTUFBTUcsa0JBQWtCLE1BQU1ILE1BQU1PLGVBQWU7QUFBQSxNQUMvRCxDQUFDO0FBQUEsSUFDSCxDQUFDO0FBR0R0QixjQUFVQyxRQUFRLENBQUFzQixTQUFRO0FBQ3hCOUYsWUFBTTRDLEtBQUs7QUFBQSxRQUNUMUQsSUFBSSxRQUFRNEcsS0FBS2xLLEdBQUc7QUFBQSxRQUNwQjdGLE1BQU07QUFBQSxRQUNOb0osTUFBTTJHLEtBQUtDLFdBQVc7QUFBQSxRQUN0QkMsWUFBWUYsS0FBS0csZUFBZTtBQUFBLFFBQ2hDakosV0FBVzhJLEtBQUtKO0FBQUFBLFFBQ2hCekksU0FBUzZJLEtBQUtJO0FBQUFBLFFBQ2RDLGNBQWNMLEtBQUtNLHdCQUF3QjtBQUFBLFFBQzNDckIsV0FBV2UsS0FBS08sa0JBQWtCO0FBQUEsUUFDbENqQixTQUFVVSxLQUFLUSxrQkFBa0I7QUFBQSxNQUNuQyxDQUFDO0FBQUEsSUFDSCxDQUFDO0FBRUQsV0FBT3RHO0FBQUFBLEVBQ1Q7QUFFQSxRQUFNSSx3QkFBd0IsT0FBTy9DLFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU10QixXQUFXLE1BQU1uTCxJQUFJb0wsSUFBSSw0QkFBNEJxQixPQUFPLEVBQUU7QUFDcEV4SixzQkFBZ0JrSSxTQUFTRSxJQUFJO0FBQzdCeEkseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTeUksT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUVBLFFBQU1tRSx3QkFBd0IsT0FBT2hELFlBQVk7QUFDL0MsUUFBSTtBQUNGLFlBQU10QixXQUFXLE1BQU1uTCxJQUFJb0wsSUFBSSw0QkFBNEJxQixPQUFPLEVBQUU7QUFDcEV4SixzQkFBZ0JrSSxTQUFTRSxJQUFJO0FBQzdCdEkseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTdUksT0FBTztBQUNkQyxjQUFRRCxNQUFNLG1DQUFtQztBQUFBLElBQ25EO0FBQUEsRUFDRjtBQUVBLFFBQU1xSyxvQkFBb0IsT0FBT3JMLE1BQU07QUFDckNBLE1BQUVzRCxlQUFlO0FBRWpCLFFBQUk1SyxjQUFjO0FBQ2hCLFlBQU02QyxVQUFVN0MsYUFBYTZDLFNBQVNtRjtBQUN0QyxVQUFJbkYsU0FBUztBQUNYLFlBQUk7QUFDRixnQkFBTTdGLElBQUk2TixJQUFJLGtCQUFrQjdLLGNBQWNnSSxHQUFHLElBQUk7QUFBQSxZQUNuRG5GO0FBQUFBLFlBQ0ErUCxZQUFZdFE7QUFBQUEsWUFDWnVRLFlBQVksb0JBQUkxUixLQUFLO0FBQUEsWUFDckJIO0FBQUFBLFVBQ0YsQ0FBQztBQUNEQywyQkFBaUIsRUFBRTtBQUNuQnBCLDZCQUFtQixLQUFLO0FBQ3hCSSwwQkFBZ0IsSUFBSTtBQUNwQmdDLHlCQUFlO0FBQUEsWUFDYkMsWUFBWTtBQUFBLFlBQ1pyRSxTQUFTO0FBQUEsWUFDVHNFLE1BQU07QUFBQSxVQUNSLENBQUM7QUFBQSxRQUNILFNBQVNtRyxPQUFPO0FBQ2RySCwyQkFBaUIsRUFBRTtBQUNuQnNILGtCQUFRRCxNQUFNLHlCQUF5QkEsS0FBSztBQUFBLFFBQzlDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTXdLLG9CQUFvQixPQUFPeEwsTUFBTTtBQUNyQ0EsTUFBRXNELGVBQWU7QUFDakIsUUFBSTVLLGNBQWM7QUFDaEIsWUFBTTZDLFVBQVU3QyxjQUFjNkMsU0FBU21GO0FBQ3ZDLFVBQUluRixTQUFTO0FBQ1gsWUFBSTtBQUNGLGdCQUFNN0YsSUFBSTZOO0FBQUFBLFlBQUksNkJBQTZCN0ssY0FBY2dJLEdBQUc7QUFBQSxZQUMxRDtBQUFBLGNBQ0VuRjtBQUFBQSxjQUNBa1EsV0FBVyxvQkFBSTVSLEtBQUs7QUFBQSxjQUNwQnlSLFlBQVl0UTtBQUFBQSxjQUNaMFEsZ0JBQWdCO0FBQUEsWUFDbEI7QUFBQSxVQUNGO0FBQ0FqVCw2QkFBbUIsRUFBRTtBQUNyQkUsMEJBQWdCLElBQUk7QUFDcEJnQyx5QkFBZTtBQUFBLFlBQ2JDLFlBQVk7QUFBQSxZQUNackUsU0FBUztBQUFBLFlBQ1RzRSxNQUFNO0FBQUEsVUFDUixDQUFDO0FBQUEsUUFFSCxTQUFTbUcsT0FBTztBQUNkQyxrQkFBUUQsTUFBTSw4QkFBOEI7QUFBQSxRQUM5QztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUdBLFFBQU0ySyxlQUFlLE9BQU8zTCxNQUFNO0FBQ2hDQSxNQUFFc0QsZUFBZTtBQUNqQixVQUFNc0ksVUFBVTtBQUFBLE1BQ2QsR0FBR3hQO0FBQUFBLE1BQ0hvSSxrQkFBa0JwSSxlQUFlSDtBQUFBQSxJQUNuQztBQUNBLFFBQUk7QUFDRixZQUFNdkcsSUFBSTZOO0FBQUFBLFFBQ1IseUJBQXlCckwsbUJBQW1Cd0ksR0FBRztBQUFBLFFBQy9Da0w7QUFBQUEsTUFDRjtBQUNBM1QseUJBQW1CLEtBQUs7QUFDeEIwQyxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNackUsU0FBUztBQUFBLFFBQ1RzRSxNQUFNO0FBQUEsTUFDUixDQUFDO0FBQUEsSUFDSCxTQUFTbUcsT0FBTztBQUNkQyxjQUFRRCxNQUFNLDBCQUEwQkEsS0FBSztBQUFBLElBQy9DO0FBQUEsRUFDRjtBQUVBekwsWUFBVSxNQUFNO0FBQ2QsUUFBSXFDLGVBQWU7QUFDakJsQyxVQUNHMFEsS0FBSyw0QkFBNEJ4TyxhQUFhLEVBQUUsRUFDaERpVSxLQUFLLENBQUNoTCxhQUFhO0FBQ2xCeEksNEJBQW9Cd0ksU0FBU0UsS0FBSzNJLG9CQUFvQixFQUFFO0FBQUEsTUFDMUQsQ0FBQyxFQUNBMFQsTUFBTSxDQUFDOUssVUFBVTtBQUNoQkMsZ0JBQVFELE1BQU0scUNBQXFDQSxLQUFLO0FBQUEsTUFDMUQsQ0FBQztBQUFBLElBQ0wsT0FBTztBQUNMM0ksMEJBQW9CLEVBQUU7QUFBQSxJQUN4QjtBQUFBLEVBQ0YsR0FBRyxDQUFDVCxhQUFhLENBQUM7QUFFbEIsUUFBTW1VLGVBQWUsWUFBWTtBQUMvQixVQUFNO0FBQUEsTUFDSnhRO0FBQUFBLE1BQ0FEO0FBQUFBLE1BQ0FNO0FBQUFBLE1BQ0FEO0FBQUFBLE1BQ0FFO0FBQUFBLE1BQ0FKO0FBQUFBLElBQ0YsSUFBSUw7QUFFSixRQUFJLENBQUNHLFdBQVcsQ0FBQ0QsVUFBVTtBQUN6QmxGLG1CQUFhNFYsUUFBUTtBQUFBLFFBQ25CelYsU0FBUztBQUFBLE1BQ1gsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUVBLFFBQUk7QUFDRixZQUFNc0ssV0FBVyxNQUFNbkwsSUFBSW9MLElBQUksNEJBQTRCO0FBQUEsUUFDekRtTCxRQUFRLEVBQUUxUSxTQUFTRCxTQUFTO0FBQUEsTUFDOUIsQ0FBQztBQUVELFlBQU1pTCxlQUFlalAsTUFBTWtQLEtBQUssQ0FBQzBGLE1BQU1BLEVBQUV4TCxRQUFRbkYsT0FBTztBQUN4RCxZQUFNM0QsaUJBQWdCUixPQUFPb1AsS0FBSyxDQUFDMkYsTUFBTUEsRUFBRXpMLFFBQVFwRixRQUFRO0FBQzNELFlBQU04USxnQkFBZ0I1UyxPQUFPZ04sS0FBSyxDQUFDNkYsTUFBTUEsRUFBRTNMLFFBQVE5RSxLQUFLO0FBQ3hELFlBQU0wUSwyQkFBMkJoVixNQUFNa1A7QUFBQUEsUUFDckMsQ0FBQzBGLE1BQU1BLEVBQUV4TCxRQUFRL0U7QUFBQUEsTUFDbkI7QUFDQSxZQUFNNFEsdUJBQXVCalQsT0FBT2tOO0FBQUFBLFFBQ2xDLENBQUNnRyxNQUFNQSxFQUFFOUwsUUFBUTdFO0FBQUFBLE1BQ25CO0FBRUEsVUFBSWdGLFVBQVVFLE1BQU07QUFDbEIsY0FBTTBMLFlBQ0osT0FBTzVMLFNBQVNFLEtBQUtuRixVQUFVLFdBQzNCaUYsU0FBU0UsS0FBS25GLE9BQU9xSSxPQUNyQjtBQUNOLGNBQU15SSx1QkFDSixPQUFPN0wsU0FBU0UsS0FBS3BGLHNCQUFzQixXQUN2Q2tGLFNBQVNFLEtBQUtwRixtQkFBbUJ1SSxZQUNqQztBQUNOLGNBQU15SSxtQkFDSixPQUFPOUwsU0FBU0UsS0FBS2xGLGtCQUFrQixXQUNuQ2dGLFNBQVNFLEtBQUtsRixlQUFlNkksWUFDN0I7QUFFTixjQUFNa0ksb0JBQW9CO0FBRTFCLFlBQUlIO0FBQ0ZHLDRCQUFrQmxGO0FBQUFBLFlBQ2hCLG9DQUFvQytFLFNBQVM7QUFBQSxVQUMvQztBQUNGLFlBQUlDO0FBQ0ZFLDRCQUFrQmxGO0FBQUFBLFlBQ2hCLHNDQUFzQ2dGLG9CQUFvQjtBQUFBLFVBQzVEO0FBQ0YsWUFBSUM7QUFDRkMsNEJBQWtCbEY7QUFBQUEsWUFDaEIsbUNBQW1DaUYsZ0JBQWdCO0FBQUEsVUFDckQ7QUFDRixZQUFJQyxrQkFBa0JqSixXQUFXO0FBQy9CaUosNEJBQWtCbEYsS0FBSywwQ0FBMEM7QUFFbkVyTSxvQkFBWSxDQUFDc0YsVUFBVTtBQUFBLFVBQ3JCLEdBQUdBO0FBQUFBLFVBQ0huRixlQUFlcUYsVUFBVUUsTUFBTXZGLGlCQUFpQm1GLEtBQUtuRjtBQUFBQSxVQUNyREUsY0FBY21GLFVBQVVFLE1BQU1yRixnQkFBZ0JpRixLQUFLakY7QUFBQUEsVUFDbkRDLG1CQUNFa0YsVUFBVUUsTUFBTXBGLHFCQUFxQmdGLEtBQUtoRjtBQUFBQSxVQUM1Q0UsZUFBZWdGLFVBQVVFLE1BQU1sRixpQkFBaUI4RSxLQUFLOUU7QUFBQUEsVUFDckRKLGVBQ0VrRixLQUFLbEYsaUJBQ0xvRixVQUFVRSxNQUFNdEYsa0JBQ2ZvRixTQUFTRSxNQUFNbkYsUUFDWixVQUNBaUYsU0FBU0UsTUFBTXBGLG9CQUNiLGFBQ0FrRixTQUFTRSxNQUFNbEYsZ0JBQ2IsVUFDQTtBQUFBLFFBRVosRUFBRTtBQUVGLFlBQUlnUixhQUFhO0FBQ2pCLFlBQUlwUixrQkFBa0I7QUFDcEJvUix1QkFBYVQsZUFBZW5JLFFBQVE7QUFBQSxpQkFDN0J4SSxrQkFBa0I7QUFDekJvUix1QkFDRVAsMEJBQTBCcEksYUFBYTtBQUFBLGlCQUNsQ3pJLGtCQUFrQjtBQUN6Qm9SLHVCQUFhTixzQkFBc0I3SCxhQUFhO0FBRWxEM0osZ0NBQXdCLElBQUk7QUFDNUJOLDBCQUFrQixVQUFVO0FBRTVCckUscUJBQWE0VixRQUFRO0FBQUEsVUFDbkJ6VixTQUNFO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFPO0FBQUEsZ0JBQ0x1VyxZQUFZO0FBQUEsZ0JBQ1pDLFVBQVU7QUFBQSxnQkFDVkMsY0FBYztBQUFBLGNBQ2hCO0FBQUEsY0FBRTtBQUFBO0FBQUEsZ0JBRWV6RyxjQUFjckM7QUFBQUEsZ0JBQVU7QUFBQSxnQkFDekMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFHO0FBQUEsZ0JBQ0gsdUJBQUMsUUFBRyxPQUFPLEVBQUUrSSxRQUFRLFVBQVVDLFdBQVcsaUJBQWlCLEtBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTZEO0FBQUEsZ0JBQUc7QUFBQSxnQkFDbER0VixnQkFBZXdNO0FBQUFBLGdCQUFXO0FBQUEsZ0JBQ3hDLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBRztBQUFBLGdCQUNILHVCQUFDLFFBQUcsT0FBTyxFQUFFNkksUUFBUSxVQUFVQyxXQUFXLGlCQUFpQixLQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE2RDtBQUFBO0FBQUE7QUFBQSxZQVovRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFhQTtBQUFBLFVBRUZDLGFBQ0UsdUJBQUMsU0FBSSxPQUFPLEVBQUVMLFlBQVksUUFBUUMsVUFBVSxVQUFVLEdBQ25ESCw0QkFBa0IvSTtBQUFBQSxZQUFJLENBQUN1SixNQUFNckosVUFDNUIsdUJBQUMsVUFDRXFKO0FBQUFBO0FBQUFBLGNBQ0QsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFHO0FBQUEsY0FDSDtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxPQUFPLEVBQUVILFFBQVEsVUFBVUMsV0FBVyxpQkFBaUI7QUFBQTtBQUFBLGdCQUR6RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FDMkQ7QUFBQSxpQkFKbERuSixPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxVQUNELEtBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBRUYwRyxVQUFVO0FBQUEsUUFDWixDQUFDO0FBQ0QxUCxnQ0FBd0IsSUFBSTtBQUM1Qm9CLHNCQUFjLElBQUk7QUFDbEIxQiwwQkFBa0IsVUFBVTtBQUFBLE1BQzlCLE9BQU87QUFDTE0sZ0NBQXdCLEtBQUs7QUFDN0JvQixzQkFBYyxJQUFJO0FBQ2xCMUIsMEJBQWtCLFVBQVU7QUFFNUJyRSxxQkFBYWdSLFFBQVE7QUFBQSxVQUNuQjdRLFNBQVM7QUFBQSxVQUNUNFcsYUFBYSxTQUFTNUcsY0FBY3JDLFNBQVMseUJBQXlCdE0sZ0JBQWV3TSxVQUFVO0FBQUEsVUFDL0ZxRyxVQUFVO0FBQUEsUUFDWixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsU0FBU3BKLEtBQUs7QUFDWkosY0FBUUQsTUFBTSx1QkFBdUJLLEdBQUc7QUFDeENqTCxtQkFBYTRLLE1BQU07QUFBQSxRQUNqQnpLLFNBQVM7QUFBQSxRQUNUNFcsYUFBYTlMLElBQUlSLFVBQVVFLE1BQU14SyxXQUFXO0FBQUEsTUFDOUMsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsUUFBTThXLGtCQUFrQixPQUFPck4sTUFBTTtBQUNuQ0EsTUFBRXNELGVBQWU7QUFFakIsUUFBSTlJLG1CQUFtQixVQUFVO0FBQy9CLFlBQU11UixhQUFhO0FBQUEsSUFDckIsV0FBV3ZSLG1CQUFtQixZQUFZO0FBQ3hDQyx3QkFBa0IsUUFBUTtBQUFBLElBQzVCLFdBQVdELG1CQUFtQixVQUFVO0FBQ3RDOE4sbUJBQWF0SSxDQUFDO0FBQUEsSUFDaEI7QUFBQSxFQUNGO0FBRUEsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLFlBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1CO0FBQUEsTUFFbkIsdUJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFNdEYsWUFBWUc7QUFBQUEsVUFDbEIsV0FBV0gsWUFBWUU7QUFBQUEsVUFDdkIsU0FBU0YsWUFBWW5FO0FBQUFBO0FBQUFBLFFBSHZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUcrQjtBQUFBLE1BRS9CLHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSxzQ0FDYjtBQUFBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXLGlDQUFpQzJFLGNBQWMsZ0JBQ3RELGlEQUNBLG1DQUFtQztBQUFBLGNBRXZDLFNBQVMsTUFBTUMsYUFBYSxhQUFhO0FBQUEsY0FBRTtBQUFBO0FBQUEsWUFMN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFXLGlDQUFpQ0QsY0FBYyxnQkFDdEQsaURBQ0EsbUNBQW1DO0FBQUEsY0FFdkMsU0FBUyxNQUFNQyxhQUFhLGFBQWE7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUw3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFRQTtBQUFBLGFBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkE7QUFBQSxRQUNDRCxjQUFjO0FBQUE7QUFBQSxVQUViLG1DQUNFO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDBCQUF5QiwyQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBa0Q7QUFBQSxZQUNsRCx1QkFBQyxTQUFJLFdBQVUsYUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxRQUNiLGlDQUFDLFdBQU0sc0NBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLDZDQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0M7QUFBQSxvQkFDQSx1QkFBdUI7QUFBQSxvQkFDdkIsT0FBT3RELGlCQUFpQjtBQUFBLG9CQUN4QixjQUFjLENBQUMwVixPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLG9CQUVqQyxhQUFZO0FBQUEsb0JBQ1osVUFBVXBHO0FBQUFBLG9CQUNWLFdBQVU7QUFBQSxvQkFFVjtBQUFBLDZDQUFDLE9BQU8sUUFBUCxFQUF5QixPQUFPLFVBQVUsaUNBQXZCLE1BQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFFQSx1QkFBQyxPQUFPLFFBQVAsRUFBeUIsT0FBTyxTQUFTLGtDQUF0QixNQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQ0NsUSxPQUFPeU07QUFBQUEsd0JBQUksQ0FBQ0MsVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTXBELEtBQ3pDb0QsZ0JBQU1NLGNBRFdOLE1BQU1wRCxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUVBO0FBQUEsc0JBQ0Q7QUFBQTtBQUFBO0FBQUEsa0JBekJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkEwQkE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFTLE1BQU0zSSxhQUFhLElBQUk7QUFBQSxvQkFDaEMsV0FBVTtBQUFBLG9CQUF1RztBQUFBO0FBQUEsa0JBRm5IO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFLQTtBQUFBLG1CQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtDQTtBQUFBLGlCQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVDQTtBQUFBLFlBQ0NQLGNBQWNtTSxTQUFTLElBQ3RCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsZUFBZXNCO0FBQUFBLGdCQUNmLE1BQU10TyxhQUFhYSxjQUFjb0YsVUFBVTtBQUFBLGdCQUMzQztBQUFBLGdCQUNBLGlCQUFnQjtBQUFBLGdCQUNoQixrQkFBa0IsZUFBZXBGLGFBQWFtTSxTQUFTLElBQ25Ebk0sYUFBYSxDQUFDLEVBQUV5TSxPQUNsQixTQUNBek0sYUFBYUEsYUFBYW1NLFNBQVMsQ0FBQyxFQUFFTSxPQUNwQyxPQUFPO0FBQUE7QUFBQSxjQVRiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVXLElBR1g7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxXQUFXakw7QUFBQUEsZ0JBQ1gsU0FBU3hCLGNBQWNtTSxVQUFVLEtBQUsvTDtBQUFBQSxnQkFDdEMsTUFBTTtBQUFBO0FBQUEsY0FIUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHMEI7QUFBQSxlQTNEOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkErREE7QUFBQTtBQUFBO0FBQUEsVUFHQSx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFZO0FBQUE7QUFBQSxXQXpGaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTJGQTtBQUFBLFNBdEdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1R0E7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXRTtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyx1QkFBYSxLQUFLO0FBQ2xCb0Isb0JBQVUsQ0FBQyxDQUFDO0FBQUEsUUFDZDtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLG1EQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHVEQUFzRCw4QkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUEsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVW1QLGNBQWMsWUFBVSxNQUM1RDtBQUFBLG1DQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxnQkFDMUQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQUR4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQzNTLFVBQVVpWSxNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDTixPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxPQUFPdFMsVUFBVUUsWUFBWXVTO0FBQUFBLGtCQUM3QixVQUFVLENBQUM1TixVQUFVK0YsaUJBQWlCLFlBQVkvRixLQUFLO0FBQUEsa0JBRXREN0ksaUJBQU95TTtBQUFBQSxvQkFBSSxDQUFDQyxVQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNcEQsS0FDekNvRCxnQkFBTU0sY0FEV04sTUFBTXBELEtBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBbkJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQW9CQTtBQUFBLGNBQ0N4SCxPQUFPb0MsWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQTZCcEMsaUJBQU9vQyxZQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEwRDtBQUFBLGlCQTFCOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE0QkE7QUFBQSxZQUVBLHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxnQkFDdkQsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXLHFDQUFxQzNGLFVBQVVpWSxNQUFNO0FBQUEsa0JBQ2hFLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDTixPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGtCQUVqQyxPQUFPdFMsVUFBVUcsV0FBV3NTO0FBQUFBLGtCQUU1QixVQUFVLENBQUM1TixVQUFVO0FBQ25CK0YscUNBQWlCLFdBQVcvRixLQUFLO0FBR2pDLDBCQUFNc0csZUFBZWpQLE1BQU1rUCxLQUFLLENBQUMwRixNQUFNQSxFQUFFeEwsUUFBUVQsS0FBSztBQUN0RCx3QkFBSXNHLGNBQWM7QUFDaEJoTSwrQkFBU2dNLGFBQWFuTSxTQUFTLEVBQUU7QUFDakNpQixrQ0FBWSxDQUFDc0YsVUFBVTtBQUFBLHdCQUNyQixHQUFHQTtBQUFBQSx3QkFDSDdFLFVBQVV5SyxhQUFhbk07QUFBQUEsc0JBQ3pCLEVBQUU7QUFBQSxvQkFDSjtBQUFBLGtCQUNGO0FBQUEsa0JBRUM5QyxnQkFBTXVNO0FBQUFBLG9CQUFJLENBQUMxRCxTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLTyxLQUN2Q1A7QUFBQUEsMkJBQUsrRDtBQUFBQSxzQkFBVTtBQUFBLHNCQUFJL0QsS0FBS2dFLGdCQUFnQjtBQUFBLHlCQUR2QmhFLEtBQUtPLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBaENIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWlDQTtBQUFBLGNBRUN0RixTQUFTRyxXQUNSLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLDRDQUEyQztBQUFBO0FBQUEsa0JBRXZEdUQsMEJBQTBCLHVCQUFDLFVBQUssV0FBVSxzQkFBcUIsMEJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQStDO0FBQUEscUJBRjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxnQkFFQyxDQUFDQSwwQkFDQSx1QkFBQyxTQUFJLFdBQVUsMERBQ1gsaUJBQU07QUFDTix3QkFBTWdQLFVBQVU1RTtBQUFBQSxvQkFDZDFLO0FBQUFBLG9CQUNBRTtBQUFBQSxvQkFDQUU7QUFBQUEsa0JBQ0Y7QUFDQSxzQkFBSWtQLFFBQVFuSyxXQUFXLEdBQUc7QUFDeEIsMkJBQ0UsdUJBQUMsU0FBSSxXQUFVLGdDQUErQiwrREFBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUVKO0FBQ0EseUJBQU9tSyxRQUFRaks7QUFBQUEsb0JBQUksQ0FBQ2tLLFNBQ2xCO0FBQUEsc0JBQUM7QUFBQTtBQUFBLHdCQUVDLFdBQVcsNENBQTRDQSxLQUFLN0QsVUFBVSxJQUFJLG1CQUFtQixrQkFBa0I7QUFBQSx3QkFJL0c7QUFBQSxpREFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSxtREFBQyxPQUFJLFdBQVUsbURBQ1o2RCxlQUFLbFQsUUFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQUVBO0FBQUEsNEJBQ0EsdUJBQUMsVUFBSyxXQUFVLHVDQUNia1QsZUFBSzlKLFFBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FFQTtBQUFBLDRCQUNDOEosS0FBS2xULFNBQVMsVUFBVWtULEtBQUtuSixVQUM1Qix1QkFBQyxVQUFLLFdBQVUscUNBQW9DO0FBQUE7QUFBQSw4QkFDekNtSixLQUFLbko7QUFBQUEsaUNBRGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBRUE7QUFBQSw0QkFFRG1KLEtBQUtsVCxTQUFTLFVBQ2IsbUNBQ0U7QUFBQSxxREFBQyxVQUFLLFdBQVUseUJBQXdCO0FBQUE7QUFBQSxnQ0FDeEJrVCxLQUFLeEU7QUFBQUEsbUNBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBRUE7QUFBQSw4QkFDQSx1QkFBQyxVQUFLLFdBQVUseUJBQXdCO0FBQUE7QUFBQSxnQ0FDbEJ3RSxLQUFLdkU7QUFBQUEsbUNBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBRUE7QUFBQSxpQ0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQU9BO0FBQUEsK0JBcEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBc0JBO0FBQUEsMEJBR0EsdUJBQUMsU0FBSSxXQUFVLGdHQUNadUU7QUFBQUEsaUNBQUtsVCxTQUFTLFVBQ2IsbUNBQ0U7QUFBQSxxREFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx1REFBQyxVQUFLLFdBQVUsa0VBQWlFLDZCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsZ0NBQ0EsdUJBQUMsVUFBSyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsa0NBQ2xEa1QsS0FBS3RFLFNBQVN1RSxlQUFlLE9BQU87QUFBQSxxQ0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQTtBQUFBLG1DQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBT0E7QUFBQSw4QkFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx1REFBQyxVQUFLLFdBQVUsa0VBQWlFLDBCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsZ0NBQ0EsdUJBQUMsVUFBSyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsa0NBQ2xERCxLQUFLbEUsV0FBV21FLGVBQWUsT0FBTztBQUFBLHFDQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsbUNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FPQTtBQUFBLDhCQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHVEQUFDLFVBQUssV0FBVSxrRUFBaUUsdUJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSxnQ0FDQSx1QkFBQyxVQUFLLFdBQVUsdUNBQXNDO0FBQUE7QUFBQSxrQ0FDbERELEtBQUtqRSxjQUFja0UsZUFBZSxPQUFPO0FBQUEscUNBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSxtQ0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQU9BO0FBQUEsOEJBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsdURBQUMsVUFBSyxXQUFVLGtFQUFpRSx3QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQTtBQUFBLGdDQUNBLHVCQUFDLFVBQUssV0FBVSx1Q0FBc0M7QUFBQTtBQUFBLGtDQUNsREQsS0FBSy9ELGNBQWNnRSxlQUFlLE9BQU87QUFBQSxxQ0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQTtBQUFBLG1DQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBT0E7QUFBQSw4QkFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx1REFBQyxVQUFLLFdBQVUsa0VBQWlFLDJCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsZ0NBQ0EsdUJBQUMsVUFBSyxXQUFXLHlCQUF5QkQsS0FBSzdELFVBQVUsSUFBSSxpQkFBaUIsZ0JBQWdCLElBQUk7QUFBQTtBQUFBLGtDQUM5RjZELEtBQUs3RCxTQUFTOEQsZUFBZSxPQUFPO0FBQUEscUNBRHhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSxtQ0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQU9BO0FBQUEsaUNBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBeUNBO0FBQUEsNEJBR0RELEtBQUtsVCxTQUFTLFVBQ2IsbUNBQ0U7QUFBQSxxREFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx1REFBQyxVQUFLLFdBQVUsa0VBQWlFLDJCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsZ0NBQ0EsdUJBQUMsVUFBSyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsa0NBQ2xEa1QsS0FBS2pELFlBQVlrRCxlQUFlLE9BQU87QUFBQSxxQ0FEM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQTtBQUFBLG1DQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBT0E7QUFBQSw4QkFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx1REFBQyxVQUFLLFdBQVUsa0VBQWlFLDBCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsZ0NBQ0EsdUJBQUMsVUFBSyxXQUFVLHVDQUNiRCxlQUFLak0sV0FBVy9ILE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRUEsTUFBTSxHQUFHLEVBQUVrVSxRQUFRLEVBQUVDLEtBQUssR0FBRyxLQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsbUNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FPQTtBQUFBLDhCQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHVEQUFDLFVBQUssV0FBVSxrRUFBaUUsd0JBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSxnQ0FDQSx1QkFBQyxVQUFLLFdBQVUsdUNBQ2JILGVBQUtoTSxTQUFTaEksTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFQSxNQUFNLEdBQUcsRUFBRWtVLFFBQVEsRUFBRUMsS0FBSyxHQUFHLEtBRDVEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSxtQ0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQU9BO0FBQUEsOEJBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsdURBQUMsVUFBSyxXQUFVLGtFQUFpRSw2QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQTtBQUFBLGdDQUNBLHVCQUFDLFVBQUssV0FBVSx1Q0FBc0M7QUFBQTtBQUFBLGtDQUNsREgsS0FBSzlDLGNBQWMrQyxlQUFlLE9BQU87QUFBQSxxQ0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQTtBQUFBLG1DQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBT0E7QUFBQSw4QkFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2I7QUFBQSx1REFBQyxVQUFLLFdBQVUsa0VBQWlFLDBCQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsZ0NBQ0EsdUJBQUMsVUFBSyxXQUFVLHVDQUFzQztBQUFBO0FBQUEsa0NBQ2xERCxLQUFLbEUsV0FBV21FLGVBQWUsT0FBTztBQUFBLHFDQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsbUNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FPQTtBQUFBLDhCQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHVEQUFDLFVBQUssV0FBVSxrRUFBaUUsdUJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSxnQ0FDQSx1QkFBQyxVQUFLLFdBQVcseUJBQXlCRCxLQUFLN0QsVUFBVSxJQUFJLGlCQUFpQixnQkFBZ0IsSUFBSTtBQUFBO0FBQUEsa0NBQzlGNkQsS0FBSzdELFNBQVM4RCxlQUFlLE9BQU87QUFBQSxxQ0FEeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQTtBQUFBLG1DQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBT0E7QUFBQSxpQ0FoREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FpREE7QUFBQSw0QkFHREQsS0FBS2xULFNBQVMsV0FDYixtQ0FDRTtBQUFBLHFEQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHVEQUFDLFVBQUssV0FBVSxrRUFBaUUsNEJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSxnQ0FDQSx1QkFBQyxVQUFLLFdBQVUsdUNBQXNDO0FBQUE7QUFBQSxrQ0FDbERrVCxLQUFLekQsZUFBZTBELGVBQWUsT0FBTztBQUFBLHFDQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsbUNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FPQTtBQUFBLDhCQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHVEQUFDLFVBQUssV0FBVSxrRUFBaUUsMEJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSxnQ0FDQSx1QkFBQyxVQUFLLFdBQVUsdUNBQ2JELGVBQUtqTSxXQUFXL0gsTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFQSxNQUFNLEdBQUcsRUFBRWtVLFFBQVEsRUFBRUMsS0FBSyxHQUFHLEtBRDlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSxtQ0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQU9BO0FBQUEsOEJBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsdURBQUMsVUFBSyxXQUFVLGtFQUFpRSx3QkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FFQTtBQUFBLGdDQUNBLHVCQUFDLFVBQUssV0FBVSx1Q0FDYkg7QUFBQUEsdUNBQUt0RDtBQUFBQSxrQ0FBUztBQUFBLHFDQURqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsbUNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FPQTtBQUFBLDhCQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLHVEQUFDLFVBQUssV0FBVSxrRUFBaUUsMEJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBRUE7QUFBQSxnQ0FDQSx1QkFBQyxVQUFLLFdBQVUsd0NBQXVDO0FBQUE7QUFBQSxrQ0FDbkRzRCxLQUFLbEUsV0FBV21FLGVBQWUsT0FBTztBQUFBLHFDQUQxQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQUVBO0FBQUEsbUNBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQ0FPQTtBQUFBLGlDQWhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQWlDQTtBQUFBLCtCQXJJSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQXVJQTtBQUFBO0FBQUE7QUFBQSxzQkFyS0tELEtBQUsvSjtBQUFBQSxzQkFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQXVLQTtBQUFBLGtCQUNEO0FBQUEsZ0JBQ0gsR0FBRyxLQXhMTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXlMQTtBQUFBLG1CQWhNSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtNQTtBQUFBLGNBRUQ1SSxVQUFVRyxXQUNULHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLE9BQU07QUFBQSxvQkFBc0M7QUFBQTtBQUFBLGtCQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxPQUFNO0FBQUEsb0JBQ04sTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDVixPQUFPbkIsU0FBUztBQUFBLG9CQUNoQixVQUFVLENBQUM0RixNQUFNO0FBQ2Z6RiwrQkFBU3lGLEVBQUVFLE9BQU9ELEtBQUs7QUFDdkI1RSxrQ0FBWSxDQUFDc0YsVUFBVTtBQUFBLHdCQUNyQixHQUFHQTtBQUFBQSx3QkFDSDdFLFVBQVVrRSxFQUFFRSxPQUFPRDtBQUFBQSxzQkFDckIsRUFBRTtBQUFBLG9CQUNKO0FBQUE7QUFBQSxrQkFYRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBV0k7QUFBQSxtQkFsQk47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFvQkE7QUFBQSxjQUVEL0csT0FBTzRDLFlBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QjVDLGlCQUFPNEMsWUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBMEQ7QUFBQSxpQkFwUTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc1FBO0FBQUEsWUFJQSx1QkFBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxxQ0FBQyxVQUFLLFdBQVUseUJBQXdCLCtCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FFQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsUUFBTztBQUFBLGtCQUNQLEtBQUk7QUFBQSxrQkFDSixXQUFVO0FBQUEsa0JBQXVIO0FBQUE7QUFBQSxnQkFKbkk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBT0E7QUFBQSxpQkFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWFBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGtCQUNuRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHFDQUFxQ25HLFVBQVVpWSxNQUFNO0FBQUEsb0JBQ2hFLGFBQVk7QUFBQSxvQkFDWix1QkFBdUI7QUFBQSxvQkFDdkI7QUFBQSxvQkFDQSxNQUFLO0FBQUEsb0JBQ0wsY0FBYyxDQUFDTixPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU0UsWUFBWSxFQUFFQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxvQkFFNUQsT0FBT3RTLFVBQVVNLGdCQUFnQm1TO0FBQUFBLG9CQUNqQyxVQUFVLENBQUM1TixVQUFVK0YsaUJBQWlCLGdCQUFnQi9GLEtBQUs7QUFBQSxvQkFFMUQsV0FBQyxTQUFTLFVBQVUsU0FBUyxFQUFFNEQ7QUFBQUEsc0JBQUksQ0FBQ3NLLFVBQ25DLHVCQUFDLE9BQU8sUUFBUCxFQUEwQixPQUFPQSxPQUMvQkEsbUJBRGlCQSxPQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBaUJBO0FBQUEsbUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBc0JBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxrREFBaUQsaUNBQWxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUNWLE9BQU9uUTtBQUFBQSxvQkFDUCxVQUFVLENBQUNnQyxNQUFNO0FBQ2YvQixzQ0FBZ0IrQixFQUFFRSxPQUFPRCxLQUFLO0FBQzlCNUUsa0NBQVksQ0FBQ3NGLFVBQVU7QUFBQSx3QkFDckIsR0FBR0E7QUFBQUEsd0JBQ0g1RSxtQkFBbUJpRSxFQUFFRSxPQUFPRDtBQUFBQTtBQUFBQSxzQkFDOUIsRUFBRTtBQUFBLG9CQUNKO0FBQUEsb0JBQ0EsS0FBSzJCLGtCQUFrQnpFLGFBQWFFLFlBQVk7QUFBQTtBQUFBLGtCQVhsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBV29EO0FBQUEsbUJBZnREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUJBO0FBQUEsaUJBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBNENBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsU0FDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxrREFBaUQ7QUFBQTtBQUFBLGtCQUNsRCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHFDQUFxQzFILFVBQVVpWSxNQUFNO0FBQUEsb0JBQ2hFLGFBQVk7QUFBQSxvQkFDWix1QkFBdUI7QUFBQSxvQkFDdkI7QUFBQSxvQkFDQSxNQUFLO0FBQUEsb0JBQ0wsY0FBYyxDQUFDTixPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU0UsWUFBWSxFQUFFQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxvQkFFNUQsT0FBT3RTLFVBQVVLLGlCQUFpQm9TO0FBQUFBLG9CQUNsQyxVQUFVLENBQUM1TixVQUFVK0YsaUJBQWlCLGlCQUFpQi9GLEtBQUs7QUFBQSxvQkFFM0Q7QUFBQSxzQkFDQztBQUFBLHNCQUNBO0FBQUEsc0JBQ0E7QUFBQSxzQkFDQTtBQUFBLHNCQUNBO0FBQUEsc0JBRUE7QUFBQSxvQkFBUSxFQUNSNEQ7QUFBQUEsc0JBQUksQ0FBQzRDLFlBQ0wsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLFNBQ2pDQSxxQkFEaUJBLFNBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBO0FBQUEsa0JBeEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkF5QkE7QUFBQSxtQkE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE4QkE7QUFBQSxjQUNDckwsU0FBU0ssa0JBQWtCLGNBQzFCLHVCQUFDLFNBQUksV0FBVSxTQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVTtBQUFBLG9CQUNWLFNBQVE7QUFBQSxvQkFBVTtBQUFBO0FBQUEsc0JBRU87QUFBQSxzQkFDekIsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixpQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBaUM7QUFBQTtBQUFBO0FBQUEsa0JBTG5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNQTtBQUFBLGdCQUVBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVcscUNBQXFDOUYsVUFBVWlZLE1BQU07QUFBQSxvQkFDaEUsYUFBWTtBQUFBLG9CQUNaLHVCQUF1QjtBQUFBLG9CQUN2QjtBQUFBLG9CQUNBLE1BQUs7QUFBQSxvQkFDTCxjQUFjLENBQUNOLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsb0JBRWpDLE9BQU90UyxVQUFVTyxxQkFBcUJrUztBQUFBQSxvQkFDdEMsVUFBVSxDQUFDNU4sVUFDVCtGLGlCQUFpQixxQkFBcUIvRixLQUFLO0FBQUEsb0JBRzVDM0ksZ0JBQU11TTtBQUFBQSxzQkFBSSxDQUFDMUQsU0FDVix1QkFBQyxPQUFPLFFBQVAsRUFBNkIsT0FBT0EsS0FBS08sS0FDdkNQO0FBQUFBLDZCQUFLK0Q7QUFBQUEsd0JBQVU7QUFBQSx3QkFBRztBQUFBLHdCQUNsQi9ELEtBQUtnRSxlQUFlaEUsS0FBS2dFLGVBQWU7QUFBQSwyQkFGdkJoRSxLQUFLTyxLQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUdBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQXRCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBdUJBO0FBQUEsbUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaUNBO0FBQUEsY0FFRHRGLFNBQVNLLGtCQUFrQixXQUMxQix1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQVU7QUFBQTtBQUFBLHNCQUVJO0FBQUEsc0JBQ3RCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHFDQUFxQzlGLFVBQVVpWSxNQUFNO0FBQUEsb0JBQ2hFLGFBQVk7QUFBQSxvQkFDWix1QkFBdUI7QUFBQSxvQkFDdkI7QUFBQSxvQkFDQSxNQUFLO0FBQUEsb0JBQ0wsY0FBYyxDQUFDTixPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsU0FBUyxFQUNUQyxZQUFZLEVBQ1pDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLG9CQUVqQyxPQUFPdFMsVUFBVVMsaUJBQWlCZ1M7QUFBQUEsb0JBQ2xDLFVBQVUsQ0FBQzVOLFVBQ1QrRixpQkFBaUIsaUJBQWlCL0YsS0FBSztBQUFBLG9CQUd4QzNHLGdCQUFNdUs7QUFBQUEsc0JBQUksQ0FBQ3VLLFNBQ1YsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLEtBQUsxTixLQUN2QzBOO0FBQUFBLDZCQUFLMUo7QUFBQUEsd0JBQVU7QUFBQSx3QkFBSTBKLEtBQUtDO0FBQUFBLDJCQURQRCxLQUFLMU4sS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQSxrQkFyQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXNCQTtBQUFBLG1CQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdDQTtBQUFBLGNBRUR0RixTQUFTSyxrQkFBa0IsV0FDMUIsdUJBQUMsU0FBSSxXQUFVLFNBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxrQkFBc0I7QUFBQSxrQkFBSTtBQUFBLGtCQUFDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFBM0g7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBa0k7QUFBQSxnQkFDbEk7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsV0FBVyxxQ0FBcUM5RixVQUFVaVksTUFBTTtBQUFBLG9CQUNoRSxhQUFZO0FBQUEsb0JBQ1osdUJBQXVCO0FBQUEsb0JBQ3ZCO0FBQUEsb0JBQ0EsTUFBSztBQUFBLG9CQUNMLGNBQWMsQ0FBQ04sT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNDLFNBQVMsRUFBRUMsWUFBWSxFQUFFQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxvQkFFdkUsT0FBT3RTLFNBQVNRLFNBQVNpUztBQUFBQSxvQkFDekIsVUFBVSxDQUFDNU4sVUFBVStGLGlCQUFpQixTQUFTL0YsS0FBSztBQUFBLG9CQUVuRHpHLGlCQUFPcUs7QUFBQUEsc0JBQUksQ0FBQ2pJLFVBQ1gsdUJBQUMsT0FBTyxRQUFQLEVBQThCLE9BQU9BLE1BQU04RSxLQUN6QzlFO0FBQUFBLDhCQUFNcUk7QUFBQUEsd0JBQUs7QUFBQSx3QkFBSXJJLE1BQU11STtBQUFBQSwyQkFESnZJLE1BQU04RSxLQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQWhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBb0JBO0FBQUEsbUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdUJBO0FBQUEsY0FFRHRGLFNBQVNLLGtCQUFrQixjQUMxQix1QkFBQyxTQUFJLFdBQVUsU0FDYjtBQUFBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixTQUFRO0FBQUEsb0JBQVU7QUFBQTtBQUFBLHNCQUVPO0FBQUEsc0JBQ3pCLHVCQUFDLFVBQUssV0FBVSxpQkFBZ0IsaUJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQWlDO0FBQUE7QUFBQTtBQUFBLGtCQUxuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFFQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFXLHFDQUFxQzlGLFVBQVVpWSxNQUFNO0FBQUEsb0JBQ2hFLGFBQVk7QUFBQSxvQkFDWix1QkFBdUI7QUFBQSxvQkFDdkI7QUFBQSxvQkFDQSxNQUFLO0FBQUEsb0JBQ0wsY0FBYyxDQUFDTixPQUFPQyxXQUFXO0FBQy9CLDBCQUFJLENBQUNBLFVBQVUsQ0FBQ0EsT0FBT0MsU0FBVSxRQUFPO0FBRXhDLDZCQUFPRCxPQUFPQyxTQUNYQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsb0JBQ2pDO0FBQUEsb0JBQ0EsT0FBT3RTLFVBQVVRLFNBQVNpUztBQUFBQSxvQkFDMUIsVUFBVSxDQUFDNU4sVUFBVStGLGlCQUFpQixTQUFTL0YsS0FBSztBQUFBLG9CQUVuRGpHLG9CQUFVNko7QUFBQUEsc0JBQUksQ0FBQzRCLGFBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQWlDLE9BQU9BLFNBQVMvRSxLQUMvQytFO0FBQUFBLGlDQUFTeEI7QUFBQUEsd0JBQUs7QUFBQSx3QkFBSXdCLFNBQVN0QjtBQUFBQSwyQkFEVnNCLFNBQVMvRSxLQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBLGtCQXJCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBc0JBO0FBQUEsbUJBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0NBO0FBQUEsaUJBbEtKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBb0tBO0FBQUEsWUFFQ3RGLFNBQVNFLFlBQVkxQyxvQkFBb0IrSyxXQUFXLElBQ25ELHVCQUFDLE9BQUUsV0FBVSx3Q0FBdUMsNkJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUEsSUFDRXZJLFNBQVNFLFlBQVkxQyxvQkFBb0IrSyxXQUFXLElBRXRELHVCQUFDLFNBQ0M7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsa0RBQWlEO0FBQUE7QUFBQSxnQkFDOUMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsTUFBSztBQUFBLGtCQUNMLE9BQU92SSxVQUFVSTtBQUFBQSxrQkFDakIsSUFBRztBQUFBLGtCQUNILFVBQVVvTTtBQUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxLQUFLaFAsb0JBQW9CK0s7QUFBQUEsa0JBQ3pCLFdBQVcscUNBQXFDaE8sVUFBVWlZLE1BQU07QUFBQTtBQUFBLGdCQVRsRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTaUk7QUFBQSxjQUVoSTFVLE9BQU9zQyxpQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1Z0QyxpQkFBT3NDLGlCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUVGLHVCQUFDLE9BQUUsV0FBVSwwQ0FBeUM7QUFBQTtBQUFBLGdCQUM5QzVDLG9CQUFvQitLO0FBQUFBLGdCQUFPO0FBQUEsbUJBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxpQkF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF1QkEsSUFDRTtBQUFBLFlBRUosdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLElBQUc7QUFBQSxrQkFDSCxNQUFLO0FBQUEsa0JBQ0wsU0FBU3ZJLFVBQVVhLG1CQUFtQjtBQUFBLGtCQUN0QyxVQUFVLENBQUMrRCxNQUNUM0UsWUFBWSxDQUFDc0YsVUFBVTtBQUFBLG9CQUNyQixHQUFHQTtBQUFBQSxvQkFDSDFFLGlCQUFpQitELEVBQUVFLE9BQU9vTztBQUFBQSxrQkFDNUIsRUFBRTtBQUFBLGtCQUVKLFdBQVU7QUFBQTtBQUFBLGdCQVhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdnSDtBQUFBLGNBR2hIO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVE7QUFBQSxrQkFDUixXQUFVO0FBQUEsa0JBQStEO0FBQUE7QUFBQSxnQkFGM0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxpQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxZQUVBLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLHFDQUFDLFFBQUcsV0FBVSx5Q0FBd0MsdUJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHlDQUFDLGNBQVcsV0FBVSw0QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBOEM7QUFBQSxrQkFDOUMsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQix1Q0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU3BVLGlCQUFpQkc7QUFBQUEsb0JBQzFCLFVBQVUsTUFDUkYsb0JBQW9CLENBQUN3RyxVQUFVO0FBQUEsc0JBQzdCLEdBQUdBO0FBQUFBLHNCQUNIdEcsVUFBVSxDQUFDc0csS0FBS3RHO0FBQUFBLG9CQUNsQixFQUFFO0FBQUEsb0JBRUosV0FBVTtBQUFBO0FBQUEsa0JBVFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVNxRDtBQUFBLG1CQWhCdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFrQkE7QUFBQSxjQUNBLHVCQUFDLFNBQUksV0FBVSxxQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLHlDQUFDLFVBQU8sV0FBVSw0QkFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMEM7QUFBQSxrQkFDMUMsdUJBQUMsVUFBSyxXQUFVLGlCQUFnQixnREFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsU0FBU0gsaUJBQWlCSTtBQUFBQSxvQkFDMUIsVUFBVSxNQUNSSCxvQkFBb0IsQ0FBQ3dHLFVBQVU7QUFBQSxzQkFDN0IsR0FBR0E7QUFBQUEsc0JBQ0hyRyxhQUFhLENBQUNxRyxLQUFLckc7QUFBQUEsb0JBQ3JCLEVBQUU7QUFBQSxvQkFFSixXQUFVO0FBQUE7QUFBQSxrQkFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU3FEO0FBQUEsbUJBaEJ2RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWtCQTtBQUFBLGNBQ0EsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEseUNBQUMsVUFBTyxXQUFVLFdBQVUsZUFBWSxVQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE4QztBQUFBLGtCQUM5Qyx1QkFBQyxVQUFLLFdBQVUsaUJBQWdCLDRCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE0QztBQUFBLHFCQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUdBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVNKLGlCQUFpQkU7QUFBQUEsb0JBQzFCLFVBQVUsTUFDUkQsb0JBQW9CLENBQUN3RyxVQUFVO0FBQUEsc0JBQzdCLEdBQUdBO0FBQUFBLHNCQUNIdkcsT0FBTyxDQUFDdUcsS0FBS3ZHO0FBQUFBLG9CQUNmLEVBQUU7QUFBQSxvQkFFSixXQUFVO0FBQUE7QUFBQSxrQkFUWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBU3FEO0FBQUEsbUJBZHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBO0FBQUEsaUJBMURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMkRBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUseUJBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsVUFDRXRCLFdBQ0MwQixtQkFBbUIsYUFDakIsQ0FBQzBCLGNBQWN0RCxvQkFBb0IrSyxXQUFXO0FBQUEsZ0JBRW5ELFNBQVMwSjtBQUFBQSxnQkFDVCxXQUFXLGlGQUFpRnZVLFVBQ3hGLG1DQUNBMEIsbUJBQW1CLFdBQ2pCLGtDQUNBQSxtQkFBbUIsYUFDakIsb0NBQ0EsbUNBQW1DO0FBQUEsZ0JBRzFDMUIsb0JBQ0csa0JBQ0EwQixtQkFBbUIsV0FDakIsV0FDQUEsbUJBQW1CLGFBQ2pCLGFBQ0E7QUFBQTtBQUFBLGNBdkJWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXdCQSxLQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLGVBeHBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXlwQkE7QUFBQSxhQTlwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStwQkE7QUFBQTtBQUFBLE1BdHFCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF1cUJBO0FBQUEsSUFFQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBV3hDO0FBQUFBLFFBQ1gsU0FBUyxNQUFNO0FBQ2JDLDZCQUFtQixLQUFLO0FBQ3hCa0Isb0JBQVUsQ0FBQyxDQUFDO0FBQUEsUUFDZDtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLDJEQUNaO0FBQUEscUNBQUMsVUFBSyxXQUFVLHlFQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFzRjtBQUFBLGNBQU87QUFBQSxpQkFEL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFHQTtBQUFBLFlBR0NqQixvQkFBb0JtTSxnQkFDbkI7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFNO0FBQUEsZ0JBQ04sYUFBWTtBQUFBLGdCQUNaLFFBQU87QUFBQSxnQkFDUCxZQUFXO0FBQUEsZ0JBQ1gsV0FBVyxNQUFNO0FBQ2ZnRCxtQ0FBaUJuUCxvQkFBb0J3SSxHQUFHO0FBQUEsZ0JBSzFDO0FBQUEsZ0JBRUN0QywyQkFDQztBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsV0FBVTtBQUFBLG9CQUVWO0FBQUEsNkNBQUMsU0FBSSxXQUFVLFdBQVUsTUFBSyxRQUFPLFFBQU8sZ0JBQWUsU0FBUSxhQUNqRSxpQ0FBQyxVQUFLLGVBQWMsU0FBUSxnQkFBZSxTQUFRLGFBQWEsR0FBRyxHQUFFLHdJQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF5TSxLQUQzTTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsc0JBQU07QUFBQTtBQUFBO0FBQUEsa0JBTlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVFBO0FBQUE7QUFBQSxjQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUF5QkEsSUFFQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE9BQU07QUFBQSxnQkFDTixhQUFZO0FBQUEsZ0JBQ1osUUFBTztBQUFBLGdCQUNQLFlBQVc7QUFBQSxnQkFDWCxXQUFXLE1BQU07QUFDZjhJLHFDQUFtQmhQLG9CQUFvQndJLEdBQUc7QUFBQSxnQkFLNUM7QUFBQSxnQkFFQ3RDLDJCQUNDO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBYSxHQUFHLEdBQUUsd0lBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQXlNLEtBRDNNO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxzQkFBTTtBQUFBO0FBQUE7QUFBQSxrQkFOUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUUE7QUFBQTtBQUFBLGNBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQXlCQTtBQUFBLGVBNURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBOERBO0FBQUEsVUFFQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVdU4sY0FDcEM7QUFBQSxtQ0FBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVU7QUFBQTtBQUFBLG9CQUVaLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBSnhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsSUFBRztBQUFBLGtCQUNILE9BQU92UCxlQUFlZDtBQUFBQSxrQkFDdEIsVUFBVXVOO0FBQUFBLGtCQUNWO0FBQUEsa0JBQ0E7QUFBQSxrQkFDQSxXQUFVO0FBQUEsa0JBRVY7QUFBQSwyQ0FBQyxZQUFPLE9BQU0sSUFBRyw0QkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBNkI7QUFBQSxvQkFDNUJ6UixPQUFPeU07QUFBQUEsc0JBQUksQ0FBQ0MsVUFDWCx1QkFBQyxZQUF1QixPQUFPQSxNQUFNcEQsS0FDbENvRCxnQkFBTU0sY0FESU4sTUFBTXBELEtBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBO0FBQUE7QUFBQSxnQkFkSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FlQTtBQUFBLGlCQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXVCQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFTO0FBQUE7QUFBQSxvQkFFUix1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUE7QUFBQTtBQUFBLGdCQUozQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLElBQUc7QUFBQSxrQkFDSCxPQUFPdEUsZUFBZWI7QUFBQUEsa0JBQ3RCLFVBQVVzTjtBQUFBQSxrQkFDVjtBQUFBLGtCQUNBO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsWUFBTyxPQUFNLElBQUcsK0JBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUEsb0JBQy9CdlIsTUFBTXVNO0FBQUFBLHNCQUFJLENBQUMxRCxTQUNWLHVCQUFDLFlBQXNCLE9BQU9BLEtBQUtPLEtBQ2hDUDtBQUFBQSw2QkFBSytEO0FBQUFBLHdCQUFVO0FBQUEsd0JBQUkvRCxLQUFLZ0U7QUFBQUEsMkJBRGRoRSxLQUFLTyxLQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUVBO0FBQUEsb0JBQ0Q7QUFBQTtBQUFBO0FBQUEsZ0JBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBZUE7QUFBQSxjQUNDeEgsT0FBT3FDLFdBQ04sdUJBQUMsT0FBRSxXQUFVLDZCQUE2QnJDLGlCQUFPcUMsV0FBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBeUQ7QUFBQSxpQkF4QjdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQWM7QUFBQTtBQUFBLG9CQUVULHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBZ0M7QUFBQTtBQUFBO0FBQUEsZ0JBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUtBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUMrUixPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU0UsWUFBWSxFQUFFQyxTQUFTTCxNQUFNSSxZQUFZLENBQUM7QUFBQSxrQkFFNUQsT0FBT3RSLGdCQUFnQlYsZ0JBQWdCbVM7QUFBQUEsa0JBQ3ZDLFVBQVUsQ0FBQzVOLFVBQVVnSCxzQkFBc0IsZ0JBQWdCaEgsS0FBSztBQUFBLGtCQUUvRCxXQUFDLFNBQVMsVUFBVSxTQUFTLEVBQUU0RDtBQUFBQSxvQkFBSSxDQUFDc0ssVUFDbkMsdUJBQUMsT0FBTyxRQUFQLEVBQXdDLE9BQU9BLE9BQzdDQSxtQkFEaUJBLE1BQU1ULFlBQVksR0FBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBaUJBO0FBQUEsaUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUJBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0MsaUNBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxXQUFVO0FBQUEsa0JBQ1YsT0FBT3RSLGVBQWVMO0FBQUFBLGtCQUN0QixVQUFVLENBQUNpRSxNQUNUM0Qsa0JBQWtCLENBQUNzRSxVQUFVO0FBQUEsb0JBQzNCLEdBQUdBO0FBQUFBLG9CQUNINUUsbUJBQW1CaUUsRUFBRUUsT0FBT0Q7QUFBQUEsa0JBQzlCLEVBQUU7QUFBQTtBQUFBLGdCQVJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVNHO0FBQUEsaUJBYkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLFlBRUEsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFlO0FBQUE7QUFBQSxvQkFFVCx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWdDO0FBQUE7QUFBQTtBQUFBLGdCQUpoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsV0FBVTtBQUFBLGtCQUNWLGFBQVk7QUFBQSxrQkFDWix1QkFBdUI7QUFBQSxrQkFDdkI7QUFBQSxrQkFDQSxNQUFLO0FBQUEsa0JBQ0wsY0FBYyxDQUFDcU4sT0FBT0MsV0FDcEJBLE9BQU9DLFNBQVNFLFlBQVksRUFBRUMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsa0JBRTVELE9BQU90UixnQkFBZ0JYLGlCQUFpQm9TO0FBQUFBLGtCQUN4QyxVQUFVLENBQUM1TixVQUFVZ0gsc0JBQXNCLGlCQUFpQmhILEtBQUs7QUFBQSxrQkFFaEU7QUFBQSxvQkFDQztBQUFBLG9CQUNBO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLG9CQUNBO0FBQUEsb0JBQ0E7QUFBQSxvQkFDQTtBQUFBLGtCQUFRLEVBQ1I0RDtBQUFBQSxvQkFBSSxDQUFDNEMsWUFDTCx1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsU0FDakNBLHFCQURpQkEsU0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkF4Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBeUJBO0FBQUEsaUJBaENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUNBO0FBQUEsWUFFQ3JLLGVBQWVYLGtCQUFrQixjQUNoQyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUM1Qyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQzZSLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTQyxTQUFTLEVBQUVDLFlBQVksRUFBRUMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsa0JBRXZFLE9BQU90UixnQkFBZ0JULHFCQUFxQmtTO0FBQUFBLGtCQUM1QyxVQUFVLENBQUM1TixVQUFVZ0gsc0JBQXNCLHFCQUFxQmhILEtBQUs7QUFBQSxrQkFFcEUzSSxnQkFBTXVNO0FBQUFBLG9CQUFJLENBQUMxRCxTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLTyxLQUN2Q1A7QUFBQUEsMkJBQUsrRDtBQUFBQSxzQkFBVTtBQUFBLHNCQUFJL0QsS0FBS2dFO0FBQUFBLHlCQURQaEUsS0FBS08sS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBaUJBO0FBQUEsaUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFHRHRFLGVBQWVYLGtCQUFrQixXQUNoQyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUMvQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQzZSLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTQyxTQUFTLEVBQUVDLFlBQVksRUFBRUMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsa0JBRXZFLE9BQU90UixlQUFlUixTQUFTaVM7QUFBQUEsa0JBQy9CLFVBQVUsQ0FBQzVOLFVBQVVnSCxzQkFBc0IsU0FBU2hILEtBQUs7QUFBQSxrQkFFeER6RyxpQkFBT3FLO0FBQUFBLG9CQUFJLENBQUNqSSxVQUNYLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNOEUsS0FDekM5RTtBQUFBQSw0QkFBTXFJO0FBQUFBLHNCQUFLO0FBQUEsc0JBQUlySSxNQUFNdUk7QUFBQUEseUJBREp2SSxNQUFNOEUsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBaUJBO0FBQUEsaUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFHRHRFLGVBQWVYLGtCQUFrQixXQUNoQyx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHFDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGdCQUMvQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdDO0FBQUEsbUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixhQUFZO0FBQUEsa0JBQ1osdUJBQXVCO0FBQUEsa0JBQ3ZCO0FBQUEsa0JBQ0EsTUFBSztBQUFBLGtCQUNMLGNBQWMsQ0FBQzZSLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTQyxTQUFTLEVBQUVDLFlBQVksRUFBRUMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsa0JBRXZFLE9BQU90UixnQkFBZ0JQLGlCQUFpQmdTO0FBQUFBLGtCQUN4QyxVQUFVLENBQUM1TixVQUFVZ0gsc0JBQXNCLGlCQUFpQmhILEtBQUs7QUFBQSxrQkFFaEUzRyxnQkFBTXVLO0FBQUFBLG9CQUFJLENBQUN1SyxTQUNWLHVCQUFDLE9BQU8sUUFBUCxFQUE2QixPQUFPQSxLQUFLMU4sS0FDdkMwTjtBQUFBQSwyQkFBSzFKO0FBQUFBLHNCQUFVO0FBQUEsc0JBQUkwSixLQUFLQztBQUFBQSx5QkFEUEQsS0FBSzFOLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRUE7QUFBQSxrQkFDRDtBQUFBO0FBQUEsZ0JBaEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWlCQTtBQUFBLGlCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNCQTtBQUFBLFlBR0R0RSxlQUFlWCxrQkFBa0IsY0FDaEMsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxxQ0FBQyxXQUFNLFdBQVUsZ0RBQStDO0FBQUE7QUFBQSxnQkFDNUMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFnQztBQUFBLG1CQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsYUFBWTtBQUFBLGtCQUNaLHVCQUF1QjtBQUFBLGtCQUN2QjtBQUFBLGtCQUNBLE1BQUs7QUFBQSxrQkFDTCxjQUFjLENBQUM2UixPQUFPQyxXQUNwQkEsT0FBT0MsU0FBU0MsU0FBUyxFQUFFQyxZQUFZLEVBQUVDLFNBQVNMLE1BQU1JLFlBQVksQ0FBQztBQUFBLGtCQUV2RSxPQUFPdFIsZ0JBQWdCUixTQUFTaVM7QUFBQUEsa0JBQ2hDLFVBQVUsQ0FBQzVOLFVBQVVnSCxzQkFBc0IsU0FBU2hILEtBQUs7QUFBQSxrQkFFeERqRyxvQkFBVTZKO0FBQUFBLG9CQUFJLENBQUNqSSxVQUNkLHVCQUFDLE9BQU8sUUFBUCxFQUE4QixPQUFPQSxNQUFNOEUsS0FDekM5RTtBQUFBQSw0QkFBTXFJO0FBQUFBLHNCQUFLO0FBQUEsc0JBQUlySSxNQUFNdUk7QUFBQUEseUJBREp2SSxNQUFNOEUsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFFQTtBQUFBLGtCQUNEO0FBQUE7QUFBQSxnQkFoQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBaUJBO0FBQUEsaUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBc0JBO0FBQUEsWUFFRix1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxNQUFLO0FBQUEsa0JBQ0wsSUFBRztBQUFBLGtCQUNILE1BQUs7QUFBQSxrQkFDTCxTQUFTdEUsZ0JBQWdCSCxtQkFBbUI7QUFBQSxrQkFDNUMsVUFBVSxDQUFDK0QsTUFDVDNELGtCQUFrQixDQUFDc0UsVUFBVTtBQUFBLG9CQUMzQixHQUFHQTtBQUFBQSxvQkFDSDFFLGlCQUFpQitELEVBQUVFLE9BQU9vTztBQUFBQSxrQkFDNUIsRUFBRTtBQUFBLGtCQUVKLFdBQVU7QUFBQTtBQUFBLGdCQVhaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVdnSDtBQUFBLGNBR2hIO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVE7QUFBQSxrQkFDUixXQUFVO0FBQUEsa0JBQStEO0FBQUE7QUFBQSxnQkFGM0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxpQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFlO0FBQUE7QUFBQSxvQkFFaEIsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBO0FBQUE7QUFBQSxnQkFKekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxPQUFPbFMsZUFBZUU7QUFBQUEsa0JBQ3RCLFVBQVV1TTtBQUFBQSxrQkFDVixJQUFHO0FBQUEsa0JBQ0g7QUFBQSxrQkFDQTtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVjtBQUFBLDJDQUFDLFlBQU8sT0FBTSxJQUFHLDZCQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE4QjtBQUFBLG9CQUM3QnpRLGlCQUNFbVcsT0FBTyxDQUFDblMsZUFBZUUsT0FBTyxDQUFDLEVBQy9CdUg7QUFBQUEsc0JBQUksQ0FBQ2UsUUFBUWIsVUFDWix1QkFBQyxZQUFtQixPQUFPYSxRQUN4QkEsb0JBRFViLE9BQWI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQTtBQUFBLGdCQWhCTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FpQkE7QUFBQSxpQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF5QkE7QUFBQSxZQUVBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMLFdBQVU7QUFBQSxnQkFFVixpQ0FBQyxVQUFLLFdBQVUsMENBQ2Q7QUFBQSx5Q0FBQyxTQUFJLFdBQVUsV0FBVSxNQUFLLFFBQU8sUUFBTyxnQkFBZSxTQUFRLGFBQ2pFLGlDQUFDLFVBQUssZUFBYyxTQUFRLGdCQUFlLFNBQVEsYUFBYSxHQUFHLEdBQUUsaUhBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtMLEtBRHBMO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFBTTtBQUFBLHFCQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQTtBQUFBLGNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUE7QUFBQSxlQXZTRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXdTQTtBQUFBLGFBeldGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwV0E7QUFBQTtBQUFBLE1BalhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWtYQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVd6TDtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkksMEJBQWdCLElBQUk7QUFBQSxRQUN0QjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLHdDQUF1QyxrREFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBRUNELGdCQUNDLHVCQUFDLFVBQUssVUFBVTJTLG1CQUFtQixXQUFVLGFBQzNDO0FBQUEsbUNBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVE7QUFBQSxrQkFDUixXQUFVO0FBQUEsa0JBQThDO0FBQUE7QUFBQSxvQkFFekMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFnQztBQUFBO0FBQUE7QUFBQSxnQkFKakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLElBQUc7QUFBQSxrQkFDSCxNQUFLO0FBQUEsa0JBQ0wsT0FBTzNSO0FBQUFBLGtCQUNQLFVBQVUsQ0FBQ3NHLE1BQU1yRyxpQkFBaUJxRyxFQUFFRSxPQUFPRCxLQUFLO0FBQUEsa0JBQ2hEO0FBQUEsa0JBQ0EsV0FBVTtBQUFBLGtCQUVWO0FBQUEsMkNBQUMsWUFBTyxPQUFNLElBQUcsbUNBQWpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQW9DO0FBQUEsb0JBSXBDLHVCQUFDLFlBQU8sT0FBTSxXQUFVLHVCQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUErQjtBQUFBLG9CQUMvQix1QkFBQyxZQUFPLE9BQU0sc0JBQXFCLGlDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUVBO0FBQUEsb0JBQ0EsdUJBQUMsWUFBTyxPQUFNLFNBQVEscUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTJCO0FBQUEsb0JBQzNCLHVCQUFDLFlBQU8sT0FBTSxVQUFTLHNCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE2QjtBQUFBO0FBQUE7QUFBQSxnQkFqQi9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWtCQTtBQUFBLGlCQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBCQTtBQUFBLFlBRUE7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUE2STtBQUFBO0FBQUEsY0FGeko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBS0E7QUFBQSxlQWxDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQW1DQTtBQUFBLGFBekNKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEyQ0E7QUFBQTtBQUFBLE1BbERGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQW1EQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVd6SDtBQUFBQSxRQUNYLFNBQVMsTUFBTTtBQUNiQyw2QkFBbUIsS0FBSztBQUN4QkUsMEJBQWdCLElBQUk7QUFBQSxRQUN0QjtBQUFBLFFBRUEsaUNBQUMsU0FBSSxXQUFVLDZCQUNiLGlDQUFDLFNBQUksV0FBVSwwQkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxpQkFDYixpQ0FBQyxTQUFJLFdBQVUscUhBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFdBQVU7QUFBQSxjQUNWLE1BQUs7QUFBQSxjQUNMLFFBQU87QUFBQSxjQUNQLFNBQVE7QUFBQSxjQUNSLGFBQWE7QUFBQSxjQUViO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGVBQWM7QUFBQSxrQkFDZCxnQkFBZTtBQUFBLGtCQUNmLEdBQUU7QUFBQTtBQUFBLGdCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUd1RztBQUFBO0FBQUEsWUFWekc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBWUEsS0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWNBLEtBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUVBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLG1DQUFrQyx3Q0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsT0FBRSxXQUFVLDhDQUE2Qyx5S0FBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUNELGdCQUNDLHVCQUFDLFNBQUksV0FBVSxpRUFDYjtBQUFBLHFDQUFDLFNBQUksV0FBVSxnQ0FDYjtBQUFBLHVDQUFDLFNBQUksV0FBVSx3Q0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRDtBQUFBLGdCQUNwRCx1QkFBQyxRQUFHLFdBQVUsdUNBQXNDLGdDQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFvRTtBQUFBLG1CQUZ0RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUscUNBQW9DLHdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RDtBQUFBLGtCQUN6RCx1QkFBQyxPQUFFLFdBQVUsNENBQ1ZBLHdCQUFjNkMsU0FBUzJJLGFBQWEsT0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFDQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUscUNBQW9DLHFCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRDtBQUFBLGtCQUN0RCx1QkFBQyxPQUFFLFdBQVUsNENBQ1Z4TCx3QkFBYzRDLFVBQVU4SSxjQUFjLE9BRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHFDQUFvQyxxQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0Q7QUFBQSxrQkFDdEQsdUJBQUMsT0FBRSxXQUFVLDRDQUNWMUwsd0JBQWM2QyxTQUFTNEksZ0JBQWdCLE9BRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBQ0EsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHFDQUFvQyxzQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdUQ7QUFBQSxrQkFDdkQsdUJBQUMsT0FBRSxXQUFVLDRDQUNWekwsd0JBQWM0RCxXQUFXLE9BRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeUJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsa0ZBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsc0NBQXFDLE1BQUssZ0JBQWUsU0FBUSxhQUM5RSxpQ0FBQyxVQUFLLFVBQVMsV0FBVSxHQUFFLG9JQUFtSSxVQUFTLGFBQXZLO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdMLEtBRGxMO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQSx1QkFBQyxPQUFFLFdBQVUsd0JBQ1g7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsaUJBQWdCLDBCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEwQztBQUFBLGtCQUFPO0FBQUEscUJBRG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU9BO0FBQUEsaUJBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeUNBO0FBQUEsWUFHRDVELGdCQUNDLHVCQUFDLFVBQUssVUFBVThTLG1CQUFtQixXQUFVLFFBQzNDLGlDQUFDLFNBQUksV0FBVSx1REFDYjtBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxTQUFTLE1BQU07QUFDYi9TLHVDQUFtQixLQUFLO0FBQ3hCRSxvQ0FBZ0IsSUFBSTtBQUFBLGtCQUN0QjtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFBNE87QUFBQTtBQUFBLGdCQU54UDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFBZ087QUFBQTtBQUFBLGdCQUY1TztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGlCQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWlCQSxLQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW1CQTtBQUFBLGVBekVKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBMkVBO0FBQUEsYUE5RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQStGQSxLQWhHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBaUdBO0FBQUE7QUFBQSxNQXhHRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUF5R0E7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXcUU7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsK0JBQXFCLEtBQUs7QUFDMUJ0RSwwQkFBZ0IsSUFBSTtBQUFBLFFBQ3RCO0FBQUEsUUFFQSxpQ0FBQyxTQUFJLFdBQVUsNkJBQ2IsaUNBQUMsU0FBSSxXQUFVLDBCQUNiO0FBQUEsaUNBQUMsU0FBSSxXQUFVLGlCQUNiLGlDQUFDLFNBQUksV0FBVSxtSEFDYjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsTUFBSztBQUFBLGNBQ0wsUUFBTztBQUFBLGNBQ1AsU0FBUTtBQUFBLGNBQ1IsYUFBYTtBQUFBLGNBRWI7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsZUFBYztBQUFBLGtCQUNkLGdCQUFlO0FBQUEsa0JBQ2YsR0FBRTtBQUFBO0FBQUEsZ0JBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBR29CO0FBQUE7QUFBQSxZQVZ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWdCQTtBQUFBLFVBRUEsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSxtQ0FBQyxRQUFHLFdBQVUsbUNBQWtDLDhDQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsWUFFQSx1QkFBQyxPQUFFLFdBQVUsOENBQTZDLHFKQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdBO0FBQUEsWUFFQ0QsZ0JBQ0MsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEscUNBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsdUNBQUMsU0FBSSxXQUFVLHVDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQW1EO0FBQUEsZ0JBQ25ELHVCQUFDLFFBQUcsV0FBVSx1Q0FBc0MsZ0NBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUtBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUseUNBQ2I7QUFBQSx1Q0FBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUscUNBQW9DLHdCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUF5RDtBQUFBLGtCQUN6RCx1QkFBQyxPQUFFLFdBQVUsNENBQ1ZBLHdCQUFjNkMsU0FBUzJJLGFBQWEsT0FEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBS0E7QUFBQSxnQkFFQSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSx5Q0FBQyxPQUFFLFdBQVUscUNBQW9DLHFCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFzRDtBQUFBLGtCQUN0RCx1QkFBQyxPQUFFLFdBQVUsNENBQ1Z4TCx3QkFBYzRDLFVBQVU4SSxjQUFjLE9BRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHFDQUFvQyxxQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBc0Q7QUFBQSxrQkFDdEQsdUJBQUMsT0FBRSxXQUFVLDRDQUNWMUwsd0JBQWM2QyxTQUFTNEksZ0JBQWdCLE9BRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsZ0JBRUEsdUJBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEseUNBQUMsT0FBRSxXQUFVLHFDQUFvQyx1QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBd0Q7QUFBQSxrQkFDeEQsdUJBQUMsT0FBRSxXQUFVLDRDQUNWekwsd0JBQWM0RCxXQUFXLE9BRDVCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUtBO0FBQUEsbUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBNEJBO0FBQUEsY0FFQSx1QkFBQyxTQUFJLFdBQVUsc0ZBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBLG9CQUNMLFNBQVE7QUFBQSxvQkFFUjtBQUFBLHNCQUFDO0FBQUE7QUFBQSx3QkFDQyxVQUFTO0FBQUEsd0JBQ1QsR0FBRTtBQUFBLHdCQUNGLFVBQVM7QUFBQTtBQUFBLHNCQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFHb0I7QUFBQTtBQUFBLGtCQVJ0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBVUE7QUFBQSxnQkFFQSx1QkFBQyxPQUFFLFdBQVUsMEJBQ1g7QUFBQSx5Q0FBQyxVQUFLLFdBQVUsaUJBQWdCLGtDQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFrRDtBQUFBLGtCQUFPO0FBQUEscUJBRDNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBR0E7QUFBQSxtQkFoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxpQkF2REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF3REE7QUFBQSxZQUdENUQsZ0JBQ0MsdUJBQUMsVUFBSyxVQUFVMkssMEJBQTBCLFdBQVUsUUFDbEQsaUNBQUMsU0FBSSxXQUFVLHVEQUNiO0FBQUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFBTTtBQUNicEcseUNBQXFCLEtBQUs7QUFDMUJ0RSxvQ0FBZ0IsSUFBSTtBQUFBLGtCQUN0QjtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFBbUo7QUFBQTtBQUFBLGdCQU4vSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FTQTtBQUFBLGNBRUE7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLFdBQVU7QUFBQSxrQkFBOEw7QUFBQTtBQUFBLGdCQUYxTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGlCQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW9CQTtBQUFBLGVBM0ZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBNkZBO0FBQUEsYUFoSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWlIQSxLQWxIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUhBO0FBQUE7QUFBQSxNQTFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUEySEE7QUFBQSxPQWg2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW0vQ0EsS0FwL0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxL0NBO0FBRUo7QUFBRXhCLEdBcDVGSUQsUUFBTTtBQUFBc1gsS0FBTnRYO0FBczVGTixlQUFlQTtBQUFPLElBQUFzWDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJTaWRlYmFyIiwiYXBpIiwiZmllbGRTaXplIiwiTW9kYWwiLCJEYXRhVGFibGUiLCJDdXN0b21BbGVydCIsIkZhV2hhdHNhcHBTcXVhcmUiLCJGYVdoYXRzYXBwIiwiRmlMaW5rIiwiU2VsZWN0IiwiRHJvcGRvd24iLCJub3RpZmljYXRpb24iLCJUb29sdGlwIiwiUG9wY29uZmlybSIsIm1lc3NhZ2UiLCJUYWciLCJJb01kTW9yZSIsIk5hdmJhciIsImZpbHRlck9wdGlvbiIsIkNpcmN1bGFyTG9hZGVyIiwiRmlNYWlsIiwiTGluayIsIkdyb3VwUmVwb3J0IiwiUmVhY3RET00iLCJDdXN0b21lckdyb3VwRW5yb2xsUHJpbnQiLCJFbnJvbGwiLCJfcyIsImdyb3VwcyIsInNldEdyb3VwcyIsInVzZXJzIiwic2V0VXNlcnMiLCJUYWJsZUVucm9sbHMiLCJzZXRUYWJsZUVucm9sbHMiLCJmaWx0ZXJlZFVzZXJzIiwic2V0RmlsdGVyZWRVc2VycyIsInNlbGVjdGVkR3JvdXAiLCJzZXRTZWxlY3RlZEdyb3VwIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwic2hvd01vZGFsVXBkYXRlIiwic2V0U2hvd01vZGFsVXBkYXRlIiwiY3VycmVudFVwZGF0ZUdyb3VwIiwic2V0Q3VycmVudFVwZGF0ZUdyb3VwIiwiYXZhaWxhYmxlVGlja2V0cyIsInNldEF2YWlsYWJsZVRpY2tldHMiLCJzaG93TW9kYWxSZW1vdmUiLCJzZXRTaG93TW9kYWxSZW1vdmUiLCJzaG93TW9kZWxPbkhvbGQiLCJzZXRTaG93TW9kZWxPbkhvbGQiLCJjdXJyZW50R3JvdXAiLCJzZXRDdXJyZW50R3JvdXAiLCJhdmFpbGFibGVUaWNrZXRzQWRkIiwic2V0QXZhaWxhYmxlVGlja2V0c0FkZCIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiaXNEYXRhVGFibGVMb2FkaW5nIiwic2V0SXNEYXRhVGFibGVMb2FkaW5nIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwiYWxsRW5yb2xsVXJsIiwic2V0QWxsRW5yb2xsVXJsIiwibGVhZHMiLCJzZXRMZWFkcyIsImFnZW50cyIsInNldEFnZW50cyIsInJlbW92YWxSZWFzb24iLCJzZXRSZW1vdmFsUmVhc29uIiwiZGF0ZSIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNwbGl0IiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwidGhpcmRQYXJ0eUVuYWJsZSIsInNldFRoaXJkUGFydHlFbmFibGUiLCJlbWFpbCIsIndoYXRzYXBwIiwicGF5bWVudExpbmsiLCJzZXRFbWFpbCIsImVucm9sbG1lbnRTdGVwIiwic2V0RW5yb2xsbWVudFN0ZXAiLCJhbGVydENvbmZpZyIsInNldEFsZXJ0Q29uZmlnIiwidmlzaWJpbGl0eSIsInR5cGUiLCJpc0V4aXN0aW5nRW5yb2xsbWVudCIsInNldElzRXhpc3RpbmdFbnJvbGxtZW50IiwiYWRtaW4iLCJzZXRBZG1pbiIsImFjdGl2ZVRhYiIsInNldEFjdGl2ZVRhYiIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJncm91cF9pZCIsInVzZXJfaWQiLCJub19vZl90aWNrZXRzIiwicmVmZXJyZWRfdHlwZSIsInBheW1lbnRfdHlwZSIsInJlZmVycmVkX2N1c3RvbWVyIiwiYWdlbnQiLCJyZWZlcnJlZF9sZWFkIiwiZW1haWxfaWQiLCJjaGl0X2Fza2luZ19tb250aCIsImNyZWF0ZWRfYnkiLCJpZ25vcmVJbmNlbnRpdmUiLCJpc1ZlcmlmaWVkIiwic2V0SXNWZXJpZmllZCIsInVwZGF0ZUZvcm1EYXRhIiwic2V0VXBkYXRlRm9ybURhdGEiLCJ0aWNrZXRzIiwiYmxvY2tlZF9yZWZlcnJhbCIsImJsb2NrZWRfcmVmZXJyYWxfdHlwZSIsImJsb2NrZWRfcmVmZXJyZWRfY3VzdG9tZXIiLCJibG9ja2VkX3JlZmVycmVkX2xlYWQiLCJibG9ja2VkX3JlZmVycmVkX2FnZW50Iiwic2VhcmNoVGV4dCIsInNldFNlYXJjaFRleHQiLCJzZWxlY3RlZEN1c3RvbWVyIiwic2V0U2VsZWN0ZWRDdXN0b21lciIsImFjdGl2YXRlTW9kZWxPcGVuIiwic2V0QWN0aXZhdGVNb2RlbE9wZW4iLCJ0b2RheSIsImN1cnJlbnRZZWFyIiwiZ2V0RnVsbFllYXIiLCJjdXJyZW50TW9udGgiLCJTdHJpbmciLCJnZXRNb250aCIsInBhZFN0YXJ0IiwiY3VycmVudFllYXJNb250aCIsImZvcm1hdERhdGUiLCJ5ZWFyIiwibW9udGgiLCJzbGljZSIsImRheSIsImdldERhdGUiLCJzZWxlY3RlZERhdGUiLCJzZXRTZWxlY3RlZERhdGUiLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsIm1vZGlmeVBheW1lbnQiLCJzZXRNb2RpZnlQYXltZW50IiwibW9kaWZ5TWluTWF4UGF5bWVudERhdGUiLCJzZXRNb2RpZnlNaW5NYXhQYXltZW50RGF0ZSIsImN1c3RvbWVyRW5yb2xsbWVudHMiLCJzZXRDdXN0b21lckVucm9sbG1lbnRzIiwiY3VzdG9tZXJQaWdteSIsInNldEN1c3RvbWVyUGlnbXkiLCJjdXN0b21lckxvYW5zIiwic2V0Q3VzdG9tZXJMb2FucyIsImN1c3RvbWVyRGV0YWlsc0xvYWRpbmciLCJzZXRDdXN0b21lckRldGFpbHNMb2FkaW5nIiwibW9udGhOYW1lcyIsIm1vbnRoVmFsdWVzIiwic2V0TW9udGhWYWx1ZXMiLCJKYW51YXJ5IiwiRmVicnVhcnkiLCJNYXJjaCIsIkFwcmlsIiwiTWF5IiwiSnVuZSIsIkp1bHkiLCJBdWd1c3QiLCJTZXB0ZW1iZXIiLCJPY3RvYmVyIiwiTm92ZW1iZXIiLCJEZWNlbWJlciIsIm9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlciIsImUiLCJ2YWx1ZSIsInRhcmdldCIsInVzZXIiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidXNlck9iaiIsIkpTT04iLCJwYXJzZSIsImFkbWluSWQiLCJfaWQiLCJwcmV2IiwiZmV0Y2hHcm91cHMiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJlcnJvciIsImNvbnNvbGUiLCJmZXRjaEN1c3RvbWVyRW5yb2xsbWVudHMiLCJ1c2VySWQiLCJyZXMiLCJlcnIiLCJmZXRjaEN1c3RvbWVyUGlnbXkiLCJmZXRjaEN1c3RvbWVyTG9hbnMiLCJwYXJzZURhdGUiLCJkYXRlU3RyaW5nIiwicGFyc2VJbnQiLCJtb250aE5hbWUiLCJmb3JtYXRUb1llYXJNb250aCIsImdldE1vbnRoRGF0ZVJhbmdlIiwic3RhcnREYXRlIiwiZW5kRGF0ZSIsImZyb21fZGF0ZSIsInRvX2RhdGUiLCJoYW5kbGVBY3RpdmF0ZU1vZGVsT3BlbiIsImdyb3VwSWQiLCJoYW5kbGVQcmludCIsImVucm9sbElkIiwiZW5yb2xsbWVudCIsInByaW50V2luZG93Iiwid2luZG93Iiwib3BlbiIsImRvY3VtZW50Iiwid3JpdGUiLCJlbnJvbGxfY29kZSIsImNsb3NlIiwiZm9jdXMiLCJyb290IiwiY3JlYXRlUm9vdCIsImdldEVsZW1lbnRCeUlkIiwicmVuZGVyIiwic2V0VGltZW91dCIsInByaW50IiwiaGFuZGxlQWN0aXZhdGVFbnJvbGxtZW50IiwicHJldmVudERlZmF1bHQiLCJwdXQiLCJjdXN0b21lcl9zdGF0dXMiLCJmZXRjaEFsbEVucm9sbG1lbnREYXRhIiwidXJsIiwibGVuZ3RoIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsImdyb3VwIiwiaW5kZXgiLCJpZCIsIm5hbWUiLCJmdWxsX25hbWUiLCJwaG9uZV9udW1iZXIiLCJncm91cF9uYW1lIiwidW5saW5rX2JyYW5jaCIsImVucm9sbG1lbnRfZGF0ZSIsImNyZWF0ZWRBdCIsImlnbm9yZV9pbmNlbnRpdmUiLCJyZWZlcnJlZF9ieSIsImxlYWRfbmFtZSIsImFnZW50X251bWJlciIsInRpY2tldCIsImFjdGlvbiIsIml0ZW1zIiwia2V5IiwibGFiZWwiLCJoYW5kbGVVcGRhdGVNb2RhbE9wZW4iLCJoYW5kbGVSZW1vdmVNb2RhbE9wZW4iLCJoYW5kbGVPbkhvbGRNb2RlbE9wZW4iLCJmaWx0ZXIiLCJCb29sZWFuIiwiZmV0Y2hVc2VycyIsImZldGNoQWdlbnRzIiwiZmV0Y2hFbXBsb3llZXMiLCJlbXBsb3llZSIsImZldGNoTGVhZHMiLCJhZG1pbkFjY2Vzc1Blcm1pc3Npb25zIiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiYWNjZXNzX3Blcm1pc3Npb25zIiwiZWRpdF9wYXltZW50IiwiZWRpdF9saW1pdGVkX3BheW1lbnQiLCJoYW5kbGVBbnREU2VsZWN0IiwiZmllbGQiLCJwcmV2RGF0YSIsInByZXZFcnJvcnMiLCJwb3N0IiwiUHJvbWlzZSIsImFsbCIsInNlbGVjdGVkVXNlciIsImZpbmQiLCJyZWZUeXBlIiwicmVmZXJyYWxfdHlwZSIsInJlZmVycmVkX2VtcGxveWVlIiwicmVmZXJyZWRfYWdlbnQiLCJzZXRSZWZmZXJlZFR5cGUiLCJyZWZlcnJhbEFycmF5IiwiZm91bmQiLCJyZWZlcmVlIiwiaGFuZGxlQW50SW5wdXREU2VsZWN0IiwiaGFuZGxlVW5saW5rQnJhbmNoIiwicGF0Y2giLCJzdWNjZXNzIiwiaGFuZGxlbGlua0JyYW5jaCIsImhhbmRsZUdyb3VwQ2hhbmdlIiwiaW5mbyIsImNvbHVtbnMiLCJoZWFkZXIiLCJwdXNoIiwid2lkdGgiLCJoYW5kbGVDaGFuZ2UiLCJ2YWxpZGF0ZSIsIm5ld0Vycm9ycyIsIm5vT2ZUaWNrZXRzIiwicmVnZXgiLCJ0cmltIiwidGVzdCIsImlzTmFOIiwiT2JqZWN0Iiwia2V5cyIsImhhbmRsZVN1Ym1pdCIsImlzdmFsaWQiLCJ0aWNrZXRzQ291bnQiLCJ0aWNrZXRFbnRyaWVzIiwidGlja2V0TnVtYmVyIiwidGlja2V0RW50cnkiLCJoZWFkZXJzIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJwcmV2U3RhdGUiLCJibG9ja2VkX3JlZmVycmFsX2N1c3RvbWVyIiwiYmxvY2tlZF9yZWZlcnJhbF9sZWFkIiwiYmxvY2tlZF9yZWZlcnJhbF9hZ2VudCIsImdldEN1c3RvbWVyVGlja2V0RGV0YWlscyIsImVucm9sbG1lbnRzIiwicGlnbXlMaXN0IiwibG9hbnNMaXN0IiwiZm9yRWFjaCIsImdyb3VwX3ZhbHVlIiwiZ3JvdXBfaW5zdGFsbCIsInBheWFibGUiLCJ0b3RhbF9wYXlhYmxlIiwicGFpZCIsInRvdGFsX2ludmVzdG1lbnQiLCJ0b3RhbFBhaWQiLCJ0b3RhbFBlbmFsdHkiLCJ0b3RhbF9wZW5hbHR5IiwidG90YWxMYXRlRmVlIiwidG90YWxfbGF0ZV9mZWUiLCJiYWxhbmNlIiwidG90YWxfYmFsYW5jZSIsInBpZ215IiwicGlnbWVfaWQiLCJwYXlhYmxlQW1vdW50IiwicGF5YWJsZV9hbW91bnQiLCJzdGFydF9kYXRlIiwiZHVyYXRpb24iLCJ0b3RhbF9wYWlkX2Ftb3VudCIsInBhaWRfYW1vdW50IiwibG9hbiIsImxvYW5faWQiLCJsb2FuQW1vdW50IiwibG9hbl9hbW91bnQiLCJlbmRfZGF0ZSIsImRhaWx5UGF5bWVudCIsImRhaWx5X3BheW1lbnRfYW1vdW50IiwidG90YWxfcGF5bWVudHMiLCJyZW1haW5pbmdfbG9hbiIsImhhbmRsZVJlbW92ZUdyb3VwIiwiZGVsZXRlZF9ieSIsImRlbGV0ZWRfYXQiLCJoYW5kbGVPbkhvbGRHcm91cCIsImhvbGRlZF9vbiIsInJlbW92YWxfcmVhc29uIiwiaGFuZGxlVXBkYXRlIiwicGF5bG9hZCIsInRoZW4iLCJjYXRjaCIsImhhbmRsZVZlcmlmeSIsIndhcm5pbmciLCJwYXJhbXMiLCJ1IiwiZyIsInNlbGVjdGVkQWdlbnQiLCJhIiwic2VsZWN0ZWRSZWZlcnJlZEN1c3RvbWVyIiwic2VsZWN0ZWRSZWZlcnJlZExlYWQiLCJsIiwiYWdlbnROYW1lIiwicmVmZXJyZWRDdXN0b21lck5hbWUiLCJyZWZlcnJlZExlYWROYW1lIiwicmVmZXJyZWRJbmZvUGFydHMiLCJzZWxlY3RlZEJ5IiwiZm9udFdlaWdodCIsImZvbnRTaXplIiwibWFyZ2luQm90dG9tIiwibWFyZ2luIiwiYm9yZGVyVG9wIiwiZGVzY3JpcHRpb24iLCJwYXJ0IiwiaGFuZGxlTXVsdGlTdGVwIiwiaW5wdXQiLCJvcHRpb24iLCJjaGlsZHJlbiIsInRvU3RyaW5nIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsImhlaWdodCIsInVuZGVmaW5lZCIsImRldGFpbHMiLCJpdGVtIiwidG9Mb2NhbGVTdHJpbmciLCJyZXZlcnNlIiwiam9pbiIsInBUeXBlIiwibGVhZCIsImxlYWRfcGhvbmUiLCJjaGVja2VkIiwiY29uY2F0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiRW5yb2xsLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgYXBpIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCB7IGZpZWxkU2l6ZSB9IGZyb20gXCIuLi9kYXRhL2ZpZWxkU2l6ZVwiO1xyXG5pbXBvcnQgTW9kYWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvbW9kYWxzL01vZGFsXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0IGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydFwiO1xyXG5pbXBvcnQgeyBGYVdoYXRzYXBwU3F1YXJlIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XHJcbmltcG9ydCB7IEZhV2hhdHNhcHAgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmFcIjtcclxuaW1wb3J0IHsgRmlMaW5rIH0gZnJvbSBcInJlYWN0LWljb25zL2ZpXCI7XHJcbmltcG9ydCB7IFNlbGVjdCwgRHJvcGRvd24sIG5vdGlmaWNhdGlvbiwgVG9vbHRpcCwgUG9wY29uZmlybSwgbWVzc2FnZSwgVGFnIH0gZnJvbSBcImFudGRcIjtcclxuaW1wb3J0IHsgSW9NZE1vcmUgfSBmcm9tIFwicmVhY3QtaWNvbnMvaW9cIjtcclxuaW1wb3J0IE5hdmJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL05hdmJhclwiO1xyXG5pbXBvcnQgZmlsdGVyT3B0aW9uIGZyb20gXCIuLi9oZWxwZXJzL2ZpbHRlck9wdGlvblwiO1xyXG5pbXBvcnQgQ2lyY3VsYXJMb2FkZXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbG9hZGVycy9DaXJjdWxhckxvYWRlclwiO1xyXG5pbXBvcnQgeyBGaU1haWwgfSBmcm9tIFwicmVhY3QtaWNvbnMvZmlcIjtcclxuaW1wb3J0IHsgTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBHcm91cFJlcG9ydCBmcm9tIFwiLi9Hcm91cFJlcG9ydFwiO1xyXG5pbXBvcnQgUmVhY3RET00gZnJvbSBcInJlYWN0LWRvbS9jbGllbnRcIjtcclxuaW1wb3J0IEN1c3RvbWVyR3JvdXBFbnJvbGxQcmludCBmcm9tIFwiLi4vY29tcG9uZW50cy9wcmludEZvcm1hdHMvQ3VzdG9tZXJHcm91cEVucm9sbFByaW50XCI7XHJcbmNvbnN0IEVucm9sbCA9ICgpID0+IHtcclxuICBjb25zdCBbZ3JvdXBzLCBzZXRHcm91cHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtUYWJsZUVucm9sbHMsIHNldFRhYmxlRW5yb2xsc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkVXNlcnMsIHNldEZpbHRlcmVkVXNlcnNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEdyb3VwLCBzZXRTZWxlY3RlZEdyb3VwXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudFVwZGF0ZUdyb3VwLCBzZXRDdXJyZW50VXBkYXRlR3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2F2YWlsYWJsZVRpY2tldHMsIHNldEF2YWlsYWJsZVRpY2tldHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzaG93TW9kYWxSZW1vdmUsIHNldFNob3dNb2RhbFJlbW92ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW3Nob3dNb2RlbE9uSG9sZCwgc2V0U2hvd01vZGVsT25Ib2xkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbY3VycmVudEdyb3VwLCBzZXRDdXJyZW50R3JvdXBdID0gdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW2F2YWlsYWJsZVRpY2tldHNBZGQsIHNldEF2YWlsYWJsZVRpY2tldHNBZGRdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbaXNEYXRhVGFibGVMb2FkaW5nLCBzZXRJc0RhdGFUYWJsZUxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7fSk7XHJcbiAgY29uc3QgW2FsbEVucm9sbFVybCwgc2V0QWxsRW5yb2xsVXJsXSA9IHVzZVN0YXRlKHRydWUpO1xyXG4gIGNvbnN0IFtsZWFkcywgc2V0TGVhZHNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFthZ2VudHMsIHNldEFnZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3JlbW92YWxSZWFzb24sIHNldFJlbW92YWxSZWFzb25dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zcGxpdChcIlRcIilbMF07XHJcbiAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbdGhpcmRQYXJ0eUVuYWJsZSwgc2V0VGhpcmRQYXJ0eUVuYWJsZV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBlbWFpbDogdHJ1ZSxcclxuICAgIHdoYXRzYXBwOiB0cnVlLFxyXG4gICAgcGF5bWVudExpbms6IHRydWUsXHJcbiAgfSk7XHJcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2Vucm9sbG1lbnRTdGVwLCBzZXRFbnJvbGxtZW50U3RlcF0gPSB1c2VTdGF0ZShcInZlcmlmeVwiKTtcclxuICBjb25zdCBbYWxlcnRDb25maWcsIHNldEFsZXJ0Q29uZmlnXSA9IHVzZVN0YXRlKHtcclxuICAgIHZpc2liaWxpdHk6IGZhbHNlLFxyXG4gICAgbWVzc2FnZTogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIixcclxuICAgIHR5cGU6IFwiaW5mb1wiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtpc0V4aXN0aW5nRW5yb2xsbWVudCwgc2V0SXNFeGlzdGluZ0Vucm9sbG1lbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFthZG1pbiwgc2V0QWRtaW5dID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlKCdlbnJvbGxtZW50cycpO1xyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgZ3JvdXBfaWQ6IFwiXCIsXHJcbiAgICB1c2VyX2lkOiBcIlwiLFxyXG4gICAgbm9fb2ZfdGlja2V0czogXCJcIixcclxuICAgIHJlZmVycmVkX3R5cGU6IFwiXCIsXHJcbiAgICBwYXltZW50X3R5cGU6IFwiXCIsXHJcbiAgICByZWZlcnJlZF9jdXN0b21lcjogXCJcIixcclxuICAgIGFnZW50OiBcIlwiLFxyXG4gICAgcmVmZXJyZWRfbGVhZDogXCJcIixcclxuICAgIGVtYWlsX2lkOiBcIlwiLFxyXG4gICAgY2hpdF9hc2tpbmdfbW9udGg6IFwiXCIsXHJcbiAgICBjcmVhdGVkX2J5OiBcIlwiLFxyXG4gICAgaWdub3JlSW5jZW50aXZlOiB0cnVlLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtpc1ZlcmlmaWVkLCBzZXRJc1ZlcmlmaWVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdXBkYXRlRm9ybURhdGEsIHNldFVwZGF0ZUZvcm1EYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIGdyb3VwX2lkOiBcIlwiLFxyXG4gICAgdXNlcl9pZDogXCJcIixcclxuICAgIHRpY2tldHM6IFwiXCIsXHJcbiAgICBwYXltZW50X3R5cGU6IFwiXCIsXHJcbiAgICByZWZlcnJlZF90eXBlOiBcIlwiLFxyXG4gICAgcmVmZXJyZWRfY3VzdG9tZXI6IFwiXCIsXHJcbiAgICBhZ2VudDogXCJcIixcclxuICAgIHJlZmVycmVkX2xlYWQ6IFwiXCIsXHJcbiAgICBjaGl0X2Fza2luZ19tb250aDogXCJcIixcclxuICAgIGJsb2NrZWRfcmVmZXJyYWw6IGZhbHNlLFxyXG4gICAgYmxvY2tlZF9yZWZlcnJhbF90eXBlOiBcIlwiLFxyXG4gICAgYmxvY2tlZF9yZWZlcnJlZF9jdXN0b21lcjogXCJcIixcclxuICAgIGJsb2NrZWRfcmVmZXJyZWRfbGVhZDogXCJcIixcclxuICAgIGJsb2NrZWRfcmVmZXJyZWRfYWdlbnQ6IFwiXCIsXHJcbiAgICBpZ25vcmVJbmNlbnRpdmU6IHRydWUsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVyLCBzZXRTZWxlY3RlZEN1c3RvbWVyXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbYWN0aXZhdGVNb2RlbE9wZW4sIHNldEFjdGl2YXRlTW9kZWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4gIGNvbnN0IGN1cnJlbnRZZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuICBjb25zdCBjdXJyZW50TW9udGggPSBTdHJpbmcodG9kYXkuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuICBjb25zdCBjdXJyZW50WWVhck1vbnRoID0gYCR7Y3VycmVudFllYXJ9LSR7Y3VycmVudE1vbnRofWA7XHJcbiAgZnVuY3Rpb24gZm9ybWF0RGF0ZShkYXRlKSB7XHJcbiAgICBjb25zdCB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpO1xyXG4gICAgY29uc3QgbW9udGggPSBgMCR7ZGF0ZS5nZXRNb250aCgpICsgMX1gLnNsaWNlKC0yKTtcclxuICAgIGNvbnN0IGRheSA9IGAwJHtkYXRlLmdldERhdGUoKX1gLnNsaWNlKC0yKTtcclxuICAgIHJldHVybiBgJHt5ZWFyfS0ke21vbnRofS0ke2RheX1gO1xyXG4gIH1cclxuXHJcbiAgY29uc3QgW3NlbGVjdGVkRGF0ZSwgc2V0U2VsZWN0ZWREYXRlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtyZWxvYWRUcmlnZ2VyLCBzZXRSZWxvYWRUcmlnZ2VyXSA9IHVzZVN0YXRlKDApO1xyXG4gIGNvbnN0IFttb2RpZnlQYXltZW50LCBzZXRNb2RpZnlQYXltZW50XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbW9kaWZ5TWluTWF4UGF5bWVudERhdGUsIHNldE1vZGlmeU1pbk1heFBheW1lbnREYXRlXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG5cclxuICBjb25zdCBbY3VzdG9tZXJFbnJvbGxtZW50cywgc2V0Q3VzdG9tZXJFbnJvbGxtZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2N1c3RvbWVyUGlnbXksIHNldEN1c3RvbWVyUGlnbXldID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtjdXN0b21lckxvYW5zLCBzZXRDdXN0b21lckxvYW5zXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbY3VzdG9tZXJEZXRhaWxzTG9hZGluZywgc2V0Q3VzdG9tZXJEZXRhaWxzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IG1vbnRoTmFtZXMgPSBbXHJcbiAgICBcIkphbnVhcnlcIixcclxuICAgIFwiRmVicnVhcnlcIixcclxuICAgIFwiTWFyY2hcIixcclxuICAgIFwiQXByaWxcIixcclxuICAgIFwiTWF5XCIsXHJcbiAgICBcIkp1bmVcIixcclxuICAgIFwiSnVseVwiLFxyXG4gICAgXCJBdWd1c3RcIixcclxuICAgIFwiU2VwdGVtYmVyXCIsXHJcbiAgICBcIk9jdG9iZXJcIixcclxuICAgIFwiTm92ZW1iZXJcIixcclxuICAgIFwiRGVjZW1iZXJcIixcclxuICBdO1xyXG5cclxuICBjb25zdCBbbW9udGhWYWx1ZXMsIHNldE1vbnRoVmFsdWVzXSA9IHVzZVN0YXRlKHtcclxuICAgIEphbnVhcnk6IDAsXHJcbiAgICBGZWJydWFyeTogMCxcclxuICAgIE1hcmNoOiAwLFxyXG4gICAgQXByaWw6IDAsXHJcbiAgICBNYXk6IDAsXHJcbiAgICBKdW5lOiAwLFxyXG4gICAgSnVseTogMCxcclxuICAgIEF1Z3VzdDogMCxcclxuICAgIFNlcHRlbWJlcjogMCxcclxuICAgIE9jdG9iZXI6IDAsXHJcbiAgICBOb3ZlbWJlcjogMCxcclxuICAgIERlY2VtYmVyOiAwLFxyXG4gIH0pO1xyXG5cclxuXHJcbiAgY29uc3Qgb25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbiAgfTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG4gICAgY29uc3QgYWRtaW5JZCA9IHVzZXJPYmo/Ll9pZDtcclxuICAgIGlmIChhZG1pbklkKSB7XHJcbiAgICAgIHNldEFkbWluKHVzZXJPYmouX2lkKTtcclxuXHJcbiAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBjcmVhdGVkX2J5OiBhZG1pbklkIH0pKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEFkbWluKFwiXCIpO1xyXG4gICAgfVxyXG4gIH0sIFtdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hHcm91cHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2dyb3VwL2dldC1ncm91cC1hZG1pblwiKTtcclxuXHJcbiAgICAgICAgc2V0R3JvdXBzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBncm91cCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEdyb3VwcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hDdXN0b21lckVucm9sbG1lbnRzID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChgL3YxL2FkbWluL2Vucm9sbHMvdXNlcnMvJHt1c2VySWR9YCk7XHJcbiAgICAgIHNldEN1c3RvbWVyRW5yb2xsbWVudHMocmVzLmRhdGE/LmRhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggY3VzdG9tZXIgZW5yb2xsbWVudHNcIiwgZXJyKTtcclxuICAgICAgc2V0Q3VzdG9tZXJFbnJvbGxtZW50cyhbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZmV0Y2hDdXN0b21lclBpZ215ID0gYXN5bmMgKHVzZXJJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChgL3YxL2FkbWluL3BpZ21lcy9nZXQtcGlnbWUtY3VzdG9tZXItZGV0YWlscy8ke3VzZXJJZH1gKTtcclxuICAgICAgc2V0Q3VzdG9tZXJQaWdteShyZXMuZGF0YT8uZGF0YSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBmZXRjaCBjdXN0b21lciBwaWdteVwiLCBlcnIpO1xyXG4gICAgICBzZXRDdXN0b21lclBpZ215KFtdKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBmZXRjaEN1c3RvbWVyTG9hbnMgPSBhc3luYyAodXNlcklkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KGAvdjEvYWRtaW4vbG9hbnMvZ2V0LWJvcnJvd2VyLWRldGFpbHMvJHt1c2VySWR9YCk7XHJcbiAgICAgIHNldEN1c3RvbWVyTG9hbnMocmVzLmRhdGE/LmRhdGEpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggY3VzdG9tZXIgbG9hbnNcIiwgZXJyKTtcclxuICAgICAgc2V0Q3VzdG9tZXJMb2FucyhbXSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgcGFyc2VEYXRlID0gKGRhdGVTdHJpbmcpID0+IHtcclxuICAgIGNvbnN0IFt5ZWFyLCBtb250aF0gPSBkYXRlU3RyaW5nLnNwbGl0KFwiLVwiKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHllYXIsXHJcbiAgICAgIG1vbnRoOiBTdHJpbmcocGFyc2VJbnQobW9udGgpKS5wYWRTdGFydCgyLCBcIjBcIiksXHJcbiAgICAgIG1vbnRoTmFtZTogbW9udGhOYW1lc1twYXJzZUludChtb250aCkgLSAxXSxcclxuICAgIH07XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZm9ybWF0VG9ZZWFyTW9udGggPSAoeWVhciwgbW9udGgpID0+IHtcclxuICAgIHJldHVybiBgJHt5ZWFyfS0ke1N0cmluZyhtb250aCkucGFkU3RhcnQoMiwgXCIwXCIpfWA7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0TW9udGhEYXRlUmFuZ2UgPSAoZGF0ZVN0cmluZykgPT4ge1xyXG4gICAgY29uc3QgeyB5ZWFyLCBtb250aCB9ID0gcGFyc2VEYXRlKGRhdGVTdHJpbmcpO1xyXG4gICAgY29uc3Qgc3RhcnREYXRlID0gbmV3IERhdGUoeWVhciwgcGFyc2VJbnQobW9udGgpIC0gMSwgMSk7XHJcbiAgICBjb25zdCBlbmREYXRlID0gbmV3IERhdGUoeWVhciwgcGFyc2VJbnQobW9udGgpLCAwKTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBmcm9tX2RhdGU6IGZvcm1hdERhdGUoc3RhcnREYXRlKSxcclxuICAgICAgdG9fZGF0ZTogZm9ybWF0RGF0ZShlbmREYXRlKSxcclxuICAgIH07XHJcbiAgfTtcclxuICBjb25zdCBoYW5kbGVBY3RpdmF0ZU1vZGVsT3BlbiA9IGFzeW5jIChncm91cElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9lbnJvbGwvZ2V0LWVucm9sbC1ieS1pZC8ke2dyb3VwSWR9YCk7XHJcbiAgICAgIHNldEN1cnJlbnRHcm91cChyZXNwb25zZS5kYXRhKTtcclxuICAgICAgc2V0QWN0aXZhdGVNb2RlbE9wZW4odHJ1ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgb24gaG9sZCBlbnJvbGxtZW50XCIpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgaGFuZGxlUHJpbnQgPSBhc3luYyAoZW5yb2xsSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChgL3YxL2FkbWluL2Vucm9sbHMvZW5yb2xsLXVzZXItcHJpbnQvJHtlbnJvbGxJZH1gKTtcclxuICAgICAgY29uc3QgZW5yb2xsbWVudCA9IHJlc3BvbnNlLmRhdGE/LmRhdGE/LmVucm9sbG1lbnQ7XHJcblxyXG4gICAgICBjb25zdCBwcmludFdpbmRvdyA9IHdpbmRvdy5vcGVuKFwiXCIsIFwiX2JsYW5rXCIsIFwid2lkdGg9OTAwLGhlaWdodD03NTBcIik7XHJcbiAgICAgIGlmICghcHJpbnRXaW5kb3cpIHtcclxuICAgICAgICBtZXNzYWdlLmVycm9yKFwiUGxlYXNlIGFsbG93IHBvcC11cHMgdG8gcHJpbnQgdGhlIGVucm9sbG1lbnQgZGV0YWlscy5cIik7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBwcmludFdpbmRvdy5kb2N1bWVudC53cml0ZShcclxuICAgICAgICBgPCFET0NUWVBFIGh0bWw+XHJcbiAgICAgICAgICA8aHRtbD5cclxuICAgICAgICAgICAgPGhlYWQ+XHJcbiAgICAgICAgICAgICAgPHRpdGxlPkVucm9sbG1lbnQgUmVjZWlwdCAtICR7ZW5yb2xsbWVudD8uZW5yb2xsX2NvZGUgfHwgXCJFbnJvbGxtZW50XCJ9PC90aXRsZT5cclxuICAgICAgICAgICAgPC9oZWFkPlxyXG4gICAgICAgICAgICA8Ym9keT5cclxuICAgICAgICAgICAgICA8ZGl2IGlkPVwiZW5yb2xsbWVudC1wcmludC1yb290XCI+PC9kaXY+XHJcbiAgICAgICAgICAgIDwvYm9keT5cclxuICAgICAgICAgIDwvaHRtbD5gXHJcbiAgICAgICk7XHJcbiAgICAgIHByaW50V2luZG93LmRvY3VtZW50LmNsb3NlKCk7XHJcbiAgICAgIHByaW50V2luZG93LmZvY3VzKCk7XHJcblxyXG4gICAgICBjb25zdCByb290ID0gUmVhY3RET00uY3JlYXRlUm9vdChcclxuICAgICAgICBwcmludFdpbmRvdy5kb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImVucm9sbG1lbnQtcHJpbnQtcm9vdFwiKVxyXG4gICAgICApO1xyXG4gICAgICByb290LnJlbmRlcig8Q3VzdG9tZXJHcm91cEVucm9sbFByaW50IGVucm9sbG1lbnQ9e2Vucm9sbG1lbnR9IC8+KTtcclxuXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIHByaW50V2luZG93LmZvY3VzKCk7XHJcbiAgICAgICAgcHJpbnRXaW5kb3cucHJpbnQoKTtcclxuICAgICAgfSwgODAwKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBwcmludGluZyBlbnJvbGxtZW50OlwiLCBlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBlbnJvbGxtZW50IGRldGFpbHMgZm9yIHByaW50aW5nLlwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVBY3RpdmF0ZUVucm9sbG1lbnQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgaWYgKGN1cnJlbnRHcm91cCkge1xyXG4gICAgICBjb25zdCB1c2VyX2lkID0gY3VycmVudEdyb3VwLnVzZXJfaWQ/Ll9pZDtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBhcGkucHV0KGAvdjEvYWRtaW4vZW5yb2xscy9hY3RpdmF0ZS8ke2N1cnJlbnRHcm91cD8uX2lkfWAsIHtcclxuICAgICAgICAgIHVzZXJfaWQsXHJcbiAgICAgICAgICBjdXN0b21lcl9zdGF0dXM6IFwiQWN0aXZhdGVcIixcclxuICAgICAgICB9KVxyXG4gICAgICAgIHNldEFjdGl2YXRlTW9kZWxPcGVuKFwiXCIpXHJcbiAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkVucm9sbCBob2xkZWQgc3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGRlbGV0aW5nIGdyb3VwOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgYXN5bmMgZnVuY3Rpb24gZmV0Y2hBbGxFbnJvbGxtZW50RGF0YSgpIHtcclxuICAgICAgc2V0QWxsRW5yb2xsVXJsKHRydWUpO1xyXG4gICAgICBsZXQgdXJsID0gYC9lbnJvbGwtcmVwb3J0L2dldC1lbnJvbGwtcmVwb3J0P2Zyb21fZGF0ZT0ke2RhdGV9JnRvX2RhdGU9JHtkYXRlfWA7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0VGFibGVFbnJvbGxzKFtdKTtcclxuICAgICAgICBzZXRJc0RhdGFUYWJsZUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KHVybCk7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChncm91cCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFncm91cD8uZ3JvdXBfaWQgfHwgIWdyb3VwPy51c2VyX2lkKSByZXR1cm4ge307XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBncm91cD8uX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgbmFtZTogZ3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZSxcclxuICAgICAgICAgICAgICBwaG9uZV9udW1iZXI6IGdyb3VwPy51c2VyX2lkPy5waG9uZV9udW1iZXIsXHJcbiAgICAgICAgICAgICAgZ3JvdXBfbmFtZTogZ3JvdXA/Lmdyb3VwX2lkPy5ncm91cF9uYW1lLFxyXG4gICAgICAgICAgICAgIHVubGlua19icmFuY2g6IGdyb3VwPy51bmxpbmtfYnJhbmNoLFxyXG4gICAgICAgICAgICAgIHBheW1lbnRfdHlwZTogZ3JvdXA/LnBheW1lbnRfdHlwZSxcclxuICAgICAgICAgICAgICBlbnJvbGxtZW50X2RhdGU6IGdyb3VwPy5jcmVhdGVkQXRcclxuICAgICAgICAgICAgICAgID8gZ3JvdXA/LmNyZWF0ZWRBdD8uc3BsaXQoXCJUXCIpWzBdXHJcbiAgICAgICAgICAgICAgICA6IFwiXCIsXHJcbiAgICAgICAgICAgICAgY2hpdF9hc2tpbmdfbW9udGg6IGdyb3VwPy5jaGl0X2Fza2luZ19tb250aCxcclxuICAgICAgICAgICAgICByZWZlcnJlZF90eXBlOiBncm91cD8ucmVmZXJyZWRfdHlwZSxcclxuICAgICAgICAgICAgICBpZ25vcmVJbmNlbnRpdmU6IGdyb3VwPy5pZ25vcmVfaW5jZW50aXZlLFxyXG4gICAgICAgICAgICAgIHJlZmVycmVkX2J5OlxyXG4gICAgICAgICAgICAgICAgZ3JvdXA/LmFnZW50Py5uYW1lICYmIGdyb3VwPy5hZ2VudD8ucGhvbmVfbnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgID8gYCR7Z3JvdXAuYWdlbnQubmFtZX0gfCAke2dyb3VwLmFnZW50LnBob25lX251bWJlcn1gXHJcbiAgICAgICAgICAgICAgICAgIDogZ3JvdXA/LnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWUgJiZcclxuICAgICAgICAgICAgICAgICAgICBncm91cD8ucmVmZXJyZWRfY3VzdG9tZXI/LnBob25lX251bWJlclxyXG4gICAgICAgICAgICAgICAgICAgID8gYCR7Z3JvdXAucmVmZXJyZWRfY3VzdG9tZXIuZnVsbF9uYW1lfSB8ICR7Z3JvdXA/LnJlZmVycmVkX2N1c3RvbWVyPy5waG9uZV9udW1iZXJ9YFxyXG4gICAgICAgICAgICAgICAgICAgIDogZ3JvdXA/LnJlZmVycmVkX2xlYWQ/LmxlYWRfbmFtZSAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LnJlZmVycmVkX2xlYWQ/LmFnZW50X251bWJlclxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBgJHtncm91cC5yZWZlcnJlZF9sZWFkLmxlYWRfbmFtZX0gfCAke2dyb3VwLnJlZmVycmVkX2xlYWQuYWdlbnRfbnVtYmVyfWBcclxuICAgICAgICAgICAgICAgICAgICAgIDogXCJOL0FcIixcclxuICAgICAgICAgICAgICB0aWNrZXQ6IGdyb3VwLnRpY2tldHMsXHJcbiAgICAgICAgICAgICAgYWN0aW9uOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxEcm9wZG93blxyXG4gICAgICAgICAgICAgICAgICAgIG1lbnU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIGl0ZW1zOiBbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVkaXRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAhZ3JvdXA/LnVubGlua19icmFuY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICA/IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgIGtleTogXCI1XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICA8UG9wY29uZmlybVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIHRpdGxlPVwiVW5saW5rIEJyYW5jaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgZGVzY3JpcHRpb249XCJBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gdW5saW5rIHRoaXMgYnJhbmNoIGZyb20gdGhlIGN1c3RvbWVyP1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgb2tUZXh0PVwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICBjYW5jZWxUZXh0PVwiTm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIG9uQ29uZmlybT17KCkgPT4gaGFuZGxlVW5saW5rQnJhbmNoKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICA8VG9vbHRpcCB0aXRsZT1cIlVubGluayB0aGlzIGN1c3RvbWVyJ3MgYnJhbmNoXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgVW5saW5rIEJyYW5jaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICA8L1BvcGNvbmZpcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICA6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgIGtleTogXCI2XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICA8UG9wY29uZmlybVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIHRpdGxlPVwibGluayBCcmFuY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIGRlc2NyaXB0aW9uPVwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGxpbmsgdGhpcyBicmFuY2ggdG8gdGhlIGN1c3RvbWVyP1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgb2tUZXh0PVwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICBjYW5jZWxUZXh0PVwiTm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIG9uQ29uZmlybT17KCkgPT4gaGFuZGxlbGlua0JyYW5jaChncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgPFRvb2x0aXAgdGl0bGU9XCJsaW5rIHRoaXMgY3VzdG9tZXIncyBicmFuY2hcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICBMaW5rIEJyYW5jaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICA8L1BvcGNvbmZpcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiMlwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlbW92ZU1vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZW1vdmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwPy5jdXN0b21lcl9zdGF0dXMgPT09IFwiQWN0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCB0aXRsZT1cIkRvIHlvdSB3YW50IHRvIG1ha2UgdGhpcyBjdXN0b21lciBPbiBIb2xkP1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQb3Bjb25maXJtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlB1dCBjdXN0b21lciBPbiBIb2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uPVwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIHB1dCB0aGlzIGN1c3RvbWVyIG9uIGhvbGQ/XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rVGV4dD1cIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYW5jZWxUZXh0PVwiTm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db25maXJtPXsoKSA9PiBoYW5kbGVPbkhvbGRNb2RlbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTUwMCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPbiBIb2xkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1BvcGNvbmZpcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogZ3JvdXA/LmN1c3RvbWVyX3N0YXR1cyA9PT0gXCJPbiBIb2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiNFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUb29sdGlwIHRpdGxlPVwiRG8geW91IHdhbnQgdG8gYWN0aXZhdGUgdGhpcyBjdXN0b21lcj9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQb3Bjb25maXJtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQWN0aXZhdGUgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbj1cIkFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBhY3RpdmF0ZSB0aGlzIGN1c3RvbWVyP1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rVGV4dD1cIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhbmNlbFRleHQ9XCJOb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybT17KCkgPT4gaGFuZGxlQWN0aXZhdGVNb2RlbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFjdGl2YXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Qb3Bjb25maXJtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJwcmludFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQcmludChncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBQcmludFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgIF0uZmlsdGVyKEJvb2xlYW4pLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgPElvTWRNb3JlIGNsYXNzTmFtZT1cInRleHQtYm9sZCBjdXJzb3ItcG9pbnRlclwiIC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvRHJvcGRvd24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRUYWJsZUVucm9sbHMoZm9ybWF0dGVkRGF0YSk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHNldEZpbHRlcmVkVXNlcnMoW10pO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW5yb2xsbWVudCBkYXRhOlwiLCBlcnJvcik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICAgICAgc2V0VGFibGVFbnJvbGxzKFtdKTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBzZXRJc0RhdGFUYWJsZUxvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBmZXRjaEFsbEVucm9sbG1lbnREYXRhKCk7XHJcbiAgfSwgW3JlbG9hZFRyaWdnZXJdKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoVXNlcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgc2V0VXNlcnMocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIHVzZXIgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hVc2VycygpO1xyXG4gIH0sIFtdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hBZ2VudHMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2FnZW50L2dldFwiKTtcclxuICAgICAgICBzZXRBZ2VudHMocmVzcG9uc2UuZGF0YT8uYWdlbnQpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIExlYWRzXCIsIGVycik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEFnZW50cygpO1xyXG4gIH0sIFtdKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICAgIHNldEVtcGxveWVlcyhyZXNwb25zZT8uZGF0YT8uZW1wbG95ZWUpXHJcblxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJmYWlsZWQgdG8gZmV0Y2ggZW1wbG95ZWVzXCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgZmV0Y2hFbXBsb3llZXMoKVxyXG4gIH0sIFtdKVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaExlYWRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLmdldChcIi9sZWFkL2dldC1sZWFkXCIpO1xyXG4gICAgICAgIHNldExlYWRzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGZldGNoIExlYWRzXCIsIGVycik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaExlYWRzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlciA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclwiKTtcclxuICAgIGNvbnN0IHVzZXJPYmogPSBKU09OLnBhcnNlKHVzZXIpO1xyXG5cclxuICAgIGlmICh1c2VyT2JqKSB7XHJcbiAgICAgIGNvbnN0IGFkbWluQWNjZXNzUGVybWlzc2lvbnMgPVxyXG4gICAgICAgIHVzZXJPYmouYWRtaW5fYWNjZXNzX3JpZ2h0X2lkPy5hY2Nlc3NfcGVybWlzc2lvbnM7XHJcblxyXG4gICAgICBpZiAoYWRtaW5BY2Nlc3NQZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50ID09PSBcInRydWVcIikge1xyXG4gICAgICAgIHNldE1vZGlmeVBheW1lbnQodHJ1ZSk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmIChhZG1pbkFjY2Vzc1Blcm1pc3Npb25zPy5lZGl0X2xpbWl0ZWRfcGF5bWVudCA9PT0gXCJ0cnVlXCIpIHtcclxuICAgICAgICBzZXRNb2RpZnlQYXltZW50KHRydWUpO1xyXG4gICAgICAgIHNldE1vZGlmeU1pbk1heFBheW1lbnREYXRlKHRydWUpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBoYW5kbGVBbnREU2VsZWN0ID0gYXN5bmMgKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gICAgc2V0Rm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RGF0YSxcclxuICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcblxyXG4gICAgc2V0RXJyb3JzKChwcmV2RXJyb3JzKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2RXJyb3JzLFxyXG4gICAgICBbZmllbGRdOiBcIlwiLFxyXG4gICAgfSkpO1xyXG4gICAgaWYgKGZpZWxkID09PSBcImdyb3VwX2lkXCIpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KGAvZW5yb2xsL2dldC1uZXh0LXRpY2tldHMvJHt2YWx1ZX1gKTtcclxuICAgICAgICBzZXRBdmFpbGFibGVUaWNrZXRzQWRkKHJlc3BvbnNlLmRhdGEuYXZhaWxhYmxlVGlja2V0cyB8fCBbXSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIG5leHQgdGlja2V0czpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAoZmllbGQgPT09IFwidXNlcl9pZFwiKSB7XHJcbiAgICAgIHNldEN1c3RvbWVyRGV0YWlsc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIC8vIENsZWFyIHByZXZpb3VzIGRhdGFcclxuICAgICAgc2V0Q3VzdG9tZXJFbnJvbGxtZW50cyhbXSk7XHJcbiAgICAgIHNldEN1c3RvbWVyUGlnbXkoW10pO1xyXG4gICAgICBzZXRDdXN0b21lckxvYW5zKFtdKTtcclxuXHJcbiAgICAgIC8vIEZldGNoIGFsbCBkZXRhaWxzIGluIHBhcmFsbGVsXHJcbiAgICAgIGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICBmZXRjaEN1c3RvbWVyRW5yb2xsbWVudHModmFsdWUpLFxyXG4gICAgICAgIGZldGNoQ3VzdG9tZXJQaWdteSh2YWx1ZSksXHJcbiAgICAgICAgZmV0Y2hDdXN0b21lckxvYW5zKHZhbHVlKVxyXG4gICAgICBdKTtcclxuICAgICAgc2V0Q3VzdG9tZXJEZXRhaWxzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIGNvbnN0IHNlbGVjdGVkVXNlciA9IHVzZXJzLmZpbmQoKHVzZXIpID0+IHVzZXIuX2lkID09PSB2YWx1ZSk7XHJcbiAgICAgIGlmIChzZWxlY3RlZFVzZXIpIHtcclxuICAgICAgICBjb25zdCByZWZUeXBlID0gc2VsZWN0ZWRVc2VyLnJlZmVycmFsX3R5cGUgfHwgXCJTZWxmIEpvaW5pbmdcIjtcclxuICAgICAgICAvLyBVcGRhdGUgcmVmZXJyYWwgdHlwZVxyXG4gICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgIHJlZmVycmVkX3R5cGU6IHJlZlR5cGUsXHJcbiAgICAgICAgICAvLyBSZXNldCByZWZlcnJhbCBzcGVjaWZpYyBmaWVsZHNcclxuICAgICAgICAgIHJlZmVycmVkX2VtcGxveWVlOiBcIlwiLFxyXG4gICAgICAgICAgYWdlbnQ6IFwiXCIsXHJcbiAgICAgICAgICByZWZlcnJlZF9jdXN0b21lcjogXCJcIixcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIC8vIFNldCB0aGUgc3BlY2lmaWMgcmVmZXJyYWwgZmllbGQgYmFzZWQgb24gdHlwZVxyXG4gICAgICAgIGlmIChyZWZUeXBlID09PSBcIkVtcGxveWVlXCIgJiYgc2VsZWN0ZWRVc2VyLnJlZmVycmVkX2VtcGxveWVlPy5faWQpIHtcclxuICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICBhZ2VudDogc2VsZWN0ZWRVc2VyLnJlZmVycmVkX2VtcGxveWVlLl9pZCxcclxuICAgICAgICAgIH0pKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHJlZlR5cGUgPT09IFwiQWdlbnRcIiAmJiBzZWxlY3RlZFVzZXIucmVmZXJyZWRfYWdlbnQ/Ll9pZCkge1xyXG4gICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgIHJlZmVycmVkX2FnZW50OiBzZWxlY3RlZFVzZXIucmVmZXJyZWRfYWdlbnQuX2lkLFxyXG4gICAgICAgICAgfSkpO1xyXG4gICAgICAgIH0gZWxzZSBpZiAocmVmVHlwZSA9PT0gXCJDdXN0b21lclwiICYmIHNlbGVjdGVkVXNlci5yZWZlcnJlZF9jdXN0b21lcj8uX2lkKSB7XHJcbiAgICAgICAgICBzZXRGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IHNlbGVjdGVkVXNlci5yZWZlcnJlZF9jdXN0b21lci5faWQsXHJcbiAgICAgICAgICB9KSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIEZvciBcIlNlbGYgSm9pbmluZ1wiIG9yIFwiT3RoZXJzXCIsIHRoZSBzcGVjaWZpYyBmaWVsZHMgc3RheSBudWxsL2VtcHR5XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG4gIGZ1bmN0aW9uIHNldFJlZmZlcmVkVHlwZShyZWZlcnJhbEFycmF5KSB7XHJcbiAgICBjb25zdCBmb3VuZCA9IHJlZmVycmFsQXJyYXkuZmluZCgocmVmZXJlZSkgPT4gcmVmZXJlZS5kYXRhKTtcclxuICAgIHJldHVybiBmb3VuZCA/IGZvdW5kLnZhbHVlIDogbnVsbDtcclxuICB9XHJcbiAgLy8gY29uc3QgaGFuZGxlQW50SW5wdXREU2VsZWN0ID0gKGZpZWxkLCB2YWx1ZSkgPT4ge1xyXG4gIC8vICAgaWYgKGZpZWxkID09PSBcInJlZmVycmVkX3R5cGVcIiApIHtcclxuICAvLyAgICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gIC8vICAgICAgIC4uLnByZXZEYXRhLFxyXG4gIC8vICAgICAgIHJlZmVycmVkX3R5cGU6IFwiXCIsXHJcbiAgLy8gICAgICAgYmxvY2tlZF9yZWZlcnJhbDogdHJ1ZSxcclxuICAvLyAgICAgICByZWZlcnJlZF9jdXN0b21lcjogXCJcIixcclxuICAvLyAgICAgICByZWZlcnJlZF9sZWFkOiBcIlwiLFxyXG4gIC8vICAgICAgIGFnZW50OiBcIlwiLFxyXG4gIC8vICAgICAgIGJsb2NrZWRfcmVmZXJyYWxfdHlwZTogc2V0UmVmZmVyZWRUeXBlKFtcclxuICAvLyAgICAgICAgIHsgZGF0YTogcHJldkRhdGE/LnJlZmVycmVkX2N1c3RvbWVyLCB2YWx1ZTogXCJDdXN0b21lclwiIH0sXHJcbiAgLy8gICAgICAgICB7IGRhdGE6IHByZXZEYXRhPy5yZWZlcnJlZF9sZWFkLCB2YWx1ZTogXCJMZWFkXCIgfSxcclxuICAvLyAgICAgICAgIHsgZGF0YTogcHJldkRhdGE/LmFnZW50LCB2YWx1ZTogXCJBZ2VudFwiIH0sXHJcbiAgLy8gICAgICAgXSksXHJcbiAgLy8gICAgICAgYmxvY2tlZF9yZWZlcnJlZF9jdXN0b21lcjogcHJldkRhdGE/LnJlZmVycmVkX2N1c3RvbWVyPy5faWQsXHJcbiAgLy8gICAgICAgYmxvY2tlZF9yZWZlcnJlZF9sZWFkOiBwcmV2RGF0YT8ucmVmZXJyZWRfbGVhZD8uX2lkLFxyXG4gIC8vICAgICAgIGJsb2NrZWRfcmVmZXJyZWRfYWdlbnQ6IHByZXZEYXRhPy5hZ2VudD8uX2lkLFxyXG4gIC8vICAgICB9KSk7XHJcbiAgLy8gICAgIHJldHVybjtcclxuICAvLyAgIH0gZWxzZSB7XHJcbiAgLy8gICAgIHNldFVwZGF0ZUZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAvLyAgICAgICAuLi5wcmV2RGF0YSxcclxuICAvLyAgICAgICBibG9ja2VkX3JlZmVycmFsX3R5cGU6IGZhbHNlLFxyXG4gIC8vICAgICAgIGJsb2NrZWRfcmVmZXJyZWRfY3VzdG9tZXI6IFwiXCIsXHJcbiAgLy8gICAgICAgYmxvY2tlZF9yZWZlcnJlZF9sZWFkOiBcIlwiLFxyXG4gIC8vICAgICAgIGJsb2NrZWRfcmVmZXJyZWRfYWdlbnQ6IFwiXCIsXHJcbiAgLy8gICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgLy8gICAgIH0pKTtcclxuICAvLyAgIH1cclxuXHJcbiAgLy8gICBzZXRFcnJvcnMoeyAuLi5lcnJvcnMsIFtmaWVsZF06IFwiXCIgfSk7XHJcbiAgLy8gfTtcclxuXHJcblxyXG4gIGNvbnN0IGhhbmRsZUFudElucHV0RFNlbGVjdCA9IChmaWVsZCwgdmFsdWUpID0+IHtcclxuICAgIGlmIChmaWVsZCA9PT0gXCJyZWZlcnJlZF90eXBlXCIpIHtcclxuICAgICAgc2V0VXBkYXRlRm9ybURhdGEoKHByZXZEYXRhKSA9PiAoe1xyXG4gICAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICAgIHJlZmVycmVkX3R5cGU6IHZhbHVlLCAgICAgICAgICAgIC8vIOKclCBGSVhFRFxyXG4gICAgICAgIGJsb2NrZWRfcmVmZXJyYWw6IHRydWUsXHJcbiAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6IFwiXCIsXHJcbiAgICAgICAgcmVmZXJyZWRfbGVhZDogXCJcIixcclxuICAgICAgICBhZ2VudDogXCJcIixcclxuICAgICAgICBibG9ja2VkX3JlZmVycmFsX3R5cGU6IHNldFJlZmZlcmVkVHlwZShbXHJcbiAgICAgICAgICB7IGRhdGE6IHByZXZEYXRhPy5yZWZlcnJlZF9jdXN0b21lciwgdmFsdWU6IFwiQ3VzdG9tZXJcIiB9LFxyXG4gICAgICAgICAgeyBkYXRhOiBwcmV2RGF0YT8ucmVmZXJyZWRfbGVhZCwgdmFsdWU6IFwiTGVhZFwiIH0sXHJcbiAgICAgICAgICB7IGRhdGE6IHByZXZEYXRhPy5hZ2VudCwgdmFsdWU6IFwiQWdlbnRcIiB9LFxyXG4gICAgICAgIF0pLFxyXG4gICAgICAgIGJsb2NrZWRfcmVmZXJyZWRfY3VzdG9tZXI6IHByZXZEYXRhPy5yZWZlcnJlZF9jdXN0b21lcj8uX2lkLFxyXG4gICAgICAgIGJsb2NrZWRfcmVmZXJyZWRfbGVhZDogcHJldkRhdGE/LnJlZmVycmVkX2xlYWQ/Ll9pZCxcclxuICAgICAgICBibG9ja2VkX3JlZmVycmVkX2FnZW50OiBwcmV2RGF0YT8uYWdlbnQ/Ll9pZCxcclxuICAgICAgfSkpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgLy8gb3RoZXIgZmllbGRzXHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldkRhdGEpID0+ICh7XHJcbiAgICAgIC4uLnByZXZEYXRhLFxyXG4gICAgICBibG9ja2VkX3JlZmVycmFsX3R5cGU6IGZhbHNlLFxyXG4gICAgICBibG9ja2VkX3JlZmVycmVkX2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgICBibG9ja2VkX3JlZmVycmVkX2xlYWQ6IFwiXCIsXHJcbiAgICAgIGJsb2NrZWRfcmVmZXJyZWRfYWdlbnQ6IFwiXCIsXHJcbiAgICAgIFtmaWVsZF06IHZhbHVlLFxyXG4gICAgfSkpO1xyXG5cclxuICAgIHNldEVycm9ycyh7IC4uLmVycm9ycywgW2ZpZWxkXTogXCJcIiB9KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVVbmxpbmtCcmFuY2ggPSBhc3luYyAoZW5yb2xsSWQpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5wYXRjaChgL3YxL2FkbWluL2Vucm9sbHMvdW5saW5rLWJyYW5jaC8ke2Vucm9sbElkfWApO1xyXG5cclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiQnJhbmNoIHVubGlua2VkIHN1Y2Nlc3NmdWxseVwiKTtcclxuXHJcbiAgICAgIC8vIFVwZGF0ZSB0aGUgY3VycmVudFVwZGF0ZUdyb3VwIHN0YXRlIGluc3RlYWQgb2YgcmVsb2FkaW5nIHRoZSBwYWdlXHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVHcm91cCgocHJldikgPT4gKHtcclxuICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgIHVubGlua19icmFuY2g6IHRydWVcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgLy8gVXBkYXRlIHRoZSB0YWJsZSBkYXRhIHdpdGhvdXQgZnVsbCByZWxvYWRcclxuICAgICAgLy8gc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG5cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyb3IpO1xyXG4gICAgICBtZXNzYWdlLmVycm9yKFwiRmFpbGVkIHRvIHVubGluayBicmFuY2hcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlbGlua0JyYW5jaCA9IGFzeW5jIChlbnJvbGxJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgYXBpLnBhdGNoKGAvdjEvYWRtaW4vZW5yb2xscy9saW5rLWJyYW5jaC8ke2Vucm9sbElkfWApO1xyXG5cclxuICAgICAgbWVzc2FnZS5zdWNjZXNzKFwiQnJhbmNoIGxpbmtlZCBzdWNjZXNzZnVsbHlcIik7XHJcblxyXG4gICAgICAvLyBVcGRhdGUgdGhlIGN1cnJlbnRVcGRhdGVHcm91cCBzdGF0ZSBpbnN0ZWFkIG9mIHJlbG9hZGluZyB0aGUgcGFnZVxyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlR3JvdXAoKHByZXYpID0+ICh7XHJcbiAgICAgICAgLi4ucHJldixcclxuICAgICAgICB1bmxpbmtfYnJhbmNoOiBmYWxzZVxyXG4gICAgICB9KSk7XHJcblxyXG4gICAgICAvLyBVcGRhdGUgdGhlIHRhYmxlIGRhdGEgd2l0aG91dCBmdWxsIHJlbG9hZFxyXG4gICAgICAvLyBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcblxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnJvcik7XHJcbiAgICAgIG1lc3NhZ2UuZXJyb3IoXCJGYWlsZWQgdG8gbGluayBicmFuY2hcIik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlR3JvdXBDaGFuZ2UgPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgc2V0U2VsZWN0ZWRHcm91cChncm91cElkKTtcclxuXHJcbiAgICBpZiAoZ3JvdXBJZCkge1xyXG4gICAgICBsZXQgdXJsO1xyXG4gICAgICBpZiAoZ3JvdXBJZCA9PT0gXCJyZWNlbnRcIikge1xyXG4gICAgICAgIHVybCA9IGAvZW5yb2xsLXJlcG9ydC9nZXQtZGFzaGJvYXJkLWVucm9sbG1lbnRgO1xyXG4gICAgICAgIHNldEFsbEVucm9sbFVybCh0cnVlKTtcclxuICAgICAgfSBlbHNlIGlmIChncm91cElkID09PSBcInRvZGF5XCIpIHtcclxuICAgICAgICB1cmwgPSBgL2Vucm9sbC1yZXBvcnQvZ2V0LWVucm9sbC1yZXBvcnQ/ZnJvbV9kYXRlPSR7ZGF0ZX0mdG9fZGF0ZT0ke2RhdGV9YDtcclxuICAgICAgICBzZXRBbGxFbnJvbGxVcmwodHJ1ZSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdXJsID0gYC9lbnJvbGwvZ2V0LWdyb3VwLWVucm9sbC8ke2dyb3VwSWR9YDtcclxuICAgICAgICBzZXRBbGxFbnJvbGxVcmwoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgc2V0VGFibGVFbnJvbGxzKFtdKTtcclxuICAgICAgICBzZXRJc0RhdGFUYWJsZUxvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KHVybCk7XHJcbiAgICAgICAgY29uc29sZS5pbmZvKHJlc3BvbnNlLCBcImVucm9sbG1lbnRcIik7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLmRhdGEgJiYgcmVzcG9uc2UuZGF0YS5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICAgICAgY29uc3QgZm9ybWF0dGVkRGF0YSA9IHJlc3BvbnNlLmRhdGEubWFwKChncm91cCwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFncm91cD8uZ3JvdXBfaWQgfHwgIWdyb3VwPy51c2VyX2lkKSByZXR1cm4ge307XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBncm91cD8uX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgZW5yb2xsX2NvZGU6IGdyb3VwPy5lbnJvbGxfY29kZSxcclxuICAgICAgICAgICAgICBuYW1lOiBncm91cD8udXNlcl9pZD8uZnVsbF9uYW1lLFxyXG4gICAgICAgICAgICAgIHBob25lX251bWJlcjogZ3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlcixcclxuICAgICAgICAgICAgICBncm91cF9uYW1lOiBncm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUsXHJcbiAgICAgICAgICAgICAgdW5saW5rX2JyYW5jaDogZ3JvdXA/LnVubGlua19icmFuY2ggPyBcIlllc1wiIDogXCJOb1wiLFxyXG4gICAgICAgICAgICAgIHBheW1lbnRfdHlwZTogZ3JvdXA/LnBheW1lbnRfdHlwZSxcclxuICAgICAgICAgICAgICBlbnJvbGxtZW50X2RhdGU6IGdyb3VwPy5jcmVhdGVkQXQuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgICAgICAgIGNoaXRfYXNraW5nX21vbnRoOiBncm91cD8uY2hpdF9hc2tpbmdfbW9udGgsXHJcbiAgICAgICAgICAgICAgcmVmZXJyZWRfdHlwZTogZ3JvdXA/LnJlZmVycmVkX3R5cGUsXHJcbiAgICAgICAgICAgICAgaWdub3JlSW5jZW50aXZlOiBncm91cD8uaWdub3JlX2luY2VudGl2ZSxcclxuICAgICAgICAgICAgICByZWZlcnJlZF9ieTpcclxuICAgICAgICAgICAgICAgIGdyb3VwPy5hZ2VudD8ubmFtZSAmJiBncm91cD8uYWdlbnQ/LnBob25lX251bWJlclxyXG4gICAgICAgICAgICAgICAgICA/IGAke2dyb3VwLmFnZW50Lm5hbWV9IHwgJHtncm91cC5hZ2VudC5waG9uZV9udW1iZXJ9YFxyXG4gICAgICAgICAgICAgICAgICA6IGdyb3VwPy5yZWZlcnJlZF9jdXN0b21lcj8uZnVsbF9uYW1lICYmXHJcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXA/LnJlZmVycmVkX2N1c3RvbWVyPy5waG9uZV9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgICA/IGAke2dyb3VwLnJlZmVycmVkX2N1c3RvbWVyLmZ1bGxfbmFtZX0gfCAke2dyb3VwPy5yZWZlcnJlZF9jdXN0b21lcj8ucGhvbmVfbnVtYmVyfWBcclxuICAgICAgICAgICAgICAgICAgICA6IGdyb3VwPy5yZWZlcnJlZF9sZWFkPy5sZWFkX25hbWUgJiZcclxuICAgICAgICAgICAgICAgICAgICAgIGdyb3VwPy5yZWZlcnJlZF9sZWFkPy5hZ2VudF9udW1iZXJcclxuICAgICAgICAgICAgICAgICAgICAgID8gYCR7Z3JvdXAucmVmZXJyZWRfbGVhZC5sZWFkX25hbWV9IHwgJHtncm91cC5yZWZlcnJlZF9sZWFkLmFnZW50X251bWJlcn1gXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiTi9BXCIsXHJcbiAgICAgICAgICAgICAgdGlja2V0OiBncm91cC50aWNrZXRzLFxyXG4gICAgICAgICAgICAgIGFjdGlvbjogKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVVwZGF0ZU1vZGFsT3Blbihncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFZGl0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcInByaW50XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVByaW50KGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByaW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjJcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXJlZC02MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZW1vdmVNb2RhbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVtb3ZlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAhZ3JvdXA/LnVubGlua19icmFuY2hcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICA/IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgIGtleTogXCI1XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICA8UG9wY29uZmlybVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIHRpdGxlPVwiVW5saW5rIEJyYW5jaFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgZGVzY3JpcHRpb249XCJBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gdW5saW5rIHRoaXMgYnJhbmNoIGZyb20gdGhlIGN1c3RvbWVyP1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgb2tUZXh0PVwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICBjYW5jZWxUZXh0PVwiTm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIG9uQ29uZmlybT17KCkgPT4gaGFuZGxlVW5saW5rQnJhbmNoKGdyb3VwLl9pZCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICA8VG9vbHRpcCB0aXRsZT1cIlVubGluayB0aGlzIGN1c3RvbWVyJ3MgYnJhbmNoXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtYmx1ZS02MDAgY3Vyc29yLXBvaW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgICAgVW5saW5rIEJyYW5jaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICA8L1BvcGNvbmZpcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICA6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgIGtleTogXCI2XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICA8UG9wY29uZmlybVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIHRpdGxlPVwibGluayBCcmFuY2hcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIGRlc2NyaXB0aW9uPVwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGxpbmsgdGhpcyBicmFuY2ggdG8gdGhlIGN1c3RvbWVyP1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgb2tUZXh0PVwiWWVzXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICBjYW5jZWxUZXh0PVwiTm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgIG9uQ29uZmlybT17KCkgPT4gaGFuZGxlbGlua0JyYW5jaChncm91cC5faWQpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgPFRvb2x0aXAgdGl0bGU9XCJsaW5rIHRoaXMgY3VzdG9tZXIncyBicmFuY2hcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTYwMCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgICBMaW5rIEJyYW5jaFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICAgICAgPC9Ub29sdGlwPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgICAgICA8L1BvcGNvbmZpcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwPy5jdXN0b21lcl9zdGF0dXMgPT09IFwiQWN0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICA/IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VG9vbHRpcCB0aXRsZT1cIkRvIHlvdSB3YW50IHRvIG1ha2UgdGhpcyBjdXN0b21lciBPbiBIb2xkP1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQb3Bjb25maXJtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlB1dCBjdXN0b21lciBPbiBIb2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uPVwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIHB1dCB0aGlzIGN1c3RvbWVyIG9uIGhvbGQ/XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rVGV4dD1cIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYW5jZWxUZXh0PVwiTm9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25Db25maXJtPXsoKSA9PiBoYW5kbGVPbkhvbGRNb2RlbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTUwMCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBPbiBIb2xkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1BvcGNvbmZpcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogZ3JvdXA/LmN1c3RvbWVyX3N0YXR1cyA9PT0gXCJPbiBIb2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiNFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUb29sdGlwIHRpdGxlPVwiRG8geW91IHdhbnQgdG8gYWN0aXZhdGUgdGhpcyBjdXN0b21lcj9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQb3Bjb25maXJtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQWN0aXZhdGUgQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbj1cIkFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBhY3RpdmF0ZSB0aGlzIGN1c3RvbWVyP1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9rVGV4dD1cIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhbmNlbFRleHQ9XCJOb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ29uZmlybT17KCkgPT4gaGFuZGxlQWN0aXZhdGVNb2RlbE9wZW4oZ3JvdXAuX2lkKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTUwMCBjdXJzb3ItcG9pbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFjdGl2YXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Qb3Bjb25maXJtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICAgIF0uZmlsdGVyKEJvb2xlYW4pLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkIGN1cnNvci1wb2ludGVyXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIHNldFRhYmxlRW5yb2xscyhmb3JtYXR0ZWREYXRhKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RmlsdGVyZWRVc2VycyhbXSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50IGRhdGE6XCIsIGVycm9yKTtcclxuICAgICAgICBzZXRGaWx0ZXJlZFVzZXJzKFtdKTtcclxuICAgICAgICBzZXRUYWJsZUVucm9sbHMoW10pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzRGF0YVRhYmxlTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEZpbHRlcmVkVXNlcnMoW10pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGNvbHVtbnMgPSBbXHJcbiAgICB7IGtleTogXCJpZFwiLCBoZWFkZXI6IFwiU0wuIE5PXCIgfSxcclxuICAgIHsga2V5OiBcIm5hbWVcIiwgaGVhZGVyOiBcIkN1c3RvbWVyIE5hbWVcIiB9LFxyXG4gICAgeyBrZXk6IFwicGhvbmVfbnVtYmVyXCIsIGhlYWRlcjogXCJDdXN0b21lciBQaG9uZSBOdW1iZXJcIiB9LFxyXG4gIF07XHJcbiAgaWYgKGFsbEVucm9sbFVybCkge1xyXG4gICAgY29sdW1ucy5wdXNoKHsga2V5OiBcImdyb3VwX25hbWVcIiwgaGVhZGVyOiBcIkVucm9sbGVkIEdyb3VwXCIgfSk7XHJcbiAgfVxyXG4gIGNvbHVtbnMucHVzaChcclxuICAgIHsga2V5OiBcImVucm9sbF9jb2RlXCIsIGhlYWRlcjogXCJFbnJvbGwgQ29kZVwiLCB3aWR0aDogMTgwIH0sXHJcbiAgICB7IGtleTogXCJ1bmxpbmtfYnJhbmNoXCIsIGhlYWRlcjogXCJ1bmxpbmsgYnJhbmNoXCIgfSxcclxuICAgIHsga2V5OiBcInRpY2tldFwiLCBoZWFkZXI6IFwiVGlja2V0IE51bWJlclwiIH0sXHJcbiAgICAvLyB7IGtleTogXCJpZ25vcmVJbmNlbnRpdmVcIiwgaGVhZGVyOiBcImlnbm9yZUluY2VudGl2ZVwiIH0sXHJcbiAgICB7IGtleTogXCJwYXltZW50X3R5cGVcIiwgaGVhZGVyOiBcIlBheW1lbnQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJlbnJvbGxtZW50X2RhdGVcIiwgaGVhZGVyOiBcIkVucm9sbG1lbnQgRGF0ZVwiIH0sXHJcbiAgICB7IGtleTogXCJjaGl0X2Fza2luZ19tb250aFwiLCBoZWFkZXI6IFwiQ2hpdCBBc2tpbmcgTW9udGhcIiB9LFxyXG4gICAgeyBrZXk6IFwicmVmZXJyZWRfdHlwZVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgVHlwZVwiIH0sXHJcbiAgICB7IGtleTogXCJyZWZlcnJlZF9ieVwiLCBoZWFkZXI6IFwiUmVmZXJyZWQgQnlcIiB9LFxyXG4gICAgeyBrZXk6IFwiYWN0aW9uXCIsIGhlYWRlcjogXCJBY3Rpb25cIiB9XHJcbiAgKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hhbmdlID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGNvbnN0IHsgbmFtZSwgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG5cclxuICAgIHNldEZvcm1EYXRhKChwcmV2RGF0YSkgPT4gKHtcclxuICAgICAgLi4ucHJldkRhdGEsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgICBzZXRFcnJvcnMoKHByZXZFcnJvcnMpID0+ICh7IC4uLnByZXZFcnJvcnMsIFtuYW1lXTogXCJcIiB9KSk7XHJcblxyXG4gICAgaWYgKG5hbWUgPT09IFwiZ3JvdXBfaWRcIikge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXBpLnBvc3QoYC9lbnJvbGwvZ2V0LW5leHQtdGlja2V0cy8ke3ZhbHVlfWApO1xyXG4gICAgICAgIHNldEF2YWlsYWJsZVRpY2tldHNBZGQocmVzcG9uc2UuZGF0YS5hdmFpbGFibGVUaWNrZXRzIHx8IFtdKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgbmV4dCB0aWNrZXRzOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG4gIGNvbnN0IHZhbGlkYXRlID0gKHR5cGUpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG4gICAgY29uc3QgZGF0YSA9IHR5cGUgPT09IFwiYWRkRW5yb2xsbWVudFwiID8gZm9ybURhdGEgOiB1cGRhdGVGb3JtRGF0YTtcclxuICAgIGNvbnN0IG5vT2ZUaWNrZXRzID0gdHlwZSA9PT0gXCJhZGRFbnJvbGxtZW50XCIgPyBcIm5vX29mX3RpY2tldHNcIiA6IFwidGlja2V0c1wiO1xyXG4gICAgY29uc3QgcmVnZXggPSB7IGVtYWlsX2lkOiAvXlteXFxzQF0rQFteXFxzQF0rXFwuW15cXHNAXSskLyB9O1xyXG4gICAgaWYgKCFkYXRhLmdyb3VwX2lkLnRyaW0oKSkge1xyXG4gICAgICBuZXdFcnJvcnMuZ3JvdXBfaWQgPSBcIlBsZWFzZSBzZWxlY3QgYSBncm91cFwiO1xyXG4gICAgfVxyXG4gICAgaWYgKCFkYXRhLnVzZXJfaWQpIHtcclxuICAgICAgbmV3RXJyb3JzLnVzZXJfaWQgPSBcIlBsZWFzZSBzZWxlY3QgYSBjdXN0b21lclwiO1xyXG4gICAgfVxyXG4gICAgaWYgKGRhdGEuZW1haWxfaWQgJiYgIXJlZ2V4LmVtYWlsX2lkLnRlc3QoZGF0YS5lbWFpbF9pZCkpIHtcclxuICAgICAgbmV3RXJyb3JzLmVtYWlsX2lkID0gXCJJbnZhbGlkIGVtYWlsIGZvcm1hdFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChhdmFpbGFibGVUaWNrZXRzQWRkLmxlbmd0aCA+IDApIHtcclxuICAgICAgaWYgKFxyXG4gICAgICAgICFkYXRhW25vT2ZUaWNrZXRzXSB8fFxyXG4gICAgICAgIGRhdGFbbm9PZlRpY2tldHNdIDw9IDAgfHxcclxuICAgICAgICBpc05hTihkYXRhW25vT2ZUaWNrZXRzXSlcclxuICAgICAgKSB7XHJcbiAgICAgICAgbmV3RXJyb3JzW25vT2ZUaWNrZXRzXSA9IFwiUGxlYXNlIGVudGVyIG51bWJlciBvZiB0aWNrZXRzXCI7XHJcbiAgICAgIH0gZWxzZSBpZiAoZGF0YVtub09mVGlja2V0c10gPiBhdmFpbGFibGVUaWNrZXRzQWRkLmxlbmd0aCkge1xyXG4gICAgICAgIG5ld0Vycm9yc1tcclxuICAgICAgICAgIG5vT2ZUaWNrZXRzXHJcbiAgICAgICAgXSA9IGBNYXhpbXVtICR7YXZhaWxhYmxlVGlja2V0c0FkZC5sZW5ndGh9IHRpY2tldHMgYWxsb3dlZGA7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIHJldHVybiBPYmplY3Qua2V5cyhuZXdFcnJvcnMpLmxlbmd0aCA9PT0gMDtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgaXN2YWxpZCA9IHZhbGlkYXRlKFwiYWRkRW5yb2xsbWVudFwiKTtcclxuICAgIGlmIChpc3ZhbGlkKSB7XHJcbiAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICAgIGNvbnN0IHtcclxuICAgICAgICBub19vZl90aWNrZXRzLFxyXG4gICAgICAgIGdyb3VwX2lkLFxyXG4gICAgICAgIHVzZXJfaWQsXHJcbiAgICAgICAgcGF5bWVudF90eXBlLFxyXG4gICAgICAgIHJlZmVycmVkX2N1c3RvbWVyLFxyXG4gICAgICAgIHJlZmVycmVkX3R5cGUsXHJcbiAgICAgICAgaWdub3JlSW5jZW50aXZlLFxyXG4gICAgICAgIGFnZW50LFxyXG4gICAgICAgIHJlZmVycmVkX2xlYWQsXHJcbiAgICAgICAgY2hpdF9hc2tpbmdfbW9udGgsXHJcbiAgICAgICAgZW1haWxfaWQsXHJcbiAgICAgICAgY3JlYXRlZF9ieSxcclxuICAgICAgfSA9IGZvcm1EYXRhO1xyXG4gICAgICBjb25zdCB0aWNrZXRzQ291bnQgPSBwYXJzZUludChub19vZl90aWNrZXRzLCAxMCk7XHJcbiAgICAgIGNvbnN0IHRpY2tldEVudHJpZXMgPSBhdmFpbGFibGVUaWNrZXRzQWRkXHJcbiAgICAgICAgLnNsaWNlKDAsIHRpY2tldHNDb3VudClcclxuICAgICAgICAubWFwKCh0aWNrZXROdW1iZXIpID0+ICh7XHJcbiAgICAgICAgICBncm91cF9pZCxcclxuICAgICAgICAgIHVzZXJfaWQsXHJcbiAgICAgICAgICBub19vZl90aWNrZXRzLFxyXG4gICAgICAgICAgcGF5bWVudF90eXBlLFxyXG4gICAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXIsXHJcbiAgICAgICAgICBhZ2VudCxcclxuICAgICAgICAgIHJlZmVycmVkX2xlYWQsXHJcbiAgICAgICAgICByZWZlcnJlZF90eXBlLFxyXG4gICAgICAgICAgaWdub3JlX2luY2VudGl2ZTogaWdub3JlSW5jZW50aXZlLFxyXG4gICAgICAgICAgY2hpdF9hc2tpbmdfbW9udGg6IGZvcm1EYXRhLmNoaXRfYXNraW5nX21vbnRoLFxyXG4gICAgICAgICAgdGlja2V0czogdGlja2V0TnVtYmVyLFxyXG4gICAgICAgICAgZW1haWxfaWQsXHJcbiAgICAgICAgICBjcmVhdGVkX2J5LFxyXG4gICAgICAgIH0pKTtcclxuXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgZm9yIChjb25zdCB0aWNrZXRFbnRyeSBvZiB0aWNrZXRFbnRyaWVzKSB7XHJcbiAgICAgICAgICBhd2FpdCBhcGkucG9zdChcclxuICAgICAgICAgICAgXCIvZW5yb2xsL2FkZC1lbnJvbGxcIixcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIC4uLnRpY2tldEVudHJ5LFxyXG4gICAgICAgICAgICAgIC4uLnRoaXJkUGFydHlFbmFibGUsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcclxuICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICBzZXRGb3JtRGF0YSh7XHJcbiAgICAgICAgICBncm91cF9pZDogXCJcIixcclxuICAgICAgICAgIHVzZXJfaWQ6IFwiXCIsXHJcbiAgICAgICAgICBub19vZl90aWNrZXRzOiBcIlwiLFxyXG4gICAgICAgICAgcmVmZXJyZWRfdHlwZTogXCJcIixcclxuICAgICAgICAgIGlnbm9yZUluY2VudGl2ZTogdHJ1ZSxcclxuICAgICAgICAgIHBheW1lbnRfdHlwZTogXCJcIixcclxuICAgICAgICAgIHJlZmVycmVkX2N1c3RvbWVyOiBcIlwiLFxyXG4gICAgICAgICAgYWdlbnQ6IFwiXCIsXHJcbiAgICAgICAgICByZWZlcnJlZF9sZWFkOiBcIlwiLFxyXG4gICAgICAgICAgZW1haWxfaWQsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0QWxlcnRDb25maWcoe1xyXG4gICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiVXNlciBFbnJvbGxlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgIHR5cGU6IFwic3VjY2Vzc1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBlbnJvbGxpbmcgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlSW5wdXRDaGFuZ2UgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyBuYW1lLCB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldlN0YXRlKSA9PiAoe1xyXG4gICAgICAuLi5wcmV2U3RhdGUsXHJcbiAgICAgIFtuYW1lXTogdmFsdWUsXHJcbiAgICB9KSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKGVucm9sbElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9lbnJvbGwvZ2V0LWVucm9sbC1ieS1pZC8ke2Vucm9sbElkfWApO1xyXG4gICAgICBzZXRDdXJyZW50VXBkYXRlR3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFVwZGF0ZUZvcm1EYXRhKHtcclxuICAgICAgICBncm91cF9pZDogcmVzcG9uc2UuZGF0YT8uZ3JvdXBfaWQ/Ll9pZCB8fCByZXNwb25zZS5kYXRhPy5ncm91cF9pZCB8fCBcIlwiLFxyXG4gICAgICAgIHVzZXJfaWQ6IHJlc3BvbnNlLmRhdGE/LnVzZXJfaWQ/Ll9pZCB8fCByZXNwb25zZS5kYXRhPy51c2VyX2lkIHx8IFwiXCIsXHJcbiAgICAgICAgdGlja2V0czogcmVzcG9uc2UuZGF0YT8udGlja2V0cyB8fCBcIlwiLFxyXG4gICAgICAgIHBheW1lbnRfdHlwZTogcmVzcG9uc2UuZGF0YT8ucGF5bWVudF90eXBlIHx8IFwiXCIsXHJcbiAgICAgICAgcmVmZXJyZWRfdHlwZTogcmVzcG9uc2UuZGF0YT8ucmVmZXJyZWRfdHlwZSB8fCBcIlwiLFxyXG4gICAgICAgIGlnbm9yZUluY2VudGl2ZTogcmVzcG9uc2UuZGF0YT8uaWdub3JlX2luY2VudGl2ZSxcclxuICAgICAgICBhZ2VudDpcclxuICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LmFnZW50Py5faWQgfHwgcmVzcG9uc2UuZGF0YT8uYWdlbnQgfHwgXCJcIixcclxuXHJcbiAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6XHJcbiAgICAgICAgICByZXNwb25zZS5kYXRhPy5yZWZlcnJlZF9jdXN0b21lcj8uX2lkIHx8XHJcbiAgICAgICAgICByZXNwb25zZS5kYXRhPy5yZWZlcnJlZF9jdXN0b21lciB8fFxyXG4gICAgICAgICAgXCJcIixcclxuXHJcbiAgICAgICAgcmVmZXJyZWRfbGVhZDpcclxuICAgICAgICAgIHJlc3BvbnNlLmRhdGE/LnJlZmVycmVkX2xlYWQ/Ll9pZCB8fFxyXG4gICAgICAgICAgcmVzcG9uc2UuZGF0YT8ucmVmZXJyZWRfbGVhZCB8fFxyXG4gICAgICAgICAgXCJcIixcclxuXHJcbiAgICAgICAgY2hpdF9hc2tpbmdfbW9udGg6IHJlc3BvbnNlLmRhdGE/LmNoaXRfYXNraW5nX21vbnRoIHx8IFwiXCIsXHJcbiAgICAgICAgYmxvY2tlZF9yZWZlcnJhbDogcmVzcG9uc2UuZGF0YT8uYmxvY2tlZF9yZWZlcnJhbCB8fCBmYWxzZSxcclxuICAgICAgICBibG9ja2VkX3JlZmVycmFsX3R5cGU6IHJlc3BvbnNlLmRhdGE/LmJsb2NrZWRfcmVmZXJyYWxfdHlwZSB8fCBcIlwiLFxyXG4gICAgICAgIGJsb2NrZWRfcmVmZXJyYWxfY3VzdG9tZXI6XHJcbiAgICAgICAgICByZXNwb25zZS5kYXRhPy5ibG9ja2VkX3JlZmVycmFsX2N1c3RvbWVyIHx8IFwiXCIsXHJcbiAgICAgICAgYmxvY2tlZF9yZWZlcnJhbF9sZWFkOiByZXNwb25zZS5kYXRhPy5ibG9ja2VkX3JlZmVycmFsX2xlYWQgfHwgXCJcIixcclxuICAgICAgICBibG9ja2VkX3JlZmVycmFsX2FnZW50OiByZXNwb25zZS5kYXRhPy5ibG9ja2VkX3JlZmVycmFsX2FnZW50IHx8IFwiXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgICAvLyBGZXRjaCBjdXN0b21lciBkZXRhaWxzIGZvciB0aGUgdXNlciBpbiB0aGlzIGVucm9sbG1lbnRcclxuICAgICAgY29uc3QgdXNlcklkID0gcmVzcG9uc2UuZGF0YT8udXNlcl9pZD8uX2lkIHx8IHJlc3BvbnNlLmRhdGE/LnVzZXJfaWQ7XHJcbiAgICAgIGlmICh1c2VySWQpIHtcclxuICAgICAgICBzZXRDdXN0b21lckRldGFpbHNMb2FkaW5nKHRydWUpO1xyXG4gICAgICAgIGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgICAgIGZldGNoQ3VzdG9tZXJFbnJvbGxtZW50cyh1c2VySWQpLFxyXG4gICAgICAgICAgZmV0Y2hDdXN0b21lclBpZ215KHVzZXJJZCksXHJcbiAgICAgICAgICBmZXRjaEN1c3RvbWVyTG9hbnModXNlcklkKVxyXG4gICAgICAgIF0pO1xyXG4gICAgICAgIHNldEN1c3RvbWVyRGV0YWlsc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgICB9XHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGxtZW50OlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgZ2V0Q3VzdG9tZXJUaWNrZXREZXRhaWxzID0gKGVucm9sbG1lbnRzLCBwaWdteUxpc3QsIGxvYW5zTGlzdCkgPT4ge1xyXG4gICAgY29uc3QgaXRlbXMgPSBbXTtcclxuXHJcbiAgICAvLyBFbnJvbGxtZW50cyAoQ2hpdClcclxuICAgIGVucm9sbG1lbnRzPy5mb3JFYWNoKGVucm9sbG1lbnQgPT4ge1xyXG4gICAgICBjb25zdCBncm91cCA9IGVucm9sbG1lbnQuZ3JvdXBfaWQ7XHJcbiAgICAgIGNvbnN0IHRpY2tldCA9IGVucm9sbG1lbnQudGlja2V0cztcclxuICAgICAgaWYgKGdyb3VwICYmIHRpY2tldCkge1xyXG4gICAgICAgIGl0ZW1zLnB1c2goe1xyXG4gICAgICAgICAgaWQ6IGBjaGl0LSR7Z3JvdXAuX2lkfXwke3RpY2tldH1gLFxyXG4gICAgICAgICAgdHlwZTogJ2NoaXQnLFxyXG4gICAgICAgICAgbmFtZTogZ3JvdXAuZ3JvdXBfbmFtZSxcclxuICAgICAgICAgIHRpY2tldDogdGlja2V0LFxyXG4gICAgICAgICAgZ3JvdXBfdmFsdWU6IGdyb3VwLmdyb3VwX3ZhbHVlIHx8ICctJyxcclxuICAgICAgICAgIGdyb3VwX2luc3RhbGw6IGdyb3VwLmdyb3VwX2luc3RhbGwgfHwgJy0nLFxyXG4gICAgICAgICAgcGF5YWJsZTogZW5yb2xsbWVudC50b3RhbF9wYXlhYmxlIHx8IDAsXHJcbiAgICAgICAgICBwYWlkOiBlbnJvbGxtZW50LnRvdGFsX2ludmVzdG1lbnQgfHwgMCxcclxuICAgICAgICAgIHRvdGFsUGFpZDogZW5yb2xsbWVudC50b3RhbF9pbnZlc3RtZW50IHx8IDAsXHJcbiAgICAgICAgICB0b3RhbFBlbmFsdHk6IGVucm9sbG1lbnQudG90YWxfcGVuYWx0eSB8fCAwLFxyXG4gICAgICAgICAgdG90YWxMYXRlRmVlOiBlbnJvbGxtZW50LnRvdGFsX2xhdGVfZmVlIHx8IDAsXHJcbiAgICAgICAgICBiYWxhbmNlOiAoZW5yb2xsbWVudC50b3RhbF9iYWxhbmNlKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBQaWdteVxyXG4gICAgcGlnbXlMaXN0LmZvckVhY2gocGlnbXkgPT4ge1xyXG4gICAgICBpdGVtcy5wdXNoKHtcclxuICAgICAgICBpZDogYHBpZ21lLSR7cGlnbXkuX2lkfWAsXHJcbiAgICAgICAgdHlwZTogJ3BpZ215JyxcclxuICAgICAgICBuYW1lOiBwaWdteS5waWdtZV9pZCB8fCAnUGlnbXkgU2NoZW1lJyxcclxuICAgICAgICBwYXlhYmxlQW1vdW50OiBwaWdteS5wYXlhYmxlX2Ftb3VudCB8fCAwLFxyXG4gICAgICAgIHN0YXJ0RGF0ZTogcGlnbXkuc3RhcnRfZGF0ZSxcclxuICAgICAgICBkdXJhdGlvbjogcGlnbXkuZHVyYXRpb24sXHJcbiAgICAgICAgdG90YWxQYWlkOiBwaWdteS50b3RhbF9wYWlkX2Ftb3VudCB8fCAwLFxyXG4gICAgICAgIGJhbGFuY2U6IChwaWdteS5wYXlhYmxlX2Ftb3VudCB8fCAwKSAtIChwaWdteS5wYWlkX2Ftb3VudCB8fCAwKVxyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIExvYW5zXHJcbiAgICBsb2Fuc0xpc3QuZm9yRWFjaChsb2FuID0+IHtcclxuICAgICAgaXRlbXMucHVzaCh7XHJcbiAgICAgICAgaWQ6IGBsb2FuLSR7bG9hbi5faWR9YCxcclxuICAgICAgICB0eXBlOiAnbG9hbicsXHJcbiAgICAgICAgbmFtZTogbG9hbi5sb2FuX2lkIHx8ICdMb2FuJyxcclxuICAgICAgICBsb2FuQW1vdW50OiBsb2FuLmxvYW5fYW1vdW50IHx8IDAsXHJcbiAgICAgICAgc3RhcnREYXRlOiBsb2FuLnN0YXJ0X2RhdGUsXHJcbiAgICAgICAgZW5kRGF0ZTogbG9hbi5lbmRfZGF0ZSxcclxuICAgICAgICBkYWlseVBheW1lbnQ6IGxvYW4uZGFpbHlfcGF5bWVudF9hbW91bnQgfHwgMCxcclxuICAgICAgICB0b3RhbFBhaWQ6IGxvYW4udG90YWxfcGF5bWVudHMgfHwgMCxcclxuICAgICAgICBiYWxhbmNlOiAobG9hbi5yZW1haW5pbmdfbG9hbiB8fCAwKVxyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBpdGVtcztcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVSZW1vdmVNb2RhbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZW5yb2xsL2dldC1lbnJvbGwtYnktaWQvJHtncm91cElkfWApO1xyXG4gICAgICBzZXRDdXJyZW50R3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RhbFJlbW92ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbnJvbGw6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVPbkhvbGRNb2RlbE9wZW4gPSBhc3luYyAoZ3JvdXBJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KGAvZW5yb2xsL2dldC1lbnJvbGwtYnktaWQvJHtncm91cElkfWApO1xyXG4gICAgICBzZXRDdXJyZW50R3JvdXAocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RlbE9uSG9sZCh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBvbiBob2xkIGVucm9sbG1lbnRcIik7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVSZW1vdmVHcm91cCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgaWYgKGN1cnJlbnRHcm91cCkge1xyXG4gICAgICBjb25zdCB1c2VyX2lkID0gY3VycmVudEdyb3VwLnVzZXJfaWQ/Ll9pZDtcclxuICAgICAgaWYgKHVzZXJfaWQpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgYXBpLnB1dChgL2Vucm9sbC9yZW1vdmUvJHtjdXJyZW50R3JvdXA/Ll9pZH1gLCB7XHJcbiAgICAgICAgICAgIHVzZXJfaWQsXHJcbiAgICAgICAgICAgIGRlbGV0ZWRfYnk6IGFkbWluLFxyXG4gICAgICAgICAgICBkZWxldGVkX2F0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICAgICAgICByZW1vdmFsUmVhc29uLFxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBzZXRSZW1vdmFsUmVhc29uKFwiXCIpO1xyXG4gICAgICAgICAgc2V0U2hvd01vZGFsUmVtb3ZlKGZhbHNlKTtcclxuICAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgbWVzc2FnZTogXCJFbnJvbGwgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIixcclxuICAgICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgc2V0UmVtb3ZhbFJlYXNvbihcIlwiKTtcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBncm91cDpcIiwgZXJyb3IpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU9uSG9sZEdyb3VwID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGlmIChjdXJyZW50R3JvdXApIHtcclxuICAgICAgY29uc3QgdXNlcl9pZCA9IGN1cnJlbnRHcm91cD8udXNlcl9pZD8uX2lkO1xyXG4gICAgICBpZiAodXNlcl9pZCkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBhcGkucHV0KGAvdjEvYWRtaW4vZW5yb2xscy9vbi1ob2xkLyR7Y3VycmVudEdyb3VwPy5faWR9YCxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIHVzZXJfaWQsXHJcbiAgICAgICAgICAgICAgaG9sZGVkX29uOiBuZXcgRGF0ZSgpLFxyXG4gICAgICAgICAgICAgIGRlbGV0ZWRfYnk6IGFkbWluLFxyXG4gICAgICAgICAgICAgIHJlbW92YWxfcmVhc29uOiBcIk9uIEhvbGRcIixcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICAgIHNldFNob3dNb2RlbE9uSG9sZChcIlwiKTtcclxuICAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICAgICAgbWVzc2FnZTogXCJFbnJvbGwgaG9sZGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcImVycm9yIG9uIGhvbGRpbmcgZW5yb2xsbWVudHNcIilcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuICBjb25zdCBoYW5kbGVVcGRhdGUgPSBhc3luYyAoZSkgPT4ge1xyXG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgLi4udXBkYXRlRm9ybURhdGEsXHJcbiAgICAgIGlnbm9yZV9pbmNlbnRpdmU6IHVwZGF0ZUZvcm1EYXRhLmlnbm9yZUluY2VudGl2ZSxcclxuICAgIH1cclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGFwaS5wdXQoXHJcbiAgICAgICAgYC9lbnJvbGwvdXBkYXRlLWVucm9sbC8ke2N1cnJlbnRVcGRhdGVHcm91cC5faWR9YCxcclxuICAgICAgICBwYXlsb2FkLFxyXG4gICAgICApO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIkVucm9sbG1lbnQgVXBkYXRlZCBTdWNjZXNzZnVsbHlcIixcclxuICAgICAgICB0eXBlOiBcInN1Y2Nlc3NcIixcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgdXBkYXRpbmcgZW5yb2xsOlwiLCBlcnJvcik7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmIChzZWxlY3RlZEdyb3VwKSB7XHJcbiAgICAgIGFwaVxyXG4gICAgICAgIC5wb3N0KGAvZW5yb2xsL2dldC1uZXh0LXRpY2tldHMvJHtzZWxlY3RlZEdyb3VwfWApXHJcbiAgICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgICBzZXRBdmFpbGFibGVUaWNrZXRzKHJlc3BvbnNlLmRhdGEuYXZhaWxhYmxlVGlja2V0cyB8fCBbXSk7XHJcbiAgICAgICAgfSlcclxuICAgICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYXZhaWxhYmxlIHRpY2tldHM6XCIsIGVycm9yKTtcclxuICAgICAgICB9KTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNldEF2YWlsYWJsZVRpY2tldHMoW10pO1xyXG4gICAgfVxyXG4gIH0sIFtzZWxlY3RlZEdyb3VwXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVZlcmlmeSA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHtcclxuICAgICAgdXNlcl9pZCxcclxuICAgICAgZ3JvdXBfaWQsXHJcbiAgICAgIGFnZW50LFxyXG4gICAgICByZWZlcnJlZF9jdXN0b21lcixcclxuICAgICAgcmVmZXJyZWRfbGVhZCxcclxuICAgICAgcmVmZXJyZWRfdHlwZSxcclxuICAgIH0gPSBmb3JtRGF0YTtcclxuXHJcbiAgICBpZiAoIXVzZXJfaWQgfHwgIWdyb3VwX2lkKSB7XHJcbiAgICAgIG5vdGlmaWNhdGlvbi53YXJuaW5nKHtcclxuICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBzZWxlY3QgYm90aCBHcm91cCBhbmQgQ3VzdG9tZXIgYmVmb3JlIHZlcmlmeWluZy5cIixcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoYC9lbnJvbGwvZ2V0LWVucm9sbC1jaGVja2AsIHtcclxuICAgICAgICBwYXJhbXM6IHsgdXNlcl9pZCwgZ3JvdXBfaWQgfSxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCBzZWxlY3RlZFVzZXIgPSB1c2Vycy5maW5kKCh1KSA9PiB1Ll9pZCA9PT0gdXNlcl9pZCk7XHJcbiAgICAgIGNvbnN0IHNlbGVjdGVkR3JvdXAgPSBncm91cHMuZmluZCgoZykgPT4gZy5faWQgPT09IGdyb3VwX2lkKTtcclxuICAgICAgY29uc3Qgc2VsZWN0ZWRBZ2VudCA9IGFnZW50cy5maW5kKChhKSA9PiBhLl9pZCA9PT0gYWdlbnQpO1xyXG4gICAgICBjb25zdCBzZWxlY3RlZFJlZmVycmVkQ3VzdG9tZXIgPSB1c2Vycy5maW5kKFxyXG4gICAgICAgICh1KSA9PiB1Ll9pZCA9PT0gcmVmZXJyZWRfY3VzdG9tZXJcclxuICAgICAgKTtcclxuICAgICAgY29uc3Qgc2VsZWN0ZWRSZWZlcnJlZExlYWQgPSBsZWFkcz8uZmluZD8uKFxyXG4gICAgICAgIChsKSA9PiBsLl9pZCA9PT0gcmVmZXJyZWRfbGVhZFxyXG4gICAgICApO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlPy5kYXRhKSB7XHJcbiAgICAgICAgY29uc3QgYWdlbnROYW1lID1cclxuICAgICAgICAgIHR5cGVvZiByZXNwb25zZS5kYXRhLmFnZW50ID09PSBcIm9iamVjdFwiXHJcbiAgICAgICAgICAgID8gcmVzcG9uc2UuZGF0YS5hZ2VudD8ubmFtZVxyXG4gICAgICAgICAgICA6IG51bGw7XHJcbiAgICAgICAgY29uc3QgcmVmZXJyZWRDdXN0b21lck5hbWUgPVxyXG4gICAgICAgICAgdHlwZW9mIHJlc3BvbnNlLmRhdGEucmVmZXJyZWRfY3VzdG9tZXIgPT09IFwib2JqZWN0XCJcclxuICAgICAgICAgICAgPyByZXNwb25zZS5kYXRhLnJlZmVycmVkX2N1c3RvbWVyPy5mdWxsX25hbWVcclxuICAgICAgICAgICAgOiBudWxsO1xyXG4gICAgICAgIGNvbnN0IHJlZmVycmVkTGVhZE5hbWUgPVxyXG4gICAgICAgICAgdHlwZW9mIHJlc3BvbnNlLmRhdGEucmVmZXJyZWRfbGVhZCA9PT0gXCJvYmplY3RcIlxyXG4gICAgICAgICAgICA/IHJlc3BvbnNlLmRhdGEucmVmZXJyZWRfbGVhZD8ubGVhZF9uYW1lXHJcbiAgICAgICAgICAgIDogbnVsbDtcclxuXHJcbiAgICAgICAgY29uc3QgcmVmZXJyZWRJbmZvUGFydHMgPSBbXTtcclxuXHJcbiAgICAgICAgaWYgKGFnZW50TmFtZSlcclxuICAgICAgICAgIHJlZmVycmVkSW5mb1BhcnRzLnB1c2goXHJcbiAgICAgICAgICAgIGAgQWxyZWFkeSByZWZlcnJlZCBieSBBZ2VudCBOYW1lOiAke2FnZW50TmFtZX1gXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIGlmIChyZWZlcnJlZEN1c3RvbWVyTmFtZSlcclxuICAgICAgICAgIHJlZmVycmVkSW5mb1BhcnRzLnB1c2goXHJcbiAgICAgICAgICAgIGBBbHJlYWR5IHJlZmVycmVkIGJ5IEN1c3RvbWVyIE5hbWU6ICR7cmVmZXJyZWRDdXN0b21lck5hbWV9YFxyXG4gICAgICAgICAgKTtcclxuICAgICAgICBpZiAocmVmZXJyZWRMZWFkTmFtZSlcclxuICAgICAgICAgIHJlZmVycmVkSW5mb1BhcnRzLnB1c2goXHJcbiAgICAgICAgICAgIGAgQWxyZWFkeSByZWZlcnJlZCBieSBMZWFkIE5hbWU6ICR7cmVmZXJyZWRMZWFkTmFtZX1gXHJcbiAgICAgICAgICApO1xyXG4gICAgICAgIGlmIChyZWZlcnJlZEluZm9QYXJ0cy5sZW5ndGggPT09IDApXHJcbiAgICAgICAgICByZWZlcnJlZEluZm9QYXJ0cy5wdXNoKFwiRW5yb2xsbWVudCBleGlzdHMgd2l0aCBubyByZWZlcnJhbCBpbmZvLlwiKTtcclxuXHJcbiAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgbm9fb2ZfdGlja2V0czogcmVzcG9uc2U/LmRhdGE/Lm5vX29mX3RpY2tldHMgPz8gcHJldi5ub19vZl90aWNrZXRzLFxyXG4gICAgICAgICAgcGF5bWVudF90eXBlOiByZXNwb25zZT8uZGF0YT8ucGF5bWVudF90eXBlID8/IHByZXYucGF5bWVudF90eXBlLFxyXG4gICAgICAgICAgcmVmZXJyZWRfY3VzdG9tZXI6XHJcbiAgICAgICAgICAgIHJlc3BvbnNlPy5kYXRhPy5yZWZlcnJlZF9jdXN0b21lciA/PyBwcmV2LnJlZmVycmVkX2N1c3RvbWVyLFxyXG4gICAgICAgICAgcmVmZXJyZWRfbGVhZDogcmVzcG9uc2U/LmRhdGE/LnJlZmVycmVkX2xlYWQgPz8gcHJldi5yZWZlcnJlZF9sZWFkLFxyXG4gICAgICAgICAgcmVmZXJyZWRfdHlwZTpcclxuICAgICAgICAgICAgcHJldi5yZWZlcnJlZF90eXBlIHx8XHJcbiAgICAgICAgICAgIHJlc3BvbnNlPy5kYXRhPy5yZWZlcnJlZF90eXBlIHx8XHJcbiAgICAgICAgICAgIChyZXNwb25zZS5kYXRhPy5hZ2VudFxyXG4gICAgICAgICAgICAgID8gXCJBZ2VudFwiXHJcbiAgICAgICAgICAgICAgOiByZXNwb25zZS5kYXRhPy5yZWZlcnJlZF9jdXN0b21lclxyXG4gICAgICAgICAgICAgICAgPyBcIkN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgIDogcmVzcG9uc2UuZGF0YT8ucmVmZXJyZWRfbGVhZFxyXG4gICAgICAgICAgICAgICAgICA/IFwiTGVhZHNcIlxyXG4gICAgICAgICAgICAgICAgICA6IFwiXCIpLFxyXG5cclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIGxldCBzZWxlY3RlZEJ5ID0gXCJVbmtub3duXCI7XHJcbiAgICAgICAgaWYgKHJlZmVycmVkX3R5cGUgPT09IFwiQWdlbnRcIilcclxuICAgICAgICAgIHNlbGVjdGVkQnkgPSBzZWxlY3RlZEFnZW50Py5uYW1lIHx8IFwiVW5rbm93biBBZ2VudFwiO1xyXG4gICAgICAgIGVsc2UgaWYgKHJlZmVycmVkX3R5cGUgPT09IFwiQ3VzdG9tZXJcIilcclxuICAgICAgICAgIHNlbGVjdGVkQnkgPVxyXG4gICAgICAgICAgICBzZWxlY3RlZFJlZmVycmVkQ3VzdG9tZXI/LmZ1bGxfbmFtZSB8fCBcIlVua25vd24gQ3VzdG9tZXJcIjtcclxuICAgICAgICBlbHNlIGlmIChyZWZlcnJlZF90eXBlID09PSBcIkxlYWRzXCIpXHJcbiAgICAgICAgICBzZWxlY3RlZEJ5ID0gc2VsZWN0ZWRSZWZlcnJlZExlYWQ/LmxlYWRfbmFtZSB8fCBcIlVua25vd24gTGVhZFwiO1xyXG5cclxuICAgICAgICBzZXRJc0V4aXN0aW5nRW5yb2xsbWVudCh0cnVlKTtcclxuICAgICAgICBzZXRFbnJvbGxtZW50U3RlcChcImNvbnRpbnVlXCIpO1xyXG5cclxuICAgICAgICBub3RpZmljYXRpb24ud2FybmluZyh7XHJcbiAgICAgICAgICBtZXNzYWdlOiAoXHJcbiAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLFxyXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMS4yNXJlbVwiLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiBcIjEwcHhcIixcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQ3VzdG9tZXIgTmFtZTogXCJ7c2VsZWN0ZWRVc2VyPy5mdWxsX25hbWV9XCJcclxuICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICA8aHIgc3R5bGU9e3sgbWFyZ2luOiBcIjEwcHggMFwiLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkICNjY2NcIiB9fSAvPlxyXG4gICAgICAgICAgICAgIEdyb3VwIE5hbWU6IFwie3NlbGVjdGVkR3JvdXA/Lmdyb3VwX25hbWV9XCJcclxuICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICA8aHIgc3R5bGU9e3sgbWFyZ2luOiBcIjEwcHggMFwiLCBib3JkZXJUb3A6IFwiMXB4IHNvbGlkICNjY2NcIiB9fSAvPlxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICApLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246IChcclxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmb250V2VpZ2h0OiBcImJvbGRcIiwgZm9udFNpemU6IFwiMS4yNXJlbVwiIH19PlxyXG4gICAgICAgICAgICAgIHtyZWZlcnJlZEluZm9QYXJ0cy5tYXAoKHBhcnQsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8c3BhbiBrZXk9e2luZGV4fT5cclxuICAgICAgICAgICAgICAgICAge3BhcnR9XHJcbiAgICAgICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgICA8aHJcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW46IFwiMTBweCAwXCIsIGJvcmRlclRvcDogXCIxcHggc29saWQgI2NjY1wiIH19XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSxcclxuICAgICAgICAgIGR1cmF0aW9uOiAzMCxcclxuICAgICAgICB9KTtcclxuICAgICAgICBzZXRJc0V4aXN0aW5nRW5yb2xsbWVudCh0cnVlKTtcclxuICAgICAgICBzZXRJc1ZlcmlmaWVkKHRydWUpO1xyXG4gICAgICAgIHNldEVucm9sbG1lbnRTdGVwKFwiY29udGludWVcIik7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgc2V0SXNFeGlzdGluZ0Vucm9sbG1lbnQoZmFsc2UpO1xyXG4gICAgICAgIHNldElzVmVyaWZpZWQodHJ1ZSk7XHJcbiAgICAgICAgc2V0RW5yb2xsbWVudFN0ZXAoXCJjb250aW51ZVwiKTtcclxuXHJcbiAgICAgICAgbm90aWZpY2F0aW9uLnN1Y2Nlc3Moe1xyXG4gICAgICAgICAgbWVzc2FnZTogYEVsaWdpYmxlIGZvciBFbnJvbGxtZW50YCxcclxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBgVXNlciBcIiR7c2VsZWN0ZWRVc2VyPy5mdWxsX25hbWV9XCIgY2FuIGJlIGVucm9sbGVkIGluIFwiJHtzZWxlY3RlZEdyb3VwPy5ncm91cF9uYW1lfVwiLmAsXHJcbiAgICAgICAgICBkdXJhdGlvbjogNixcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJWZXJpZmljYXRpb24gZXJyb3I6XCIsIGVycik7XHJcbiAgICAgIG5vdGlmaWNhdGlvbi5lcnJvcih7XHJcbiAgICAgICAgbWVzc2FnZTogXCJFcnJvciBjaGVja2luZyBlbnJvbGxtZW50XCIsXHJcbiAgICAgICAgZGVzY3JpcHRpb246IGVyci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIlNvbWV0aGluZyB3ZW50IHdyb25nXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZU11bHRpU3RlcCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgaWYgKGVucm9sbG1lbnRTdGVwID09PSBcInZlcmlmeVwiKSB7XHJcbiAgICAgIGF3YWl0IGhhbmRsZVZlcmlmeSgpO1xyXG4gICAgfSBlbHNlIGlmIChlbnJvbGxtZW50U3RlcCA9PT0gXCJjb250aW51ZVwiKSB7XHJcbiAgICAgIHNldEVucm9sbG1lbnRTdGVwKFwic3VibWl0XCIpO1xyXG4gICAgfSBlbHNlIGlmIChlbnJvbGxtZW50U3RlcCA9PT0gXCJzdWJtaXRcIikge1xyXG4gICAgICBoYW5kbGVTdWJtaXQoZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIwXCI+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17b25HbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyfVxyXG4gICAgICAgICAgICB2aXNpYmlsaXR5PXt0cnVlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnRcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtNyBvdmVyZmxvdy1oaWRkZW5cIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBtYi02XCI+XHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMiBweC00IHRleHQtc20gZm9udC1tZWRpdW0gJHthY3RpdmVUYWIgPT09ICdlbnJvbGxtZW50cydcclxuICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLWItMiBib3JkZXItdmlvbGV0LTk1MCB0ZXh0LXZpb2xldC05NTAnXHJcbiAgICAgICAgICAgICAgICAgIDogJ3RleHQtZ3JheS01MDAgaG92ZXI6dGV4dC1ncmF5LTcwMCdcclxuICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2Vucm9sbG1lbnRzJyl9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgRW5yb2xsbWVudHNcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTQgdGV4dC1zbSBmb250LW1lZGl1bSAke2FjdGl2ZVRhYiA9PT0gJ2dyb3VwUmVwb3J0J1xyXG4gICAgICAgICAgICAgICAgICA/ICdib3JkZXItYi0yIGJvcmRlci12aW9sZXQtOTUwIHRleHQtdmlvbGV0LTk1MCdcclxuICAgICAgICAgICAgICAgICAgOiAndGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LWdyYXktNzAwJ1xyXG4gICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignZ3JvdXBSZXBvcnQnKX1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBHcm91cCBSZXBvcnRcclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdlbnJvbGxtZW50cycgPyAoXHJcbiAgICAgICAgICAgICAgLy8gLS0tLS0tLS0tLSBFWElTVElORyBFTlJPTExNRU5UUyBDT05URU5UIC0tLS0tLS0tLS1cclxuICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5FbnJvbGxtZW50czwvaDE+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgbWItOFwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWw+U2VhcmNoIG9yIFNlbGVjdCBHcm91cDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggIGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZEdyb3VwIHx8IFwicmVjZW50XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBvciBTZWxlY3QgR3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUdyb3VwQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYm9yZGVyICBoLTE0IHctZnVsbCBtYXgtdy1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtcIiQxXCJ9IHZhbHVlPXtcInJlY2VudFwifT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUmVjZW50IEVucm9sbG1lbnRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e1wiJDJcIn0gdmFsdWU9e1widG9kYXlcIn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRvZGF5J3MgRW5yb2xsbWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2dyb3Vwcy5tYXAoKGdyb3VwKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd01vZGFsKHRydWUpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy12aW9sZXQtOTUwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLXZpb2xldC04MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDBcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICsgQWRkIEVucm9sbG1lbnRcclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHtUYWJsZUVucm9sbHM/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgICAgICB1cGRhdGVIYW5kbGVyPXtoYW5kbGVVcGRhdGVNb2RhbE9wZW59XHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT17ZmlsdGVyT3B0aW9uKFRhYmxlRW5yb2xscywgc2VhcmNoVGV4dCl9XHJcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucz17Y29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJFbnJvbGxtZW50c1wiXHJcbiAgICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEVucm9sbG1lbnRzLSR7VGFibGVFbnJvbGxzLmxlbmd0aCA+IDBcclxuICAgICAgICAgICAgICAgICAgICAgID8gVGFibGVFbnJvbGxzWzBdLm5hbWUgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgXCIgdG8gXCIgK1xyXG4gICAgICAgICAgICAgICAgICAgICAgVGFibGVFbnJvbGxzW1RhYmxlRW5yb2xscy5sZW5ndGggLSAxXS5uYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IFwiZW1wdHlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgfS5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0RhdGFUYWJsZUxvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgZmFpbHVyZT17VGFibGVFbnJvbGxzPy5sZW5ndGggPD0gMCAmJiBzZWxlY3RlZEdyb3VwfVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGE9e1wiRW5yb2xsbWVudCBEYXRhXCJ9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAvLyAtLS0tLS0tLS0tIEdST1VQIFJFUE9SVCBUQUIgLS0tLS0tLS0tLVxyXG4gICAgICAgICAgICAgIDxHcm91cFJlcG9ydCAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbH1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0RXJyb3JzKHt9KTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnQgYmctd2hpdGUgcm91bmRlZC1sZ1wiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNiB0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBib3JkZXItYiBwYi0zXCI+XHJcbiAgICAgICAgICAgICAgQWRkIEVucm9sbG1lbnRcclxuICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IG5vVmFsaWRhdGU+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEdyb3VwIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGxgfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBTZWFyY2ggR3JvdXBcIlxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJncm91cF9pZFwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLnRvTG93ZXJDYXNlKClcclxuICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uZ3JvdXBfaWQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwiZ3JvdXBfaWRcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2dyb3VwLl9pZH0gdmFsdWU9e2dyb3VwLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Z3JvdXAuZ3JvdXBfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICB7ZXJyb3JzLmdyb3VwX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTYwMFwiPntlcnJvcnMuZ3JvdXBfaWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLWxnIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB3LWZ1bGxgfVxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBTZWFyY2ggQ3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJ1c2VyX2lkXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy51c2VyX2lkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgLy9vbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnREU2VsZWN0KFwidXNlcl9pZFwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwidXNlcl9pZFwiLCB2YWx1ZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIC8vIGZpbmQgc2VsZWN0ZWQgdXNlclxyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkVXNlciA9IHVzZXJzLmZpbmQoKHUpID0+IHUuX2lkID09PSB2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNlbGVjdGVkVXNlcikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0RW1haWwoc2VsZWN0ZWRVc2VyLmVtYWlsIHx8IFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtYWlsX2lkOiBzZWxlY3RlZFVzZXIuZW1haWwsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9KSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXt1c2VyLl9pZH0gdmFsdWU9e3VzZXIuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX0gfCB7dXNlci5waG9uZV9udW1iZXIgfHwgXCJObyBOdW1iZXJcIn1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICB7LyogQ3VzdG9tZXIgZGV0YWlscyBzZWN0aW9uICovfVxyXG4gICAgICAgICAgICAgICAge2Zvcm1EYXRhLnVzZXJfaWQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTRcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEN1c3RvbWVyIEV4aXN0aW5nIERldGFpbHNcclxuICAgICAgICAgICAgICAgICAgICAgIHtjdXN0b21lckRldGFpbHNMb2FkaW5nICYmIDxzcGFuIGNsYXNzTmFtZT1cIm1sLTIgdGV4dC1ncmF5LTQwMFwiPkxvYWRpbmcuLi48L3NwYW4+fVxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7IWN1c3RvbWVyRGV0YWlsc0xvYWRpbmcgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC00IG1heC1oLVsyNDBweF0gb3ZlcmZsb3cteS1hdXRvIHByLTJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgeygoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZGV0YWlscyA9IGdldEN1c3RvbWVyVGlja2V0RGV0YWlscyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1c3RvbWVyRW5yb2xsbWVudHMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXN0b21lclBpZ215LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJMb2Fuc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGRldGFpbHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBpdGFsaWNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBObyBleGlzdGluZyBlbnJvbGxtZW50cywgcGlnbXksIG9yIGxvYW5zIGZvdW5kLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBkZXRhaWxzLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uaWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJvcmRlciByb3VuZGVkLWxnIHAtNCBzaGFkb3ctc20gYmctd2hpdGUgJHtpdGVtLmJhbGFuY2UgPiAwID8gJ2JvcmRlci1yZWQtMjAwJyA6ICdib3JkZXItZ3JlZW4tMjAwJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogSGVhZGVyICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLXN0YXJ0IGdhcC0zIG1iLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFnIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgbS0wIHB4LTIgcHktMC41XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50eXBlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGFnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50eXBlID09PSAnY2hpdCcgJiYgaXRlbS50aWNrZXQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWJsdWUtNjAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRpY2tldDoge2l0ZW0udGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udHlwZSA9PT0gJ2NoaXQnICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyb3VwIFZhbHVlOiB7aXRlbS5ncm91cF92YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHcm91cCBJbnN0YWxsbWVudDoge2l0ZW0uZ3JvdXBfaW5zdGFsbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRGV0YWlscyBHcmlkICovfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTMgbWQ6Z3JpZC1jb2xzLTQgbGc6Z3JpZC1jb2xzLTUgeGw6Z3JpZC1jb2xzLTYgZ2FwLXgtNiBnYXAteS0yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udHlwZSA9PT0gJ2NoaXQnICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNDAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUb3RhbCBQYXlhYmxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7aXRlbS5wYXlhYmxlPy50b0xvY2FsZVN0cmluZygnZW4tSU4nKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTQwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgUGFpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2l0ZW0udG90YWxQYWlkPy50b0xvY2FsZVN0cmluZygnZW4tSU4nKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTQwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUGVuYWx0eVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2l0ZW0udG90YWxQZW5hbHR5Py50b0xvY2FsZVN0cmluZygnZW4tSU4nKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTQwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTGF0ZSBGZWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKCuXtpdGVtLnRvdGFsTGF0ZUZlZT8udG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEJhbGFuY2UgRHVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1zZW1pYm9sZCAke2l0ZW0uYmFsYW5jZSA+IDAgPyAndGV4dC1yZWQtNjAwJyA6ICd0ZXh0LWdyZWVuLTYwMCd9YH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7aXRlbS5iYWxhbmNlPy50b0xvY2FsZVN0cmluZygnZW4tSU4nKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udHlwZSA9PT0gJ2xvYW4nICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LWdyYXktNDAwIGZvbnQtbWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMb2FuIEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2l0ZW0ubG9hbkFtb3VudD8udG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0YXJ0IERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnN0YXJ0RGF0ZT8uc3BsaXQoJ1QnKVswXS5zcGxpdCgnLScpLnJldmVyc2UoKS5qb2luKCctJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVuZCBEYXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5lbmREYXRlPy5zcGxpdCgnVCcpWzBdLnNwbGl0KCctJykucmV2ZXJzZSgpLmpvaW4oJy0nKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTQwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRGFpbHkgUGF5bWVudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2l0ZW0uZGFpbHlQYXltZW50Py50b0xvY2FsZVN0cmluZygnZW4tSU4nKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTQwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVG90YWwgUGFpZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2l0ZW0udG90YWxQYWlkPy50b0xvY2FsZVN0cmluZygnZW4tSU4nKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1ncmF5LTQwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQmFsYW5jZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgJHtpdGVtLmJhbGFuY2UgPiAwID8gJ3RleHQtcmVkLTYwMCcgOiAndGV4dC1ncmVlbi02MDAnfWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2l0ZW0uYmFsYW5jZT8udG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnR5cGUgPT09ICdwaWdteScgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIERhaWx5IEFtb3VudFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4oK5e2l0ZW0ucGF5YWJsZUFtb3VudD8udG9Mb2NhbGVTdHJpbmcoJ2VuLUlOJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFN0YXJ0IERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnN0YXJ0RGF0ZT8uc3BsaXQoJ1QnKVswXS5zcGxpdCgnLScpLnJldmVyc2UoKS5qb2luKCctJyl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIER1cmF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5kdXJhdGlvbn0gbW9udGhzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZ3JheS00MDAgZm9udC1tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRvdGFsIFBhaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JlZW4tNjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICDigrl7aXRlbS50b3RhbFBhaWQ/LnRvTG9jYWxlU3RyaW5nKCdlbi1JTicpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSgpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge2Zvcm1EYXRhPy51c2VyX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkVtYWlsIElEIEZvciBQYXltZW50IExpbmsgU3VibWlzc2lvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgRW1haWxcclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFbWFpbCBJRCBGb3IgUGF5bWVudCBMaW5rIFN1Ym1pc3Npb25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgcC0yXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtlbWFpbCB8fCBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEVtYWlsKGUudGFyZ2V0LnZhbHVlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBlbWFpbF9pZDogZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge2Vycm9ycy5lbWFpbF9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC14cyB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLmVtYWlsX2lkfTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIG10LTAgaXRlbXMtY2VudGVyIGdhcC0xXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtYmx1ZS02MDBcIj5cclxuICAgICAgICAgICAgICAgICAgTm90IGEgY3VzdG9tZXI/XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgPGFcclxuICAgICAgICAgICAgICAgICAgaHJlZj1cIi9jdXN0b21lci1tZW51L3VzZXI/b3Blbk1vZGFsPXRydWVcIlxyXG4gICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxyXG4gICAgICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIHB4LTIgcHktMSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgYmctYmx1ZS02MDAgcm91bmRlZC1tZCBob3ZlcjpiZy1ibHVlLTcwMCB0cmFuc2l0aW9uXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgKyBBZGQgQ3VzdG9tZXJcclxuICAgICAgICAgICAgICAgIDwvYT5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIGdhcC00XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUGF5bWVudCBUeXBlXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicGF5bWVudF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5wYXltZW50X3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJwYXltZW50X3R5cGVcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge1tcIkRhaWx5XCIsIFwiV2Vla2x5XCIsIFwiTW9udGhseVwiXS5tYXAoKHBUeXBlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3BUeXBlfSB2YWx1ZT17cFR5cGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cFR5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBDaGl0IEFza2luZyBNb250aFxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibW9udGhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiBib3JkZXIgcm91bmRlZCB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZERhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaXRfYXNraW5nX21vbnRoOiBlLnRhcmdldC52YWx1ZSwgLy8gPC0tIEZJWFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgbWluPXtmb3JtYXRUb1llYXJNb250aChjdXJyZW50WWVhciwgY3VycmVudE1vbnRoKX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwgZ2FwLTRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBSZWZlcnJlZCBUeXBlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgUmVmZXJyZWQgVHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGE/LnJlZmVycmVkX3R5cGUgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudERTZWxlY3QoXCJyZWZlcnJlZF90eXBlXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICAgICBcIlNlbGYgSm9pbmluZ1wiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lclwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJFbXBsb3llZVwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJBZ2VudFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgXCJMZWFkc1wiLFxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIFwiT3RoZXJzXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXS5tYXAoKHJlZlR5cGUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17cmVmVHlwZX0gdmFsdWU9e3JlZlR5cGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7cmVmVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkN1c3RvbWVyXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiY2F0ZWdvcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCBSZWZlcnJlZCBDdXN0b21lcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGJnLWdyYXktNTAgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCAke2ZpZWxkU2l6ZS5oZWlnaHR9IHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbCBgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfY3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5yZWZlcnJlZF9jdXN0b21lciB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVBbnREU2VsZWN0KFwicmVmZXJyZWRfY3VzdG9tZXJcIiwgdmFsdWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXJzLm1hcCgodXNlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX0gfHtcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7dXNlci5waG9uZV9udW1iZXIgPyB1c2VyLnBob25lX251bWJlciA6IFwiTm8gTnVtYmVyXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICB7Zm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJMZWFkc1wiICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEvMlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImNhdGVnb3J5XCJcclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBTZWxlY3QgUmVmZXJyZWQgTGVhZHN7XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLWJsdWUtNTAwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB3LWZ1bGwgYH1cclxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBSZWZlcnJlZCBMZWFkc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInJlZmVycmVkX2xlYWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhPy5yZWZlcnJlZF9sZWFkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZUFudERTZWxlY3QoXCJyZWZlcnJlZF9sZWFkXCIsIHZhbHVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtsZWFkcy5tYXAoKGxlYWQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtsZWFkLl9pZH0gdmFsdWU9e2xlYWQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7bGVhZC5sZWFkX25hbWV9IHwge2xlYWQubGVhZF9waG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkFnZW50XCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+U2VsZWN0IFJlZmVycmVkIEFnZW50e1wiIFwifSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBTZWFyY2ggUmVmZXJyZWQgQWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuYWdlbnQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50RFNlbGVjdChcImFnZW50XCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYWdlbnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfSB8IHthZ2VudC5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpXHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAge2Zvcm1EYXRhLnJlZmVycmVkX3R5cGUgPT09IFwiRW1wbG95ZWVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xLzJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJjYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFJlZmVycmVkIEVtcGxveWVle1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgYmctZ3JheS01MCBib3JkZXIgYm9yZGVyLWdyYXktMzAwICR7ZmllbGRTaXplLmhlaWdodH0gdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgZm9jdXM6cmluZy1ibHVlLTUwMCBmb2N1czpib3JkZXItYmx1ZS01MDAgdy1mdWxsIGB9XHJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBPciBTZWFyY2ggUmVmZXJyZWQgRW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghb3B0aW9uIHx8ICFvcHRpb24uY2hpbGRyZW4pIHJldHVybiBmYWxzZTsgLy8gRW5zdXJlIG9wdGlvbiBhbmQgY2hpbGRyZW4gZXhpc3RcclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAudG9TdHJpbmcoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8uYWdlbnQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT4gaGFuZGxlQW50RFNlbGVjdChcImFnZW50XCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wbG95ZWUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXBsb3llZS5faWR9IHZhbHVlPXtlbXBsb3llZS5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZS5uYW1lfSB8IHtlbXBsb3llZS5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHtmb3JtRGF0YS5ncm91cF9pZCAmJiBhdmFpbGFibGVUaWNrZXRzQWRkLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHRleHQtcmVkLTYwMCBmb250LW1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICBHcm91cCBpcyBGdWxsXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgKSA6IGZvcm1EYXRhLmdyb3VwX2lkICYmIGF2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RoICE9PSAwID8gKFxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTnVtYmVyIG9mIFRpY2tldHMgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vX29mX3RpY2tldHNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YT8ubm9fb2ZfdGlja2V0c31cclxuICAgICAgICAgICAgICAgICAgICBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgTnVtYmVyIG9mIFRpY2tldHNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgbWF4PXthdmFpbGFibGVUaWNrZXRzQWRkLmxlbmd0aH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSByb3VuZGVkLWxnIGZvY3VzOnJpbmctYmx1ZS01MDAgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIHctZnVsbGB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgIHtlcnJvcnMubm9fb2ZfdGlja2V0cyAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5ub19vZl90aWNrZXRzfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtYmx1ZS04MDAgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICBPbmx5IHthdmFpbGFibGVUaWNrZXRzQWRkLmxlbmd0aH0gdGlja2V0cyBsZWZ0XHJcbiAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICkgOiBudWxsfVxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJpZ25vcmVJbmNlbnRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwiaWdub3JlSW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICAgICAgY2hlY2tlZD17Zm9ybURhdGE/Lmlnbm9yZUluY2VudGl2ZSB8fCBmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgIGlnbm9yZUluY2VudGl2ZTogZS50YXJnZXQuY2hlY2tlZCxcclxuICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLTQgdy00IGN1cnNvci1wb2ludGVyIHJvdW5kZWQgYm9yZGVyLXNsYXRlLTMwMCB0ZXh0LWluZGlnby02MDAgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctaW5kaWdvLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiaWdub3JlSW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY3Vyc29yLXBvaW50ZXIgc2VsZWN0LW5vbmUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTcwMFwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIElnbm9yZSBJbmNlbnRpdmVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgcHQtNCBzcGFjZS15LTRcIj5cclxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIEFjdGlvbnNcclxuICAgICAgICAgICAgICAgIDwvaDI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGYVdoYXRzYXBwIGNsYXNzTmFtZT1cInRleHQtZ3JlZW4tNjAwIHctNSBoLTVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEVuYWJsZSBXaGF0c0FwcCBTZW5kaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcclxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlyZFBhcnR5RW5hYmxlLndoYXRzYXBwfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0VGhpcmRQYXJ0eUVuYWJsZSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2hhdHNhcHA6ICFwcmV2LndoYXRzYXBwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgYWNjZW50LWdyZWVuLTYwMCBjdXJzb3ItcG9pbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZpTGluayBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMCB3LTUgaC01XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBFbmFibGUgUmVnaXN0cmF0aW9uIFBheW1lbnQgTGlua1xyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcmRQYXJ0eUVuYWJsZS5wYXltZW50TGlua31cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFRoaXJkUGFydHlFbmFibGUoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBheW1lbnRMaW5rOiAhcHJldi5wYXltZW50TGluayxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IGFjY2VudC1ncmVlbi02MDAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGaU1haWwgY2xhc3NOYW1lPVwidy01IGgtNVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMFwiPkVuYWJsZSBFbWFpbDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcmRQYXJ0eUVuYWJsZS5lbWFpbH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHNldFRoaXJkUGFydHlFbmFibGUoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtYWlsOiAhcHJldi5lbWFpbCxcclxuICAgICAgICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTUgaC01IGFjY2VudC1ncmVlbi02MDAgY3Vyc29yLXBvaW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBwdC00XCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgbG9hZGluZyB8fFxyXG4gICAgICAgICAgICAgICAgICAgIChlbnJvbGxtZW50U3RlcCA9PT0gXCJzdWJtaXRcIiAmJlxyXG4gICAgICAgICAgICAgICAgICAgICAgKCFpc1ZlcmlmaWVkIHx8IGF2YWlsYWJsZVRpY2tldHNBZGQubGVuZ3RoID09PSAwKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVNdWx0aVN0ZXB9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctMS80IHRleHQtd2hpdGUgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRyYW5zaXRpb24tY29sb3JzICR7bG9hZGluZ1xyXG4gICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmF5LTQwMCBjdXJzb3Itbm90LWFsbG93ZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIDogZW5yb2xsbWVudFN0ZXAgPT09IFwidmVyaWZ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgID8gXCJiZy1ncmF5LTYwMCBob3ZlcjpiZy1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IGVucm9sbG1lbnRTdGVwID09PSBcImNvbnRpbnVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcImJnLWdyZWVuLTYwMCBob3ZlcjpiZy1ncmVlbi03MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IFwiYmctdmlvbGV0LTcwMCBob3ZlcjpiZy12aW9sZXQtODAwXCJcclxuICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAge2xvYWRpbmdcclxuICAgICAgICAgICAgICAgICAgICA/IFwiUHJvY2Vzc2luZy4uLlwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBlbnJvbGxtZW50U3RlcCA9PT0gXCJ2ZXJpZnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPyBcIlZlcmlmeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA6IGVucm9sbG1lbnRTdGVwID09PSBcImNvbnRpbnVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyBcIkNvbnRpbnVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiBcIlN1Ym1pdFwifVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kYWxVcGRhdGV9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbFVwZGF0ZShmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEVycm9ycyh7fSk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTYgYm9yZGVyLWIgcGItM1wiPlxyXG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tdmlvbGV0LTYwMCB0by1pbmRpZ28tNjAwIHctMSBoLTYgcm91bmRlZC1mdWxsXCI+PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgVXBkYXRlIEVucm9sbG1lbnRcclxuICAgICAgICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICAgICAgICB7LyogTGluay9VbmxpbmsgQnV0dG9uIC0gVG9wIFJpZ2h0IENvcm5lciAqL31cclxuICAgICAgICAgICAgICB7Y3VycmVudFVwZGF0ZUdyb3VwPy51bmxpbmtfYnJhbmNoID8gKFxyXG4gICAgICAgICAgICAgICAgPFBvcGNvbmZpcm1cclxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJMaW5rIEJyYW5jaFwiXHJcbiAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uPVwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGxpbmsgdGhpcyBicmFuY2ggdG8gdGhlIGN1c3RvbWVyP1wiXHJcbiAgICAgICAgICAgICAgICAgIG9rVGV4dD1cIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgIGNhbmNlbFRleHQ9XCJOb1wiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ29uZmlybT17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZWxpbmtCcmFuY2goY3VycmVudFVwZGF0ZUdyb3VwPy5faWQpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgLy8gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyAgIHNldFJlbG9hZFRyaWdnZXIoKHByZXYpID0+IHByZXYgKyAxKTtcclxuICAgICAgICAgICAgICAgICAgICAvLyB9LCA1MDApO1xyXG4gICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7bW9kaWZ5UGF5bWVudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctZ3JlZW4tNTAwIGhvdmVyOmJnLWdyZWVuLTYwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgdGV4dC1zbSBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk0xMy44MjggMTAuMTcyYTQgNCAwIDAwLTUuNjU2IDBsLTQgNGE0IDQgMCAxMDUuNjU2IDUuNjU2bDEuMTAyLTEuMTAxbS0uNzU4LTQuODk5YTQgNCAwIDAwNS42NTYgMGw0LTRhNCA0IDAgMDAtNS42NTYtNS42NTZsLTEuMSAxLjFcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICBMaW5rIEJyYW5jaFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIDwvUG9wY29uZmlybT5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgPFBvcGNvbmZpcm1cclxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJVbmxpbmsgQnJhbmNoXCJcclxuICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb249XCJBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gdW5saW5rIHRoaXMgYnJhbmNoIGZyb20gdGhlIGN1c3RvbWVyP1wiXHJcbiAgICAgICAgICAgICAgICAgIG9rVGV4dD1cIlllc1wiXHJcbiAgICAgICAgICAgICAgICAgIGNhbmNlbFRleHQ9XCJOb1wiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ29uZmlybT17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZVVubGlua0JyYW5jaChjdXJyZW50VXBkYXRlR3JvdXA/Ll9pZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLy8gICAvLyBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vIH0sIDUwMCk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHttb2RpZnlQYXltZW50ICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1yZWQtNTAwIGhvdmVyOmJnLXJlZC02MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHRleHQtc20gZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIlxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9ezJ9IGQ9XCJNMTMuODI4IDEwLjE3MmE0IDQgMCAwMC01LjY1NiAwbC00IDRhNCA0IDAgMTA1LjY1NiA1LjY1NmwxLjEwMi0xLjEwMW0tLjc1OC00Ljg5OWE0IDQgMCAwMDUuNjU2IDBsNC00YTQgNCAwIDAwLTUuNjU2LTUuNjU2bC0xLjEgMS4xXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgVW5saW5rIEJyYW5jaFxyXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIDwvUG9wY29uZmlybT5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cInNwYWNlLXktNlwiIG9uU3VibWl0PXtoYW5kbGVVcGRhdGV9PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBfaWRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBHcm91cCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImdyb3VwX2lkXCJcclxuICAgICAgICAgICAgICAgICAgaWQ9XCJncm91cF9pZFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YS5ncm91cF9pZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTYwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHB4LTQgY3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBHcm91cDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICB7Z3JvdXBzLm1hcCgoZ3JvdXApID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17Z3JvdXAuX2lkfSB2YWx1ZT17Z3JvdXAuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtncm91cC5ncm91cF9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cInVzZXJfaWRcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDdXN0b21lciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInVzZXJfaWRcIlxyXG4gICAgICAgICAgICAgICAgICBpZD1cInVzZXJfaWRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEudXNlcl9pZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTYwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHB4LTQgY3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBDdXN0b21lcjwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICB7dXNlcnMubWFwKCh1c2VyKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3VzZXIuX2lkfSB2YWx1ZT17dXNlci5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3VzZXIuZnVsbF9uYW1lfSB8IHt1c2VyLnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICAgIHtlcnJvcnMudXNlcl9pZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXJlZC02MDBcIj57ZXJyb3JzLnVzZXJfaWR9PC9wPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwYXltZW50X3R5cGVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBQYXltZW50IFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBob3Zlcjpib3JkZXItdmlvbGV0LTQwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFBheW1lbnQgVHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInBheW1lbnRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGE/LnBheW1lbnRfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudElucHV0RFNlbGVjdChcInBheW1lbnRfdHlwZVwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtbXCJEYWlseVwiLCBcIldlZWtseVwiLCBcIk1vbnRobHlcIl0ubWFwKChwVHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17cFR5cGUudG9Mb3dlckNhc2UoKX0gdmFsdWU9e3BUeXBlfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHtwVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQ2hpdCBBc2tpbmcgTW9udGhcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHB4LTQgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctdmlvbGV0LTUwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCBvdXRsaW5lLW5vbmUgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEuY2hpdF9hc2tpbmdfbW9udGh9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICBjaGl0X2Fza2luZ19tb250aDogZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwicmVmZXJyZWRfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFJlZmVycmVkIFR5cGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBob3Zlcjpib3JkZXItdmlvbGV0LTQwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFJlZmVycmVkIFR5cGVcIlxyXG4gICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJyZWZlcnJlZF90eXBlXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucmVmZXJyZWRfdHlwZSB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudElucHV0RFNlbGVjdChcInJlZmVycmVkX3R5cGVcIiwgdmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgIFwiU2VsZiBKb2luaW5nXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJDdXN0b21lclwiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiRW1wbG95ZWVcIixcclxuICAgICAgICAgICAgICAgICAgICBcIkFnZW50XCIsXHJcbiAgICAgICAgICAgICAgICAgICAgXCJMZWFkc1wiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiQmxvY2tlZCBSZWZlcnJhbFwiLFxyXG4gICAgICAgICAgICAgICAgICAgIFwiT3RoZXJzXCIsXHJcbiAgICAgICAgICAgICAgICAgIF0ubWFwKChyZWZUeXBlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtyZWZUeXBlfSB2YWx1ZT17cmVmVHlwZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7cmVmVHlwZX1cclxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkN1c3RvbWVyXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVmZXJyZWQgQ3VzdG9tZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBob3Zlcjpib3JkZXItdmlvbGV0LTQwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfY3VzdG9tZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8ucmVmZXJyZWRfY3VzdG9tZXIgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudElucHV0RFNlbGVjdChcInJlZmVycmVkX2N1c3RvbWVyXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHt1c2Vycy5tYXAoKHVzZXIpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17dXNlci5faWR9IHZhbHVlPXt1c2VyLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt1c2VyLmZ1bGxfbmFtZX0gfCB7dXNlci5waG9uZV9udW1iZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAge3VwZGF0ZUZvcm1EYXRhLnJlZmVycmVkX3R5cGUgPT09IFwiQWdlbnRcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBSZWZlcnJlZCBBZ2VudCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIGhvdmVyOmJvcmRlci12aW9sZXQtNDAwIGZvY3VzOmJvcmRlci12aW9sZXQtNTAwIHRyYW5zaXRpb24tY29sb3JzXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBvciBTZWFyY2ggUmVmZXJyZWQgQWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhZ2VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhLmFnZW50IHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJhZ2VudFwiLCB2YWx1ZSl9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7YWdlbnRzLm1hcCgoYWdlbnQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17YWdlbnQuX2lkfSB2YWx1ZT17YWdlbnQuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2FnZW50Lm5hbWV9IHwge2FnZW50LnBob25lX251bWJlcn1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICB7dXBkYXRlRm9ybURhdGEucmVmZXJyZWRfdHlwZSA9PT0gXCJMZWFkc1wiICYmIChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlZmVycmVkIExlYWRzIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGwgaG92ZXI6Ym9yZGVyLXZpb2xldC00MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IE9yIFNlYXJjaCBSZWZlcnJlZCBMZWFkXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVmZXJyZWRfbGVhZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlbi50b1N0cmluZygpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUZvcm1EYXRhPy5yZWZlcnJlZF9sZWFkIHx8IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBoYW5kbGVBbnRJbnB1dERTZWxlY3QoXCJyZWZlcnJlZF9sZWFkXCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtsZWFkcy5tYXAoKGxlYWQpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17bGVhZC5faWR9IHZhbHVlPXtsZWFkLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsZWFkLmxlYWRfbmFtZX0gfCB7bGVhZC5sZWFkX3Bob25lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgIHt1cGRhdGVGb3JtRGF0YS5yZWZlcnJlZF90eXBlID09PSBcIkVtcGxveWVlXCIgJiYgKFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgUmVmZXJyZWQgRW1wbG95ZWUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYXktNTAgYm9yZGVyIGgtMTQgYm9yZGVyLWdyYXktMzAwIHRleHQtZ3JheS05MDAgdGV4dC1zbSByb3VuZGVkLWxnIHctZnVsbCBob3Zlcjpib3JkZXItdmlvbGV0LTQwMCBmb2N1czpib3JkZXItdmlvbGV0LTUwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgT3IgU2VhcmNoIFJlZmVycmVkIEVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgICAgICBwb3B1cE1hdGNoU2VsZWN0V2lkdGg9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWdlbnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZpbHRlck9wdGlvbj17KGlucHV0LCBvcHRpb24pID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9TdHJpbmcoKS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVGb3JtRGF0YT8uYWdlbnQgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IGhhbmRsZUFudElucHV0RFNlbGVjdChcImFnZW50XCIsIHZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtlbXBsb3llZXMubWFwKChhZ2VudCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXthZ2VudC5faWR9IHZhbHVlPXthZ2VudC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWdlbnQubmFtZX0gfCB7YWdlbnQucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXHJcbiAgICAgICAgICAgICAgICAgIGlkPVwiaWdub3JlSW5jZW50aXZlXCJcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cImlnbm9yZUluY2VudGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VwZGF0ZUZvcm1EYXRhPy5pZ25vcmVJbmNlbnRpdmUgfHwgZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVGb3JtRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICBpZ25vcmVJbmNlbnRpdmU6IGUudGFyZ2V0LmNoZWNrZWQsXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC00IHctNCBjdXJzb3ItcG9pbnRlciByb3VuZGVkIGJvcmRlci1zbGF0ZS0zMDAgdGV4dC1pbmRpZ28tNjAwIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWluZGlnby01MDBcIlxyXG4gICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgaHRtbEZvcj1cImlnbm9yZUluY2VudGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN1cnNvci1wb2ludGVyIHNlbGVjdC1ub25lIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDBcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBJZ25vcmUgSW5jZW50aXZlXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwibm9fb2ZfdGlja2V0c1wiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFRpY2tldCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICAgICAgbmFtZT1cInRpY2tldHNcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlRm9ybURhdGEudGlja2V0c31cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cIm5vX29mX3RpY2tldHNcIlxyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTEwMCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTYwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsIHB4LTQgY3Vyc29yLW5vdC1hbGxvd2VkXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPlNlbGVjdCBUaWNrZXQ8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAge2F2YWlsYWJsZVRpY2tldHNcclxuICAgICAgICAgICAgICAgICAgICAuY29uY2F0KFt1cGRhdGVGb3JtRGF0YS50aWNrZXRzXSlcclxuICAgICAgICAgICAgICAgICAgICAubWFwKCh0aWNrZXQsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17aW5kZXh9IHZhbHVlPXt0aWNrZXR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dGlja2V0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L3NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tdmlvbGV0LTYwMCB0by1pbmRpZ28tNjAwIGhvdmVyOmZyb20tdmlvbGV0LTcwMCBob3Zlcjp0by1pbmRpZ28tNzAwIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTMgdGV4dC1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGdcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD17Mn0gZD1cIk00IDR2NWguNTgybTE1LjM1NiAyQTguMDAxIDguMDAxIDAgMDA0LjU4MiA5bTAgMEg5bTExIDExdi01aC0uNTgxbTAgMGE4LjAwMyA4LjAwMyAwIDAxLTE1LjM1Ny0ybTE1LjM1NyAySDE1XCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgIFVwZGF0ZSBFbnJvbGxtZW50XHJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbFJlbW92ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsUmVtb3ZlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgUGxlYXNlIFNlbGVjdCBhIFJlYXNvbiBmb3IgUmVtb3ZhbFxyXG4gICAgICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICAgICAge2N1cnJlbnRHcm91cCAmJiAoXHJcbiAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVJlbW92ZUdyb3VwfSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJyZW1vdmFsUmVhc29uXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTcwMFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBSZW1vdmFsIFJlYXNvbiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJyZW1vdmFsUmVhc29uXCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwicmVtb3ZhbFJlYXNvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3JlbW92YWxSZWFzb259XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZW1vdmFsUmVhc29uKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIHctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgcHgtMyBweS0yIHRleHQtc20gZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctcmVkLTUwMCBmb2N1czpib3JkZXItcmVkLTUwMFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+LS0gU2VsZWN0IFJlYXNvbiAtLTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiA8b3B0aW9uIHZhbHVlPVwiR3JvdXAgQ2xvc2VkXCI+R3JvdXAgQ2xvc2VkPC9vcHRpb24+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiA8b3B0aW9uIHZhbHVlPVwiR3JvdXAgQ2hhbmdlZFwiPkdyb3VwIENoYW5nZWQ8L29wdGlvbj4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIDxvcHRpb24gdmFsdWU9XCJDaGl0IENhbmNlbGxhdGlvblwiPkNoaXQgQ2FuY2VsbGF0aW9uPC9vcHRpb24+ICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTdXNwZW5kXCI+U3VzcGVuZDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJJbiBBY3RpdmUgQ3VzdG9tZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIEluQWN0aXZlIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkxlZ2FsXCI+TGVnYWw8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiT3RoZXJzXCI+T3RoZXJzPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy1yZWQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNVwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFJlbW92ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcblxyXG4gICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgaXNWaXNpYmxlPXtzaG93TW9kZWxPbkhvbGR9XHJcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RlbE9uSG9sZChmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYmctZ3JheS01MCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTQgdy0xNCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20teWVsbG93LTQwMCB0by15ZWxsb3ctNjAwIHNoYWRvdy1sZ1wiPlxyXG4gICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctOCB0ZXh0LXdoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlPVwiY3VycmVudENvbG9yXCJcclxuICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDI0IDI0XCJcclxuICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIDxwYXRoXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBkPVwiTTEyIDl2NG0wIDRoLjAxTTEwLjI5IDMuODZsLTcuNSAxM0ExIDEgMCAwMDMuNjYgMThoMTYuNjhhMSAxIDAgMDAuODctMS41bC03LjUtMTNhMSAxIDAgMDAtMS43NCAwelwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cclxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIENvbmZpcm0gRW5yb2xsbWVudCBIb2xkP1xyXG4gICAgICAgICAgICAgICAgPC9oMz5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gcGxhY2UgdGhpcyBlbnJvbGxtZW50IG9uIGhvbGQ/IFRoZSBjdXN0b21lciB3aWxsIGJlIHRlbXBvcmFyaWx5IGV4Y2x1ZGVkIGZyb20gcGFydGljaXBhdGlvbiB1bnRpbCB0aGUgZW5yb2xsbWVudCBpcyByZWFjdGl2YXRlZC5cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC01IGJnLXdoaXRlIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTUgc2hhZG93LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi00XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImgtOCB3LTEgYmcteWVsbG93LTUwMCByb3VuZGVkLWZ1bGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPkN1c3RvbWVyIERldGFpbHM8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLWxnIHAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj5DdXN0b21lcjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50R3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC1sZyBwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+R3JvdXA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYXktNTAgcm91bmRlZC1sZyBwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwXCI+UGhvbmU8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwPy51c2VyX2lkPy5waG9uZV9udW1iZXIgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPlRpY2tldDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50R3JvdXA/LnRpY2tldHMgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgZmxleCBpdGVtcy1zdGFydCBnYXAtMiBiZy1yZWQtNTAgcm91bmRlZC1sZyBwLTMgYm9yZGVyLWwtNCBib3JkZXItcmVkLTUwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtcmVkLTUwMCBmbGV4LXNocmluay0wXCIgZmlsbD1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjAgMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggZmlsbFJ1bGU9XCJldmVub2RkXCIgZD1cIk0xOCAxMGE4IDggMCAxMS0xNiAwIDggOCAwIDAxMTYgMHptLTctNGExIDEgMCAxMS0yIDAgMSAxIDAgMDEyIDB6TTkgOWExIDEgMCAwMDAgMnYzYTEgMSAwIDAwMSAxaDFhMSAxIDAgMTAwLTJoLTFWOWExIDEgMCAwMC0xLTF6XCIgY2xpcFJ1bGU9XCJldmVub2RkXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXJlZC03MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPkltcG9ydGFudDo8L3NwYW4+IFZlcmlmeSBjdXN0b21lciBkZXRhaWxzIGJlZm9yZSBwcm9jZWVkaW5nLlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAge2N1cnJlbnRHcm91cCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVPbkhvbGRHcm91cH0gY2xhc3NOYW1lPVwibXQtNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbC1yZXZlcnNlIHNtOmZsZXgtcm93IGp1c3RpZnktZW5kIGdhcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGVsT25Ib2xkKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBweC02IHB5LTIuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnIGhvdmVyOmJnLWdyYXktNTAgaG92ZXI6Ym9yZGVyLWdyYXktNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ncmF5LTMwMCB0cmFuc2l0aW9uLWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcHgtNiBweS0yLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLXllbGxvdy01MDAgcm91bmRlZC1sZyBob3ZlcjpiZy15ZWxsb3ctNjAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTQgZm9jdXM6cmluZy15ZWxsb3ctMzAwIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDb25maXJtIEhvbGRcclxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e2FjdGl2YXRlTW9kZWxPcGVufVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRBY3RpdmF0ZU1vZGVsT3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgIHNldEN1cnJlbnRHcm91cChudWxsKTtcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgYmctZ3JheS01MCByb3VuZGVkLXhsXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtNFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTQgdy0xNCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tZ3JlZW4tNDAwIHRvLWdyZWVuLTYwMCBzaGFkb3ctbGdcIj5cclxuICAgICAgICAgICAgICAgICAgPHN2Z1xyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCB3LTggdGV4dC13aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgZD1cIk01IDEzbDQgNEwxOSA3XCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgQ29uZmlybSBFbnJvbGxtZW50IEFjdGl2YXRpb24/XHJcbiAgICAgICAgICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTIgdGV4dC1zbSB0ZXh0LWdyYXktNjAwIGxlYWRpbmctcmVsYXhlZFwiPlxyXG4gICAgICAgICAgICAgICAgICBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gcmVhY3RpdmF0ZSB0aGlzIGVucm9sbG1lbnQ/IFRoZSBjdXN0b21lclxyXG4gICAgICAgICAgICAgICAgICB3aWxsIGJlIGVsaWdpYmxlIHRvIHBhcnRpY2lwYXRlIGluIGFsbCBmdXR1cmUgYWN0aXZpdGllcyBhbmQgZHJhd3MuXHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAge2N1cnJlbnRHcm91cCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNSBiZy13aGl0ZSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC01IHNoYWRvdy1zbVwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWItNFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoLTggdy0xIGJnLWdyZWVuLTUwMCByb3VuZGVkLWZ1bGxcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBDdXN0b21lciBEZXRhaWxzXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLWxnIHAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj5DdXN0b21lcjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50R3JvdXA/LnVzZXJfaWQ/LmZ1bGxfbmFtZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPkdyb3VwPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTgwMCBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRHcm91cD8uZ3JvdXBfaWQ/Lmdyb3VwX25hbWUgfHwgXCItXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCByb3VuZGVkLWxnIHAtM1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDBcIj5QaG9uZTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS04MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50R3JvdXA/LnVzZXJfaWQ/LnBob25lX251bWJlciB8fCBcIi1cIn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIHJvdW5kZWQtbGcgcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMFwiPlRpY2tldHM8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwPy50aWNrZXRzIHx8IFwiLVwifVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC00IGZsZXggaXRlbXMtc3RhcnQgZ2FwLTIgYmctZ3JlZW4tNTAgcm91bmRlZC1sZyBwLTMgYm9yZGVyLWwtNCBib3JkZXItZ3JlZW4tNTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8c3ZnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1ncmVlbi01MDAgZmxleC1zaHJpbmstMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2aWV3Qm94PVwiMCAwIDIwIDIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBmaWxsUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNMTggMTBBOCA4IDAgMTE0IDEwYTggOCAwIDAxMTYgMHptLTkgMWwyIDIgNC00XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGlwUnVsZT1cImV2ZW5vZGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyZWVuLTcwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+QWN0aXZhdGlvbiBOb3RpY2U6PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUaGlzIGN1c3RvbWVyIHdpbGwgYmUgcmVzdG9yZWQgdG8gYWN0aXZlIHN0YXR1cyBpbW1lZGlhdGVseS5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIHtjdXJyZW50R3JvdXAgJiYgKFxyXG4gICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlQWN0aXZhdGVFbnJvbGxtZW50fSBjbGFzc05hbWU9XCJtdC02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sLXJldmVyc2Ugc206ZmxleC1yb3cganVzdGlmeS1lbmQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmF0ZU1vZGVsT3BlbihmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcHgtNiBweS0yLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZyBob3ZlcjpiZy1ncmF5LTUwXCJcclxuICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgcHgtNiBweS0yLjUgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIGJnLWdyZWVuLTYwMCByb3VuZGVkLWxnIGhvdmVyOmJnLWdyZWVuLTcwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmctZ3JlZW4tMzAwIHNoYWRvdy1tZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIENvbmZpcm0gQWN0aXZhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgey8qIDxNb2RhbFxyXG4gIGlzVmlzaWJsZT17c2hvd01vZGVsT25Ib2xkfVxyXG4gIG9uQ2xvc2U9eygpID0+IHtcclxuICAgIHNldFNob3dNb2RlbE9uSG9sZChmYWxzZSk7XHJcbiAgICBzZXRDdXJyZW50R3JvdXAobnVsbCk7XHJcbiAgfX1cclxuPlxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTNcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGgtMTIgdy0xMiBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLXllbGxvdy0xMDBcIj5cclxuICAgICAgICA8c3ZnXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJoLTYgdy02IHRleHQteWVsbG93LTYwMFwiXHJcbiAgICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgICBzdHJva2U9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgICAgdmlld0JveD1cIjAgMCAyNCAyNFwiXHJcbiAgICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8cGF0aFxyXG4gICAgICAgICAgICBzdHJva2VMaW5lY2FwPVwicm91bmRcIlxyXG4gICAgICAgICAgICBzdHJva2VMaW5lam9pbj1cInJvdW5kXCJcclxuICAgICAgICAgICAgZD1cIk0xMiA5djRtMCA0aC4wMU0xMC4yOSAzLjg2bC03LjUgMTNBMSAxIDAgMDAzLjY2IDE4aDE2LjY4YTEgMSAwIDAwLjg3LTEuNWwtNy41LTEzYTEgMSAwIDAwLTEuNzQgMHpcIlxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L3N2Zz5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxyXG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgUHV0IEVucm9sbG1lbnQgT24gSG9sZD9cclxuICAgICAgICA8L2gzPlxyXG5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc20gdGV4dC1ncmF5LTYwMFwiPlxyXG4gICAgICAgICAgWW91IGFyZSBhYm91dCB0byBwbGFjZSB0aGlzIGN1c3RvbWVyJ3MgZW5yb2xsbWVudCBvbiBob2xkLlxyXG4gICAgICAgICAgT25jZSBjb25maXJtZWQsIHRoZSBjdXN0b21lciBtYXkgYmUgcmVzdHJpY3RlZCBmcm9tIHBlcmZvcm1pbmdcclxuICAgICAgICAgIGVucm9sbG1lbnQtcmVsYXRlZCBhY3Rpdml0aWVzIHVudGlsIHRoZSBob2xkIHN0YXR1cyBpcyByZW1vdmVkLlxyXG4gICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAge2N1cnJlbnRHcm91cCAmJiAoXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXllbGxvdy0yMDAgYmcteWVsbG93LTUwIHAtNFwiPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS03MDBcIj5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1lZGl1bVwiPkN1c3RvbWVyOjwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAge2N1cnJlbnRHcm91cD8udXNlcl9pZD8uZnVsbF9uYW1lIHx8IFwiLVwifVxyXG4gICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS03MDAgbXQtMVwiPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+R3JvdXA6PC9zcGFuPntcIiBcIn1cclxuICAgICAgICAgICAgICB7Y3VycmVudEdyb3VwPy5ncm91cF9pZD8uZ3JvdXBfbmFtZSB8fCBcIi1cIn1cclxuICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMyB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtcmVkLTYwMFwiPlxyXG4gICAgICAgICAgICAgIFRoaXMgYWN0aW9uIHNob3VsZCBvbmx5IGJlIHBlcmZvcm1lZCBhZnRlciBwcm9wZXIgdmVyaWZpY2F0aW9uLlxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICB7Y3VycmVudEdyb3VwICYmIChcclxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVPbkhvbGRHcm91cH0gY2xhc3NOYW1lPVwibXQtNlwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgZ2FwLTNcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGVsT25Ib2xkKGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgc2V0Q3VycmVudEdyb3VwKG51bGwpO1xyXG4gICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBweC01IHB5LTIuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS03MDAgaG92ZXI6YmctZ3JheS0xMDBcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtbGcgYmcteWVsbG93LTYwMCBweC01IHB5LTIuNSB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtd2hpdGUgaG92ZXI6YmcteWVsbG93LTcwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy00IGZvY3VzOnJpbmcteWVsbG93LTMwMFwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQ29uZmlybSBIb2xkXHJcbiAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgPC9kaXY+XHJcbjwvTW9kYWw+ICovfVxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFbnJvbGw7Il0sImZpbGUiOiJDOi9Vc2Vycy9TWVMgNi9Eb2N1bWVudHMvUHJvamVjdC9wcm9kLWZyb250ZW5kLW15Y2hpdHMtdjIvc3JjL3BhZ2VzL0Vucm9sbC5qc3gifQ==