import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/CustomerAllocation.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Modal from "/src/components/modals/Modal.jsx";
import api from "/src/instance/TokenInstance.js";
import { Input, Dropdown, Select, Spin } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { IoMdMore } from "/node_modules/.vite/deps/react-icons_io.js?v=819e0a34";
import DataTable from "/src/components/layouts/Datatable.jsx";
import filterOption from "/src/helpers/filterOption.js";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import { fieldSize } from "/src/data/fieldSize.js";
const CustomerAllocation = () => {
  _s();
  const [currentCollectionArea, setCurrentCollectionArea] = useState(null);
  const [showModalDelete, setShowModalDelete] = useState(false);
  const [currentUpdateCollectionArea, setCurrentUpdateCollectionArea] = useState(null);
  const [showModalUpdate, setShowModalUpdate] = useState(false);
  const [tableCollectionArea, setTableCollectionArea] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [reloadTrigger, setReloadTrigger] = useState(0);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedArea, setSelectedArea] = useState(null);
  const [selectedRepresentative, setSelectedRepresentative] = useState(null);
  const [collectionArea, setCollectionArea] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [areas, setAreas] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [updateCollectionAreaData, setUpdateCollectionAreaData] = useState({
    route_name: "",
    route_pincode: "",
    agent_id: ""
  });
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    type: "info"
  });
  const [searchText, setSearchText] = useState("");
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const response = await api.get("/employee");
        setEmployees(response?.data?.employee);
      } catch (error) {
        console.error("failed to fetch employees", error);
      }
    };
    fetchEmployees();
  }, []);
  useEffect(() => {
    const fetchCollectionArea = async () => {
      try {
        const response = await api.get(
          "/collection-area-request/get-collection-area-data"
        );
        setAreas(response.data);
      } catch (error) {
        console.error("Error fetching collection area data:", error);
      }
    };
    fetchCollectionArea();
  }, []);
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const usersRes = await api.get("/user/get-user");
        setFilteredUsers(usersRes.data);
      } catch (error) {
        console.error("Error fetching users:", error);
      }
    };
    fetchCustomers();
  }, []);
  useEffect(() => {
    const fetchAreaCollection = async () => {
      try {
        setIsLoading(true);
        const response = await api.get(
          "/collection-area-request/get-customer-allocation"
        );
        setCollectionArea(response.data);
        const collectionAreaData = response?.data.map(
          (collectionArea2, index) => {
            return {
              _id: collectionArea2?._id,
              id: index + 1,
              collection_area_code: collectionArea2?.collection_area_code,
              name: collectionArea2?.route_name,
              pincode: collectionArea2?.route_pincode,
              employee_name: collectionArea2?.agent_id?.map((emp) => emp?.name).join(","),
              employee_phone: collectionArea2?.agent_id?.map((emp) => emp?.phone_number).join(","),
              employee_id: collectionArea2?.agent_id?.map((emp) => emp?.employeeCode).join(","),
              action: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-center gap-2", children: /* @__PURE__ */ jsxDEV(
                Dropdown,
                {
                  trigger: ["click"],
                  menu: {
                    items: [
                      {
                        key: "1",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-green-600",
                            onClick: () => handleUpdateModalOpen(collectionArea2?._id),
                            children: "Edit"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                            lineNumber: 134,
                            columnNumber: 23
                          },
                          this
                        )
                      },
                      {
                        key: "2",
                        label: /* @__PURE__ */ jsxDEV(
                          "div",
                          {
                            className: "text-red-600",
                            onClick: () => handleDeleteModalOpen(collectionArea2?._id),
                            children: "Delete"
                          },
                          void 0,
                          false,
                          {
                            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                            lineNumber: 147,
                            columnNumber: 23
                          },
                          this
                        )
                      }
                    ]
                  },
                  placement: "bottomLeft",
                  children: /* @__PURE__ */ jsxDEV(IoMdMore, { className: "text-bold" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                    lineNumber: 161,
                    columnNumber: 21
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                  lineNumber: 127,
                  columnNumber: 19
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                lineNumber: 126,
                columnNumber: 15
              }, this)
            };
          }
        );
        setTableCollectionArea(collectionAreaData);
      } catch (error) {
        console.error("Error fetching collection area data:", error.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchAreaCollection();
  }, [reloadTrigger]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!selectedCustomer || !selectedArea || !selectedRepresentative) {
      setAlertConfig({
        type: "error",
        message: "Please select Customer, Collection Area, and Representative.",
        visibility: true
      });
      return;
    }
    try {
      const payload = {
        customerId: selectedCustomer._id || selectedCustomer,
        // adjust based on your data structure
        collectionAreaId: selectedArea,
        representativeId: selectedRepresentative
      };
      await api.patch(`/v1/admin/users/customer-allocation/${selectedCustomer._id}`, payload);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        type: "success",
        message: "Customer assigned successfully!",
        visibility: true
      });
      setShowModal(false);
      setSelectedCustomer(null);
      setSelectedArea(null);
      setSelectedRepresentative(null);
    } catch (error) {
      console.error("Error assigning customer:", error);
      const errorMsg = error.response?.data?.message || "An unexpected error occurred. Please try again.";
      setAlertConfig({
        type: "error",
        message: errorMsg,
        visibility: true
      });
    }
  };
  const handleUpdateModalOpen = async (Id) => {
    try {
      const response = await api.get(
        `/collection-area-request/get-collection-area-data-by-id/${Id}`
      );
      setCurrentUpdateCollectionArea(response?.data);
      setUpdateCollectionAreaData({
        agent_id: response?.data?.agent_id,
        route_name: response?.data?.route_name,
        route_pincode: response?.data?.route_pincode
      });
      setShowModalUpdate(true);
    } catch (error) {
      console.error("Error fetching collection area data:", error);
    }
  };
  const handleDeleteModalOpen = async (Id) => {
    try {
      const response = await api.get(
        `/collection-area-request/get-collection-area-data-by-id/${Id}`
      );
      setCurrentCollectionArea(response.data);
      setShowModalDelete(true);
    } catch (error) {
      console.error("Error fetching Collection area Data :", error);
    }
  };
  const handleDeleteCollectionArea = async () => {
    if (currentCollectionArea) {
      try {
        await api.delete(
          `/collection-area-request/delete-collection-area-data-by-id/${currentCollectionArea._id}`
        );
        setAlertConfig({
          visibility: true,
          message: "Collection Area deleted successfully",
          type: "success"
        });
        setReloadTrigger((prev) => prev + 1);
        setShowModalDelete(false);
        setCurrentCollectionArea(null);
      } catch (error) {
        console.error("Error deleting Collection Area:", error);
      }
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      await api.put(
        `/collection-area-request/update-collection-area-data-by-id/${currentUpdateCollectionArea._id}`,
        updateCollectionAreaData
      );
      setShowModalUpdate(false);
      setReloadTrigger((prev) => prev + 1);
      setAlertConfig({
        visibility: true,
        message: "Collection Area Updated Successfully",
        type: "success"
      });
    } catch (error) {
      console.error("Error updating Collection Area:", error);
      const errorMsg = error.response?.data?.message || "An unexpected error occurred. Please try again.";
      setAlertConfig({
        visibility: true,
        message: errorMsg,
        type: "error"
      });
    }
  };
  const columns = [
    { key: "id", header: "SL. NO" },
    { key: "collection_area_code", header: "Collection Code" },
    { key: "name", header: "Collection Area Name" },
    { key: "pincode", header: "pincode" },
    { key: "employee_name", header: "Employee" },
    { key: "employee_phone", header: "Phone Number" },
    { key: "employee_id", header: "Employee Id" },
    { key: "action", header: "Action" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
        lineNumber: 321,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
          lineNumber: 322,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
          lineNumber: 326,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7 overflow-x-auto", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mt-6 mb-8 min-w-max", children: /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center w-full", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: "Customer Allocation" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
            lineNumber: 338,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => {
                setShowModal(true);
              },
              className: "ml-4 bg-violet-950 text-white px-4 py-2 rounded shadow-md hover:bg-violet-800 transition duration-200",
              children: "+ Assign Customer"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
              lineNumber: 340,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
          lineNumber: 337,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
          lineNumber: 336,
          columnNumber: 13
        }, this),
        tableCollectionArea?.length > 0 && !isLoading ? /* @__PURE__ */ jsxDEV(
          DataTable,
          {
            catcher: "_id",
            updateHandler: handleUpdateModalOpen,
            data: filterOption(tableCollectionArea, searchText),
            columns,
            exportedPdfName: "Collection Area",
            exportedFileName: "Collection Area.csv"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
            lineNumber: 351,
            columnNumber: 13
          },
          this
        ) : /* @__PURE__ */ jsxDEV(
          CircularLoader,
          {
            isLoading,
            failure: tableCollectionArea.length <= 0,
            data: " Customer allocation Data "
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
            lineNumber: 360,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
        lineNumber: 335,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
      lineNumber: 320,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Modal, { isVisible: showModal, onClose: () => setShowModal(false), children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
      /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Assign Customer" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
        lineNumber: 372,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleSubmit, noValidate: true, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "mb-2", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-medium text-gray-900 mb-2", children: [
            "Select Customer ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
              lineNumber: 379,
              columnNumber: 35
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
            lineNumber: 378,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "w-full h-10",
              showSearch: true,
              value: selectedCustomer?._id,
              onChange: (value) => {
                const customer = filteredUsers.find((u) => u._id === value);
                setSelectedCustomer(customer);
              },
              placeholder: "Select Customer",
              filterOption: (input, option) => option?.children?.toString().toLowerCase().includes(input.toLowerCase()),
              children: filteredUsers.map(
                (u) => /* @__PURE__ */ jsxDEV(Select.Option, { value: u._id, children: [
                  u?.full_name,
                  " - ",
                  u?.phone_number
                ] }, u._id, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                  lineNumber: 398,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
              lineNumber: 381,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
          lineNumber: 377,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
            "Collection Area ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
              lineNumber: 408,
              columnNumber: 35
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
            lineNumber: 407,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
              placeholder: "Select Collection Area",
              popupMatchSelectWidth: false,
              showSearch: true,
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              value: selectedArea,
              onChange: (value) => setSelectedArea(value),
              children: areas.map(
                (area) => /* @__PURE__ */ jsxDEV(Select.Option, { value: area._id, children: area.route_name }, area._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                  lineNumber: 425,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
              lineNumber: 410,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
          lineNumber: 406,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
            "Collection Representative ",
            /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
              lineNumber: 435,
              columnNumber: 45
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
            lineNumber: 434,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              className: "bg-gray-50 border h-14 border-gray-300 text-gray-900 text-sm rounded-lg w-full",
              placeholder: "Select Representative",
              popupMatchSelectWidth: false,
              showSearch: true,
              filterOption: (input, option) => option.children.toString().toLowerCase().includes(input.toLowerCase()),
              value: selectedRepresentative,
              onChange: (value) => setSelectedRepresentative(value),
              children: employees.map(
                (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: `${emp.name} | ${emp.phone_number}` }, emp._id, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                  lineNumber: 452,
                  columnNumber: 19
                }, this)
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
              lineNumber: 437,
              columnNumber: 17
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
          lineNumber: 433,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
          "button",
          {
            type: "submit",
            className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n                  focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
            children: "Assign Customer"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
            lineNumber: 460,
            columnNumber: 17
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
          lineNumber: 459,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
        lineNumber: 375,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
      lineNumber: 371,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
      lineNumber: 370,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalUpdate,
        onClose: () => setShowModalUpdate(false),
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Update Collection Area" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
            lineNumber: 478,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV("form", { className: "space-y-6", onSubmit: handleUpdate, noValidate: true, children: [
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "rname",
                  children: "Collection Area Name"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                  lineNumber: 483,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "route_name",
                  value: updateCollectionAreaData?.route_name,
                  onChange: (e) => setUpdateCollectionAreaData((prev) => ({
                    ...prev,
                    route_name: e.target.value
                  })),
                  id: "rname",
                  placeholder: "Enter the Collection Area Name",
                  required: true,
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                  lineNumber: 489,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
              lineNumber: 482,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "pincode",
                  children: "Collection Area Pincode"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                  lineNumber: 506,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Input,
                {
                  type: "text",
                  name: "route_pincode",
                  value: updateCollectionAreaData?.route_pincode,
                  onChange: (e) => setUpdateCollectionAreaData((prev) => ({
                    ...prev,
                    route_pincode: e.target.value
                  })),
                  id: "pincode",
                  placeholder: "Enter the Collection Area Pincode",
                  className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                  lineNumber: 512,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
              lineNumber: 505,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { children: [
              /* @__PURE__ */ jsxDEV(
                "label",
                {
                  className: "block mb-2 text-sm font-medium text-gray-900",
                  htmlFor: "pincode",
                  children: "Select Employee"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                  lineNumber: 528,
                  columnNumber: 17
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Select,
                {
                  mode: "tags",
                  size: "large",
                  placeholder: "Select Employee",
                  value: updateCollectionAreaData?.agent_id,
                  onChange: (arrayElement) => setUpdateCollectionAreaData((prev) => ({
                    ...prev,
                    agent_id: arrayElement
                  })),
                  style: { width: "100%" },
                  options: employees.map((emp) => ({
                    label: `${emp.name} (${emp.phone_number})`,
                    value: emp._id
                  }))
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                  lineNumber: 534,
                  columnNumber: 17
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
              lineNumber: 527,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "w-full flex justify-end", children: /* @__PURE__ */ jsxDEV(
              "button",
              {
                type: "submit",
                className: "w-1/4 text-white bg-violet-700 hover:bg-violet-800 border-2 border-black\r\n                  focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                children: "Update"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                lineNumber: 553,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
              lineNumber: 552,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
            lineNumber: 481,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
          lineNumber: 477,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
        lineNumber: 473,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Modal,
      {
        isVisible: showModalDelete,
        onClose: () => {
          setShowModalDelete(false);
          setCurrentCollectionArea(null);
        },
        children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900", children: "Delete Collection Area" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
            lineNumber: 574,
            columnNumber: 13
          }, this),
          currentCollectionArea && /* @__PURE__ */ jsxDEV(
            "form",
            {
              onSubmit: (e) => {
                e.preventDefault();
                handleDeleteCollectionArea();
              },
              className: "space-y-6",
              children: [
                /* @__PURE__ */ jsxDEV("div", { children: [
                  /* @__PURE__ */ jsxDEV(
                    "label",
                    {
                      className: "block mb-2 text-sm font-medium text-gray-900",
                      htmlFor: "groupName",
                      children: [
                        "Please enter",
                        " ",
                        /* @__PURE__ */ jsxDEV("span", { className: "text-primary font-bold", children: currentCollectionArea?.route_name }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                          lineNumber: 591,
                          columnNumber: 21
                        }, this),
                        " ",
                        "to confirm deletion."
                      ]
                    },
                    void 0,
                    true,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                      lineNumber: 586,
                      columnNumber: 19
                    },
                    this
                  ),
                  /* @__PURE__ */ jsxDEV(
                    Input,
                    {
                      type: "text",
                      id: "routeName",
                      placeholder: "Enter the Collection Area Name",
                      required: true,
                      className: `bg-gray-50 border border-gray-300 ${fieldSize.height} text-gray-900 text-sm rounded-lg focus:ring-violet-500 focus:border-violet-500 w-full p-2.5`
                    },
                    void 0,
                    false,
                    {
                      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                      lineNumber: 596,
                      columnNumber: 19
                    },
                    this
                  )
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                  lineNumber: 585,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    className: "w-full text-white bg-red-700 hover:bg-red-800\r\n                  focus:ring-4 focus:outline-none focus:ring-violet-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center",
                    children: "Delete"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
                    lineNumber: 604,
                    columnNumber: 17
                  },
                  this
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
              lineNumber: 578,
              columnNumber: 13
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
          lineNumber: 573,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
        lineNumber: 566,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
    lineNumber: 319,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx",
    lineNumber: 318,
    columnNumber: 5
  }, this);
};
_s(CustomerAllocation, "vaLdNuqsSm/BHp1J1xkfWnxCZuA=");
_c = CustomerAllocation;
export default CustomerAllocation;
var _c;
$RefreshReg$(_c, "CustomerAllocation");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/CustomerAllocation.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUk0QixTQXdMeEIsVUF4THdCOzJCQXJJNUI7QUFBbUJBLG9CQUFpQixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQzNDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxvQkFBb0I7QUFDM0IsT0FBT0MsV0FBVztBQUNsQixPQUFPQyxTQUFTO0FBQ2hCLFNBQVNDLE9BQU9DLFVBQVVDLFFBQVFDLFlBQVk7QUFDOUMsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLHVCQUF1QjtBQUM5QixTQUFTQyxpQkFBaUI7QUFFMUIsTUFBTUMscUJBQXFCQSxNQUFNO0FBQUFDLEtBQUE7QUFFL0IsUUFBTSxDQUFDQyx1QkFBdUJDLHdCQUF3QixJQUFJQyxTQUFTLElBQUk7QUFDdkUsUUFBTSxDQUFDQyxpQkFBaUJDLGtCQUFrQixJQUFJRixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDRyw2QkFBNkJDLDhCQUE4QixJQUNoRUosU0FBUyxJQUFJO0FBQ2YsUUFBTSxDQUFDSyxpQkFBaUJDLGtCQUFrQixJQUFJTixTQUFTLEtBQUs7QUFDNUQsUUFBTSxDQUFDTyxxQkFBcUJDLHNCQUFzQixJQUFJUixTQUFTLEVBQUU7QUFDakUsUUFBTSxDQUFDUyxXQUFXQyxZQUFZLElBQUlWLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNXLFdBQVdDLFlBQVksSUFBSVosU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ2EsV0FBV0MsWUFBWSxJQUFJZCxTQUFTLEtBQUs7QUFDaEQsUUFBTSxDQUFDZSxZQUFZQyxhQUFhLElBQUloQixTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDaUIsZUFBZUMsZ0JBQWdCLElBQUlsQixTQUFTLENBQUM7QUFHcEQsUUFBTSxDQUFDbUIsa0JBQWtCQyxtQkFBbUIsSUFBSXBCLFNBQVMsSUFBSTtBQUM3RCxRQUFNLENBQUNxQixjQUFjQyxlQUFlLElBQUl0QixTQUFTLElBQUk7QUFDckQsUUFBTSxDQUFDdUIsd0JBQXdCQyx5QkFBeUIsSUFBSXhCLFNBQVMsSUFBSTtBQUd6RSxRQUFNLENBQUN5QixnQkFBZ0JDLGlCQUFpQixJQUFJMUIsU0FBUyxFQUFFO0FBQ3ZELFFBQU0sQ0FBQzJCLFdBQVdDLFlBQVksSUFBSTVCLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUM2QixPQUFPQyxRQUFRLElBQUk5QixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDK0IsZUFBZUMsZ0JBQWdCLElBQUloQyxTQUFTLEVBQUU7QUFHckQsUUFBTSxDQUFDaUMsMEJBQTBCQywyQkFBMkIsSUFBSWxDLFNBQVM7QUFBQSxJQUN2RW1DLFlBQVk7QUFBQSxJQUNaQyxlQUFlO0FBQUEsSUFDZkMsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUVELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJdkMsU0FBUztBQUFBLElBQzdDd0MsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBRUQsUUFBTSxDQUFDQyxZQUFZQyxhQUFhLElBQUk1QyxTQUFTLEVBQUU7QUFDL0MsUUFBTTZDLDRCQUE0QkEsQ0FBQ0MsTUFBTTtBQUN2QyxVQUFNLEVBQUVDLE1BQU0sSUFBSUQsRUFBRUU7QUFDcEJKLGtCQUFjRyxLQUFLO0FBQUEsRUFDckI7QUFHQWxFLFlBQVUsTUFBTTtBQUNkLFVBQU1vRSxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YsY0FBTUMsV0FBVyxNQUFNaEUsSUFBSWlFLElBQUksV0FBVztBQUMxQ3ZCLHFCQUFhc0IsVUFBVUUsTUFBTUMsUUFBUTtBQUFBLE1BQ3ZDLFNBQVNDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sNkJBQTZCQSxLQUFLO0FBQUEsTUFDbEQ7QUFBQSxJQUNGO0FBQ0FMLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBR0xwRSxZQUFVLE1BQU07QUFDZCxVQUFNMkUsc0JBQXNCLFlBQVk7QUFDdEMsVUFBSTtBQUNGLGNBQU1OLFdBQVcsTUFBTWhFLElBQUlpRTtBQUFBQSxVQUN6QjtBQUFBLFFBQ0Y7QUFDQXJCLGlCQUFTb0IsU0FBU0UsSUFBSTtBQUFBLE1BQ3hCLFNBQVNFLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sd0NBQXdDQSxLQUFLO0FBQUEsTUFDN0Q7QUFBQSxJQUNGO0FBQ0FFLHdCQUFvQjtBQUFBLEVBQ3RCLEdBQUcsRUFBRTtBQUdMM0UsWUFBVSxNQUFNO0FBQ2QsVUFBTTRFLGlCQUFpQixZQUFZO0FBQ2pDLFVBQUk7QUFDRixjQUFNQyxXQUFXLE1BQU14RSxJQUFJaUUsSUFBSSxnQkFBZ0I7QUFDL0NuQix5QkFBaUIwQixTQUFTTixJQUFJO0FBQUEsTUFDaEMsU0FBU0UsT0FBTztBQUNkQyxnQkFBUUQsTUFBTSx5QkFBeUJBLEtBQUs7QUFBQSxNQUM5QztBQUFBLElBQ0Y7QUFDQUcsbUJBQWU7QUFBQSxFQUNqQixHQUFHLEVBQUU7QUFHTDVFLFlBQVUsTUFBTTtBQUNkLFVBQU04RSxzQkFBc0IsWUFBWTtBQUN0QyxVQUFJO0FBQ0Y3QyxxQkFBYSxJQUFJO0FBQ2pCLGNBQU1vQyxXQUFXLE1BQU1oRSxJQUFJaUU7QUFBQUEsVUFDekI7QUFBQSxRQUNGO0FBQ0F6QiwwQkFBa0J3QixTQUFTRSxJQUFJO0FBQy9CLGNBQU1RLHFCQUFxQlYsVUFBVUUsS0FBS1M7QUFBQUEsVUFDeEMsQ0FBQ3BDLGlCQUFnQnFDLFVBQVU7QUFDekIsbUJBQU87QUFBQSxjQUNMQyxLQUFLdEMsaUJBQWdCc0M7QUFBQUEsY0FDckJDLElBQUlGLFFBQVE7QUFBQSxjQUNaRyxzQkFBc0J4QyxpQkFBZ0J3QztBQUFBQSxjQUN0Q0MsTUFBTXpDLGlCQUFnQlU7QUFBQUEsY0FDdEJnQyxTQUFTMUMsaUJBQWdCVztBQUFBQSxjQUN6QmdDLGVBQWUzQyxpQkFBZ0JZLFVBQzNCd0IsSUFBSSxDQUFDUSxRQUFRQSxLQUFLSCxJQUFJLEVBQ3ZCSSxLQUFLLEdBQUc7QUFBQSxjQUNYQyxnQkFBZ0I5QyxpQkFBZ0JZLFVBQzVCd0IsSUFBSSxDQUFDUSxRQUFRQSxLQUFLRyxZQUFZLEVBQy9CRixLQUFLLEdBQUc7QUFBQSxjQUNYRyxhQUFhaEQsaUJBQWdCWSxVQUN6QndCLElBQUksQ0FBQ1EsUUFBUUEsS0FBS0ssWUFBWSxFQUMvQkosS0FBSyxHQUFHO0FBQUEsY0FDWEssUUFDRSx1QkFBQyxTQUFJLFdBQVUsNkJBQ2I7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUyxDQUFDLE9BQU87QUFBQSxrQkFDakIsTUFBTTtBQUFBLG9CQUNKQyxPQUFPO0FBQUEsc0JBQ0w7QUFBQSx3QkFDRUMsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLE1BQ1BDLHNCQUFzQnRELGlCQUFnQnNDLEdBQUc7QUFBQSw0QkFDMUM7QUFBQTtBQUFBLDBCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFPQTtBQUFBLHNCQUVKO0FBQUEsc0JBQ0E7QUFBQSx3QkFDRWMsS0FBSztBQUFBLHdCQUNMQyxPQUNFO0FBQUEsMEJBQUM7QUFBQTtBQUFBLDRCQUNDLFdBQVU7QUFBQSw0QkFDVixTQUFTLE1BQ1BFLHNCQUFzQnZELGlCQUFnQnNDLEdBQUc7QUFBQSw0QkFDMUM7QUFBQTtBQUFBLDBCQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFPQTtBQUFBLHNCQUVKO0FBQUEsb0JBQUM7QUFBQSxrQkFFTDtBQUFBLGtCQUNBLFdBQVU7QUFBQSxrQkFFVixpQ0FBQyxZQUFTLFdBQVUsZUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBK0I7QUFBQTtBQUFBLGdCQWxDakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBbUNBLEtBcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBcUNBO0FBQUEsWUFFSjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBRUF2RCwrQkFBdUJvRCxrQkFBa0I7QUFBQSxNQUMzQyxTQUFTTixPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLHdDQUF3Q0EsTUFBTWIsT0FBTztBQUFBLE1BQ3JFLFVBQUM7QUFDQzNCLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFDQTZDLHdCQUFvQjtBQUFBLEVBQ3RCLEdBQUcsQ0FBQzFDLGFBQWEsQ0FBQztBQUdsQixRQUFNZ0UsZUFBZSxPQUFPbkMsTUFBTTtBQUNoQ0EsTUFBRW9DLGVBQWU7QUFHakIsUUFBSSxDQUFDL0Qsb0JBQW9CLENBQUNFLGdCQUFnQixDQUFDRSx3QkFBd0I7QUFDakVnQixxQkFBZTtBQUFBLFFBQ2JHLE1BQU07QUFBQSxRQUNORCxTQUFTO0FBQUEsUUFDVEQsWUFBWTtBQUFBLE1BQ2QsQ0FBQztBQUNEO0FBQUEsSUFDRjtBQUVBLFFBQUk7QUFFRixZQUFNMkMsVUFBVTtBQUFBLFFBQ2RDLFlBQVlqRSxpQkFBaUI0QyxPQUFPNUM7QUFBQUE7QUFBQUEsUUFDcENrRSxrQkFBa0JoRTtBQUFBQSxRQUNsQmlFLGtCQUFrQi9EO0FBQUFBLE1BQ3BCO0FBRUEsWUFBTXJDLElBQUlxRyxNQUFNLHVDQUF1Q3BFLGlCQUFpQjRDLEdBQUcsSUFBS29CLE9BQU87QUFFdkZqRSx1QkFBaUIsQ0FBQ3NFLFNBQVNBLE9BQU8sQ0FBQztBQUNuQ2pELHFCQUFlO0FBQUEsUUFDYkcsTUFBTTtBQUFBLFFBQ05ELFNBQVM7QUFBQSxRQUNURCxZQUFZO0FBQUEsTUFDZCxDQUFDO0FBR0Q1QixtQkFBYSxLQUFLO0FBQ2xCUSwwQkFBb0IsSUFBSTtBQUN4QkUsc0JBQWdCLElBQUk7QUFDcEJFLGdDQUEwQixJQUFJO0FBQUEsSUFDaEMsU0FBUzhCLE9BQU87QUFDZEMsY0FBUUQsTUFBTSw2QkFBNkJBLEtBQUs7QUFDaEQsWUFBTW1DLFdBQ0puQyxNQUFNSixVQUFVRSxNQUFNWCxXQUN0QjtBQUNGRixxQkFBZTtBQUFBLFFBQ2JHLE1BQU07QUFBQSxRQUNORCxTQUFTZ0Q7QUFBQUEsUUFDVGpELFlBQVk7QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUdBLFFBQU11Qyx3QkFBd0IsT0FBT1csT0FBTztBQUMxQyxRQUFJO0FBQ0YsWUFBTXhDLFdBQVcsTUFBTWhFLElBQUlpRTtBQUFBQSxRQUN6QiwyREFBMkR1QyxFQUFFO0FBQUEsTUFDL0Q7QUFDQXRGLHFDQUErQjhDLFVBQVVFLElBQUk7QUFDN0NsQixrQ0FBNEI7QUFBQSxRQUMxQkcsVUFBVWEsVUFBVUUsTUFBTWY7QUFBQUEsUUFDMUJGLFlBQVllLFVBQVVFLE1BQU1qQjtBQUFBQSxRQUM1QkMsZUFBZWMsVUFBVUUsTUFBTWhCO0FBQUFBLE1BQ2pDLENBQUM7QUFDRDlCLHlCQUFtQixJQUFJO0FBQUEsSUFDekIsU0FBU2dELE9BQU87QUFDZEMsY0FBUUQsTUFBTSx3Q0FBd0NBLEtBQUs7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFFQSxRQUFNMEIsd0JBQXdCLE9BQU9VLE9BQU87QUFDMUMsUUFBSTtBQUNGLFlBQU14QyxXQUFXLE1BQU1oRSxJQUFJaUU7QUFBQUEsUUFDekIsMkRBQTJEdUMsRUFBRTtBQUFBLE1BQy9EO0FBQ0EzRiwrQkFBeUJtRCxTQUFTRSxJQUFJO0FBQ3RDbEQseUJBQW1CLElBQUk7QUFBQSxJQUN6QixTQUFTb0QsT0FBTztBQUNkQyxjQUFRRCxNQUFNLHlDQUF5Q0EsS0FBSztBQUFBLElBQzlEO0FBQUEsRUFDRjtBQUVBLFFBQU1xQyw2QkFBNkIsWUFBWTtBQUM3QyxRQUFJN0YsdUJBQXVCO0FBQ3pCLFVBQUk7QUFDRixjQUFNWixJQUFJMEc7QUFBQUEsVUFDUiw4REFBOEQ5RixzQkFBc0JpRSxHQUFHO0FBQUEsUUFDekY7QUFDQXhCLHVCQUFlO0FBQUEsVUFDYkMsWUFBWTtBQUFBLFVBQ1pDLFNBQVM7QUFBQSxVQUNUQyxNQUFNO0FBQUEsUUFDUixDQUFDO0FBQ0R4Qix5QkFBaUIsQ0FBQ3NFLFNBQVNBLE9BQU8sQ0FBQztBQUNuQ3RGLDJCQUFtQixLQUFLO0FBQ3hCSCxpQ0FBeUIsSUFBSTtBQUFBLE1BQy9CLFNBQVN1RCxPQUFPO0FBQ2RDLGdCQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUFBLE1BQ3hEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNdUMsZUFBZSxPQUFPL0MsTUFBTTtBQUNoQ0EsTUFBRW9DLGVBQWU7QUFDakIsUUFBSTtBQUNGLFlBQU1oRyxJQUFJNEc7QUFBQUEsUUFDUiw4REFBOEQzRiw0QkFBNEI0RCxHQUFHO0FBQUEsUUFDN0Y5QjtBQUFBQSxNQUNGO0FBQ0EzQix5QkFBbUIsS0FBSztBQUN4QlksdUJBQWlCLENBQUNzRSxTQUFTQSxPQUFPLENBQUM7QUFDbkNqRCxxQkFBZTtBQUFBLFFBQ2JDLFlBQVk7QUFBQSxRQUNaQyxTQUFTO0FBQUEsUUFDVEMsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0gsU0FBU1ksT0FBTztBQUNkQyxjQUFRRCxNQUFNLG1DQUFtQ0EsS0FBSztBQUN0RCxZQUFNbUMsV0FDSm5DLE1BQU1KLFVBQVVFLE1BQU1YLFdBQ3RCO0FBQ0ZGLHFCQUFlO0FBQUEsUUFDYkMsWUFBWTtBQUFBLFFBQ1pDLFNBQVNnRDtBQUFBQSxRQUNUL0MsTUFBTTtBQUFBLE1BQ1IsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBR0EsUUFBTXFELFVBQVU7QUFBQSxJQUNkLEVBQUVsQixLQUFLLE1BQU1tQixRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFbkIsS0FBSyx3QkFBd0JtQixRQUFRLGtCQUFrQjtBQUFBLElBQ3pELEVBQUVuQixLQUFLLFFBQVFtQixRQUFRLHVCQUF1QjtBQUFBLElBQzlDLEVBQUVuQixLQUFLLFdBQVdtQixRQUFRLFVBQVU7QUFBQSxJQUNwQyxFQUFFbkIsS0FBSyxpQkFBaUJtQixRQUFRLFdBQVc7QUFBQSxJQUMzQyxFQUFFbkIsS0FBSyxrQkFBa0JtQixRQUFRLGVBQWU7QUFBQSxJQUNoRCxFQUFFbkIsS0FBSyxlQUFlbUIsUUFBUSxjQUFjO0FBQUEsSUFDNUMsRUFBRW5CLEtBQUssVUFBVW1CLFFBQVEsU0FBUztBQUFBLEVBQUM7QUFHckMsU0FDRSxtQ0FDRSxpQ0FBQyxTQUNDO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2I7QUFBQSw2QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUTtBQUFBLE1BQ1I7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLDZCQUE2Qm5EO0FBQUFBLFVBQzdCLFlBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1CO0FBQUEsTUFFbkI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1QLFlBQVlJO0FBQUFBLFVBQ2xCLFdBQVdKLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFVBQ3JCLFNBQVMsTUFDUEYsZUFBZSxDQUFDaUQsVUFBVSxFQUFFLEdBQUdBLE1BQU1oRCxZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUdILHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx1QkFDYixpQ0FBQyxTQUFJLFdBQVUsNENBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsMEJBQXlCLG1DQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUEwRDtBQUFBLFVBRTFEO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFTLE1BQU07QUFDYjVCLDZCQUFhLElBQUk7QUFBQSxjQUNuQjtBQUFBLGNBQ0EsV0FBVTtBQUFBLGNBQXVHO0FBQUE7QUFBQSxZQUpuSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPQTtBQUFBLGFBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWFBO0FBQUEsUUFDQ0wscUJBQXFCMEYsU0FBUyxLQUFLLENBQUNwRixZQUNuQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsZUFBZWtFO0FBQUFBLFlBQ2YsTUFBTXRGLGFBQWFjLHFCQUFxQm9DLFVBQVU7QUFBQSxZQUNsRDtBQUFBLFlBQ0EsaUJBQWdCO0FBQUEsWUFDaEIsa0JBQWlCO0FBQUE7QUFBQSxVQU5uQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNd0MsSUFHeEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxTQUFTcEMsb0JBQW9CMEYsVUFBVTtBQUFBLFlBQ3ZDLE1BQUs7QUFBQTtBQUFBLFVBSFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR21DO0FBQUEsV0E1QnZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErQkE7QUFBQSxTQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0NBO0FBQUEsSUFHQSx1QkFBQyxTQUFNLFdBQVd0RixXQUFXLFNBQVMsTUFBTUMsYUFBYSxLQUFLLEdBQzVELGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLDZCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsK0JBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVXFFLGNBQWMsWUFBVSxNQUU1RDtBQUFBLCtCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsWUFDOUMsdUJBQUMsVUFBSyxXQUFVLGdCQUFlLGlCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFnQztBQUFBLGVBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxXQUFVO0FBQUEsY0FDVjtBQUFBLGNBQ0EsT0FBTzlELGtCQUFrQjRDO0FBQUFBLGNBQ3pCLFVBQVUsQ0FBQ2hCLFVBQVU7QUFDbkIsc0JBQU1tRCxXQUFXbkUsY0FBY29FLEtBQUssQ0FBQ0MsTUFBTUEsRUFBRXJDLFFBQVFoQixLQUFLO0FBQzFEM0Isb0NBQW9COEUsUUFBUTtBQUFBLGNBQzlCO0FBQUEsY0FDQSxhQUFZO0FBQUEsY0FDWixjQUFjLENBQUNHLE9BQU9DLFdBQ3BCQSxRQUFRQyxVQUNKQyxTQUFTLEVBQ1ZDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsY0FHaEMxRSx3QkFBYzhCO0FBQUFBLGdCQUFJLENBQUN1QyxNQUNsQix1QkFBQyxPQUFPLFFBQVAsRUFBMEIsT0FBT0EsRUFBRXJDLEtBQ2pDcUM7QUFBQUEscUJBQUdPO0FBQUFBLGtCQUFVO0FBQUEsa0JBQUlQLEdBQUc1QjtBQUFBQSxxQkFESDRCLEVBQUVyQyxLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBcUJBO0FBQUEsYUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTBCQTtBQUFBLFFBR0EsdUJBQUMsU0FDQztBQUFBLGlDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLFlBQzlDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxlQURsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBLGNBQ1osdUJBQXVCO0FBQUEsY0FDdkI7QUFBQSxjQUNBLGNBQWMsQ0FBQ3NDLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsY0FFakMsT0FBT3BGO0FBQUFBLGNBQ1AsVUFBVSxDQUFDMEIsVUFBVXpCLGdCQUFnQnlCLEtBQUs7QUFBQSxjQUV6Q2xCLGdCQUFNZ0M7QUFBQUEsZ0JBQUksQ0FBQytDLFNBQ1YsdUJBQUMsT0FBTyxRQUFQLEVBQTZCLE9BQU9BLEtBQUs3QyxLQUN2QzZDLGVBQUt6RSxjQURZeUUsS0FBSzdDLEtBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxjQUNEO0FBQUE7QUFBQSxZQWxCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFtQkE7QUFBQSxhQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFHQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLFlBQ3BDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBZ0M7QUFBQSxlQUQ1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsYUFBWTtBQUFBLGNBQ1osdUJBQXVCO0FBQUEsY0FDdkI7QUFBQSxjQUNBLGNBQWMsQ0FBQ3NDLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUNKQyxTQUFTLEVBQ1RDLFlBQVksRUFDWkMsU0FBU0wsTUFBTUksWUFBWSxDQUFDO0FBQUEsY0FFakMsT0FBT2xGO0FBQUFBLGNBQ1AsVUFBVSxDQUFDd0IsVUFBVXZCLDBCQUEwQnVCLEtBQUs7QUFBQSxjQUVuRHBCLG9CQUFVa0M7QUFBQUEsZ0JBQUksQ0FBQ1EsUUFDZCx1QkFBQyxPQUFPLFFBQVAsRUFBNEIsT0FBT0EsSUFBSU4sS0FDckMsYUFBR00sSUFBSUgsSUFBSSxNQUFNRyxJQUFJRyxZQUFZLE1BRGhCSCxJQUFJTixLQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsY0FDRDtBQUFBO0FBQUEsWUFsQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBbUJBO0FBQUEsYUF2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDJCQUNiO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxXQUFVO0FBQUEsWUFDbUc7QUFBQTtBQUFBLFVBSC9HO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0E1RkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTZGQTtBQUFBLFNBakdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrR0EsS0FuR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9HQTtBQUFBLElBR0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFdBQVcxRDtBQUFBQSxRQUNYLFNBQVMsTUFBTUMsbUJBQW1CLEtBQUs7QUFBQSxRQUV2QyxpQ0FBQyxTQUFJLFdBQVUsK0JBQ2I7QUFBQSxpQ0FBQyxRQUFHLFdBQVUsd0NBQXVDLHNDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxVQUFLLFdBQVUsYUFBWSxVQUFVdUYsY0FBYyxZQUFVLE1BQzVEO0FBQUEsbUNBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQU87QUFBQTtBQUFBLGdCQUZqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPNUQsMEJBQTBCRTtBQUFBQSxrQkFDakMsVUFBVSxDQUFDVyxNQUNUWiw0QkFBNEIsQ0FBQ3NELFVBQVU7QUFBQSxvQkFDckMsR0FBR0E7QUFBQUEsb0JBQ0hyRCxZQUFZVyxFQUFFRSxPQUFPRDtBQUFBQSxrQkFDdkIsRUFBRTtBQUFBLGtCQUVKLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1o7QUFBQSxrQkFDQSxXQUFXLHFDQUFxQ3BELFVBQVVrSCxNQUFNO0FBQUE7QUFBQSxnQkFibEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYWlLO0FBQUEsaUJBcEJuSztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXNCQTtBQUFBLFlBQ0EsdUJBQUMsU0FDQztBQUFBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVU7QUFBQSxrQkFDVixTQUFRO0FBQUEsa0JBQVM7QUFBQTtBQUFBLGdCQUZuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FLQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsTUFBSztBQUFBLGtCQUNMLE1BQUs7QUFBQSxrQkFDTCxPQUFPNUUsMEJBQTBCRztBQUFBQSxrQkFDakMsVUFBVSxDQUFDVSxNQUNUWiw0QkFBNEIsQ0FBQ3NELFVBQVU7QUFBQSxvQkFDckMsR0FBR0E7QUFBQUEsb0JBQ0hwRCxlQUFlVSxFQUFFRSxPQUFPRDtBQUFBQSxrQkFDMUIsRUFBRTtBQUFBLGtCQUVKLElBQUc7QUFBQSxrQkFDSCxhQUFZO0FBQUEsa0JBQ1osV0FBVyxxQ0FBcUNwRCxVQUFVa0gsTUFBTTtBQUFBO0FBQUEsZ0JBWmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQVlpSztBQUFBLGlCQW5Cbks7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFxQkE7QUFBQSxZQUNBLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFVO0FBQUEsa0JBQ1YsU0FBUTtBQUFBLGtCQUFTO0FBQUE7QUFBQSxnQkFGbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBS0E7QUFBQSxjQUNBO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLE1BQUs7QUFBQSxrQkFDTCxNQUFNO0FBQUEsa0JBQ04sYUFBWTtBQUFBLGtCQUNaLE9BQU81RSwwQkFBMEJJO0FBQUFBLGtCQUNqQyxVQUFVLENBQUN5RSxpQkFDVDVFLDRCQUE0QixDQUFDc0QsVUFBVTtBQUFBLG9CQUNyQyxHQUFHQTtBQUFBQSxvQkFDSG5ELFVBQVV5RTtBQUFBQSxrQkFDWixFQUFFO0FBQUEsa0JBRUosT0FBTyxFQUFFQyxPQUFPLE9BQU87QUFBQSxrQkFDdkIsU0FBU3BGLFVBQVVrQyxJQUFJLENBQUNRLFNBQVM7QUFBQSxvQkFDL0JTLE9BQU8sR0FBR1QsSUFBSUgsSUFBSSxLQUFLRyxJQUFJRyxZQUFZO0FBQUEsb0JBQ3ZDekIsT0FBT3NCLElBQUlOO0FBQUFBLGtCQUNiLEVBQUU7QUFBQTtBQUFBLGdCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWVNO0FBQUEsaUJBdEJSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBd0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsMkJBQ2I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxNQUFLO0FBQUEsZ0JBQ0wsV0FBVTtBQUFBLGdCQUNtRztBQUFBO0FBQUEsY0FIL0c7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUEsZUEvRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnRkE7QUFBQSxhQXBGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcUZBO0FBQUE7QUFBQSxNQXpGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUEwRkE7QUFBQSxJQUdBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxXQUFXOUQ7QUFBQUEsUUFDWCxTQUFTLE1BQU07QUFDYkMsNkJBQW1CLEtBQUs7QUFDeEJILG1DQUF5QixJQUFJO0FBQUEsUUFDL0I7QUFBQSxRQUVBLGlDQUFDLFNBQUksV0FBVSwrQkFDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSx3Q0FBdUMsc0NBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNDRCx5QkFDQztBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsVUFBVSxDQUFDZ0QsTUFBTTtBQUNmQSxrQkFBRW9DLGVBQWU7QUFDakJTLDJDQUEyQjtBQUFBLGNBQzdCO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFNBQ0M7QUFBQTtBQUFBLG9CQUFDO0FBQUE7QUFBQSxzQkFDQyxXQUFVO0FBQUEsc0JBQ1YsU0FBUTtBQUFBLHNCQUFXO0FBQUE7QUFBQSx3QkFFTjtBQUFBLHdCQUNiLHVCQUFDLFVBQUssV0FBVSwwQkFDYjdGLGlDQUF1QnFDLGNBRDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRUE7QUFBQSx3QkFBUTtBQUFBLHdCQUFJO0FBQUE7QUFBQTtBQUFBLG9CQVBkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFTQTtBQUFBLGtCQUNBO0FBQUEsb0JBQUM7QUFBQTtBQUFBLHNCQUNDLE1BQUs7QUFBQSxzQkFDTCxJQUFHO0FBQUEsc0JBQ0gsYUFBWTtBQUFBLHNCQUNaO0FBQUEsc0JBQ0EsV0FBVyxxQ0FBcUN4QyxVQUFVa0gsTUFBTTtBQUFBO0FBQUEsb0JBTGxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFLaUs7QUFBQSxxQkFoQm5LO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBa0JBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFdBQVU7QUFBQSxvQkFDbUc7QUFBQTtBQUFBLGtCQUgvRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQTtBQUFBO0FBQUEsWUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBaUNBO0FBQUEsYUF0Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdDQTtBQUFBO0FBQUEsTUEvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0RBO0FBQUEsT0F2U0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdTQSxLQXpTRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMFNBO0FBRUo7QUFBRWhILEdBNWxCSUQsb0JBQWtCO0FBQUFvSCxLQUFsQnBIO0FBOGxCTixlQUFlQTtBQUFtQixJQUFBb0g7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsIlNpZGViYXIiLCJOYXZiYXIiLCJDaXJjdWxhckxvYWRlciIsIk1vZGFsIiwiYXBpIiwiSW5wdXQiLCJEcm9wZG93biIsIlNlbGVjdCIsIlNwaW4iLCJJb01kTW9yZSIsIkRhdGFUYWJsZSIsImZpbHRlck9wdGlvbiIsIkN1c3RvbUFsZXJ0RGlhbG9nIiwiZmllbGRTaXplIiwiQ3VzdG9tZXJBbGxvY2F0aW9uIiwiX3MiLCJjdXJyZW50Q29sbGVjdGlvbkFyZWEiLCJzZXRDdXJyZW50Q29sbGVjdGlvbkFyZWEiLCJ1c2VTdGF0ZSIsInNob3dNb2RhbERlbGV0ZSIsInNldFNob3dNb2RhbERlbGV0ZSIsImN1cnJlbnRVcGRhdGVDb2xsZWN0aW9uQXJlYSIsInNldEN1cnJlbnRVcGRhdGVDb2xsZWN0aW9uQXJlYSIsInNob3dNb2RhbFVwZGF0ZSIsInNldFNob3dNb2RhbFVwZGF0ZSIsInRhYmxlQ29sbGVjdGlvbkFyZWEiLCJzZXRUYWJsZUNvbGxlY3Rpb25BcmVhIiwiY3VzdG9tZXJzIiwic2V0Q3VzdG9tZXJzIiwic2hvd01vZGFsIiwic2V0U2hvd01vZGFsIiwiaXNMb2FkaW5nIiwic2V0SXNMb2FkaW5nIiwic2VhcmNoVGVybSIsInNldFNlYXJjaFRlcm0iLCJyZWxvYWRUcmlnZ2VyIiwic2V0UmVsb2FkVHJpZ2dlciIsInNlbGVjdGVkQ3VzdG9tZXIiLCJzZXRTZWxlY3RlZEN1c3RvbWVyIiwic2VsZWN0ZWRBcmVhIiwic2V0U2VsZWN0ZWRBcmVhIiwic2VsZWN0ZWRSZXByZXNlbnRhdGl2ZSIsInNldFNlbGVjdGVkUmVwcmVzZW50YXRpdmUiLCJjb2xsZWN0aW9uQXJlYSIsInNldENvbGxlY3Rpb25BcmVhIiwiZW1wbG95ZWVzIiwic2V0RW1wbG95ZWVzIiwiYXJlYXMiLCJzZXRBcmVhcyIsImZpbHRlcmVkVXNlcnMiLCJzZXRGaWx0ZXJlZFVzZXJzIiwidXBkYXRlQ29sbGVjdGlvbkFyZWFEYXRhIiwic2V0VXBkYXRlQ29sbGVjdGlvbkFyZWFEYXRhIiwicm91dGVfbmFtZSIsInJvdXRlX3BpbmNvZGUiLCJhZ2VudF9pZCIsImFsZXJ0Q29uZmlnIiwic2V0QWxlcnRDb25maWciLCJ2aXNpYmlsaXR5IiwibWVzc2FnZSIsInR5cGUiLCJzZWFyY2hUZXh0Iiwic2V0U2VhcmNoVGV4dCIsIkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJmZXRjaEVtcGxveWVlcyIsInJlc3BvbnNlIiwiZ2V0IiwiZGF0YSIsImVtcGxveWVlIiwiZXJyb3IiLCJjb25zb2xlIiwiZmV0Y2hDb2xsZWN0aW9uQXJlYSIsImZldGNoQ3VzdG9tZXJzIiwidXNlcnNSZXMiLCJmZXRjaEFyZWFDb2xsZWN0aW9uIiwiY29sbGVjdGlvbkFyZWFEYXRhIiwibWFwIiwiaW5kZXgiLCJfaWQiLCJpZCIsImNvbGxlY3Rpb25fYXJlYV9jb2RlIiwibmFtZSIsInBpbmNvZGUiLCJlbXBsb3llZV9uYW1lIiwiZW1wIiwiam9pbiIsImVtcGxveWVlX3Bob25lIiwicGhvbmVfbnVtYmVyIiwiZW1wbG95ZWVfaWQiLCJlbXBsb3llZUNvZGUiLCJhY3Rpb24iLCJpdGVtcyIsImtleSIsImxhYmVsIiwiaGFuZGxlVXBkYXRlTW9kYWxPcGVuIiwiaGFuZGxlRGVsZXRlTW9kYWxPcGVuIiwiaGFuZGxlU3VibWl0IiwicHJldmVudERlZmF1bHQiLCJwYXlsb2FkIiwiY3VzdG9tZXJJZCIsImNvbGxlY3Rpb25BcmVhSWQiLCJyZXByZXNlbnRhdGl2ZUlkIiwicGF0Y2giLCJwcmV2IiwiZXJyb3JNc2ciLCJJZCIsImhhbmRsZURlbGV0ZUNvbGxlY3Rpb25BcmVhIiwiZGVsZXRlIiwiaGFuZGxlVXBkYXRlIiwicHV0IiwiY29sdW1ucyIsImhlYWRlciIsImxlbmd0aCIsImN1c3RvbWVyIiwiZmluZCIsInUiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwidG9TdHJpbmciLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwiZnVsbF9uYW1lIiwiYXJlYSIsImhlaWdodCIsImFycmF5RWxlbWVudCIsIndpZHRoIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiQ3VzdG9tZXJBbGxvY2F0aW9uLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgTmF2YmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvTmF2YmFyXCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IGFwaSBmcm9tIFwiLi4vaW5zdGFuY2UvVG9rZW5JbnN0YW5jZVwiO1xyXG5pbXBvcnQgeyBJbnB1dCwgRHJvcGRvd24sIFNlbGVjdCwgU3BpbiB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IElvTWRNb3JlIH0gZnJvbSBcInJlYWN0LWljb25zL2lvXCI7XHJcbmltcG9ydCBEYXRhVGFibGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9EYXRhdGFibGVcIjtcclxuaW1wb3J0IGZpbHRlck9wdGlvbiBmcm9tIFwiLi4vaGVscGVycy9maWx0ZXJPcHRpb25cIjtcclxuaW1wb3J0IEN1c3RvbUFsZXJ0RGlhbG9nIGZyb20gXCIuLi9jb21wb25lbnRzL2FsZXJ0cy9DdXN0b21BbGVydERpYWxvZ1wiO1xyXG5pbXBvcnQgeyBmaWVsZFNpemUgfSBmcm9tIFwiLi4vZGF0YS9maWVsZFNpemVcIjtcclxuXHJcbmNvbnN0IEN1c3RvbWVyQWxsb2NhdGlvbiA9ICgpID0+IHtcclxuICAvLyBTdGF0ZXMgZm9yIG1vZGFscyBhbmQgZGF0YVxyXG4gIGNvbnN0IFtjdXJyZW50Q29sbGVjdGlvbkFyZWEsIHNldEN1cnJlbnRDb2xsZWN0aW9uQXJlYV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2hvd01vZGFsRGVsZXRlLCBzZXRTaG93TW9kYWxEZWxldGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtjdXJyZW50VXBkYXRlQ29sbGVjdGlvbkFyZWEsIHNldEN1cnJlbnRVcGRhdGVDb2xsZWN0aW9uQXJlYV0gPVxyXG4gICAgdXNlU3RhdGUobnVsbCk7XHJcbiAgY29uc3QgW3Nob3dNb2RhbFVwZGF0ZSwgc2V0U2hvd01vZGFsVXBkYXRlXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbdGFibGVDb2xsZWN0aW9uQXJlYSwgc2V0VGFibGVDb2xsZWN0aW9uQXJlYV0gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2N1c3RvbWVycywgc2V0Q3VzdG9tZXJzXSA9IHVzZVN0YXRlKFtdKTsgLy8gTWlnaHQgYmUgdXNlZCBsYXRlclxyXG4gIGNvbnN0IFtzaG93TW9kYWwsIHNldFNob3dNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc2VhcmNoVGVybSwgc2V0U2VhcmNoVGVybV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcmVsb2FkVHJpZ2dlciwgc2V0UmVsb2FkVHJpZ2dlcl0gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgLy8gU3RhdGVzIGZvciB0aGUgYWRkIG1vZGFsIGZpZWxkc1xyXG4gIGNvbnN0IFtzZWxlY3RlZEN1c3RvbWVyLCBzZXRTZWxlY3RlZEN1c3RvbWVyXSA9IHVzZVN0YXRlKG51bGwpO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEFyZWEsIHNldFNlbGVjdGVkQXJlYV0gPSB1c2VTdGF0ZShudWxsKTtcclxuICBjb25zdCBbc2VsZWN0ZWRSZXByZXNlbnRhdGl2ZSwgc2V0U2VsZWN0ZWRSZXByZXNlbnRhdGl2ZV0gPSB1c2VTdGF0ZShudWxsKTtcclxuXHJcbiAgLy8gRGF0YSBmcm9tIEFQSVxyXG4gIGNvbnN0IFtjb2xsZWN0aW9uQXJlYSwgc2V0Q29sbGVjdGlvbkFyZWFdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtlbXBsb3llZXMsIHNldEVtcGxveWVlc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2FyZWFzLCBzZXRBcmVhc10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW2ZpbHRlcmVkVXNlcnMsIHNldEZpbHRlcmVkVXNlcnNdID0gdXNlU3RhdGUoW10pOyAvLyBmb3IgY3VzdG9tZXIgZHJvcGRvd25cclxuXHJcbiAgLy8gVXBkYXRlIG1vZGFsIHN0YXRlXHJcbiAgY29uc3QgW3VwZGF0ZUNvbGxlY3Rpb25BcmVhRGF0YSwgc2V0VXBkYXRlQ29sbGVjdGlvbkFyZWFEYXRhXSA9IHVzZVN0YXRlKHtcclxuICAgIHJvdXRlX25hbWU6IFwiXCIsXHJcbiAgICByb3V0ZV9waW5jb2RlOiBcIlwiLFxyXG4gICAgYWdlbnRfaWQ6IFwiXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFthbGVydENvbmZpZywgc2V0QWxlcnRDb25maWddID0gdXNlU3RhdGUoe1xyXG4gICAgdmlzaWJpbGl0eTogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiLFxyXG4gICAgdHlwZTogXCJpbmZvXCIsXHJcbiAgfSk7XHJcblxyXG4gIGNvbnN0IFtzZWFyY2hUZXh0LCBzZXRTZWFyY2hUZXh0XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IEdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIgPSAoZSkgPT4ge1xyXG4gICAgY29uc3QgeyB2YWx1ZSB9ID0gZS50YXJnZXQ7XHJcbiAgICBzZXRTZWFyY2hUZXh0KHZhbHVlKTtcclxuICB9O1xyXG5cclxuICAvLyBGZXRjaCBlbXBsb3llZXMgKHJlcHJlc2VudGF0aXZlcylcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICAgIHNldEVtcGxveWVlcyhyZXNwb25zZT8uZGF0YT8uZW1wbG95ZWUpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJmYWlsZWQgdG8gZmV0Y2ggZW1wbG95ZWVzXCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoRW1wbG95ZWVzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBGZXRjaCBjb2xsZWN0aW9uIGFyZWFzXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGZldGNoQ29sbGVjdGlvbkFyZWEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgICAgXCIvY29sbGVjdGlvbi1hcmVhLXJlcXVlc3QvZ2V0LWNvbGxlY3Rpb24tYXJlYS1kYXRhXCJcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldEFyZWFzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjb2xsZWN0aW9uIGFyZWEgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgZmV0Y2hDb2xsZWN0aW9uQXJlYSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgLy8gRmV0Y2ggY3VzdG9tZXJzICh1c2VycylcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgZmV0Y2hDdXN0b21lcnMgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgdXNlcnNSZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL3VzZXIvZ2V0LXVzZXJcIik7XHJcbiAgICAgICAgc2V0RmlsdGVyZWRVc2Vycyh1c2Vyc1Jlcy5kYXRhKTtcclxuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgdXNlcnM6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQ3VzdG9tZXJzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICAvLyBGZXRjaCB0YWJsZSBkYXRhIChhc3NpZ25tZW50cykgLSByZXVzaW5nIGNvbGxlY3Rpb24gYXJlYSB0YWJsZSBmb3IgZGVtb1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEFyZWFDb2xsZWN0aW9uID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgICBcIi9jb2xsZWN0aW9uLWFyZWEtcmVxdWVzdC9nZXQtY3VzdG9tZXItYWxsb2NhdGlvblwiXHJcbiAgICAgICAgKTtcclxuICAgICAgICBzZXRDb2xsZWN0aW9uQXJlYShyZXNwb25zZS5kYXRhKTtcclxuICAgICAgICBjb25zdCBjb2xsZWN0aW9uQXJlYURhdGEgPSByZXNwb25zZT8uZGF0YS5tYXAoXHJcbiAgICAgICAgICAoY29sbGVjdGlvbkFyZWEsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgX2lkOiBjb2xsZWN0aW9uQXJlYT8uX2lkLFxyXG4gICAgICAgICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgICAgICAgY29sbGVjdGlvbl9hcmVhX2NvZGU6IGNvbGxlY3Rpb25BcmVhPy5jb2xsZWN0aW9uX2FyZWFfY29kZSxcclxuICAgICAgICAgICAgICBuYW1lOiBjb2xsZWN0aW9uQXJlYT8ucm91dGVfbmFtZSxcclxuICAgICAgICAgICAgICBwaW5jb2RlOiBjb2xsZWN0aW9uQXJlYT8ucm91dGVfcGluY29kZSxcclxuICAgICAgICAgICAgICBlbXBsb3llZV9uYW1lOiBjb2xsZWN0aW9uQXJlYT8uYWdlbnRfaWRcclxuICAgICAgICAgICAgICAgID8ubWFwKChlbXApID0+IGVtcD8ubmFtZSlcclxuICAgICAgICAgICAgICAgIC5qb2luKFwiLFwiKSxcclxuICAgICAgICAgICAgICBlbXBsb3llZV9waG9uZTogY29sbGVjdGlvbkFyZWE/LmFnZW50X2lkXHJcbiAgICAgICAgICAgICAgICA/Lm1hcCgoZW1wKSA9PiBlbXA/LnBob25lX251bWJlcilcclxuICAgICAgICAgICAgICAgIC5qb2luKFwiLFwiKSxcclxuICAgICAgICAgICAgICBlbXBsb3llZV9pZDogY29sbGVjdGlvbkFyZWE/LmFnZW50X2lkXHJcbiAgICAgICAgICAgICAgICA/Lm1hcCgoZW1wKSA9PiBlbXA/LmVtcGxveWVlQ29kZSlcclxuICAgICAgICAgICAgICAgIC5qb2luKFwiLFwiKSxcclxuICAgICAgICAgICAgICBhY3Rpb246IChcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxyXG4gICAgICAgICAgICAgICAgICA8RHJvcGRvd25cclxuICAgICAgICAgICAgICAgICAgICB0cmlnZ2VyPXtbXCJjbGlja1wiXX1cclxuICAgICAgICAgICAgICAgICAgICBtZW51PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICBpdGVtczogW1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIjFcIixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWdyZWVuLTYwMFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlVXBkYXRlTW9kYWxPcGVuKGNvbGxlY3Rpb25BcmVhPy5faWQpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRWRpdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCIyXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXZcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVNb2RhbE9wZW4oY29sbGVjdGlvbkFyZWE/Ll9pZClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZWxldGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICBdLFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2VtZW50PVwiYm90dG9tTGVmdFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8SW9NZE1vcmUgY2xhc3NOYW1lPVwidGV4dC1ib2xkXCIgLz5cclxuICAgICAgICAgICAgICAgICAgPC9Ecm9wZG93bj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuXHJcbiAgICAgICAgc2V0VGFibGVDb2xsZWN0aW9uQXJlYShjb2xsZWN0aW9uQXJlYURhdGEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjb2xsZWN0aW9uIGFyZWEgZGF0YTpcIiwgZXJyb3IubWVzc2FnZSk7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfVxyXG4gICAgfTtcclxuICAgIGZldGNoQXJlYUNvbGxlY3Rpb24oKTtcclxuICB9LCBbcmVsb2FkVHJpZ2dlcl0pO1xyXG5cclxuICAvLyAtLS0tIEFkZCBNb2RhbCBIYW5kbGVycyAtLS0tXHJcbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gYXN5bmMgKGUpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICAvLyBWYWxpZGF0aW9uOiBhbGwgZmllbGRzIG11c3QgYmUgc2VsZWN0ZWRcclxuICAgIGlmICghc2VsZWN0ZWRDdXN0b21lciB8fCAhc2VsZWN0ZWRBcmVhIHx8ICFzZWxlY3RlZFJlcHJlc2VudGF0aXZlKSB7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB0eXBlOiBcImVycm9yXCIsXHJcbiAgICAgICAgbWVzc2FnZTogXCJQbGVhc2Ugc2VsZWN0IEN1c3RvbWVyLCBDb2xsZWN0aW9uIEFyZWEsIGFuZCBSZXByZXNlbnRhdGl2ZS5cIixcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIC8vIEJ1aWxkIHBheWxvYWQgYWNjb3JkaW5nIHRvIHlvdXIgQVBJIGV4cGVjdGF0aW9uc1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIGN1c3RvbWVySWQ6IHNlbGVjdGVkQ3VzdG9tZXIuX2lkIHx8IHNlbGVjdGVkQ3VzdG9tZXIsIC8vIGFkanVzdCBiYXNlZCBvbiB5b3VyIGRhdGEgc3RydWN0dXJlXHJcbiAgICAgICAgY29sbGVjdGlvbkFyZWFJZDogc2VsZWN0ZWRBcmVhLFxyXG4gICAgICAgIHJlcHJlc2VudGF0aXZlSWQ6IHNlbGVjdGVkUmVwcmVzZW50YXRpdmUsXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBhd2FpdCBhcGkucGF0Y2goYC92MS9hZG1pbi91c2Vycy9jdXN0b21lci1hbGxvY2F0aW9uLyR7c2VsZWN0ZWRDdXN0b21lci5faWQgfWAsIHBheWxvYWQpO1xyXG5cclxuICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgbWVzc2FnZTogXCJDdXN0b21lciBhc3NpZ25lZCBzdWNjZXNzZnVsbHkhXCIsXHJcbiAgICAgICAgdmlzaWJpbGl0eTogdHJ1ZSxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBDbG9zZSBtb2RhbCBhbmQgcmVzZXQgZmllbGRzXHJcbiAgICAgIHNldFNob3dNb2RhbChmYWxzZSk7XHJcbiAgICAgIHNldFNlbGVjdGVkQ3VzdG9tZXIobnVsbCk7XHJcbiAgICAgIHNldFNlbGVjdGVkQXJlYShudWxsKTtcclxuICAgICAgc2V0U2VsZWN0ZWRSZXByZXNlbnRhdGl2ZShudWxsKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBhc3NpZ25pbmcgY3VzdG9tZXI6XCIsIGVycm9yKTtcclxuICAgICAgY29uc3QgZXJyb3JNc2cgPVxyXG4gICAgICAgIGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8XHJcbiAgICAgICAgXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkLiBQbGVhc2UgdHJ5IGFnYWluLlwiO1xyXG4gICAgICBzZXRBbGVydENvbmZpZyh7XHJcbiAgICAgICAgdHlwZTogXCJlcnJvclwiLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVycm9yTXNnLFxyXG4gICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIC8vIC0tLS0gT3RoZXIgaGFuZGxlcnMgKHVwZGF0ZSwgZGVsZXRlKSAtLS0tXHJcbiAgY29uc3QgaGFuZGxlVXBkYXRlTW9kYWxPcGVuID0gYXN5bmMgKElkKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5nZXQoXHJcbiAgICAgICAgYC9jb2xsZWN0aW9uLWFyZWEtcmVxdWVzdC9nZXQtY29sbGVjdGlvbi1hcmVhLWRhdGEtYnktaWQvJHtJZH1gXHJcbiAgICAgICk7XHJcbiAgICAgIHNldEN1cnJlbnRVcGRhdGVDb2xsZWN0aW9uQXJlYShyZXNwb25zZT8uZGF0YSk7XHJcbiAgICAgIHNldFVwZGF0ZUNvbGxlY3Rpb25BcmVhRGF0YSh7XHJcbiAgICAgICAgYWdlbnRfaWQ6IHJlc3BvbnNlPy5kYXRhPy5hZ2VudF9pZCxcclxuICAgICAgICByb3V0ZV9uYW1lOiByZXNwb25zZT8uZGF0YT8ucm91dGVfbmFtZSxcclxuICAgICAgICByb3V0ZV9waW5jb2RlOiByZXNwb25zZT8uZGF0YT8ucm91dGVfcGluY29kZSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldFNob3dNb2RhbFVwZGF0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBjb2xsZWN0aW9uIGFyZWEgZGF0YTpcIiwgZXJyb3IpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU1vZGFsT3BlbiA9IGFzeW5jIChJZCkgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkuZ2V0KFxyXG4gICAgICAgIGAvY29sbGVjdGlvbi1hcmVhLXJlcXVlc3QvZ2V0LWNvbGxlY3Rpb24tYXJlYS1kYXRhLWJ5LWlkLyR7SWR9YFxyXG4gICAgICApO1xyXG4gICAgICBzZXRDdXJyZW50Q29sbGVjdGlvbkFyZWEocmVzcG9uc2UuZGF0YSk7XHJcbiAgICAgIHNldFNob3dNb2RhbERlbGV0ZSh0cnVlKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBDb2xsZWN0aW9uIGFyZWEgRGF0YSA6XCIsIGVycm9yKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEZWxldGVDb2xsZWN0aW9uQXJlYSA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmIChjdXJyZW50Q29sbGVjdGlvbkFyZWEpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBhcGkuZGVsZXRlKFxyXG4gICAgICAgICAgYC9jb2xsZWN0aW9uLWFyZWEtcmVxdWVzdC9kZWxldGUtY29sbGVjdGlvbi1hcmVhLWRhdGEtYnktaWQvJHtjdXJyZW50Q29sbGVjdGlvbkFyZWEuX2lkfWBcclxuICAgICAgICApO1xyXG4gICAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICAgIHZpc2liaWxpdHk6IHRydWUsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIkNvbGxlY3Rpb24gQXJlYSBkZWxldGVkIHN1Y2Nlc3NmdWxseVwiLFxyXG4gICAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgc2V0UmVsb2FkVHJpZ2dlcigocHJldikgPT4gcHJldiArIDEpO1xyXG4gICAgICAgIHNldFNob3dNb2RhbERlbGV0ZShmYWxzZSk7XHJcbiAgICAgICAgc2V0Q3VycmVudENvbGxlY3Rpb25BcmVhKG51bGwpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBkZWxldGluZyBDb2xsZWN0aW9uIEFyZWE6XCIsIGVycm9yKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZSA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICB0cnkge1xyXG4gICAgICBhd2FpdCBhcGkucHV0KFxyXG4gICAgICAgIGAvY29sbGVjdGlvbi1hcmVhLXJlcXVlc3QvdXBkYXRlLWNvbGxlY3Rpb24tYXJlYS1kYXRhLWJ5LWlkLyR7Y3VycmVudFVwZGF0ZUNvbGxlY3Rpb25BcmVhLl9pZH1gLFxyXG4gICAgICAgIHVwZGF0ZUNvbGxlY3Rpb25BcmVhRGF0YVxyXG4gICAgICApO1xyXG4gICAgICBzZXRTaG93TW9kYWxVcGRhdGUoZmFsc2UpO1xyXG4gICAgICBzZXRSZWxvYWRUcmlnZ2VyKChwcmV2KSA9PiBwcmV2ICsgMSk7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiQ29sbGVjdGlvbiBBcmVhIFVwZGF0ZWQgU3VjY2Vzc2Z1bGx5XCIsXHJcbiAgICAgICAgdHlwZTogXCJzdWNjZXNzXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIHVwZGF0aW5nIENvbGxlY3Rpb24gQXJlYTpcIiwgZXJyb3IpO1xyXG4gICAgICBjb25zdCBlcnJvck1zZyA9XHJcbiAgICAgICAgZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHxcclxuICAgICAgICBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWQuIFBsZWFzZSB0cnkgYWdhaW4uXCI7XHJcbiAgICAgIHNldEFsZXJ0Q29uZmlnKHtcclxuICAgICAgICB2aXNpYmlsaXR5OiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IGVycm9yTXNnLFxyXG4gICAgICAgIHR5cGU6IFwiZXJyb3JcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgLy8gQ29sdW1ucyBmb3IgRGF0YVRhYmxlXHJcbiAgY29uc3QgY29sdW1ucyA9IFtcclxuICAgIHsga2V5OiBcImlkXCIsIGhlYWRlcjogXCJTTC4gTk9cIiB9LFxyXG4gICAgeyBrZXk6IFwiY29sbGVjdGlvbl9hcmVhX2NvZGVcIiwgaGVhZGVyOiBcIkNvbGxlY3Rpb24gQ29kZVwiIH0sXHJcbiAgICB7IGtleTogXCJuYW1lXCIsIGhlYWRlcjogXCJDb2xsZWN0aW9uIEFyZWEgTmFtZVwiIH0sXHJcbiAgICB7IGtleTogXCJwaW5jb2RlXCIsIGhlYWRlcjogXCJwaW5jb2RlXCIgfSxcclxuICAgIHsga2V5OiBcImVtcGxveWVlX25hbWVcIiwgaGVhZGVyOiBcIkVtcGxveWVlXCIgfSxcclxuICAgIHsga2V5OiBcImVtcGxveWVlX3Bob25lXCIsIGhlYWRlcjogXCJQaG9uZSBOdW1iZXJcIiB9LFxyXG4gICAgeyBrZXk6IFwiZW1wbG95ZWVfaWRcIiwgaGVhZGVyOiBcIkVtcGxveWVlIElkXCIgfSxcclxuICAgIHsga2V5OiBcImFjdGlvblwiLCBoZWFkZXI6IFwiQWN0aW9uXCIgfSxcclxuICBdO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIj5cclxuICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgICA8TmF2YmFyXHJcbiAgICAgICAgICAgIG9uR2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcj17R2xvYmFsU2VhcmNoQ2hhbmdlSGFuZGxlcn1cclxuICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8Q3VzdG9tQWxlcnREaWFsb2dcclxuICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgaXNWaXNpYmxlPXthbGVydENvbmZpZy52aXNpYmlsaXR5fVxyXG4gICAgICAgICAgICBtZXNzYWdlPXthbGVydENvbmZpZy5tZXNzYWdlfVxyXG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgIHNldEFsZXJ0Q29uZmlnKChwcmV2KSA9PiAoeyAuLi5wcmV2LCB2aXNpYmlsaXR5OiBmYWxzZSB9KSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3JvdyBwLTcgb3ZlcmZsb3cteC1hdXRvXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNiBtYi04IG1pbi13LW1heFwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtc2VtaWJvbGRcIj5DdXN0b21lciBBbGxvY2F0aW9uPC9oMT5cclxuXHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWwodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1sLTQgYmctdmlvbGV0LTk1MCB0ZXh0LXdoaXRlIHB4LTQgcHktMiByb3VuZGVkIHNoYWRvdy1tZCBob3ZlcjpiZy12aW9sZXQtODAwIHRyYW5zaXRpb24gZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgKyBBc3NpZ24gQ3VzdG9tZXJcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAge3RhYmxlQ29sbGVjdGlvbkFyZWE/Lmxlbmd0aCA+IDAgJiYgIWlzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICA8RGF0YVRhYmxlXHJcbiAgICAgICAgICAgICAgICBjYXRjaGVyPVwiX2lkXCJcclxuICAgICAgICAgICAgICAgIHVwZGF0ZUhhbmRsZXI9e2hhbmRsZVVwZGF0ZU1vZGFsT3Blbn1cclxuICAgICAgICAgICAgICAgIGRhdGE9e2ZpbHRlck9wdGlvbih0YWJsZUNvbGxlY3Rpb25BcmVhLCBzZWFyY2hUZXh0KX1cclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e2NvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBleHBvcnRlZFBkZk5hbWU9XCJDb2xsZWN0aW9uIEFyZWFcIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT1cIkNvbGxlY3Rpb24gQXJlYS5jc3ZcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc9e2lzTG9hZGluZ31cclxuICAgICAgICAgICAgICAgIGZhaWx1cmU9e3RhYmxlQ29sbGVjdGlvbkFyZWEubGVuZ3RoIDw9IDB9XHJcbiAgICAgICAgICAgICAgICBkYXRhPVwiIEN1c3RvbWVyIGFsbG9jYXRpb24gRGF0YSBcIlxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qID09PT09IEFERCBNT0RBTCA9PT09PSAqL31cclxuICAgICAgICA8TW9kYWwgaXNWaXNpYmxlPXtzaG93TW9kYWx9IG9uQ2xvc2U9eygpID0+IHNldFNob3dNb2RhbChmYWxzZSl9PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS02IHB4LTUgbGc6cHgtOCB0ZXh0LWxlZnRcIj5cclxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgIEFzc2lnbiBDdXN0b21lclxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIHsvKiBDdXN0b21lciAqL31cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTJcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDAgbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgICBTZWxlY3QgQ3VzdG9tZXIgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEwXCJcclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRDdXN0b21lcj8uX2lkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3VzdG9tZXIgPSBmaWx0ZXJlZFVzZXJzLmZpbmQoKHUpID0+IHUuX2lkID09PSB2YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRDdXN0b21lcihjdXN0b21lcik7XHJcbiAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IEN1c3RvbWVyXCJcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24/LmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICA/LnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7ZmlsdGVyZWRVc2Vycy5tYXAoKHUpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e3UuX2lkfSB2YWx1ZT17dS5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAge3U/LmZ1bGxfbmFtZX0gLSB7dT8ucGhvbmVfbnVtYmVyfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Lk9wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgey8qIENvbGxlY3Rpb24gQXJlYSAqL31cclxuICAgICAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgIENvbGxlY3Rpb24gQXJlYSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBib3JkZXIgaC0xNCBib3JkZXItZ3JheS0zMDAgdGV4dC1ncmF5LTkwMCB0ZXh0LXNtIHJvdW5kZWQtbGcgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgQ29sbGVjdGlvbiBBcmVhXCJcclxuICAgICAgICAgICAgICAgICAgcG9wdXBNYXRjaFNlbGVjdFdpZHRoPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRBcmVhfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KHZhbHVlKSA9PiBzZXRTZWxlY3RlZEFyZWEodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7YXJlYXMubWFwKChhcmVhKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXthcmVhLl9pZH0gdmFsdWU9e2FyZWEuX2lkfT5cclxuICAgICAgICAgICAgICAgICAgICAgIHthcmVhLnJvdXRlX25hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICB7LyogUmVwcmVzZW50YXRpdmUgKi99XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICBDb2xsZWN0aW9uIFJlcHJlc2VudGF0aXZlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmF5LTUwIGJvcmRlciBoLTE0IGJvcmRlci1ncmF5LTMwMCB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBSZXByZXNlbnRhdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgIHBvcHVwTWF0Y2hTZWxlY3RXaWR0aD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgIHNob3dTZWFyY2hcclxuICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW5cclxuICAgICAgICAgICAgICAgICAgICAgIC50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgLmluY2x1ZGVzKGlucHV0LnRvTG93ZXJDYXNlKCkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkUmVwcmVzZW50YXRpdmV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+IHNldFNlbGVjdGVkUmVwcmVzZW50YXRpdmUodmFsdWUpfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFNlbGVjdC5PcHRpb24ga2V5PXtlbXAuX2lkfSB2YWx1ZT17ZW1wLl9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7YCR7ZW1wLm5hbWV9IHwgJHtlbXAucGhvbmVfbnVtYmVyfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGp1c3RpZnktZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTEvNCB0ZXh0LXdoaXRlIGJnLXZpb2xldC03MDAgaG92ZXI6YmctdmlvbGV0LTgwMCBib3JkZXItMiBib3JkZXItYmxhY2tcclxuICAgICAgICAgICAgICAgICAgZm9jdXM6cmluZy00IGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLXZpb2xldC0zMDAgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0ZXh0LXNtIHB4LTUgcHktMi41IHRleHQtY2VudGVyXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQXNzaWduIEN1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuXHJcbiAgICAgICAgey8qID09PT09IFVQREFURSBNT0RBTCAodW5jaGFuZ2VkKSA9PT09PSAqL31cclxuICAgICAgICA8TW9kYWxcclxuICAgICAgICAgIGlzVmlzaWJsZT17c2hvd01vZGFsVXBkYXRlfVxyXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd01vZGFsVXBkYXRlKGZhbHNlKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgVXBkYXRlIENvbGxlY3Rpb24gQXJlYVxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9XCJzcGFjZS15LTZcIiBvblN1Ym1pdD17aGFuZGxlVXBkYXRlfSBub1ZhbGlkYXRlPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWxcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIlxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPVwicm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDb2xsZWN0aW9uIEFyZWEgTmFtZVxyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDxJbnB1dFxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJyb3V0ZV9uYW1lXCJcclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3VwZGF0ZUNvbGxlY3Rpb25BcmVhRGF0YT8ucm91dGVfbmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldFVwZGF0ZUNvbGxlY3Rpb25BcmVhRGF0YSgocHJldikgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICAgIC4uLnByZXYsXHJcbiAgICAgICAgICAgICAgICAgICAgICByb3V0ZV9uYW1lOiBlLnRhcmdldC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICB9KSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBpZD1cInJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQ29sbGVjdGlvbiBBcmVhIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgQ29sbGVjdGlvbiBBcmVhIFBpbmNvZGVcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICA8SW5wdXRcclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBuYW1lPVwicm91dGVfcGluY29kZVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1cGRhdGVDb2xsZWN0aW9uQXJlYURhdGE/LnJvdXRlX3BpbmNvZGV9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRVcGRhdGVDb2xsZWN0aW9uQXJlYURhdGEoKHByZXYpID0+ICh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2LFxyXG4gICAgICAgICAgICAgICAgICAgICAgcm91dGVfcGluY29kZTogZS50YXJnZXQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgaWQ9XCJwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0aGUgQ29sbGVjdGlvbiBBcmVhIFBpbmNvZGVcIlxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9XCJwaW5jb2RlXCJcclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2VsZWN0IEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICBtb2RlPVwidGFnc1wiXHJcbiAgICAgICAgICAgICAgICAgIHNpemU9e1wibGFyZ2VcIn1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWxlY3QgRW1wbG95ZWVcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dXBkYXRlQ29sbGVjdGlvbkFyZWFEYXRhPy5hZ2VudF9pZH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhhcnJheUVsZW1lbnQpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0VXBkYXRlQ29sbGVjdGlvbkFyZWFEYXRhKChwcmV2KSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgLi4ucHJldixcclxuICAgICAgICAgICAgICAgICAgICAgIGFnZW50X2lkOiBhcnJheUVsZW1lbnQsXHJcbiAgICAgICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e2VtcGxveWVlcy5tYXAoKGVtcCkgPT4gKHtcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbDogYCR7ZW1wLm5hbWV9ICgke2VtcC5waG9uZV9udW1iZXJ9KWAsXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGVtcC5faWQsXHJcbiAgICAgICAgICAgICAgICAgIH0pKX1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBqdXN0aWZ5LWVuZFwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xLzQgdGV4dC13aGl0ZSBiZy12aW9sZXQtNzAwIGhvdmVyOmJnLXZpb2xldC04MDAgYm9yZGVyLTIgYm9yZGVyLWJsYWNrXHJcbiAgICAgICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFVwZGF0ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvTW9kYWw+XHJcblxyXG4gICAgICAgIHsvKiA9PT09PSBERUxFVEUgTU9EQUwgKHVuY2hhbmdlZCkgPT09PT0gKi99XHJcbiAgICAgICAgPE1vZGFsXHJcbiAgICAgICAgICBpc1Zpc2libGU9e3Nob3dNb2RhbERlbGV0ZX1cclxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsRGVsZXRlKGZhbHNlKTtcclxuICAgICAgICAgICAgc2V0Q3VycmVudENvbGxlY3Rpb25BcmVhKG51bGwpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTYgcHgtNSBsZzpweC04IHRleHQtbGVmdFwiPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgRGVsZXRlIENvbGxlY3Rpb24gQXJlYVxyXG4gICAgICAgICAgICA8L2gzPlxyXG4gICAgICAgICAgICB7Y3VycmVudENvbGxlY3Rpb25BcmVhICYmIChcclxuICAgICAgICAgICAgICA8Zm9ybVxyXG4gICAgICAgICAgICAgICAgb25TdWJtaXQ9eyhlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlQ29sbGVjdGlvbkFyZWEoKTtcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzcGFjZS15LTZcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCJcclxuICAgICAgICAgICAgICAgICAgICBodG1sRm9yPVwiZ3JvdXBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFBsZWFzZSBlbnRlcntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXByaW1hcnkgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudENvbGxlY3Rpb25BcmVhPy5yb3V0ZV9uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj57XCIgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdG8gY29uZmlybSBkZWxldGlvbi5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPElucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwicm91dGVOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHRoZSBDb2xsZWN0aW9uIEFyZWEgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy1ncmF5LTUwIGJvcmRlciBib3JkZXItZ3JheS0zMDAgJHtmaWVsZFNpemUuaGVpZ2h0fSB0ZXh0LWdyYXktOTAwIHRleHQtc20gcm91bmRlZC1sZyBmb2N1czpyaW5nLXZpb2xldC01MDAgZm9jdXM6Ym9yZGVyLXZpb2xldC01MDAgdy1mdWxsIHAtMi41YH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtd2hpdGUgYmctcmVkLTcwMCBob3ZlcjpiZy1yZWQtODAwXHJcbiAgICAgICAgICAgICAgICAgIGZvY3VzOnJpbmctNCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy12aW9sZXQtMzAwIGZvbnQtbWVkaXVtIHJvdW5kZWQtbGcgdGV4dC1zbSBweC01IHB5LTIuNSB0ZXh0LWNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ3VzdG9tZXJBbGxvY2F0aW9uOyJdLCJmaWxlIjoiQzovVXNlcnMvU1lTIDYvRG9jdW1lbnRzL1Byb2plY3QvcHJvZC1mcm9udGVuZC1teWNoaXRzLXYyL3NyYy9wYWdlcy9DdXN0b21lckFsbG9jYXRpb24uanN4In0=