import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/EmployeeMonthlyReport.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useMemo = __vite__cjsImport3_react["useMemo"];
import DataTable from "/src/components/layouts/Datatable.jsx";
import api from "/src/instance/TokenInstance.js";
import { Select, Spin, Button, Tag } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import { CalendarOutlined, UserOutlined, FilterOutlined } from "/node_modules/.vite/deps/@ant-design_icons.js?v=819e0a34";
import __vite__cjsImport8_dayjs from "/node_modules/.vite/deps/dayjs.js?v=819e0a34"; const dayjs = __vite__cjsImport8_dayjs.__esModule ? __vite__cjsImport8_dayjs.default : __vite__cjsImport8_dayjs;
import __vite__cjsImport9_dayjs_plugin_duration from "/node_modules/.vite/deps/dayjs_plugin_duration.js?v=819e0a34"; const duration = __vite__cjsImport9_dayjs_plugin_duration.__esModule ? __vite__cjsImport9_dayjs_plugin_duration.default : __vite__cjsImport9_dayjs_plugin_duration;
dayjs.extend(duration);
import { numberToIndianWords } from "/src/helpers/numberToIndianWords.js";
const EmployeeMonthlyReport = () => {
  _s();
  const today = /* @__PURE__ */ new Date();
  const currentYear = today.getFullYear();
  const currentMonth = String(today.getMonth() + 1).padStart(2, "0");
  const currentYearMonth = `${currentYear}-${currentMonth}`;
  const formatDate = (date) => {
    const year = date.getFullYear();
    const month = `0${date.getMonth() + 1}`.slice(-2);
    const day = `0${date.getDate()}`.slice(-2);
    return `${year}-${month}-${day}`;
  };
  const [selectedDate, setSelectedDate] = useState(currentYearMonth);
  const [attendanceData, setAttendanceData] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [selectedEmployee, setSelectedEmployee] = useState("all");
  const [loading, setLoading] = useState(false);
  const getMonthRange = (yearMonth) => {
    const [year, month] = yearMonth.split("-");
    const firstDay = new Date(year, month - 1, 1);
    const lastDay = new Date(year, month, 0);
    return {
      from_date: formatDate(firstDay),
      to_date: formatDate(lastDay)
    };
  };
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const res = await api.get("/employee");
        setEmployees(res.data.employee || []);
      } catch (err) {
        console.error("Error fetching employees:", err);
      }
    };
    fetchEmployees();
  }, []);
  const fetchAttendanceData = async () => {
    setLoading(true);
    try {
      const { from_date, to_date } = getMonthRange(selectedDate);
      const params = {
        from_date,
        to_date,
        employee_id: selectedEmployee !== "all" ? selectedEmployee : ""
      };
      const res = await api.get("/employee-attendance/monthly-report", { params });
      const attendanceResponse = res.data.attendanceDataResponse || [];
      if (selectedEmployee !== "all") {
        const formatted = attendanceResponse?.filter((emp) => emp?.employee_id?.isVerified === true)?.map((rec, index) => {
          let workingHours = "-";
          const loginTime = rec?.time;
          const logoutTime = rec?.logout_time;
          if (loginTime && logoutTime) {
            const start = dayjs(loginTime, "hh:mm:ss a");
            const end = dayjs(logoutTime, "hh:mm:ss a");
            if (start.isValid() && end.isValid()) {
              let diffMinutes = end.diff(start, "minute");
              if (diffMinutes < 0) {
                diffMinutes += 24 * 60;
              }
              const hours = Math.floor(diffMinutes / 60);
              const minutes = diffMinutes % 60;
              workingHours = `${hours}h ${minutes}m`;
            }
          }
          return {
            slNo: index + 1,
            key: rec._id || index,
            date: rec?.date ? rec.date.split("T")[0] : "",
            time: rec?.time || "",
            outTime: rec?.logout_time || "",
            WorkingHours: workingHours,
            approval_status: rec?.approval_status,
            day: rec?.date ? new Date(rec.date).toLocaleDateString("en-US", { weekday: "short" }) : "",
            Note: rec?.note || "",
            status: rec?.status || ""
          };
        });
        setAttendanceData(formatted);
      } else {
        const grouped = {};
        attendanceResponse?.filter((emp) => emp?.employee_id?.isVerified === true).forEach((record, index) => {
          const emp = record?.employee_id;
          if (!emp?._id) return;
          if (!grouped[emp._id]) {
            grouped[emp._id] = {
              slNo: index + 1,
              key: emp._id,
              EmployeeName: emp?.name || "",
              PresentDays: 0,
              AbsentDays: 0,
              HalfDays: 0,
              OnLeave: 0
            };
          }
          if (record?.status === "Present") grouped[emp._id].PresentDays++;
          if (record?.status === "Absent") grouped[emp._id].AbsentDays++;
          if (record?.status === "Half Day") grouped[emp._id].HalfDays++;
          if (record?.status === "On Leave") grouped[emp._id].OnLeave++;
        });
        setAttendanceData(Object.values(grouped));
      }
    } catch (err) {
      console.error("Error fetching attendance:", err);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchAttendanceData();
  }, [selectedEmployee, selectedDate]);
  const allEmployeesColumns = [
    { header: "Sl No", key: "slNo" },
    { header: "Employee Name", key: "EmployeeName" },
    { header: "Present Days", key: "PresentDays" },
    { header: "Absent Days", key: "AbsentDays" },
    { header: "Half Days", key: "HalfDays" },
    { header: "On Leave", key: "OnLeave" }
  ];
  const individualColumns = [
    { header: "Sl No", key: "slNo" },
    { header: "Date", key: "date" },
    { header: "In-Time", key: "time" },
    { header: "Out-Time", key: "outTime" },
    { header: "Approval Status", key: "approval_status" },
    { header: "Working Hours", key: "WorkingHours" },
    { header: "Day", key: "day" },
    { header: "Note", key: "Note" },
    {
      header: "Status",
      key: "status",
      render: (status) => {
        if (status?.toLowerCase() === "present") {
          return /* @__PURE__ */ jsxDEV(Tag, { color: "green", children: "Present" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
            lineNumber: 718,
            columnNumber: 16
          }, this);
        } else if (status?.toLowerCase() === "absent") {
          return /* @__PURE__ */ jsxDEV(Tag, { color: "red", children: "Absent" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
            lineNumber: 720,
            columnNumber: 16
          }, this);
        } else if (status?.toLowerCase() === "half day") {
          return /* @__PURE__ */ jsxDEV(Tag, { color: "orange", children: "Half Day" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
            lineNumber: 722,
            columnNumber: 16
          }, this);
        } else if (status?.toLowerCase() === "on leave") {
          return /* @__PURE__ */ jsxDEV(Tag, { color: "blue", children: "On Leave" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
            lineNumber: 724,
            columnNumber: 16
          }, this);
        }
        return status || "";
      }
    }
  ];
  const safeData = attendanceData.map((row) => {
    const clean = {};
    Object.keys(row).forEach((key) => {
      clean[key] = row[key] === null || row[key] === void 0 ? "" : String(row[key]);
    });
    return clean;
  });
  const parseWorkingHoursToMinutes = (workingHours) => {
    if (!workingHours || workingHours === "-") return 0;
    const match = workingHours.match(/(\d+)h\s*(\d+)m/);
    if (!match) return 0;
    const hours = parseInt(match[1], 10);
    const minutes = parseInt(match[2], 10);
    return hours * 60 + minutes;
  };
  const summaryStats = useMemo(() => {
    const total = attendanceData.length;
    if (selectedEmployee === "all") {
      const totalPresent = attendanceData.reduce(
        (sum, e) => sum + (e.PresentDays || 0),
        0
      );
      const totalAbsent = attendanceData.reduce(
        (sum, e) => sum + (e.AbsentDays || 0),
        0
      );
      const totalHalfDays = attendanceData.reduce(
        (sum, e) => sum + (e.HalfDays || 0),
        0
      );
      const totalOnLeave = attendanceData.reduce(
        (sum, e) => sum + (e.OnLeave || 0),
        0
      );
      return {
        totalEmployees: total,
        totalPresent,
        totalAbsent,
        totalHalfDays,
        totalOnLeave,
        presentPercent: totalPresent + totalAbsent + totalHalfDays ? (totalPresent / (totalPresent + totalAbsent + totalHalfDays) * 100).toFixed(1) : 0
      };
    }
    const present = attendanceData.filter((r) => r.status === "Present").length;
    const absent = attendanceData.filter((r) => r.status === "Absent").length;
    const halfDays = attendanceData.filter((r) => r.status === "Half Day").length;
    const onLeave = attendanceData.filter((r) => r.status === "On Leave").length;
    const totalMinutes = attendanceData.reduce((sum, r) => {
      return sum + parseWorkingHoursToMinutes(r.WorkingHours);
    }, 0);
    const totalHours = Math.floor(totalMinutes / 60);
    const remainingMinutes = totalMinutes % 60;
    return {
      totalDays: total,
      present,
      absent,
      halfDays,
      onLeave,
      totalWorkingTime: `${totalHours}h ${remainingMinutes}m`,
      presentPercent: total ? (present / total * 100).toFixed(1) : 0
    };
  }, [attendanceData, selectedEmployee]);
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-6", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-7xl mx-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-8 mb-6 border border-slate-200", children: /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 mb-2", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg", children: /* @__PURE__ */ jsxDEV(CalendarOutlined, { className: "text-white text-2xl" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 823,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 822,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h1", { className: "text-3xl font-bold text-slate-800", children: "Monthly Attendance Report" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 826,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-500 text-sm mt-1", children: "Track and analyze employee attendance patterns" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 827,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 825,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
      lineNumber: 821,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
      lineNumber: 820,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-6 mb-6 border border-slate-200", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-4", children: [
        /* @__PURE__ */ jsxDEV(FilterOutlined, { className: "text-blue-600 text-lg" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 835,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-semibold text-slate-700", children: "Filters" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 836,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 834,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-4 items-end", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[200px]", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700 mb-2", children: "Target Month" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
            lineNumber: 841,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            "input",
            {
              type: "month",
              className: "w-full px-4 py-2.5 border-2 border-slate-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors duration-200 bg-slate-50 hover:bg-white",
              value: selectedDate,
              onChange: (e) => setSelectedDate(e.target.value),
              max: currentYearMonth
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
              lineNumber: 844,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 840,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-1 min-w-[250px]", children: [
          /* @__PURE__ */ jsxDEV("label", { className: "block text-sm font-semibold text-slate-700 mb-2", children: "Employee" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
            lineNumber: 854,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Select,
            {
              showSearch: true,
              className: "w-full",
              style: { width: "100%" },
              value: selectedEmployee,
              onChange: setSelectedEmployee,
              placeholder: "Search employee",
              size: "large",
              filterOption: (input, option) => option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0,
              children: [
                /* @__PURE__ */ jsxDEV(Select.Option, { value: "all", children: "All Employees" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
                  lineNumber: 869,
                  columnNumber: 17
                }, this),
                employees.map(
                  (emp) => /* @__PURE__ */ jsxDEV(Select.Option, { value: emp._id, children: emp.name }, emp._id, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
                    lineNumber: 871,
                    columnNumber: 17
                  }, this)
                )
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
              lineNumber: 857,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 853,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Button,
          {
            type: "primary",
            size: "large",
            onClick: fetchAttendanceData,
            className: "px-8 h-11 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 border-0 shadow-md hover:shadow-lg transition-all duration-200",
            children: "Apply Filters"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
            lineNumber: 878,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 839,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
      lineNumber: 833,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-slate-700 to-slate-900 rounded-2xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-200", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: /* @__PURE__ */ jsxDEV(UserOutlined, { className: "text-3xl opacity-80" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 894,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 893,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-slate-300 text-sm font-medium mb-1", children: selectedEmployee === "all" ? "Total Employees" : "Total Days" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 896,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold", children: selectedEmployee === "all" ? summaryStats.totalEmployees : summaryStats.totalDays }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 899,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-mono text-white `, children: numberToIndianWords(selectedEmployee === "all" ? summaryStats.totalEmployees : summaryStats.totalDays || 0) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 904,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 892,
        columnNumber: 11
      }, this),
      selectedEmployee !== "all" && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-emerald-500 to-green-600 rounded-2xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-200", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-white/20 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-2xl", children: "✓" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 916,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 915,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 914,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-emerald-100 text-sm font-medium mb-1", children: "Present" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 919,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold", children: summaryStats.present }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 920,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-mono text-white `, children: numberToIndianWords(summaryStats.present || 0) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 921,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 913,
        columnNumber: 11
      }, this),
      selectedEmployee !== "all" && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-rose-500 to-red-600 rounded-2xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-200", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-white/20 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-2xl", children: "✕" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 932,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 931,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 930,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-rose-100 text-sm font-medium mb-1", children: "Absent" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 935,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold", children: summaryStats.absent }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 936,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-mono text-white `, children: numberToIndianWords(summaryStats.absent || 0) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 937,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 929,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-200", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-white/20 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-2xl", children: "½" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 947,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 946,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 945,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-amber-100 text-sm font-medium mb-1", children: "Half Day" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 950,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold", children: selectedEmployee === "all" ? summaryStats.totalHalfDays : summaryStats.halfDays }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 951,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-mono text-white `, children: numberToIndianWords(selectedEmployee === "all" ? summaryStats.totalHalfDays : summaryStats.halfDays || 0) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 954,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 944,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-blue-500 to-indigo-600 center rounded-2xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-200", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-blue-100 text-sm font-medium mb-1", children: "On Leave" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 966,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold", children: selectedEmployee === "all" ? summaryStats.totalOnLeave : summaryStats.onLeave }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 967,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-mono text-white `, children: numberToIndianWords(selectedEmployee === "all" ? summaryStats.totalOnLeave : summaryStats.onLeave || 0) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 970,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 960,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-200", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-2", children: /* @__PURE__ */ jsxDEV("div", { className: "w-10 h-10 bg-white/20 rounded-full flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("span", { className: "text-2xl", children: "%" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 979,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 978,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 977,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-purple-100 text-sm font-medium mb-1", children: "Present Rate" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 982,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold", children: [
          summaryStats.presentPercent,
          "%"
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 983,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("span", { className: `text-sm font-mono text-white `, children: numberToIndianWords(summaryStats.presentPercent || 0) }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 984,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 976,
        columnNumber: 11
      }, this),
      selectedEmployee !== "all" && /* @__PURE__ */ jsxDEV("div", { className: "bg-gradient-to-br from-teal-500 to-cyan-600 rounded-2xl shadow-lg p-6 text-white transform hover:scale-105 transition-transform duration-200", children: [
        /* @__PURE__ */ jsxDEV("p", { className: "text-teal-100 text-sm font-medium mb-1", children: "Total Working Time" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 997,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("p", { className: "text-4xl font-bold", children: summaryStats.totalWorkingTime }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 998,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 991,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
      lineNumber: 890,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "bg-white rounded-2xl shadow-lg p-6 border border-slate-200", children: loading ? /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col justify-center items-center h-64", children: [
      /* @__PURE__ */ jsxDEV(Spin, { size: "large" }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 1007,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-slate-500 mt-4", children: "Loading attendance data..." }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 1008,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
      lineNumber: 1006,
      columnNumber: 11
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(
        DataTable,
        {
          columns: selectedEmployee === "all" ? allEmployeesColumns : individualColumns,
          data: safeData,
          exportedPdfName: "Employee Monthly Attendence Report",
          exportedFileName: `EmployeeMonthly Attendence Report.csv`,
          loading
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 1012,
          columnNumber: 15
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-6 pt-4 border-t border-slate-200", children: /* @__PURE__ */ jsxDEV("p", { className: "text-slate-600 text-sm", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "font-medium", children: "Showing attendance for:" }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 1022,
          columnNumber: 19
        }, this),
        " ",
        /* @__PURE__ */ jsxDEV("span", { className: "text-blue-600 font-semibold", children: selectedDate }, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
          lineNumber: 1023,
          columnNumber: 19
        }, this),
        selectedEmployee !== "all" && ` • ${employees.find((e) => e._id === selectedEmployee)?.name || ""}`
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 1021,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
        lineNumber: 1020,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
      lineNumber: 1011,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
      lineNumber: 1004,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
    lineNumber: 818,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx",
    lineNumber: 817,
    columnNumber: 5
  }, this);
};
_s(EmployeeMonthlyReport, "K71nxQtnvCGD7m8vl5Cw2LTV2DA=");
_c = EmployeeMonthlyReport;
export default EmployeeMonthlyReport;
var _c;
$RefreshReg$(_c, "EmployeeMonthlyReport");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/EmployeeMonthlyReport.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNnNCaUIsU0FxU0wsVUFyU0s7MkJBN3NCakI7QUFBbUJBLG9CQUFrQixPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3BELE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxRQUFRQyxNQUFNQyxRQUFRQyxXQUFXO0FBQzFDLFNBQVNDLGtCQUFrQkMsY0FBY0Msc0JBQXNCO0FBQy9ELE9BQU9DLFdBQVc7QUFDbEIsT0FBT0MsY0FBYztBQUVyQkQsTUFBTUUsT0FBT0QsUUFBUTtBQUVyQixTQUFTRSwyQkFBMkI7QUE4aEJwQyxNQUFNQyx3QkFBd0JBLE1BQU07QUFBQUMsS0FBQTtBQUNsQyxRQUFNQyxRQUFRLG9CQUFJQyxLQUFLO0FBQ3ZCLFFBQU1DLGNBQWNGLE1BQU1HLFlBQVk7QUFDdEMsUUFBTUMsZUFBZUMsT0FBT0wsTUFBTU0sU0FBUyxJQUFJLENBQUMsRUFBRUMsU0FBUyxHQUFHLEdBQUc7QUFDakUsUUFBTUMsbUJBQW1CLEdBQUdOLFdBQVcsSUFBSUUsWUFBWTtBQUV2RCxRQUFNSyxhQUFhQSxDQUFDQyxTQUFTO0FBQzNCLFVBQU1DLE9BQU9ELEtBQUtQLFlBQVk7QUFDOUIsVUFBTVMsUUFBUSxJQUFJRixLQUFLSixTQUFTLElBQUksQ0FBQyxHQUFHTyxNQUFNLEVBQUU7QUFDaEQsVUFBTUMsTUFBTSxJQUFJSixLQUFLSyxRQUFRLENBQUMsR0FBR0YsTUFBTSxFQUFFO0FBQ3pDLFdBQU8sR0FBR0YsSUFBSSxJQUFJQyxLQUFLLElBQUlFLEdBQUc7QUFBQSxFQUNoQztBQUVBLFFBQU0sQ0FBQ0UsY0FBY0MsZUFBZSxJQUFJQyxTQUFTVixnQkFBZ0I7QUFDakUsUUFBTSxDQUFDVyxnQkFBZ0JDLGlCQUFpQixJQUFJRixTQUFTLEVBQUU7QUFDdkQsUUFBTSxDQUFDRyxXQUFXQyxZQUFZLElBQUlKLFNBQVMsRUFBRTtBQUM3QyxRQUFNLENBQUNLLGtCQUFrQkMsbUJBQW1CLElBQUlOLFNBQVMsS0FBSztBQUM5RCxRQUFNLENBQUNPLFNBQVNDLFVBQVUsSUFBSVIsU0FBUyxLQUFLO0FBRTVDLFFBQU1TLGdCQUFnQkEsQ0FBQ0MsY0FBYztBQUNuQyxVQUFNLENBQUNqQixNQUFNQyxLQUFLLElBQUlnQixVQUFVQyxNQUFNLEdBQUc7QUFDekMsVUFBTUMsV0FBVyxJQUFJN0IsS0FBS1UsTUFBTUMsUUFBUSxHQUFHLENBQUM7QUFDNUMsVUFBTW1CLFVBQVUsSUFBSTlCLEtBQUtVLE1BQU1DLE9BQU8sQ0FBQztBQUN2QyxXQUFPO0FBQUEsTUFDTG9CLFdBQVd2QixXQUFXcUIsUUFBUTtBQUFBLE1BQzlCRyxTQUFTeEIsV0FBV3NCLE9BQU87QUFBQSxJQUM3QjtBQUFBLEVBQ0Y7QUFFQS9DLFlBQVUsTUFBTTtBQUNkLFVBQU1rRCxpQkFBaUIsWUFBWTtBQUNqQyxVQUFJO0FBQ0YsY0FBTUMsTUFBTSxNQUFNakQsSUFBSWtELElBQUksV0FBVztBQUNyQ2QscUJBQWFhLElBQUlFLEtBQUtDLFlBQVksRUFBRTtBQUFBLE1BQ3RDLFNBQVNDLEtBQUs7QUFDWkMsZ0JBQVFDLE1BQU0sNkJBQTZCRixHQUFHO0FBQUEsTUFDaEQ7QUFBQSxJQUNGO0FBQ0FMLG1CQUFlO0FBQUEsRUFDakIsR0FBRyxFQUFFO0FBRUwsUUFBTVEsc0JBQXNCLFlBQVk7QUFDdENoQixlQUFXLElBQUk7QUFFZixRQUFJO0FBQ0YsWUFBTSxFQUFFTSxXQUFXQyxRQUFRLElBQUlOLGNBQWNYLFlBQVk7QUFFekQsWUFBTTJCLFNBQVM7QUFBQSxRQUNiWDtBQUFBQSxRQUNBQztBQUFBQSxRQUNBVyxhQUFhckIscUJBQXFCLFFBQVFBLG1CQUFtQjtBQUFBLE1BQy9EO0FBRUEsWUFBTVksTUFBTSxNQUFNakQsSUFBSWtELElBQUksdUNBQXVDLEVBQUVPLE9BQU8sQ0FBQztBQUMzRSxZQUFNRSxxQkFBcUJWLElBQUlFLEtBQUtTLDBCQUEwQjtBQUc5RCxVQUFJdkIscUJBQXFCLE9BQU87QUFDOUIsY0FBTXdCLFlBQVlGLG9CQUFvQkcsT0FBTyxDQUFDQyxRQUFRQSxLQUFLTCxhQUFhTSxlQUFlLElBQUksR0FBR0MsSUFBSSxDQUFDQyxLQUFLQyxVQUFVO0FBQ2hILGNBQUlDLGVBQWU7QUFFbkIsZ0JBQU1DLFlBQVlILEtBQUtJO0FBQ3ZCLGdCQUFNQyxhQUFhTCxLQUFLTTtBQUV4QixjQUFJSCxhQUFhRSxZQUFZO0FBQzNCLGtCQUFNRSxRQUFRakUsTUFBTTZELFdBQVcsWUFBWTtBQUMzQyxrQkFBTUssTUFBTWxFLE1BQU0rRCxZQUFZLFlBQVk7QUFFMUMsZ0JBQUlFLE1BQU1FLFFBQVEsS0FBS0QsSUFBSUMsUUFBUSxHQUFHO0FBQ3BDLGtCQUFJQyxjQUFjRixJQUFJRyxLQUFLSixPQUFPLFFBQVE7QUFHMUMsa0JBQUlHLGNBQWMsR0FBRztBQUNuQkEsK0JBQWUsS0FBSztBQUFBLGNBQ3RCO0FBRUEsb0JBQU1FLFFBQVFDLEtBQUtDLE1BQU1KLGNBQWMsRUFBRTtBQUN6QyxvQkFBTUssVUFBVUwsY0FBYztBQUU5QlIsNkJBQWUsR0FBR1UsS0FBSyxLQUFLRyxPQUFPO0FBQUEsWUFDckM7QUFBQSxVQUNGO0FBRUEsaUJBQU87QUFBQSxZQUNMQyxNQUFNZixRQUFRO0FBQUEsWUFDZGdCLEtBQUtqQixJQUFJa0IsT0FBT2pCO0FBQUFBLFlBQ2hCM0MsTUFBTTBDLEtBQUsxQyxPQUFPMEMsSUFBSTFDLEtBQUttQixNQUFNLEdBQUcsRUFBRSxDQUFDLElBQUk7QUFBQSxZQUMzQzJCLE1BQU1KLEtBQUtJLFFBQVE7QUFBQSxZQUNuQmUsU0FBU25CLEtBQUtNLGVBQWU7QUFBQSxZQUM3QmMsY0FBY2xCO0FBQUFBLFlBQ2RtQixpQkFBaUJyQixLQUFLcUI7QUFBQUEsWUFDdEIzRCxLQUFLc0MsS0FBSzFDLE9BQ04sSUFBSVQsS0FBS21ELElBQUkxQyxJQUFJLEVBQUVnRSxtQkFBbUIsU0FBUyxFQUFFQyxTQUFTLFFBQVEsQ0FBQyxJQUNuRTtBQUFBLFlBQ0pDLE1BQU14QixLQUFLeUIsUUFBUTtBQUFBLFlBQ25CQyxRQUFRMUIsS0FBSzBCLFVBQVU7QUFBQSxVQUN6QjtBQUFBLFFBQ0YsQ0FBQztBQUVEMUQsMEJBQWtCMkIsU0FBUztBQUFBLE1BQzdCLE9BR0s7QUFDSCxjQUFNZ0MsVUFBVSxDQUFDO0FBRWpCbEMsNEJBQW9CRyxPQUFPLENBQUNDLFFBQVFBLEtBQUtMLGFBQWFNLGVBQWUsSUFBSSxFQUFFOEIsUUFBUSxDQUFDQyxRQUFRNUIsVUFBVTtBQUNwRyxnQkFBTUosTUFBTWdDLFFBQVFyQztBQUNwQixjQUFJLENBQUNLLEtBQUtxQixJQUFLO0FBRWYsY0FBSSxDQUFDUyxRQUFROUIsSUFBSXFCLEdBQUcsR0FBRztBQUNyQlMsb0JBQVE5QixJQUFJcUIsR0FBRyxJQUFJO0FBQUEsY0FDakJGLE1BQU1mLFFBQVE7QUFBQSxjQUNkZ0IsS0FBS3BCLElBQUlxQjtBQUFBQSxjQUNUWSxjQUFjakMsS0FBS2tDLFFBQVE7QUFBQSxjQUMzQkMsYUFBYTtBQUFBLGNBQ2JDLFlBQVk7QUFBQSxjQUNaQyxVQUFVO0FBQUEsY0FDVkMsU0FBUztBQUFBLFlBQ1g7QUFBQSxVQUNGO0FBRUEsY0FBSU4sUUFBUUgsV0FBVyxVQUFXQyxTQUFROUIsSUFBSXFCLEdBQUcsRUFBRWM7QUFDbkQsY0FBSUgsUUFBUUgsV0FBVyxTQUFVQyxTQUFROUIsSUFBSXFCLEdBQUcsRUFBRWU7QUFDbEQsY0FBSUosUUFBUUgsV0FBVyxXQUFZQyxTQUFROUIsSUFBSXFCLEdBQUcsRUFBRWdCO0FBQ3BELGNBQUlMLFFBQVFILFdBQVcsV0FBWUMsU0FBUTlCLElBQUlxQixHQUFHLEVBQUVpQjtBQUFBQSxRQUV0RCxDQUFDO0FBRURuRSwwQkFBa0JvRSxPQUFPQyxPQUFPVixPQUFPLENBQUM7QUFBQSxNQUMxQztBQUFBLElBQ0YsU0FBU3hDLEtBQUs7QUFDWkMsY0FBUUMsTUFBTSw4QkFBOEJGLEdBQUc7QUFBQSxJQUNqRCxVQUFDO0FBQ0NiLGlCQUFXLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFFQTFDLFlBQVUsTUFBTTtBQUNkMEQsd0JBQW9CO0FBQUEsRUFDdEIsR0FBRyxDQUFDbkIsa0JBQWtCUCxZQUFZLENBQUM7QUFFbkMsUUFBTTBFLHNCQUFzQjtBQUFBLElBQzFCLEVBQUVDLFFBQVEsU0FBU3RCLEtBQUssT0FBUTtBQUFBLElBQ2hDLEVBQUVzQixRQUFRLGlCQUFpQnRCLEtBQUssZUFBZTtBQUFBLElBQy9DLEVBQUVzQixRQUFRLGdCQUFnQnRCLEtBQUssY0FBYztBQUFBLElBQzdDLEVBQUVzQixRQUFRLGVBQWV0QixLQUFLLGFBQWE7QUFBQSxJQUMzQyxFQUFFc0IsUUFBUSxhQUFhdEIsS0FBSyxXQUFXO0FBQUEsSUFDdkMsRUFBRXNCLFFBQVEsWUFBWXRCLEtBQUssVUFBVTtBQUFBLEVBQUM7QUFHeEMsUUFBTXVCLG9CQUFvQjtBQUFBLElBQ3hCLEVBQUVELFFBQVEsU0FBU3RCLEtBQUssT0FBTztBQUFBLElBQy9CLEVBQUVzQixRQUFRLFFBQVF0QixLQUFLLE9BQU87QUFBQSxJQUM5QixFQUFFc0IsUUFBUSxXQUFXdEIsS0FBSyxPQUFPO0FBQUEsSUFDakMsRUFBRXNCLFFBQVEsWUFBWXRCLEtBQUssVUFBVTtBQUFBLElBQ3JDLEVBQUNzQixRQUFRLG1CQUFtQnRCLEtBQUssa0JBQWlCO0FBQUEsSUFDbEQsRUFBRXNCLFFBQVEsaUJBQWlCdEIsS0FBSyxlQUFlO0FBQUEsSUFDL0MsRUFBRXNCLFFBQVEsT0FBT3RCLEtBQUssTUFBTTtBQUFBLElBQzVCLEVBQUVzQixRQUFRLFFBQVF0QixLQUFLLE9BQU87QUFBQSxJQUM5QjtBQUFBLE1BQ0VzQixRQUFRO0FBQUEsTUFDUnRCLEtBQUs7QUFBQSxNQUNMd0IsUUFBUUEsQ0FBQ2YsV0FBVztBQUNsQixZQUFJQSxRQUFRZ0IsWUFBWSxNQUFNLFdBQVc7QUFDdkMsaUJBQU8sdUJBQUMsT0FBSSxPQUFNLFNBQVEsdUJBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsUUFDbkMsV0FBV2hCLFFBQVFnQixZQUFZLE1BQU0sVUFBVTtBQUM3QyxpQkFBTyx1QkFBQyxPQUFJLE9BQU0sT0FBTSxzQkFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBdUI7QUFBQSxRQUNoQyxXQUFXaEIsUUFBUWdCLFlBQVksTUFBTSxZQUFZO0FBQy9DLGlCQUFPLHVCQUFDLE9BQUksT0FBTSxVQUFTLHdCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QjtBQUFBLFFBQ3JDLFdBQVdoQixRQUFRZ0IsWUFBWSxNQUFNLFlBQVk7QUFDL0MsaUJBQU8sdUJBQUMsT0FBSSxPQUFNLFFBQU8sd0JBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTBCO0FBQUEsUUFDbkM7QUFDQSxlQUFPaEIsVUFBVTtBQUFBLE1BQ25CO0FBQUEsSUFDRjtBQUFBLEVBQUM7QUFHSCxRQUFNaUIsV0FBVzVFLGVBQWVnQyxJQUFJLENBQUM2QyxRQUFRO0FBQzNDLFVBQU1DLFFBQVEsQ0FBQztBQUNmVCxXQUFPVSxLQUFLRixHQUFHLEVBQUVoQixRQUFRLENBQUNYLFFBQVE7QUFDaEM0QixZQUFNNUIsR0FBRyxJQUNQMkIsSUFBSTNCLEdBQUcsTUFBTSxRQUFRMkIsSUFBSTNCLEdBQUcsTUFBTThCLFNBQVksS0FBSzlGLE9BQU8yRixJQUFJM0IsR0FBRyxDQUFDO0FBQUEsSUFDdEUsQ0FBQztBQUNELFdBQU80QjtBQUFBQSxFQUNULENBQUM7QUFFRCxRQUFNRyw2QkFBNkJBLENBQUM5QyxpQkFBaUI7QUFDbkQsUUFBSSxDQUFDQSxnQkFBZ0JBLGlCQUFpQixJQUFLLFFBQU87QUFFbEQsVUFBTStDLFFBQVEvQyxhQUFhK0MsTUFBTSxpQkFBaUI7QUFDbEQsUUFBSSxDQUFDQSxNQUFPLFFBQU87QUFFbkIsVUFBTXJDLFFBQVFzQyxTQUFTRCxNQUFNLENBQUMsR0FBRyxFQUFFO0FBQ25DLFVBQU1sQyxVQUFVbUMsU0FBU0QsTUFBTSxDQUFDLEdBQUcsRUFBRTtBQUVyQyxXQUFPckMsUUFBUSxLQUFLRztBQUFBQSxFQUN0QjtBQUVBLFFBQU1vQyxlQUFlQyxRQUFRLE1BQU07QUFDakMsVUFBTUMsUUFBUXRGLGVBQWV1RjtBQUc3QixRQUFJbkYscUJBQXFCLE9BQU87QUFDOUIsWUFBTW9GLGVBQWV4RixlQUFleUY7QUFBQUEsUUFDbEMsQ0FBQ0MsS0FBS0MsTUFBTUQsT0FBT0MsRUFBRTFCLGVBQWU7QUFBQSxRQUNwQztBQUFBLE1BQ0Y7QUFDQSxZQUFNMkIsY0FBYzVGLGVBQWV5RjtBQUFBQSxRQUNqQyxDQUFDQyxLQUFLQyxNQUFNRCxPQUFPQyxFQUFFekIsY0FBYztBQUFBLFFBQ25DO0FBQUEsTUFDRjtBQUNBLFlBQU0yQixnQkFBZ0I3RixlQUFleUY7QUFBQUEsUUFDbkMsQ0FBQ0MsS0FBS0MsTUFBTUQsT0FBT0MsRUFBRXhCLFlBQVk7QUFBQSxRQUNqQztBQUFBLE1BQ0Y7QUFDQSxZQUFNMkIsZUFBZTlGLGVBQWV5RjtBQUFBQSxRQUNsQyxDQUFDQyxLQUFLQyxNQUFNRCxPQUFPQyxFQUFFdkIsV0FBVztBQUFBLFFBQ2hDO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxRQUNMMkIsZ0JBQWdCVDtBQUFBQSxRQUNoQkU7QUFBQUEsUUFDQUk7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQUM7QUFBQUEsUUFDQUUsZ0JBQ0VSLGVBQWVJLGNBQWNDLGlCQUV4QkwsZ0JBQ0VBLGVBQWVJLGNBQWNDLGlCQUNoQyxLQUNBSSxRQUFRLENBQUMsSUFDVDtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBR0EsVUFBTUMsVUFBVWxHLGVBQWU2QixPQUFPLENBQUNzRSxNQUFNQSxFQUFFeEMsV0FBVyxTQUFTLEVBQUU0QjtBQUNyRSxVQUFNYSxTQUFTcEcsZUFBZTZCLE9BQU8sQ0FBQ3NFLE1BQU1BLEVBQUV4QyxXQUFXLFFBQVEsRUFBRTRCO0FBQ25FLFVBQU1jLFdBQVdyRyxlQUFlNkIsT0FBTyxDQUFDc0UsTUFBTUEsRUFBRXhDLFdBQVcsVUFBVSxFQUFFNEI7QUFDdkUsVUFBTWUsVUFBVXRHLGVBQWU2QixPQUFPLENBQUNzRSxNQUFNQSxFQUFFeEMsV0FBVyxVQUFVLEVBQUU0QjtBQUd0RSxVQUFNZ0IsZUFBZXZHLGVBQWV5RixPQUFPLENBQUNDLEtBQUtTLE1BQU07QUFDckQsYUFBT1QsTUFBTVQsMkJBQTJCa0IsRUFBRTlDLFlBQVk7QUFBQSxJQUN4RCxHQUFHLENBQUM7QUFFSixVQUFNbUQsYUFBYTFELEtBQUtDLE1BQU13RCxlQUFlLEVBQUU7QUFDL0MsVUFBTUUsbUJBQW1CRixlQUFlO0FBRXhDLFdBQU87QUFBQSxNQUNMRyxXQUFXcEI7QUFBQUEsTUFDWFk7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUM7QUFBQUEsTUFDQUssa0JBQWtCLEdBQUdILFVBQVUsS0FBS0MsZ0JBQWdCO0FBQUEsTUFDcERULGdCQUFnQlYsU0FBVVksVUFBVVosUUFBUyxLQUFLVyxRQUFRLENBQUMsSUFBSTtBQUFBLElBQ2pFO0FBQUEsRUFDRixHQUFHLENBQUNqRyxnQkFBZ0JJLGdCQUFnQixDQUFDO0FBRXJDLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDZFQUNiLGlDQUFDLFNBQUksV0FBVSxxQkFFYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxtRUFDYixpQ0FBQyxTQUFJLFdBQVUsZ0NBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsaUhBQ2IsaUNBQUMsb0JBQWlCLFdBQVUseUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQsS0FEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUNDO0FBQUEsK0JBQUMsUUFBRyxXQUFVLHFDQUFvQyx5Q0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFFBQzNFLHVCQUFDLE9BQUUsV0FBVSwrQkFBOEIsOERBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUY7QUFBQSxXQUYzRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxTQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBR0EsdUJBQUMsU0FBSSxXQUFVLG1FQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLGdDQUNiO0FBQUEsK0JBQUMsa0JBQWUsV0FBVSwyQkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQ2pELHVCQUFDLFFBQUcsV0FBVSx3Q0FBdUMsdUJBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEQ7QUFBQSxXQUY5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLCtCQUFDLFNBQUksV0FBVSx3QkFDYjtBQUFBLGlDQUFDLFdBQU0sV0FBVSxtREFBa0QsNEJBQW5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxNQUFLO0FBQUEsY0FDTCxXQUFVO0FBQUEsY0FDVixPQUFPUDtBQUFBQSxjQUNQLFVBQVUsQ0FBQzhGLE1BQU03RixnQkFBZ0I2RixFQUFFaUIsT0FBT0MsS0FBSztBQUFBLGNBQy9DLEtBQUt4SDtBQUFBQTtBQUFBQSxZQUxQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUt3QjtBQUFBLGFBVDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLHdCQUNiO0FBQUEsaUNBQUMsV0FBTSxXQUFVLG1EQUFrRCx3QkFBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLFVBQ0E7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDO0FBQUEsY0FDQSxXQUFVO0FBQUEsY0FDVixPQUFPLEVBQUV5SCxPQUFPLE9BQU87QUFBQSxjQUN2QixPQUFPMUc7QUFBQUEsY0FDUCxVQUFVQztBQUFBQSxjQUNWLGFBQVk7QUFBQSxjQUNaLE1BQUs7QUFBQSxjQUNMLGNBQWMsQ0FBQzBHLE9BQU9DLFdBQ3BCQSxPQUFPQyxTQUFTdEMsWUFBWSxFQUFFdUMsUUFBUUgsTUFBTXBDLFlBQVksQ0FBQyxLQUFLO0FBQUEsY0FHaEU7QUFBQSx1Q0FBQyxPQUFPLFFBQVAsRUFBYyxPQUFNLE9BQU0sNkJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXdDO0FBQUEsZ0JBQ3ZDekUsVUFBVThCO0FBQUFBLGtCQUFJLENBQUNGLFFBQ2QsdUJBQUMsT0FBTyxRQUFQLEVBQTRCLE9BQU9BLElBQUlxQixLQUNyQ3JCLGNBQUlrQyxRQURhbEMsSUFBSXFCLEtBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxnQkFDRDtBQUFBO0FBQUE7QUFBQSxZQWpCSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFrQkE7QUFBQSxhQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsUUFFQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsTUFBSztBQUFBLFlBQ0wsU0FBUzVCO0FBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQTBLO0FBQUE7QUFBQSxVQUp0TDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPQTtBQUFBLFdBOUNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUErQ0E7QUFBQSxTQXJERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0RBO0FBQUEsSUFHQSx1QkFBQyxTQUFJLFdBQVUsNkRBRWI7QUFBQSw2QkFBQyxTQUFJLFdBQVUsa0pBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsZ0JBQWEsV0FBVSx5QkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2QyxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSwyQ0FDVm5CLCtCQUFxQixRQUFRLG9CQUFvQixnQkFEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFFLFdBQVUsc0JBQ1ZBLCtCQUFxQixRQUNsQmdGLGFBQWFXLGlCQUNiWCxhQUFhc0IsYUFIbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFDQSx1QkFBQyxVQUFLLFdBQVcsaUNBQ2RoSSw4QkFBb0IwQixxQkFBcUIsUUFDdENnRixhQUFhVyxpQkFDYlgsYUFBYXNCLGFBQWEsQ0FBQyxLQUhqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxXQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUJBO0FBQUEsTUFHQ3RHLHFCQUFxQixTQUNwQix1QkFBQyxTQUFJLFdBQVUsb0pBQ2I7QUFBQSwrQkFBQyxTQUFJLFdBQVUsMENBQ2IsaUNBQUMsU0FBSSxXQUFVLHVFQUNiLGlDQUFDLFVBQUssV0FBVSxZQUFXLGlCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCLEtBRDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBQ0EsdUJBQUMsT0FBRSxXQUFVLDZDQUE0Qyx1QkFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRTtBQUFBLFFBQ2hFLHVCQUFDLE9BQUUsV0FBVSxzQkFBc0JnRix1QkFBYWMsV0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RDtBQUFBLFFBQ3hELHVCQUFDLFVBQUssV0FBVyxpQ0FDZHhILDhCQUFvQjBHLGFBQWFjLFdBQVcsQ0FBQyxLQURoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BSUQ5RixxQkFBcUIsU0FDcEIsdUJBQUMsU0FBSSxXQUFVLCtJQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFNBQUksV0FBVSx1RUFDYixpQ0FBQyxVQUFLLFdBQVUsWUFBVyxpQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QixLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSwwQ0FBeUMsc0JBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEQ7QUFBQSxRQUM1RCx1QkFBQyxPQUFFLFdBQVUsc0JBQXNCZ0YsdUJBQWFnQixVQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVEO0FBQUEsUUFDdkQsdUJBQUMsVUFBSyxXQUFXLGlDQUNkMUgsOEJBQW9CMEcsYUFBYWdCLFVBQVUsQ0FBQyxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFXQTtBQUFBLE1BSUYsdUJBQUMsU0FBSSxXQUFVLG1KQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFNBQUksV0FBVSx1RUFDYixpQ0FBQyxVQUFLLFdBQVUsWUFBVyxpQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QixLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSwyQ0FBMEMsd0JBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0Q7QUFBQSxRQUMvRCx1QkFBQyxPQUFFLFdBQVUsc0JBQ1ZoRywrQkFBcUIsUUFBUWdGLGFBQWFTLGdCQUFnQlQsYUFBYWlCLFlBRDFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsVUFBSyxXQUFXLGlDQUNkM0gsOEJBQW9CMEIscUJBQXFCLFFBQVFnRixhQUFhUyxnQkFBZ0JULGFBQWFpQixZQUFZLENBQUMsS0FEM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxNQUdBLHVCQUFDLFNBQUksV0FBVSx5SkFNYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSwwQ0FBeUMsd0JBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEQ7QUFBQSxRQUM5RCx1QkFBQyxPQUFFLFdBQVUsc0JBQ1ZqRywrQkFBcUIsUUFBUWdGLGFBQWFVLGVBQWVWLGFBQWFrQixXQUR6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFVBQUssV0FBVyxpQ0FDZDVILDhCQUFvQjBCLHFCQUFxQixRQUFRZ0YsYUFBYVUsZUFBZVYsYUFBYWtCLFdBQVcsQ0FBQyxLQUR6RztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BR0EsdUJBQUMsU0FBSSxXQUFVLG9KQUNiO0FBQUEsK0JBQUMsU0FBSSxXQUFVLDBDQUNiLGlDQUFDLFNBQUksV0FBVSx1RUFDYixpQ0FBQyxVQUFLLFdBQVUsWUFBVyxpQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QixLQUQ5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUE7QUFBQSxRQUNBLHVCQUFDLE9BQUUsV0FBVSw0Q0FBMkMsNEJBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0U7QUFBQSxRQUNwRSx1QkFBQyxPQUFFLFdBQVUsc0JBQXNCbEI7QUFBQUEsdUJBQWFZO0FBQUFBLFVBQWU7QUFBQSxhQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdFO0FBQUEsUUFDaEUsdUJBQUMsVUFBSyxXQUFXLGlDQUNkdEgsOEJBQW9CMEcsYUFBYVksa0JBQWtCLENBQUMsS0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUdDNUYscUJBQXFCLFNBQ3BCLHVCQUFDLFNBQUksV0FBVSxnSkFNYjtBQUFBLCtCQUFDLE9BQUUsV0FBVSwwQ0FBeUMsa0NBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUN4RSx1QkFBQyxPQUFFLFdBQVUsc0JBQXNCZ0YsdUJBQWF1QixvQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFdBUG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLFNBN0dKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0ErR0E7QUFBQSxJQUdBLHVCQUFDLFNBQUksV0FBVSw4REFDWnJHLG9CQUNDLHVCQUFDLFNBQUksV0FBVSxrREFDYjtBQUFBLDZCQUFDLFFBQUssTUFBSyxXQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0I7QUFBQSxNQUNsQix1QkFBQyxPQUFFLFdBQVUsdUJBQXNCLDBDQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZEO0FBQUEsU0FGL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBLElBRUEsbUNBQ0U7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsU0FBU0YscUJBQXFCLFFBQVFtRSxzQkFBc0JFO0FBQUFBLFVBQzVELE1BQU1HO0FBQUFBLFVBQ04saUJBQWdCO0FBQUEsVUFDaEIsa0JBQWtCO0FBQUEsVUFDbEI7QUFBQTtBQUFBLFFBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS21CO0FBQUEsTUFHbkIsdUJBQUMsU0FBSSxXQUFVLHVDQUNiLGlDQUFDLE9BQUUsV0FBVSwwQkFDWDtBQUFBLCtCQUFDLFVBQUssV0FBVSxlQUFjLHVDQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFEO0FBQUEsUUFBUTtBQUFBLFFBQzdELHVCQUFDLFVBQUssV0FBVSwrQkFBK0IvRSwwQkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0RDtBQUFBLFFBQzNETyxxQkFBcUIsU0FDcEIsTUFBTUYsVUFBVWlILEtBQUssQ0FBQ3hCLE1BQU1BLEVBQUV4QyxRQUFRL0MsZ0JBQWdCLEdBQUc0RCxRQUFRLEVBQUU7QUFBQSxXQUp2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxTQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBLEtBeEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQkE7QUFBQSxPQXBORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcU5BLEtBdE5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1TkE7QUFFSjtBQUFFcEYsR0FqZUlELHVCQUFxQjtBQUFBeUksS0FBckJ6STtBQW1lTixlQUFlQTtBQUFzQixJQUFBeUk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsIkRhdGFUYWJsZSIsImFwaSIsIlNlbGVjdCIsIlNwaW4iLCJCdXR0b24iLCJUYWciLCJDYWxlbmRhck91dGxpbmVkIiwiVXNlck91dGxpbmVkIiwiRmlsdGVyT3V0bGluZWQiLCJkYXlqcyIsImR1cmF0aW9uIiwiZXh0ZW5kIiwibnVtYmVyVG9JbmRpYW5Xb3JkcyIsIkVtcGxveWVlTW9udGhseVJlcG9ydCIsIl9zIiwidG9kYXkiLCJEYXRlIiwiY3VycmVudFllYXIiLCJnZXRGdWxsWWVhciIsImN1cnJlbnRNb250aCIsIlN0cmluZyIsImdldE1vbnRoIiwicGFkU3RhcnQiLCJjdXJyZW50WWVhck1vbnRoIiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJ5ZWFyIiwibW9udGgiLCJzbGljZSIsImRheSIsImdldERhdGUiLCJzZWxlY3RlZERhdGUiLCJzZXRTZWxlY3RlZERhdGUiLCJ1c2VTdGF0ZSIsImF0dGVuZGFuY2VEYXRhIiwic2V0QXR0ZW5kYW5jZURhdGEiLCJlbXBsb3llZXMiLCJzZXRFbXBsb3llZXMiLCJzZWxlY3RlZEVtcGxveWVlIiwic2V0U2VsZWN0ZWRFbXBsb3llZSIsImxvYWRpbmciLCJzZXRMb2FkaW5nIiwiZ2V0TW9udGhSYW5nZSIsInllYXJNb250aCIsInNwbGl0IiwiZmlyc3REYXkiLCJsYXN0RGF5IiwiZnJvbV9kYXRlIiwidG9fZGF0ZSIsImZldGNoRW1wbG95ZWVzIiwicmVzIiwiZ2V0IiwiZGF0YSIsImVtcGxveWVlIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwiZmV0Y2hBdHRlbmRhbmNlRGF0YSIsInBhcmFtcyIsImVtcGxveWVlX2lkIiwiYXR0ZW5kYW5jZVJlc3BvbnNlIiwiYXR0ZW5kYW5jZURhdGFSZXNwb25zZSIsImZvcm1hdHRlZCIsImZpbHRlciIsImVtcCIsImlzVmVyaWZpZWQiLCJtYXAiLCJyZWMiLCJpbmRleCIsIndvcmtpbmdIb3VycyIsImxvZ2luVGltZSIsInRpbWUiLCJsb2dvdXRUaW1lIiwibG9nb3V0X3RpbWUiLCJzdGFydCIsImVuZCIsImlzVmFsaWQiLCJkaWZmTWludXRlcyIsImRpZmYiLCJob3VycyIsIk1hdGgiLCJmbG9vciIsIm1pbnV0ZXMiLCJzbE5vIiwia2V5IiwiX2lkIiwib3V0VGltZSIsIldvcmtpbmdIb3VycyIsImFwcHJvdmFsX3N0YXR1cyIsInRvTG9jYWxlRGF0ZVN0cmluZyIsIndlZWtkYXkiLCJOb3RlIiwibm90ZSIsInN0YXR1cyIsImdyb3VwZWQiLCJmb3JFYWNoIiwicmVjb3JkIiwiRW1wbG95ZWVOYW1lIiwibmFtZSIsIlByZXNlbnREYXlzIiwiQWJzZW50RGF5cyIsIkhhbGZEYXlzIiwiT25MZWF2ZSIsIk9iamVjdCIsInZhbHVlcyIsImFsbEVtcGxveWVlc0NvbHVtbnMiLCJoZWFkZXIiLCJpbmRpdmlkdWFsQ29sdW1ucyIsInJlbmRlciIsInRvTG93ZXJDYXNlIiwic2FmZURhdGEiLCJyb3ciLCJjbGVhbiIsImtleXMiLCJ1bmRlZmluZWQiLCJwYXJzZVdvcmtpbmdIb3Vyc1RvTWludXRlcyIsIm1hdGNoIiwicGFyc2VJbnQiLCJzdW1tYXJ5U3RhdHMiLCJ1c2VNZW1vIiwidG90YWwiLCJsZW5ndGgiLCJ0b3RhbFByZXNlbnQiLCJyZWR1Y2UiLCJzdW0iLCJlIiwidG90YWxBYnNlbnQiLCJ0b3RhbEhhbGZEYXlzIiwidG90YWxPbkxlYXZlIiwidG90YWxFbXBsb3llZXMiLCJwcmVzZW50UGVyY2VudCIsInRvRml4ZWQiLCJwcmVzZW50IiwiciIsImFic2VudCIsImhhbGZEYXlzIiwib25MZWF2ZSIsInRvdGFsTWludXRlcyIsInRvdGFsSG91cnMiLCJyZW1haW5pbmdNaW51dGVzIiwidG90YWxEYXlzIiwidG90YWxXb3JraW5nVGltZSIsInRhcmdldCIsInZhbHVlIiwid2lkdGgiLCJpbnB1dCIsIm9wdGlvbiIsImNoaWxkcmVuIiwiaW5kZXhPZiIsImZpbmQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJFbXBsb3llZU1vbnRobHlSZXBvcnQuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZU1lbW8gfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiXHJcbmltcG9ydCBhcGkgZnJvbSBcIi4uL2luc3RhbmNlL1Rva2VuSW5zdGFuY2VcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBTcGluLCBCdXR0b24sIFRhZyB9IGZyb20gXCJhbnRkXCI7XHJcbmltcG9ydCB7IENhbGVuZGFyT3V0bGluZWQsIFVzZXJPdXRsaW5lZCwgRmlsdGVyT3V0bGluZWQgfSBmcm9tICdAYW50LWRlc2lnbi9pY29ucyc7XHJcbmltcG9ydCBkYXlqcyBmcm9tIFwiZGF5anNcIjtcclxuaW1wb3J0IGR1cmF0aW9uIGZyb20gXCJkYXlqcy9wbHVnaW4vZHVyYXRpb25cIjtcclxuXHJcbmRheWpzLmV4dGVuZChkdXJhdGlvbik7XHJcblxyXG5pbXBvcnQgeyBudW1iZXJUb0luZGlhbldvcmRzIH0gZnJvbSBcIi4uL2hlbHBlcnMvbnVtYmVyVG9JbmRpYW5Xb3Jkc1wiXHJcblxyXG4vLyBjb25zdCBFbXBsb3llZU1vbnRobHlSZXBvcnQgPSAoKSA9PiB7XHJcbi8vICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xyXG4vLyAgIGNvbnN0IGN1cnJlbnRZZWFyID0gdG9kYXkuZ2V0RnVsbFllYXIoKTtcclxuLy8gICBjb25zdCBjdXJyZW50TW9udGggPSBTdHJpbmcodG9kYXkuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcclxuLy8gICBjb25zdCBjdXJyZW50WWVhck1vbnRoID0gYCR7Y3VycmVudFllYXJ9LSR7Y3VycmVudE1vbnRofWA7XHJcblxyXG4vLyAgIGNvbnN0IGZvcm1hdERhdGUgPSAoZGF0ZSkgPT4ge1xyXG4vLyAgICAgY29uc3QgeWVhciA9IGRhdGUuZ2V0RnVsbFllYXIoKTtcclxuLy8gICAgIGNvbnN0IG1vbnRoID0gYDAke2RhdGUuZ2V0TW9udGgoKSArIDF9YC5zbGljZSgtMik7XHJcbi8vICAgICBjb25zdCBkYXkgPSBgMCR7ZGF0ZS5nZXREYXRlKCl9YC5zbGljZSgtMik7XHJcbi8vICAgICByZXR1cm4gYCR7eWVhcn0tJHttb250aH0tJHtkYXl9YDtcclxuLy8gICB9O1xyXG5cclxuLy8gICBjb25zdCBbc2VsZWN0ZWREYXRlLCBzZXRTZWxlY3RlZERhdGVdID0gdXNlU3RhdGUoY3VycmVudFllYXJNb250aCk7XHJcbi8vICAgY29uc3QgW2F0dGVuZGFuY2VEYXRhLCBzZXRBdHRlbmRhbmNlRGF0YV0gPSB1c2VTdGF0ZShbXSk7XHJcbi8vICAgY29uc3QgW2VtcGxveWVlcywgc2V0RW1wbG95ZWVzXSA9IHVzZVN0YXRlKFtdKTtcclxuLy8gICBjb25zdCBbc2VsZWN0ZWRFbXBsb3llZSwgc2V0U2VsZWN0ZWRFbXBsb3llZV0gPSB1c2VTdGF0ZShcImFsbFwiKTtcclxuLy8gICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4vLyAgIGNvbnN0IGdldE1vbnRoUmFuZ2UgPSAoeWVhck1vbnRoKSA9PiB7XHJcbi8vICAgICBjb25zdCBbeWVhciwgbW9udGhdID0geWVhck1vbnRoLnNwbGl0KFwiLVwiKTtcclxuLy8gICAgIGNvbnN0IGZpcnN0RGF5ID0gbmV3IERhdGUoeWVhciwgbW9udGggLSAxLCAxKTtcclxuLy8gICAgIGNvbnN0IGxhc3REYXkgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCwgMCk7XHJcbi8vICAgICByZXR1cm4ge1xyXG4vLyAgICAgICBmcm9tX2RhdGU6IGZvcm1hdERhdGUoZmlyc3REYXkpLFxyXG4vLyAgICAgICB0b19kYXRlOiBmb3JtYXREYXRlKGxhc3REYXkpLFxyXG4vLyAgICAgfTtcclxuLy8gICB9O1xyXG5cclxuLy8gICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4vLyAgICAgY29uc3QgZmV0Y2hFbXBsb3llZXMgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgICAgIHRyeSB7XHJcbi8vICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9lbXBsb3llZVwiKTtcclxuLy8gICAgICAgICBzZXRFbXBsb3llZXMocmVzLmRhdGEuZW1wbG95ZWUgfHwgW10pO1xyXG4vLyAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuLy8gICAgICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgZW1wbG95ZWVzOlwiLCBlcnIpO1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9O1xyXG4vLyAgICAgZmV0Y2hFbXBsb3llZXMoKTtcclxuLy8gICB9LCBbXSk7XHJcblxyXG4vLyAgIC8vIGNvbnN0IGZldGNoQXR0ZW5kYW5jZURhdGEgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgLy8gICBzZXRMb2FkaW5nKHRydWUpO1xyXG4vLyAgIC8vICAgdHJ5IHtcclxuLy8gICAvLyAgICAgY29uc3QgeyBmcm9tX2RhdGUsIHRvX2RhdGUgfSA9IGdldE1vbnRoUmFuZ2Uoc2VsZWN0ZWREYXRlKTtcclxuLy8gICAvLyAgICAgY29uc3QgcGFyYW1zID0ge1xyXG4vLyAgIC8vICAgICAgIGZyb21fZGF0ZSxcclxuLy8gICAvLyAgICAgICB0b19kYXRlLFxyXG4vLyAgIC8vICAgICAgIGVtcGxveWVlX2lkOiBzZWxlY3RlZEVtcGxveWVlICE9PSBcImFsbFwiID8gc2VsZWN0ZWRFbXBsb3llZSA6IFwiXCIsXHJcbi8vICAgLy8gICAgIH07XHJcblxyXG4vLyAgIC8vICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlLWF0dGVuZGFuY2UvbW9udGhseS1yZXBvcnRcIiwgeyBwYXJhbXMgfSk7XHJcbi8vICAgLy8gICAgIGNvbnN0IGF0dGVuZGFuY2VSZXNwb25zZSA9IHJlcy5kYXRhLmF0dGVuZGFuY2VEYXRhUmVzcG9uc2UgfHwgW107XHJcblxyXG4vLyAgIC8vICAgICBpZiAoc2VsZWN0ZWRFbXBsb3llZSAhPT0gXCJhbGxcIikge1xyXG5cclxuLy8gICAvLyAgICAgICBjb25zdCBmb3JtYXR0ZWQgPSBhdHRlbmRhbmNlUmVzcG9uc2UubWFwKChyZWMsIGluZGV4KSA9PiAoe1xyXG4vLyAgIC8vICAgICAgICAgc2xObzogaW5kZXggKyAxLFxyXG4vLyAgIC8vICAgICAgICAga2V5OiByZWMuX2lkIHx8IGluZGV4LFxyXG4vLyAgIC8vICAgICAgICAgZGF0ZTogcmVjPy5kYXRlID8gcmVjLmRhdGUuc3BsaXQoXCJUXCIpWzBdIDogXCJcIixcclxuLy8gICAvLyAgICAgICAgIHRpbWU6IHJlYz8udGltZSB8fCBcIlwiLFxyXG4vLyAgIC8vICAgICAgICAgb3V0VGltZTogcmVjPy5sb2dvdXRfdGltZSB8fCBcIlwiLFxyXG4vLyAgIC8vICAgICAgICAgIFdvcmtpbmdIb3Vyczogd29ya2luZ0hvdXJzLFxyXG4vLyAgIC8vICAgICAgICAgZGF5OiByZWM/LmRhdGVcclxuLy8gICAvLyAgICAgICAgICAgPyBuZXcgRGF0ZShyZWMuZGF0ZSkudG9Mb2NhbGVEYXRlU3RyaW5nKFwiZW4tVVNcIiwgeyB3ZWVrZGF5OiBcInNob3J0XCIgfSlcclxuLy8gICAvLyAgICAgICAgICAgOiBcIlwiLFxyXG4vLyAgIC8vICAgICAgICAgTm90ZTogcmVjPy5ub3RlIHx8IFwiXCIsXHJcbi8vICAgLy8gICAgICAgICBzdGF0dXM6IHJlYz8uc3RhdHVzIHx8IFwiXCIsXHJcbi8vICAgLy8gICAgICAgfSkpO1xyXG4vLyAgIC8vICAgICAgIHNldEF0dGVuZGFuY2VEYXRhKGZvcm1hdHRlZCk7XHJcbi8vICAgLy8gICAgIH0gZWxzZSB7XHJcbi8vICAgLy8gICAgICAgY29uc3QgZ3JvdXBlZCA9IHt9O1xyXG4vLyAgIC8vICAgICAgIGF0dGVuZGFuY2VSZXNwb25zZS5mb3JFYWNoKChyZWNvcmQsIGluZGV4KSA9PiB7XHJcbi8vICAgLy8gICAgICAgICBjb25zdCBlbXAgPSByZWNvcmQ/LmVtcGxveWVlX2lkO1xyXG4vLyAgIC8vICAgICAgICAgaWYgKCFlbXA/Ll9pZCkgcmV0dXJuO1xyXG5cclxuLy8gICAvLyAgICAgICAgIGlmICghZ3JvdXBlZFtlbXAuX2lkXSkge1xyXG4vLyAgIC8vICAgICAgICAgICBncm91cGVkW2VtcC5faWRdID0ge1xyXG4vLyAgIC8vICAgICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuLy8gICAvLyAgICAgICAgICAgICBrZXk6IGVtcC5faWQsXHJcbi8vICAgLy8gICAgICAgICAgICAgRW1wbG95ZWVOYW1lOiBlbXA/Lm5hbWUgfHwgXCJcIixcclxuLy8gICAvLyAgICAgICAgICAgICBQcmVzZW50RGF5czogMCxcclxuLy8gICAvLyAgICAgICAgICAgICBBYnNlbnREYXlzOiAwLFxyXG4vLyAgIC8vICAgICAgICAgICAgIEhhbGZEYXlzOiAwLFxyXG4vLyAgIC8vICAgICAgICAgICB9O1xyXG4vLyAgIC8vICAgICAgICAgfVxyXG4vLyAgIC8vICAgICAgICAgaWYgKHJlY29yZD8uc3RhdHVzID09PSBcIlByZXNlbnRcIikgZ3JvdXBlZFtlbXAuX2lkXS5QcmVzZW50RGF5cysrO1xyXG4vLyAgIC8vICAgICAgICAgaWYgKHJlY29yZD8uc3RhdHVzID09PSBcIkFic2VudFwiKSBncm91cGVkW2VtcC5faWRdLkFic2VudERheXMrKztcclxuLy8gICAvLyAgICAgICAgIGlmIChyZWNvcmQ/LnN0YXR1cyA9PT0gXCJIYWxmIERheVwiKSBncm91cGVkW2VtcC5faWRdLkhhbGZEYXlzKys7XHJcbi8vICAgLy8gICAgICAgfSk7XHJcbi8vICAgLy8gICAgICAgc2V0QXR0ZW5kYW5jZURhdGEoT2JqZWN0LnZhbHVlcyhncm91cGVkKSk7XHJcbi8vICAgLy8gICAgIH1cclxuLy8gICAvLyAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgIC8vICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgZmV0Y2hpbmcgYXR0ZW5kYW5jZTpcIiwgZXJyKTtcclxuLy8gICAvLyAgIH0gZmluYWxseSB7XHJcbi8vICAgLy8gICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4vLyAgIC8vICAgfVxyXG4vLyAgIC8vIH07XHJcblxyXG4vLyAgIGNvbnN0IGZldGNoQXR0ZW5kYW5jZURhdGEgPSBhc3luYyAoKSA9PiB7XHJcbi8vICAgc2V0TG9hZGluZyh0cnVlKTtcclxuXHJcbi8vICAgdHJ5IHtcclxuLy8gICAgIGNvbnN0IHsgZnJvbV9kYXRlLCB0b19kYXRlIH0gPSBnZXRNb250aFJhbmdlKHNlbGVjdGVkRGF0ZSk7XHJcblxyXG4vLyAgICAgY29uc3QgcGFyYW1zID0ge1xyXG4vLyAgICAgICBmcm9tX2RhdGUsXHJcbi8vICAgICAgIHRvX2RhdGUsXHJcbi8vICAgICAgIGVtcGxveWVlX2lkOiBzZWxlY3RlZEVtcGxveWVlICE9PSBcImFsbFwiID8gc2VsZWN0ZWRFbXBsb3llZSA6IFwiXCIsXHJcbi8vICAgICB9O1xyXG5cclxuLy8gICAgIGNvbnN0IHJlcyA9IGF3YWl0IGFwaS5nZXQoXCIvZW1wbG95ZWUtYXR0ZW5kYW5jZS9tb250aGx5LXJlcG9ydFwiLCB7IHBhcmFtcyB9KTtcclxuLy8gICAgIGNvbnN0IGF0dGVuZGFuY2VSZXNwb25zZSA9IHJlcy5kYXRhLmF0dGVuZGFuY2VEYXRhUmVzcG9uc2UgfHwgW107XHJcblxyXG4vLyAgICAgLy8gPT09PT09PT09PT09PT09PT09PT09IFNJTkdMRSBFTVBMT1lFRSBWSUVXID09PT09PT09PT09PT09PT09PT09PVxyXG4vLyAgICAgaWYgKHNlbGVjdGVkRW1wbG95ZWUgIT09IFwiYWxsXCIpIHtcclxuLy8gICAgICAgY29uc3QgZm9ybWF0dGVkID0gYXR0ZW5kYW5jZVJlc3BvbnNlLm1hcCgocmVjLCBpbmRleCkgPT4ge1xyXG4vLyAgICAgICAgIGxldCB3b3JraW5nSG91cnMgPSBcIi1cIjtcclxuXHJcbi8vICAgICAgICAgY29uc3QgbG9naW5UaW1lID0gcmVjPy50aW1lOyAgICAgICAgICAvLyBlLmcuIFwiMTA6NTA6MjIgYW1cIlxyXG4vLyAgICAgICAgIGNvbnN0IGxvZ291dFRpbWUgPSByZWM/LmxvZ291dF90aW1lOyAgLy8gZS5nLiBcIjI6NDE6MjkgcG1cIlxyXG5cclxuLy8gICAgICAgICBpZiAobG9naW5UaW1lICYmIGxvZ291dFRpbWUpIHtcclxuLy8gICAgICAgICAgIGNvbnN0IHN0YXJ0ID0gZGF5anMobG9naW5UaW1lLCBcImhoOm1tOnNzIGFcIik7XHJcbi8vICAgICAgICAgICBjb25zdCBlbmQgPSBkYXlqcyhsb2dvdXRUaW1lLCBcImhoOm1tOnNzIGFcIik7XHJcblxyXG4vLyAgICAgICAgICAgaWYgKHN0YXJ0LmlzVmFsaWQoKSAmJiBlbmQuaXNWYWxpZCgpKSB7XHJcbi8vICAgICAgICAgICAgIGxldCBkaWZmTWludXRlcyA9IGVuZC5kaWZmKHN0YXJ0LCBcIm1pbnV0ZVwiKTtcclxuXHJcbi8vICAgICAgICAgICAgIC8vIEhhbmRsZSBvdmVybmlnaHQgc2hpZnRzIChvcHRpb25hbCBzYWZldHkpXHJcbi8vICAgICAgICAgICAgIGlmIChkaWZmTWludXRlcyA8IDApIHtcclxuLy8gICAgICAgICAgICAgICBkaWZmTWludXRlcyArPSAyNCAqIDYwO1xyXG4vLyAgICAgICAgICAgICB9XHJcblxyXG4vLyAgICAgICAgICAgICBjb25zdCBob3VycyA9IE1hdGguZmxvb3IoZGlmZk1pbnV0ZXMgLyA2MCk7XHJcbi8vICAgICAgICAgICAgIGNvbnN0IG1pbnV0ZXMgPSBkaWZmTWludXRlcyAlIDYwO1xyXG5cclxuLy8gICAgICAgICAgICAgd29ya2luZ0hvdXJzID0gYCR7aG91cnN9aCAke21pbnV0ZXN9bWA7XHJcbi8vICAgICAgICAgICB9XHJcbi8vICAgICAgICAgfVxyXG5cclxuLy8gICAgICAgICByZXR1cm4ge1xyXG4vLyAgICAgICAgICAgc2xObzogaW5kZXggKyAxLFxyXG4vLyAgICAgICAgICAga2V5OiByZWMuX2lkIHx8IGluZGV4LFxyXG4vLyAgICAgICAgICAgZGF0ZTogcmVjPy5kYXRlID8gcmVjLmRhdGUuc3BsaXQoXCJUXCIpWzBdIDogXCJcIixcclxuLy8gICAgICAgICAgIHRpbWU6IHJlYz8udGltZSB8fCBcIlwiLFxyXG4vLyAgICAgICAgICAgb3V0VGltZTogcmVjPy5sb2dvdXRfdGltZSB8fCBcIlwiLFxyXG4vLyAgICAgICAgICAgV29ya2luZ0hvdXJzOiB3b3JraW5nSG91cnMsXHJcbi8vICAgICAgICAgICBkYXk6IHJlYz8uZGF0ZVxyXG4vLyAgICAgICAgICAgICA/IG5ldyBEYXRlKHJlYy5kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoXCJlbi1VU1wiLCB7IHdlZWtkYXk6IFwic2hvcnRcIiB9KVxyXG4vLyAgICAgICAgICAgICA6IFwiXCIsXHJcbi8vICAgICAgICAgICBOb3RlOiByZWM/Lm5vdGUgfHwgXCJcIixcclxuLy8gICAgICAgICAgIHN0YXR1czogcmVjPy5zdGF0dXMgfHwgXCJcIixcclxuLy8gICAgICAgICB9O1xyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIHNldEF0dGVuZGFuY2VEYXRhKGZvcm1hdHRlZCk7XHJcbi8vICAgICB9XHJcblxyXG4vLyAgICAgLy8gPT09PT09PT09PT09PT09PT09PT09IEFMTCBFTVBMT1lFRVMgU1VNTUFSWSA9PT09PT09PT09PT09PT09PT09PT1cclxuLy8gICAgIGVsc2Uge1xyXG4vLyAgICAgICBjb25zdCBncm91cGVkID0ge307XHJcblxyXG4vLyAgICAgICBhdHRlbmRhbmNlUmVzcG9uc2UuZm9yRWFjaCgocmVjb3JkLCBpbmRleCkgPT4ge1xyXG4vLyAgICAgICAgIGNvbnN0IGVtcCA9IHJlY29yZD8uZW1wbG95ZWVfaWQ7XHJcbi8vICAgICAgICAgaWYgKCFlbXA/Ll9pZCkgcmV0dXJuO1xyXG5cclxuLy8gICAgICAgICBpZiAoIWdyb3VwZWRbZW1wLl9pZF0pIHtcclxuLy8gICAgICAgICAgIGdyb3VwZWRbZW1wLl9pZF0gPSB7XHJcbi8vICAgICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuLy8gICAgICAgICAgICAga2V5OiBlbXAuX2lkLFxyXG4vLyAgICAgICAgICAgICBFbXBsb3llZU5hbWU6IGVtcD8ubmFtZSB8fCBcIlwiLFxyXG4vLyAgICAgICAgICAgICBQcmVzZW50RGF5czogMCxcclxuLy8gICAgICAgICAgICAgQWJzZW50RGF5czogMCxcclxuLy8gICAgICAgICAgICAgSGFsZkRheXM6IDAsXHJcbi8vICAgICAgICAgICAgIE9uTGVhdmU6IDAsXHJcbi8vICAgICAgICAgICB9O1xyXG4vLyAgICAgICAgIH1cclxuXHJcbi8vICAgICAgICAgaWYgKHJlY29yZD8uc3RhdHVzID09PSBcIlByZXNlbnRcIikgZ3JvdXBlZFtlbXAuX2lkXS5QcmVzZW50RGF5cysrO1xyXG4vLyAgICAgICAgIGlmIChyZWNvcmQ/LnN0YXR1cyA9PT0gXCJBYnNlbnRcIikgZ3JvdXBlZFtlbXAuX2lkXS5BYnNlbnREYXlzKys7XHJcbi8vICAgICAgICAgaWYgKHJlY29yZD8uc3RhdHVzID09PSBcIkhhbGYgRGF5XCIpIGdyb3VwZWRbZW1wLl9pZF0uSGFsZkRheXMrKztcclxuLy8gICAgICAgICBpZiAocmVjb3JkPy5zdGF0dXMgPT09IFwiT24gTGVhdmVcIikgZ3JvdXBlZFtlbXAuX2lkXS5PbkxlYXZlKys7XHJcblxyXG4vLyAgICAgICB9KTtcclxuXHJcbi8vICAgICAgIHNldEF0dGVuZGFuY2VEYXRhKE9iamVjdC52YWx1ZXMoZ3JvdXBlZCkpO1xyXG4vLyAgICAgfVxyXG4vLyAgIH0gY2F0Y2ggKGVycikge1xyXG4vLyAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGZldGNoaW5nIGF0dGVuZGFuY2U6XCIsIGVycik7XHJcbi8vICAgfSBmaW5hbGx5IHtcclxuLy8gICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4vLyAgIH1cclxuLy8gfTtcclxuXHJcbi8vICAgdXNlRWZmZWN0KCgpID0+IHtcclxuLy8gICAgIGZldGNoQXR0ZW5kYW5jZURhdGEoKTtcclxuLy8gICB9LCBbc2VsZWN0ZWRFbXBsb3llZSwgc2VsZWN0ZWREYXRlXSk7XHJcblxyXG4vLyAgIGNvbnN0IGFsbEVtcGxveWVlc0NvbHVtbnMgPSBbXHJcbi8vICAgICB7IGhlYWRlcjogXCJTbCBOb1wiLCBrZXk6IFwic2xOb1wiLCB9LFxyXG4vLyAgICAgeyBoZWFkZXI6IFwiRW1wbG95ZWUgTmFtZVwiLCBrZXk6IFwiRW1wbG95ZWVOYW1lXCIgfSxcclxuLy8gICAgIHsgaGVhZGVyOiBcIlByZXNlbnQgRGF5c1wiLCBrZXk6IFwiUHJlc2VudERheXNcIiB9LFxyXG4vLyAgICAgeyBoZWFkZXI6IFwiQWJzZW50IERheXNcIiwga2V5OiBcIkFic2VudERheXNcIn0sXHJcbi8vICAgICB7IGhlYWRlcjogXCJIYWxmIERheXNcIiwga2V5OiBcIkhhbGZEYXlzXCJ9LFxyXG4vLyAgICAge2hlYWRlcjogXCJPbiBMZWF2ZVwiLCBrZXk6IFwiT25MZWF2ZVwifVxyXG4vLyAgIF07XHJcblxyXG4vLyAgIGNvbnN0IGluZGl2aWR1YWxDb2x1bW5zID0gW1xyXG4vLyAgICAgeyBoZWFkZXI6IFwiU2wgTm9cIiwga2V5OiBcInNsTm9cIiB9LFxyXG4vLyAgICAgeyBoZWFkZXI6IFwiRGF0ZVwiLCBrZXk6IFwiZGF0ZVwiIH0sXHJcbi8vICAgICB7IGhlYWRlcjogXCJJbi1UaW1lXCIsIGtleTogXCJ0aW1lXCIgfSxcclxuLy8gICAgIHtoZWFkZXI6IFwiT3V0LVRpbWVcIiwga2V5OiBcIm91dFRpbWVcIn0sXHJcbi8vICAgICAge2hlYWRlcjogXCJXb3JraW5nIEhvdXJzXCIsIGtleTogXCJXb3JraW5nSG91cnNcIn0sXHJcbi8vICAgICB7IGhlYWRlcjogXCJEYXlcIiwga2V5OiBcImRheVwiIH0sXHJcbi8vICAgICB7aGVhZGVyOiBcIk5vdGVcIiwga2V5OiBcIk5vdGVcIn0sXHJcbi8vICAgICB7XHJcbi8vICAgICAgIGhlYWRlcjogXCJTdGF0dXNcIixcclxuLy8gICAgICAga2V5OiBcInN0YXR1c1wiLFxyXG4vLyAgICAgICByZW5kZXI6IChzdGF0dXMpID0+IHtcclxuLy8gICAgICAgICBpZiAoc3RhdHVzPy50b0xvd2VyQ2FzZSgpID09PSBcInByZXNlbnRcIikge1xyXG4vLyAgICAgICAgICAgcmV0dXJuIDxUYWcgY29sb3I9XCJncmVlblwiPlByZXNlbnQ8L1RhZz47XHJcbi8vICAgICAgICAgfSBlbHNlIGlmIChzdGF0dXM/LnRvTG93ZXJDYXNlKCkgPT09IFwiYWJzZW50XCIpIHtcclxuLy8gICAgICAgICAgIHJldHVybiA8VGFnIGNvbG9yPVwicmVkXCI+QWJzZW50PC9UYWc+O1xyXG4vLyAgICAgICAgIH0gZWxzZSBpZiAoc3RhdHVzPy50b0xvd2VyQ2FzZSgpID09PSBcImhhbGYgZGF5XCIpIHtcclxuLy8gICAgICAgICAgIHJldHVybiA8VGFnIGNvbG9yPVwib3JhbmdlXCI+SGFsZiBEYXk8L1RhZz47XHJcbi8vICAgICAgICAgfVxyXG4vLyAgICAgICAgIHJldHVybiBzdGF0dXMgfHwgXCJcIjtcclxuLy8gICAgICAgfSxcclxuLy8gICAgIH0sXHJcbi8vICAgXTtcclxuXHJcbi8vICAgY29uc3Qgc2FmZURhdGEgPSBhdHRlbmRhbmNlRGF0YS5tYXAoKHJvdykgPT4ge1xyXG4vLyAgICAgY29uc3QgY2xlYW4gPSB7fTtcclxuLy8gICAgIE9iamVjdC5rZXlzKHJvdykuZm9yRWFjaCgoa2V5KSA9PiB7XHJcbi8vICAgICAgIGNsZWFuW2tleV0gPVxyXG4vLyAgICAgICAgIHJvd1trZXldID09PSBudWxsIHx8IHJvd1trZXldID09PSB1bmRlZmluZWQgPyBcIlwiIDogU3RyaW5nKHJvd1trZXldKTtcclxuLy8gICAgIH0pO1xyXG4vLyAgICAgcmV0dXJuIGNsZWFuO1xyXG4vLyAgIH0pO1xyXG5cclxuLy8gICAvLyBjb25zdCBzdW1tYXJ5U3RhdHMgPSB1c2VNZW1vKCgpID0+IHtcclxuLy8gICAvLyAgIGNvbnN0IHRvdGFsID0gYXR0ZW5kYW5jZURhdGEubGVuZ3RoO1xyXG5cclxuLy8gICAvLyAgIGlmIChzZWxlY3RlZEVtcGxveWVlID09PSBcImFsbFwiKSB7XHJcbi8vICAgLy8gICAgIGNvbnN0IHRvdGFsUHJlc2VudCA9IGF0dGVuZGFuY2VEYXRhLnJlZHVjZSgoc3VtLCBlKSA9PiBzdW0gKyAoZS5QcmVzZW50RGF5cyB8fCAwKSwgMCk7XHJcbi8vICAgLy8gICAgIGNvbnN0IHRvdGFsQWJzZW50ID0gYXR0ZW5kYW5jZURhdGEucmVkdWNlKChzdW0sIGUpID0+IHN1bSArIChlLkFic2VudERheXMgfHwgMCksIDApO1xyXG4vLyAgIC8vICAgICBjb25zdCB0b3RhbEhhbGZEYXlzID0gYXR0ZW5kYW5jZURhdGEucmVkdWNlKChzdW0sIGUpID0+IHN1bSArIChlLkhhbGZEYXlzIHx8IDApLCAwKTtcclxuXHJcbi8vICAgLy8gICAgIHJldHVybiB7XHJcbi8vICAgLy8gICAgICAgdG90YWxFbXBsb3llZXM6IHRvdGFsLFxyXG4vLyAgIC8vICAgICAgIHRvdGFsUHJlc2VudCxcclxuLy8gICAvLyAgICAgICB0b3RhbEFic2VudCxcclxuLy8gICAvLyAgICAgICB0b3RhbEhhbGZEYXlzLFxyXG4vLyAgIC8vICAgICAgIHByZXNlbnRQZXJjZW50OiB0b3RhbCA/ICgodG90YWxQcmVzZW50IC8gKHRvdGFsUHJlc2VudCArIHRvdGFsQWJzZW50ICsgdG90YWxIYWxmRGF5cykpICogMTAwKS50b0ZpeGVkKDEpIDogMCxcclxuLy8gICAvLyAgICAgfTtcclxuLy8gICAvLyAgIH1cclxuXHJcbi8vICAgLy8gICBjb25zdCBwcmVzZW50ID0gYXR0ZW5kYW5jZURhdGEuZmlsdGVyKChyKSA9PiByLnN0YXR1cyA9PT0gXCJQcmVzZW50XCIpLmxlbmd0aDtcclxuLy8gICAvLyAgIGNvbnN0IGFic2VudCA9IGF0dGVuZGFuY2VEYXRhLmZpbHRlcigocikgPT4gci5zdGF0dXMgPT09IFwiQWJzZW50XCIpLmxlbmd0aDtcclxuLy8gICAvLyAgIGNvbnN0IGhhbGZEYXlzID0gYXR0ZW5kYW5jZURhdGEuZmlsdGVyKChyKSA9PiByLnN0YXR1cyA9PT0gXCJIYWxmIERheVwiKS5sZW5ndGg7XHJcblxyXG4vLyAgIC8vICAgcmV0dXJuIHtcclxuLy8gICAvLyAgICAgdG90YWxEYXlzOiB0b3RhbCxcclxuLy8gICAvLyAgICAgcHJlc2VudCxcclxuLy8gICAvLyAgICAgYWJzZW50LFxyXG4vLyAgIC8vICAgICBoYWxmRGF5cyxcclxuLy8gICAvLyAgICAgcHJlc2VudFBlcmNlbnQ6IHRvdGFsID8gKChwcmVzZW50IC8gdG90YWwpICogMTAwKS50b0ZpeGVkKDEpIDogMCxcclxuLy8gICAvLyAgIH07XHJcbi8vICAgLy8gfSwgW2F0dGVuZGFuY2VEYXRhLCBzZWxlY3RlZEVtcGxveWVlXSk7XHJcblxyXG4vLyBjb25zdCBwYXJzZVdvcmtpbmdIb3Vyc1RvTWludXRlcyA9ICh3b3JraW5nSG91cnMpID0+IHtcclxuLy8gICBpZiAoIXdvcmtpbmdIb3VycyB8fCB3b3JraW5nSG91cnMgPT09IFwiLVwiKSByZXR1cm4gMDtcclxuXHJcbi8vICAgY29uc3QgbWF0Y2ggPSB3b3JraW5nSG91cnMubWF0Y2goLyhcXGQrKWhcXHMqKFxcZCspbS8pO1xyXG4vLyAgIGlmICghbWF0Y2gpIHJldHVybiAwO1xyXG5cclxuLy8gICBjb25zdCBob3VycyA9IHBhcnNlSW50KG1hdGNoWzFdLCAxMCk7XHJcbi8vICAgY29uc3QgbWludXRlcyA9IHBhcnNlSW50KG1hdGNoWzJdLCAxMCk7XHJcblxyXG4vLyAgIHJldHVybiBob3VycyAqIDYwICsgbWludXRlcztcclxuLy8gfTtcclxuXHJcblxyXG4vLyAgIGNvbnN0IHN1bW1hcnlTdGF0cyA9IHVzZU1lbW8oKCkgPT4ge1xyXG4vLyAgIGNvbnN0IHRvdGFsID0gYXR0ZW5kYW5jZURhdGEubGVuZ3RoO1xyXG5cclxuLy8gICAvLyA9PT09PT09PT09PT09PT09PSBBTEwgRU1QTE9ZRUVTID09PT09PT09PT09PT09PT09XHJcbi8vICAgaWYgKHNlbGVjdGVkRW1wbG95ZWUgPT09IFwiYWxsXCIpIHtcclxuLy8gICAgIGNvbnN0IHRvdGFsUHJlc2VudCA9IGF0dGVuZGFuY2VEYXRhLnJlZHVjZShcclxuLy8gICAgICAgKHN1bSwgZSkgPT4gc3VtICsgKGUuUHJlc2VudERheXMgfHwgMCksXHJcbi8vICAgICAgIDBcclxuLy8gICAgICk7XHJcbi8vICAgICBjb25zdCB0b3RhbEFic2VudCA9IGF0dGVuZGFuY2VEYXRhLnJlZHVjZShcclxuLy8gICAgICAgKHN1bSwgZSkgPT4gc3VtICsgKGUuQWJzZW50RGF5cyB8fCAwKSxcclxuLy8gICAgICAgMFxyXG4vLyAgICAgKTtcclxuLy8gICAgIGNvbnN0IHRvdGFsSGFsZkRheXMgPSBhdHRlbmRhbmNlRGF0YS5yZWR1Y2UoXHJcbi8vICAgICAgIChzdW0sIGUpID0+IHN1bSArIChlLkhhbGZEYXlzIHx8IDApLFxyXG4vLyAgICAgICAwXHJcbi8vICAgICApO1xyXG4vLyAgICAgY29uc3QgdG90YWxPbkxlYXZlID0gYXR0ZW5kYW5jZURhdGEucmVkdWNlKFxyXG4vLyAgICAgICAoc3VtLCBlKSA9PiBzdW0gKyAoZS5PbkxlYXZlIHx8IDApLFxyXG4vLyAgICAgICAwXHJcbi8vICAgICApO1xyXG5cclxuLy8gICAgIHJldHVybiB7XHJcbi8vICAgICAgIHRvdGFsRW1wbG95ZWVzOiB0b3RhbCxcclxuLy8gICAgICAgdG90YWxQcmVzZW50LFxyXG4vLyAgICAgICB0b3RhbEFic2VudCxcclxuLy8gICAgICAgdG90YWxIYWxmRGF5cyxcclxuLy8gICAgICAgdG90YWxPbkxlYXZlLFxyXG4vLyAgICAgICBwcmVzZW50UGVyY2VudDpcclxuLy8gICAgICAgICB0b3RhbFByZXNlbnQgKyB0b3RhbEFic2VudCArIHRvdGFsSGFsZkRheXNcclxuLy8gICAgICAgICAgID8gKFxyXG4vLyAgICAgICAgICAgICAgICh0b3RhbFByZXNlbnQgL1xyXG4vLyAgICAgICAgICAgICAgICAgKHRvdGFsUHJlc2VudCArIHRvdGFsQWJzZW50ICsgdG90YWxIYWxmRGF5cykpICpcclxuLy8gICAgICAgICAgICAgICAxMDBcclxuLy8gICAgICAgICAgICAgKS50b0ZpeGVkKDEpXHJcbi8vICAgICAgICAgICA6IDAsXHJcbi8vICAgICB9O1xyXG4vLyAgIH1cclxuXHJcbi8vICAgLy8gPT09PT09PT09PT09PT09PT0gU0lOR0xFIEVNUExPWUVFID09PT09PT09PT09PT09PT09XHJcbi8vICAgY29uc3QgcHJlc2VudCA9IGF0dGVuZGFuY2VEYXRhLmZpbHRlcigocikgPT4gci5zdGF0dXMgPT09IFwiUHJlc2VudFwiKS5sZW5ndGg7XHJcbi8vICAgY29uc3QgYWJzZW50ID0gYXR0ZW5kYW5jZURhdGEuZmlsdGVyKChyKSA9PiByLnN0YXR1cyA9PT0gXCJBYnNlbnRcIikubGVuZ3RoO1xyXG4vLyAgIGNvbnN0IGhhbGZEYXlzID0gYXR0ZW5kYW5jZURhdGEuZmlsdGVyKChyKSA9PiByLnN0YXR1cyA9PT0gXCJIYWxmIERheVwiKS5sZW5ndGg7XHJcblxyXG4vLyAgIC8vIPCflLkgVE9UQUwgV09SS0lORyBUSU1FXHJcbi8vICAgY29uc3QgdG90YWxNaW51dGVzID0gYXR0ZW5kYW5jZURhdGEucmVkdWNlKChzdW0sIHIpID0+IHtcclxuLy8gICAgIHJldHVybiBzdW0gKyBwYXJzZVdvcmtpbmdIb3Vyc1RvTWludXRlcyhyLldvcmtpbmdIb3Vycyk7XHJcbi8vICAgfSwgMCk7XHJcblxyXG4vLyAgIGNvbnN0IHRvdGFsSG91cnMgPSBNYXRoLmZsb29yKHRvdGFsTWludXRlcyAvIDYwKTtcclxuLy8gICBjb25zdCByZW1haW5pbmdNaW51dGVzID0gdG90YWxNaW51dGVzICUgNjA7XHJcblxyXG4vLyAgIHJldHVybiB7XHJcbi8vICAgICB0b3RhbERheXM6IHRvdGFsLFxyXG4vLyAgICAgcHJlc2VudCxcclxuLy8gICAgIGFic2VudCxcclxuLy8gICAgIGhhbGZEYXlzLFxyXG4vLyAgICAgdG90YWxXb3JraW5nVGltZTogYCR7dG90YWxIb3Vyc31oICR7cmVtYWluaW5nTWludXRlc31tYCxcclxuLy8gICAgIHByZXNlbnRQZXJjZW50OiB0b3RhbCA/ICgocHJlc2VudCAvIHRvdGFsKSAqIDEwMCkudG9GaXhlZCgxKSA6IDAsXHJcbi8vICAgfTtcclxuLy8gfSwgW2F0dGVuZGFuY2VEYXRhLCBzZWxlY3RlZEVtcGxveWVlXSk7XHJcblxyXG4vLyAgIHJldHVybiAoXHJcbi8vICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTUwIHZpYS1ibHVlLTUwIHRvLWluZGlnby01MCBwLTZcIj5cclxuLy8gICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0b1wiPlxyXG4vLyAgICAgICAgIHsvKiBIZWFkZXIgU2VjdGlvbiAqL31cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBwLTggbWItNiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi0yXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MDAgdG8taW5kaWdvLTYwMCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy1sZ1wiPlxyXG4vLyAgICAgICAgICAgICAgIDxDYWxlbmRhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC0yeGxcIiAvPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPGRpdj5cclxuLy8gICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+TW9udGhseSBBdHRlbmRhbmNlIFJlcG9ydDwvaDE+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBtdC0xXCI+VHJhY2sgYW5kIGFuYWx5emUgZW1wbG95ZWUgYXR0ZW5kYW5jZSBwYXR0ZXJuczwvcD5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgey8qIEZpbHRlcnMgU2VjdGlvbiAqL31cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBwLTYgbWItNiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi00XCI+XHJcbi8vICAgICAgICAgICAgIDxGaWx0ZXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIHRleHQtbGdcIiAvPlxyXG4vLyAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+RmlsdGVyczwvaDM+XHJcbi8vICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC00IGl0ZW1zLWVuZFwiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy1bMjAwcHhdXCI+XHJcbi8vICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICBUYXJnZXQgTW9udGhcclxuLy8gICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4vLyAgICAgICAgICAgICAgIDxpbnB1dFxyXG4vLyAgICAgICAgICAgICAgICAgdHlwZT1cIm1vbnRoXCJcclxuLy8gICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIuNSBib3JkZXItMiBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQteGwgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDAgYmctc2xhdGUtNTAgaG92ZXI6Ymctd2hpdGVcIlxyXG4vLyAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuLy8gICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuLy8gICAgICAgICAgICAgICAgIG1heD17Y3VycmVudFllYXJNb250aH1cclxuLy8gICAgICAgICAgICAgICAvPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LVsyNTBweF1cIj5cclxuLy8gICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTJcIj5cclxuLy8gICAgICAgICAgICAgICAgIEVtcGxveWVlXHJcbi8vICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuLy8gICAgICAgICAgICAgICA8U2VsZWN0XHJcbi8vICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbi8vICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4vLyAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJyB9fVxyXG4vLyAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWV9XHJcbi8vICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRFbXBsb3llZX1cclxuLy8gICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGVtcGxveWVlXCJcclxuLy8gICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbi8vICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4vLyAgICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmRleE9mKGlucHV0LnRvTG93ZXJDYXNlKCkpID49IDBcclxuLy8gICAgICAgICAgICAgICAgIH1cclxuLy8gICAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImFsbFwiPkFsbCBFbXBsb3llZXM8L1NlbGVjdC5PcHRpb24+XHJcbi8vICAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbi8vICAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17ZW1wLl9pZH0gdmFsdWU9e2VtcC5faWR9PlxyXG4vLyAgICAgICAgICAgICAgICAgICAgIHtlbXAubmFtZX1cclxuLy8gICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4vLyAgICAgICAgICAgICAgICAgKSl9XHJcbi8vICAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICAgICAgPEJ1dHRvbiBcclxuLy8gICAgICAgICAgICAgICB0eXBlPVwicHJpbWFyeVwiIFxyXG4vLyAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbi8vICAgICAgICAgICAgICAgb25DbGljaz17ZmV0Y2hBdHRlbmRhbmNlRGF0YX1cclxuLy8gICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC04IGgtMTEgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8taW5kaWdvLTYwMCBob3Zlcjpmcm9tLWJsdWUtNzAwIGhvdmVyOnRvLWluZGlnby03MDAgYm9yZGVyLTAgc2hhZG93LW1kIGhvdmVyOnNoYWRvdy1sZyB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDBcIlxyXG4vLyAgICAgICAgICAgICA+XHJcbi8vICAgICAgICAgICAgICAgQXBwbHkgRmlsdGVyc1xyXG4vLyAgICAgICAgICAgICA8L0J1dHRvbj5cclxuLy8gICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgIDwvZGl2PlxyXG5cclxuLy8gICAgICAgICB7LyogU3VtbWFyeSBDYXJkcyAqL31cclxuLy8gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTUgZ2FwLTQgbWItNlwiPlxyXG4vLyAgICAgICAgICAgey8qIFRvdGFsIEVtcGxveWVlcyAvIFRvdGFsIERheXMgKi99XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tc2xhdGUtNzAwIHRvLXNsYXRlLTkwMCByb3VuZGVkLTJ4bCBzaGFkb3ctbGcgcC02IHRleHQtd2hpdGUgdHJhbnNmb3JtIGhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0yMDBcIj5cclxuLy8gICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4vLyAgICAgICAgICAgICAgIDxVc2VyT3V0bGluZWQgY2xhc3NOYW1lPVwidGV4dC0zeGwgb3BhY2l0eS04MFwiIC8+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5cclxuLy8gICAgICAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZSA9PT0gXCJhbGxcIiA/IFwiVG90YWwgRW1wbG95ZWVzXCIgOiBcIlRvdGFsIERheXNcIn1cclxuLy8gICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGRcIj5cclxuLy8gICAgICAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZSA9PT0gXCJhbGxcIlxyXG4vLyAgICAgICAgICAgICAgICAgPyBzdW1tYXJ5U3RhdHMudG90YWxFbXBsb3llZXNcclxuLy8gICAgICAgICAgICAgICAgIDogc3VtbWFyeVN0YXRzLnRvdGFsRGF5c31cclxuLy8gICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgey8qIFByZXNlbnQgKi99XHJcbi8vICAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZSAhPT0gXCJhbGxcIiAmJiAoXHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1lbWVyYWxkLTUwMCB0by1ncmVlbi02MDAgcm91bmRlZC0yeGwgc2hhZG93LWxnIHAtNiB0ZXh0LXdoaXRlIHRyYW5zZm9ybSBob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4vLyAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgYmctd2hpdGUvMjAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsXCI+4pyTPC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTEwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5QcmVzZW50PC9wPlxyXG4vLyAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtNHhsIGZvbnQtYm9sZFwiPntzdW1tYXJ5U3RhdHMucHJlc2VudH08L3A+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICB7LyogQWJzZW50ICovfVxyXG4vLyAgICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWUgIT09IFwiYWxsXCIgJiYgKFxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tcm9zZS01MDAgdG8tcmVkLTYwMCByb3VuZGVkLTJ4bCBzaGFkb3ctbGcgcC02IHRleHQtd2hpdGUgdHJhbnNmb3JtIGhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0yMDBcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCBiZy13aGl0ZS8yMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuLy8gICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGxcIj7inJU8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtMTAwIHRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPkFic2VudDwvcD5cclxuLy8gICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGRcIj57c3VtbWFyeVN0YXRzLmFic2VudH08L3A+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgKX1cclxuXHJcbi8vICAgICAgICAgICB7LyogSGFsZiBEYXkgKi99XHJcbi8vICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tYW1iZXItNTAwIHRvLW9yYW5nZS02MDAgcm91bmRlZC0yeGwgc2hhZG93LWxnIHAtNiB0ZXh0LXdoaXRlIHRyYW5zZm9ybSBob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCBiZy13aGl0ZS8yMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsXCI+wr08L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTEwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5IYWxmIERheTwvcD5cclxuLy8gICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkXCI+XHJcbi8vICAgICAgICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWUgPT09IFwiYWxsXCIgPyBzdW1tYXJ5U3RhdHMudG90YWxIYWxmRGF5cyA6IHN1bW1hcnlTdGF0cy5oYWxmRGF5c31cclxuLy8gICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgey8qIFByZXNlbnQgJSAqL31cclxuLy8gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1ibHVlLTUwMCB0by1pbmRpZ28tNjAwIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBwLTYgdGV4dC13aGl0ZSB0cmFuc2Zvcm0gaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTIwMFwiPlxyXG4vLyAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbi8vICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgYmctd2hpdGUvMjAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiPiU8L3NwYW4+XHJcbi8vICAgICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtMTAwIHRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPlByZXNlbnQgUmF0ZTwvcD5cclxuLy8gICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkXCI+e3N1bW1hcnlTdGF0cy5wcmVzZW50UGVyY2VudH0lPC9wPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAwIHRvLWluZGlnby02MDAgcm91bmRlZC0yeGwgc2hhZG93LWxnIHAtNiB0ZXh0LXdoaXRlIHRyYW5zZm9ybSBob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCBiZy13aGl0ZS8yMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsXCI+PC9zcGFuPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTEwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5PbiBMZWF2ZTwvcD5cclxuLy8gICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkXCI+e3N1bW1hcnlTdGF0cy50b3RhbE9uTGVhdmV9PC9wPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWJsdWUtNTAwIHRvLWluZGlnby02MDAgcm91bmRlZC0yeGwgc2hhZG93LWxnIHAtNiB0ZXh0LXdoaXRlIHRyYW5zZm9ybSBob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwXCI+XHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCBiZy13aGl0ZS8yMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuLy8gICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsXCI+JTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmx1ZS0xMDAgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+VG90YWwgV29ya2luZyBUaW1lPC9wPlxyXG4vLyAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGRcIj57c3VtbWFyeVN0YXRzLnRvdGFsV29ya2luZ1RpbWV9PC9wPlxyXG4vLyAgICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgICAgPC9kaXY+XHJcblxyXG4vLyAgICAgICAgIHsvKiBEYXRhIFRhYmxlICovfVxyXG4vLyAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LWxnIHAtNiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4vLyAgICAgICAgICAge2xvYWRpbmcgPyAoXHJcbi8vICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgaC02NFwiPlxyXG4vLyAgICAgICAgICAgICAgIDxTcGluIHNpemU9XCJsYXJnZVwiIC8+XHJcbi8vICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgbXQtNFwiPkxvYWRpbmcgYXR0ZW5kYW5jZSBkYXRhLi4uPC9wPlxyXG4vLyAgICAgICAgICAgICA8L2Rpdj5cclxuLy8gICAgICAgICAgICkgOiAoXHJcbi8vICAgICAgICAgICAgIDw+XHJcbi8vICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4vLyAgICAgICAgICAgICAgICAgY29sdW1ucz17c2VsZWN0ZWRFbXBsb3llZSA9PT0gXCJhbGxcIiA/IGFsbEVtcGxveWVlc0NvbHVtbnMgOiBpbmRpdmlkdWFsQ29sdW1uc31cclxuLy8gICAgICAgICAgICAgICAgIGRhdGE9e3NhZmVEYXRhfVxyXG4vLyAgICAgICAgICAgICAgICAgZXhwb3J0ZWRQZGZOYW1lPVwiRW1wbG95ZWUgTW9udGhseSBBdHRlbmRlbmNlIFJlcG9ydFwiXHJcbi8vICAgICAgICAgICAgICAgICBleHBvcnRlZEZpbGVOYW1lPXtgRW1wbG95ZWVNb250aGx5QXR0ZW5kZW5jZVJlcG9ydC5jc3ZgfVxyXG4vLyAgICAgICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cclxuLy8gICAgICAgICAgICAgICAvPlxyXG5cclxuLy8gICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwXCI+XHJcbi8vICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCB0ZXh0LXNtXCI+XHJcbi8vICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+U2hvd2luZyBhdHRlbmRhbmNlIGZvcjo8L3NwYW4+e1wiIFwifVxyXG4vLyAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIGZvbnQtc2VtaWJvbGRcIj57c2VsZWN0ZWREYXRlfTwvc3Bhbj5cclxuLy8gICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWUgIT09IFwiYWxsXCIgJiZcclxuLy8gICAgICAgICAgICAgICAgICAgICBgIOKAoiAke2VtcGxveWVlcy5maW5kKChlKSA9PiBlLl9pZCA9PT0gc2VsZWN0ZWRFbXBsb3llZSk/Lm5hbWUgfHwgXCJcIn1gfVxyXG4vLyAgICAgICAgICAgICAgICAgPC9wPlxyXG4vLyAgICAgICAgICAgICAgIDwvZGl2PlxyXG4vLyAgICAgICAgICAgICA8Lz5cclxuLy8gICAgICAgICAgICl9XHJcbi8vICAgICAgICAgPC9kaXY+XHJcbi8vICAgICAgIDwvZGl2PlxyXG4vLyAgICAgPC9kaXY+XHJcbi8vICAgKTtcclxuLy8gfTtcclxuXHJcbmNvbnN0IEVtcGxveWVlTW9udGhseVJlcG9ydCA9ICgpID0+IHtcclxuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XHJcbiAgY29uc3QgY3VycmVudFllYXIgPSB0b2RheS5nZXRGdWxsWWVhcigpO1xyXG4gIGNvbnN0IGN1cnJlbnRNb250aCA9IFN0cmluZyh0b2RheS5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgXCIwXCIpO1xyXG4gIGNvbnN0IGN1cnJlbnRZZWFyTW9udGggPSBgJHtjdXJyZW50WWVhcn0tJHtjdXJyZW50TW9udGh9YDtcclxuXHJcbiAgY29uc3QgZm9ybWF0RGF0ZSA9IChkYXRlKSA9PiB7XHJcbiAgICBjb25zdCB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpO1xyXG4gICAgY29uc3QgbW9udGggPSBgMCR7ZGF0ZS5nZXRNb250aCgpICsgMX1gLnNsaWNlKC0yKTtcclxuICAgIGNvbnN0IGRheSA9IGAwJHtkYXRlLmdldERhdGUoKX1gLnNsaWNlKC0yKTtcclxuICAgIHJldHVybiBgJHt5ZWFyfS0ke21vbnRofS0ke2RheX1gO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IFtzZWxlY3RlZERhdGUsIHNldFNlbGVjdGVkRGF0ZV0gPSB1c2VTdGF0ZShjdXJyZW50WWVhck1vbnRoKTtcclxuICBjb25zdCBbYXR0ZW5kYW5jZURhdGEsIHNldEF0dGVuZGFuY2VEYXRhXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbZW1wbG95ZWVzLCBzZXRFbXBsb3llZXNdID0gdXNlU3RhdGUoW10pO1xyXG4gIGNvbnN0IFtzZWxlY3RlZEVtcGxveWVlLCBzZXRTZWxlY3RlZEVtcGxveWVlXSA9IHVzZVN0YXRlKFwiYWxsXCIpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgY29uc3QgZ2V0TW9udGhSYW5nZSA9ICh5ZWFyTW9udGgpID0+IHtcclxuICAgIGNvbnN0IFt5ZWFyLCBtb250aF0gPSB5ZWFyTW9udGguc3BsaXQoXCItXCIpO1xyXG4gICAgY29uc3QgZmlyc3REYXkgPSBuZXcgRGF0ZSh5ZWFyLCBtb250aCAtIDEsIDEpO1xyXG4gICAgY29uc3QgbGFzdERheSA9IG5ldyBEYXRlKHllYXIsIG1vbnRoLCAwKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIGZyb21fZGF0ZTogZm9ybWF0RGF0ZShmaXJzdERheSksXHJcbiAgICAgIHRvX2RhdGU6IGZvcm1hdERhdGUobGFzdERheSksXHJcbiAgICB9O1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBmZXRjaEVtcGxveWVlcyA9IGFzeW5jICgpID0+IHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBhcGkuZ2V0KFwiL2VtcGxveWVlXCIpO1xyXG4gICAgICAgIHNldEVtcGxveWVlcyhyZXMuZGF0YS5lbXBsb3llZSB8fCBbXSk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBlbXBsb3llZXM6XCIsIGVycik7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBmZXRjaEVtcGxveWVlcygpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hBdHRlbmRhbmNlRGF0YSA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgeyBmcm9tX2RhdGUsIHRvX2RhdGUgfSA9IGdldE1vbnRoUmFuZ2Uoc2VsZWN0ZWREYXRlKTtcclxuXHJcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHtcclxuICAgICAgICBmcm9tX2RhdGUsXHJcbiAgICAgICAgdG9fZGF0ZSxcclxuICAgICAgICBlbXBsb3llZV9pZDogc2VsZWN0ZWRFbXBsb3llZSAhPT0gXCJhbGxcIiA/IHNlbGVjdGVkRW1wbG95ZWUgOiBcIlwiLFxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgYXBpLmdldChcIi9lbXBsb3llZS1hdHRlbmRhbmNlL21vbnRobHktcmVwb3J0XCIsIHsgcGFyYW1zIH0pO1xyXG4gICAgICBjb25zdCBhdHRlbmRhbmNlUmVzcG9uc2UgPSByZXMuZGF0YS5hdHRlbmRhbmNlRGF0YVJlc3BvbnNlIHx8IFtdO1xyXG5cclxuICAgICAgLy8gPT09PT09PT09PT09PT09PT09PT09IFNJTkdMRSBFTVBMT1lFRSBWSUVXID09PT09PT09PT09PT09PT09PT09PVxyXG4gICAgICBpZiAoc2VsZWN0ZWRFbXBsb3llZSAhPT0gXCJhbGxcIikge1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZCA9IGF0dGVuZGFuY2VSZXNwb25zZT8uZmlsdGVyKChlbXApID0+IGVtcD8uZW1wbG95ZWVfaWQ/LmlzVmVyaWZpZWQgPT09IHRydWUpPy5tYXAoKHJlYywgaW5kZXgpID0+IHtcclxuICAgICAgICAgIGxldCB3b3JraW5nSG91cnMgPSBcIi1cIjtcclxuXHJcbiAgICAgICAgICBjb25zdCBsb2dpblRpbWUgPSByZWM/LnRpbWU7ICAgICAgICAgIC8vIGUuZy4gXCIxMDo1MDoyMiBhbVwiXHJcbiAgICAgICAgICBjb25zdCBsb2dvdXRUaW1lID0gcmVjPy5sb2dvdXRfdGltZTsgIC8vIGUuZy4gXCIyOjQxOjI5IHBtXCJcclxuXHJcbiAgICAgICAgICBpZiAobG9naW5UaW1lICYmIGxvZ291dFRpbWUpIHtcclxuICAgICAgICAgICAgY29uc3Qgc3RhcnQgPSBkYXlqcyhsb2dpblRpbWUsIFwiaGg6bW06c3MgYVwiKTtcclxuICAgICAgICAgICAgY29uc3QgZW5kID0gZGF5anMobG9nb3V0VGltZSwgXCJoaDptbTpzcyBhXCIpO1xyXG5cclxuICAgICAgICAgICAgaWYgKHN0YXJ0LmlzVmFsaWQoKSAmJiBlbmQuaXNWYWxpZCgpKSB7XHJcbiAgICAgICAgICAgICAgbGV0IGRpZmZNaW51dGVzID0gZW5kLmRpZmYoc3RhcnQsIFwibWludXRlXCIpO1xyXG5cclxuICAgICAgICAgICAgICAvLyBIYW5kbGUgb3Zlcm5pZ2h0IHNoaWZ0cyAob3B0aW9uYWwgc2FmZXR5KVxyXG4gICAgICAgICAgICAgIGlmIChkaWZmTWludXRlcyA8IDApIHtcclxuICAgICAgICAgICAgICAgIGRpZmZNaW51dGVzICs9IDI0ICogNjA7XHJcbiAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICBjb25zdCBob3VycyA9IE1hdGguZmxvb3IoZGlmZk1pbnV0ZXMgLyA2MCk7XHJcbiAgICAgICAgICAgICAgY29uc3QgbWludXRlcyA9IGRpZmZNaW51dGVzICUgNjA7XHJcblxyXG4gICAgICAgICAgICAgIHdvcmtpbmdIb3VycyA9IGAke2hvdXJzfWggJHttaW51dGVzfW1gO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc2xObzogaW5kZXggKyAxLFxyXG4gICAgICAgICAgICBrZXk6IHJlYy5faWQgfHwgaW5kZXgsXHJcbiAgICAgICAgICAgIGRhdGU6IHJlYz8uZGF0ZSA/IHJlYy5kYXRlLnNwbGl0KFwiVFwiKVswXSA6IFwiXCIsXHJcbiAgICAgICAgICAgIHRpbWU6IHJlYz8udGltZSB8fCBcIlwiLFxyXG4gICAgICAgICAgICBvdXRUaW1lOiByZWM/LmxvZ291dF90aW1lIHx8IFwiXCIsXHJcbiAgICAgICAgICAgIFdvcmtpbmdIb3Vyczogd29ya2luZ0hvdXJzLFxyXG4gICAgICAgICAgICBhcHByb3ZhbF9zdGF0dXM6IHJlYz8uYXBwcm92YWxfc3RhdHVzLFxyXG4gICAgICAgICAgICBkYXk6IHJlYz8uZGF0ZVxyXG4gICAgICAgICAgICAgID8gbmV3IERhdGUocmVjLmRhdGUpLnRvTG9jYWxlRGF0ZVN0cmluZyhcImVuLVVTXCIsIHsgd2Vla2RheTogXCJzaG9ydFwiIH0pXHJcbiAgICAgICAgICAgICAgOiBcIlwiLFxyXG4gICAgICAgICAgICBOb3RlOiByZWM/Lm5vdGUgfHwgXCJcIixcclxuICAgICAgICAgICAgc3RhdHVzOiByZWM/LnN0YXR1cyB8fCBcIlwiLFxyXG4gICAgICAgICAgfTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgc2V0QXR0ZW5kYW5jZURhdGEoZm9ybWF0dGVkKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gPT09PT09PT09PT09PT09PT09PT09IEFMTCBFTVBMT1lFRVMgU1VNTUFSWSA9PT09PT09PT09PT09PT09PT09PT1cclxuICAgICAgZWxzZSB7XHJcbiAgICAgICAgY29uc3QgZ3JvdXBlZCA9IHt9O1xyXG5cclxuICAgICAgICBhdHRlbmRhbmNlUmVzcG9uc2U/LmZpbHRlcigoZW1wKSA9PiBlbXA/LmVtcGxveWVlX2lkPy5pc1ZlcmlmaWVkID09PSB0cnVlKS5mb3JFYWNoKChyZWNvcmQsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBlbXAgPSByZWNvcmQ/LmVtcGxveWVlX2lkO1xyXG4gICAgICAgICAgaWYgKCFlbXA/Ll9pZCkgcmV0dXJuO1xyXG5cclxuICAgICAgICAgIGlmICghZ3JvdXBlZFtlbXAuX2lkXSkge1xyXG4gICAgICAgICAgICBncm91cGVkW2VtcC5faWRdID0ge1xyXG4gICAgICAgICAgICAgIHNsTm86IGluZGV4ICsgMSxcclxuICAgICAgICAgICAgICBrZXk6IGVtcC5faWQsXHJcbiAgICAgICAgICAgICAgRW1wbG95ZWVOYW1lOiBlbXA/Lm5hbWUgfHwgXCJcIixcclxuICAgICAgICAgICAgICBQcmVzZW50RGF5czogMCxcclxuICAgICAgICAgICAgICBBYnNlbnREYXlzOiAwLFxyXG4gICAgICAgICAgICAgIEhhbGZEYXlzOiAwLFxyXG4gICAgICAgICAgICAgIE9uTGVhdmU6IDAsXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgaWYgKHJlY29yZD8uc3RhdHVzID09PSBcIlByZXNlbnRcIikgZ3JvdXBlZFtlbXAuX2lkXS5QcmVzZW50RGF5cysrO1xyXG4gICAgICAgICAgaWYgKHJlY29yZD8uc3RhdHVzID09PSBcIkFic2VudFwiKSBncm91cGVkW2VtcC5faWRdLkFic2VudERheXMrKztcclxuICAgICAgICAgIGlmIChyZWNvcmQ/LnN0YXR1cyA9PT0gXCJIYWxmIERheVwiKSBncm91cGVkW2VtcC5faWRdLkhhbGZEYXlzKys7XHJcbiAgICAgICAgICBpZiAocmVjb3JkPy5zdGF0dXMgPT09IFwiT24gTGVhdmVcIikgZ3JvdXBlZFtlbXAuX2lkXS5PbkxlYXZlKys7XHJcblxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBzZXRBdHRlbmRhbmNlRGF0YShPYmplY3QudmFsdWVzKGdyb3VwZWQpKTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJFcnJvciBmZXRjaGluZyBhdHRlbmRhbmNlOlwiLCBlcnIpO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoQXR0ZW5kYW5jZURhdGEoKTtcclxuICB9LCBbc2VsZWN0ZWRFbXBsb3llZSwgc2VsZWN0ZWREYXRlXSk7XHJcblxyXG4gIGNvbnN0IGFsbEVtcGxveWVlc0NvbHVtbnMgPSBbXHJcbiAgICB7IGhlYWRlcjogXCJTbCBOb1wiLCBrZXk6IFwic2xOb1wiLCB9LFxyXG4gICAgeyBoZWFkZXI6IFwiRW1wbG95ZWUgTmFtZVwiLCBrZXk6IFwiRW1wbG95ZWVOYW1lXCIgfSxcclxuICAgIHsgaGVhZGVyOiBcIlByZXNlbnQgRGF5c1wiLCBrZXk6IFwiUHJlc2VudERheXNcIiB9LFxyXG4gICAgeyBoZWFkZXI6IFwiQWJzZW50IERheXNcIiwga2V5OiBcIkFic2VudERheXNcIiB9LFxyXG4gICAgeyBoZWFkZXI6IFwiSGFsZiBEYXlzXCIsIGtleTogXCJIYWxmRGF5c1wiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJPbiBMZWF2ZVwiLCBrZXk6IFwiT25MZWF2ZVwiIH1cclxuICBdO1xyXG5cclxuICBjb25zdCBpbmRpdmlkdWFsQ29sdW1ucyA9IFtcclxuICAgIHsgaGVhZGVyOiBcIlNsIE5vXCIsIGtleTogXCJzbE5vXCIgfSxcclxuICAgIHsgaGVhZGVyOiBcIkRhdGVcIiwga2V5OiBcImRhdGVcIiB9LFxyXG4gICAgeyBoZWFkZXI6IFwiSW4tVGltZVwiLCBrZXk6IFwidGltZVwiIH0sXHJcbiAgICB7IGhlYWRlcjogXCJPdXQtVGltZVwiLCBrZXk6IFwib3V0VGltZVwiIH0sXHJcbiAgICB7aGVhZGVyOiBcIkFwcHJvdmFsIFN0YXR1c1wiLCBrZXk6IFwiYXBwcm92YWxfc3RhdHVzXCJ9LFxyXG4gICAgeyBoZWFkZXI6IFwiV29ya2luZyBIb3Vyc1wiLCBrZXk6IFwiV29ya2luZ0hvdXJzXCIgfSxcclxuICAgIHsgaGVhZGVyOiBcIkRheVwiLCBrZXk6IFwiZGF5XCIgfSxcclxuICAgIHsgaGVhZGVyOiBcIk5vdGVcIiwga2V5OiBcIk5vdGVcIiB9LFxyXG4gICAge1xyXG4gICAgICBoZWFkZXI6IFwiU3RhdHVzXCIsXHJcbiAgICAgIGtleTogXCJzdGF0dXNcIixcclxuICAgICAgcmVuZGVyOiAoc3RhdHVzKSA9PiB7XHJcbiAgICAgICAgaWYgKHN0YXR1cz8udG9Mb3dlckNhc2UoKSA9PT0gXCJwcmVzZW50XCIpIHtcclxuICAgICAgICAgIHJldHVybiA8VGFnIGNvbG9yPVwiZ3JlZW5cIj5QcmVzZW50PC9UYWc+O1xyXG4gICAgICAgIH0gZWxzZSBpZiAoc3RhdHVzPy50b0xvd2VyQ2FzZSgpID09PSBcImFic2VudFwiKSB7XHJcbiAgICAgICAgICByZXR1cm4gPFRhZyBjb2xvcj1cInJlZFwiPkFic2VudDwvVGFnPjtcclxuICAgICAgICB9IGVsc2UgaWYgKHN0YXR1cz8udG9Mb3dlckNhc2UoKSA9PT0gXCJoYWxmIGRheVwiKSB7XHJcbiAgICAgICAgICByZXR1cm4gPFRhZyBjb2xvcj1cIm9yYW5nZVwiPkhhbGYgRGF5PC9UYWc+O1xyXG4gICAgICAgIH0gZWxzZSBpZiAoc3RhdHVzPy50b0xvd2VyQ2FzZSgpID09PSBcIm9uIGxlYXZlXCIpIHtcclxuICAgICAgICAgIHJldHVybiA8VGFnIGNvbG9yPVwiYmx1ZVwiPk9uIExlYXZlPC9UYWc+O1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gc3RhdHVzIHx8IFwiXCI7XHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gIF07XHJcblxyXG4gIGNvbnN0IHNhZmVEYXRhID0gYXR0ZW5kYW5jZURhdGEubWFwKChyb3cpID0+IHtcclxuICAgIGNvbnN0IGNsZWFuID0ge307XHJcbiAgICBPYmplY3Qua2V5cyhyb3cpLmZvckVhY2goKGtleSkgPT4ge1xyXG4gICAgICBjbGVhbltrZXldID1cclxuICAgICAgICByb3dba2V5XSA9PT0gbnVsbCB8fCByb3dba2V5XSA9PT0gdW5kZWZpbmVkID8gXCJcIiA6IFN0cmluZyhyb3dba2V5XSk7XHJcbiAgICB9KTtcclxuICAgIHJldHVybiBjbGVhbjtcclxuICB9KTtcclxuXHJcbiAgY29uc3QgcGFyc2VXb3JraW5nSG91cnNUb01pbnV0ZXMgPSAod29ya2luZ0hvdXJzKSA9PiB7XHJcbiAgICBpZiAoIXdvcmtpbmdIb3VycyB8fCB3b3JraW5nSG91cnMgPT09IFwiLVwiKSByZXR1cm4gMDtcclxuXHJcbiAgICBjb25zdCBtYXRjaCA9IHdvcmtpbmdIb3Vycy5tYXRjaCgvKFxcZCspaFxccyooXFxkKyltLyk7XHJcbiAgICBpZiAoIW1hdGNoKSByZXR1cm4gMDtcclxuXHJcbiAgICBjb25zdCBob3VycyA9IHBhcnNlSW50KG1hdGNoWzFdLCAxMCk7XHJcbiAgICBjb25zdCBtaW51dGVzID0gcGFyc2VJbnQobWF0Y2hbMl0sIDEwKTtcclxuXHJcbiAgICByZXR1cm4gaG91cnMgKiA2MCArIG1pbnV0ZXM7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc3VtbWFyeVN0YXRzID0gdXNlTWVtbygoKSA9PiB7XHJcbiAgICBjb25zdCB0b3RhbCA9IGF0dGVuZGFuY2VEYXRhLmxlbmd0aDtcclxuXHJcbiAgICAvLyA9PT09PT09PT09PT09PT09PSBBTEwgRU1QTE9ZRUVTID09PT09PT09PT09PT09PT09XHJcbiAgICBpZiAoc2VsZWN0ZWRFbXBsb3llZSA9PT0gXCJhbGxcIikge1xyXG4gICAgICBjb25zdCB0b3RhbFByZXNlbnQgPSBhdHRlbmRhbmNlRGF0YS5yZWR1Y2UoXHJcbiAgICAgICAgKHN1bSwgZSkgPT4gc3VtICsgKGUuUHJlc2VudERheXMgfHwgMCksXHJcbiAgICAgICAgMFxyXG4gICAgICApO1xyXG4gICAgICBjb25zdCB0b3RhbEFic2VudCA9IGF0dGVuZGFuY2VEYXRhLnJlZHVjZShcclxuICAgICAgICAoc3VtLCBlKSA9PiBzdW0gKyAoZS5BYnNlbnREYXlzIHx8IDApLFxyXG4gICAgICAgIDBcclxuICAgICAgKTtcclxuICAgICAgY29uc3QgdG90YWxIYWxmRGF5cyA9IGF0dGVuZGFuY2VEYXRhLnJlZHVjZShcclxuICAgICAgICAoc3VtLCBlKSA9PiBzdW0gKyAoZS5IYWxmRGF5cyB8fCAwKSxcclxuICAgICAgICAwXHJcbiAgICAgICk7XHJcbiAgICAgIGNvbnN0IHRvdGFsT25MZWF2ZSA9IGF0dGVuZGFuY2VEYXRhLnJlZHVjZShcclxuICAgICAgICAoc3VtLCBlKSA9PiBzdW0gKyAoZS5PbkxlYXZlIHx8IDApLFxyXG4gICAgICAgIDBcclxuICAgICAgKTtcclxuXHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgdG90YWxFbXBsb3llZXM6IHRvdGFsLFxyXG4gICAgICAgIHRvdGFsUHJlc2VudCxcclxuICAgICAgICB0b3RhbEFic2VudCxcclxuICAgICAgICB0b3RhbEhhbGZEYXlzLFxyXG4gICAgICAgIHRvdGFsT25MZWF2ZSxcclxuICAgICAgICBwcmVzZW50UGVyY2VudDpcclxuICAgICAgICAgIHRvdGFsUHJlc2VudCArIHRvdGFsQWJzZW50ICsgdG90YWxIYWxmRGF5c1xyXG4gICAgICAgICAgICA/IChcclxuICAgICAgICAgICAgICAodG90YWxQcmVzZW50IC9cclxuICAgICAgICAgICAgICAgICh0b3RhbFByZXNlbnQgKyB0b3RhbEFic2VudCArIHRvdGFsSGFsZkRheXMpKSAqXHJcbiAgICAgICAgICAgICAgMTAwXHJcbiAgICAgICAgICAgICkudG9GaXhlZCgxKVxyXG4gICAgICAgICAgICA6IDAsXHJcbiAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgLy8gPT09PT09PT09PT09PT09PT0gU0lOR0xFIEVNUExPWUVFID09PT09PT09PT09PT09PT09XHJcbiAgICBjb25zdCBwcmVzZW50ID0gYXR0ZW5kYW5jZURhdGEuZmlsdGVyKChyKSA9PiByLnN0YXR1cyA9PT0gXCJQcmVzZW50XCIpLmxlbmd0aDtcclxuICAgIGNvbnN0IGFic2VudCA9IGF0dGVuZGFuY2VEYXRhLmZpbHRlcigocikgPT4gci5zdGF0dXMgPT09IFwiQWJzZW50XCIpLmxlbmd0aDtcclxuICAgIGNvbnN0IGhhbGZEYXlzID0gYXR0ZW5kYW5jZURhdGEuZmlsdGVyKChyKSA9PiByLnN0YXR1cyA9PT0gXCJIYWxmIERheVwiKS5sZW5ndGg7XHJcbiAgICBjb25zdCBvbkxlYXZlID0gYXR0ZW5kYW5jZURhdGEuZmlsdGVyKChyKSA9PiByLnN0YXR1cyA9PT0gXCJPbiBMZWF2ZVwiKS5sZW5ndGg7XHJcblxyXG4gICAgLy8g8J+UuSBUT1RBTCBXT1JLSU5HIFRJTUVcclxuICAgIGNvbnN0IHRvdGFsTWludXRlcyA9IGF0dGVuZGFuY2VEYXRhLnJlZHVjZSgoc3VtLCByKSA9PiB7XHJcbiAgICAgIHJldHVybiBzdW0gKyBwYXJzZVdvcmtpbmdIb3Vyc1RvTWludXRlcyhyLldvcmtpbmdIb3Vycyk7XHJcbiAgICB9LCAwKTtcclxuXHJcbiAgICBjb25zdCB0b3RhbEhvdXJzID0gTWF0aC5mbG9vcih0b3RhbE1pbnV0ZXMgLyA2MCk7XHJcbiAgICBjb25zdCByZW1haW5pbmdNaW51dGVzID0gdG90YWxNaW51dGVzICUgNjA7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgdG90YWxEYXlzOiB0b3RhbCxcclxuICAgICAgcHJlc2VudCxcclxuICAgICAgYWJzZW50LFxyXG4gICAgICBoYWxmRGF5cyxcclxuICAgICAgb25MZWF2ZSxcclxuICAgICAgdG90YWxXb3JraW5nVGltZTogYCR7dG90YWxIb3Vyc31oICR7cmVtYWluaW5nTWludXRlc31tYCxcclxuICAgICAgcHJlc2VudFBlcmNlbnQ6IHRvdGFsID8gKChwcmVzZW50IC8gdG90YWwpICogMTAwKS50b0ZpeGVkKDEpIDogMCxcclxuICAgIH07XHJcbiAgfSwgW2F0dGVuZGFuY2VEYXRhLCBzZWxlY3RlZEVtcGxveWVlXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTUwIHZpYS1ibHVlLTUwIHRvLWluZGlnby01MCBwLTZcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0b1wiPlxyXG4gICAgICAgIHsvKiBIZWFkZXIgU2VjdGlvbiAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBwLTggbWItNiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBtYi0yXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIGJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MDAgdG8taW5kaWdvLTYwMCByb3VuZGVkLXhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy1sZ1wiPlxyXG4gICAgICAgICAgICAgIDxDYWxlbmRhck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC0yeGxcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwXCI+TW9udGhseSBBdHRlbmRhbmNlIFJlcG9ydDwvaDE+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgdGV4dC1zbSBtdC0xXCI+VHJhY2sgYW5kIGFuYWx5emUgZW1wbG95ZWUgYXR0ZW5kYW5jZSBwYXR0ZXJuczwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIEZpbHRlcnMgU2VjdGlvbiAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBwLTYgbWItNiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtYi00XCI+XHJcbiAgICAgICAgICAgIDxGaWx0ZXJPdXRsaW5lZCBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIHRleHQtbGdcIiAvPlxyXG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+RmlsdGVyczwvaDM+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC00IGl0ZW1zLWVuZFwiPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy1bMjAwcHhdXCI+XHJcbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtc20gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICBUYXJnZXQgTW9udGhcclxuICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgdHlwZT1cIm1vbnRoXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC00IHB5LTIuNSBib3JkZXItMiBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQteGwgZm9jdXM6Ym9yZGVyLWJsdWUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0yMDAgYmctc2xhdGUtNTAgaG92ZXI6Ymctd2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VsZWN0ZWREYXRlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAgIG1heD17Y3VycmVudFllYXJNb250aH1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG1pbi13LVsyNTBweF1cIj5cclxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTJcIj5cclxuICAgICAgICAgICAgICAgIEVtcGxveWVlXHJcbiAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJyB9fVxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRW1wbG95ZWV9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0U2VsZWN0ZWRFbXBsb3llZX1cclxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoIGVtcGxveWVlXCJcclxuICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICBvcHRpb24uY2hpbGRyZW4udG9Mb3dlckNhc2UoKS5pbmRleE9mKGlucHV0LnRvTG93ZXJDYXNlKCkpID49IDBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiB2YWx1ZT1cImFsbFwiPkFsbCBFbXBsb3llZXM8L1NlbGVjdC5PcHRpb24+XHJcbiAgICAgICAgICAgICAgICB7ZW1wbG95ZWVzLm1hcCgoZW1wKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxTZWxlY3QuT3B0aW9uIGtleT17ZW1wLl9pZH0gdmFsdWU9e2VtcC5faWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlbXAubmFtZX1cclxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgPC9TZWxlY3Q+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2ZldGNoQXR0ZW5kYW5jZURhdGF9XHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtOCBoLTExIHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHRvLWluZGlnby02MDAgaG92ZXI6ZnJvbS1ibHVlLTcwMCBob3Zlcjp0by1pbmRpZ28tNzAwIGJvcmRlci0wIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIEFwcGx5IEZpbHRlcnNcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgey8qIFN1bW1hcnkgQ2FyZHMgKi99XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00IG1iLTZcIj5cclxuICAgICAgICAgIHsvKiBUb3RhbCBFbXBsb3llZXMgLyBUb3RhbCBEYXlzICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTcwMCB0by1zbGF0ZS05MDAgcm91bmRlZC0yeGwgc2hhZG93LWxnIHAtNiB0ZXh0LXdoaXRlIHRyYW5zZm9ybSBob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cclxuICAgICAgICAgICAgICA8VXNlck91dGxpbmVkIGNsYXNzTmFtZT1cInRleHQtM3hsIG9wYWNpdHktODBcIiAvPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgdGV4dC1zbSBmb250LW1lZGl1bSBtYi0xXCI+XHJcbiAgICAgICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWUgPT09IFwiYWxsXCIgPyBcIlRvdGFsIEVtcGxveWVlc1wiIDogXCJUb3RhbCBEYXlzXCJ9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWUgPT09IFwiYWxsXCJcclxuICAgICAgICAgICAgICAgID8gc3VtbWFyeVN0YXRzLnRvdGFsRW1wbG95ZWVzXHJcbiAgICAgICAgICAgICAgICA6IHN1bW1hcnlTdGF0cy50b3RhbERheXN9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LW1vbm8gdGV4dC13aGl0ZSBgfT5cclxuICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhzZWxlY3RlZEVtcGxveWVlID09PSBcImFsbFwiXHJcbiAgICAgICAgICAgICAgICA/IHN1bW1hcnlTdGF0cy50b3RhbEVtcGxveWVlc1xyXG4gICAgICAgICAgICAgICAgOiBzdW1tYXJ5U3RhdHMudG90YWxEYXlzIHx8IDApfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogUHJlc2VudCAqL31cclxuICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlICE9PSBcImFsbFwiICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLWVtZXJhbGQtNTAwIHRvLWdyZWVuLTYwMCByb3VuZGVkLTJ4bCBzaGFkb3ctbGcgcC02IHRleHQtd2hpdGUgdHJhbnNmb3JtIGhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0yMDBcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCBiZy13aGl0ZS8yMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGxcIj7inJM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtMTAwIHRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPlByZXNlbnQ8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkXCI+e3N1bW1hcnlTdGF0cy5wcmVzZW50fTwvcD5cclxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LXdoaXRlIGB9PlxyXG4gICAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoc3VtbWFyeVN0YXRzLnByZXNlbnQgfHwgMCl9XHJcbiAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgey8qIEFic2VudCAqL31cclxuICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlICE9PSBcImFsbFwiICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXJvc2UtNTAwIHRvLXJlZC02MDAgcm91bmRlZC0yeGwgc2hhZG93LWxnIHAtNiB0ZXh0LXdoaXRlIHRyYW5zZm9ybSBob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgYmctd2hpdGUvMjAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsXCI+4pyVPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yb3NlLTEwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5BYnNlbnQ8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkXCI+e3N1bW1hcnlTdGF0cy5hYnNlbnR9PC9wPlxyXG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tb25vIHRleHQtd2hpdGUgYH0+XHJcbiAgICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhzdW1tYXJ5U3RhdHMuYWJzZW50IHx8IDApfVxyXG4gICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHsvKiBIYWxmIERheSAqL31cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1hbWJlci01MDAgdG8tb3JhbmdlLTYwMCByb3VuZGVkLTJ4bCBzaGFkb3ctbGcgcC02IHRleHQtd2hpdGUgdHJhbnNmb3JtIGhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0yMDBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIGJnLXdoaXRlLzIwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGxcIj7CvTwvc3Bhbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYW1iZXItMTAwIHRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPkhhbGYgRGF5PC9wPlxyXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTR4bCBmb250LWJvbGRcIj5cclxuICAgICAgICAgICAgICB7c2VsZWN0ZWRFbXBsb3llZSA9PT0gXCJhbGxcIiA/IHN1bW1hcnlTdGF0cy50b3RhbEhhbGZEYXlzIDogc3VtbWFyeVN0YXRzLmhhbGZEYXlzfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtc20gZm9udC1tb25vIHRleHQtd2hpdGUgYH0+XHJcbiAgICAgICAgICAgICAge251bWJlclRvSW5kaWFuV29yZHMoc2VsZWN0ZWRFbXBsb3llZSA9PT0gXCJhbGxcIiA/IHN1bW1hcnlTdGF0cy50b3RhbEhhbGZEYXlzIDogc3VtbWFyeVN0YXRzLmhhbGZEYXlzIHx8IDApfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogT24gTGVhdmUgKi99XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tYmx1ZS01MDAgdG8taW5kaWdvLTYwMCBjZW50ZXIgcm91bmRlZC0yeGwgc2hhZG93LWxnIHAtNiB0ZXh0LXdoaXRlIHRyYW5zZm9ybSBob3ZlcjpzY2FsZS0xMDUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMjAwXCI+XHJcbiAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgYmctd2hpdGUvMjAgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiPvCfk4U8L3NwYW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PiAqL31cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ibHVlLTEwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5PbiBMZWF2ZTwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWUgPT09IFwiYWxsXCIgPyBzdW1tYXJ5U3RhdHMudG90YWxPbkxlYXZlIDogc3VtbWFyeVN0YXRzLm9uTGVhdmV9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1zbSBmb250LW1vbm8gdGV4dC13aGl0ZSBgfT5cclxuICAgICAgICAgICAgICB7bnVtYmVyVG9JbmRpYW5Xb3JkcyhzZWxlY3RlZEVtcGxveWVlID09PSBcImFsbFwiID8gc3VtbWFyeVN0YXRzLnRvdGFsT25MZWF2ZSA6IHN1bW1hcnlTdGF0cy5vbkxlYXZlIHx8IDApfVxyXG4gICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICB7LyogUHJlc2VudCAlICovfVxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXB1cnBsZS01MDAgdG8taW5kaWdvLTYwMCByb3VuZGVkLTJ4bCBzaGFkb3ctbGcgcC02IHRleHQtd2hpdGUgdHJhbnNmb3JtIGhvdmVyOnNjYWxlLTEwNSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0yMDBcIj5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIGJnLXdoaXRlLzIwIHJvdW5kZWQtZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGxcIj4lPC9zcGFuPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1wdXJwbGUtMTAwIHRleHQtc20gZm9udC1tZWRpdW0gbWItMVwiPlByZXNlbnQgUmF0ZTwvcD5cclxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkXCI+e3N1bW1hcnlTdGF0cy5wcmVzZW50UGVyY2VudH0lPC9wPlxyXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LXNtIGZvbnQtbW9ubyB0ZXh0LXdoaXRlIGB9PlxyXG4gICAgICAgICAgICAgIHtudW1iZXJUb0luZGlhbldvcmRzKHN1bW1hcnlTdGF0cy5wcmVzZW50UGVyY2VudCB8fCAwKX1cclxuICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgey8qIFRvdGFsIFdvcmtpbmcgVGltZSAtIE9ubHkgZm9yIHNpbmdsZSBlbXBsb3llZSAqL31cclxuICAgICAgICAgIHtzZWxlY3RlZEVtcGxveWVlICE9PSBcImFsbFwiICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1iciBmcm9tLXRlYWwtNTAwIHRvLWN5YW4tNjAwIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBwLTYgdGV4dC13aGl0ZSB0cmFuc2Zvcm0gaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTIwMFwiPlxyXG4gICAgICAgICAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0yXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCBiZy13aGl0ZS8yMCByb3VuZGVkLWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGxcIj7ij7E8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Rpdj4gKi99XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC10ZWFsLTEwMCB0ZXh0LXNtIGZvbnQtbWVkaXVtIG1iLTFcIj5Ub3RhbCBXb3JraW5nIFRpbWU8L3A+XHJcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC00eGwgZm9udC1ib2xkXCI+e3N1bW1hcnlTdGF0cy50b3RhbFdvcmtpbmdUaW1lfTwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICB7LyogRGF0YSBUYWJsZSAqL31cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtMnhsIHNoYWRvdy1sZyBwLTYgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDBcIj5cclxuICAgICAgICAgIHtsb2FkaW5nID8gKFxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGgtNjRcIj5cclxuICAgICAgICAgICAgICA8U3BpbiBzaXplPVwibGFyZ2VcIiAvPlxyXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIG10LTRcIj5Mb2FkaW5nIGF0dGVuZGFuY2UgZGF0YS4uLjwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIDxEYXRhVGFibGVcclxuICAgICAgICAgICAgICAgIGNvbHVtbnM9e3NlbGVjdGVkRW1wbG95ZWUgPT09IFwiYWxsXCIgPyBhbGxFbXBsb3llZXNDb2x1bW5zIDogaW5kaXZpZHVhbENvbHVtbnN9XHJcbiAgICAgICAgICAgICAgICBkYXRhPXtzYWZlRGF0YX1cclxuICAgICAgICAgICAgICAgIGV4cG9ydGVkUGRmTmFtZT1cIkVtcGxveWVlIE1vbnRobHkgQXR0ZW5kZW5jZSBSZXBvcnRcIlxyXG4gICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YEVtcGxveWVlTW9udGhseSBBdHRlbmRlbmNlIFJlcG9ydC5jc3ZgfVxyXG4gICAgICAgICAgICAgICAgbG9hZGluZz17bG9hZGluZ31cclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwXCI+XHJcbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCB0ZXh0LXNtXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+U2hvd2luZyBhdHRlbmRhbmNlIGZvcjo8L3NwYW4+e1wiIFwifVxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJsdWUtNjAwIGZvbnQtc2VtaWJvbGRcIj57c2VsZWN0ZWREYXRlfTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkRW1wbG95ZWUgIT09IFwiYWxsXCIgJiZcclxuICAgICAgICAgICAgICAgICAgICBgIOKAoiAke2VtcGxveWVlcy5maW5kKChlKSA9PiBlLl9pZCA9PT0gc2VsZWN0ZWRFbXBsb3llZSk/Lm5hbWUgfHwgXCJcIn1gfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEVtcGxveWVlTW9udGhseVJlcG9ydDsiXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvRW1wbG95ZWVNb250aGx5UmVwb3J0LmpzeCJ9