import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/PayOutPettyCash.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=819e0a34"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=819e0a34"; const useEffect = __vite__cjsImport3_react["useEffect"]; const useState = __vite__cjsImport3_react["useState"];
import Sidebar from "/src/components/layouts/Sidebar.jsx";
import API from "/src/instance/TokenInstance.js";
import Modal from "/src/components/modals/Modal.jsx";
import DataTable from "/src/components/layouts/Datatable.jsx";
import CustomAlert from "/src/components/alerts/CustomAlert.jsx";
import CircularLoader from "/src/components/loaders/CircularLoader.jsx";
import Navbar from "/src/components/layouts/Navbar.jsx";
import { Select, Tooltip, notification } from "/node_modules/.vite/deps/antd.js?v=819e0a34";
import CustomAlertDialog from "/src/components/alerts/CustomAlertDialog.jsx";
import Breadcrumb from "/src/helpers/Breadcrumb.jsx";
const PayOutPettyCash = () => {
  _s();
  const paymentFor = "petty_cash";
  const [api, contextHolder] = notification.useNotification();
  const [showPettyCashModal, setShowPettyCashModal] = useState(false);
  const [modifyPayment, setModifyPayment] = useState(false);
  const [adminId, setAdminId] = useState("");
  const GlobalSearchChangeHandler = (e) => {
    const { value } = e.target;
    setSearchText(value);
  };
  const [alertConfig, setAlertConfig] = useState({
    visibility: false,
    message: "Something went wrong!",
    noReload: false,
    type: "info"
  });
  const expenseCategories = [
    { key: "$1", title: "Chit Operations" },
    { key: "$2", title: "Staff & Administration" },
    { key: "$3", title: "Communication & Technology" },
    { key: "$4", title: "Legal & Compliance" },
    { key: "$5", title: "Marketing & Promotion" },
    { key: "$6", title: "Travel & Conveyance" },
    { key: "$7", title: "Training & Development" },
    { key: "$8", title: "Maintenance & Repairs" },
    { key: "$9", title: "Banking & Financial Charges" },
    { key: "$10", title: "Utilities & Bills" },
    { key: "$11", title: "Insurance" },
    { key: "$12", title: "Data & Security" },
    { key: "$13", title: "Customer Service & Support" },
    { key: "$14", title: "Depreciation & Assets" },
    { key: "$15", title: "Miscellaneous / Other Expenses" }
  ];
  const [pettyCashPayments, setPettyCashPayments] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [adminName, setAdminName] = useState("");
  const [errors, setErrors] = useState({});
  const [agents, setAgents] = useState([]);
  const [reRender, setReRender] = useState(0);
  const [pettyCashForm, setPettyCashForm] = useState({
    category: "",
    pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
    amount: "",
    pay_type: "cash",
    transaction_id: "",
    note: "",
    pay_for: paymentFor,
    admin_type: "",
    expense_description: "",
    agent_id: ""
  });
  const fetchPettyCashPayments = async () => {
    setIsLoading(true);
    try {
      const response = await API.get("/payment-out/get-petty-cash-payments");
      const responseData = response.data.map((payment, index) => ({
        id: index + 1,
        _id: payment._id,
        category: payment.category,
        expense_description: payment.expense_description,
        pay_date: payment.pay_date,
        amount: payment.amount,
        pay_type: payment.pay_type,
        transaction_id: payment.transaction_id,
        note: payment.note,
        disbursed_by: payment.admin_type?.name,
        receipt_no: payment.receipt_no,
        agent: payment.agent_id?.name
      }));
      setPettyCashPayments(responseData);
    } catch (error) {
      console.error("Failed to fetch Petty Cash payments", error);
      setPettyCashPayments([]);
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    const fetchAgents = async () => {
      try {
        const response = await API.get("/agent/get-agent");
        if (response.data) {
          setAgents(response.data);
        } else {
          setAgents({});
        }
      } catch (error) {
        console.error("Failed to fetch Agents");
      }
    };
    fetchAgents();
  }, []);
  useEffect(() => {
    const user = localStorage.getItem("user");
    const userObj = JSON.parse(user);
    setAdminId(userObj?._id);
    setAdminName(userObj?.name || "");
    if (userObj?.admin_access_right_id?.access_permissions?.edit_payment) {
      setModifyPayment(
        userObj.admin_access_right_id.access_permissions.edit_payment === "true"
      );
    }
    fetchPettyCashPayments();
  }, [reRender]);
  const handlePettyCashChange = (e) => {
    const { name, value } = e.target;
    setPettyCashForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };
  const validateForm = () => {
    const newErrors = {};
    if (!pettyCashForm.category) {
      newErrors.category = "Please select a category";
    }
    if (!pettyCashForm.amount || isNaN(pettyCashForm.amount)) {
      newErrors.amount = "Please enter a valid amount";
    }
    if (pettyCashForm.pay_type === "online" && !pettyCashForm.transaction_id) {
      newErrors.transaction_id = "Transaction ID is required for online payments";
    }
    if (!pettyCashForm.expense_description) {
      newErrors.expense_description = "Please enter expense description";
    }
    if (!pettyCashForm.agent_id) {
      newErrors.agent = "Please select staff name";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  const handlePettyCashSubmit = async (e) => {
    e.preventDefault();
    const isValid = validateForm();
    if (isValid) {
      try {
        setIsLoading(true);
        const payload = {
          ...pettyCashForm,
          admin_type: adminId
        };
        await API.post("/payment-out/add-petty-cash-payment", payload);
        api.open({
          message: "Petty Cash Payment Successful",
          description: "The petty cash payment has been recorded successfully.",
          className: "bg-green-500 rounded-lg font-semibold text-white",
          showProgress: true,
          pauseOnHover: false
        });
        setShowPettyCashModal(false);
        setPettyCashForm({
          category: "",
          pay_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
          amount: "",
          pay_type: "cash",
          transaction_id: "",
          note: "",
          admin_type: adminId,
          pay_for: paymentFor,
          expense_description: "",
          agent_id: ""
        });
        setReRender((val) => val + 1);
      } catch (error) {
        const message = error.response?.data?.message || "Something went wrong";
        api.open({
          message: "Petty Cash Payment Failed",
          description: message,
          showProgress: true,
          pauseOnHover: false,
          className: "bg-red-500 rounded-lg font-semibold text-white"
        });
      } finally {
        setIsLoading(false);
      }
    }
  };
  const pettyCashColumns = [
    { key: "id", header: "SL. NO" },
    { key: "pay_date", header: "Payment Date" },
    { key: "category", header: "Category" },
    { key: "expense_description", header: "Description" },
    { key: "amount", header: "Amount (₹)" },
    { key: "pay_type", header: "Payment Mode" },
    { key: "receipt_no", header: "Receipt No" },
    { key: "agent", header: "Staff" },
    { key: "note", header: "Note" },
    { key: "disbursed_by", header: "Disbursed by" }
  ];
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV("div", { children: [
    contextHolder,
    /* @__PURE__ */ jsxDEV("div", { className: "flex mt-20", children: [
      /* @__PURE__ */ jsxDEV(Sidebar, {}, void 0, false, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
        lineNumber: 227,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV(
        Navbar,
        {
          onGlobalSearchChangeHandler: GlobalSearchChangeHandler,
          visibility: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
          lineNumber: 228,
          columnNumber: 19
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CustomAlertDialog,
        {
          type: alertConfig.type,
          isVisible: alertConfig.visibility,
          message: alertConfig.message,
          onClose: () => setAlertConfig((prev) => ({ ...prev, visibility: false }))
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
          lineNumber: 232,
          columnNumber: 19
        },
        this
      ),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-7", children: [
        /* @__PURE__ */ jsxDEV(Breadcrumb, {}, void 0, false, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
          lineNumber: 241,
          columnNumber: 16
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-center", children: [
          /* @__PURE__ */ jsxDEV("h1", { className: "text-2xl font-semibold", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-2xl text-red-500 font-bold", children: "PETTY CASH" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
              lineNumber: 244,
              columnNumber: 17
            }, this),
            "  ",
            "Management"
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
            lineNumber: 243,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Tooltip, { title: "Record Petty Cash Expense", children: /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: () => setShowPettyCashModal(true),
              className: "ml-4 bg-violet-900 text-white px-4 py-2 rounded shadow-md hover:bg-violet-600 transition duration-200 flex items-center",
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "mr-2", children: "+" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 256,
                  columnNumber: 19
                }, this),
                " New Expense"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
              lineNumber: 252,
              columnNumber: 17
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
            lineNumber: 251,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
          lineNumber: 242,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "mt-8 bg-white p-6 rounded-lg shadow-md", children: [
          /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-semibold mb-4 text-violet-800 border-b pb-2", children: "Petty Cash Transactions" }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
            lineNumber: 262,
            columnNumber: 15
          }, this),
          pettyCashPayments.length > 0 ? /* @__PURE__ */ jsxDEV(
            DataTable,
            {
              data: pettyCashPayments,
              columns: pettyCashColumns,
              exportedFileName: `petty_cash_transactions_${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.csv`
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
              lineNumber: 267,
              columnNumber: 15
            },
            this
          ) : /* @__PURE__ */ jsxDEV("div", { className: "mt-10 text-center text-gray-500", children: /* @__PURE__ */ jsxDEV(
            CircularLoader,
            {
              isLoading,
              data: "Petty Cash Transactions",
              failure: pettyCashPayments.length === 0
            },
            void 0,
            false,
            {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
              lineNumber: 276,
              columnNumber: 19
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
            lineNumber: 275,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
          lineNumber: 261,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
        lineNumber: 240,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(
        Modal,
        {
          isVisible: showPettyCashModal,
          onClose: () => setShowPettyCashModal(false),
          width: "max-w-md",
          children: /* @__PURE__ */ jsxDEV("div", { className: "py-6 px-5 lg:px-8 text-left", children: [
            /* @__PURE__ */ jsxDEV("h3", { className: "mb-4 text-xl font-bold text-gray-900 border-b pb-2", children: "Record Petty Cash Expense" }, void 0, false, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
              lineNumber: 292,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV("form", { className: "space-y-4", onSubmit: handlePettyCashSubmit, children: [
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Expense Category ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 300,
                    columnNumber: 38
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 299,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "w-full h-12",
                    placeholder: "Select Category",
                    showSearch: true,
                    optionFilterProp: "children",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: pettyCashForm.category || void 0,
                    onChange: (value) => {
                      setErrors((prev) => ({ ...prev, category: "" }));
                      setPettyCashForm((prev) => ({ ...prev, category: value }));
                    },
                    children: expenseCategories.map(
                      (category) => /* @__PURE__ */ jsxDEV(Select.Option, { value: category.title, children: category.title }, category.key, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                        lineNumber: 319,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 302,
                    columnNumber: 19
                  },
                  this
                ),
                errors.category && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.category }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 325,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                lineNumber: 298,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Expense Description ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 333,
                    columnNumber: 41
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 332,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "expense_description",
                    value: pettyCashForm.expense_description,
                    onChange: handlePettyCashChange,
                    placeholder: "Enter description",
                    className: "w-full p-3 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 335,
                    columnNumber: 19
                  },
                  this
                ),
                errors.expense_description && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.expense_description }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 344,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                lineNumber: 331,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Payment Date" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 352,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "date",
                    name: "pay_date",
                    value: pettyCashForm.pay_date,
                    onChange: handlePettyCashChange,
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    disabled: !modifyPayment
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 355,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                lineNumber: 351,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Amount (₹) ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 368,
                    columnNumber: 32
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 367,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "number",
                    name: "amount",
                    value: pettyCashForm.amount,
                    onChange: handlePettyCashChange,
                    placeholder: "Enter amount",
                    className: "w-full p-3 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 370,
                    columnNumber: 19
                  },
                  this
                ),
                errors.amount && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.amount }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 379,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                lineNumber: 366,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Payment Mode" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 385,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "select",
                  {
                    name: "pay_type",
                    value: pettyCashForm.pay_type,
                    onChange: handlePettyCashChange,
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    children: [
                      /* @__PURE__ */ jsxDEV("option", { value: "cash", children: "Cash" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                        lineNumber: 394,
                        columnNumber: 21
                      }, this),
                      /* @__PURE__ */ jsxDEV("option", { value: "online", children: "Online" }, void 0, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                        lineNumber: 395,
                        columnNumber: 21
                      }, this),
                      modifyPayment && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                        /* @__PURE__ */ jsxDEV("option", { value: "cheque", children: "Cheque" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                          lineNumber: 398,
                          columnNumber: 25
                        }, this),
                        /* @__PURE__ */ jsxDEV("option", { value: "bank_transfer", children: "Bank Transfer" }, void 0, false, {
                          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                          lineNumber: 399,
                          columnNumber: 25
                        }, this)
                      ] }, void 0, true, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                        lineNumber: 397,
                        columnNumber: 21
                      }, this)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 388,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                lineNumber: 384,
                columnNumber: 17
              }, this),
              pettyCashForm.pay_type === "online" && /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Transaction ID ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 409,
                    columnNumber: 38
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 408,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    name: "transaction_id",
                    value: pettyCashForm.transaction_id,
                    onChange: handlePettyCashChange,
                    placeholder: "Enter transaction ID",
                    className: "w-full p-3 border border-gray-300 rounded-lg"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 411,
                    columnNumber: 21
                  },
                  this
                ),
                errors.transaction_id && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.transaction_id }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 420,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                lineNumber: 407,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: "Note" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 429,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "textarea",
                  {
                    name: "note",
                    value: pettyCashForm.note,
                    onChange: handlePettyCashChange,
                    placeholder: "Additional details",
                    className: "w-full p-3 border border-gray-300 rounded-lg",
                    rows: "2"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 432,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                lineNumber: 428,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-2 text-sm font-medium text-gray-900", children: [
                  "Staff ",
                  /* @__PURE__ */ jsxDEV("span", { className: "text-red-500", children: "*" }, void 0, false, {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 443,
                    columnNumber: 26
                  }, this)
                ] }, void 0, true, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 442,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV(
                  Select,
                  {
                    className: "w-full h-12",
                    placeholder: "Select Staff",
                    showSearch: true,
                    optionFilterProp: "children",
                    filterOption: (input, option) => option.children.toLowerCase().includes(input.toLowerCase()),
                    value: pettyCashForm.agent_id || void 0,
                    onChange: (value) => {
                      setErrors((prev) => ({ ...prev, agent: "" }));
                      setPettyCashForm((prev) => ({ ...prev, agent_id: value }));
                    },
                    children: agents.map(
                      (agent) => /* @__PURE__ */ jsxDEV(Select.Option, { value: agent._id, children: agent.name }, agent.key, false, {
                        fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                        lineNumber: 462,
                        columnNumber: 21
                      }, this)
                    )
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 445,
                    columnNumber: 19
                  },
                  this
                ),
                errors.agent && /* @__PURE__ */ jsxDEV("p", { className: "text-red-500 text-xs mt-1", children: errors.agent }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 468,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                lineNumber: 441,
                columnNumber: 20
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "w-full bg-violet-50 p-3 rounded-lg", children: [
                /* @__PURE__ */ jsxDEV("label", { className: "block mb-1 text-sm font-medium text-gray-900", children: "Disbursed By" }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 475,
                  columnNumber: 19
                }, this),
                /* @__PURE__ */ jsxDEV("div", { className: "font-semibold", children: adminName }, void 0, false, {
                  fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                  lineNumber: 478,
                  columnNumber: 19
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                lineNumber: 474,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end space-x-3 pt-4", children: [
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "button",
                    onClick: () => setShowPettyCashModal(false),
                    className: "px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100",
                    children: "Cancel"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 483,
                    columnNumber: 19
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  "button",
                  {
                    type: "submit",
                    disabled: isLoading,
                    className: "px-4 py-2 bg-violet-700 text-white rounded-lg hover:bg-violet-600 disabled:opacity-50",
                    children: isLoading ? "Processing..." : "Save Expense"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                    lineNumber: 490,
                    columnNumber: 19
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
                lineNumber: 482,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
              lineNumber: 296,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
            lineNumber: 291,
            columnNumber: 13
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
          lineNumber: 286,
          columnNumber: 11
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
      lineNumber: 226,
      columnNumber: 10
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
    lineNumber: 224,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx",
    lineNumber: 223,
    columnNumber: 5
  }, this);
};
_s(PayOutPettyCash, "V65MSr4TqAeKmtuxgD3Nr44l6ow=", false, function() {
  return [notification.useNotification];
});
_c = PayOutPettyCash;
export default PayOutPettyCash;
var _c;
$RefreshReg$(_c, "PayOutPettyCash");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/SYS 6/Documents/Project/prod-frontend-mychits-v2/src/pages/PayOutPettyCash.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa09rQixTQTBLSSxVQTFLSjsyQkFsT2xCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsU0FBU0EsV0FBV0MsZ0JBQWdCO0FBQ3BDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsU0FBUztBQUNoQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLG9CQUFvQjtBQUMzQixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLFFBQVFDLFNBQVNDLG9CQUFvQjtBQUM5QyxPQUFPQyx1QkFBdUI7QUFDOUIsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLGtCQUFrQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzVCLFFBQU1DLGFBQWE7QUFDbkIsUUFBTSxDQUFDQyxLQUFLQyxhQUFhLElBQUlQLGFBQWFRLGdCQUFnQjtBQUMxRCxRQUFNLENBQUNDLG9CQUFvQkMscUJBQXFCLElBQUlwQixTQUFTLEtBQUs7QUFDbEUsUUFBTSxDQUFDcUIsZUFBZUMsZ0JBQWdCLElBQUl0QixTQUFTLEtBQUs7QUFDeEQsUUFBTSxDQUFDdUIsU0FBU0MsVUFBVSxJQUFJeEIsU0FBUyxFQUFFO0FBRXhDLFFBQU15Qiw0QkFBNEJBLENBQUNDLE1BQU07QUFDeEMsVUFBTSxFQUFFQyxNQUFNLElBQUlELEVBQUVFO0FBQ3BCQyxrQkFBY0YsS0FBSztBQUFBLEVBQ3JCO0FBRUEsUUFBTSxDQUFDRyxhQUFhQyxjQUFjLElBQUkvQixTQUFTO0FBQUEsSUFDN0NnQyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxJQUNWQyxNQUFNO0FBQUEsRUFDUixDQUFDO0FBQ0QsUUFBTUMsb0JBQW9CO0FBQUEsSUFDeEIsRUFBRUMsS0FBSyxNQUFNQyxPQUFPLGtCQUFrQjtBQUFBLElBQ3RDLEVBQUVELEtBQUssTUFBTUMsT0FBTyx5QkFBeUI7QUFBQSxJQUM3QyxFQUFFRCxLQUFLLE1BQU1DLE9BQU8sNkJBQTZCO0FBQUEsSUFDakQsRUFBRUQsS0FBSyxNQUFNQyxPQUFPLHFCQUFxQjtBQUFBLElBQ3pDLEVBQUVELEtBQUssTUFBTUMsT0FBTyx3QkFBd0I7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLE1BQU1DLE9BQU8sc0JBQXNCO0FBQUEsSUFDMUMsRUFBRUQsS0FBSyxNQUFNQyxPQUFPLHlCQUF5QjtBQUFBLElBQzdDLEVBQUVELEtBQUssTUFBTUMsT0FBTyx3QkFBd0I7QUFBQSxJQUM1QyxFQUFFRCxLQUFLLE1BQU1DLE9BQU8sOEJBQThCO0FBQUEsSUFDbEQsRUFBRUQsS0FBSyxPQUFPQyxPQUFPLG9CQUFvQjtBQUFBLElBQ3pDLEVBQUVELEtBQUssT0FBT0MsT0FBTyxZQUFZO0FBQUEsSUFDakMsRUFBRUQsS0FBSyxPQUFPQyxPQUFPLGtCQUFrQjtBQUFBLElBQ3ZDLEVBQUVELEtBQUssT0FBT0MsT0FBTyw2QkFBNkI7QUFBQSxJQUNsRCxFQUFFRCxLQUFLLE9BQU9DLE9BQU8sd0JBQXdCO0FBQUEsSUFDN0MsRUFBRUQsS0FBSyxPQUFPQyxPQUFPLGlDQUFpQztBQUFBLEVBQUM7QUFHekQsUUFBTSxDQUFDQyxtQkFBbUJDLG9CQUFvQixJQUFJeEMsU0FBUyxFQUFFO0FBQzdELFFBQU0sQ0FBQ3lDLFdBQVdDLFlBQVksSUFBSTFDLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMyQyxXQUFXQyxZQUFZLElBQUk1QyxTQUFTLEVBQUU7QUFDN0MsUUFBTSxDQUFDNkMsUUFBUUMsU0FBUyxJQUFJOUMsU0FBUyxDQUFDLENBQUM7QUFDdkMsUUFBTSxDQUFDK0MsUUFBUUMsU0FBUyxJQUFJaEQsU0FBUyxFQUFFO0FBQ3ZDLFFBQU0sQ0FBQ2lELFVBQVVDLFdBQVcsSUFBSWxELFNBQVMsQ0FBQztBQUMxQyxRQUFNLENBQUNtRCxlQUFlQyxnQkFBZ0IsSUFBSXBELFNBQVM7QUFBQSxJQUNqRHFELFVBQVU7QUFBQSxJQUNWQyxXQUFVLG9CQUFJQyxLQUFLLEdBQUVDLFlBQVksRUFBRUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUFBLElBQy9DQyxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLElBQ1ZDLGdCQUFnQjtBQUFBLElBQ2hCQyxNQUFNO0FBQUEsSUFDTkMsU0FBUy9DO0FBQUFBLElBQ1RnRCxZQUFZO0FBQUEsSUFDWkMscUJBQXFCO0FBQUEsSUFDckJDLFVBQVM7QUFBQSxFQUNYLENBQUM7QUFHRCxRQUFNQyx5QkFBeUIsWUFBWTtBQUN6Q3hCLGlCQUFhLElBQUk7QUFDakIsUUFBSTtBQUNGLFlBQU15QixXQUFXLE1BQU1qRSxJQUFJa0UsSUFBSSxzQ0FBc0M7QUFDckUsWUFBTUMsZUFBZUYsU0FBU0csS0FBS0MsSUFBSSxDQUFDQyxTQUFTQyxXQUFXO0FBQUEsUUFDMURDLElBQUlELFFBQVE7QUFBQSxRQUNaRSxLQUFLSCxRQUFRRztBQUFBQSxRQUNidEIsVUFBVW1CLFFBQVFuQjtBQUFBQSxRQUNsQlcscUJBQXFCUSxRQUFRUjtBQUFBQSxRQUM3QlYsVUFBVWtCLFFBQVFsQjtBQUFBQSxRQUNsQkksUUFBUWMsUUFBUWQ7QUFBQUEsUUFDaEJDLFVBQVVhLFFBQVFiO0FBQUFBLFFBQ2xCQyxnQkFBZ0JZLFFBQVFaO0FBQUFBLFFBQ3hCQyxNQUFNVyxRQUFRWDtBQUFBQSxRQUNkZSxjQUFjSixRQUFRVCxZQUFZYztBQUFBQSxRQUNsQ0MsWUFBWU4sUUFBUU07QUFBQUEsUUFDcEJDLE9BQU1QLFFBQVFQLFVBQVVZO0FBQUFBLE1BQzFCLEVBQUU7QUFDRnJDLDJCQUFxQjZCLFlBQVk7QUFBQSxJQUNuQyxTQUFTVyxPQUFPO0FBQ2RDLGNBQVFELE1BQU0sdUNBQXVDQSxLQUFLO0FBQzFEeEMsMkJBQXFCLEVBQUU7QUFBQSxJQUN6QixVQUFDO0FBQ0NFLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFDQTNDLFlBQVUsTUFBTTtBQUNmLFVBQU1tRixjQUFjLFlBQVk7QUFDL0IsVUFBSTtBQUNGLGNBQU1mLFdBQVcsTUFBTWpFLElBQUlrRSxJQUFJLGtCQUFrQjtBQUNqRCxZQUFJRCxTQUFTRyxNQUFNO0FBQ2pCdEIsb0JBQVVtQixTQUFTRyxJQUFJO0FBQUEsUUFDekIsT0FBTztBQUNMdEIsb0JBQVUsQ0FBQyxDQUFDO0FBQUEsUUFDZDtBQUFBLE1BQ0YsU0FBU2dDLE9BQU87QUFDZEMsZ0JBQVFELE1BQU0sd0JBQXdCO0FBQUEsTUFDeEM7QUFBQSxJQUNGO0FBQ0FFLGdCQUFZO0FBQUEsRUFDWixHQUFHLEVBQUU7QUFDTG5GLFlBQVUsTUFBTTtBQUNkLFVBQU1vRixPQUFPQyxhQUFhQyxRQUFRLE1BQU07QUFDeEMsVUFBTUMsVUFBVUMsS0FBS0MsTUFBTUwsSUFBSTtBQUMvQjNELGVBQVc4RCxTQUFTWCxHQUFHO0FBQ3ZCL0IsaUJBQWEwQyxTQUFTVCxRQUFRLEVBQUU7QUFFaEMsUUFBSVMsU0FBU0csdUJBQXVCQyxvQkFBb0JDLGNBQWM7QUFDcEVyRTtBQUFBQSxRQUNFZ0UsUUFBUUcsc0JBQXNCQyxtQkFBbUJDLGlCQUFpQjtBQUFBLE1BQ3BFO0FBQUEsSUFDRjtBQUVBekIsMkJBQXVCO0FBQUEsRUFDekIsR0FBRyxDQUFDakIsUUFBUSxDQUFDO0FBRWIsUUFBTTJDLHdCQUF3QkEsQ0FBQ2xFLE1BQU07QUFDbkMsVUFBTSxFQUFFbUQsTUFBTWxELE1BQU0sSUFBSUQsRUFBRUU7QUFDMUJ3QixxQkFBaUIsQ0FBQ3lDLFVBQVUsRUFBRSxHQUFHQSxNQUFNLENBQUNoQixJQUFJLEdBQUdsRCxNQUFNLEVBQUU7QUFDdkRtQixjQUFVLENBQUMrQyxVQUFVLEVBQUUsR0FBR0EsTUFBTSxDQUFDaEIsSUFBSSxHQUFHLEdBQUcsRUFBRTtBQUFBLEVBQy9DO0FBRUEsUUFBTWlCLGVBQWVBLE1BQU07QUFDekIsVUFBTUMsWUFBWSxDQUFDO0FBRW5CLFFBQUksQ0FBQzVDLGNBQWNFLFVBQVU7QUFDM0IwQyxnQkFBVTFDLFdBQVc7QUFBQSxJQUN2QjtBQUVBLFFBQUksQ0FBQ0YsY0FBY08sVUFBVXNDLE1BQU03QyxjQUFjTyxNQUFNLEdBQUc7QUFDeERxQyxnQkFBVXJDLFNBQVM7QUFBQSxJQUNyQjtBQUVBLFFBQUlQLGNBQWNRLGFBQWEsWUFBWSxDQUFDUixjQUFjUyxnQkFBZ0I7QUFDeEVtQyxnQkFBVW5DLGlCQUNSO0FBQUEsSUFDSjtBQUVBLFFBQUksQ0FBQ1QsY0FBY2EscUJBQXFCO0FBQ3RDK0IsZ0JBQVUvQixzQkFBc0I7QUFBQSxJQUNsQztBQUNBLFFBQUcsQ0FBQ2IsY0FBY2MsVUFBUztBQUN6QjhCLGdCQUFVaEIsUUFBUTtBQUFBLElBRXBCO0FBRUFqQyxjQUFVaUQsU0FBUztBQUNuQixXQUFPRSxPQUFPQyxLQUFLSCxTQUFTLEVBQUVJLFdBQVc7QUFBQSxFQUMzQztBQUVBLFFBQU1DLHdCQUF3QixPQUFPMUUsTUFBTTtBQUN6Q0EsTUFBRTJFLGVBQWU7QUFDakIsVUFBTUMsVUFBVVIsYUFBYTtBQUU3QixRQUFJUSxTQUFTO0FBQ1gsVUFBSTtBQUNGNUQscUJBQWEsSUFBSTtBQUNqQixjQUFNNkQsVUFBVTtBQUFBLFVBQ2QsR0FBR3BEO0FBQUFBLFVBQ0hZLFlBQVl4QztBQUFBQSxRQUNkO0FBQ0EsY0FBTXJCLElBQUlzRyxLQUFLLHVDQUF1Q0QsT0FBTztBQUM3RHZGLFlBQUl5RixLQUFLO0FBQUEsVUFDUHhFLFNBQVM7QUFBQSxVQUNUeUUsYUFBYTtBQUFBLFVBQ2JDLFdBQVc7QUFBQSxVQUNYQyxjQUFjO0FBQUEsVUFDZEMsY0FBYztBQUFBLFFBQ2hCLENBQUM7QUFFRHpGLDhCQUFzQixLQUFLO0FBQzNCZ0MseUJBQWlCO0FBQUEsVUFDZkMsVUFBVTtBQUFBLFVBQ1ZDLFdBQVUsb0JBQUlDLEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQUEsVUFDL0NDLFFBQVE7QUFBQSxVQUNSQyxVQUFVO0FBQUEsVUFDVkMsZ0JBQWdCO0FBQUEsVUFDaEJDLE1BQU07QUFBQSxVQUNORSxZQUFZeEM7QUFBQUEsVUFDWnVDLFNBQVMvQztBQUFBQSxVQUNUaUQscUJBQXFCO0FBQUEsVUFDckJDLFVBQVM7QUFBQSxRQUNYLENBQUM7QUFDRGYsb0JBQVksQ0FBQzRELFFBQVFBLE1BQU0sQ0FBQztBQUFBLE1BQzlCLFNBQVM5QixPQUFPO0FBQ2QsY0FBTS9DLFVBQVUrQyxNQUFNYixVQUFVRyxNQUFNckMsV0FBVztBQUNqRGpCLFlBQUl5RixLQUFLO0FBQUEsVUFDUHhFLFNBQVM7QUFBQSxVQUNUeUUsYUFBYXpFO0FBQUFBLFVBQ2IyRSxjQUFjO0FBQUEsVUFDZEMsY0FBYztBQUFBLFVBQ2RGLFdBQVc7QUFBQSxRQUNiLENBQUM7QUFBQSxNQUNILFVBQUM7QUFDQ2pFLHFCQUFhLEtBQUs7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsUUFBTXFFLG1CQUFtQjtBQUFBLElBQ3ZCLEVBQUUxRSxLQUFLLE1BQU0yRSxRQUFRLFNBQVM7QUFBQSxJQUM5QixFQUFFM0UsS0FBSyxZQUFZMkUsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRTNFLEtBQUssWUFBWTJFLFFBQVEsV0FBVztBQUFBLElBQ3RDLEVBQUUzRSxLQUFLLHVCQUF1QjJFLFFBQVEsY0FBYztBQUFBLElBQ3BELEVBQUUzRSxLQUFLLFVBQVUyRSxRQUFRLGFBQWE7QUFBQSxJQUN0QyxFQUFFM0UsS0FBSyxZQUFZMkUsUUFBUSxlQUFlO0FBQUEsSUFDMUMsRUFBRTNFLEtBQUssY0FBYzJFLFFBQVEsYUFBYTtBQUFBLElBQzFDLEVBQUUzRSxLQUFLLFNBQVMyRSxRQUFRLFFBQVE7QUFBQSxJQUNoQyxFQUFFM0UsS0FBSyxRQUFRMkUsUUFBUSxPQUFPO0FBQUEsSUFDOUIsRUFBRTNFLEtBQUssZ0JBQWdCMkUsUUFBUSxlQUFlO0FBQUEsRUFBQztBQUdqRCxTQUNFLG1DQUNFLGlDQUFDLFNBQ0UvRjtBQUFBQTtBQUFBQSxJQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNOO0FBQUEsNkJBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVE7QUFBQSxNQUNSO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyw2QkFBNkJRO0FBQUFBLFVBQzdCLFlBQVk7QUFBQTtBQUFBLFFBRmQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRW1CO0FBQUEsTUFFbkI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQU1LLFlBQVlLO0FBQUFBLFVBQ2xCLFdBQVdMLFlBQVlFO0FBQUFBLFVBQ3ZCLFNBQVNGLFlBQVlHO0FBQUFBLFVBQ3JCLFNBQVMsTUFDUEYsZUFBZSxDQUFDOEQsVUFBVSxFQUFFLEdBQUdBLE1BQU03RCxZQUFZLE1BQU0sRUFBRTtBQUFBO0FBQUEsUUFMN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTUc7QUFBQSxNQUVYLHVCQUFDLFNBQUksV0FBVSxpQkFDVjtBQUFBLCtCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ2QsdUJBQUMsU0FBSSxXQUFVLHFDQUNiO0FBQUEsaUNBQUMsUUFBRyxXQUFVLDBCQUNaO0FBQUEsbUNBQUMsVUFBSyxXQUFVLG1DQUFrQywwQkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0M7QUFBQSxZQUFLO0FBQUEsZUFKUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsVUFFQSx1QkFBQyxXQUFRLE9BQU0sNkJBQ2I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVMsTUFBTVosc0JBQXNCLElBQUk7QUFBQSxjQUN6QyxXQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLFVBQUssV0FBVSxRQUFPLGlCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3QjtBQUFBLGdCQUFPO0FBQUE7QUFBQTtBQUFBLFlBSmpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFPQTtBQUFBLGFBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFpQkE7QUFBQSxRQUVBLHVCQUFDLFNBQUksV0FBVSwwQ0FDYjtBQUFBLGlDQUFDLFFBQUcsV0FBVSw0REFBMkQsdUNBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUVDbUIsa0JBQWtCNEQsU0FBUyxJQUMxQjtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsTUFBTTVEO0FBQUFBLGNBQ04sU0FBU3dFO0FBQUFBLGNBQ1Qsa0JBQWtCLDRCQUNoQixvQkFBSXhELEtBQUssR0FBRUMsWUFBWSxFQUFFQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFBQTtBQUFBLFlBSjFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtTLElBR1QsdUJBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQztBQUFBLGNBQ0EsTUFBSztBQUFBLGNBQ0wsU0FBU2xCLGtCQUFrQjRELFdBQVc7QUFBQTtBQUFBLFlBSHhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUcwQyxLQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1BO0FBQUEsYUFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXNCQTtBQUFBLFdBM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0Q0E7QUFBQSxNQUVBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFXaEY7QUFBQUEsVUFDWCxTQUFTLE1BQU1DLHNCQUFzQixLQUFLO0FBQUEsVUFDMUMsT0FBTTtBQUFBLFVBRU4saUNBQUMsU0FBSSxXQUFVLCtCQUNiO0FBQUEsbUNBQUMsUUFBRyxXQUFVLHNEQUFxRCx5Q0FBbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBRUEsdUJBQUMsVUFBSyxXQUFVLGFBQVksVUFBVWdGLHVCQUVwQztBQUFBLHFDQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsa0JBQzdDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxrQkFBaUI7QUFBQSxvQkFDakIsY0FBYyxDQUFDYSxPQUFPQyxXQUNwQkEsT0FBT0MsU0FDSkMsWUFBWSxFQUNaQyxTQUFTSixNQUFNRyxZQUFZLENBQUM7QUFBQSxvQkFFakMsT0FBT2pFLGNBQWNFLFlBQVlpRTtBQUFBQSxvQkFDakMsVUFBVSxDQUFDM0YsVUFBUztBQUNsQm1CLGdDQUFVLENBQUErQyxVQUFPLEVBQUMsR0FBR0EsTUFBS3hDLFVBQVMsR0FBRSxFQUFFO0FBQ3ZDRCx1Q0FBaUIsQ0FBQ3lDLFVBQVUsRUFBRSxHQUFHQSxNQUFNeEMsVUFBVTFCLE1BQU0sRUFBRTtBQUFBLG9CQUFDO0FBQUEsb0JBRzNEUyw0QkFBa0JtQztBQUFBQSxzQkFBSSxDQUFDbEIsYUFDdEIsdUJBQUMsT0FBTyxRQUFQLEVBQWlDLE9BQU9BLFNBQVNmLE9BQy9DZSxtQkFBU2YsU0FEUWUsU0FBU2hCLEtBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRUE7QUFBQSxvQkFDRDtBQUFBO0FBQUEsa0JBcEJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFxQkE7QUFBQSxnQkFDQ1EsT0FBT1EsWUFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZSLGlCQUFPUSxZQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkE3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkErQkE7QUFBQSxjQUVBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsa0JBQzFDLHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBT0YsY0FBY2E7QUFBQUEsb0JBQ3JCLFVBQVU0QjtBQUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1osV0FBVTtBQUFBO0FBQUEsa0JBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU0wRDtBQUFBLGdCQUV6RC9DLE9BQU9tQix1QkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZuQixpQkFBT21CLHVCQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxtQkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWlCQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2I7QUFBQSx1Q0FBQyxXQUFNLFdBQVUsZ0RBQStDLDRCQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLE1BQUs7QUFBQSxvQkFDTCxPQUFPYixjQUFjRztBQUFBQSxvQkFDckIsVUFBVXNDO0FBQUFBLG9CQUNWLFdBQVU7QUFBQSxvQkFDVixVQUFVLENBQUN2RTtBQUFBQTtBQUFBQSxrQkFOYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTTJCO0FBQUEsbUJBVjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUE7QUFBQSxjQUdBLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsa0JBQ25ELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxNQUFLO0FBQUEsb0JBQ0wsT0FBTzhCLGNBQWNPO0FBQUFBLG9CQUNyQixVQUFVa0M7QUFBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaLFdBQVU7QUFBQTtBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNMEQ7QUFBQSxnQkFFekQvQyxPQUFPYSxVQUNOLHVCQUFDLE9BQUUsV0FBVSw2QkFBNkJiLGlCQUFPYSxVQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF3RDtBQUFBLG1CQWI1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWVBO0FBQUEsY0FHQSx1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0MsNEJBQWhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsT0FBT1AsY0FBY1E7QUFBQUEsb0JBQ3JCLFVBQVVpQztBQUFBQSxvQkFDVixXQUFVO0FBQUEsb0JBRVY7QUFBQSw2Q0FBQyxZQUFPLE9BQU0sUUFBTyxvQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBeUI7QUFBQSxzQkFDekIsdUJBQUMsWUFBTyxPQUFNLFVBQVMsc0JBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTZCO0FBQUEsc0JBQzVCdkUsaUJBQ0MsbUNBQ0U7QUFBQSwrQ0FBQyxZQUFPLE9BQU0sVUFBUyxzQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBNkI7QUFBQSx3QkFDN0IsdUJBQUMsWUFBTyxPQUFNLGlCQUFnQiw2QkFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFBMkM7QUFBQSwyQkFGN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFHQTtBQUFBO0FBQUE7QUFBQSxrQkFaSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBY0E7QUFBQSxtQkFsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFtQkE7QUFBQSxjQUdDOEIsY0FBY1EsYUFBYSxZQUMxQix1QkFBQyxTQUFJLFdBQVUsVUFDYjtBQUFBLHVDQUFDLFdBQU0sV0FBVSxnREFBK0M7QUFBQTtBQUFBLGtCQUMvQyx1QkFBQyxVQUFLLFdBQVUsZ0JBQWUsaUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWdDO0FBQUEscUJBRGpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsTUFBSztBQUFBLG9CQUNMLE9BQU9SLGNBQWNTO0FBQUFBLG9CQUNyQixVQUFVZ0M7QUFBQUEsb0JBQ1YsYUFBWTtBQUFBLG9CQUNaLFdBQVU7QUFBQTtBQUFBLGtCQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFNMEQ7QUFBQSxnQkFFekQvQyxPQUFPZSxrQkFDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZmLGlCQUFPZSxrQkFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUVBO0FBQUEsbUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFpQkE7QUFBQSxjQUlGLHVCQUFDLFNBQUksV0FBVSxVQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyxvQkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTCxPQUFPVCxjQUFjVTtBQUFBQSxvQkFDckIsVUFBVStCO0FBQUFBLG9CQUNWLGFBQVk7QUFBQSxvQkFDWixXQUFVO0FBQUEsb0JBQ1YsTUFBSztBQUFBO0FBQUEsa0JBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1VO0FBQUEsbUJBVlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFZQTtBQUFBLGNBQ0csdUJBQUMsU0FBSSxXQUFVLFVBQ2hCO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQztBQUFBO0FBQUEsa0JBQ3pELHVCQUFDLFVBQUssV0FBVSxnQkFBZSxpQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBZ0M7QUFBQSxxQkFEdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLFdBQVU7QUFBQSxvQkFDVixhQUFZO0FBQUEsb0JBQ1o7QUFBQSxvQkFDQSxrQkFBaUI7QUFBQSxvQkFDakIsY0FBYyxDQUFDcUIsT0FBT0MsV0FDcEJBLE9BQU9DLFNBQ0pDLFlBQVksRUFDWkMsU0FBU0osTUFBTUcsWUFBWSxDQUFDO0FBQUEsb0JBRWpDLE9BQU9qRSxjQUFjYyxZQUFZcUQ7QUFBQUEsb0JBQ2pDLFVBQVUsQ0FBQzNGLFVBQVM7QUFDbEJtQixnQ0FBVSxDQUFBK0MsVUFBTyxFQUFDLEdBQUdBLE1BQUtkLE9BQU0sR0FBRSxFQUFFO0FBQ3BDM0IsdUNBQWlCLENBQUN5QyxVQUFVLEVBQUUsR0FBR0EsTUFBTTVCLFVBQVV0QyxNQUFNLEVBQUU7QUFBQSxvQkFBQztBQUFBLG9CQUczRG9CLGlCQUFPd0I7QUFBQUEsc0JBQUksQ0FBQ1EsVUFDWCx1QkFBQyxPQUFPLFFBQVAsRUFBOEIsT0FBT0EsTUFBTUosS0FDekNJLGdCQUFNRixRQURXRSxNQUFNMUMsS0FBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFFQTtBQUFBLG9CQUNEO0FBQUE7QUFBQSxrQkFwQkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQXFCQTtBQUFBLGdCQUNDUSxPQUFPa0MsU0FDTix1QkFBQyxPQUFFLFdBQVUsNkJBQ1ZsQyxpQkFBT2tDLFNBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQTdCRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQStCSDtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLHNDQUNiO0FBQUEsdUNBQUMsV0FBTSxXQUFVLGdEQUErQyw0QkFBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLGdCQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFBaUJwQyx1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMEM7QUFBQSxtQkFKNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFLQTtBQUFBLGNBR0EsdUJBQUMsU0FBSSxXQUFVLG1DQUNiO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMLFNBQVMsTUFBTXZCLHNCQUFzQixLQUFLO0FBQUEsb0JBQzFDLFdBQVU7QUFBQSxvQkFBNkU7QUFBQTtBQUFBLGtCQUh6RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBTUE7QUFBQSxnQkFDQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxNQUFLO0FBQUEsb0JBQ0wsVUFBVXFCO0FBQUFBLG9CQUNWLFdBQVU7QUFBQSxvQkFFVEEsc0JBQVksa0JBQWtCO0FBQUE7QUFBQSxrQkFMakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsbUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFlQTtBQUFBLGlCQXpNRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTBNQTtBQUFBLGVBL01GO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZ05BO0FBQUE7QUFBQSxRQXJORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFzTkE7QUFBQSxTQWxSRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbVJEO0FBQUEsT0FyUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNSQSxLQXZSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd1JBO0FBRUo7QUFBRTNCLEdBM2VJRCxpQkFBZTtBQUFBLFVBRVVILGFBQWFRLGVBQWU7QUFBQTtBQUFBcUcsS0FGckQxRztBQTZlTixlQUFlQTtBQUFnQixJQUFBMEc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiU2lkZWJhciIsIkFQSSIsIk1vZGFsIiwiRGF0YVRhYmxlIiwiQ3VzdG9tQWxlcnQiLCJDaXJjdWxhckxvYWRlciIsIk5hdmJhciIsIlNlbGVjdCIsIlRvb2x0aXAiLCJub3RpZmljYXRpb24iLCJDdXN0b21BbGVydERpYWxvZyIsIkJyZWFkY3J1bWIiLCJQYXlPdXRQZXR0eUNhc2giLCJfcyIsInBheW1lbnRGb3IiLCJhcGkiLCJjb250ZXh0SG9sZGVyIiwidXNlTm90aWZpY2F0aW9uIiwic2hvd1BldHR5Q2FzaE1vZGFsIiwic2V0U2hvd1BldHR5Q2FzaE1vZGFsIiwibW9kaWZ5UGF5bWVudCIsInNldE1vZGlmeVBheW1lbnQiLCJhZG1pbklkIiwic2V0QWRtaW5JZCIsIkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXIiLCJlIiwidmFsdWUiLCJ0YXJnZXQiLCJzZXRTZWFyY2hUZXh0IiwiYWxlcnRDb25maWciLCJzZXRBbGVydENvbmZpZyIsInZpc2liaWxpdHkiLCJtZXNzYWdlIiwibm9SZWxvYWQiLCJ0eXBlIiwiZXhwZW5zZUNhdGVnb3JpZXMiLCJrZXkiLCJ0aXRsZSIsInBldHR5Q2FzaFBheW1lbnRzIiwic2V0UGV0dHlDYXNoUGF5bWVudHMiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJhZG1pbk5hbWUiLCJzZXRBZG1pbk5hbWUiLCJlcnJvcnMiLCJzZXRFcnJvcnMiLCJhZ2VudHMiLCJzZXRBZ2VudHMiLCJyZVJlbmRlciIsInNldFJlUmVuZGVyIiwicGV0dHlDYXNoRm9ybSIsInNldFBldHR5Q2FzaEZvcm0iLCJjYXRlZ29yeSIsInBheV9kYXRlIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic3BsaXQiLCJhbW91bnQiLCJwYXlfdHlwZSIsInRyYW5zYWN0aW9uX2lkIiwibm90ZSIsInBheV9mb3IiLCJhZG1pbl90eXBlIiwiZXhwZW5zZV9kZXNjcmlwdGlvbiIsImFnZW50X2lkIiwiZmV0Y2hQZXR0eUNhc2hQYXltZW50cyIsInJlc3BvbnNlIiwiZ2V0IiwicmVzcG9uc2VEYXRhIiwiZGF0YSIsIm1hcCIsInBheW1lbnQiLCJpbmRleCIsImlkIiwiX2lkIiwiZGlzYnVyc2VkX2J5IiwibmFtZSIsInJlY2VpcHRfbm8iLCJhZ2VudCIsImVycm9yIiwiY29uc29sZSIsImZldGNoQWdlbnRzIiwidXNlciIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJ1c2VyT2JqIiwiSlNPTiIsInBhcnNlIiwiYWRtaW5fYWNjZXNzX3JpZ2h0X2lkIiwiYWNjZXNzX3Blcm1pc3Npb25zIiwiZWRpdF9wYXltZW50IiwiaGFuZGxlUGV0dHlDYXNoQ2hhbmdlIiwicHJldiIsInZhbGlkYXRlRm9ybSIsIm5ld0Vycm9ycyIsImlzTmFOIiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsImhhbmRsZVBldHR5Q2FzaFN1Ym1pdCIsInByZXZlbnREZWZhdWx0IiwiaXNWYWxpZCIsInBheWxvYWQiLCJwb3N0Iiwib3BlbiIsImRlc2NyaXB0aW9uIiwiY2xhc3NOYW1lIiwic2hvd1Byb2dyZXNzIiwicGF1c2VPbkhvdmVyIiwidmFsIiwicGV0dHlDYXNoQ29sdW1ucyIsImhlYWRlciIsImlucHV0Iiwib3B0aW9uIiwiY2hpbGRyZW4iLCJ0b0xvd2VyQ2FzZSIsImluY2x1ZGVzIiwidW5kZWZpbmVkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUGF5T3V0UGV0dHlDYXNoLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiBlc2xpbnQtZGlzYWJsZSBuby11bnVzZWQtdmFycyAqL1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBTaWRlYmFyIGZyb20gXCIuLi9jb21wb25lbnRzL2xheW91dHMvU2lkZWJhclwiO1xyXG5pbXBvcnQgQVBJIGZyb20gXCIuLi9pbnN0YW5jZS9Ub2tlbkluc3RhbmNlXCI7XHJcbmltcG9ydCBNb2RhbCBmcm9tIFwiLi4vY29tcG9uZW50cy9tb2RhbHMvTW9kYWxcIjtcclxuaW1wb3J0IERhdGFUYWJsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXRzL0RhdGF0YWJsZVwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnQgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0XCI7XHJcbmltcG9ydCBDaXJjdWxhckxvYWRlciBmcm9tIFwiLi4vY29tcG9uZW50cy9sb2FkZXJzL0NpcmN1bGFyTG9hZGVyXCI7XHJcbmltcG9ydCBOYXZiYXIgZnJvbSBcIi4uL2NvbXBvbmVudHMvbGF5b3V0cy9OYXZiYXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0LCBUb29sdGlwLCBub3RpZmljYXRpb24gfSBmcm9tIFwiYW50ZFwiO1xyXG5pbXBvcnQgQ3VzdG9tQWxlcnREaWFsb2cgZnJvbSBcIi4uL2NvbXBvbmVudHMvYWxlcnRzL0N1c3RvbUFsZXJ0RGlhbG9nXCI7XHJcbmltcG9ydCBCcmVhZGNydW1iIGZyb20gXCIuLi9oZWxwZXJzL0JyZWFkY3J1bWJcIjtcclxuXHJcbmNvbnN0IFBheU91dFBldHR5Q2FzaCA9ICgpID0+IHtcclxuICBjb25zdCBwYXltZW50Rm9yID0gXCJwZXR0eV9jYXNoXCI7XHJcbiAgY29uc3QgW2FwaSwgY29udGV4dEhvbGRlcl0gPSBub3RpZmljYXRpb24udXNlTm90aWZpY2F0aW9uKCk7XHJcbiAgY29uc3QgW3Nob3dQZXR0eUNhc2hNb2RhbCwgc2V0U2hvd1BldHR5Q2FzaE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbbW9kaWZ5UGF5bWVudCwgc2V0TW9kaWZ5UGF5bWVudF0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2FkbWluSWQsIHNldEFkbWluSWRdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gICBjb25zdCBHbG9iYWxTZWFyY2hDaGFuZ2VIYW5kbGVyID0gKGUpID0+IHtcclxuICAgIGNvbnN0IHsgdmFsdWUgfSA9IGUudGFyZ2V0O1xyXG4gICAgc2V0U2VhcmNoVGV4dCh2YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgW2FsZXJ0Q29uZmlnLCBzZXRBbGVydENvbmZpZ10gPSB1c2VTdGF0ZSh7XHJcbiAgICB2aXNpYmlsaXR5OiBmYWxzZSxcclxuICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgd3JvbmchXCIsXHJcbiAgICBub1JlbG9hZDogZmFsc2UsXHJcbiAgICB0eXBlOiBcImluZm9cIixcclxuICB9KTtcclxuICBjb25zdCBleHBlbnNlQ2F0ZWdvcmllcyA9IFtcclxuICAgIHsga2V5OiBcIiQxXCIsIHRpdGxlOiBcIkNoaXQgT3BlcmF0aW9uc1wiIH0sXHJcbiAgICB7IGtleTogXCIkMlwiLCB0aXRsZTogXCJTdGFmZiAmIEFkbWluaXN0cmF0aW9uXCIgfSxcclxuICAgIHsga2V5OiBcIiQzXCIsIHRpdGxlOiBcIkNvbW11bmljYXRpb24gJiBUZWNobm9sb2d5XCIgfSxcclxuICAgIHsga2V5OiBcIiQ0XCIsIHRpdGxlOiBcIkxlZ2FsICYgQ29tcGxpYW5jZVwiIH0sXHJcbiAgICB7IGtleTogXCIkNVwiLCB0aXRsZTogXCJNYXJrZXRpbmcgJiBQcm9tb3Rpb25cIiB9LFxyXG4gICAgeyBrZXk6IFwiJDZcIiwgdGl0bGU6IFwiVHJhdmVsICYgQ29udmV5YW5jZVwiIH0sXHJcbiAgICB7IGtleTogXCIkN1wiLCB0aXRsZTogXCJUcmFpbmluZyAmIERldmVsb3BtZW50XCIgfSxcclxuICAgIHsga2V5OiBcIiQ4XCIsIHRpdGxlOiBcIk1haW50ZW5hbmNlICYgUmVwYWlyc1wiIH0sXHJcbiAgICB7IGtleTogXCIkOVwiLCB0aXRsZTogXCJCYW5raW5nICYgRmluYW5jaWFsIENoYXJnZXNcIiB9LFxyXG4gICAgeyBrZXk6IFwiJDEwXCIsIHRpdGxlOiBcIlV0aWxpdGllcyAmIEJpbGxzXCIgfSxcclxuICAgIHsga2V5OiBcIiQxMVwiLCB0aXRsZTogXCJJbnN1cmFuY2VcIiB9LFxyXG4gICAgeyBrZXk6IFwiJDEyXCIsIHRpdGxlOiBcIkRhdGEgJiBTZWN1cml0eVwiIH0sXHJcbiAgICB7IGtleTogXCIkMTNcIiwgdGl0bGU6IFwiQ3VzdG9tZXIgU2VydmljZSAmIFN1cHBvcnRcIiB9LFxyXG4gICAgeyBrZXk6IFwiJDE0XCIsIHRpdGxlOiBcIkRlcHJlY2lhdGlvbiAmIEFzc2V0c1wiIH0sXHJcbiAgICB7IGtleTogXCIkMTVcIiwgdGl0bGU6IFwiTWlzY2VsbGFuZW91cyAvIE90aGVyIEV4cGVuc2VzXCIgfSxcclxuICBdO1xyXG5cclxuICBjb25zdCBbcGV0dHlDYXNoUGF5bWVudHMsIHNldFBldHR5Q2FzaFBheW1lbnRzXSA9IHVzZVN0YXRlKFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFthZG1pbk5hbWUsIHNldEFkbWluTmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoe30pO1xyXG4gIGNvbnN0IFthZ2VudHMgLHNldEFnZW50c10gPSB1c2VTdGF0ZShbXSk7XHJcbiAgY29uc3QgW3JlUmVuZGVyLCBzZXRSZVJlbmRlcl0gPSB1c2VTdGF0ZSgwKTtcclxuICBjb25zdCBbcGV0dHlDYXNoRm9ybSwgc2V0UGV0dHlDYXNoRm9ybV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBjYXRlZ29yeTogXCJcIixcclxuICAgIHBheV9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgYW1vdW50OiBcIlwiLFxyXG4gICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICBub3RlOiBcIlwiLFxyXG4gICAgcGF5X2ZvcjogcGF5bWVudEZvcixcclxuICAgIGFkbWluX3R5cGU6IFwiXCIsXHJcbiAgICBleHBlbnNlX2Rlc2NyaXB0aW9uOiBcIlwiLFxyXG4gICAgYWdlbnRfaWQ6XCJcIlxyXG4gIH0pO1xyXG5cclxuICAvLyBGZXRjaCBwZXR0eSBjYXNoIHBheW1lbnRzXHJcbiAgY29uc3QgZmV0Y2hQZXR0eUNhc2hQYXltZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi9wYXltZW50LW91dC9nZXQtcGV0dHktY2FzaC1wYXltZW50c1wiKTtcclxuICAgICAgY29uc3QgcmVzcG9uc2VEYXRhID0gcmVzcG9uc2UuZGF0YS5tYXAoKHBheW1lbnQsIGluZGV4KSA9PiAoe1xyXG4gICAgICAgIGlkOiBpbmRleCArIDEsXHJcbiAgICAgICAgX2lkOiBwYXltZW50Ll9pZCxcclxuICAgICAgICBjYXRlZ29yeTogcGF5bWVudC5jYXRlZ29yeSxcclxuICAgICAgICBleHBlbnNlX2Rlc2NyaXB0aW9uOiBwYXltZW50LmV4cGVuc2VfZGVzY3JpcHRpb24sXHJcbiAgICAgICAgcGF5X2RhdGU6IHBheW1lbnQucGF5X2RhdGUsXHJcbiAgICAgICAgYW1vdW50OiBwYXltZW50LmFtb3VudCxcclxuICAgICAgICBwYXlfdHlwZTogcGF5bWVudC5wYXlfdHlwZSxcclxuICAgICAgICB0cmFuc2FjdGlvbl9pZDogcGF5bWVudC50cmFuc2FjdGlvbl9pZCxcclxuICAgICAgICBub3RlOiBwYXltZW50Lm5vdGUsXHJcbiAgICAgICAgZGlzYnVyc2VkX2J5OiBwYXltZW50LmFkbWluX3R5cGU/Lm5hbWUsXHJcbiAgICAgICAgcmVjZWlwdF9ubzogcGF5bWVudC5yZWNlaXB0X25vLFxyXG4gICAgICAgIGFnZW50OnBheW1lbnQuYWdlbnRfaWQ/Lm5hbWUsXHJcbiAgICAgIH0pKTtcclxuICAgICAgc2V0UGV0dHlDYXNoUGF5bWVudHMocmVzcG9uc2VEYXRhKTtcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggUGV0dHkgQ2FzaCBwYXltZW50c1wiLCBlcnJvcik7XHJcbiAgICAgIHNldFBldHR5Q2FzaFBheW1lbnRzKFtdKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICBjb25zdCBmZXRjaEFnZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgQVBJLmdldChcIi9hZ2VudC9nZXQtYWdlbnRcIik7XHJcbiAgICAgIGlmIChyZXNwb25zZS5kYXRhKSB7XHJcbiAgICAgICAgc2V0QWdlbnRzKHJlc3BvbnNlLmRhdGEpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEFnZW50cyh7fSk7XHJcbiAgICAgIH1cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggQWdlbnRzXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcbiAgZmV0Y2hBZ2VudHMoKTtcclxuICB9LCBbXSk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IHVzZXIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJcIik7XHJcbiAgICBjb25zdCB1c2VyT2JqID0gSlNPTi5wYXJzZSh1c2VyKTtcclxuICAgIHNldEFkbWluSWQodXNlck9iaj8uX2lkKTtcclxuICAgIHNldEFkbWluTmFtZSh1c2VyT2JqPy5uYW1lIHx8IFwiXCIpO1xyXG5cclxuICAgIGlmICh1c2VyT2JqPy5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQ/LmFjY2Vzc19wZXJtaXNzaW9ucz8uZWRpdF9wYXltZW50KSB7XHJcbiAgICAgIHNldE1vZGlmeVBheW1lbnQoXHJcbiAgICAgICAgdXNlck9iai5hZG1pbl9hY2Nlc3NfcmlnaHRfaWQuYWNjZXNzX3Blcm1pc3Npb25zLmVkaXRfcGF5bWVudCA9PT0gXCJ0cnVlXCJcclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBmZXRjaFBldHR5Q2FzaFBheW1lbnRzKCk7XHJcbiAgfSwgW3JlUmVuZGVyXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBldHR5Q2FzaENoYW5nZSA9IChlKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBlLnRhcmdldDtcclxuICAgIHNldFBldHR5Q2FzaEZvcm0oKHByZXYpID0+ICh7IC4uLnByZXYsIFtuYW1lXTogdmFsdWUgfSkpO1xyXG4gICAgc2V0RXJyb3JzKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBbbmFtZV06IFwiXCIgfSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IHZhbGlkYXRlRm9ybSA9ICgpID0+IHtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHt9O1xyXG5cclxuICAgIGlmICghcGV0dHlDYXNoRm9ybS5jYXRlZ29yeSkge1xyXG4gICAgICBuZXdFcnJvcnMuY2F0ZWdvcnkgPSBcIlBsZWFzZSBzZWxlY3QgYSBjYXRlZ29yeVwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghcGV0dHlDYXNoRm9ybS5hbW91bnQgfHwgaXNOYU4ocGV0dHlDYXNoRm9ybS5hbW91bnQpKSB7XHJcbiAgICAgIG5ld0Vycm9ycy5hbW91bnQgPSBcIlBsZWFzZSBlbnRlciBhIHZhbGlkIGFtb3VudFwiO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChwZXR0eUNhc2hGb3JtLnBheV90eXBlID09PSBcIm9ubGluZVwiICYmICFwZXR0eUNhc2hGb3JtLnRyYW5zYWN0aW9uX2lkKSB7XHJcbiAgICAgIG5ld0Vycm9ycy50cmFuc2FjdGlvbl9pZCA9XHJcbiAgICAgICAgXCJUcmFuc2FjdGlvbiBJRCBpcyByZXF1aXJlZCBmb3Igb25saW5lIHBheW1lbnRzXCI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFwZXR0eUNhc2hGb3JtLmV4cGVuc2VfZGVzY3JpcHRpb24pIHtcclxuICAgICAgbmV3RXJyb3JzLmV4cGVuc2VfZGVzY3JpcHRpb24gPSBcIlBsZWFzZSBlbnRlciBleHBlbnNlIGRlc2NyaXB0aW9uXCI7XHJcbiAgICB9XHJcbiAgICBpZighcGV0dHlDYXNoRm9ybS5hZ2VudF9pZCl7XHJcbiAgICAgIG5ld0Vycm9ycy5hZ2VudCA9IFwiUGxlYXNlIHNlbGVjdCBzdGFmZiBuYW1lXCI7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG5ld0Vycm9ycykubGVuZ3RoID09PSAwO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVBldHR5Q2FzaFN1Ym1pdCA9IGFzeW5jIChlKSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBjb25zdCBpc1ZhbGlkID0gdmFsaWRhdGVGb3JtKCk7XHJcblxyXG4gICAgaWYgKGlzVmFsaWQpIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IHtcclxuICAgICAgICAgIC4uLnBldHR5Q2FzaEZvcm0sXHJcbiAgICAgICAgICBhZG1pbl90eXBlOiBhZG1pbklkLFxyXG4gICAgICAgIH07XHJcbiAgICAgICAgYXdhaXQgQVBJLnBvc3QoXCIvcGF5bWVudC1vdXQvYWRkLXBldHR5LWNhc2gtcGF5bWVudFwiLCBwYXlsb2FkKTtcclxuICAgICAgICBhcGkub3Blbih7XHJcbiAgICAgICAgICBtZXNzYWdlOiBcIlBldHR5IENhc2ggUGF5bWVudCBTdWNjZXNzZnVsXCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogXCJUaGUgcGV0dHkgY2FzaCBwYXltZW50IGhhcyBiZWVuIHJlY29yZGVkIHN1Y2Nlc3NmdWxseS5cIixcclxuICAgICAgICAgIGNsYXNzTmFtZTogXCJiZy1ncmVlbi01MDAgcm91bmRlZC1sZyBmb250LXNlbWlib2xkIHRleHQtd2hpdGVcIixcclxuICAgICAgICAgIHNob3dQcm9ncmVzczogdHJ1ZSxcclxuICAgICAgICAgIHBhdXNlT25Ib3ZlcjogZmFsc2UsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHNldFNob3dQZXR0eUNhc2hNb2RhbChmYWxzZSk7XHJcbiAgICAgICAgc2V0UGV0dHlDYXNoRm9ybSh7XHJcbiAgICAgICAgICBjYXRlZ29yeTogXCJcIixcclxuICAgICAgICAgIHBheV9kYXRlOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc3BsaXQoXCJUXCIpWzBdLFxyXG4gICAgICAgICAgYW1vdW50OiBcIlwiLFxyXG4gICAgICAgICAgcGF5X3R5cGU6IFwiY2FzaFwiLFxyXG4gICAgICAgICAgdHJhbnNhY3Rpb25faWQ6IFwiXCIsXHJcbiAgICAgICAgICBub3RlOiBcIlwiLFxyXG4gICAgICAgICAgYWRtaW5fdHlwZTogYWRtaW5JZCxcclxuICAgICAgICAgIHBheV9mb3I6IHBheW1lbnRGb3IsXHJcbiAgICAgICAgICBleHBlbnNlX2Rlc2NyaXB0aW9uOiBcIlwiLFxyXG4gICAgICAgICAgYWdlbnRfaWQ6XCJcIlxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHNldFJlUmVuZGVyKCh2YWwpID0+IHZhbCArIDEpO1xyXG4gICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvci5yZXNwb25zZT8uZGF0YT8ubWVzc2FnZSB8fCBcIlNvbWV0aGluZyB3ZW50IHdyb25nXCI7XHJcbiAgICAgICAgYXBpLm9wZW4oe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJQZXR0eSBDYXNoIFBheW1lbnQgRmFpbGVkXCIsXHJcbiAgICAgICAgICBkZXNjcmlwdGlvbjogbWVzc2FnZSxcclxuICAgICAgICAgIHNob3dQcm9ncmVzczogdHJ1ZSxcclxuICAgICAgICAgIHBhdXNlT25Ib3ZlcjogZmFsc2UsXHJcbiAgICAgICAgICBjbGFzc05hbWU6IFwiYmctcmVkLTUwMCByb3VuZGVkLWxnIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBwZXR0eUNhc2hDb2x1bW5zID0gW1xyXG4gICAgeyBrZXk6IFwiaWRcIiwgaGVhZGVyOiBcIlNMLiBOT1wiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfZGF0ZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBEYXRlXCIgfSxcclxuICAgIHsga2V5OiBcImNhdGVnb3J5XCIsIGhlYWRlcjogXCJDYXRlZ29yeVwiIH0sXHJcbiAgICB7IGtleTogXCJleHBlbnNlX2Rlc2NyaXB0aW9uXCIsIGhlYWRlcjogXCJEZXNjcmlwdGlvblwiIH0sXHJcbiAgICB7IGtleTogXCJhbW91bnRcIiwgaGVhZGVyOiBcIkFtb3VudCAo4oK5KVwiIH0sXHJcbiAgICB7IGtleTogXCJwYXlfdHlwZVwiLCBoZWFkZXI6IFwiUGF5bWVudCBNb2RlXCIgfSxcclxuICAgIHsga2V5OiBcInJlY2VpcHRfbm9cIiwgaGVhZGVyOiBcIlJlY2VpcHQgTm9cIiB9LFxyXG4gICAgeyBrZXk6IFwiYWdlbnRcIiwgaGVhZGVyOiBcIlN0YWZmXCIgfSxcclxuICAgIHsga2V5OiBcIm5vdGVcIiwgaGVhZGVyOiBcIk5vdGVcIiB9LFxyXG4gICAgeyBrZXk6IFwiZGlzYnVyc2VkX2J5XCIsIGhlYWRlcjogXCJEaXNidXJzZWQgYnlcIiB9LFxyXG4gIF07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIHtjb250ZXh0SG9sZGVyfVxyXG4gICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbXQtMjBcIiA+XHJcbiAgICAgICAgICAgICAgICAgIDxTaWRlYmFyIC8+XHJcbiAgICAgICAgICAgICAgICAgIDxOYXZiYXJcclxuICAgICAgICAgICAgICAgICAgICBvbkdsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXI9e0dsb2JhbFNlYXJjaENoYW5nZUhhbmRsZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdmlzaWJpbGl0eT17dHJ1ZX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgPEN1c3RvbUFsZXJ0RGlhbG9nXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT17YWxlcnRDb25maWcudHlwZX1cclxuICAgICAgICAgICAgICAgICAgICBpc1Zpc2libGU9e2FsZXJ0Q29uZmlnLnZpc2liaWxpdHl9XHJcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZT17YWxlcnRDb25maWcubWVzc2FnZX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0QWxlcnRDb25maWcoKHByZXYpID0+ICh7IC4uLnByZXYsIHZpc2liaWxpdHk6IGZhbHNlIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IHAtN1wiPlxyXG4gICAgICAgICAgICAgICA8QnJlYWRjcnVtYiAvPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCB0ZXh0LXJlZC01MDAgZm9udC1ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgIFBFVFRZIENBU0hcclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgIHtcIiAgXCJ9XHJcbiAgICAgICAgICAgICAgICBNYW5hZ2VtZW50XHJcbiAgICAgICAgICAgICAgPC9oMT5cclxuXHJcbiAgICAgICAgICAgICAgPFRvb2x0aXAgdGl0bGU9XCJSZWNvcmQgUGV0dHkgQ2FzaCBFeHBlbnNlXCI+XHJcbiAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dQZXR0eUNhc2hNb2RhbCh0cnVlKX1cclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtNCBiZy12aW9sZXQtOTAwIHRleHQtd2hpdGUgcHgtNCBweS0yIHJvdW5kZWQgc2hhZG93LW1kIGhvdmVyOmJnLXZpb2xldC02MDAgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgZmxleCBpdGVtcy1jZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtci0yXCI+Kzwvc3Bhbj4gTmV3IEV4cGVuc2VcclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvVG9vbHRpcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggYmctd2hpdGUgcC02IHJvdW5kZWQtbGcgc2hhZG93LW1kXCI+XHJcbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZCBtYi00IHRleHQtdmlvbGV0LTgwMCBib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgICBQZXR0eSBDYXNoIFRyYW5zYWN0aW9uc1xyXG4gICAgICAgICAgICAgIDwvaDI+XHJcblxyXG4gICAgICAgICAgICAgIHtwZXR0eUNhc2hQYXltZW50cy5sZW5ndGggPiAwID8gKFxyXG4gICAgICAgICAgICAgICAgPERhdGFUYWJsZVxyXG4gICAgICAgICAgICAgICAgICBkYXRhPXtwZXR0eUNhc2hQYXltZW50c31cclxuICAgICAgICAgICAgICAgICAgY29sdW1ucz17cGV0dHlDYXNoQ29sdW1uc31cclxuICAgICAgICAgICAgICAgICAgZXhwb3J0ZWRGaWxlTmFtZT17YHBldHR5X2Nhc2hfdHJhbnNhY3Rpb25zXyR7XHJcbiAgICAgICAgICAgICAgICAgICAgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNwbGl0KFwiVFwiKVswXVxyXG4gICAgICAgICAgICAgICAgICB9LmNzdmB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwIHRleHQtY2VudGVyIHRleHQtZ3JheS01MDBcIj5cclxuICAgICAgICAgICAgICAgICAgPENpcmN1bGFyTG9hZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgaXNMb2FkaW5nPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YT1cIlBldHR5IENhc2ggVHJhbnNhY3Rpb25zXCJcclxuICAgICAgICAgICAgICAgICAgICBmYWlsdXJlPXtwZXR0eUNhc2hQYXltZW50cy5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxNb2RhbFxyXG4gICAgICAgICAgICBpc1Zpc2libGU9e3Nob3dQZXR0eUNhc2hNb2RhbH1cclxuICAgICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd1BldHR5Q2FzaE1vZGFsKGZhbHNlKX1cclxuICAgICAgICAgICAgd2lkdGg9XCJtYXgtdy1tZFwiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHktNiBweC01IGxnOnB4LTggdGV4dC1sZWZ0XCI+XHJcbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTkwMCBib3JkZXItYiBwYi0yXCI+XHJcbiAgICAgICAgICAgICAgICBSZWNvcmQgUGV0dHkgQ2FzaCBFeHBlbnNlXHJcbiAgICAgICAgICAgICAgPC9oMz5cclxuXHJcbiAgICAgICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPVwic3BhY2UteS00XCIgb25TdWJtaXQ9e2hhbmRsZVBldHR5Q2FzaFN1Ym1pdH0+XHJcbiAgICAgICAgICAgICAgICB7LyogRXhwZW5zZSBDYXRlZ29yeSAqL31cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEV4cGVuc2UgQ2F0ZWdvcnkgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLTEyXCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbGVjdCBDYXRlZ29yeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgc2hvd1NlYXJjaFxyXG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbkZpbHRlclByb3A9XCJjaGlsZHJlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgZmlsdGVyT3B0aW9uPXsoaW5wdXQsIG9wdGlvbikgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbi5jaGlsZHJlblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAudG9Mb3dlckNhc2UoKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuaW5jbHVkZXMoaW5wdXQudG9Mb3dlckNhc2UoKSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BldHR5Q2FzaEZvcm0uY2F0ZWdvcnkgfHwgdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsodmFsdWUpID0+e1xyXG4gICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JzKHByZXY9Pih7Li4ucHJldixjYXRlZ29yeTpcIlwifSkpXHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRQZXR0eUNhc2hGb3JtKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBjYXRlZ29yeTogdmFsdWUgfSkpfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIHtleHBlbnNlQ2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2NhdGVnb3J5LmtleX0gdmFsdWU9e2NhdGVnb3J5LnRpdGxlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2NhdGVnb3J5LnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5jYXRlZ29yeSAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5jYXRlZ29yeX1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBFeHBlbnNlIERlc2NyaXB0aW9uIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiZXhwZW5zZV9kZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BldHR5Q2FzaEZvcm0uZXhwZW5zZV9kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUGV0dHlDYXNoQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgZGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5leHBlbnNlX2Rlc2NyaXB0aW9uICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgdGV4dC14cyBtdC0xXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLmV4cGVuc2VfZGVzY3JpcHRpb259XHJcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBQYXltZW50IERhdGVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXlfZGF0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BldHR5Q2FzaEZvcm0ucGF5X2RhdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBldHR5Q2FzaENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFtb2RpZnlQYXltZW50fVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBBbW91bnQgKOKCuSkgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cImFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BldHR5Q2FzaEZvcm0uYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQZXR0eUNhc2hDaGFuZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciBhbW91bnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkLWxnXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5hbW91bnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj57ZXJyb3JzLmFtb3VudH08L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbFwiPlxyXG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgbWItMiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtZ3JheS05MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICBQYXltZW50IE1vZGVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwYXlfdHlwZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BldHR5Q2FzaEZvcm0ucGF5X3R5cGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBldHR5Q2FzaENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2FzaFwiPkNhc2g8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwib25saW5lXCI+T25saW5lPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgICAgICAge21vZGlmeVBheW1lbnQgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNoZXF1ZVwiPkNoZXF1ZTwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiYmFua190cmFuc2ZlclwiPkJhbmsgVHJhbnNmZXI8L29wdGlvbj5cclxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICB7cGV0dHlDYXNoRm9ybS5wYXlfdHlwZSA9PT0gXCJvbmxpbmVcIiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICBUcmFuc2FjdGlvbiBJRCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwidHJhbnNhY3Rpb25faWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3BldHR5Q2FzaEZvcm0udHJhbnNhY3Rpb25faWR9XHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlUGV0dHlDYXNoQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFbnRlciB0cmFuc2FjdGlvbiBJRFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZC1sZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JzLnRyYW5zYWN0aW9uX2lkICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LXhzIG10LTFcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy50cmFuc2FjdGlvbl9pZH1cclxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0yIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIE5vdGVcclxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cIm5vdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwZXR0eUNhc2hGb3JtLm5vdGV9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVBldHR5Q2FzaENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFkZGl0aW9uYWwgZGV0YWlsc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGdcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJvd3M9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cclxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIG1iLTIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktOTAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICBTdGFmZiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8U2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMTJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VsZWN0IFN0YWZmXCJcclxuICAgICAgICAgICAgICAgICAgICBzaG93U2VhcmNoXHJcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uRmlsdGVyUHJvcD1cImNoaWxkcmVuXCJcclxuICAgICAgICAgICAgICAgICAgICBmaWx0ZXJPcHRpb249eyhpbnB1dCwgb3B0aW9uKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgb3B0aW9uLmNoaWxkcmVuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC50b0xvd2VyQ2FzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC5pbmNsdWRlcyhpbnB1dC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGV0dHlDYXNoRm9ybS5hZ2VudF9pZCB8fCB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyh2YWx1ZSkgPT57XHJcbiAgICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcnMocHJldj0+KHsuLi5wcmV2LGFnZW50OlwiXCJ9KSlcclxuICAgICAgICAgICAgICAgICAgICAgIHNldFBldHR5Q2FzaEZvcm0oKHByZXYpID0+ICh7IC4uLnByZXYsIGFnZW50X2lkOiB2YWx1ZSB9KSl9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2FnZW50cy5tYXAoKGFnZW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0Lk9wdGlvbiBrZXk9e2FnZW50LmtleX0gdmFsdWU9e2FnZW50Ll9pZH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHthZ2VudC5uYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3QuT3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdD5cclxuICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZ2VudCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwIHRleHQteHMgbXQtMVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAge2Vycm9ycy5hZ2VudH1cclxuICAgICAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctdmlvbGV0LTUwIHAtMyByb3VuZGVkLWxnXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayBtYi0xIHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1ncmF5LTkwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIERpc2J1cnNlZCBCeVxyXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj57YWRtaW5OYW1lfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktZW5kIHNwYWNlLXgtMyBwdC00XCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93UGV0dHlDYXNoTW9kYWwoZmFsc2UpfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQtbGcgdGV4dC1ncmF5LTcwMCBob3ZlcjpiZy1ncmF5LTEwMFwiXHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBDYW5jZWxcclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy12aW9sZXQtNzAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBob3ZlcjpiZy12aW9sZXQtNjAwIGRpc2FibGVkOm9wYWNpdHktNTBcIlxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge2lzTG9hZGluZyA/IFwiUHJvY2Vzc2luZy4uLlwiIDogXCJTYXZlIEV4cGVuc2VcIn1cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPC9Nb2RhbD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUGF5T3V0UGV0dHlDYXNoO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL1NZUyA2L0RvY3VtZW50cy9Qcm9qZWN0L3Byb2QtZnJvbnRlbmQtbXljaGl0cy12Mi9zcmMvcGFnZXMvUGF5T3V0UGV0dHlDYXNoLmpzeCJ9