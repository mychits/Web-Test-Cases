import {
  GenIcon
} from "/node_modules/.vite/deps/chunk-QB673HEH.js?v=819e0a34";
import "/node_modules/.vite/deps/chunk-73THXJN7.js?v=819e0a34";
import "/node_modules/.vite/deps/chunk-2TUXWMP5.js?v=819e0a34";

// node_modules/react-icons/fi/index.mjs
function FiActivity(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "22 12 18 12 15 21 9 3 6 12 2 12" }, "child": [] }] })(props);
}
function FiAirplay(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M5 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-1" }, "child": [] }, { "tag": "polygon", "attr": { "points": "12 15 17 21 7 21 12 15" }, "child": [] }] })(props);
}
function FiAlertCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "8", "x2": "12", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "16", "x2": "12.01", "y2": "16" }, "child": [] }] })(props);
}
function FiAlertOctagon(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "8", "x2": "12", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "16", "x2": "12.01", "y2": "16" }, "child": [] }] })(props);
}
function FiAlertTriangle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "9", "x2": "12", "y2": "13" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "17", "x2": "12.01", "y2": "17" }, "child": [] }] })(props);
}
function FiAlignCenter(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "18", "y1": "10", "x2": "6", "y2": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "6", "x2": "3", "y2": "6" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "14", "x2": "3", "y2": "14" }, "child": [] }, { "tag": "line", "attr": { "x1": "18", "y1": "18", "x2": "6", "y2": "18" }, "child": [] }] })(props);
}
function FiAlignJustify(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "21", "y1": "10", "x2": "3", "y2": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "6", "x2": "3", "y2": "6" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "14", "x2": "3", "y2": "14" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "18", "x2": "3", "y2": "18" }, "child": [] }] })(props);
}
function FiAlignLeft(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "17", "y1": "10", "x2": "3", "y2": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "6", "x2": "3", "y2": "6" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "14", "x2": "3", "y2": "14" }, "child": [] }, { "tag": "line", "attr": { "x1": "17", "y1": "18", "x2": "3", "y2": "18" }, "child": [] }] })(props);
}
function FiAlignRight(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "21", "y1": "10", "x2": "7", "y2": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "6", "x2": "3", "y2": "6" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "14", "x2": "3", "y2": "14" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "18", "x2": "7", "y2": "18" }, "child": [] }] })(props);
}
function FiAnchor(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "5", "r": "3" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "22", "x2": "12", "y2": "8" }, "child": [] }, { "tag": "path", "attr": { "d": "M5 12H2a10 10 0 0 0 20 0h-3" }, "child": [] }] })(props);
}
function FiAperture(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "14.31", "y1": "8", "x2": "20.05", "y2": "17.94" }, "child": [] }, { "tag": "line", "attr": { "x1": "9.69", "y1": "8", "x2": "21.17", "y2": "8" }, "child": [] }, { "tag": "line", "attr": { "x1": "7.38", "y1": "12", "x2": "13.12", "y2": "2.06" }, "child": [] }, { "tag": "line", "attr": { "x1": "9.69", "y1": "16", "x2": "3.95", "y2": "6.06" }, "child": [] }, { "tag": "line", "attr": { "x1": "14.31", "y1": "16", "x2": "2.83", "y2": "16" }, "child": [] }, { "tag": "line", "attr": { "x1": "16.62", "y1": "12", "x2": "10.88", "y2": "21.94" }, "child": [] }] })(props);
}
function FiArchive(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "21 8 21 21 3 21 3 8" }, "child": [] }, { "tag": "rect", "attr": { "x": "1", "y": "3", "width": "22", "height": "5" }, "child": [] }, { "tag": "line", "attr": { "x1": "10", "y1": "12", "x2": "14", "y2": "12" }, "child": [] }] })(props);
}
function FiArrowDownCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "polyline", "attr": { "points": "8 12 12 16 16 12" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "8", "x2": "12", "y2": "16" }, "child": [] }] })(props);
}
function FiArrowDownLeft(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "17", "y1": "7", "x2": "7", "y2": "17" }, "child": [] }, { "tag": "polyline", "attr": { "points": "17 17 7 17 7 7" }, "child": [] }] })(props);
}
function FiArrowDownRight(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "7", "y1": "7", "x2": "17", "y2": "17" }, "child": [] }, { "tag": "polyline", "attr": { "points": "17 7 17 17 7 17" }, "child": [] }] })(props);
}
function FiArrowDown(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "12", "y1": "5", "x2": "12", "y2": "19" }, "child": [] }, { "tag": "polyline", "attr": { "points": "19 12 12 19 5 12" }, "child": [] }] })(props);
}
function FiArrowLeftCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "polyline", "attr": { "points": "12 8 8 12 12 16" }, "child": [] }, { "tag": "line", "attr": { "x1": "16", "y1": "12", "x2": "8", "y2": "12" }, "child": [] }] })(props);
}
function FiArrowLeft(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "19", "y1": "12", "x2": "5", "y2": "12" }, "child": [] }, { "tag": "polyline", "attr": { "points": "12 19 5 12 12 5" }, "child": [] }] })(props);
}
function FiArrowRightCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "polyline", "attr": { "points": "12 16 16 12 12 8" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "12", "x2": "16", "y2": "12" }, "child": [] }] })(props);
}
function FiArrowRight(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "5", "y1": "12", "x2": "19", "y2": "12" }, "child": [] }, { "tag": "polyline", "attr": { "points": "12 5 19 12 12 19" }, "child": [] }] })(props);
}
function FiArrowUpCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "polyline", "attr": { "points": "16 12 12 8 8 12" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "16", "x2": "12", "y2": "8" }, "child": [] }] })(props);
}
function FiArrowUpLeft(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "17", "y1": "17", "x2": "7", "y2": "7" }, "child": [] }, { "tag": "polyline", "attr": { "points": "7 17 7 7 17 7" }, "child": [] }] })(props);
}
function FiArrowUpRight(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "7", "y1": "17", "x2": "17", "y2": "7" }, "child": [] }, { "tag": "polyline", "attr": { "points": "7 7 17 7 17 17" }, "child": [] }] })(props);
}
function FiArrowUp(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "12", "y1": "19", "x2": "12", "y2": "5" }, "child": [] }, { "tag": "polyline", "attr": { "points": "5 12 12 5 19 12" }, "child": [] }] })(props);
}
function FiAtSign(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "4" }, "child": [] }, { "tag": "path", "attr": { "d": "M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94" }, "child": [] }] })(props);
}
function FiAward(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "8", "r": "7" }, "child": [] }, { "tag": "polyline", "attr": { "points": "8.21 13.89 7 23 12 20 17 23 15.79 13.88" }, "child": [] }] })(props);
}
function FiBarChart2(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "18", "y1": "20", "x2": "18", "y2": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "20", "x2": "12", "y2": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "6", "y1": "20", "x2": "6", "y2": "14" }, "child": [] }] })(props);
}
function FiBarChart(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "12", "y1": "20", "x2": "12", "y2": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "18", "y1": "20", "x2": "18", "y2": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "6", "y1": "20", "x2": "6", "y2": "16" }, "child": [] }] })(props);
}
function FiBatteryCharging(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M5 18H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3.19M15 6h2a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-3.19" }, "child": [] }, { "tag": "line", "attr": { "x1": "23", "y1": "13", "x2": "23", "y2": "11" }, "child": [] }, { "tag": "polyline", "attr": { "points": "11 6 7 12 13 12 9 18" }, "child": [] }] })(props);
}
function FiBattery(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "1", "y": "6", "width": "18", "height": "12", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "23", "y1": "13", "x2": "23", "y2": "11" }, "child": [] }] })(props);
}
function FiBellOff(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M13.73 21a2 2 0 0 1-3.46 0" }, "child": [] }, { "tag": "path", "attr": { "d": "M18.63 13A17.89 17.89 0 0 1 18 8" }, "child": [] }, { "tag": "path", "attr": { "d": "M6.26 6.26A5.86 5.86 0 0 0 6 8c0 7-3 9-3 9h14" }, "child": [] }, { "tag": "path", "attr": { "d": "M18 8a6 6 0 0 0-9.33-5" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "1", "x2": "23", "y2": "23" }, "child": [] }] })(props);
}
function FiBell(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" }, "child": [] }, { "tag": "path", "attr": { "d": "M13.73 21a2 2 0 0 1-3.46 0" }, "child": [] }] })(props);
}
function FiBluetooth(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "6.5 6.5 17.5 17.5 12 23 12 1 17.5 6.5 6.5 17.5" }, "child": [] }] })(props);
}
function FiBold(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M6 4h8a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z" }, "child": [] }, { "tag": "path", "attr": { "d": "M6 12h9a4 4 0 0 1 4 4 4 4 0 0 1-4 4H6z" }, "child": [] }] })(props);
}
function FiBookOpen(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" }, "child": [] }, { "tag": "path", "attr": { "d": "M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" }, "child": [] }] })(props);
}
function FiBook(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M4 19.5A2.5 2.5 0 0 1 6.5 17H20" }, "child": [] }, { "tag": "path", "attr": { "d": "M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" }, "child": [] }] })(props);
}
function FiBookmark(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" }, "child": [] }] })(props);
}
function FiBox(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" }, "child": [] }, { "tag": "polyline", "attr": { "points": "3.27 6.96 12 12.01 20.73 6.96" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "22.08", "x2": "12", "y2": "12" }, "child": [] }] })(props);
}
function FiBriefcase(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "2", "y": "7", "width": "20", "height": "14", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "path", "attr": { "d": "M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" }, "child": [] }] })(props);
}
function FiCalendar(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "4", "width": "18", "height": "18", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "16", "y1": "2", "x2": "16", "y2": "6" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "2", "x2": "8", "y2": "6" }, "child": [] }, { "tag": "line", "attr": { "x1": "3", "y1": "10", "x2": "21", "y2": "10" }, "child": [] }] })(props);
}
function FiCameraOff(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "1", "y1": "1", "x2": "23", "y2": "23" }, "child": [] }, { "tag": "path", "attr": { "d": "M21 21H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3m3-3h6l2 3h4a2 2 0 0 1 2 2v9.34m-7.72-2.06a4 4 0 1 1-5.56-5.56" }, "child": [] }] })(props);
}
function FiCamera(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "13", "r": "4" }, "child": [] }] })(props);
}
function FiCast(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M2 16.1A5 5 0 0 1 5.9 20M2 12.05A9 9 0 0 1 9.95 20M2 8V6a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-6" }, "child": [] }, { "tag": "line", "attr": { "x1": "2", "y1": "20", "x2": "2.01", "y2": "20" }, "child": [] }] })(props);
}
function FiCheckCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M22 11.08V12a10 10 0 1 1-5.93-9.14" }, "child": [] }, { "tag": "polyline", "attr": { "points": "22 4 12 14.01 9 11.01" }, "child": [] }] })(props);
}
function FiCheckSquare(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "9 11 12 14 22 4" }, "child": [] }, { "tag": "path", "attr": { "d": "M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" }, "child": [] }] })(props);
}
function FiCheck(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "20 6 9 17 4 12" }, "child": [] }] })(props);
}
function FiChevronDown(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "6 9 12 15 18 9" }, "child": [] }] })(props);
}
function FiChevronLeft(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "15 18 9 12 15 6" }, "child": [] }] })(props);
}
function FiChevronRight(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "9 18 15 12 9 6" }, "child": [] }] })(props);
}
function FiChevronUp(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "18 15 12 9 6 15" }, "child": [] }] })(props);
}
function FiChevronsDown(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "7 13 12 18 17 13" }, "child": [] }, { "tag": "polyline", "attr": { "points": "7 6 12 11 17 6" }, "child": [] }] })(props);
}
function FiChevronsLeft(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "11 17 6 12 11 7" }, "child": [] }, { "tag": "polyline", "attr": { "points": "18 17 13 12 18 7" }, "child": [] }] })(props);
}
function FiChevronsRight(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "13 17 18 12 13 7" }, "child": [] }, { "tag": "polyline", "attr": { "points": "6 17 11 12 6 7" }, "child": [] }] })(props);
}
function FiChevronsUp(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "17 11 12 6 7 11" }, "child": [] }, { "tag": "polyline", "attr": { "points": "17 18 12 13 7 18" }, "child": [] }] })(props);
}
function FiChrome(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "21.17", "y1": "8", "x2": "12", "y2": "8" }, "child": [] }, { "tag": "line", "attr": { "x1": "3.95", "y1": "6.06", "x2": "8.54", "y2": "14" }, "child": [] }, { "tag": "line", "attr": { "x1": "10.88", "y1": "21.94", "x2": "15.46", "y2": "14" }, "child": [] }] })(props);
}
function FiCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }] })(props);
}
function FiClipboard(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" }, "child": [] }, { "tag": "rect", "attr": { "x": "8", "y": "2", "width": "8", "height": "4", "rx": "1", "ry": "1" }, "child": [] }] })(props);
}
function FiClock(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "polyline", "attr": { "points": "12 6 12 12 16 14" }, "child": [] }] })(props);
}
function FiCloudDrizzle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "8", "y1": "19", "x2": "8", "y2": "21" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "13", "x2": "8", "y2": "15" }, "child": [] }, { "tag": "line", "attr": { "x1": "16", "y1": "19", "x2": "16", "y2": "21" }, "child": [] }, { "tag": "line", "attr": { "x1": "16", "y1": "13", "x2": "16", "y2": "15" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "21", "x2": "12", "y2": "23" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "15", "x2": "12", "y2": "17" }, "child": [] }, { "tag": "path", "attr": { "d": "M20 16.58A5 5 0 0 0 18 7h-1.26A8 8 0 1 0 4 15.25" }, "child": [] }] })(props);
}
function FiCloudLightning(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M19 16.9A5 5 0 0 0 18 7h-1.26a8 8 0 1 0-11.62 9" }, "child": [] }, { "tag": "polyline", "attr": { "points": "13 11 9 17 15 17 11 23" }, "child": [] }] })(props);
}
function FiCloudOff(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M22.61 16.95A5 5 0 0 0 18 10h-1.26a8 8 0 0 0-7.05-6M5 5a8 8 0 0 0 4 15h9a5 5 0 0 0 1.7-.3" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "1", "x2": "23", "y2": "23" }, "child": [] }] })(props);
}
function FiCloudRain(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "16", "y1": "13", "x2": "16", "y2": "21" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "13", "x2": "8", "y2": "21" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "15", "x2": "12", "y2": "23" }, "child": [] }, { "tag": "path", "attr": { "d": "M20 16.58A5 5 0 0 0 18 7h-1.26A8 8 0 1 0 4 15.25" }, "child": [] }] })(props);
}
function FiCloudSnow(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M20 17.58A5 5 0 0 0 18 8h-1.26A8 8 0 1 0 4 16.25" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "16", "x2": "8.01", "y2": "16" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "20", "x2": "8.01", "y2": "20" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "18", "x2": "12.01", "y2": "18" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "22", "x2": "12.01", "y2": "22" }, "child": [] }, { "tag": "line", "attr": { "x1": "16", "y1": "16", "x2": "16.01", "y2": "16" }, "child": [] }, { "tag": "line", "attr": { "x1": "16", "y1": "20", "x2": "16.01", "y2": "20" }, "child": [] }] })(props);
}
function FiCloud(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" }, "child": [] }] })(props);
}
function FiCode(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "16 18 22 12 16 6" }, "child": [] }, { "tag": "polyline", "attr": { "points": "8 6 2 12 8 18" }, "child": [] }] })(props);
}
function FiCodepen(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5 12 2" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "22", "x2": "12", "y2": "15.5" }, "child": [] }, { "tag": "polyline", "attr": { "points": "22 8.5 12 15.5 2 8.5" }, "child": [] }, { "tag": "polyline", "attr": { "points": "2 15.5 12 8.5 22 15.5" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "2", "x2": "12", "y2": "8.5" }, "child": [] }] })(props);
}
function FiCodesandbox(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" }, "child": [] }, { "tag": "polyline", "attr": { "points": "7.5 4.21 12 6.81 16.5 4.21" }, "child": [] }, { "tag": "polyline", "attr": { "points": "7.5 19.79 7.5 14.6 3 12" }, "child": [] }, { "tag": "polyline", "attr": { "points": "21 12 16.5 14.6 16.5 19.79" }, "child": [] }, { "tag": "polyline", "attr": { "points": "3.27 6.96 12 12.01 20.73 6.96" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "22.08", "x2": "12", "y2": "12" }, "child": [] }] })(props);
}
function FiCoffee(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M18 8h1a4 4 0 0 1 0 8h-1" }, "child": [] }, { "tag": "path", "attr": { "d": "M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z" }, "child": [] }, { "tag": "line", "attr": { "x1": "6", "y1": "1", "x2": "6", "y2": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "10", "y1": "1", "x2": "10", "y2": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "14", "y1": "1", "x2": "14", "y2": "4" }, "child": [] }] })(props);
}
function FiColumns(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M12 3h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-7m0-18H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h7m0-18v18" }, "child": [] }] })(props);
}
function FiCommand(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M18 3a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3H6a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 3 3 0 0 0-3-3z" }, "child": [] }] })(props);
}
function FiCompass(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "polygon", "attr": { "points": "16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" }, "child": [] }] })(props);
}
function FiCopy(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "9", "y": "9", "width": "13", "height": "13", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "path", "attr": { "d": "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" }, "child": [] }] })(props);
}
function FiCornerDownLeft(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "9 10 4 15 9 20" }, "child": [] }, { "tag": "path", "attr": { "d": "M20 4v7a4 4 0 0 1-4 4H4" }, "child": [] }] })(props);
}
function FiCornerDownRight(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "15 10 20 15 15 20" }, "child": [] }, { "tag": "path", "attr": { "d": "M4 4v7a4 4 0 0 0 4 4h12" }, "child": [] }] })(props);
}
function FiCornerLeftDown(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "14 15 9 20 4 15" }, "child": [] }, { "tag": "path", "attr": { "d": "M20 4h-7a4 4 0 0 0-4 4v12" }, "child": [] }] })(props);
}
function FiCornerLeftUp(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "14 9 9 4 4 9" }, "child": [] }, { "tag": "path", "attr": { "d": "M20 20h-7a4 4 0 0 1-4-4V4" }, "child": [] }] })(props);
}
function FiCornerRightDown(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "10 15 15 20 20 15" }, "child": [] }, { "tag": "path", "attr": { "d": "M4 4h7a4 4 0 0 1 4 4v12" }, "child": [] }] })(props);
}
function FiCornerRightUp(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "10 9 15 4 20 9" }, "child": [] }, { "tag": "path", "attr": { "d": "M4 20h7a4 4 0 0 0 4-4V4" }, "child": [] }] })(props);
}
function FiCornerUpLeft(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "9 14 4 9 9 4" }, "child": [] }, { "tag": "path", "attr": { "d": "M20 20v-7a4 4 0 0 0-4-4H4" }, "child": [] }] })(props);
}
function FiCornerUpRight(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "15 14 20 9 15 4" }, "child": [] }, { "tag": "path", "attr": { "d": "M4 20v-7a4 4 0 0 1 4-4h12" }, "child": [] }] })(props);
}
function FiCpu(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "4", "y": "4", "width": "16", "height": "16", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "rect", "attr": { "x": "9", "y": "9", "width": "6", "height": "6" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "1", "x2": "9", "y2": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "15", "y1": "1", "x2": "15", "y2": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "20", "x2": "9", "y2": "23" }, "child": [] }, { "tag": "line", "attr": { "x1": "15", "y1": "20", "x2": "15", "y2": "23" }, "child": [] }, { "tag": "line", "attr": { "x1": "20", "y1": "9", "x2": "23", "y2": "9" }, "child": [] }, { "tag": "line", "attr": { "x1": "20", "y1": "14", "x2": "23", "y2": "14" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "9", "x2": "4", "y2": "9" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "14", "x2": "4", "y2": "14" }, "child": [] }] })(props);
}
function FiCreditCard(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "1", "y": "4", "width": "22", "height": "16", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "10", "x2": "23", "y2": "10" }, "child": [] }] })(props);
}
function FiCrop(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M6.13 1L6 16a2 2 0 0 0 2 2h15" }, "child": [] }, { "tag": "path", "attr": { "d": "M1 6.13L16 6a2 2 0 0 1 2 2v15" }, "child": [] }] })(props);
}
function FiCrosshair(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "22", "y1": "12", "x2": "18", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "6", "y1": "12", "x2": "2", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "6", "x2": "12", "y2": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "22", "x2": "12", "y2": "18" }, "child": [] }] })(props);
}
function FiDatabase(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "ellipse", "attr": { "cx": "12", "cy": "5", "rx": "9", "ry": "3" }, "child": [] }, { "tag": "path", "attr": { "d": "M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" }, "child": [] }, { "tag": "path", "attr": { "d": "M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" }, "child": [] }] })(props);
}
function FiDelete(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z" }, "child": [] }, { "tag": "line", "attr": { "x1": "18", "y1": "9", "x2": "12", "y2": "15" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "9", "x2": "18", "y2": "15" }, "child": [] }] })(props);
}
function FiDisc(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "3" }, "child": [] }] })(props);
}
function FiDivideCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "8", "y1": "12", "x2": "16", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "16", "x2": "12", "y2": "16" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "8", "x2": "12", "y2": "8" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }] })(props);
}
function FiDivideSquare(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "3", "width": "18", "height": "18", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "12", "x2": "16", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "16", "x2": "12", "y2": "16" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "8", "x2": "12", "y2": "8" }, "child": [] }] })(props);
}
function FiDivide(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "6", "r": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "5", "y1": "12", "x2": "19", "y2": "12" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "18", "r": "2" }, "child": [] }] })(props);
}
function FiDollarSign(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "12", "y1": "1", "x2": "12", "y2": "23" }, "child": [] }, { "tag": "path", "attr": { "d": "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" }, "child": [] }] })(props);
}
function FiDownloadCloud(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "8 17 12 21 16 17" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "12", "x2": "12", "y2": "21" }, "child": [] }, { "tag": "path", "attr": { "d": "M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29" }, "child": [] }] })(props);
}
function FiDownload(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }, "child": [] }, { "tag": "polyline", "attr": { "points": "7 10 12 15 17 10" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "15", "x2": "12", "y2": "3" }, "child": [] }] })(props);
}
function FiDribbble(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "path", "attr": { "d": "M8.56 2.75c4.37 6.03 6.02 9.42 8.03 17.72m2.54-15.38c-3.72 4.35-8.94 5.66-16.88 5.85m19.5 1.9c-3.5-.93-6.63-.82-8.94 0-2.58.92-5.01 2.86-7.44 6.32" }, "child": [] }] })(props);
}
function FiDroplet(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z" }, "child": [] }] })(props);
}
function FiEdit2(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" }, "child": [] }] })(props);
}
function FiEdit3(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M12 20h9" }, "child": [] }, { "tag": "path", "attr": { "d": "M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" }, "child": [] }] })(props);
}
function FiEdit(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" }, "child": [] }, { "tag": "path", "attr": { "d": "M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" }, "child": [] }] })(props);
}
function FiExternalLink(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" }, "child": [] }, { "tag": "polyline", "attr": { "points": "15 3 21 3 21 9" }, "child": [] }, { "tag": "line", "attr": { "x1": "10", "y1": "14", "x2": "21", "y2": "3" }, "child": [] }] })(props);
}
function FiEyeOff(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "1", "x2": "23", "y2": "23" }, "child": [] }] })(props);
}
function FiEye(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "3" }, "child": [] }] })(props);
}
function FiFacebook(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" }, "child": [] }] })(props);
}
function FiFastForward(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "13 19 22 12 13 5 13 19" }, "child": [] }, { "tag": "polygon", "attr": { "points": "2 19 11 12 2 5 2 19" }, "child": [] }] })(props);
}
function FiFeather(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z" }, "child": [] }, { "tag": "line", "attr": { "x1": "16", "y1": "8", "x2": "2", "y2": "22" }, "child": [] }, { "tag": "line", "attr": { "x1": "17.5", "y1": "15", "x2": "9", "y2": "15" }, "child": [] }] })(props);
}
function FiFigma(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M5 5.5A3.5 3.5 0 0 1 8.5 2H12v7H8.5A3.5 3.5 0 0 1 5 5.5z" }, "child": [] }, { "tag": "path", "attr": { "d": "M12 2h3.5a3.5 3.5 0 1 1 0 7H12V2z" }, "child": [] }, { "tag": "path", "attr": { "d": "M12 12.5a3.5 3.5 0 1 1 7 0 3.5 3.5 0 1 1-7 0z" }, "child": [] }, { "tag": "path", "attr": { "d": "M5 19.5A3.5 3.5 0 0 1 8.5 16H12v3.5a3.5 3.5 0 1 1-7 0z" }, "child": [] }, { "tag": "path", "attr": { "d": "M5 12.5A3.5 3.5 0 0 1 8.5 9H12v7H8.5A3.5 3.5 0 0 1 5 12.5z" }, "child": [] }] })(props);
}
function FiFileMinus(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" }, "child": [] }, { "tag": "polyline", "attr": { "points": "14 2 14 8 20 8" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "15", "x2": "15", "y2": "15" }, "child": [] }] })(props);
}
function FiFilePlus(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" }, "child": [] }, { "tag": "polyline", "attr": { "points": "14 2 14 8 20 8" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "18", "x2": "12", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "15", "x2": "15", "y2": "15" }, "child": [] }] })(props);
}
function FiFileText(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" }, "child": [] }, { "tag": "polyline", "attr": { "points": "14 2 14 8 20 8" }, "child": [] }, { "tag": "line", "attr": { "x1": "16", "y1": "13", "x2": "8", "y2": "13" }, "child": [] }, { "tag": "line", "attr": { "x1": "16", "y1": "17", "x2": "8", "y2": "17" }, "child": [] }, { "tag": "polyline", "attr": { "points": "10 9 9 9 8 9" }, "child": [] }] })(props);
}
function FiFile(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z" }, "child": [] }, { "tag": "polyline", "attr": { "points": "13 2 13 9 20 9" }, "child": [] }] })(props);
}
function FiFilm(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "2", "y": "2", "width": "20", "height": "20", "rx": "2.18", "ry": "2.18" }, "child": [] }, { "tag": "line", "attr": { "x1": "7", "y1": "2", "x2": "7", "y2": "22" }, "child": [] }, { "tag": "line", "attr": { "x1": "17", "y1": "2", "x2": "17", "y2": "22" }, "child": [] }, { "tag": "line", "attr": { "x1": "2", "y1": "12", "x2": "22", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "2", "y1": "7", "x2": "7", "y2": "7" }, "child": [] }, { "tag": "line", "attr": { "x1": "2", "y1": "17", "x2": "7", "y2": "17" }, "child": [] }, { "tag": "line", "attr": { "x1": "17", "y1": "17", "x2": "22", "y2": "17" }, "child": [] }, { "tag": "line", "attr": { "x1": "17", "y1": "7", "x2": "22", "y2": "7" }, "child": [] }] })(props);
}
function FiFilter(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" }, "child": [] }] })(props);
}
function FiFlag(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" }, "child": [] }, { "tag": "line", "attr": { "x1": "4", "y1": "22", "x2": "4", "y2": "15" }, "child": [] }] })(props);
}
function FiFolderMinus(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "14", "x2": "15", "y2": "14" }, "child": [] }] })(props);
}
function FiFolderPlus(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "11", "x2": "12", "y2": "17" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "14", "x2": "15", "y2": "14" }, "child": [] }] })(props);
}
function FiFolder(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" }, "child": [] }] })(props);
}
function FiFramer(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M5 16V9h14V2H5l14 14h-7m-7 0l7 7v-7m-7 0h7" }, "child": [] }] })(props);
}
function FiFrown(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "path", "attr": { "d": "M16 16s-1.5-2-4-2-4 2-4 2" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "9", "x2": "9.01", "y2": "9" }, "child": [] }, { "tag": "line", "attr": { "x1": "15", "y1": "9", "x2": "15.01", "y2": "9" }, "child": [] }] })(props);
}
function FiGift(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "20 12 20 22 4 22 4 12" }, "child": [] }, { "tag": "rect", "attr": { "x": "2", "y": "7", "width": "20", "height": "5" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "22", "x2": "12", "y2": "7" }, "child": [] }, { "tag": "path", "attr": { "d": "M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z" }, "child": [] }, { "tag": "path", "attr": { "d": "M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z" }, "child": [] }] })(props);
}
function FiGitBranch(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "6", "y1": "3", "x2": "6", "y2": "15" }, "child": [] }, { "tag": "circle", "attr": { "cx": "18", "cy": "6", "r": "3" }, "child": [] }, { "tag": "circle", "attr": { "cx": "6", "cy": "18", "r": "3" }, "child": [] }, { "tag": "path", "attr": { "d": "M18 9a9 9 0 0 1-9 9" }, "child": [] }] })(props);
}
function FiGitCommit(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "1.05", "y1": "12", "x2": "7", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "17.01", "y1": "12", "x2": "22.96", "y2": "12" }, "child": [] }] })(props);
}
function FiGitMerge(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "18", "cy": "18", "r": "3" }, "child": [] }, { "tag": "circle", "attr": { "cx": "6", "cy": "6", "r": "3" }, "child": [] }, { "tag": "path", "attr": { "d": "M6 21V9a9 9 0 0 0 9 9" }, "child": [] }] })(props);
}
function FiGitPullRequest(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "18", "cy": "18", "r": "3" }, "child": [] }, { "tag": "circle", "attr": { "cx": "6", "cy": "6", "r": "3" }, "child": [] }, { "tag": "path", "attr": { "d": "M13 6h3a2 2 0 0 1 2 2v7" }, "child": [] }, { "tag": "line", "attr": { "x1": "6", "y1": "9", "x2": "6", "y2": "21" }, "child": [] }] })(props);
}
function FiGithub(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22" }, "child": [] }] })(props);
}
function FiGitlab(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M22.65 14.39L12 22.13 1.35 14.39a.84.84 0 0 1-.3-.94l1.22-3.78 2.44-7.51A.42.42 0 0 1 4.82 2a.43.43 0 0 1 .58 0 .42.42 0 0 1 .11.18l2.44 7.49h8.1l2.44-7.51A.42.42 0 0 1 18.6 2a.43.43 0 0 1 .58 0 .42.42 0 0 1 .11.18l2.44 7.51L23 13.45a.84.84 0 0 1-.35.94z" }, "child": [] }] })(props);
}
function FiGlobe(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "2", "y1": "12", "x2": "22", "y2": "12" }, "child": [] }, { "tag": "path", "attr": { "d": "M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" }, "child": [] }] })(props);
}
function FiGrid(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "3", "width": "7", "height": "7" }, "child": [] }, { "tag": "rect", "attr": { "x": "14", "y": "3", "width": "7", "height": "7" }, "child": [] }, { "tag": "rect", "attr": { "x": "14", "y": "14", "width": "7", "height": "7" }, "child": [] }, { "tag": "rect", "attr": { "x": "3", "y": "14", "width": "7", "height": "7" }, "child": [] }] })(props);
}
function FiHardDrive(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "22", "y1": "12", "x2": "2", "y2": "12" }, "child": [] }, { "tag": "path", "attr": { "d": "M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z" }, "child": [] }, { "tag": "line", "attr": { "x1": "6", "y1": "16", "x2": "6.01", "y2": "16" }, "child": [] }, { "tag": "line", "attr": { "x1": "10", "y1": "16", "x2": "10.01", "y2": "16" }, "child": [] }] })(props);
}
function FiHash(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "4", "y1": "9", "x2": "20", "y2": "9" }, "child": [] }, { "tag": "line", "attr": { "x1": "4", "y1": "15", "x2": "20", "y2": "15" }, "child": [] }, { "tag": "line", "attr": { "x1": "10", "y1": "3", "x2": "8", "y2": "21" }, "child": [] }, { "tag": "line", "attr": { "x1": "16", "y1": "3", "x2": "14", "y2": "21" }, "child": [] }] })(props);
}
function FiHeadphones(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M3 18v-6a9 9 0 0 1 18 0v6" }, "child": [] }, { "tag": "path", "attr": { "d": "M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z" }, "child": [] }] })(props);
}
function FiHeart(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" }, "child": [] }] })(props);
}
function FiHelpCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "path", "attr": { "d": "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "17", "x2": "12.01", "y2": "17" }, "child": [] }] })(props);
}
function FiHexagon(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" }, "child": [] }] })(props);
}
function FiHome(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" }, "child": [] }, { "tag": "polyline", "attr": { "points": "9 22 9 12 15 12 15 22" }, "child": [] }] })(props);
}
function FiImage(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "3", "width": "18", "height": "18", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "circle", "attr": { "cx": "8.5", "cy": "8.5", "r": "1.5" }, "child": [] }, { "tag": "polyline", "attr": { "points": "21 15 16 10 5 21" }, "child": [] }] })(props);
}
function FiInbox(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "22 12 16 12 14 15 10 15 8 12 2 12" }, "child": [] }, { "tag": "path", "attr": { "d": "M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z" }, "child": [] }] })(props);
}
function FiInfo(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "16", "x2": "12", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "8", "x2": "12.01", "y2": "8" }, "child": [] }] })(props);
}
function FiInstagram(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "2", "y": "2", "width": "20", "height": "20", "rx": "5", "ry": "5" }, "child": [] }, { "tag": "path", "attr": { "d": "M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" }, "child": [] }, { "tag": "line", "attr": { "x1": "17.5", "y1": "6.5", "x2": "17.51", "y2": "6.5" }, "child": [] }] })(props);
}
function FiItalic(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "19", "y1": "4", "x2": "10", "y2": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "14", "y1": "20", "x2": "5", "y2": "20" }, "child": [] }, { "tag": "line", "attr": { "x1": "15", "y1": "4", "x2": "9", "y2": "20" }, "child": [] }] })(props);
}
function FiKey(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4" }, "child": [] }] })(props);
}
function FiLayers(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "12 2 2 7 12 12 22 7 12 2" }, "child": [] }, { "tag": "polyline", "attr": { "points": "2 17 12 22 22 17" }, "child": [] }, { "tag": "polyline", "attr": { "points": "2 12 12 17 22 12" }, "child": [] }] })(props);
}
function FiLayout(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "3", "width": "18", "height": "18", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "3", "y1": "9", "x2": "21", "y2": "9" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "21", "x2": "9", "y2": "9" }, "child": [] }] })(props);
}
function FiLifeBuoy(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "4.93", "y1": "4.93", "x2": "9.17", "y2": "9.17" }, "child": [] }, { "tag": "line", "attr": { "x1": "14.83", "y1": "14.83", "x2": "19.07", "y2": "19.07" }, "child": [] }, { "tag": "line", "attr": { "x1": "14.83", "y1": "9.17", "x2": "19.07", "y2": "4.93" }, "child": [] }, { "tag": "line", "attr": { "x1": "14.83", "y1": "9.17", "x2": "18.36", "y2": "5.64" }, "child": [] }, { "tag": "line", "attr": { "x1": "4.93", "y1": "19.07", "x2": "9.17", "y2": "14.83" }, "child": [] }] })(props);
}
function FiLink2(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M15 7h3a5 5 0 0 1 5 5 5 5 0 0 1-5 5h-3m-6 0H6a5 5 0 0 1-5-5 5 5 0 0 1 5-5h3" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "12", "x2": "16", "y2": "12" }, "child": [] }] })(props);
}
function FiLink(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" }, "child": [] }, { "tag": "path", "attr": { "d": "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" }, "child": [] }] })(props);
}
function FiLinkedin(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" }, "child": [] }, { "tag": "rect", "attr": { "x": "2", "y": "9", "width": "4", "height": "12" }, "child": [] }, { "tag": "circle", "attr": { "cx": "4", "cy": "4", "r": "2" }, "child": [] }] })(props);
}
function FiList(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "8", "y1": "6", "x2": "21", "y2": "6" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "12", "x2": "21", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "18", "x2": "21", "y2": "18" }, "child": [] }, { "tag": "line", "attr": { "x1": "3", "y1": "6", "x2": "3.01", "y2": "6" }, "child": [] }, { "tag": "line", "attr": { "x1": "3", "y1": "12", "x2": "3.01", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "3", "y1": "18", "x2": "3.01", "y2": "18" }, "child": [] }] })(props);
}
function FiLoader(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "12", "y1": "2", "x2": "12", "y2": "6" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "18", "x2": "12", "y2": "22" }, "child": [] }, { "tag": "line", "attr": { "x1": "4.93", "y1": "4.93", "x2": "7.76", "y2": "7.76" }, "child": [] }, { "tag": "line", "attr": { "x1": "16.24", "y1": "16.24", "x2": "19.07", "y2": "19.07" }, "child": [] }, { "tag": "line", "attr": { "x1": "2", "y1": "12", "x2": "6", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "18", "y1": "12", "x2": "22", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "4.93", "y1": "19.07", "x2": "7.76", "y2": "16.24" }, "child": [] }, { "tag": "line", "attr": { "x1": "16.24", "y1": "7.76", "x2": "19.07", "y2": "4.93" }, "child": [] }] })(props);
}
function FiLock(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "11", "width": "18", "height": "11", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "path", "attr": { "d": "M7 11V7a5 5 0 0 1 10 0v4" }, "child": [] }] })(props);
}
function FiLogIn(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" }, "child": [] }, { "tag": "polyline", "attr": { "points": "10 17 15 12 10 7" }, "child": [] }, { "tag": "line", "attr": { "x1": "15", "y1": "12", "x2": "3", "y2": "12" }, "child": [] }] })(props);
}
function FiLogOut(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" }, "child": [] }, { "tag": "polyline", "attr": { "points": "16 17 21 12 16 7" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "12", "x2": "9", "y2": "12" }, "child": [] }] })(props);
}
function FiMail(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" }, "child": [] }, { "tag": "polyline", "attr": { "points": "22,6 12,13 2,6" }, "child": [] }] })(props);
}
function FiMapPin(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "10", "r": "3" }, "child": [] }] })(props);
}
function FiMap(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "2", "x2": "8", "y2": "18" }, "child": [] }, { "tag": "line", "attr": { "x1": "16", "y1": "6", "x2": "16", "y2": "22" }, "child": [] }] })(props);
}
function FiMaximize2(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "15 3 21 3 21 9" }, "child": [] }, { "tag": "polyline", "attr": { "points": "9 21 3 21 3 15" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "3", "x2": "14", "y2": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "3", "y1": "21", "x2": "10", "y2": "14" }, "child": [] }] })(props);
}
function FiMaximize(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" }, "child": [] }] })(props);
}
function FiMeh(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "15", "x2": "16", "y2": "15" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "9", "x2": "9.01", "y2": "9" }, "child": [] }, { "tag": "line", "attr": { "x1": "15", "y1": "9", "x2": "15.01", "y2": "9" }, "child": [] }] })(props);
}
function FiMenu(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "3", "y1": "12", "x2": "21", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "3", "y1": "6", "x2": "21", "y2": "6" }, "child": [] }, { "tag": "line", "attr": { "x1": "3", "y1": "18", "x2": "21", "y2": "18" }, "child": [] }] })(props);
}
function FiMessageCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" }, "child": [] }] })(props);
}
function FiMessageSquare(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" }, "child": [] }] })(props);
}
function FiMicOff(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "1", "y1": "1", "x2": "23", "y2": "23" }, "child": [] }, { "tag": "path", "attr": { "d": "M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6" }, "child": [] }, { "tag": "path", "attr": { "d": "M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "19", "x2": "12", "y2": "23" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "23", "x2": "16", "y2": "23" }, "child": [] }] })(props);
}
function FiMic(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" }, "child": [] }, { "tag": "path", "attr": { "d": "M19 10v2a7 7 0 0 1-14 0v-2" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "19", "x2": "12", "y2": "23" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "23", "x2": "16", "y2": "23" }, "child": [] }] })(props);
}
function FiMinimize2(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "4 14 10 14 10 20" }, "child": [] }, { "tag": "polyline", "attr": { "points": "20 10 14 10 14 4" }, "child": [] }, { "tag": "line", "attr": { "x1": "14", "y1": "10", "x2": "21", "y2": "3" }, "child": [] }, { "tag": "line", "attr": { "x1": "3", "y1": "21", "x2": "10", "y2": "14" }, "child": [] }] })(props);
}
function FiMinimize(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M8 3v3a2 2 0 0 1-2 2H3m18 0h-3a2 2 0 0 1-2-2V3m0 18v-3a2 2 0 0 1 2-2h3M3 16h3a2 2 0 0 1 2 2v3" }, "child": [] }] })(props);
}
function FiMinusCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "12", "x2": "16", "y2": "12" }, "child": [] }] })(props);
}
function FiMinusSquare(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "3", "width": "18", "height": "18", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "12", "x2": "16", "y2": "12" }, "child": [] }] })(props);
}
function FiMinus(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "5", "y1": "12", "x2": "19", "y2": "12" }, "child": [] }] })(props);
}
function FiMonitor(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "2", "y": "3", "width": "20", "height": "14", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "21", "x2": "16", "y2": "21" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "17", "x2": "12", "y2": "21" }, "child": [] }] })(props);
}
function FiMoon(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" }, "child": [] }] })(props);
}
function FiMoreHorizontal(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "1" }, "child": [] }, { "tag": "circle", "attr": { "cx": "19", "cy": "12", "r": "1" }, "child": [] }, { "tag": "circle", "attr": { "cx": "5", "cy": "12", "r": "1" }, "child": [] }] })(props);
}
function FiMoreVertical(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "1" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "5", "r": "1" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "19", "r": "1" }, "child": [] }] })(props);
}
function FiMousePointer(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z" }, "child": [] }, { "tag": "path", "attr": { "d": "M13 13l6 6" }, "child": [] }] })(props);
}
function FiMove(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "5 9 2 12 5 15" }, "child": [] }, { "tag": "polyline", "attr": { "points": "9 5 12 2 15 5" }, "child": [] }, { "tag": "polyline", "attr": { "points": "15 19 12 22 9 19" }, "child": [] }, { "tag": "polyline", "attr": { "points": "19 9 22 12 19 15" }, "child": [] }, { "tag": "line", "attr": { "x1": "2", "y1": "12", "x2": "22", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "2", "x2": "12", "y2": "22" }, "child": [] }] })(props);
}
function FiMusic(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M9 18V5l12-2v13" }, "child": [] }, { "tag": "circle", "attr": { "cx": "6", "cy": "18", "r": "3" }, "child": [] }, { "tag": "circle", "attr": { "cx": "18", "cy": "16", "r": "3" }, "child": [] }] })(props);
}
function FiNavigation2(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "12 2 19 21 12 17 5 21 12 2" }, "child": [] }] })(props);
}
function FiNavigation(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "3 11 22 2 13 21 11 13 3 11" }, "child": [] }] })(props);
}
function FiOctagon(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2" }, "child": [] }] })(props);
}
function FiPackage(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "16.5", "y1": "9.4", "x2": "7.5", "y2": "4.21" }, "child": [] }, { "tag": "path", "attr": { "d": "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" }, "child": [] }, { "tag": "polyline", "attr": { "points": "3.27 6.96 12 12.01 20.73 6.96" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "22.08", "x2": "12", "y2": "12" }, "child": [] }] })(props);
}
function FiPaperclip(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" }, "child": [] }] })(props);
}
function FiPauseCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "10", "y1": "15", "x2": "10", "y2": "9" }, "child": [] }, { "tag": "line", "attr": { "x1": "14", "y1": "15", "x2": "14", "y2": "9" }, "child": [] }] })(props);
}
function FiPause(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "6", "y": "4", "width": "4", "height": "16" }, "child": [] }, { "tag": "rect", "attr": { "x": "14", "y": "4", "width": "4", "height": "16" }, "child": [] }] })(props);
}
function FiPenTool(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M12 19l7-7 3 3-7 7-3-3z" }, "child": [] }, { "tag": "path", "attr": { "d": "M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z" }, "child": [] }, { "tag": "path", "attr": { "d": "M2 2l7.586 7.586" }, "child": [] }, { "tag": "circle", "attr": { "cx": "11", "cy": "11", "r": "2" }, "child": [] }] })(props);
}
function FiPercent(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "19", "y1": "5", "x2": "5", "y2": "19" }, "child": [] }, { "tag": "circle", "attr": { "cx": "6.5", "cy": "6.5", "r": "2.5" }, "child": [] }, { "tag": "circle", "attr": { "cx": "17.5", "cy": "17.5", "r": "2.5" }, "child": [] }] })(props);
}
function FiPhoneCall(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M15.05 5A5 5 0 0 1 19 8.95M15.05 1A9 9 0 0 1 23 8.94m-1 7.98v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" }, "child": [] }] })(props);
}
function FiPhoneForwarded(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "19 1 23 5 19 9" }, "child": [] }, { "tag": "line", "attr": { "x1": "15", "y1": "5", "x2": "23", "y2": "5" }, "child": [] }, { "tag": "path", "attr": { "d": "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" }, "child": [] }] })(props);
}
function FiPhoneIncoming(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "16 2 16 8 22 8" }, "child": [] }, { "tag": "line", "attr": { "x1": "23", "y1": "1", "x2": "16", "y2": "8" }, "child": [] }, { "tag": "path", "attr": { "d": "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" }, "child": [] }] })(props);
}
function FiPhoneMissed(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "23", "y1": "1", "x2": "17", "y2": "7" }, "child": [] }, { "tag": "line", "attr": { "x1": "17", "y1": "1", "x2": "23", "y2": "7" }, "child": [] }, { "tag": "path", "attr": { "d": "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" }, "child": [] }] })(props);
}
function FiPhoneOff(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M10.68 13.31a16 16 0 0 0 3.41 2.6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7 2 2 0 0 1 1.72 2v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.42 19.42 0 0 1-3.33-2.67m-2.67-3.34a19.79 19.79 0 0 1-3.07-8.63A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91" }, "child": [] }, { "tag": "line", "attr": { "x1": "23", "y1": "1", "x2": "1", "y2": "23" }, "child": [] }] })(props);
}
function FiPhoneOutgoing(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "23 7 23 1 17 1" }, "child": [] }, { "tag": "line", "attr": { "x1": "16", "y1": "8", "x2": "23", "y2": "1" }, "child": [] }, { "tag": "path", "attr": { "d": "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" }, "child": [] }] })(props);
}
function FiPhone(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" }, "child": [] }] })(props);
}
function FiPieChart(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21.21 15.89A10 10 0 1 1 8 2.83" }, "child": [] }, { "tag": "path", "attr": { "d": "M22 12A10 10 0 0 0 12 2v10z" }, "child": [] }] })(props);
}
function FiPlayCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "polygon", "attr": { "points": "10 8 16 12 10 16 10 8" }, "child": [] }] })(props);
}
function FiPlay(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "5 3 19 12 5 21 5 3" }, "child": [] }] })(props);
}
function FiPlusCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "8", "x2": "12", "y2": "16" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "12", "x2": "16", "y2": "12" }, "child": [] }] })(props);
}
function FiPlusSquare(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "3", "width": "18", "height": "18", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "8", "x2": "12", "y2": "16" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "12", "x2": "16", "y2": "12" }, "child": [] }] })(props);
}
function FiPlus(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "12", "y1": "5", "x2": "12", "y2": "19" }, "child": [] }, { "tag": "line", "attr": { "x1": "5", "y1": "12", "x2": "19", "y2": "12" }, "child": [] }] })(props);
}
function FiPocket(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M4 3h16a2 2 0 0 1 2 2v6a10 10 0 0 1-10 10A10 10 0 0 1 2 11V5a2 2 0 0 1 2-2z" }, "child": [] }, { "tag": "polyline", "attr": { "points": "8 10 12 14 16 10" }, "child": [] }] })(props);
}
function FiPower(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M18.36 6.64a9 9 0 1 1-12.73 0" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "2", "x2": "12", "y2": "12" }, "child": [] }] })(props);
}
function FiPrinter(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "6 9 6 2 18 2 18 9" }, "child": [] }, { "tag": "path", "attr": { "d": "M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2" }, "child": [] }, { "tag": "rect", "attr": { "x": "6", "y": "14", "width": "12", "height": "8" }, "child": [] }] })(props);
}
function FiRadio(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "2" }, "child": [] }, { "tag": "path", "attr": { "d": "M16.24 7.76a6 6 0 0 1 0 8.49m-8.48-.01a6 6 0 0 1 0-8.49m11.31-2.82a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14" }, "child": [] }] })(props);
}
function FiRefreshCcw(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "1 4 1 10 7 10" }, "child": [] }, { "tag": "polyline", "attr": { "points": "23 20 23 14 17 14" }, "child": [] }, { "tag": "path", "attr": { "d": "M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15" }, "child": [] }] })(props);
}
function FiRefreshCw(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "23 4 23 10 17 10" }, "child": [] }, { "tag": "polyline", "attr": { "points": "1 20 1 14 7 14" }, "child": [] }, { "tag": "path", "attr": { "d": "M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" }, "child": [] }] })(props);
}
function FiRepeat(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "17 1 21 5 17 9" }, "child": [] }, { "tag": "path", "attr": { "d": "M3 11V9a4 4 0 0 1 4-4h14" }, "child": [] }, { "tag": "polyline", "attr": { "points": "7 23 3 19 7 15" }, "child": [] }, { "tag": "path", "attr": { "d": "M21 13v2a4 4 0 0 1-4 4H3" }, "child": [] }] })(props);
}
function FiRewind(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "11 19 2 12 11 5 11 19" }, "child": [] }, { "tag": "polygon", "attr": { "points": "22 19 13 12 22 5 22 19" }, "child": [] }] })(props);
}
function FiRotateCcw(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "1 4 1 10 7 10" }, "child": [] }, { "tag": "path", "attr": { "d": "M3.51 15a9 9 0 1 0 2.13-9.36L1 10" }, "child": [] }] })(props);
}
function FiRotateCw(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "23 4 23 10 17 10" }, "child": [] }, { "tag": "path", "attr": { "d": "M20.49 15a9 9 0 1 1-2.12-9.36L23 10" }, "child": [] }] })(props);
}
function FiRss(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M4 11a9 9 0 0 1 9 9" }, "child": [] }, { "tag": "path", "attr": { "d": "M4 4a16 16 0 0 1 16 16" }, "child": [] }, { "tag": "circle", "attr": { "cx": "5", "cy": "19", "r": "1" }, "child": [] }] })(props);
}
function FiSave(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" }, "child": [] }, { "tag": "polyline", "attr": { "points": "17 21 17 13 7 13 7 21" }, "child": [] }, { "tag": "polyline", "attr": { "points": "7 3 7 8 15 8" }, "child": [] }] })(props);
}
function FiScissors(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "6", "cy": "6", "r": "3" }, "child": [] }, { "tag": "circle", "attr": { "cx": "6", "cy": "18", "r": "3" }, "child": [] }, { "tag": "line", "attr": { "x1": "20", "y1": "4", "x2": "8.12", "y2": "15.88" }, "child": [] }, { "tag": "line", "attr": { "x1": "14.47", "y1": "14.48", "x2": "20", "y2": "20" }, "child": [] }, { "tag": "line", "attr": { "x1": "8.12", "y1": "8.12", "x2": "12", "y2": "12" }, "child": [] }] })(props);
}
function FiSearch(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "11", "cy": "11", "r": "8" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "21", "x2": "16.65", "y2": "16.65" }, "child": [] }] })(props);
}
function FiSend(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "22", "y1": "2", "x2": "11", "y2": "13" }, "child": [] }, { "tag": "polygon", "attr": { "points": "22 2 15 22 11 13 2 9 22 2" }, "child": [] }] })(props);
}
function FiServer(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "2", "y": "2", "width": "20", "height": "8", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "rect", "attr": { "x": "2", "y": "14", "width": "20", "height": "8", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "6", "y1": "6", "x2": "6.01", "y2": "6" }, "child": [] }, { "tag": "line", "attr": { "x1": "6", "y1": "18", "x2": "6.01", "y2": "18" }, "child": [] }] })(props);
}
function FiSettings(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "3" }, "child": [] }, { "tag": "path", "attr": { "d": "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" }, "child": [] }] })(props);
}
function FiShare2(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "18", "cy": "5", "r": "3" }, "child": [] }, { "tag": "circle", "attr": { "cx": "6", "cy": "12", "r": "3" }, "child": [] }, { "tag": "circle", "attr": { "cx": "18", "cy": "19", "r": "3" }, "child": [] }, { "tag": "line", "attr": { "x1": "8.59", "y1": "13.51", "x2": "15.42", "y2": "17.49" }, "child": [] }, { "tag": "line", "attr": { "x1": "15.41", "y1": "6.51", "x2": "8.59", "y2": "10.49" }, "child": [] }] })(props);
}
function FiShare(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8" }, "child": [] }, { "tag": "polyline", "attr": { "points": "16 6 12 2 8 6" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "2", "x2": "12", "y2": "15" }, "child": [] }] })(props);
}
function FiShieldOff(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M19.69 14a6.9 6.9 0 0 0 .31-2V5l-8-3-3.16 1.18" }, "child": [] }, { "tag": "path", "attr": { "d": "M4.73 4.73L4 5v7c0 6 8 10 8 10a20.29 20.29 0 0 0 5.62-4.38" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "1", "x2": "23", "y2": "23" }, "child": [] }] })(props);
}
function FiShield(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" }, "child": [] }] })(props);
}
function FiShoppingBag(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" }, "child": [] }, { "tag": "line", "attr": { "x1": "3", "y1": "6", "x2": "21", "y2": "6" }, "child": [] }, { "tag": "path", "attr": { "d": "M16 10a4 4 0 0 1-8 0" }, "child": [] }] })(props);
}
function FiShoppingCart(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "9", "cy": "21", "r": "1" }, "child": [] }, { "tag": "circle", "attr": { "cx": "20", "cy": "21", "r": "1" }, "child": [] }, { "tag": "path", "attr": { "d": "M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" }, "child": [] }] })(props);
}
function FiShuffle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "16 3 21 3 21 8" }, "child": [] }, { "tag": "line", "attr": { "x1": "4", "y1": "20", "x2": "21", "y2": "3" }, "child": [] }, { "tag": "polyline", "attr": { "points": "21 16 21 21 16 21" }, "child": [] }, { "tag": "line", "attr": { "x1": "15", "y1": "15", "x2": "21", "y2": "21" }, "child": [] }, { "tag": "line", "attr": { "x1": "4", "y1": "4", "x2": "9", "y2": "9" }, "child": [] }] })(props);
}
function FiSidebar(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "3", "width": "18", "height": "18", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "3", "x2": "9", "y2": "21" }, "child": [] }] })(props);
}
function FiSkipBack(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "19 20 9 12 19 4 19 20" }, "child": [] }, { "tag": "line", "attr": { "x1": "5", "y1": "19", "x2": "5", "y2": "5" }, "child": [] }] })(props);
}
function FiSkipForward(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "5 4 15 12 5 20 5 4" }, "child": [] }, { "tag": "line", "attr": { "x1": "19", "y1": "5", "x2": "19", "y2": "19" }, "child": [] }] })(props);
}
function FiSlack(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M14.5 10c-.83 0-1.5-.67-1.5-1.5v-5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5z" }, "child": [] }, { "tag": "path", "attr": { "d": "M20.5 10H19V8.5c0-.83.67-1.5 1.5-1.5s1.5.67 1.5 1.5-.67 1.5-1.5 1.5z" }, "child": [] }, { "tag": "path", "attr": { "d": "M9.5 14c.83 0 1.5.67 1.5 1.5v5c0 .83-.67 1.5-1.5 1.5S8 21.33 8 20.5v-5c0-.83.67-1.5 1.5-1.5z" }, "child": [] }, { "tag": "path", "attr": { "d": "M3.5 14H5v1.5c0 .83-.67 1.5-1.5 1.5S2 16.33 2 15.5 2.67 14 3.5 14z" }, "child": [] }, { "tag": "path", "attr": { "d": "M14 14.5c0-.83.67-1.5 1.5-1.5h5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5h-5c-.83 0-1.5-.67-1.5-1.5z" }, "child": [] }, { "tag": "path", "attr": { "d": "M15.5 19H14v1.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5-.67-1.5-1.5-1.5z" }, "child": [] }, { "tag": "path", "attr": { "d": "M10 9.5C10 8.67 9.33 8 8.5 8h-5C2.67 8 2 8.67 2 9.5S2.67 11 3.5 11h5c.83 0 1.5-.67 1.5-1.5z" }, "child": [] }, { "tag": "path", "attr": { "d": "M8.5 5H10V3.5C10 2.67 9.33 2 8.5 2S7 2.67 7 3.5 7.67 5 8.5 5z" }, "child": [] }] })(props);
}
function FiSlash(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "4.93", "y1": "4.93", "x2": "19.07", "y2": "19.07" }, "child": [] }] })(props);
}
function FiSliders(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "4", "y1": "21", "x2": "4", "y2": "14" }, "child": [] }, { "tag": "line", "attr": { "x1": "4", "y1": "10", "x2": "4", "y2": "3" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "21", "x2": "12", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "8", "x2": "12", "y2": "3" }, "child": [] }, { "tag": "line", "attr": { "x1": "20", "y1": "21", "x2": "20", "y2": "16" }, "child": [] }, { "tag": "line", "attr": { "x1": "20", "y1": "12", "x2": "20", "y2": "3" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "14", "x2": "7", "y2": "14" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "8", "x2": "15", "y2": "8" }, "child": [] }, { "tag": "line", "attr": { "x1": "17", "y1": "16", "x2": "23", "y2": "16" }, "child": [] }] })(props);
}
function FiSmartphone(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "5", "y": "2", "width": "14", "height": "20", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "18", "x2": "12.01", "y2": "18" }, "child": [] }] })(props);
}
function FiSmile(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "path", "attr": { "d": "M8 14s1.5 2 4 2 4-2 4-2" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "9", "x2": "9.01", "y2": "9" }, "child": [] }, { "tag": "line", "attr": { "x1": "15", "y1": "9", "x2": "15.01", "y2": "9" }, "child": [] }] })(props);
}
function FiSpeaker(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "4", "y": "2", "width": "16", "height": "20", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "14", "r": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "6", "x2": "12.01", "y2": "6" }, "child": [] }] })(props);
}
function FiSquare(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "3", "width": "18", "height": "18", "rx": "2", "ry": "2" }, "child": [] }] })(props);
}
function FiStar(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" }, "child": [] }] })(props);
}
function FiStopCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "rect", "attr": { "x": "9", "y": "9", "width": "6", "height": "6" }, "child": [] }] })(props);
}
function FiSun(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "5" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "1", "x2": "12", "y2": "3" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "21", "x2": "12", "y2": "23" }, "child": [] }, { "tag": "line", "attr": { "x1": "4.22", "y1": "4.22", "x2": "5.64", "y2": "5.64" }, "child": [] }, { "tag": "line", "attr": { "x1": "18.36", "y1": "18.36", "x2": "19.78", "y2": "19.78" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "12", "x2": "3", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "12", "x2": "23", "y2": "12" }, "child": [] }, { "tag": "line", "attr": { "x1": "4.22", "y1": "19.78", "x2": "5.64", "y2": "18.36" }, "child": [] }, { "tag": "line", "attr": { "x1": "18.36", "y1": "5.64", "x2": "19.78", "y2": "4.22" }, "child": [] }] })(props);
}
function FiSunrise(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M17 18a5 5 0 0 0-10 0" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "2", "x2": "12", "y2": "9" }, "child": [] }, { "tag": "line", "attr": { "x1": "4.22", "y1": "10.22", "x2": "5.64", "y2": "11.64" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "18", "x2": "3", "y2": "18" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "18", "x2": "23", "y2": "18" }, "child": [] }, { "tag": "line", "attr": { "x1": "18.36", "y1": "11.64", "x2": "19.78", "y2": "10.22" }, "child": [] }, { "tag": "line", "attr": { "x1": "23", "y1": "22", "x2": "1", "y2": "22" }, "child": [] }, { "tag": "polyline", "attr": { "points": "8 6 12 2 16 6" }, "child": [] }] })(props);
}
function FiSunset(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M17 18a5 5 0 0 0-10 0" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "9", "x2": "12", "y2": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "4.22", "y1": "10.22", "x2": "5.64", "y2": "11.64" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "18", "x2": "3", "y2": "18" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "18", "x2": "23", "y2": "18" }, "child": [] }, { "tag": "line", "attr": { "x1": "18.36", "y1": "11.64", "x2": "19.78", "y2": "10.22" }, "child": [] }, { "tag": "line", "attr": { "x1": "23", "y1": "22", "x2": "1", "y2": "22" }, "child": [] }, { "tag": "polyline", "attr": { "points": "16 5 12 9 8 5" }, "child": [] }] })(props);
}
function FiTable(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18m0 0h10a2 2 0 0 0 2-2V9M9 21H5a2 2 0 0 1-2-2V9m0 0h18" }, "child": [] }] })(props);
}
function FiTablet(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "4", "y": "2", "width": "16", "height": "20", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "18", "x2": "12.01", "y2": "18" }, "child": [] }] })(props);
}
function FiTag(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" }, "child": [] }, { "tag": "line", "attr": { "x1": "7", "y1": "7", "x2": "7.01", "y2": "7" }, "child": [] }] })(props);
}
function FiTarget(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "6" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "2" }, "child": [] }] })(props);
}
function FiTerminal(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "4 17 10 11 4 5" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "19", "x2": "20", "y2": "19" }, "child": [] }] })(props);
}
function FiThermometer(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z" }, "child": [] }] })(props);
}
function FiThumbsDown(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17" }, "child": [] }] })(props);
}
function FiThumbsUp(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" }, "child": [] }] })(props);
}
function FiToggleLeft(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "1", "y": "5", "width": "22", "height": "14", "rx": "7", "ry": "7" }, "child": [] }, { "tag": "circle", "attr": { "cx": "8", "cy": "12", "r": "3" }, "child": [] }] })(props);
}
function FiToggleRight(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "1", "y": "5", "width": "22", "height": "14", "rx": "7", "ry": "7" }, "child": [] }, { "tag": "circle", "attr": { "cx": "16", "cy": "12", "r": "3" }, "child": [] }] })(props);
}
function FiTool(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" }, "child": [] }] })(props);
}
function FiTrash2(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "3 6 5 6 21 6" }, "child": [] }, { "tag": "path", "attr": { "d": "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" }, "child": [] }, { "tag": "line", "attr": { "x1": "10", "y1": "11", "x2": "10", "y2": "17" }, "child": [] }, { "tag": "line", "attr": { "x1": "14", "y1": "11", "x2": "14", "y2": "17" }, "child": [] }] })(props);
}
function FiTrash(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "3 6 5 6 21 6" }, "child": [] }, { "tag": "path", "attr": { "d": "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" }, "child": [] }] })(props);
}
function FiTrello(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "3", "width": "18", "height": "18", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "rect", "attr": { "x": "7", "y": "7", "width": "3", "height": "9" }, "child": [] }, { "tag": "rect", "attr": { "x": "14", "y": "7", "width": "3", "height": "5" }, "child": [] }] })(props);
}
function FiTrendingDown(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "23 18 13.5 8.5 8.5 13.5 1 6" }, "child": [] }, { "tag": "polyline", "attr": { "points": "17 18 23 18 23 12" }, "child": [] }] })(props);
}
function FiTrendingUp(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "23 6 13.5 15.5 8.5 10.5 1 18" }, "child": [] }, { "tag": "polyline", "attr": { "points": "17 6 23 6 23 12" }, "child": [] }] })(props);
}
function FiTriangle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" }, "child": [] }] })(props);
}
function FiTruck(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "1", "y": "3", "width": "15", "height": "13" }, "child": [] }, { "tag": "polygon", "attr": { "points": "16 8 20 8 23 11 23 16 16 16 16 8" }, "child": [] }, { "tag": "circle", "attr": { "cx": "5.5", "cy": "18.5", "r": "2.5" }, "child": [] }, { "tag": "circle", "attr": { "cx": "18.5", "cy": "18.5", "r": "2.5" }, "child": [] }] })(props);
}
function FiTv(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "2", "y": "7", "width": "20", "height": "15", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "polyline", "attr": { "points": "17 2 12 7 7 2" }, "child": [] }] })(props);
}
function FiTwitch(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21 2H3v16h5v4l4-4h5l4-4V2zM11 11V7M16 11V7" }, "child": [] }] })(props);
}
function FiTwitter(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z" }, "child": [] }] })(props);
}
function FiType(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "4 7 4 4 20 4 20 7" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "20", "x2": "15", "y2": "20" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "4", "x2": "12", "y2": "20" }, "child": [] }] })(props);
}
function FiUmbrella(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M23 12a11.05 11.05 0 0 0-22 0zm-5 7a3 3 0 0 1-6 0v-7" }, "child": [] }] })(props);
}
function FiUnderline(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M6 3v7a6 6 0 0 0 6 6 6 6 0 0 0 6-6V3" }, "child": [] }, { "tag": "line", "attr": { "x1": "4", "y1": "21", "x2": "20", "y2": "21" }, "child": [] }] })(props);
}
function FiUnlock(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "11", "width": "18", "height": "11", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "path", "attr": { "d": "M7 11V7a5 5 0 0 1 9.9-1" }, "child": [] }] })(props);
}
function FiUploadCloud(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "16 16 12 12 8 16" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "12", "x2": "12", "y2": "21" }, "child": [] }, { "tag": "path", "attr": { "d": "M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3" }, "child": [] }, { "tag": "polyline", "attr": { "points": "16 16 12 12 8 16" }, "child": [] }] })(props);
}
function FiUpload(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }, "child": [] }, { "tag": "polyline", "attr": { "points": "17 8 12 3 7 8" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "3", "x2": "12", "y2": "15" }, "child": [] }] })(props);
}
function FiUserCheck(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" }, "child": [] }, { "tag": "circle", "attr": { "cx": "8.5", "cy": "7", "r": "4" }, "child": [] }, { "tag": "polyline", "attr": { "points": "17 11 19 13 23 9" }, "child": [] }] })(props);
}
function FiUserMinus(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" }, "child": [] }, { "tag": "circle", "attr": { "cx": "8.5", "cy": "7", "r": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "23", "y1": "11", "x2": "17", "y2": "11" }, "child": [] }] })(props);
}
function FiUserPlus(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" }, "child": [] }, { "tag": "circle", "attr": { "cx": "8.5", "cy": "7", "r": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "20", "y1": "8", "x2": "20", "y2": "14" }, "child": [] }, { "tag": "line", "attr": { "x1": "23", "y1": "11", "x2": "17", "y2": "11" }, "child": [] }] })(props);
}
function FiUserX(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" }, "child": [] }, { "tag": "circle", "attr": { "cx": "8.5", "cy": "7", "r": "4" }, "child": [] }, { "tag": "line", "attr": { "x1": "18", "y1": "8", "x2": "23", "y2": "13" }, "child": [] }, { "tag": "line", "attr": { "x1": "23", "y1": "8", "x2": "18", "y2": "13" }, "child": [] }] })(props);
}
function FiUser(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" }, "child": [] }, { "tag": "circle", "attr": { "cx": "12", "cy": "7", "r": "4" }, "child": [] }] })(props);
}
function FiUsers(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" }, "child": [] }, { "tag": "circle", "attr": { "cx": "9", "cy": "7", "r": "4" }, "child": [] }, { "tag": "path", "attr": { "d": "M23 21v-2a4 4 0 0 0-3-3.87" }, "child": [] }, { "tag": "path", "attr": { "d": "M16 3.13a4 4 0 0 1 0 7.75" }, "child": [] }] })(props);
}
function FiVideoOff(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M16 16v1a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2m5.66 0H14a2 2 0 0 1 2 2v3.34l1 1L23 7v10" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "1", "x2": "23", "y2": "23" }, "child": [] }] })(props);
}
function FiVideo(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "23 7 16 12 23 17 23 7" }, "child": [] }, { "tag": "rect", "attr": { "x": "1", "y": "5", "width": "15", "height": "14", "rx": "2", "ry": "2" }, "child": [] }] })(props);
}
function FiVoicemail(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "5.5", "cy": "11.5", "r": "4.5" }, "child": [] }, { "tag": "circle", "attr": { "cx": "18.5", "cy": "11.5", "r": "4.5" }, "child": [] }, { "tag": "line", "attr": { "x1": "5.5", "y1": "16", "x2": "18.5", "y2": "16" }, "child": [] }] })(props);
}
function FiVolume1(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "11 5 6 9 2 9 2 15 6 15 11 19 11 5" }, "child": [] }, { "tag": "path", "attr": { "d": "M15.54 8.46a5 5 0 0 1 0 7.07" }, "child": [] }] })(props);
}
function FiVolume2(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "11 5 6 9 2 9 2 15 6 15 11 19 11 5" }, "child": [] }, { "tag": "path", "attr": { "d": "M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07" }, "child": [] }] })(props);
}
function FiVolumeX(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "11 5 6 9 2 9 2 15 6 15 11 19 11 5" }, "child": [] }, { "tag": "line", "attr": { "x1": "23", "y1": "9", "x2": "17", "y2": "15" }, "child": [] }, { "tag": "line", "attr": { "x1": "17", "y1": "9", "x2": "23", "y2": "15" }, "child": [] }] })(props);
}
function FiVolume(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "11 5 6 9 2 9 2 15 6 15 11 19 11 5" }, "child": [] }] })(props);
}
function FiWatch(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "7" }, "child": [] }, { "tag": "polyline", "attr": { "points": "12 9 12 12 13.5 13.5" }, "child": [] }, { "tag": "path", "attr": { "d": "M16.51 17.35l-.35 3.83a2 2 0 0 1-2 1.82H9.83a2 2 0 0 1-2-1.82l-.35-3.83m.01-10.7l.35-3.83A2 2 0 0 1 9.83 1h4.35a2 2 0 0 1 2 1.82l.35 3.83" }, "child": [] }] })(props);
}
function FiWifiOff(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "1", "y1": "1", "x2": "23", "y2": "23" }, "child": [] }, { "tag": "path", "attr": { "d": "M16.72 11.06A10.94 10.94 0 0 1 19 12.55" }, "child": [] }, { "tag": "path", "attr": { "d": "M5 12.55a10.94 10.94 0 0 1 5.17-2.39" }, "child": [] }, { "tag": "path", "attr": { "d": "M10.71 5.05A16 16 0 0 1 22.58 9" }, "child": [] }, { "tag": "path", "attr": { "d": "M1.42 9a15.91 15.91 0 0 1 4.7-2.88" }, "child": [] }, { "tag": "path", "attr": { "d": "M8.53 16.11a6 6 0 0 1 6.95 0" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "20", "x2": "12.01", "y2": "20" }, "child": [] }] })(props);
}
function FiWifi(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M5 12.55a11 11 0 0 1 14.08 0" }, "child": [] }, { "tag": "path", "attr": { "d": "M1.42 9a16 16 0 0 1 21.16 0" }, "child": [] }, { "tag": "path", "attr": { "d": "M8.53 16.11a6 6 0 0 1 6.95 0" }, "child": [] }, { "tag": "line", "attr": { "x1": "12", "y1": "20", "x2": "12.01", "y2": "20" }, "child": [] }] })(props);
}
function FiWind(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M9.59 4.59A2 2 0 1 1 11 8H2m10.59 11.41A2 2 0 1 0 14 16H2m15.73-8.27A2.5 2.5 0 1 1 19.5 12H2" }, "child": [] }] })(props);
}
function FiXCircle(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "12", "cy": "12", "r": "10" }, "child": [] }, { "tag": "line", "attr": { "x1": "15", "y1": "9", "x2": "9", "y2": "15" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "9", "x2": "15", "y2": "15" }, "child": [] }] })(props);
}
function FiXOctagon(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "7.86 2 16.14 2 22 7.86 22 16.14 16.14 22 7.86 22 2 16.14 2 7.86 7.86 2" }, "child": [] }, { "tag": "line", "attr": { "x1": "15", "y1": "9", "x2": "9", "y2": "15" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "9", "x2": "15", "y2": "15" }, "child": [] }] })(props);
}
function FiXSquare(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "rect", "attr": { "x": "3", "y": "3", "width": "18", "height": "18", "rx": "2", "ry": "2" }, "child": [] }, { "tag": "line", "attr": { "x1": "9", "y1": "9", "x2": "15", "y2": "15" }, "child": [] }, { "tag": "line", "attr": { "x1": "15", "y1": "9", "x2": "9", "y2": "15" }, "child": [] }] })(props);
}
function FiX(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "line", "attr": { "x1": "18", "y1": "6", "x2": "6", "y2": "18" }, "child": [] }, { "tag": "line", "attr": { "x1": "6", "y1": "6", "x2": "18", "y2": "18" }, "child": [] }] })(props);
}
function FiYoutube(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "path", "attr": { "d": "M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33A2.78 2.78 0 0 0 3.4 19c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.25 29 29 0 0 0-.46-5.33z" }, "child": [] }, { "tag": "polygon", "attr": { "points": "9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02" }, "child": [] }] })(props);
}
function FiZapOff(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polyline", "attr": { "points": "12.41 6.75 13 2 10.57 4.92" }, "child": [] }, { "tag": "polyline", "attr": { "points": "18.57 12.91 21 10 15.66 10" }, "child": [] }, { "tag": "polyline", "attr": { "points": "8 8 3 14 12 14 11 22 16 16" }, "child": [] }, { "tag": "line", "attr": { "x1": "1", "y1": "1", "x2": "23", "y2": "23" }, "child": [] }] })(props);
}
function FiZap(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "polygon", "attr": { "points": "13 2 3 14 12 14 11 22 21 10 12 10 13 2" }, "child": [] }] })(props);
}
function FiZoomIn(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "11", "cy": "11", "r": "8" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "21", "x2": "16.65", "y2": "16.65" }, "child": [] }, { "tag": "line", "attr": { "x1": "11", "y1": "8", "x2": "11", "y2": "14" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "11", "x2": "14", "y2": "11" }, "child": [] }] })(props);
}
function FiZoomOut(props) {
  return GenIcon({ "tag": "svg", "attr": { "viewBox": "0 0 24 24", "fill": "none", "stroke": "currentColor", "strokeWidth": "2", "strokeLinecap": "round", "strokeLinejoin": "round" }, "child": [{ "tag": "circle", "attr": { "cx": "11", "cy": "11", "r": "8" }, "child": [] }, { "tag": "line", "attr": { "x1": "21", "y1": "21", "x2": "16.65", "y2": "16.65" }, "child": [] }, { "tag": "line", "attr": { "x1": "8", "y1": "11", "x2": "14", "y2": "11" }, "child": [] }] })(props);
}
export {
  FiActivity,
  FiAirplay,
  FiAlertCircle,
  FiAlertOctagon,
  FiAlertTriangle,
  FiAlignCenter,
  FiAlignJustify,
  FiAlignLeft,
  FiAlignRight,
  FiAnchor,
  FiAperture,
  FiArchive,
  FiArrowDown,
  FiArrowDownCircle,
  FiArrowDownLeft,
  FiArrowDownRight,
  FiArrowLeft,
  FiArrowLeftCircle,
  FiArrowRight,
  FiArrowRightCircle,
  FiArrowUp,
  FiArrowUpCircle,
  FiArrowUpLeft,
  FiArrowUpRight,
  FiAtSign,
  FiAward,
  FiBarChart,
  FiBarChart2,
  FiBattery,
  FiBatteryCharging,
  FiBell,
  FiBellOff,
  FiBluetooth,
  FiBold,
  FiBook,
  FiBookOpen,
  FiBookmark,
  FiBox,
  FiBriefcase,
  FiCalendar,
  FiCamera,
  FiCameraOff,
  FiCast,
  FiCheck,
  FiCheckCircle,
  FiCheckSquare,
  FiChevronDown,
  FiChevronLeft,
  FiChevronRight,
  FiChevronUp,
  FiChevronsDown,
  FiChevronsLeft,
  FiChevronsRight,
  FiChevronsUp,
  FiChrome,
  FiCircle,
  FiClipboard,
  FiClock,
  FiCloud,
  FiCloudDrizzle,
  FiCloudLightning,
  FiCloudOff,
  FiCloudRain,
  FiCloudSnow,
  FiCode,
  FiCodepen,
  FiCodesandbox,
  FiCoffee,
  FiColumns,
  FiCommand,
  FiCompass,
  FiCopy,
  FiCornerDownLeft,
  FiCornerDownRight,
  FiCornerLeftDown,
  FiCornerLeftUp,
  FiCornerRightDown,
  FiCornerRightUp,
  FiCornerUpLeft,
  FiCornerUpRight,
  FiCpu,
  FiCreditCard,
  FiCrop,
  FiCrosshair,
  FiDatabase,
  FiDelete,
  FiDisc,
  FiDivide,
  FiDivideCircle,
  FiDivideSquare,
  FiDollarSign,
  FiDownload,
  FiDownloadCloud,
  FiDribbble,
  FiDroplet,
  FiEdit,
  FiEdit2,
  FiEdit3,
  FiExternalLink,
  FiEye,
  FiEyeOff,
  FiFacebook,
  FiFastForward,
  FiFeather,
  FiFigma,
  FiFile,
  FiFileMinus,
  FiFilePlus,
  FiFileText,
  FiFilm,
  FiFilter,
  FiFlag,
  FiFolder,
  FiFolderMinus,
  FiFolderPlus,
  FiFramer,
  FiFrown,
  FiGift,
  FiGitBranch,
  FiGitCommit,
  FiGitMerge,
  FiGitPullRequest,
  FiGithub,
  FiGitlab,
  FiGlobe,
  FiGrid,
  FiHardDrive,
  FiHash,
  FiHeadphones,
  FiHeart,
  FiHelpCircle,
  FiHexagon,
  FiHome,
  FiImage,
  FiInbox,
  FiInfo,
  FiInstagram,
  FiItalic,
  FiKey,
  FiLayers,
  FiLayout,
  FiLifeBuoy,
  FiLink,
  FiLink2,
  FiLinkedin,
  FiList,
  FiLoader,
  FiLock,
  FiLogIn,
  FiLogOut,
  FiMail,
  FiMap,
  FiMapPin,
  FiMaximize,
  FiMaximize2,
  FiMeh,
  FiMenu,
  FiMessageCircle,
  FiMessageSquare,
  FiMic,
  FiMicOff,
  FiMinimize,
  FiMinimize2,
  FiMinus,
  FiMinusCircle,
  FiMinusSquare,
  FiMonitor,
  FiMoon,
  FiMoreHorizontal,
  FiMoreVertical,
  FiMousePointer,
  FiMove,
  FiMusic,
  FiNavigation,
  FiNavigation2,
  FiOctagon,
  FiPackage,
  FiPaperclip,
  FiPause,
  FiPauseCircle,
  FiPenTool,
  FiPercent,
  FiPhone,
  FiPhoneCall,
  FiPhoneForwarded,
  FiPhoneIncoming,
  FiPhoneMissed,
  FiPhoneOff,
  FiPhoneOutgoing,
  FiPieChart,
  FiPlay,
  FiPlayCircle,
  FiPlus,
  FiPlusCircle,
  FiPlusSquare,
  FiPocket,
  FiPower,
  FiPrinter,
  FiRadio,
  FiRefreshCcw,
  FiRefreshCw,
  FiRepeat,
  FiRewind,
  FiRotateCcw,
  FiRotateCw,
  FiRss,
  FiSave,
  FiScissors,
  FiSearch,
  FiSend,
  FiServer,
  FiSettings,
  FiShare,
  FiShare2,
  FiShield,
  FiShieldOff,
  FiShoppingBag,
  FiShoppingCart,
  FiShuffle,
  FiSidebar,
  FiSkipBack,
  FiSkipForward,
  FiSlack,
  FiSlash,
  FiSliders,
  FiSmartphone,
  FiSmile,
  FiSpeaker,
  FiSquare,
  FiStar,
  FiStopCircle,
  FiSun,
  FiSunrise,
  FiSunset,
  FiTable,
  FiTablet,
  FiTag,
  FiTarget,
  FiTerminal,
  FiThermometer,
  FiThumbsDown,
  FiThumbsUp,
  FiToggleLeft,
  FiToggleRight,
  FiTool,
  FiTrash,
  FiTrash2,
  FiTrello,
  FiTrendingDown,
  FiTrendingUp,
  FiTriangle,
  FiTruck,
  FiTv,
  FiTwitch,
  FiTwitter,
  FiType,
  FiUmbrella,
  FiUnderline,
  FiUnlock,
  FiUpload,
  FiUploadCloud,
  FiUser,
  FiUserCheck,
  FiUserMinus,
  FiUserPlus,
  FiUserX,
  FiUsers,
  FiVideo,
  FiVideoOff,
  FiVoicemail,
  FiVolume,
  FiVolume1,
  FiVolume2,
  FiVolumeX,
  FiWatch,
  FiWifi,
  FiWifiOff,
  FiWind,
  FiX,
  FiXCircle,
  FiXOctagon,
  FiXSquare,
  FiYoutube,
  FiZap,
  FiZapOff,
  FiZoomIn,
  FiZoomOut
};
//# sourceMappingURL=react-icons_fi.js.map
